export const PHASES = [
    {
        id: 'document', title: 'I. THE DOCUMENT', subtitle: 'Before there was a place, there was a page.',
        historicalNote: 'Museum of Me began closer to an interactive document than a physical building; the content was organized by page.',
        fromZ: 18, checkpointZ: 10, accent: '#dfb886'
    },
    {
        id: 'rooms', title: 'II. THE ROOMS', subtitle: 'Many rooms. Not yet one museum.',
        historicalNote: 'The early Reliquary took the form of separate scenes and disconnected rooms, not a continuous place.',
        fromZ: -34, checkpointZ: -39, accent: '#c4b1ff'
    },
    {
        id: 'monolith', title: 'III. THE MONOLITH', subtitle: 'One file held an entire world. And its weight.',
        historicalNote: 'The restored Reliquary was a large self-contained Three.js HTML artifact. Its recovery exposed the costs of an everything-in-one-file architecture.',
        fromZ: -77, checkpointZ: -82, accent: '#adcefb'
    },
    {
        id: 'vnext', title: 'IV. THE BECOMING', subtitle: 'A separate lineage. Still under construction.',
        historicalNote: 'Museum of Me vNext is an evolving, distinct codebase with one navigable building, a central Rotunda, themed wings and an island exterior. It is not a finished 1.0 release.',
        fromZ: -123, checkpointZ: -129, accent: '#e6bf73'
    }
];
/**
 * Overlapping platforms allow traversal without mandatory precision jumps.
 * Sub-0.46 m changes are automatic step-ups; jumping remains expressive.
 */
export const PLATFORMS = [
    { id: 'p01', phase: 'document', x: 0, z: 8, width: 10, length: 24, top: 0, kind: 'floor' },
    { id: 'p02', phase: 'document', x: -0.9, z: -11, width: 6.2, length: 16, top: 0.15, kind: 'floor' },
    { id: 'p03', phase: 'document', x: 0.9, z: -25, width: 7.6, length: 15.2, top: 0.35, kind: 'floor' },
    { id: 'p04', phase: 'rooms', x: -0.8, z: -39, width: 7.0, length: 16, top: 0.55, kind: 'floor' },
    { id: 'p05', phase: 'rooms', x: 0.8, z: -52, width: 5.4, length: 13.5, top: 0.85, kind: 'bridge' },
    { id: 'p06', phase: 'rooms', x: -0.7, z: -65, width: 7.4, length: 15.2, top: 1.1, kind: 'floor' },
    { id: 'p07', phase: 'monolith', x: 0, z: -79, width: 7.5, length: 14.5, top: 1.35, kind: 'floor' },
    { id: 'p08', phase: 'monolith', x: 0.7, z: -91, width: 5.5, length: 12.6, top: 1.75, kind: 'step' },
    { id: 'p09', phase: 'monolith', x: -0.7, z: -103, width: 5.5, length: 12.6, top: 2.15, kind: 'step' },
    { id: 'p10', phase: 'monolith', x: 0, z: -115, width: 7.0, length: 12.6, top: 2.55, kind: 'step' },
    { id: 'p11', phase: 'vnext', x: 0, z: -128, width: 8.4, length: 15.0, top: 2.8, kind: 'bridge' },
    { id: 'p12', phase: 'vnext', x: -0.7, z: -141, width: 7.2, length: 13.5, top: 3.15, kind: 'bridge' },
    { id: 'p13', phase: 'vnext', x: 0.7, z: -154, width: 7.5, length: 13.5, top: 3.5, kind: 'bridge' },
    { id: 'p14', phase: 'vnext', x: 0, z: -168, width: 8.0, length: 15.0, top: 3.9, kind: 'bridge' },
    { id: 'p15', phase: 'vnext', x: 0, z: -183, width: 11.8, length: 18.0, top: 4.3, kind: 'view' }
];
export const START = { x: 0, y: 0, z: 15 };
export const GOAL_Z = -183;
export const RECOVERY_Y = -24;
export function phaseIndexAt(z) {
    if (z <= PHASES[3].fromZ)
        return 3;
    if (z <= PHASES[2].fromZ)
        return 2;
    if (z <= PHASES[1].fromZ)
        return 1;
    return 0;
}
export function containsXZ(p, x, z, inset = 0) {
    return Math.abs(x - p.x) <= p.width / 2 + inset && Math.abs(z - p.z) <= p.length / 2 + inset;
}
export function floorBelow(x, z, footY, stepLimit = 0.48) {
    let best = null;
    for (const p of PLATFORMS) {
        if (!containsXZ(p, x, z, 0.19))
            continue;
        if (p.top > footY + stepLimit)
            continue;
        if (best === null || p.top > best.top)
            best = p;
    }
    return best;
}
export function checkpointFor(z) {
    const index = phaseIndexAt(z);
    const phase = PHASES[index];
    const p = floorBelow(0, phase.checkpointZ, 10, 0) ?? PLATFORMS[0];
    return { x: p.x, y: p.top, z: phase.checkpointZ, phase: phase.id };
}
/** Explicitly reject mandatory progression locks in this independent exhibit. */
export function canEnterPhase(_previous, _next) { return true; }
