import { EXPERIMENTS, completedExperiments } from './core/experiments.js';
import { landmarksIn } from './core/expedition.js';
import { SEASONS } from './core/seasons.js';
import { OBSERVATIONS, narrativeStatus } from './core/mystery.js';
import { echoDifferences, heartIrrigation, causalStage } from './core/simulation.js';
import { resonanceChannels, resonanceReading } from './core/resonance.js';
import { fieldNote } from './core/guidance.js';
import { WORLD_NAMES, WEATHER, extraDroplets, constellationPower, lightAligned, tideAt, ruinsComplete, TERRAIN_ZONES } from './core/state.js';
import { CONSTELLATION_SHAPES, edgeKey } from './worlds/garden.js';
const TOOLS = {
    0: [{ id: 'inspect', name: 'Observe', glyph: '◎' }, { id: 'gravity', name: 'Gravity', glyph: '◈' }, { id: 'echo', name: 'Echo', glyph: '◷' }],
    1: [{ id: 'inspect', name: 'Observe', glyph: '◎' }, { id: 'sculpt', name: 'Sculpt', glyph: '⌁' }, { id: 'river', name: 'Rivers', glyph: '≈' }, { id: 'seed', name: 'Seeds', glyph: '✿' }, { id: 'moon', name: 'Tides', glyph: '◔' }, { id: 'light', name: 'Light', glyph: '◇' }, { id: 'wildlife', name: 'Wildlife', glyph: '♧' }, { id: 'ruins', name: 'Ruins', glyph: '⌂' }, { id: 'echo', name: 'Echo', glyph: '◷' }],
    2: [{ id: 'inspect', name: 'Observe', glyph: '◎' }, { id: 'constellation', name: 'Stars', glyph: '✧' }, { id: 'echo', name: 'Echo', glyph: '◷' }]
};
export const TOOL_HINTS = {
    inspect: 'Drag to look around. Click an object to inspect. Move with W A S D.',
    gravity: 'Drag the great raindrop to tilt gravity inside. Sliders offer precise control.',
    sculpt: 'Drag upward or downward in the three glowing terrain zones; use the zone buttons for precise steps.',
    river: 'Drag across the landscape to draw a real watercourse. You can also add aimed waypoints.',
    seed: 'Touch a patch of earth to plant. Each seed matures while the simulation runs.',
    constellation: 'Drag between bright stars, or connect the next line using the keyboard-accessible controls.',
    moon: 'Drag the moon or change its orbital angle. The shoreline answers.',
    light: 'Drag the prism and mirror, or tune both angles until the receivers align.',
    wildlife: 'Touch earth to place an attraction beacon; touch a beacon to remove it.',
    ruins: 'Drag stone fragments toward their turquoise sockets until they snap into position.',
    echo: 'Capture the environment, then restore any captured version. The ghost remembers.',
};
const esc = (s) => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));
const timeText = (time) => {
    const h = Math.floor(time) % 24, m = Math.floor((time - h) * 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};
const opt = (items, active) => items.map(x => `<option value="${esc(x)}" ${active === x ? 'selected' : ''}>${esc(x)}</option>`).join('');
export class UI {
    store;
    host;
    root;
    toastEl;
    worldEl;
    detailEl;
    toolEl;
    settingsEl;
    timeEl;
    weatherEl;
    mobileEl;
    settingsOpen = false;
    journalOpen = false;
    atlasOpen = false;
    atlasEl;
    activeExperiment = null;
    photoEl;
    journalEl;
    journalHash = '';
    resonanceEl;
    saveAlert;
    saveMessage;
    toolsOpen = false;
    hiddenUI = false;
    lastWorld = -1;
    lastTool = 'inspect';
    lastEchoCount = 0;
    lastRedraw = 0;
    constructor(store, host) {
        this.store = store;
        this.host = host;
        const root = document.getElementById('interface');
        if (!root)
            throw new Error('Missing UI root');
        this.root = root;
        root.innerHTML = `
      <div class="topbar" data-ui>
        <div class="brand"><span class="brand-mark">◈</span><span class="brand-name">INFINITUM</span><span class="brand-sub">The Rain That Remembers Stars · DexGPT Edition</span></div>
        <div class="world-heading" id="world-heading" aria-live="polite"></div>
        <div class="top-actions">
          <button type="button" class="icon-button" data-action="resonance-toggle" aria-pressed="false" aria-label="Resonance sight: show real connections across scales (X)" title="Resonance sight (X)">⌁</button>
          <button type="button" class="icon-button" data-action="focus" aria-label="Find the next droplet" title="Find the next droplet">⌖</button>
          <button type="button" class="icon-button" data-action="atlas" aria-label="Expedition atlas (M)" title="Expedition atlas (M)">⌾</button>
          <button type="button" class="icon-button" data-action="photo-toggle" aria-label="Photo mode (P)" title="Photo mode (P)">▣</button>
          <button type="button" class="icon-button" data-action="journal" aria-label="Observation journal (J)" title="Observations (J)">✦</button>
          <button type="button" class="icon-button" data-action="settings" aria-label="Environment controls" title="Environment controls">☼</button>
          <button type="button" class="icon-button" data-action="toggle-tools" aria-label="Interactive systems" title="Interactive systems">☷</button>
          <button type="button" class="icon-button" data-action="hide" aria-label="Hide all controls (H)" title="Hide controls (H)">×</button>
        </div>
      </div>
      <div class="top-trail" data-ui><span>THE OUTER WORLD</span><span class="trail-line"></span><strong id="world-number">I / III</strong></div>
      <div class="scale-atlas" data-ui aria-label="Current nested world">
        <span class="atlas-title">SCALE / DEPTH</span>
        <div class="atlas-orbit"><span class="atlas-glyph">◈</span><span>01</span></div>
        <div class="atlas-spine"></div>
        <div class="atlas-orbit"><span class="atlas-glyph">◌</span><span>02</span></div>
        <div class="atlas-spine"></div>
        <div class="atlas-orbit"><span class="atlas-glyph">✧</span><span>03</span></div>
      </div>
      <div class="spatial-reticle" id="spatial-reticle" data-ui aria-hidden="true"><span></span></div>
      <aside class="resonance-readout surface" id="resonance-readout" data-ui aria-label="Cross-scale resonance sight" hidden>
        <div class="resonance-head"><span class="micro-label">RESONANCE SIGHT · X</span><button type="button" data-action="resonance-toggle" aria-label="Close resonance sight">×</button></div>
        <div id="resonance-intro" class="resonance-intro"></div>
        <div class="resonance-channels">
          ${['water', 'stars', 'alignment'].map((id, i) => `<div class="resonance-channel" data-channel="${id}"><span class="resonance-symbol">${['≈', '✧', '◈'][i]}</span><div><strong class="resonance-title"></strong><p class="resonance-description"></p><div class="resonance-meter" aria-hidden="true"><i></i></div></div></div>`).join('')}
        </div>
        <p class="resonance-foot">These luminous paths occupy real space. Each responds to the state of all three worlds.</p>
      </aside>
      <aside class="settings-panel surface" id="settings-panel" hidden data-ui aria-label="Environment and accessibility">
        <div class="panel-head"><strong>CELESTIAL WEATHER</strong><button type="button" class="icon-button" data-action="settings" aria-label="Close settings">×</button></div>
        <div class="environment-inner"></div>
      </aside>
      <aside class="journal-panel surface" id="journal-panel" hidden data-ui aria-label="Observation journal">
        <div class="panel-head"><strong>THE FIELD NOTEBOOK</strong><button type="button" class="icon-button" data-action="journal" aria-label="Close observations">×</button></div>
        <div id="journal-body"></div>
      </aside>
      <aside class="atlas-panel surface" id="atlas-panel" hidden data-ui aria-label="Expedition atlas">
        <div class="panel-head"><strong>THE EXPEDITION ATLAS</strong><button type="button" class="icon-button" data-action="atlas" aria-label="Close atlas">×</button></div>
        <div id="atlas-body"></div>
      </aside>
      <aside class="systems-panel surface" id="systems-panel" hidden data-ui aria-label="World interaction systems">
        <div class="panel-head"><strong>INSTRUMENTS OF INFLUENCE</strong><button type="button" class="icon-button" data-action="toggle-tools" aria-label="Close interaction controls">×</button></div>
        <div class="tool-buttons" id="tool-buttons"></div>
        <div class="tool-details" id="tool-details"></div>
      </aside>
      <div class="bottom-rail" data-ui>
        <div class="bottom-left"><span class="hairline">◌</span> <span id="status-time">17:36</span> <span class="separator">/</span> <span id="status-weather">CLEAR</span></div>
        <div class="center-actions">
          <button type="button" class="action-pill" id="portal-button" data-action="enter"><span class="pulse">◉</span> <span id="portal-label">APPROACH THE DROP</span> <span class="key">E</span></button>
          <div class="tiny-hint" id="tiny-hint">The first world is smaller than it appears.</div>
        </div>
        <div class="bottom-right">
          <button type="button" class="text-button" id="mode-button" data-action="mode">ORBIT</button>
          <button type="button" class="text-button" data-action="reset-camera">RESET <span class="key">C</span></button>
          <button type="button" class="text-button" id="return-button" data-action="back">RETURN <span class="key">R</span></button>
        </div>
      </div>
      <div class="scene-caption" id="scene-caption" data-ui></div>
      <div class="toast" id="toast" role="status" aria-live="polite" hidden></div>
      <div class="save-alert surface" id="save-alert" data-ui role="alert" hidden>
        <span id="save-message"></span>
        <div><button type="button" data-action="save-export">EXPORT CURRENT WORLD</button><button type="button" id="save-recovery" data-action="save-recovery" hidden>RECOVER ORIGINAL</button></div>
      </div>
      <div class="mobile-controls" id="mobile-controls" data-ui>
        <div class="move-pad" aria-label="Mobile movement controls">
          <button type="button" data-hold="KeyW" aria-label="Move forward">↑</button>
          <div><button type="button" data-hold="KeyA" aria-label="Move left">←</button><button type="button" data-hold="KeyS" aria-label="Move backward">↓</button><button type="button" data-hold="KeyD" aria-label="Move right">→</button></div>
        </div>
        <div class="vertical-pad"><button type="button" data-hold="Space" aria-label="Ascend">UP</button><button type="button" data-hold="ShiftLeft" aria-label="Descend">DOWN</button></div>
      </div>
      <div class="photo-interface" id="photo-interface" data-photo hidden>
        <div class="photo-crosshair" aria-hidden="true"></div>
        <div class="photo-instructions">PHOTO MODE · DRAG TO FRAME · K TO CAPTURE · P TO EXIT</div>
        <div class="photo-actions"><button type="button" data-action="photo-capture" aria-label="Save this view as PNG">CAPTURE FRAME · K</button><button type="button" data-action="photo-toggle" aria-label="Exit photo mode">RETURN TO WORLD · P</button></div>
      </div>
      <div class="focus-restore" id="focus-restore" hidden><button type="button" data-action="hide" aria-label="Show controls (H)">SHOW CONTROLS · H</button></div>
      `;
        this.toastEl = root.querySelector('#toast');
        this.resonanceEl = root.querySelector('#resonance-readout');
        this.saveAlert = root.querySelector('#save-alert');
        this.saveMessage = root.querySelector('#save-message');
        this.worldEl = root.querySelector('#world-heading');
        this.detailEl = root.querySelector('#tool-details');
        this.toolEl = root.querySelector('#tool-buttons');
        this.settingsEl = root.querySelector('#settings-panel');
        this.journalEl = root.querySelector('#journal-panel');
        this.atlasEl = root.querySelector('#atlas-panel');
        this.photoEl = root.querySelector('#photo-interface');
        this.timeEl = root.querySelector('#status-time');
        this.weatherEl = root.querySelector('#status-weather');
        this.mobileEl = root.querySelector('#mobile-controls');
        // Pointer-hold buttons are a real touch movement adapter.
        root.addEventListener('pointerdown', event => {
            const b = event.target.closest('[data-hold]');
            if (b) {
                event.preventDefault();
                b.setPointerCapture(event.pointerId);
                this.host.action('hold-on', b.dataset.hold);
            }
        });
        const release = (event) => {
            const b = event.target.closest('[data-hold]');
            if (b) {
                event.preventDefault();
                this.host.action('hold-off', b.dataset.hold);
            }
        };
        root.addEventListener('pointerup', release);
        root.addEventListener('pointercancel', release);
        root.addEventListener('click', event => {
            const button = event.target.closest('[data-action]');
            if (!button)
                return;
            const action = button.dataset.action;
            if (action === 'settings') {
                this.settingsOpen = !this.settingsOpen;
                this.toolsOpen = false;
                this.journalOpen = false;
                this.atlasOpen = false;
                this.renderPanels();
                return;
            }
            if (action === 'journal') {
                this.toggleJournal();
                return;
            }
            if (action === 'atlas') {
                this.toggleAtlas();
                return;
            }
            if (action === 'experiment-focus') {
                this.activeExperiment = button.dataset.value ?? null;
                this.renderJournal();
                return;
            }
            if (action === 'toggle-tools') {
                this.toolsOpen = !this.toolsOpen;
                this.settingsOpen = false;
                this.journalOpen = false;
                this.atlasOpen = false;
                this.renderPanels();
                return;
            }
            if (action === 'hide') {
                this.hiddenUI = !this.hiddenUI;
                this.applyHidden();
                return;
            }
            if (action === 'select-tool') {
                this.host.setTool(button.dataset.value);
                this.toolsOpen = true;
                this.renderPanels();
                return;
            }
            this.host.action(action, button.dataset.value);
        });
        root.addEventListener('input', event => {
            const input = event.target;
            const field = input.dataset.field;
            if (!field)
                return;
            this.host.action(`input:${field}`, input.type === 'checkbox' ? String(input.checked) : input.value);
            if (input instanceof HTMLInputElement && input.type === 'range') {
                const node = input.closest('.range-group')?.querySelector('output');
                if (node)
                    node.textContent = input.value;
            }
        });
        root.addEventListener('change', event => {
            const input = event.target;
            if (input.id === 'import-save') {
                const file = input.files?.[0];
                input.value = '';
                if (!file)
                    return;
                if (file.size > 2_000_000) {
                    this.showToast('Save rejected: maximum 2 MB.');
                    return;
                }
                void file.text().then(value => this.host.action('save-import', value)).catch(() => this.showToast('Unable to read that save file.'));
                return;
            }
            if (input.dataset.field)
                this.host.action('edit-end');
            const field = input.dataset.field;
            if (field && input.type !== 'checkbox')
                this.host.action(`change:${field}`, input.value);
        });
        this.renderPanels();
        this.refresh(true);
    }
    get isHidden() { return this.hiddenUI; }
    toggleHidden() { this.hiddenUI = !this.hiddenUI; this.applyHidden(); }
    toggleJournal(open) { this.journalOpen = open ?? !this.journalOpen; this.settingsOpen = false; this.toolsOpen = false; this.atlasOpen = false; this.renderPanels(); }
    toggleAtlas(open) { this.atlasOpen = open ?? !this.atlasOpen; this.settingsOpen = false; this.toolsOpen = false; this.journalOpen = false; this.renderPanels(); }
    setPhotoMode(on) { this.root.classList.toggle('photo-mode', on); this.photoEl.hidden = !on; if (on)
        this.renderPanels(); }
    applyHidden() {
        this.root.classList.toggle('all-hidden', this.hiddenUI);
        const focus = this.root.querySelector('#focus-restore');
        if (focus)
            focus.hidden = !this.hiddenUI;
        if (this.hiddenUI) {
            this.settingsOpen = false;
            this.toolsOpen = false;
            this.journalOpen = false;
            this.atlasOpen = false;
            this.renderPanels();
        }
    }
    showToast(message) {
        this.toastEl.textContent = message;
        this.toastEl.hidden = false;
        // No timers: the single render loop applies expiration.
        this.toastEl.dataset.until = String(performance.now() + 3700);
    }
    setCaption(message) { const c = this.root.querySelector('#scene-caption'); if (c)
        c.textContent = message; }
    renderPanels() {
        this.settingsEl.hidden = !this.settingsOpen;
        this.journalEl.hidden = !this.journalOpen;
        this.atlasEl.hidden = !this.atlasOpen;
        if (this.atlasOpen)
            this.renderAtlas();
        if (this.journalOpen)
            this.renderJournal();
        const t = this.root.querySelector('#systems-panel');
        t.hidden = !this.toolsOpen;
        if (this.settingsOpen)
            this.renderEnvironment();
        if (this.toolsOpen)
            this.renderTools();
    }
    renderAtlas() {
        const places = landmarksIn(this.host.world);
        this.atlasEl.querySelector('#atlas-body').innerHTML = `
      <p class="journal-lead">This world can be learned by its landmarks. Focusing moves the camera through space; crossing worlds still requires the droplets.</p>
      <div class="micro-label">${esc(WORLD_NAMES[this.host.world])} · ${places.length} OBSERVABLE PLACES</div>
      <div class="atlas-destinations">${places.map((p, i) => `<article><span class="atlas-index">${String(i + 1).padStart(2, '0')}</span><div><b>${esc(p.name)}</b><p>${esc(p.note)}</p></div><button type="button" data-action="focus-landmark" data-value="${esc(p.id)}">FOCUS</button></article>`).join('')}</div>
      <div class="micro-label">THE THREE DEPTHS</div>
      <p class="value-note">${this.host.world === 0 ? 'Enter the first suspended droplet.' : this.host.world === 1 ? 'The tree carries the next droplet.' : 'Return through the luminous membrane to the tree.'}</p>
    `;
    }
    renderJournal() {
        const s = this.store.data, story = narrativeStatus(s);
        const found = OBSERVATIONS.filter(x => s.knowledge.includes(x.id));
        const completed = completedExperiments(s);
        const lastEcho = this.store.selectedEcho;
        const changes = lastEcho ? echoDifferences(s, lastEcho.data) : [];
        this.journalEl.querySelector('#journal-body').innerHTML = `
      <div class="micro-label">RESONANCE / ${causalStage(s)} OF 3</div>
      <h3 class="journal-heading">${esc(story.title)}</h3>
      <p class="journal-lead">${esc(story.hint)}</p>
      <div class="micro-label">THE WORLD'S OBSERVATIONS · ${found.length}/${OBSERVATIONS.length}</div>
      <div class="journal-list">${found.length ? found.map(o => `<article><b>${esc(o.title)}</b><p>${esc(o.text)}</p><small>${WORLD_NAMES[o.world]}</small></article>`).join('') : '<p class="value-note">Inspect strange structures with I or the Aim Inspect button. Your observations will remain here.</p>'}</div>
      <div class="micro-label">EXPERIMENTS · ${completed.length}/${EXPERIMENTS.length} OBSERVED</div>
      <div class="experiment-list">${EXPERIMENTS.map(e => {
            const done = e.test(s), focus = e.id === this.activeExperiment;
            return `<article class="experiment" ${done ? 'data-complete="true"' : ''}><button type="button" data-action="experiment-focus" data-value="${esc(e.id)}" aria-expanded="${focus}"><span>${done ? '✦' : '◇'}</span><strong>${esc(e.title)}</strong></button><p>${esc(e.question)}</p>${focus ? `<p class="experiment-hint">${esc(e.hint)}</p>` : ''}</article>`;
        }).join('')}</div>
      <div class="micro-label">THE CAUSAL THREAD</div>
      <div class="causal-readout"><span class="${heartIrrigation(s) > .48 ? 'active' : ''}">01 · WATER & GROWTH</span><span class="${s.constellations.some(v => v.startsWith('complete:')) ? 'active' : ''}">02 · STARS</span><span class="${causalStage(s) === 3 ? 'active' : ''}">03 · GRAVITY & LIGHT</span></div>
      <p class="value-note">Heart Tree irrigation: ${Math.round(heartIrrigation(s) * 100)}%. ${s.endingSeen ? 'The correspondence has been witnessed.' : 'A change at one scale may answer at another.'}</p>
      ${lastEcho ? `<div class="micro-label">SELECTED PAST · ${esc(lastEcho.at)}</div><p class="value-note">${changes.length ? 'Since then: ' + esc(changes.join(', ')) + '.' : 'The selected past and present still agree.'}</p>` : ''}
    `;
    }
    renderEnvironment() {
        const s = this.store.data;
        this.settingsEl.querySelector('.environment-inner').innerHTML = `
      <div class="micro-label">SINGLE SHARED CLOCK</div>
      <label class="range-group"><span>Solar hour <output>${s.time.toFixed(1)}</output></span><input aria-label="Time of day" data-field="time" type="range" min="0" max="24" step="0.05" value="${s.time}" /></label>
      <div class="inline-3"><button type="button" data-action="pause-time">${s.paused ? 'RESUME' : 'PAUSE'} TIME</button><button type="button" data-action="rate-half">SLOW</button><button type="button" data-action="rate-double">FASTER</button></div>
      <div class="value-note">${s.timeRate.toFixed(2)} simulated hours per second</div>
      <div class="micro-label">THE PASSAGE OF SEASONS</div>
      <label class="control-label">Season <select data-field="season" aria-label="Current season">${opt(SEASONS, s.season)}</select></label>
      <div class="micro-label">ATMOSPHERIC CONDITIONS</div>
      <label class="control-label">Weather <select data-field="weather" aria-label="Weather condition">${opt(WEATHER, s.weather)}</select></label>
      <div class="micro-label">RENDER BUDGET</div>
      <label class="control-label">Quality <select data-field="quality" aria-label="Rendering quality">${opt(['low', 'medium', 'high'], s.quality)}</select></label>
      <label class="check-line"><input data-field="adaptiveQuality" type="checkbox" ${s.adaptiveQuality ? 'checked' : ''}/><span>Automatic resolution scaling · currently ${this.host.resolutionScale}%</span></label>
      <label class="check-line"><input data-field="reducedMotion" type="checkbox" ${s.reducedMotion ? 'checked' : ''}/><span>Reduced motion</span></label>
      <label class="check-line"><input data-field="sound" type="checkbox" ${this.host.soundEnabled ? 'checked' : ''}/><span>Procedural three-world soundscapes (opt-in)</span></label>
      <div class="panel-note">Local simulation only. No login, telemetry or paid services.</div>
      <button type="button" data-action="resonance-toggle">${this.host.resonanceActive ? 'CLOSE' : 'OPEN'} RESONANCE SIGHT · X</button>
      <p class="panel-note">Reveal a world-space diagram of actual irrigation, constellation and gravity state. No progress is awarded for opening it.</p>
      <div class="inline-3"><button data-action="mode">${this.host.navigationMode.toUpperCase()} / CHANGE</button><button data-action="back">RETURN</button><button data-action="hide">HIDE UI</button></div>
      <div class="micro-label">PRESERVE / REVERSE / SHARE</div>
      <div class="inline-2"><button type="button" data-action="undo" aria-label="Undo last world edit">UNDO · Z</button><button type="button" data-action="redo" aria-label="Redo last world edit">REDO · Y</button></div>
      <div class="inline-2"><button type="button" data-action="save-export">EXPORT SAVE</button><button type="button" data-action="save-browse">IMPORT SAVE</button></div>
      <input id="import-save" type="file" accept=".json,application/json" hidden aria-label="Choose a local INFINITUM save file"/>
      <p class="panel-note">Export and import use local JSON files. No account or network is required.</p>
      <button type="button" data-action="diagnostics">RENDER DIAGNOSTICS (V)</button>
      <button type="button" class="danger-lite" data-action="reset-state">RESET SIMULATION STATE</button>
    `;
    }
    renderTools() {
        const selected = this.host.tool, world = this.host.world;
        this.toolEl.innerHTML = TOOLS[world].map(t => `<button type="button" data-action="select-tool" data-value="${t.id}" ${selected === t.id ? 'aria-pressed="true"' : ''} class="tool-choice ${selected === t.id ? 'active' : ''}"><span>${t.glyph}</span>${t.name}</button>`).join('');
        this.detailEl.innerHTML = `<p class="tool-instruction">${esc(TOOL_HINTS[selected])}</p>${this.toolSpecific(selected)}`;
    }
    toolSpecific(tool) {
        const s = this.store.data;
        const slider = (label, field, value, min, max, step, unit = '') => `<label class="range-group"><span>${label}<output>${value}${unit}</output></span><input data-field="${field}" type="range" min="${min}" max="${max}" step="${step}" value="${value}" aria-label="${label}"/></label>`;
        switch (tool) {
            case 'inspect': return '<div class="tool-tip">Inspect places to record their discoveries. Press I, or use the aim button. J opens the field notebook. Use O to switch orbit/flight, G for ground navigation.</div><button type="button" data-action="inspect-aim">INSPECT CENTER AIM · I</button>';
            case 'gravity': return `${slider('Horizontal gravity · X', 'gravityX', Math.round(s.gravity[0] * 100), -100, 100, 1)}${slider('Depth gravity · Z', 'gravityZ', Math.round(s.gravity[1] * 100), -100, 100, 1)}<button data-action="gravity-zero">RELEASE THE RAINDROP</button>`;
            case 'sculpt': return `<label class="control-label">Sculpting zone<select data-field="sculptZone">${TERRAIN_ZONES.map((z, i) => `<option value="${i}">${z.name}</option>`).join('')}</select></label><div class="inline-2"><button data-action="sculpt-down">− LOWER EARTH</button><button data-action="sculpt-up">+ RAISE EARTH</button></div><p class="value-note">Actual mesh vertices and trees update together.</p>`;
            case 'river': return `<p class="value-note">Current hand-drawn route: ${this.host.riverPointCount} points. Drag a continuous line over the terrain or use the aim waypoint.</p><div class="inline-2"><button data-action="river-waypoint">ADD AIMED POINT</button><button data-action="river-finish">FINISH CHANNEL</button></div><div class="inline-2"><button data-action="river-undo">UNDO POINT</button><button data-action="river-delete">REMOVE LAST RIVER</button></div>`;
            case 'seed': return `<button data-action="plant-ahead">PLANT AT AIMED EARTH</button><p class="value-note">${s.seeds.length} plants · ${extraDroplets(s)} new droplets on the Heart Tree · ${Math.round(heartIrrigation(s) * 100)}% irrigation.</p>`;
            case 'constellation': {
                const completed = constellationPower(s);
                return `<p class="value-note">${s.constellations.filter(e => e.startsWith('edge:')).length} connections · ${completed} awakened constellations.</p><label class="control-label">Constellation<select data-field="starGroup"><option value="0">THE CROWN</option><option value="1">THE COMPASS</option><option value="2">THE RETURN</option></select></label><button data-action="star-next">CONNECT NEXT UNLINKED STARS</button><p class="tool-tip">Each connected line becomes real geometry. Finish three connected edges to awaken a structure.</p>`;
            }
            case 'moon': return `${slider('Lunar orbital angle', 'moonAngle', Math.round(s.moonAngle * 180 / Math.PI), 0, 360, 1, '°')}<p class="value-note">Tidal displacement: ${tideAt(s.moonAngle).toFixed(2)} m (stylized)</p>`;
            case 'light': return `${slider('Solar prism', 'prismAngle', Math.round(s.prismAngle * 180 / Math.PI), -180, 180, 1, '°')}${slider('Lunar mirror', 'mirrorAngle', Math.round(s.mirrorAngle * 180 / Math.PI), -180, 180, 1, '°')}<p class="value-note">${lightAligned(s) ? 'RECEIVERS ALIGNED · THE RUINS ARE ILLUMINATED' : 'Receiver targets: prism +41°, mirror −28°'}</p>`;
            case 'wildlife': return `<p class="value-note">${s.wildlifeMarkers.length} living attraction marker(s)</p><div class="inline-2"><button data-action="marker-ahead">PLACE AT AIM</button><button data-action="markers-clear">CLEAR ALL</button></div>`;
            case 'ruins': return `<p class="value-note">${s.ruins.filter(r => r.snapped).length} / 3 restored. ${ruinsComplete(s) ? 'THE ARCHITECTURE IS AWAKENING.' : 'Drag a fallen stone onto its luminous socket.'}</p><label class="control-label">Select fragment<select data-field="ruinPiece">${s.ruins.map((r, i) => `<option value="${i}">FRAGMENT ${i + 1} · ${r.snapped ? 'RESTORED' : 'LOOSE'}</option>`).join('')}</select></label><button data-action="ruin-snap">MOVE SELECTED FRAGMENT TO SOCKET</button>`;
            case 'echo': return `<button data-action="echo-capture">CAPTURE TEMPORAL ECHO</button><p class="value-note">View any of five past states without restoring it. Geometry, rivers, growth and constellations appear as a ghost. Restoring remains a separate action.</p><div class="echoes">${this.store.echoes.length ? this.store.echoes.slice().reverse().map(e => `<div class="echo-row" ${this.store.selectedEcho?.id === e.id ? 'data-selected="true"' : ''}><span>◷ ${esc(e.at)}</span><span><button data-action="echo-display" data-value="${e.id}" aria-label="View past ${esc(e.at)}">VIEW</button><button data-action="echo-restore" data-value="${e.id}" aria-label="Restore past ${esc(e.at)}">RESTORE</button></span></div>`).join('') : '<span class="value-note">No memories captured yet.</span>'}</div>`;
        }
    }
    refresh(force = false) {
        const w = this.host.world, s = this.store.data, tool = this.host.tool;
        this.timeEl.textContent = timeText(s.time);
        this.weatherEl.textContent = s.weather.toUpperCase();
        const fieldHint = this.root.querySelector('#tiny-hint');
        if (fieldHint)
            fieldHint.textContent = fieldNote(s, w);
        if (w !== this.lastWorld || force) {
            this.lastWorld = w;
            this.worldEl.textContent = WORLD_NAMES[w];
            this.root.querySelectorAll('.atlas-orbit').forEach((el, i) => {
                el.classList.toggle('active', i === w);
                el.classList.toggle('visited', i < w);
            });
            const n = this.root.querySelector('#world-number');
            if (n)
                n.textContent = ['I / III', 'II / III', 'III / III'][w];
            const action = this.root.querySelector('#portal-button');
            if (action)
                action.hidden = w === 2;
            const label = this.root.querySelector('#portal-label');
            if (label)
                label.textContent = w === 0 ? 'CROSS THE FIRST DROP' : 'CROSS THE LEAF DROP';
            const ret = this.root.querySelector('#return-button');
            if (ret)
                ret.hidden = w === 0;
            this.setCaption(['A single impossible object awaits inspection.', 'The world has a coastline, a memory, and another droplet.', 'Look upward. The cosmos knows the shape of its origin.'][w]);
            this.renderPanels();
        }
        const now = performance.now();
        if (tool !== this.lastTool || this.store.echoes.length !== this.lastEchoCount || force) {
            this.lastTool = tool;
            this.lastEchoCount = this.store.echoes.length;
            if (this.toolsOpen)
                this.renderTools();
        }
        this.root.querySelector('#mode-button').textContent = this.host.navigationMode.toUpperCase();
        this.root.querySelector('#spatial-reticle')?.classList.toggle('tool-active', tool !== 'inspect');
        this.root.dataset.weather = s.weather.toLowerCase();
        if (!this.toastEl.hidden && now > Number(this.toastEl.dataset.until))
            this.toastEl.hidden = true;
        if (now - this.lastRedraw > 1300) {
            this.lastRedraw = now;
            if (this.toolsOpen && tool === 'echo')
                this.renderTools();
            if (this.toolsOpen && tool === 'seed')
                this.renderTools();
            if (this.journalOpen) {
                const hash = JSON.stringify([s.knowledge, s.rivers, s.terrain, s.soilWater, s.constellations, s.endingSeen, s.gravity, s.moonAngle, s.prismAngle, s.mirrorAngle, s.season, this.store.selectedEcho?.id]);
                if (hash !== this.journalHash) {
                    this.journalHash = hash;
                    this.renderJournal();
                }
            }
        }
        const saveState = this.host.saveStatus;
        const needsHelp = saveState === 'blocked' || saveState === 'unavailable';
        this.saveAlert.hidden = !needsHelp || this.host.photoMode;
        if (saveState === 'blocked')
            this.saveMessage.textContent = 'A previous save is damaged. It has NOT been overwritten. Export its original bytes before resetting or importing.';
        else if (saveState === 'unavailable')
            this.saveMessage.textContent = 'This browser cannot save the world right now. Export an expedition file to keep your work.';
        const recovery = this.saveAlert.querySelector('#save-recovery');
        if (recovery)
            recovery.hidden = saveState !== 'blocked';
        this.resonanceEl.hidden = !this.host.resonanceActive || this.hiddenUI || this.host.photoMode || this.settingsOpen || this.toolsOpen || this.atlasOpen || this.journalOpen;
        const button = this.root.querySelector('[data-action="resonance-toggle"]');
        if (button)
            button.setAttribute('aria-pressed', String(this.host.resonanceActive));
        if (!this.resonanceEl.hidden) {
            this.resonanceEl.querySelector('#resonance-intro').textContent = resonanceReading(s, w);
            const channels = resonanceChannels(s);
            for (const channel of channels) {
                const item = this.resonanceEl.querySelector(`[data-channel="${channel.id}"]`);
                item.dataset.complete = String(channel.complete);
                item.querySelector('.resonance-title').textContent = channel.label;
                item.querySelector('.resonance-description').textContent = channel.explanation;
                item.querySelector('.resonance-meter i').style.width = `${Math.round(channel.strength * 100)}%`;
            }
        }
        this.mobileEl.hidden = this.hiddenUI || this.host.photoMode;
    }
    setTool(t) { this.lastTool = 'inspect'; this.host.tool = t; this.toolsOpen = true; this.renderPanels(); }
    dispose() { this.root.replaceChildren(); }
}
export function nextConstellationEdge(s, index) {
    const edges = CONSTELLATION_SHAPES[index] ?? CONSTELLATION_SHAPES[0];
    for (const [a, b] of edges) {
        const key = edgeKey(a, b);
        if (!s.constellations.includes(key))
            return key;
    }
    return null;
}
