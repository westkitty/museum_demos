import * as THREE from 'three';
import { COURSE_FLOORS, GATE_CENTERS, GESTURES } from './domain.js';
import { districtAtX } from './presentation.js';
/** All additions are non-colliding visual surfaces. The level's CPU floor list is authoritative. */
const UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
const prism = (color) => new THREE.MeshStandardMaterial({
    color, metalness: .72, roughness: .27
});
const light = (color, opacity = 1) => new THREE.MeshBasicMaterial({
    color, transparent: opacity < 1, opacity, depthWrite: false, toneMapped: false
});
function cuboid(root, material, w, h, d, x, y, z) {
    const mesh = new THREE.Mesh(UNIT_BOX, material);
    mesh.scale.set(w, h, d);
    mesh.position.set(x, y, z);
    root.add(mesh);
    return mesh;
}
const scratch = new THREE.Object3D();
function batch(root, geometry, material, placements) {
    if (!placements.length)
        return;
    const mesh = new THREE.InstancedMesh(geometry, material, placements.length);
    for (let i = 0; i < placements.length; i++) {
        const v = placements[i];
        scratch.position.set(v.x, v.y, v.z);
        scratch.rotation.set(0, 0, v.angle || 0);
        scratch.scale.set(v.w, v.h, v.d);
        scratch.updateMatrix();
        mesh.setMatrixAt(i, scratch.matrix);
        if (v.color !== undefined)
            mesh.setColorAt(i, new THREE.Color(v.color));
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor)
        mesh.instanceColor.needsUpdate = true;
    mesh.frustumCulled = false;
    root.add(mesh);
}
function drawStreetCanvas(index) {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    if (ctx) {
        ctx.clearRect(0, 0, 512, 256);
        const palettes = ['#58e5e3', '#c89aff', '#ffd182', '#a4ffd3'];
        const tint = palettes[index];
        ctx.strokeStyle = 'rgba(157,218,240,.19)';
        ctx.lineWidth = 2;
        for (let x = 0; x <= 512; x += 32) {
            ctx.beginPath();
            ctx.moveTo(x, 3);
            ctx.lineTo(x, 253);
            ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(173,224,248,.12)';
        for (let y = 0; y <= 256; y += 32) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(512, y);
            ctx.stroke();
        }
        ctx.strokeStyle = tint;
        ctx.lineWidth = 5;
        ctx.globalAlpha = .7;
        for (let edge of [24, 232]) {
            ctx.beginPath();
            ctx.moveTo(0, edge);
            ctx.lineTo(512, edge);
            ctx.stroke();
        }
        ctx.globalAlpha = .42;
        for (let x = 27; x < 512; x += 112) {
            ctx.fillStyle = tint;
            ctx.fillRect(x, 124, 53, 7);
            ctx.fillRect(x + 56, 124, 9, 7);
            ctx.fillStyle = 'rgba(226,245,255,.45)';
            ctx.fillRect(x, 49, 5, 12);
            ctx.fillRect(x + 18, 194, 4, 10);
        }
        ctx.globalAlpha = .44;
        ctx.strokeStyle = tint;
        ctx.lineWidth = 2;
        for (let i = 0; i < 6; i++) {
            const x = i * 96 + 8;
            ctx.beginPath();
            ctx.moveTo(x, 36);
            ctx.lineTo(x + 14, 36);
            ctx.lineTo(x + 20, 48);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(x, 209);
            ctx.lineTo(x + 14, 209);
            ctx.lineTo(x + 20, 197);
            ctx.stroke();
        }
        ctx.globalAlpha = 1;
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    return tex;
}
function drawFlowCanvas(index) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 32;
    const ctx = canvas.getContext('2d');
    if (ctx) {
        ctx.clearRect(0, 0, 256, 32);
        const tones = ['#77fff2', '#ddaaff', '#ffe2a0', '#b9ffe4'];
        for (let x = 0; x < 256; x += 64) {
            const fade = ctx.createLinearGradient(x, 0, x + 52, 0);
            fade.addColorStop(0, 'rgba(0,0,0,0)');
            fade.addColorStop(.65, tones[index]);
            fade.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = fade;
            ctx.fillRect(x, 12, 48, 8);
        }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    return tex;
}
export class StreetFinishes {
    root = new THREE.Group();
    optional = new THREE.Group();
    flowTextures = [];
    counterRotors = [];
    suspendedArcs = [];
    metadata = [];
    signalHubs = [];
    initAngles = [];
    constructor(scene) {
        scene.add(this.root);
        this.root.add(this.optional);
        this.buildStreetSkin();
        this.buildFramingArches();
        this.buildSignalHubs();
    }
    buildStreetSkin() {
        const rim = prism(0x8ab8bd), deep = prism(0x102c42);
        const posts = [], caps = [];
        const textures = GESTURES.map((_g, i) => drawStreetCanvas(i));
        const flowTextures = GESTURES.map((_g, i) => drawFlowCanvas(i));
        this.flowTextures.push(...flowTextures);
        const flowMats = GESTURES.map((g, i) => new THREE.MeshBasicMaterial({
            color: g.color, map: flowTextures[i], transparent: true, opacity: .84,
            depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, side: THREE.DoubleSide
        }));
        for (const [lo, hi] of COURSE_FLOORS) {
            const center = (lo + hi) * .5, len = hi - lo, chapter = districtAtX(center);
            // Canvas map adds fine route language without adding physical platforms.
            const tex = textures[chapter].clone();
            tex.needsUpdate = true;
            tex.repeat.set(Math.max(.5, len / 14), 1);
            const surface = new THREE.Mesh(new THREE.PlaneGeometry(len, 7.55), new THREE.MeshBasicMaterial({
                map: tex, transparent: true, opacity: .52, depthWrite: false, side: THREE.DoubleSide
            }));
            surface.rotation.x = -Math.PI / 2;
            surface.position.set(center, .068, 0);
            this.root.add(surface);
            // Traveling data signal is a 2D texture animation, not many CPU particles.
            for (const z of [-3.8, 3.8]) {
                const flow = new THREE.Mesh(new THREE.PlaneGeometry(len, .22), flowMats[chapter]);
                flow.rotation.x = -Math.PI / 2;
                flow.position.set(center, .179, z);
                this.optional.add(flow);
            }
            // Deep rail mount brackets and ivory-scaled joints punctuate the spine.
            for (const x of [lo + 1.2, hi - 1.2]) {
                for (const side of [-1, 1]) {
                    posts.push({ x, y: -.7, z: side * 4.25, w: .42, h: 1.05, d: 1.18 });
                    caps.push({ x, y: -.16, z: side * 4.25, w: .48, h: .12, d: 1.32 });
                }
            }
        }
        batch(this.root, UNIT_BOX, deep, posts);
        batch(this.root, UNIT_BOX, rim, caps);
        // Retain tile textures as scene-traversable references through the plane maps.
        // The initial templates are never placed on a mesh and can be freed immediately.
        textures.forEach(t => t.dispose());
    }
    buildFramingArches() {
        const spine = prism(0x213c52), chrome = prism(0xa7d5dd), dark = prism(0x0b1b31);
        const sideDiodes = [];
        for (let i = 0; i < 4; i++) {
            const accent = GESTURES[i].color;
            const focusX = 12 + i * 40;
            const portal = new THREE.Group();
            portal.position.set(focusX, 0, 0);
            this.root.add(portal);
            for (const side of [-1, 1]) {
                const z = side * 5.15;
                cuboid(portal, spine, 1, 8.2, 1.1, 0, 4, z);
                cuboid(portal, chrome, 1.1, .28, 1.2, 0, 7.9, z);
                cuboid(portal, light(accent), .16, 6.7, .13, .48, 4.2, z);
                for (let slot = 0; slot < 5; slot++) {
                    sideDiodes.push({ x: focusX + .61, y: 2.2 + slot * 1.3, z, w: .22, h: .19, d: .62, color: accent });
                }
            }
            // The upper aperture is translucent and deliberately high above the visitor.
            const arch = new THREE.Mesh(new THREE.TorusGeometry(4.55, .095, 8, 64, Math.PI), new THREE.MeshBasicMaterial({ color: accent, transparent: true, opacity: .76, depthWrite: false, toneMapped: false }));
            arch.rotation.set(0, Math.PI / 2, 0);
            arch.position.set(.15, 7.1, 0);
            portal.add(arch);
            this.suspendedArcs.push(arch);
            this.metadata.push({ phase: i * 1.6, speed: .21 + i * .036 });
            const header = new THREE.Group();
            header.position.set(0, 10.35, 0);
            portal.add(header);
            cuboid(header, dark, .72, 1.02, 9.9, 0, 0, 0);
            cuboid(header, light(accent), .24, .2, 9.6, .43, -.30, 0);
            const headerChips = [];
            for (let j = 0; j < 8; j++)
                headerChips.push({ x: .42, y: .36, z: -4 + j * 1.14, w: .19, h: .09, d: .38 });
            batch(header, UNIT_BOX, light(accent, .72), headerChips);
            // Always legible: the aperture accent is secondary to the safe deck.
            const title = new THREE.Mesh(new THREE.OctahedronGeometry(.65, 0), light(accent, .87));
            title.position.set(0, 12.05, 0);
            portal.add(title);
        }
        batch(this.optional, UNIT_BOX, light(0xffffff, .82), sideDiodes);
    }
    buildSignalHubs() {
        const steel = prism(0x203347);
        for (let i = 0; i < 4; i++) {
            const x = GATE_CENTERS[i], accent = GESTURES[i].color;
            const rotor = new THREE.Group();
            rotor.position.set(x, 1.45, -5.95);
            this.root.add(rotor);
            const lightMat = light(accent, .68);
            const outer = new THREE.Mesh(new THREE.TorusGeometry(7.35, .15, 9, 72), lightMat);
            rotor.add(outer);
            this.signalHubs.push(outer);
            const spokes = [], diodes = [];
            for (let k = 0; k < 12; k++) {
                const angle = k * Math.PI / 6;
                spokes.push({ x: Math.cos(angle) * 5.5, y: Math.sin(angle) * 5.5, z: 0, w: .12, h: 1.5, d: .16,
                    angle: angle - Math.PI / 2, color: k % 3 === 0 ? 0xb4d3dc : 0x203347 });
                diodes.push({ x: Math.cos(angle) * 7.3, y: Math.sin(angle) * 7.3, z: .08, w: 1, h: 1, d: 1 });
            }
            batch(rotor, UNIT_BOX, prism(0xffffff), spokes);
            batch(rotor, new THREE.IcosahedronGeometry(.23, 0), light(accent, .91), diodes);
            const core = new THREE.Mesh(new THREE.CylinderGeometry(1.18, 1.18, 1.8, 16), steel);
            core.rotation.x = Math.PI / 2;
            rotor.add(core);
            const heart = new THREE.Mesh(new THREE.TorusGeometry(.88, .095, 9, 24), light(accent));
            heart.position.z = 1.01;
            rotor.add(heart);
            this.counterRotors.push(rotor);
            this.initAngles.push(0);
        }
    }
    setGateAngle(index, angle) {
        const rotor = this.counterRotors[index];
        if (!rotor)
            return;
        rotor.rotation.z = -angle * .82;
        this.signalHubs[index].scale.setScalar(1 + Math.abs(angle) * .014);
    }
    reset() {
        this.counterRotors.forEach((r, i) => { r.rotation.z = this.initAngles[i]; this.signalHubs[i].scale.setScalar(1); });
        this.flowTextures.forEach(tex => { tex.offset.x = 0; });
        this.suspendedArcs.forEach((ring, i) => { ring.rotation.z = 0; });
    }
    update(time, reduced) {
        if (reduced)
            return;
        for (let i = 0; i < 4; i++)
            this.flowTextures[i].offset.x = (time * (.07 + i * .012)) % 1;
        this.suspendedArcs.forEach((ring, i) => {
            const m = this.metadata[i];
            ring.rotation.z = Math.sin(time * m.speed + m.phase) * .025;
        });
    }
    setQuality(mode) { this.optional.visible = mode === 'high'; }
}
