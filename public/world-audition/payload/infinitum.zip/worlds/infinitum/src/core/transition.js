import * as THREE from 'three';
import { clamp } from './math.js';
export class TransitionComposer {
    renderer;
    fromTarget;
    toTarget;
    stage = new THREE.Scene();
    ortho = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    material;
    constructor(renderer) {
        this.renderer = renderer;
        const size = new THREE.Vector2();
        renderer.getDrawingBufferSize(size);
        this.fromTarget = new THREE.WebGLRenderTarget(size.x, size.y, { depthBuffer: true });
        this.toTarget = new THREE.WebGLRenderTarget(size.x, size.y, { depthBuffer: true });
        this.material = new THREE.ShaderMaterial({
            uniforms: { uFrom: { value: this.fromTarget.texture }, uTo: { value: this.toTarget.texture }, uProgress: { value: 0 }, uTime: { value: 0 }, uAspect: { value: 1 } },
            vertexShader: `varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`,
            fragmentShader: `uniform sampler2D uFrom;uniform sampler2D uTo;uniform float uProgress;uniform float uTime;uniform float uAspect;varying vec2 vUv;
      void main(){
        vec2 aspect=vec2(uAspect,1.);vec2 p=(vUv-.5)*aspect;
        float r=length(p),extent=length(aspect*.5),t=smoothstep(0.,1.,uProgress);
        // The expanding glass occupies the actual portal center, not a conventional lateral wipe.
        float radius=mix(.003,extent*1.25,t*t*(3.-2.*t));
        float membrane=abs(r-radius);
        float edge=1.-smoothstep(.0,.072,membrane);
        float normalZ=sqrt(max(.001,1.-pow(min(r/max(radius,.001),1.),2.)));
        float bend=pow(1.-normalZ,1.55);
        float wav=sin(r*67.-uTime*1.8+uProgress*19.)*.0022;
        vec2 dir=normalize(p+vec2(.0001));
        vec2 refractOffset=dir*(bend*.036+edge*.016+wav);
        vec3 outer=texture2D(uFrom,clamp(vUv+refractOffset/aspect,0.,1.)).rgb;
        vec3 inner=texture2D(uTo,clamp(vUv-refractOffset/aspect,0.,1.)).rgb;
        float through=1.-smoothstep(radius-.042,radius+.052,r);
        float refractiveBand=exp(-pow(membrane*24.,2.))*min(1.,radius*3.);
        vec3 color=mix(outer,inner,through);
        color=mix(color,color.bgr,edge*.018);
        color+=vec3(.10,.21,.23)*(refractiveBand*.48+edge*.19);
        color+=vec3(.035,.07,.085)*pow(max(0.,1.-normalZ),3.)*(1.-through*.5);
        gl_FragColor=vec4(color,1.);
      }`, depthWrite: false, depthTest: false
        });
        this.stage.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material));
    }
    resize() {
        const size = new THREE.Vector2();
        this.renderer.getDrawingBufferSize(size);
        this.fromTarget.setSize(size.x, size.y);
        this.toTarget.setSize(size.x, size.y);
        this.material.uniforms.uAspect.value = size.x / Math.max(1, size.y);
    }
    render(from, fromCamera, to, toCamera, progress, elapsed) {
        this.renderer.setRenderTarget(this.fromTarget);
        this.renderer.clear();
        this.renderer.render(from, fromCamera);
        this.renderer.setRenderTarget(this.toTarget);
        this.renderer.clear();
        this.renderer.render(to, toCamera);
        this.renderer.setRenderTarget(null);
        this.material.uniforms.uProgress.value = clamp(progress, 0, 1);
        this.material.uniforms.uTime.value = elapsed;
        this.renderer.render(this.stage, this.ortho);
    }
    dispose() { this.fromTarget.dispose(); this.toTarget.dispose(); this.material.dispose(); this.stage.traverse(o => o.geometry?.dispose()); }
}
