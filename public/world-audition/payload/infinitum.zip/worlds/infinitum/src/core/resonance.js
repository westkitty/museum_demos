import { constellationPower, lightAligned, ruinsComplete } from './state.js';
import { causalStage, gravityAligned, heartIrrigation } from './simulation.js';
const cap = (v) => Math.max(0, Math.min(1, v));
export function resonanceChannels(s) {
    const irrigation = heartIrrigation(s), powered = constellationPower(s);
    const planted = s.seeds.some(p => Math.hypot(p.x - 17, p.z + 2) < 27 && p.age > .3);
    const water = irrigation > .48 && planted;
    const celestial = powered > 0;
    const aligned = gravityAligned(s) || ruinsComplete(s);
    return [
        { id: 'water', label: 'THE LIVING CURRENT', explanation: `Heart Tree irrigation ${Math.round(irrigation * 100)}%; ${planted ? 'a seed has matured' : 'no mature seed is near its roots'}.`, strength: cap(irrigation * .7 + (planted ? .3 : 0)), complete: water },
        { id: 'stars', label: 'THE INNER PATTERN', explanation: `${powered} celestial ${powered === 1 ? 'structure' : 'structures'} awakened in the Garden.`, strength: cap(powered / 3), complete: celestial },
        { id: 'alignment', label: 'THE OUTER ANSWER', explanation: aligned ? 'Gravity or restored ruins have aligned the circuit.' : `The outer gravity is displaced; ${lightAligned(s) ? 'the light receivers are aligned' : 'the light receivers await alignment'}.`, strength: aligned ? 1 : lightAligned(s) ? .45 : .08, complete: aligned }
    ];
}
export function resonanceReading(s, world) {
    const stage = causalStage(s), channels = resonanceChannels(s);
    const focus = world === 0 ? channels[2] : world === 1 ? channels[0] : channels[1];
    const pending = channels.filter(c => !c.complete);
    const summary = stage === 3 ? 'THE SCALES HAVE ANSWERED' : `RESONANCE ${stage} / 3`;
    return `${summary} · ${focus.label}: ${focus.explanation} ${pending.length ? `Awaiting ${pending.map(c => c.label.toLowerCase()).join(' and ')}.` : 'The correspondence is complete.'}`;
}
