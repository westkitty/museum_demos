import { clamp } from '../core/math.js';
/** GPU-side leaf/needle movement. No per-frame instance-matrix uploads, shadow-map work,
 * allocations or extra draw calls. The original material remains fully lit and fogged. */
export function windDriven(material, height, strength = 1) {
    const clock = { value: 0 }, amplitude = { value: 0 }, direction = { value: 0 };
    const before = material.onBeforeCompile;
    material.onBeforeCompile = (shader, renderer) => {
        before(shader, renderer);
        shader.uniforms.uInfWindClock = clock;
        shader.uniforms.uInfWindAmplitude = amplitude;
        shader.uniforms.uInfWindDirection = direction;
        shader.vertexShader = shader.vertexShader.replace('void main() {', 'uniform float uInfWindClock; uniform float uInfWindAmplitude; uniform float uInfWindDirection;\nvoid main() {');
        shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
    float infSeed=position.x*1.13+position.z*.83;
    #ifdef USE_INSTANCING
      infSeed += instanceMatrix[3].x*.071 + instanceMatrix[3].z*.093;
    #endif
    float infTip=clamp(max(0.,position.y)/${Math.max(.5, height).toFixed(2)},0.,1.);
    infTip=infTip*infTip*(3.-2.*infTip);
    float infWave=sin(uInfWindClock*.91+infSeed)*.64+sin(uInfWindClock*1.73+infSeed*1.41)*.36;
    transformed.x += infTip*uInfWindAmplitude*(infWave+uInfWindDirection*.42);
    transformed.z += infTip*uInfWindAmplitude*cos(uInfWindClock*.73+infSeed*.77)*.43;
    `);
    };
    const oldKey = material.customProgramCacheKey.bind(material);
    material.customProgramCacheKey = () => oldKey() + '-infinitum-wind-v1-' + height.toFixed(2);
    material.needsUpdate = true;
    return { update(time, s) {
            const weather = s.weather === 'Thunderstorm' ? 1.65 : s.weather === 'Rain' ? 1.05 : s.weather === 'Cloudy' ? .75 : s.weather === 'Snow' ? .38 : .33;
            const motion = s.reducedMotion ? .1 : 1;
            clock.value = time * motion;
            amplitude.value = clamp(weather * strength * motion, 0, 1.6);
            direction.value = s.gravity[0];
        } };
}
