const cap = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const HEART = [17, -2];
export const HYDROLOGY_GRID_SIZE = 26;
export function pointToSegmentDistance(x, z, a, b) {
    const dx = b[0] - a[0], dz = b[1] - a[1], denom = dx * dx + dz * dz;
    const t = denom === 0 ? 0 : cap(((x - a[0]) * dx + (z - a[1]) * dz) / denom);
    return Math.hypot(x - a[0] - t * dx, z - a[1] - t * dz);
}
export function waterProximity(s, x, z) {
    const naturalRiver = -17 + Math.sin(z * .043 + .4) * 10 + Math.cos(z * .087) * 4;
    let distance = Math.abs(x - naturalRiver);
    for (const river of s.rivers)
        for (let i = 1; i < river.length; i++)
            distance = Math.min(distance, pointToSegmentDistance(x, z, river[i - 1], river[i]));
    return Math.exp(-distance / 10);
}
export function soilMoisture(s, x, z) {
    const coastal = z > 62 ? cap((z - 62) / 30) * .6 : 0;
    const depression = Math.max(0, -s.terrain[2]) * Math.exp(-((x - 5) ** 2 + (z + 21) ** 2) / 470) * .043;
    return cap(.08 + s.soilWater * .42 + waterProximity(s, x, z) * .56 + coastal + depression);
}
export function heartIrrigation(s) {
    // The low forest saddle is an authored drainage basin leading toward the Heart Tree.
    const basin = cap(-s.terrain[2] / 12) * .22;
    return cap(soilMoisture(s, HEART[0], HEART[1]) + basin);
}
export function growthRate(s, x, z) {
    return .005 + soilMoisture(s, x, z) * .014;
}
export function stormWaterTarget(s) {
    if (s.weather === 'Thunderstorm')
        return .96;
    if (s.weather === 'Rain')
        return .72;
    if (s.weather === 'Snow')
        return .36;
    if (s.weather === 'Cloudy' || s.weather === 'Fog')
        return .26;
    return .07;
}
export function collectWaterCells(s) {
    const count = HYDROLOGY_GRID_SIZE, values = new Float32Array(count * count);
    for (let z = 0; z < count; z++)
        for (let x = 0; x < count; x++) {
            const wx = (x / (count - 1) - .5) * 230, wz = (z / (count - 1) - .5) * 230;
            values[z * count + x] = soilMoisture(s, wx, wz);
        }
    return values;
}
export function gravityAligned(s) { return s.gravity[0] > .32 && s.gravity[1] < -.18; }
export function gardenAccess(s, index) { return s.constellations.includes(`complete:${index}`); }
export function causalStage(s) {
    const grownNearTree = s.seeds.some(p => Math.hypot(p.x - HEART[0], p.z - HEART[1]) < 27 && p.age > .3);
    const waterSolved = heartIrrigation(s) > .48 && grownNearTree;
    if (!waterSolved)
        return 0;
    if (!gardenAccess(s, 0) && !gardenAccess(s, 1) && !gardenAccess(s, 2))
        return 1;
    if (!(gravityAligned(s) || s.ruins.every(r => r.snapped)))
        return 2;
    return 3;
}
export function finaleReady(s) {
    return causalStage(s) === 3 && s.gardenVisited && s.reveal > .23;
}
export function echoDifferences(now, before) {
    const diff = [];
    if (now.terrain.some((v, i) => Math.abs(v - before.terrain[i]) > .1))
        diff.push('the shape of the earth');
    if (now.rivers.length !== before.rivers.length)
        diff.push('the courses of water');
    if (now.seeds.length !== before.seeds.length || now.seeds.some((v, i) => Math.abs(v.age - (before.seeds[i]?.age ?? 0)) > .15))
        diff.push('living growth');
    if (now.weather !== before.weather)
        diff.push('the atmosphere');
    if (now.constellations.join('|') !== before.constellations.join('|'))
        diff.push('the celestial record');
    if (now.ruins.some((p, i) => p.snapped !== before.ruins[i]?.snapped))
        diff.push('the ruined architecture');
    if (Math.abs(now.moonAngle - before.moonAngle) > .2)
        diff.push('the tide');
    if (Math.abs(now.gravity[0] - before.gravity[0]) > .1 || Math.abs(now.gravity[1] - before.gravity[1]) > .1)
        diff.push('the direction of gravity');
    return diff;
}
