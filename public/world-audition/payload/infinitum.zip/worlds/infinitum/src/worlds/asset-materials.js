/** Original, bundled texture assets for INFINITUM's three mineral/botanical scales.
 * Every call creates scene-owned textures: disposeScene() can reclaim each world
 * without invalidating the independent preview/other world materials.
 * URLs are statically analyzable by Vite and never make external requests.
 */
import * as THREE from 'three';
const SOURCES = {
    slate: {
        color: new URL('../assets/materials/slate_color.png', import.meta.url).href,
        normal: new URL('../assets/materials/slate_normal.png', import.meta.url).href
    },
    bronze: {
        color: new URL('../assets/materials/bronze_color.png', import.meta.url).href,
        normal: new URL('../assets/materials/bronze_normal.png', import.meta.url).href
    },
    bark: {
        color: new URL('../assets/materials/bark_color.png', import.meta.url).href,
        normal: new URL('../assets/materials/bark_normal.png', import.meta.url).href
    },
    roof: {
        color: new URL('../assets/materials/roof_color.png', import.meta.url).href,
        normal: new URL('../assets/materials/roof_normal.png', import.meta.url).href
    },
    moss: {
        color: new URL('../assets/materials/moss_color.png', import.meta.url).href,
        normal: new URL('../assets/materials/moss_normal.png', import.meta.url).href
    },
    astral: {
        color: new URL('../assets/materials/astral_color.png', import.meta.url).href,
        normal: new URL('../assets/materials/astral_normal.png', import.meta.url).href
    }
};
const loader = new THREE.TextureLoader();
function texture(url, repeat, normal) {
    const map = loader.load(url);
    map.wrapS = map.wrapT = THREE.RepeatWrapping;
    map.repeat.set(repeat, repeat);
    map.colorSpace = normal ? THREE.NoColorSpace : THREE.SRGBColorSpace;
    map.minFilter = THREE.LinearMipmapLinearFilter;
    map.magFilter = THREE.LinearFilter;
    map.anisotropy = 4;
    map.name = `infinitum/${normal ? 'normal' : 'color'}/${url.split('/').pop() || 'asset'}`;
    return map;
}
export function authoredSurface(name, opts = {}) {
    const pair = SOURCES[name], repeat = opts.repeat ?? 1;
    const map = texture(pair.color, repeat, false);
    const normalMap = opts.quality === 'low' ? null : texture(pair.normal, repeat, true);
    const mat = new THREE.MeshStandardMaterial({
        color: opts.tint ?? 0xffffff, roughness: opts.roughness ?? .84, metalness: opts.metalness ?? .03,
        vertexColors: opts.vertexColors ?? false, side: opts.side ?? THREE.FrontSide,
        map, normalMap, normalScale: new THREE.Vector2(opts.normalStrength ?? .27, opts.normalStrength ?? .27)
    });
    mat.name = `infinitum/authored/${name}`;
    mat.userData.assetFamily = name;
    return mat;
}
const DECALS = {
    observatory: new URL('../assets/materials/observatory_dial.png', import.meta.url).href,
    celestial: new URL('../assets/materials/astral_seal.png', import.meta.url).href
};
export function authoredDecal(name, opacity = .65) {
    const map = loader.load(DECALS[name]);
    map.colorSpace = THREE.SRGBColorSpace;
    map.minFilter = THREE.LinearMipmapLinearFilter;
    map.magFilter = THREE.LinearFilter;
    map.anisotropy = 4;
    map.name = `infinitum/decal/${name}`;
    const mat = new THREE.MeshBasicMaterial({ map, transparent: true, opacity, depthWrite: false,
        polygonOffset: true, polygonOffsetFactor: -1, side: THREE.DoubleSide });
    mat.name = `infinitum/decal/${name}`;
    return mat;
}
