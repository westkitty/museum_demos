const SOURCE = 'the-machine-that-eats-worlds';
const VERSION = 1;
const EXHIBIT = 'E02';
const REQUEST = 'museum:pocket-world:return-request';
const ACK = 'museum:pocket-world:return-ack';
const READY = 'museum:pocket-world:return-ready';
export function mountE02PocketWorld(path, hooks) {
    const destination = new URL(path, window.location.href);
    if (destination.origin !== window.location.origin)
        throw new Error('E02 must be served on the museum origin.');
    const frame = document.createElement('iframe');
    frame.title = 'The Machine That Eats Worlds — E02 pocket-world';
    frame.setAttribute('aria-label', 'Separate interactive interpretation of four Drakken processes');
    frame.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;border:0;z-index:9999;background:#080d15;';
    frame.allow = 'fullscreen';
    frame.src = destination.href;
    let pendingNonce = null;
    let closed = false;
    let parked = false;
    const isProtocol = (message) => {
        if (!message || typeof message !== 'object')
            return false;
        const m = message;
        return m.version === VERSION && m.source === SOURCE && m.exhibitId === EXHIBIT && typeof m.nonce === 'string' && m.nonce.length > 0 && m.nonce.length < 150;
    };
    const close = () => {
        if (closed)
            return;
        closed = true;
        window.removeEventListener('message', onMessage);
        frame.remove();
        if (parked)
            hooks.resumeMuseum();
        if (hooks.trigger.isConnected)
            hooks.trigger.focus();
    };
    const onMessage = (event) => {
        if (event.origin !== window.location.origin || event.source !== frame.contentWindow || !isProtocol(event.data))
            return;
        const m = event.data;
        if (m.type === REQUEST) {
            pendingNonce = m.nonce;
            frame.contentWindow?.postMessage({ type: ACK, version: VERSION, source: SOURCE, exhibitId: EXHIBIT, nonce: m.nonce }, event.origin);
        }
        else if (m.type === READY && m.nonce === pendingNonce) {
            close();
        }
    };
    hooks.parkMuseum();
    parked = true;
    window.addEventListener('message', onMessage);
    document.body.appendChild(frame);
    frame.focus();
    return close;
}
