import test from 'node:test';
import assert from 'node:assert/strict';
import { createMuseumSession } from '../src/host.ts';

test('mock museum handoff retains original visitor snapshot',async()=>{
  const session=createMuseumSession(undefined);
  assert.equal(session.realHost,false);
  const saved=session.visitorSnapshot;
  const p=await session.returnToMuseum({outcome:'complete',elapsedSeconds:290,stagesGrown:3});
  assert.deepEqual(p.visitorSnapshot,saved);
  assert.equal(p.exhibitId,'E31');
  assert.equal(p.pocketWorld,'breath-of-the-wildly-overwatered');
  assert.equal(p.outcome,'complete');
});

test('host integration delegates return only when explicitly requested',async()=>{
  let calls=0;const saved={room:'storyworlds',visited:19,yaw:.9};
  const session=createMuseumSession({captureVisitorState(){return saved;},returnToMuseum(c){calls++;assert.deepEqual(c.visitorSnapshot,saved);}});
  assert.equal(session.realHost,true);assert.equal(calls,0);
  await session.returnToMuseum({outcome:'abandoned',elapsedSeconds:28,stagesGrown:1});
  assert.equal(calls,1);
});
