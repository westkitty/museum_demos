import * as THREE from 'three';

import { InputRouter } from './game/input.js';
import { DEVICES, REWARDS, THRONE_BUTTON } from './game/layout.js';
import { MECHANISMS, SAVE_KEY, collect, engaged, finish, freshProgress, parseProgress, partyMeter, rewardCount, throneUnlocked } from './game/rules.js';
import { ToyWorld } from './game/world.js';
import { requestMuseumReturn } from './museum.js';
const app = document.querySelector('#app');
if (!app)
    throw new Error('Missing game mount');
app.innerHTML = `
  <canvas id="viewport" aria-label="Three-dimensional toy-castle game. Keyboard controls: arrows or WASD, Space to jump, E to interact." aria-describedby="controls-hint" role="application" tabindex="0"></canvas>
  <div id="grain" aria-hidden="true"></div><div id="vignette" aria-hidden="true"></div>
  <main id="hud" aria-label="Game information">
    <div class="brand" aria-label="Full Weasel 64">
      <div class="brand-logo" aria-hidden="true">★</div>
      <div><div class="brand-kicker">STINKY WEASEL ARCADE · E27</div><div class="brand-title">FULL WEASEL <span style="color:#ffda82">64</span></div><div class="brand-sub">THE PARTY IS IN ANOTHER CABINET</div></div>
    </div>
    <aside class="quest-panel" aria-label="Collected rewards">
      <div class="quest-kicker">THE THREE GOLDEN STARS</div>
      <div class="quest-row" data-quest="crank"><div class="quest-coin">☆</div><div><div class="quest-name">CLOCKWORK CRANK</div><div class="quest-state">Wind to unlock</div></div></div>
      <div class="quest-row" data-quest="catch"><div class="quest-coin">☆</div><div><div class="quest-name">CATCH CONSERVATORY</div><div class="quest-state">Release to unlock</div></div></div>
      <div class="quest-row" data-quest="lever"><div class="quest-coin">☆</div><div><div class="quest-name">LEVER LANES</div><div class="quest-state">Pull to unlock</div></div></div>
    </aside>
    <nav id="route-ribbon" aria-label="Quest route overview" aria-live="off">
      <span class="route-unit" data-route="crank"><span class="route-index">I</span> CLOCKWORK</span><span class="route-joint" aria-hidden="true">✦</span>
      <span class="route-unit" data-route="catch"><span class="route-index">II</span> CONSERVATORY</span><span class="route-joint" aria-hidden="true">✦</span>
      <span class="route-unit" data-route="lever"><span class="route-index">III</span> LEVER LANES</span>
    </nav>
    <aside class="hud-right"><div class="meter-card" aria-label="Party meter"><div class="meter-heading"><span>PARTY POWER</span><output id="meter-number" aria-label="Party power percentage">0%</output></div><div class="meter-track"><div class="meter-fill" id="meter-fill"></div></div><div class="meter-note" id="meter-note">0 / 3 GOLDEN STARS</div></div><button id="pause-button" class="icon-button" aria-label="Pause and settings" title="Pause and settings">⚙</button></aside>
    <div id="zone-banner" aria-live="polite"></div><div id="interaction-cue" aria-live="polite"><span class="keycap">E</span><span id="action-label">Interact</span></div><div id="toast" role="status" aria-live="polite"></div>
    <div id="checkpoint-readout" aria-live="polite"><span aria-hidden="true">◆</span> CASTLE HUB · CHECKPOINT</div>
    <div id="controls-hint">WASD / ARROWS · MOVE &nbsp; SPACE · JUMP &nbsp; E · INTERACT &nbsp; R · CHECKPOINT &nbsp; RIGHT-DRAG · LOOK</div>
  </main>
  <div id="touch-controls" aria-label="On-screen game controls">
    <div class="touch-pad" role="group" aria-label="Movement directions"><button data-action="up" class="up" aria-label="Move forward">▲</button><button data-action="left" class="left" aria-label="Move left">◀</button><button data-action="down" class="down" aria-label="Move backward">▼</button><button data-action="right" class="right" aria-label="Move right">▶</button></div>
    <div class="touch-action" role="group" aria-label="Game actions"><button data-action="interact" aria-label="Interact">ACTION</button><button data-action="jump" aria-label="Jump">JUMP</button></div>
  </div>
  <div id="overlay" aria-live="polite"></div>
  <div id="loading-failure" role="alert"><div><h1>The cabinet needs WebGL2.</h1><p>Try an up-to-date browser with hardware acceleration enabled.</p></div></div>
`;
const $ = (selector) => {
    const item = document.querySelector(selector);
    if (!item)
        throw new Error('Missing UI element: ' + selector);
    return item;
};
const canvas = $('#viewport');
const overlayRoot = $('#overlay');
const interactionPrompt = $('#interaction-cue');
const actionLabel = $('#action-label');
const zoneBanner = $('#zone-banner');
const toastRoot = $('#toast');
const touchRoot = $('#touch-controls');
const meterFill = $('#meter-fill');
const meterNumber = $('#meter-number');
const meterNote = $('#meter-note');
function safeRead(key) {
    try {
        return localStorage.getItem(key);
    }
    catch {
        return null;
    }
}
function safeWrite(key, value) {
    try {
        localStorage.setItem(key, value);
    }
    catch { /* Adventure still works with volatile progress. */ }
}
function safeDelete(key) {
    try {
        localStorage.removeItem(key);
    }
    catch { /* No storage available. */ }
}
class Game {
    renderer;
    scene;
    camera;
    input;
    hero;
    heroBody;
    shadowBlob;
    heroArms = [];
    heroHands = [];
    heroBoots = [];
    heroEyes = [];
    progress = parseProgress(safeRead(SAVE_KEY));
    quality = safeRead('full-weasel-64-quality') === 'low' ? 'low' : safeRead('full-weasel-64-quality') === 'high' ? 'high' : 'medium';
    reducedMotion = safeRead('full-weasel-64-reduced-motion') === 'yes' || (safeRead('full-weasel-64-reduced-motion') === null && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    overlay = 'intro';
    position = new THREE.Vector3(0, 0, 6);
    velocity = new THREE.Vector3(0, 0, 0);
    grounded = true;
    groundId = 'hub';
    coyote = 0;
    jumpBuffer = 0;
    bounceTime = 0;
    faceYaw = 0;
    cameraYaw = -.12;
    cameraPitch = .6;
    camTarget = new THREE.Vector3();
    camDesired = new THREE.Vector3();
    cameraFocus = new THREE.Vector3();
    cameraRay = new THREE.Raycaster();
    cameraDirection = new THREE.Vector3();
    playerForward = new THREE.Vector3();
    playerRight = new THREE.Vector3();
    elapsed = 0;
    accumulator = 0;
    lastFrameMs = 0;
    toastUntil = 0;
    zoneUntil = 0;
    lastZone = '';
    lastCheckpointName = 'Castle Hub';
    checkpoint = { x: 0, y: 0, z: 6, name: 'Castle Hub' };
    pendingWinOverlay = 0;
    stepSeconds = 1 / 60;
    destroyed = false;
    disposeFns = [];
    constructor() {
        let renderer;
        try {
            renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', alpha: false });
        }
        catch (error) {
            $('#loading-failure').classList.add('visible');
            throw error;
        }
        this.renderer = renderer;
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.17;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.scene = new ToyWorld();
        this.scene.synchronize(this.progress);
        this.scene.setGraphicsQuality(this.quality);
        this.camera = new THREE.PerspectiveCamera(58, 1, .1, 420);
        this.hero = new THREE.Group();
        this.heroBody = new THREE.Group();
        this.scene.scene.add(this.hero);
        this.hero.add(this.heroBody);
        this.createHero();
        const blob = new THREE.Mesh(new THREE.CircleGeometry(.72, 28), new THREE.MeshBasicMaterial({ color: 0x211644, transparent: true, opacity: .3, depthWrite: false }));
        blob.rotation.x = -Math.PI / 2;
        this.scene.scene.add(blob);
        this.shadowBlob = blob;
        this.input = new InputRouter(canvas, touchRoot);
        this.input.onLook = (dx, dy) => {
            if (this.overlay)
                return;
            this.cameraYaw -= dx * .006;
            this.cameraPitch = THREE.MathUtils.clamp(this.cameraPitch + dy * .0035, .3, 1.12);
        };
        this.createBindings();
        this.applyQuality();
        this.updateHUD();
        this.showOverlay('intro');
        this.moveCamera(1);
        this.renderer.setAnimationLoop(t => this.frame(t));
        if (({DEV:false,PROD:true,MODE:"production",BASE_URL:"./"}).DEV && new URLSearchParams(location.search).get('autotest') === '1')
            this.installTestBridge();
        window.FullWeasel64Bridge = {
            getState: () => structuredClone(this.progress),
            returnToMuseum: () => this.returnToMuseum(),
            destroy: () => this.destroy()
        };
    }
    createHero() {
        const cookie = this.heroBody;
        const shape = new THREE.Shape();
        for (let i = 0; i <= 48; i++) {
            const a = i * Math.PI * 2 / 48;
            const radius = 1 + .08 * Math.sin(a * 8);
            const x = Math.cos(a) * radius;
            const y = Math.sin(a) * radius;
            if (i === 0)
                shape.moveTo(x, y);
            else
                shape.lineTo(x, y);
        }
        const gold = new THREE.MeshPhysicalMaterial({ color: 0xffbc47, metalness: .26, roughness: .23, clearcoat: .77, clearcoatRoughness: .24 });
        const edge = new THREE.MeshPhysicalMaterial({ color: 0xeb8b32, metalness: .28, roughness: .37, clearcoat: .45 });
        const geo = new THREE.ExtrudeGeometry(shape, { depth: .34, bevelEnabled: true, bevelThickness: .16, bevelSize: .12, bevelSegments: 3, steps: 1 });
        const biscuit = new THREE.Mesh(geo, [gold, edge]);
        biscuit.castShadow = true;
        biscuit.receiveShadow = true;
        cookie.add(biscuit);
        const eyeWhite = new THREE.MeshStandardMaterial({ color: 0xfff7e1, roughness: .28 });
        const dark = new THREE.MeshStandardMaterial({ color: 0x3b224b, roughness: .2 });
        const blush = new THREE.MeshStandardMaterial({ color: 0xf18476, roughness: .52 });
        const sparkle = new THREE.MeshBasicMaterial({ color: 0xffffff });
        const ball = (mat, at, s) => {
            const m = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), mat);
            m.position.set(...at);
            m.scale.set(...s);
            m.castShadow = true;
            cookie.add(m);
            return m;
        };
        for (const x of [-.37, .37]) {
            ball(eyeWhite, [x, .21, .56], [.3, .34, .12]);
            const pupil = ball(dark, [x + .055, .18, .665], [.156, .22, .068]);
            this.heroEyes.push(pupil);
            ball(sparkle, [x + .105, .28, .72], [.062, .082, .04]);
            ball(blush, [x * 1.64, -.24, .49], [.22, .13, .064]);
            const brow = ball(dark, [x, .66, .52], [.21, .055, .05]);
            brow.rotation.z = x < 0 ? .21 : -.21;
        }
        const smilePoints = [];
        for (let i = 0; i <= 16; i++) {
            const a = Math.PI + .3 + i / 16 * (Math.PI - .6);
            smilePoints.push(new THREE.Vector3(Math.cos(a) * .36, -.2 + Math.sin(a) * .28, .62));
        }
        const smileGeo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(smilePoints), 20, .037, 6, false);
        cookie.add(new THREE.Mesh(smileGeo, dark));
        for (const x of [-.62, .62]) {
            const side = x < 0 ? -1 : 1;
            const arm = ball(gold, [x * 1.45, -.18, .04], [.19, .53, .2]);
            arm.rotation.z = side * .55;
            this.heroArms.push({ mesh: arm, side });
            const hand = ball(gold, [x * 1.6, -.62, .07], [.23, .23, .22]);
            this.heroHands.push({ mesh: hand, side, originY: hand.position.y });
            const shoe = ball(edge, [x * .8, -1.15, .17], [.31, .28, .45]);
            shoe.rotation.y = x < 0 ? -.12 : .12;
            this.heroBoots.push({ mesh: shoe, side, originY: shoe.position.y });
        }
        // Embossed sugar crest and star-studded, slightly toasted edge.
        const wafer = new THREE.MeshStandardMaterial({ color: 0xffe0a0, metalness: .3, roughness: .34 });
        const icing = new THREE.MeshPhysicalMaterial({ color: 0xfff6d2, metalness: .05, roughness: .22, clearcoat: .75 });
        for (let i = 0; i < 12; i++) {
            const a = i * Math.PI * 2 / 12;
            const r = 1.07 + .05 * Math.sin(8 * a);
            ball(i % 3 === 0 ? icing : wafer, [Math.cos(a) * r, Math.sin(a) * r, .31], [.12, .12, .095]);
        }
        for (const [x, y] of [[-.52, -.36], [-.34, -.47], [.52, -.36], [.34, -.47]]) {
            ball(wafer, [x, y, .53], [.056, .057, .045]);
        }
        const badgeShape = new THREE.Shape();
        for (let i = 0; i < 10; i++) {
            const a = i * Math.PI / 5 - Math.PI / 2, r = i % 2 ? .11 : .26;
            if (i === 0)
                badgeShape.moveTo(Math.cos(a) * r, Math.sin(a) * r);
            else
                badgeShape.lineTo(Math.cos(a) * r, Math.sin(a) * r);
        }
        badgeShape.closePath();
        const badge = new THREE.Mesh(new THREE.ExtrudeGeometry(badgeShape, { depth: .035, bevelEnabled: true, bevelSize: .025, bevelThickness: .025, bevelSegments: 2 }), icing);
        badge.position.set(0, -.59, .52);
        badge.castShadow = false;
        cookie.add(badge);
        cookie.position.set(0, .88, -.15);
        // A second face makes direction changes readable even in a third-person chase view.
        const backFace = ball(gold, [0, .1, -.38], [.7, .55, .08]);
        backFace.material = edge;
    }
    createBindings() {
        const onResize = () => {
            const width = Math.max(1, canvas.clientWidth), height = Math.max(1, canvas.clientHeight);
            this.camera.aspect = width / height;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(width, height, false);
        };
        window.addEventListener('resize', onResize);
        this.disposeFns.push(() => window.removeEventListener('resize', onResize));
        const onVisibility = () => { if (document.hidden && !this.overlay)
            this.showOverlay('paused'); };
        document.addEventListener('visibilitychange', onVisibility);
        this.disposeFns.push(() => document.removeEventListener('visibilitychange', onVisibility));
        const onOverlayClick = (event) => {
            const target = event.target;
            const button = target.closest('[data-ui]');
            if (!button)
                return;
            const action = button.dataset.ui;
            if (action === 'play' || action === 'continue') {
                this.showOverlay(null);
                this.input.clear();
            }
            else if (action === 'new') {
                this.newGame();
            }
            else if (action === 'return') {
                this.returnToMuseum();
            }
            else if (action === 'respawn') {
                this.respawn();
                this.showOverlay(null);
            }
        };
        overlayRoot.addEventListener('click', onOverlayClick);
        this.disposeFns.push(() => overlayRoot.removeEventListener('click', onOverlayClick));
        const onSetting = (event) => {
            const target = event.target;
            if (target.id === 'quality-setting' && target instanceof HTMLSelectElement) {
                this.quality = target.value === 'low' ? 'low' : target.value === 'high' ? 'high' : 'medium';
                safeWrite('full-weasel-64-quality', this.quality);
                this.applyQuality();
            }
            if (target.id === 'motion-setting' && target instanceof HTMLInputElement) {
                this.reducedMotion = target.checked;
                safeWrite('full-weasel-64-reduced-motion', this.reducedMotion ? 'yes' : 'no');
            }
        };
        overlayRoot.addEventListener('change', onSetting);
        this.disposeFns.push(() => overlayRoot.removeEventListener('change', onSetting));
        const onPause = () => this.showOverlay(this.overlay ? null : 'paused');
        $('#pause-button').addEventListener('click', onPause);
        this.disposeFns.push(() => $('#pause-button').removeEventListener('click', onPause));
        const onContextLoss = (e) => { e.preventDefault(); this.showOverlay('paused'); this.toast('Graphics paused. Reload if the cabinet does not recover.'); };
        canvas.addEventListener('webglcontextlost', onContextLoss);
        this.disposeFns.push(() => canvas.removeEventListener('webglcontextlost', onContextLoss));
        onResize();
    }
    applyQuality() {
        const cap = this.quality === 'low' ? 1 : this.quality === 'medium' ? 1.5 : 2;
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cap));
        this.renderer.shadowMap.enabled = this.quality !== 'low';
        this.renderer.setSize(Math.max(1, canvas.clientWidth), Math.max(1, canvas.clientHeight), false);
        this.scene.setGraphicsQuality(this.quality);
    }
    renderOverlayContent(kind) {
        if (kind === 'intro')
            return `
      <section class="overlay-panel" aria-label="Start adventure">
        <p class="eyebrow">A CABINET-SIZED ADVENTURE · EXHIBIT E27</p>
        <h1 class="overlay-title">FULL WEASEL <span>64</span></h1>
        <p class="overlay-description">Three impossible machines. Three golden stars. One biscuit with heroic ambitions. The party is locked behind a throne-room gate, and the shark is on a very theatrical pulley.</p>
        <div class="overlay-split"><div class="rule-card"><h3>THE GRAND MISSION</h3><p>Wind the crank, release the catch, and pull the lever. Claim one star in each real, traversable challenge room.</p></div><div class="rule-card"><h3>HOW TO MOVE</h3><p>WASD / arrows to run, Space to jump, E to interact. Right-drag or swipe the view. Touch controls appear on phones and tablets.</p></div></div>
        <div class="button-row"><button class="primary-button" data-ui="play">ENTER THE CABINET ✦</button><button class="secondary-button" data-ui="return">RETURN TO MUSEUM (MOCK)</button></div>
        <p class="small-print">A standalone imaginative adventure, separate from the finished Full Weasel game. ${rewardCount(this.progress) > 0 ? `${rewardCount(this.progress)} saved star${rewardCount(this.progress) === 1 ? '' : 's'} found.` : 'Progress saves locally.'}</p>
      </section>`;
        if (kind === 'win')
            return `
      <section class="overlay-panel" aria-label="Victory celebration">
        <p class="eyebrow">YOU HAVE DEFINITELY COMPLETED THE NECESSARY PROCEDURE</p>
        <h1 class="overlay-title">PARTY <span>ACTIVATED!</span></h1>
        <p class="overlay-description">The toy castle has achieved maximum festivities. The shark is a puppet, the biscuit is a legend, and the party was in this cabinet all along. Apparently.</p>
        <div class="rule-card"><h3>FINAL INVENTORY</h3><p>✦ Crank Star &nbsp; ✦ Catch Star &nbsp; ✦ Lever Star &nbsp; ✦ 100% party power</p></div>
        <div class="button-row"><button class="primary-button" data-ui="continue">WATCH THE PARTY</button><button class="secondary-button" data-ui="new">NEW ADVENTURE ↻</button><button class="secondary-button" data-ui="return">RETURN TO MUSEUM (MOCK)</button></div>
      </section>`;
        return `
      <section class="overlay-panel" aria-label="Pause menu and settings">
        <p class="eyebrow">THE ARCADE TAKES A SHORT BREAK</p><h1 class="overlay-title">PAUSED<span> · ✦</span></h1>
        <div class="setting"><label for="quality-setting">Graphics quality</label><select id="quality-setting"><option value="low" ${this.quality === 'low' ? 'selected' : ''}>Low — efficient</option><option value="medium" ${this.quality === 'medium' ? 'selected' : ''}>Medium — balanced</option><option value="high" ${this.quality === 'high' ? 'selected' : ''}>High — sparkling</option></select></div>
        <div class="setting"><label for="motion-setting">Reduce animation and camera easing</label><input id="motion-setting" type="checkbox" ${this.reducedMotion ? 'checked' : ''}/></div>
        <div class="rule-card"><h3>CURRENT QUEST</h3><p>${rewardCount(this.progress)} / 3 stars collected. Last checkpoint: ${this.checkpoint.name}. Press R during play to respawn without losing rewards.</p></div>
        <div class="button-row"><button class="primary-button" data-ui="continue">RESUME ADVENTURE</button><button class="secondary-button" data-ui="respawn">BACK TO CHECKPOINT</button><button class="secondary-button" data-ui="new">NEW GAME (CLEAR SAVE)</button><button class="secondary-button" data-ui="return">MUSEUM RETURN (MOCK)</button></div>
        <p class="small-print">Your three mechanisms, stars and win state are saved locally. New game deliberately resets only this adventure's saved progress.</p>
      </section>`;
    }
    showOverlay(next) {
        this.overlay = next;
        overlayRoot.classList.toggle('hidden', next === null);
        if (next) {
            overlayRoot.setAttribute('role', 'dialog');
            overlayRoot.setAttribute('aria-modal', 'true');
            overlayRoot.innerHTML = this.renderOverlayContent(next);
            this.input?.clear();
            overlayRoot.querySelector('button')?.focus();
        }
        else {
            overlayRoot.removeAttribute('role');
            overlayRoot.removeAttribute('aria-modal');
            overlayRoot.innerHTML = '';
            canvas.focus({ preventScroll: true });
        }
    }
    save() { safeWrite(SAVE_KEY, JSON.stringify(this.progress)); this.scene.synchronize(this.progress); this.updateHUD(); }
    updateHUD() {
        for (const name of MECHANISMS) {
            const entry = $(`[data-quest="${name}"]`);
            const complete = this.progress.rewards[name];
            const active = this.progress.engaged[name];
            entry.classList.toggle('done', complete);
            document.querySelector(`[data-route="${name}"]`)?.classList.toggle('done', complete);
            entry.querySelector('.quest-coin').textContent = complete ? '★' : '☆';
            entry.querySelector('.quest-state').textContent = complete ? 'STAR COLLECTED' : active ? 'Mechanism engaged' : 'Mechanism waiting';
        }
        meterFill.style.width = partyMeter(this.progress) + '%';
        meterNumber.textContent = partyMeter(this.progress) + '%';
        meterNote.textContent = this.progress.won ? 'THE PARTY HAS ESCAPED CONTAINMENT' : throneUnlocked(this.progress) ? 'ALL STARS FOUND · THE GATE IS OPEN' : `${rewardCount(this.progress)} / 3 GOLDEN STARS`;
    }
    toast(message, seconds = 3) {
        toastRoot.textContent = message;
        toastRoot.classList.add('visible');
        this.toastUntil = this.elapsed + seconds;
    }
    announceZone(name, subtitle) {
        if (name === this.lastZone)
            return;
        this.lastZone = name;
        zoneBanner.innerHTML = `<strong>${name}</strong>${subtitle}`;
        zoneBanner.classList.add('active');
        this.zoneUntil = this.elapsed + 2.9;
    }
    updateZone() {
        const p = this.position;
        if (p.z < -29)
            this.announceZone('CLOCKWORK CRANK', '01 · WIND THE CRANK');
        else if (p.x > 30)
            this.announceZone('CATCH CONSERVATORY', '02 · RELEASE THE CATCH');
        else if (p.x < -30)
            this.announceZone('LEVER LANES', '03 · PULL THE LEVER');
        else if (p.z > 29)
            this.announceZone('THE THRONE ROOM', 'THE FINAL BUTTON');
        else if (this.lastZone !== 'THE CASTLE HUB')
            this.announceZone('THE CASTLE HUB', 'THREE PATHS · ONE PARTY');
    }
    nearDevice() {
        for (const key of MECHANISMS) {
            if (this.progress.engaged[key])
                continue;
            const device = DEVICES[key];
            if (Math.hypot(this.position.x - device.x, this.position.z - device.z) < 2.65 && Math.abs(this.position.y - device.y) < 1.5)
                return key;
        }
        return null;
    }
    nearFinale() {
        return throneUnlocked(this.progress) && !this.progress.won &&
            Math.hypot(this.position.x - THRONE_BUTTON.x, this.position.z - THRONE_BUTTON.z) < 3.25 &&
            Math.abs(this.position.y - THRONE_BUTTON.y) < 1.4;
    }
    updateInteractPrompt() {
        const key = this.nearDevice();
        const nearButton = this.nearFinale();
        const show = Boolean(key) || nearButton;
        interactionPrompt.classList.toggle('active', show);
        if (nearButton)
            actionLabel.textContent = 'PRESS THE GIANT PARTY BUTTON';
        else if (key)
            actionLabel.textContent = DEVICES[key].verb.toUpperCase();
    }
    interact() {
        const key = this.nearDevice();
        if (key) {
            this.progress = engaged(this.progress, key);
            this.save();
            const switchAt = DEVICES[key];
            this.scene.burst(new THREE.Vector3(switchAt.x, switchAt.y + .45, switchAt.z), 'mechanism', this.quality, this.reducedMotion);
            this.toast(key === 'crank' ? 'The wind-up bridge unfolds!' : key === 'catch' ? 'Catch released! The star is free.' : 'The lever reveals a glittering walkway!', 4);
            return;
        }
        if (this.nearFinale()) {
            this.progress = finish(this.progress);
            this.save();
            this.pendingWinOverlay = 5;
            this.scene.burst(new THREE.Vector3(THRONE_BUTTON.x, 1.2, THRONE_BUTTON.z), 'finale', this.quality, this.reducedMotion);
            this.scene.burst(new THREE.Vector3(0, 9, 52.5), 'finale', this.quality, this.reducedMotion);
            this.toast('PARTY POWER: 100% · SHARK PUPPET DESCENDING!', 5);
            return;
        }
        if (!throneUnlocked(this.progress) && this.position.z > 22 && this.position.z < 29 && Math.abs(this.position.x) < 5) {
            this.toast('Three golden stars required. The party is very particular.');
        }
    }
    tryCollect() {
        for (const key of MECHANISMS) {
            if (!this.progress.engaged[key] || this.progress.rewards[key])
                continue;
            const reward = REWARDS[key];
            if (Math.hypot(this.position.x - reward.x, this.position.z - reward.z) > 1.25)
                continue;
            if (Math.abs((this.position.y + 1.3) - reward.y) > 1.6)
                continue;
            this.progress = collect(this.progress, key);
            this.save();
            this.scene.burst(new THREE.Vector3(reward.x, reward.y, reward.z), 'reward', this.quality, this.reducedMotion);
            const count = rewardCount(this.progress);
            this.toast(`${reward.label.toUpperCase()} COLLECTED! · ${count}/3`, 4);
            if (count === 3)
                this.toast('ALL THREE STARS! THE THRONE GATE IS OPEN.', 5);
        }
    }
    newGame() {
        this.progress = freshProgress();
        safeDelete(SAVE_KEY);
        this.scene.synchronize(this.progress);
        this.scene.clearFeedback();
        this.scene.setGraphicsQuality(this.quality);
        this.updateHUD();
        this.checkpoint = { x: 0, y: 0, z: 6, name: 'Castle Hub' };
        this.respawn();
        this.pendingWinOverlay = 0;
        this.lastZone = '';
        this.toast('NEW ADVENTURE · STARS RESET');
        this.showOverlay(null);
    }
    respawn() {
        this.position.set(this.checkpoint.x, this.checkpoint.y, this.checkpoint.z);
        this.velocity.set(0, 0, 0);
        this.grounded = true;
        this.groundId = null;
        this.coyote = 0;
        this.jumpBuffer = 0;
        this.input.clear();
        this.moveCamera(1);
        this.scene.burst(this.position.clone().add(new THREE.Vector3(0, .5, 0)), 'respawn', this.quality, this.reducedMotion);
    }
    returnToMuseum() {
        requestMuseumReturn();
        this.toast('Museum return event dispatched. No production museum was changed.', 5);
        this.showOverlay(this.progress.won ? 'win' : 'paused');
    }
    currentGround() {
        const px = this.position.x, pz = this.position.z;
        for (const platform of this.scene.visibleSurfaces(this.progress)) {
            if (Math.abs(platform.top - this.position.y) > .16)
                continue;
            if (Math.abs(px - platform.x) < platform.sx / 2 + .25 && Math.abs(pz - platform.z) < platform.sz / 2 + .25)
                return platform;
        }
        return null;
    }
    hitsWall(x, z, feet) {
        const r = .55;
        for (const box of this.scene.solidBounds(this.progress)) {
            if (feet + 1.7 < box.bottom || feet + .08 > box.top)
                continue;
            const nx = Math.max(box.x0, Math.min(x, box.x1));
            const nz = Math.max(box.z0, Math.min(z, box.z1));
            if ((x - nx) * (x - nx) + (z - nz) * (z - nz) < r * r)
                return true;
        }
        return false;
    }
    findLanding(prevFeet, nextFeet) {
        let best = null;
        for (const p of this.scene.visibleSurfaces(this.progress)) {
            if (prevFeet < p.top - .18 || nextFeet > p.top || (best && p.top <= best.top))
                continue;
            if (Math.abs(this.position.x - p.x) > p.sx / 2 + .35 || Math.abs(this.position.z - p.z) > p.sz / 2 + .35)
                continue;
            best = p;
        }
        return best;
    }
    updateCheckpoint() {
        const p = this.position;
        const previous = this.checkpoint.name;
        if (p.z < -31 && !this.checkpoint.name.includes('Crank'))
            this.checkpoint = { x: 0, y: 0, z: -34, name: 'Clockwork Crank' };
        else if (p.x > 33 && !this.checkpoint.name.includes('Catch'))
            this.checkpoint = { x: 35, y: 0, z: 0, name: 'Catch Conservatory' };
        else if (p.x < -33 && !this.checkpoint.name.includes('Lever'))
            this.checkpoint = { x: -35, y: 0, z: 0, name: 'Lever Lanes' };
        else if (p.z > 33 && !this.checkpoint.name.includes('Throne'))
            this.checkpoint = { x: 0, y: 0, z: 35, name: 'Throne Room' };
        else if (Math.abs(p.x) < 10 && Math.abs(p.z) < 10 && this.checkpoint.name !== 'Castle Hub')
            this.checkpoint = { x: 0, y: 0, z: 6, name: 'Castle Hub' };
        if (previous !== this.checkpoint.name) {
            this.lastCheckpointName = this.checkpoint.name;
            $('#checkpoint-readout').textContent = `◆ ${this.lastCheckpointName.toUpperCase()} · CHECKPOINT`;
        }
    }
    step(dt) {
        const buttons = this.input.sample();
        if (buttons.pause) {
            this.showOverlay(this.overlay ? null : 'paused');
        }
        if (!this.overlay) {
            this.elapsed += dt;
            if (buttons.respawn) {
                this.respawn();
                this.toast('BACK TO CHECKPOINT · PROGRESS KEPT');
            }
            if (buttons.interact)
                this.interact();
            if (buttons.jump)
                this.jumpBuffer = .14;
            this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);
            this.coyote = Math.max(0, this.coyote - dt);
            this.playerForward.set(Math.sin(this.cameraYaw), 0, -Math.cos(this.cameraYaw));
            this.playerRight.set(Math.cos(this.cameraYaw), 0, Math.sin(this.cameraYaw));
            const inputLength = Math.hypot(buttons.x, buttons.y);
            const dx = inputLength > 0 ? (this.playerRight.x * buttons.x + this.playerForward.x * buttons.y) / inputLength : 0;
            const dz = inputLength > 0 ? (this.playerRight.z * buttons.x + this.playerForward.z * buttons.y) / inputLength : 0;
            const maxSpeed = 7.8;
            this.velocity.x = THREE.MathUtils.damp(this.velocity.x, dx * maxSpeed, this.grounded ? 15 : 8, dt);
            this.velocity.z = THREE.MathUtils.damp(this.velocity.z, dz * maxSpeed, this.grounded ? 15 : 8, dt);
            const support = this.grounded ? this.currentGround() : null;
            if (support) {
                this.groundId = support.id;
                this.coyote = .115;
                if (support.beltX)
                    this.velocity.x += support.beltX * dt * 4;
                if (support.beltZ)
                    this.velocity.z += support.beltZ * dt * 4;
            }
            else if (this.grounded) {
                this.grounded = false;
                this.groundId = null;
            }
            if (this.jumpBuffer > 0 && (this.grounded || this.coyote > 0)) {
                this.velocity.y = 9.65;
                this.grounded = false;
                this.coyote = 0;
                this.jumpBuffer = 0;
                this.bounceTime = .25;
                this.scene.burst(this.position.clone().add(new THREE.Vector3(0, .3, 0)), 'jump', this.quality, this.reducedMotion);
            }
            if (inputLength > .1) {
                const targetYaw = Math.atan2(dx, dz);
                let delta = ((targetYaw - this.faceYaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
                this.faceYaw += delta * (1 - Math.exp(-13 * dt));
            }
            const xNext = this.position.x + this.velocity.x * dt;
            if (!this.hitsWall(xNext, this.position.z, this.position.y))
                this.position.x = xNext;
            else
                this.velocity.x = 0;
            const zNext = this.position.z + this.velocity.z * dt;
            if (!this.hitsWall(this.position.x, zNext, this.position.y))
                this.position.z = zNext;
            else
                this.velocity.z = 0;
            const previousY = this.position.y;
            if (this.grounded) {
                const newSurface = this.currentGround();
                if (newSurface) {
                    this.position.y = newSurface.top;
                    this.velocity.y = 0;
                    this.groundId = newSurface.id;
                }
                else {
                    this.grounded = false;
                    this.groundId = null;
                }
            }
            if (!this.grounded) {
                this.velocity.y = Math.max(-28, this.velocity.y - 23 * dt);
                const nextY = previousY + this.velocity.y * dt;
                const landing = this.velocity.y <= 0 ? this.findLanding(previousY, nextY) : null;
                if (landing) {
                    this.position.y = landing.top;
                    this.velocity.y = 0;
                    this.grounded = true;
                    this.groundId = landing.id;
                    this.coyote = .115;
                    this.bounceTime = .18;
                    this.scene.burst(new THREE.Vector3(this.position.x, landing.top + .12, this.position.z), landing.kind === 'spring' ? 'spring' : 'land', this.quality, this.reducedMotion);
                    if (landing.kind === 'spring') {
                        this.velocity.y = 11.1;
                        this.grounded = false;
                        this.coyote = 0;
                        this.bounceTime = .5;
                        this.toast('BOING! · SPRING PETAL', 1.0);
                    }
                }
                else
                    this.position.y = nextY;
            }
            if (this.position.y < -7.3) {
                this.respawn();
                this.toast('THE FOAM PIT WINS THIS ROUND · CHECKPOINT RESTORED', 2.4);
            }
            this.updateCheckpoint();
            this.updateZone();
            this.updateInteractPrompt();
            this.tryCollect();
            if (this.pendingWinOverlay > 0) {
                this.pendingWinOverlay = Math.max(0, this.pendingWinOverlay - dt);
                if (this.pendingWinOverlay === 0)
                    this.showOverlay('win');
            }
            if (this.toastUntil > 0 && this.elapsed > this.toastUntil)
                toastRoot.classList.remove('visible');
            if (this.zoneUntil > 0 && this.elapsed > this.zoneUntil)
                zoneBanner.classList.remove('active');
            this.bounceTime = Math.max(0, this.bounceTime - dt);
        }
        this.scene.update(dt, this.progress, this.reducedMotion, this.quality, this.position);
    }
    updateHeroVisual() {
        this.hero.position.copy(this.position);
        this.hero.rotation.y = this.faceYaw;
        const running = Math.min(1, Math.hypot(this.velocity.x, this.velocity.z) / 7.8);
        const t = this.elapsed;
        const movement = this.reducedMotion ? 0 : Math.sin(t * (8 + running * 6)) * running;
        const stretching = this.grounded ? .025 * (1 - Math.cos(t * 2)) : .14;
        const squash = this.bounceTime > 0 ? Math.sin((1 - this.bounceTime / .5) * Math.PI) * .2 : 0;
        const yScale = Math.max(.58, .75 + stretching - squash);
        const xScale = .74 + Math.max(0, squash) * .55;
        this.heroBody.scale.set(xScale, yScale, .75);
        this.heroBody.rotation.z = this.reducedMotion ? 0 : -this.velocity.x * .018;
        this.heroBody.rotation.x = this.reducedMotion ? 0 : this.velocity.z * .012;
        this.heroBody.position.y = .88 + (this.reducedMotion ? 0 : movement * .05) + (this.grounded ? 0 : Math.max(-.1, Math.min(.12, this.velocity.y * .007)));
        const gait = this.reducedMotion ? 0 : Math.sin(t * 12.5) * running;
        for (const arm of this.heroArms)
            arm.mesh.rotation.z = arm.side * .55 + gait * arm.side * .19;
        for (const hand of this.heroHands)
            hand.mesh.position.y = hand.originY + gait * hand.side * .13;
        for (const shoe of this.heroBoots) {
            shoe.mesh.position.y = shoe.originY + Math.max(0, gait * shoe.side) * .19;
            shoe.mesh.rotation.x = gait * shoe.side * .11;
        }
        // A quick, opt-out blink makes the biscuit expressive without an animation rig.
        const blink = this.reducedMotion ? 0 : Math.max(0, 1 - Math.abs((t % 5.1) - 4.46) / .095);
        for (const eye of this.heroEyes)
            eye.scale.y = .22 * (1 - .93 * blink);
        let floorBelow = null;
        for (const platform of this.scene.visibleSurfaces(this.progress)) {
            if (platform.top > this.position.y + .12)
                continue;
            if (Math.abs(this.position.x - platform.x) > platform.sx / 2 || Math.abs(this.position.z - platform.z) > platform.sz / 2)
                continue;
            if (!floorBelow || platform.top > floorBelow.top)
                floorBelow = platform;
        }
        this.shadowBlob.visible = Boolean(floorBelow);
        if (floorBelow) {
            const altitude = Math.max(0, this.position.y - floorBelow.top);
            this.shadowBlob.position.set(this.position.x, floorBelow.top + .04, this.position.z);
            this.shadowBlob.scale.setScalar(1 + Math.min(3, altitude) * .13);
            this.shadowBlob.material.opacity = .32 / (1 + altitude * .4);
        }
    }
    moveCamera(dt) {
        // Persistent vectors avoid allocation spikes; a small lead gives the player jump space.
        this.cameraFocus.set(this.position.x + this.velocity.x * .08, this.position.y + 1.15, this.position.z + this.velocity.z * .08);
        const follow = this.reducedMotion || dt > .4 ? 1 : 1 - Math.exp(-10.5 * dt);
        this.camTarget.lerp(this.cameraFocus, follow);
        const travel = 13.5;
        const horizontal = travel * Math.cos(this.cameraPitch);
        this.camDesired.set(this.camTarget.x - Math.sin(this.cameraYaw) * horizontal, this.camTarget.y + travel * Math.sin(this.cameraPitch), this.camTarget.z + Math.cos(this.cameraYaw) * horizontal);
        this.cameraDirection.subVectors(this.camDesired, this.camTarget);
        const distance = this.cameraDirection.length();
        this.cameraDirection.multiplyScalar(1 / Math.max(.00001, distance));
        this.cameraRay.set(this.camTarget, this.cameraDirection);
        this.cameraRay.far = distance;
        const obstruction = this.cameraRay.intersectObjects(this.scene.cameraObstacles, false);
        if (obstruction.length && obstruction[0].distance < distance) {
            const permitted = Math.max(2.9, obstruction[0].distance - .65);
            this.camDesired.copy(this.camTarget).addScaledVector(this.cameraDirection, permitted);
        }
        if (this.reducedMotion || dt > .4)
            this.camera.position.copy(this.camDesired);
        else
            this.camera.position.lerp(this.camDesired, 1 - Math.exp(-9.2 * dt));
        this.camera.lookAt(this.camTarget);
    }
    frame(timeMs) {
        if (this.destroyed)
            return;
        if (this.lastFrameMs === 0)
            this.lastFrameMs = timeMs;
        const seconds = Math.min(.20, Math.max(0, (timeMs - this.lastFrameMs) / 1000));
        this.lastFrameMs = timeMs;
        this.accumulator += seconds;
        let steps = 0;
        while (this.accumulator >= this.stepSeconds && steps < 5) {
            this.step(this.stepSeconds);
            this.accumulator -= this.stepSeconds;
            steps++;
        }
        if (steps === 5)
            this.accumulator = 0;
        this.updateHeroVisual();
        this.moveCamera(Math.max(seconds, .0001));
        this.renderer.render(this.scene.scene, this.camera);
    }
    installTestBridge() {
        window.__WEASEL_TEST__ = {
            placeAtDevice: (key) => {
                const d = DEVICES[key];
                this.position.set(d.x, d.y, d.z);
                this.velocity.set(0, 0, 0);
                this.grounded = true;
                this.overlay = null;
                this.showOverlay(null);
            },
            placeAtReward: (key) => {
                const d = REWARDS[key];
                this.position.set(d.x, d.y - 1.15, d.z);
                this.velocity.set(0, 0, 0);
                this.grounded = true;
            },
            placeAtFinale: () => {
                this.position.set(THRONE_BUTTON.x, 0, THRONE_BUTTON.z);
                this.velocity.set(0, 0, 0);
                this.grounded = true;
            },
            interact: () => this.interact(),
            collectNearby: () => this.tryCollect(),
            getDebug: () => ({ feet: this.position.toArray(), gateLocked: !throneUnlocked(this.progress), platformCount: this.scene.visibleSurfaces(this.progress).length, ground: this.groundId })
        };
    }
    destroy() {
        if (this.destroyed)
            return;
        this.destroyed = true;
        this.renderer.setAnimationLoop(null);
        this.input.dispose();
        for (const fn of this.disposeFns)
            fn();
        this.disposeFns.length = 0;
        this.scene.scene.remove(this.hero, this.shadowBlob);
        const heroGeometry = new Set();
        const heroMaterials = new Set();
        this.hero.traverse(obj => {
            if (!(obj instanceof THREE.Mesh))
                return;
            heroGeometry.add(obj.geometry);
            const materials = Array.isArray(obj.material) ? obj.material : [obj.material];
            for (const mat of materials)
                heroMaterials.add(mat);
        });
        for (const geometry of heroGeometry)
            geometry.dispose();
        for (const material of heroMaterials)
            material.dispose();
        this.shadowBlob.geometry.dispose();
        this.shadowBlob.material.dispose();
        this.scene.dispose();
        this.renderer.dispose();
        this.renderer.forceContextLoss();
        delete window.FullWeasel64Bridge;
        delete window.__WEASEL_TEST__;
    }
}
try {
    new Game();
}
catch (error) {
    console.error('Cabinet initialization failed:', error);
    $('#loading-failure').classList.add('visible');
}
