import { CHECKPOINTS, FINISH_X, getLanding, getSupport } from './level.js';
export const FIXED_DT = 1 / 60;
export const MAX_SIM_STEPS = 5;
const SPEED = 12.7;
const SPRINT_SPEED = 17.5;
const JUMP_SPEED = 11.7;
const GRAVITY = 25;
const BOOST_SPEED = 27;
const BOOST_SECONDS = 0.58;
export const NEUTRAL_INPUT = { forward: 0, lateral: 0, sprint: false, jump: false, boost: false };
export function newGame() {
    const start = CHECKPOINTS[0];
    return {
        x: start.x, y: start.y, z: start.z,
        vx: 0, vy: 0, vz: 0, grounded: true, coyote: 0.11, jumpBuffer: 0,
        boostReady: true, boostTime: 0, checkpoint: 0, elapsed: 0, respawns: 0,
        completed: false, frame: 0, lastEvent: 'none',
    };
}
function approach(from, to, maxDelta) {
    return from < to ? Math.min(to, from + maxDelta) : Math.max(to, from - maxDelta);
}
export function respawn(state) {
    const checkpoint = CHECKPOINTS[state.checkpoint];
    state.x = checkpoint.x;
    state.y = checkpoint.y;
    state.z = checkpoint.z;
    state.vx = 0;
    state.vy = 0;
    state.vz = 0;
    state.grounded = true;
    state.coyote = 0.11;
    state.jumpBuffer = 0;
    state.boostReady = true;
    state.boostTime = 0;
    state.respawns++;
    state.lastEvent = 'respawn';
}
/** Deterministic feet-space collision. Every playable surface is a simple authored deck top. */
export function stepGame(state, controls, dt = FIXED_DT) {
    if (state.completed)
        return;
    state.frame++;
    state.elapsed += dt;
    state.lastEvent = 'none';
    if (controls.jump)
        state.jumpBuffer = 0.16;
    else
        state.jumpBuffer = Math.max(0, state.jumpBuffer - dt);
    state.coyote = state.grounded ? 0.12 : Math.max(0, state.coyote - dt);
    const norm = Math.max(1, Math.hypot(controls.forward, controls.lateral));
    const forward = controls.forward / norm;
    const lateral = controls.lateral / norm;
    const maxSpeed = controls.sprint ? SPRINT_SPEED : SPEED;
    const acceleration = state.grounded ? 72 : 35;
    state.vx = approach(state.vx, forward * maxSpeed, acceleration * dt);
    state.vz = approach(state.vz, lateral * maxSpeed, acceleration * dt);
    if (state.jumpBuffer > 0 && state.coyote > 0) {
        state.vy = JUMP_SPEED;
        state.grounded = false;
        state.coyote = 0;
        state.jumpBuffer = 0;
        state.lastEvent = 'jump';
    }
    if (controls.boost && state.boostReady) {
        state.boostReady = false;
        state.boostTime = BOOST_SECONDS;
        state.vx = Math.max(state.vx, BOOST_SPEED);
        state.vy = Math.max(state.vy, 2.6);
        state.grounded = false;
        state.coyote = 0;
        state.lastEvent = 'boost';
    }
    if (state.boostTime > 0) {
        state.boostTime = Math.max(0, state.boostTime - dt);
        state.vx = Math.max(state.vx, BOOST_SPEED);
    }
    const prevY = state.y;
    state.x += state.vx * dt;
    state.z += state.vz * dt;
    if (state.grounded) {
        const support = getSupport(state.x, state.z, state.y, 0.20);
        if (support) {
            state.y = support.top;
            state.vy = 0;
        }
        else {
            state.grounded = false;
            state.coyote = Math.max(state.coyote, 0.09);
        }
    }
    if (!state.grounded) {
        state.vy -= GRAVITY * dt;
        state.y += state.vy * dt;
        const landed = getLanding(state.x, state.z, prevY, state.y, state.vy);
        if (landed) {
            state.y = landed.top;
            state.vy = 0;
            state.grounded = true;
            state.lastEvent = 'land';
        }
    }
    if (state.grounded) {
        for (let i = CHECKPOINTS.length - 1; i > state.checkpoint; i--) {
            const cp = CHECKPOINTS[i];
            if (state.x >= cp.x && Math.abs(state.y - cp.y) <= 1.1) {
                state.checkpoint = i;
                state.lastEvent = 'checkpoint';
                break;
            }
        }
    }
    if (state.x >= FINISH_X && state.grounded) {
        state.completed = true;
        state.lastEvent = 'finished';
        state.vx = state.vz = 0;
    }
    if (!Number.isFinite(state.y) || state.y < -22 || Math.abs(state.z) > 66 || state.x < -36)
        respawn(state);
}
