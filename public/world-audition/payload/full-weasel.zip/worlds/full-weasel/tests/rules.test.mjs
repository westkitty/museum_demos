import assert from 'node:assert/strict';
import test from 'node:test';
import { collect, decodeProgress, engaged, finish, freshProgress, parseProgress, partyMeter, rewardCount, throneUnlocked } from '../.test-build/game/rules.js';
import { DEVICES, PLATFORMS, REWARDS, pathExists } from '../.test-build/game/layout.js';

for (const name of ['crank', 'catch', 'lever']) {
  test(`${name}: mechanism must activate before reward becomes collectible`, () => {
    const start = freshProgress();
    assert.equal(collect(start, name).rewards[name], false);
    const triggered = engaged(start, name);
    assert.equal(triggered.engaged[name], true);
    const obtained = collect(triggered, name);
    assert.equal(obtained.rewards[name], true);
    assert.equal(collect(obtained, name), obtained, 'collectibles are one-time');
    assert.equal(engaged(triggered, name), triggered, 'devices are one-time');
  });
  test(`${name}: device and reward have traversable authored platforms`, () => {
    const device = DEVICES[name];
    const reward = REWARDS[name];
    assert.ok(PLATFORMS.some(p => Math.abs(p.top - device.y) < 0.1 && Math.abs(p.x - device.x) < p.sx / 2 && Math.abs(p.z - device.z) < p.sz / 2));
    assert.ok(PLATFORMS.some(p => Math.abs(p.top - (reward.y - 1.15)) < 0.1 && Math.abs(p.x - reward.x) < p.sx / 2 && Math.abs(p.z - reward.z) < p.sz / 2));
    const targetId = name === 'crank' ? 'crank-5' : name === 'catch' ? 'catch-4' : 'lever-4';
    assert.equal(pathExists('hub', targetId), true, 'device must be reachable from hub');
  });
}

test('all three room entrances are connected directly to hub', () => {
  for (const id of ['crank-0','catch-0','lever-0','throne']) assert.equal(pathExists('hub', id), true, id);
});

test('crank and lever reward bridge surfaces are genuinely gated', () => {
  assert.equal(pathExists('hub', 'crank-bridge-b'), false);
  assert.equal(pathExists('hub', 'crank-bridge-b', ['crank']), true);
  assert.equal(pathExists('hub', 'lever-bridge'), false);
  assert.equal(pathExists('hub', 'lever-bridge', ['lever']), true);
});

test('throne stays closed until every golden reward is earned', () => {
  let p = freshProgress();
  assert.equal(throneUnlocked(p), false);
  assert.equal(finish(p).won, false);
  for (const name of ['crank','catch']) p = collect(engaged(p, name), name);
  assert.equal(rewardCount(p), 2);
  assert.equal(partyMeter(p), 50);
  assert.equal(throneUnlocked(p), false);
  p = collect(engaged(p, 'lever'), 'lever');
  assert.equal(rewardCount(p), 3);
  assert.equal(partyMeter(p), 75);
  assert.equal(throneUnlocked(p), true);
  p = finish(p);
  assert.equal(p.won, true);
  assert.equal(partyMeter(p), 100);
});

test('save restores exactly earned progress, never fraudulent or corrupt state', () => {
  const p = collect(engaged(freshProgress(), 'catch'), 'catch');
  assert.deepEqual(parseProgress(JSON.stringify(p)), p);
  assert.deepEqual(parseProgress('{broken json'), freshProgress());
  assert.deepEqual(decodeProgress({version:99, won:true}), freshProgress());
  assert.equal(decodeProgress({version:1, engaged:{crank:false,catch:false,lever:false}, rewards:{crank:true,catch:true,lever:true}, won:true}).won, false);
});

test('restart replaces win, switches and collectibles with clean state', () => {
  let p = freshProgress();
  for (const name of ['crank','catch','lever']) p = collect(engaged(p, name), name);
  p = finish(p);
  assert.equal(p.won, true);
  p = freshProgress();
  assert.equal(p.won, false);
  assert.equal(partyMeter(p), 0);
  assert.equal(rewardCount(p), 0);
});

test('final button sits on the actual throne floor beyond the gated corridor', async () => {
  const { THRONE_BUTTON, GATE_Z } = await import('../.test-build/game/layout.js');
  const hall = PLATFORMS.find(p => p.id === 'south-hall');
  const throne = PLATFORMS.find(p => p.id === 'throne');
  assert.ok(hall && throne);
  assert.ok(GATE_Z > 13 && GATE_Z < 33, 'gate is inside the connected hallway');
  assert.ok(THRONE_BUTTON.z > GATE_Z, 'button is physically behind the gate');
  assert.ok(Math.abs(THRONE_BUTTON.x - throne.x) < throne.sx/2);
  assert.ok(Math.abs(THRONE_BUTTON.z - throne.z) < throne.sz/2);
  assert.equal(THRONE_BUTTON.y, throne.top);
});

test('authored platforms are unique and continuous without level-selection teleporters', () => {
  const ids = PLATFORMS.map(p => p.id);
  assert.equal(new Set(ids).size, ids.length);
  for (const p of PLATFORMS) {
    assert.ok(p.sx > 0 && p.sz > 0 && Number.isFinite(p.top));
    if (p.kind === 'bridge') assert.ok(p.required === 'crank' || p.required === 'lever');
  }
  for (const id of ['north-hall','east-hall','west-hall','south-hall']) {
    assert.ok(pathExists('hub', id), `continuous traversal into ${id}`);
  }
});
