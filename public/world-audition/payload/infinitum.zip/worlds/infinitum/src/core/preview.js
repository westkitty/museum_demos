import * as THREE from 'three';
import { constellationPower, stormIntensity, sunAmount, treeGrowth } from './state.js';
import { makeTerrain, updateTerrain, heightAt, riverX, mulberry32, material, disposeScene } from './math.js';
import { waterMaterial } from '../worlds/shared.js';
const nightLiving = new THREE.Color(0x172d3e);
const dayLiving = new THREE.Color(0x9cbbc0);
const nightGarden = new THREE.Color(0x0e1734);
const dayGarden = new THREE.Color(0x526f84);
const tempMatrix = new THREE.Object3D();
/** Physical portal texture resolution follows the selected GPU budget. */
export const previewResolution = (quality) => quality === 'low' ? 160 : quality === 'medium' ? 224 : 280;
function moveInstance(mesh, index, x, y, z, size) {
    tempMatrix.position.set(x, y, z);
    tempMatrix.rotation.set(0, 0, 0);
    tempMatrix.scale.setScalar(size);
    tempMatrix.updateMatrix();
    mesh.setMatrixAt(index, tempMatrix.matrix);
}
function relocateForest(forest, s) {
    forest.places.forEach((p, i) => {
        const h = heightAt(p.x, p.z, s);
        moveInstance(forest.trunks, i, p.x, h + 3.4 * p.size, p.z, p.size);
        moveInstance(forest.lowCrowns, i, p.x, h + 7.7 * p.size, p.z, p.size);
        moveInstance(forest.highCrowns, i, p.x, h + 10.4 * p.size, p.z, p.size * .78);
    });
    for (const mesh of [forest.trunks, forest.lowCrowns, forest.highCrowns]) {
        mesh.instanceMatrix.needsUpdate = true;
        mesh.computeBoundingSphere();
    }
}
function plantForest(scene, s) {
    const rng = mulberry32(411), places = [];
    for (let i = 0; i < 240; i++) {
        const x = (rng() - .5) * 226, z = (rng() - .5) * 155;
        if (z > 63 || Math.abs(x - riverX(z)) < 8 || Math.hypot(x - 17, z + 2) < 17 || Math.hypot(x + 29, z - 28) < 26)
            continue;
        places.push({ x, z, size: .50 + rng() * .50 });
    }
    const n = places.length;
    const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(.48, .68, 7, 5), material(0x725846, .94), n);
    const lowCrowns = new THREE.InstancedMesh(new THREE.ConeGeometry(3.5, 7, 6), material(0x446951, .93), n);
    const highCrowns = new THREE.InstancedMesh(new THREE.ConeGeometry(2.5, 6.6, 6), material(0x527c62, .92), n);
    const variations = [0xd5e8d0, 0xc1dec5, 0xabc9b7, 0xe6e6bf];
    places.forEach((_, i) => {
        const c = new THREE.Color(variations[i % variations.length]);
        lowCrowns.setColorAt(i, c);
        highCrowns.setColorAt(i, c);
    });
    const forest = { places, trunks, lowCrowns, highCrowns };
    relocateForest(forest, s);
    for (const mesh of [trunks, lowCrowns, highCrowns]) {
        mesh.frustumCulled = false;
        scene.add(mesh);
    }
    return forest;
}
function riverGeometry(s) {
    const pts = [];
    for (let z = -111; z <= 85; z += 5) {
        const x = riverX(z);
        pts.push(new THREE.Vector3(x, heightAt(x, z, s) + .30, z));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), Math.max(32, pts.length * 2), .64, 5, false);
}
function makeRiverMesh(s) {
    return new THREE.Mesh(riverGeometry(s), material(0x6aafb9, .31, .14));
}
function rebuildUserRivers(group, s) {
    const oldMaterials = new Set();
    group.children.forEach(child => {
        const river = child;
        river.geometry.dispose();
        for (const mat of Array.isArray(river.material) ? river.material : [river.material])
            oldMaterials.add(mat);
    });
    group.clear();
    oldMaterials.forEach(mat => mat.dispose());
    const mat = material(0x8acccf, .41, .08);
    for (const river of s.rivers) {
        const pts = river.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z, s) + .5, z));
        if (pts.length < 2)
            continue;
        const r = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), Math.max(10, pts.length * 4), .70, 5, false), mat);
        group.add(r);
    }
    // This material is shared by all river segments, and disposed by disposeScene().
    if (!group.children.length)
        mat.dispose();
}
function relocateVillage(town, s) {
    const { places, walls, roofs, windows } = town;
    places.forEach(({ x, z, scale, angle }, j) => {
        const y = heightAt(x, z, s);
        tempMatrix.position.set(x, y + 2.35 * scale, z);
        tempMatrix.rotation.set(0, angle, 0);
        tempMatrix.scale.setScalar(scale);
        tempMatrix.updateMatrix();
        walls.setMatrixAt(j, tempMatrix.matrix);
        tempMatrix.position.y = y + 5.7 * scale;
        tempMatrix.rotation.y = angle + Math.PI / 4;
        tempMatrix.updateMatrix();
        roofs.setMatrixAt(j, tempMatrix.matrix);
        tempMatrix.position.set(x + Math.sin(angle) * 2.55 * scale, y + 2.3 * scale, z + Math.cos(angle) * 2.3 * scale);
        tempMatrix.rotation.set(0, angle, 0);
        tempMatrix.scale.setScalar(scale);
        tempMatrix.updateMatrix();
        windows.setMatrixAt(j, tempMatrix.matrix);
    });
    for (const obj of [walls, roofs, windows]) {
        obj.instanceMatrix.needsUpdate = true;
        obj.computeBoundingSphere();
    }
}
function buildVillage(scene, s) {
    const village = new THREE.Group();
    const wall = material(0xbcb5a6, .98), roof = material(0x795e51, .91), window = new THREE.MeshBasicMaterial({ color: 0xffdcb1 });
    const wallMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(5, 4.7, 4.4), wall, 12);
    const roofMesh = new THREE.InstancedMesh(new THREE.ConeGeometry(4.2, 3.1, 4), roof, 12);
    const lights = new THREE.InstancedMesh(new THREE.PlaneGeometry(1.5, 1.2), window, 12);
    const rng = mulberry32(114), places = [];
    for (let j = 0; j < 12; j++) {
        const a = j / 12 * Math.PI * 1.8, dist = 5 + Math.floor(j / 4) * 5;
        places.push({ x: -29 + Math.sin(a + j * .12) * dist, z: 28 + Math.cos(a + j * .12) * dist,
            angle: rng() * Math.PI * 2, scale: .75 + rng() * .38 });
    }
    const town = { places, walls: wallMesh, roofs: roofMesh, windows: lights };
    relocateVillage(town, s);
    lights.material.side = THREE.DoubleSide;
    village.add(wallMesh, roofMesh, lights);
    scene.add(village);
    return town;
}
export class PreviewManager {
    renderer;
    previews;
    /** Number of actual miniature render-target passes, useful for source/runtime proof. */
    renderPasses = 0;
    constructor(renderer, initial) {
        this.renderer = renderer;
        this.previews = [this.createLiving(initial), this.createGarden(initial)];
        this.previews.forEach(m => { m.target.texture.userData.shared = true; });
    }
    get living() { return this.previews[0].target.texture; }
    get garden() { return this.previews[1].target.texture; }
    createLiving(s) {
        const scene = new THREE.Scene(), background = new THREE.Color(dayLiving);
        scene.background = background;
        scene.fog = new THREE.FogExp2(0x819ea6, .0035);
        const camera = new THREE.PerspectiveCamera(42, 1, .1, 600);
        camera.position.set(93, 80, 133);
        camera.lookAt(0, 12, -10);
        const target = new THREE.WebGLRenderTarget(previewResolution(s.quality), previewResolution(s.quality), { depthBuffer: true });
        const lighting = new THREE.DirectionalLight(0xffdfc0, 2.2);
        lighting.position.set(-100, 170, 65);
        scene.add(lighting, new THREE.HemisphereLight(0xb7d1d6, 0x253c32, 2.0));
        const terrain = new THREE.Mesh(makeTerrain(s, 240, 54), material(0x557b68, .94));
        scene.add(terrain);
        const ocean = new THREE.Mesh(new THREE.PlaneGeometry(245, 100), waterMaterial(0x427e92, .89));
        ocean.rotation.x = -Math.PI / 2;
        ocean.position.set(0, -.6, 95);
        scene.add(ocean);
        const river = makeRiverMesh(s);
        scene.add(river);
        const playerRivers = new THREE.Group();
        scene.add(playerRivers);
        rebuildUserRivers(playerRivers, s);
        const forest = plantForest(scene, s);
        const town = buildVillage(scene, s);
        const ruins = new THREE.Group();
        ruins.position.set(32, heightAt(32, 44, s) + 1, 44);
        const stone = material(0xa2a99c, .85), glow = new THREE.MeshBasicMaterial({ color: 0x8ee1da });
        const ring = new THREE.Mesh(new THREE.TorusGeometry(6, .36, 5, 20), glow);
        ring.rotation.x = -Math.PI / 2;
        ruins.add(ring);
        for (let i = 0; i < 5; i++) {
            const a = i / 5 * Math.PI * 2;
            const pillar = new THREE.Mesh(new THREE.CylinderGeometry(.68, .83, 5.8, 6), stone);
            pillar.position.set(Math.cos(a) * 4, 2.9, Math.sin(a) * 4);
            ruins.add(pillar);
        }
        scene.add(ruins);
        const central = new THREE.Group();
        const bark = material(0x6e5144, .95), leaves = material(0x86b08b, .85);
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(1.65, 3, 30, 9), bark);
        trunk.position.y = 15;
        central.add(trunk);
        for (let i = 0; i < 5; i++) {
            const a = i / 5 * Math.PI * 2;
            const branch = new THREE.Mesh(new THREE.CylinderGeometry(.55, 1.05, 12, 6), bark);
            branch.position.set(Math.sin(a) * 6.1, 23, Math.cos(a) * 6.1);
            branch.rotation.z = Math.cos(a) * .74;
            branch.rotation.x = -Math.sin(a) * .74;
            central.add(branch);
        }
        for (let j = 0; j < 3; j++) {
            const canopy = new THREE.Mesh(new THREE.IcosahedronGeometry(10.7 - j * 1.2, 1), leaves);
            canopy.position.set(j === 0 ? 0 : j === 1 ? 8 : -7, 29 + j * 2, j === 2 ? -5 : 0);
            central.add(canopy);
        }
        central.position.set(17, heightAt(17, -2, s), -2);
        scene.add(central);
        const atmosphere = new THREE.MeshBasicMaterial({ color: 0xf1eee0 });
        const sun = new THREE.Mesh(new THREE.SphereGeometry(8, 14, 9), atmosphere);
        sun.position.set(-92, 119, -125);
        scene.add(sun);
        return { scene, camera, target, lighting, atmosphere, background, terrain, central, forest, river, playerRivers, water: ocean, ruins, town,
            lastTerrain: s.terrain.join(','), lastRiver: JSON.stringify(s.rivers), lastSeason: s.season };
    }
    createGarden(s) {
        const scene = new THREE.Scene(), background = new THREE.Color(0x192943);
        scene.background = background;
        const camera = new THREE.PerspectiveCamera(45, 1, .1, 500);
        camera.position.set(76, 47, 100);
        camera.lookAt(0, 20, -32);
        const target = new THREE.WebGLRenderTarget(previewResolution(s.quality), previewResolution(s.quality), { depthBuffer: true });
        const lighting = new THREE.DirectionalLight(0x9cdce1, 2.7);
        lighting.position.set(-30, 90, 50);
        scene.add(lighting, new THREE.HemisphereLight(0x83bfc3, 0x24243d, 1.8));
        const glass = material(0x416c7b, .4, .34), vein = material(0x8dc6bc, .35, .47);
        const glow = new THREE.MeshBasicMaterial({ color: 0xabeae1 });
        for (let j = 0; j < 8; j++) {
            const a = j / 8 * Math.PI * 2, r = j === 0 ? 0 : 28 + j * 6;
            const root = new THREE.Group();
            root.position.set(Math.cos(a) * r, 7 + j % 3 * 9, Math.sin(a) * r - 20);
            const base = new THREE.Mesh(new THREE.IcosahedronGeometry(10 + j % 3 * 2, 1), glass);
            base.scale.y = .65;
            root.add(base);
            const under = new THREE.Mesh(new THREE.ConeGeometry(7.7 + j % 3 * 2, 16 + j % 4 * 3, 7), glass);
            under.rotation.z = Math.PI;
            under.position.y = -11;
            root.add(under);
            for (let k = 0; k < 3; k++) {
                const spire = new THREE.Mesh(new THREE.CylinderGeometry(.35, 1.1, 16 + j % 4 * 4, 6), vein);
                spire.position.set(Math.cos(k * 2.09) * 5, 10 + k % 2 * 2, Math.sin(k * 2.09) * 5);
                spire.rotation.z = .1 * Math.sin(k);
                root.add(spire);
            }
            scene.add(root);
        }
        const stars = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.72, 0), glow, 78);
        const rng = mulberry32(868);
        for (let i = 0; i < 78; i++) {
            const a = rng() * Math.PI * 2, r = 20 + rng() * 130;
            tempMatrix.position.set(Math.cos(a) * r, rng() * 75 + 28, Math.sin(a) * r - 55);
            tempMatrix.scale.setScalar(.35 + rng() * 1.3);
            tempMatrix.rotation.set(0, 0, 0);
            tempMatrix.updateMatrix();
            stars.setMatrixAt(i, tempMatrix.matrix);
        }
        stars.instanceMatrix.needsUpdate = true;
        stars.frustumCulled = false;
        scene.add(stars);
        const gardenSignals = [];
        for (let i = 0; i < 3; i++) {
            const halo = new THREE.Mesh(new THREE.TorusGeometry(10 + i * 3, .21, 7, 72), new THREE.MeshBasicMaterial({ color: i === 0 ? 0xbfe8bd : i === 1 ? 0xa5e4e9 : 0xd4bfeb, transparent: true, opacity: .20 }));
            halo.position.set(0, 42 + i * 6, -34);
            halo.rotation.set(.33 + i * .14, i * .42, 0);
            scene.add(halo);
            gardenSignals.push(halo);
        }
        const atmosphere = new THREE.MeshBasicMaterial({ color: 0x96d4e5 });
        const planet = new THREE.Mesh(new THREE.SphereGeometry(12, 20, 14), atmosphere);
        planet.position.set(-43, 65, -93);
        scene.add(planet);
        return { scene, camera, target, lighting, atmosphere, background, gardenSignals };
    }
    update(s, elapsed, _force = false, visibleTargets = [0, 1]) {
        const targets = new Set(visibleTargets);
        const oldTarget = this.renderer.getRenderTarget();
        try {
            for (const i of targets) {
                const m = this.previews[i];
                const size = previewResolution(s.quality);
                if (m.target.width !== size || m.target.height !== size)
                    m.target.setSize(size, size);
                if (i === 0) {
                    const terrainKey = s.terrain.join(','), riverKey = JSON.stringify(s.rivers);
                    if (m.lastTerrain !== terrainKey && m.terrain && m.forest) {
                        updateTerrain(m.terrain.geometry, s);
                        relocateForest(m.forest, s);
                        if (m.town)
                            relocateVillage(m.town, s);
                        if (m.central)
                            m.central.position.y = heightAt(17, -2, s);
                        if (m.ruins)
                            m.ruins.position.y = heightAt(32, 44, s) + 1;
                        if (m.river) {
                            const old = m.river.geometry;
                            m.river.geometry = riverGeometry(s);
                            old.dispose();
                        }
                        m.lastTerrain = terrainKey;
                        m.lastRiver = ''; // sculpting invalidates player-made river heights too
                    }
                    if (m.lastRiver !== riverKey && m.playerRivers) {
                        rebuildUserRivers(m.playerRivers, s);
                        m.lastRiver = riverKey;
                    }
                    if (m.forest && m.lastSeason !== s.season) {
                        const tint = s.season === 'Autumn' ? 0xb77e52 : s.season === 'Winter' ? 0xb3c8c7 : s.season === 'Spring' ? 0x9dcd99 : 0xffffff;
                        for (const foliage of [m.forest.lowCrowns, m.forest.highCrowns]) {
                            foliage.material.color.setHex(tint);
                        }
                        m.lastSeason = s.season;
                    }
                }
                const sun = sunAmount(s.time);
                m.lighting.intensity = (i === 0 ? 1.4 : 1.2) + sun * .9;
                m.background.copy(i === 0 ? nightLiving : nightGarden).lerp(i === 0 ? dayLiving : dayGarden, sun * .72);
                m.atmosphere.color.set(i === 0 ? (sun > .3 ? 0xffe4b5 : 0xa1d8ed) : constellationPower(s) > 0 ? 0xb0fff1 : 0x92b9df);
                if (i === 0) {
                    if (m.central)
                        m.central.scale.setScalar(1 + treeGrowth(s) * .2);
                    if (m.water) {
                        const shader = m.water.material;
                        shader.uniforms.uTime.value = elapsed;
                        shader.uniforms.uRain.value = stormIntensity(s.weather);
                        shader.uniforms.uDay.value = sun;
                    }
                    if (m.scene.fog instanceof THREE.FogExp2)
                        m.scene.fog.density = .0035 + stormIntensity(s.weather) * .012;
                }
                else {
                    m.scene.rotation.y = s.reducedMotion ? 0 : Math.sin(elapsed * .01) * .005;
                    const power = constellationPower(s);
                    m.gardenSignals?.forEach((ring, j) => {
                        const mat = ring.material;
                        mat.opacity = power > j ? .56 : .12;
                        ring.rotation.y = .4 + j * .42 + (s.reducedMotion ? 0 : elapsed * (.017 + j * .008));
                    });
                }
                this.renderer.setRenderTarget(m.target);
                this.renderer.render(m.scene, m.camera);
                this.renderPasses++;
            }
        }
        finally {
            this.renderer.setRenderTarget(oldTarget);
        }
    }
    dispose() { this.previews.forEach(p => { disposeScene(p.scene); p.target.dispose(); }); }
}
