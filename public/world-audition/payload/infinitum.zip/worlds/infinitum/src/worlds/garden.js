import { gardenAccess, gravityAligned, causalStage } from '../core/simulation.js';
import * as THREE from 'three';
import { CinematicVistas } from './cinematic-vistas.js';
import { constellationPower, stormIntensity, lightAligned } from '../core/state.js';
import { TAU, material, mulberry32, tube, clamp, lerp, disposeScene } from '../core/math.js';
import { EnvironmentRig, makeDust, labelObject, waterMaterial } from './shared.js';
import { ART, grainTexture, leafBlade, softGlow } from './art.js';
import { authoredSurface, authoredDecal } from './asset-materials.js';
import { STAR_POINTS } from '../core/constellations.js';
export { STAR_POINTS, CONSTELLATION_SHAPES, edgeKey, constellationCompletion } from '../core/constellations.js';
function islandGeometry(radius, seed) {
    const rng = mulberry32(seed), ringCount = 9, radial = 28, vert = [], colors = [], indices = [];
    const top = new THREE.Color(0x596f72), underside = new THREE.Color(0x273a43);
    const baseRadii = Array.from({ length: radial }, () => radius * (.85 + rng() * .3));
    for (let j = 0; j < ringCount; j++) {
        const layer = j / (ringCount - 1);
        const y = j === 0 ? 3 : (j === 1 ? 1.8 : 3 - layer * 12);
        const rMultiplier = j === 0 ? 0.83 : j === 1 ? 1 : Math.pow(1 - layer, .84);
        for (let i = 0; i < radial; i++) {
            const a = i / radial * TAU, r = baseRadii[i] * rMultiplier;
            const vY = y + (j < 2 ? Math.sin(a * 5 + seed) * .65 : rng() * .5);
            vert.push(Math.cos(a) * r, vY, Math.sin(a) * r);
            const c = top.clone().lerp(underside, layer * .91);
            colors.push(c.r, c.g, c.b);
        }
    }
    for (let j = 0; j < ringCount - 1; j++)
        for (let i = 0; i < radial; i++) {
            const a = j * radial + i, b = j * radial + (i + 1) % radial, c = (j + 1) * radial + i, d = (j + 1) * radial + (i + 1) % radial;
            indices.push(a, b, c, b, d, c);
        }
    // top fan to central vertex
    const center = vert.length / 3;
    vert.push(0, 3.0, 0);
    colors.push(top.r, top.g, top.b);
    for (let i = 0; i < radial; i++)
        indices.push(center, i, (i + 1) % radial);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(vert, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    // Authored astral glaze maps to top and underside; planar UVs avoid a ring seam.
    const uv = [];
    for (let j = 0; j < vert.length; j += 3)
        uv.push(.5 + vert[j] / (radius * 2.4), .5 + vert[j + 2] / (radius * 2.4));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
}
function cosmicFlora(seed, height) {
    const rng = mulberry32(seed), group = new THREE.Group();
    const bark = material(0x4c6770, .61, .49), glow = new THREE.MeshStandardMaterial({ color: 0x9ac2bc, roughness: .34, metalness: .09, emissive: 0x43ad9f, emissiveIntensity: 1.0 });
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.22, .7, height, 7), bark);
    trunk.position.y = height * .5 + 1.1;
    group.add(trunk);
    const blossoms = new THREE.Group();
    for (let i = 0; i < 12; i++) {
        const a = i / 12 * TAU, r = 2 + rng() * 2.8;
        const points = [new THREE.Vector3(0, height * .62 + 1, 0), new THREE.Vector3(Math.cos(a) * r * .6, height * .83 + 1.3, Math.sin(a) * r * .6), new THREE.Vector3(Math.cos(a) * r, height + 1.4 + rng() * 1.8, Math.sin(a) * r)];
        group.add(tube(points, .09, 0x779b9b, 16));
        const star = new THREE.Mesh(new THREE.IcosahedronGeometry(.26 + rng() * .2, 1), glow);
        star.position.copy(points[2]);
        blossoms.add(star);
    }
    // One instanced botanical crown replaces a cluster of individual decorative meshes.
    // Each petal is authored leaf geometry and is animated with the existing blossom group.
    const bractMat = new THREE.MeshStandardMaterial({ color: 0xa1c9bd, emissive: 0x316b68, emissiveIntensity: .36, metalness: .18, roughness: .49, side: THREE.DoubleSide });
    const bracts = new THREE.InstancedMesh(leafBlade(), bractMat, 9), petal = new THREE.Object3D();
    for (let i = 0; i < 9; i++) {
        const a = i / 9 * TAU + seed * .1;
        petal.position.set(Math.cos(a) * 1.05, height + 2.35, Math.sin(a) * 1.05);
        petal.rotation.set(.30 * Math.cos(a), -a, .56 * Math.sin(a));
        petal.scale.set(1.5, 2.0, 1.5);
        petal.updateMatrix();
        bracts.setMatrixAt(i, petal.matrix);
    }
    bracts.instanceMatrix.needsUpdate = true;
    bracts.userData.feature = 'astral-bracts-art';
    blossoms.add(bracts);
    const globe = new THREE.Mesh(new THREE.IcosahedronGeometry(1.1, 1), new THREE.MeshStandardMaterial({ color: 0xc7dcdf, emissive: 0x6daab2, emissiveIntensity: 1.0, transparent: true, opacity: .72 }));
    globe.position.y = height + 3.2;
    group.add(globe);
    group.add(blossoms);
    group.userData.blossoms = blossoms;
    group.userData.bracts = bracts;
    return group;
}
export class CelestialGarden {
    id = 2;
    scene = new THREE.Scene();
    spawn = { position: new THREE.Vector3(20, 22, 72), target: new THREE.Vector3(0, 17, 0) };
    portal = null;
    exitPortal = new THREE.Vector3(0, 9, 6);
    inspectionObjects = [];
    rig;
    vistas;
    islands = [];
    celestialBodies = [];
    starmesh = [];
    lineGroup = new THREE.Group();
    lastEdgeHash = '';
    signature = new THREE.Group();
    signatureObjects = [];
    flora = [];
    mechanism = [];
    water;
    dust;
    nebulaVeils = [];
    worldGlows = [];
    breathingOrnaments = [];
    glowingGarden = new THREE.PointLight(0x4bb5bf, 5.0, 160);
    sanctuaries = [];
    returnGate = new THREE.Group();
    authoredBridges = [];
    sanctuaryBridges = [];
    islandRadii = [];
    astralSeal = null;
    constructor(s) {
        this.rig = new EnvironmentRig(this.scene, 2, s.quality);
        this.vistas = new CinematicVistas(this.scene, 2, s);
        this.rig.haze.color.set(0x0c152b);
        this.rig.haze.density = .0028; // EnvironmentRig must own fog transitions.
        const horizon = new THREE.Mesh(new THREE.PlaneGeometry(1000, 1000, 64, 64), waterMaterial(0x172a4d, .87));
        horizon.rotation.x = -Math.PI / 2;
        horizon.position.y = -17;
        this.scene.add(horizon);
        this.water = horizon;
        this.scene.add(this.glowingGarden);
        this.glowingGarden.position.set(0, 22, 0);
        // Distant astral direction markers give the garden a visual north without a HUD minimap.
        const compass = new THREE.Group();
        compass.position.set(0, 7, 0);
        const compassMat = new THREE.MeshBasicMaterial({ color: ART.gold, transparent: true, opacity: .68 });
        for (let i = 0; i < 8; i++) {
            const a = i / 8 * TAU;
            const guide = new THREE.Mesh(new THREE.OctahedronGeometry(i % 2 ? 1.1 : 1.7, 0), compassMat);
            guide.position.set(Math.cos(a) * 13, 0, Math.sin(a) * 13);
            guide.rotation.y = a;
            compass.add(guide);
        }
        this.scene.add(compass);
        this.breathingOrnaments.push(compass);
        this.returnGate.position.copy(this.exitPortal);
        const glassArc = new THREE.Mesh(new THREE.TorusGeometry(4.6, .13, 8, 80), new THREE.MeshStandardMaterial({ color: 0x8ed9d9, metalness: .62, roughness: .18, emissive: 0x358f92, emissiveIntensity: 1.0 }));
        glassArc.rotation.set(.12, .28, 0);
        this.returnGate.add(glassArc);
        const trace = new THREE.Mesh(new THREE.SphereGeometry(.92, 20, 14), new THREE.MeshPhysicalMaterial({ color: 0xd7f0e7, transmission: .78, roughness: .05, ior: 1.33, transparent: true, opacity: .57 }));
        this.returnGate.add(trace);
        labelObject(this.returnGate, 'THE INNER MEMBRANE · Return to the leaf', 'portal');
        this.returnGate.userData.clueId = 'garden-origin';
        this.inspectionObjects.push(this.returnGate);
        this.scene.add(this.returnGate);
        const islandMaterial = authoredSurface('astral', { tint: 0xf1f8f9, repeat: 2.15, vertexColors: true, roughness: .55, metalness: .24, quality: s.quality, side: THREE.DoubleSide });
        const coords = [
            [0, 0, 0, 18], [29, 8, -22, 13], [-34, 9, -25, 14], [57, 15, -55, 11], [-64, 16, -48, 15],
            [9, 19, -73, 16], [39, 25, -113, 15], [-39, 27, -112, 12], [0, 35, -150, 19], [79, 32, -151, 12]
        ];
        coords.forEach(([x, y, z, r], i) => {
            const group = new THREE.Group();
            group.position.set(x, y, z);
            this.islandRadii.push(r);
            const stone = new THREE.Mesh(islandGeometry(r, 100 + i * 37), islandMaterial);
            stone.userData.feature = 'astral-mineral-art';
            group.add(stone);
            if (i === 0) {
                const glyph = new THREE.Mesh(new THREE.PlaneGeometry(r * 1.18, r * 1.18), authoredDecal('celestial', .31));
                glyph.rotation.x = -Math.PI / 2;
                glyph.position.y = 3.23;
                glyph.renderOrder = 2;
                glyph.userData.feature = 'astral-seal-art';
                group.add(glyph);
                this.astralSeal = glyph;
            }
            // Faceted crystal roots and dark radial striations clarify each island silhouette.
            const crystals = new THREE.Group();
            group.add(crystals);
            const spireMat = new THREE.MeshStandardMaterial({ color: i % 2 ? 0x6b9d9b : 0x7c83a6, roughness: .2, metalness: .39, emissive: 0x225863, emissiveIntensity: .27 });
            const shardCount = s.quality === 'low' ? 4 : 9;
            for (let k = 0; k < shardCount; k++) {
                const a = k / shardCount * TAU + i * .31, rad = r * (.34 + .3 * Math.sin(k * 4.1 + i));
                const shard = new THREE.Mesh(new THREE.ConeGeometry(.55 + (k % 3) * .4, 4.5 + (k % 4) * 3.4, 5), spireMat);
                shard.position.set(Math.cos(a) * rad, -5.2 - (k % 4) * 1.2, Math.sin(a) * rad);
                shard.rotation.z = Math.sin(a) * .28;
                shard.rotation.x = Math.cos(a) * .28;
                crystals.add(shard);
            }
            const rim = new THREE.Mesh(new THREE.TorusGeometry(r * .8, .22, 6, 72), new THREE.MeshBasicMaterial({ color: i % 2 ? 0x93b7bc : 0x6ad8cc, transparent: true, opacity: .54 }));
            rim.rotation.x = Math.PI / 2;
            rim.position.y = 2.7;
            group.add(rim);
            const engraved = new THREE.Mesh(new THREE.TorusGeometry(r * .68, .035, 4, 90), new THREE.MeshBasicMaterial({ color: ART.gold, transparent: true, opacity: .32, depthWrite: false }));
            engraved.rotation.x = Math.PI / 2;
            engraved.position.y = 3.06;
            group.add(engraved);
            if (i % 2 === 0) {
                const lamp = softGlow(i % 4 === 0 ? ART.glacial : ART.lilac, r * 1.45, .13);
                lamp.position.set(0, 4.5, 0);
                group.add(lamp);
                this.worldGlows.push(lamp);
            }
            for (let f = 0; f < ((i % 3) + 2); f++) {
                const a = f * TAU / 5 + i, flower = cosmicFlora(i * 40 + f, 7 + (i + f) % 4 * 2);
                flower.position.set(Math.sin(a) * r * .5, 3, Math.cos(a) * r * .5);
                group.add(flower);
                this.flora.push(flower);
            }
            const gate = new THREE.Mesh(new THREE.TorusGeometry(4.8, .19, 8, 50), material(0x8aa9af, .27, .71));
            gate.rotation.x = Math.PI / 2;
            gate.position.y = 2.9;
            group.add(gate);
            this.scene.add(group);
            this.islands.push(group);
            labelObject(group, `CRYSTAL ISLAND ${i + 1} · Celestial flora`);
            this.inspectionObjects.push(group);
        });
        // Finite navigable constellation path linking authored islands.
        const bridgeMat = new THREE.MeshStandardMaterial({ color: 0x748f9d, metalness: .65, roughness: .32, emissive: 0x24565f, emissiveIntensity: .72 });
        for (let i = 0; i < coords.length - 1; i++) {
            const a = coords[i], b = coords[i + 1];
            const A = new THREE.Vector3(a[0], a[1] + 3.5, a[2]);
            const B = new THREE.Vector3(b[0], b[1] + 3.5, b[2]);
            const curve = new THREE.CatmullRomCurve3([A, A.clone().lerp(B, .45).add(new THREE.Vector3(0, 3.5, 0)), B]);
            const bridge = new THREE.Mesh(new THREE.TubeGeometry(curve, 48, 1.4, 9, false), bridgeMat);
            this.scene.add(bridge);
            this.authoredBridges.push(curve);
            const railCurve = new THREE.CatmullRomCurve3([A.clone().add(new THREE.Vector3(0, 1, 2)), A.clone().lerp(B, .5).add(new THREE.Vector3(0, 4, 2)), B.clone().add(new THREE.Vector3(0, 1, 2))]);
            const railL = new THREE.Mesh(new THREE.TubeGeometry(railCurve, 38, .1, 5), bridgeMat);
            this.scene.add(railL);
            const inlay = new THREE.Mesh(new THREE.TubeGeometry(curve, 48, .06, 4, false), new THREE.MeshBasicMaterial({ color: ART.glacial, transparent: true, opacity: .56, depthWrite: false }));
            inlay.position.y = 1.13;
            this.scene.add(inlay);
            // Free-standing celestial beacons punctuate long sightlines and act as route markers.
            const marker = new THREE.Mesh(new THREE.OctahedronGeometry(.62, 0), new THREE.MeshStandardMaterial({ color: 0xc3e2d5, emissive: 0x4da59a, emissiveIntensity: .8, roughness: .25 }));
            marker.position.copy(A).add(new THREE.Vector3(0, 4, 0));
            this.scene.add(marker);
        }
        // Three optional sanctuaries are literal navigable terrain, not light-only rewards.
        const sanctuaryAnchors = [new THREE.Vector3(57, 18.5, -55), new THREE.Vector3(-64, 19.5, -48), new THREE.Vector3(79, 35.5, -151)];
        const sanctuaryDestinations = [new THREE.Vector3(105, 33, -73), new THREE.Vector3(-108, 31, -76), new THREE.Vector3(115, 49, -196)];
        sanctuaryDestinations.forEach((target, i) => {
            const root = new THREE.Group();
            root.position.copy(target);
            const land = new THREE.Mesh(islandGeometry(10 + i * 2, 918 + i * 34), islandMaterial);
            root.add(land);
            const bloom = cosmicFlora(80 + i, 11 + i * 2);
            bloom.position.y = 3.1;
            root.add(bloom);
            this.flora.push(bloom);
            const marker = new THREE.Mesh(new THREE.IcosahedronGeometry(1.7, 1), new THREE.MeshStandardMaterial({ color: 0xc6eedf, emissive: 0x53bcaf, emissiveIntensity: 1.5 }));
            marker.position.set(0, 22, 0);
            root.add(marker);
            labelObject(root, `AWAKENED SANCTUARY ${i + 1} · a constellation opens the path`);
            root.userData.feature = 'sanctuary-island';
            root.userData.clueId = 'garden-orrery';
            this.inspectionObjects.push(root);
            this.scene.add(root);
            const A = sanctuaryAnchors[i], B = target.clone().add(new THREE.Vector3(0, 3.6, 0));
            const curve = new THREE.CatmullRomCurve3([A, A.clone().lerp(B, .4).add(new THREE.Vector3(0, 7, 0)), B]);
            this.sanctuaryBridges.push(curve);
            const bridge = new THREE.Mesh(new THREE.TubeGeometry(curve, 48, 1.15, 8, false), new THREE.MeshStandardMaterial({ color: 0x7bc3bf, emissive: 0x285a62, emissiveIntensity: 1.2, metalness: .62, roughness: .37, transparent: true, opacity: 0, depthWrite: false }));
            bridge.userData.feature = 'sanctuary-route';
            bridge.visible = false;
            this.scene.add(bridge);
            this.sanctuaries.push({ root, bridge, target, progress: 0 });
        });
        // Orbiting astronomical bodies; their paths are geometrically distinct.
        const bodyCols = [0x98afcf, 0xa1c6bd, 0xd8b69e, 0xd4d5bb, 0x7c9bca];
        for (let i = 0; i < 5; i++) {
            const group = new THREE.Group();
            const map = grainTexture(i * 41 + 2);
            const planet = new THREE.Mesh(new THREE.SphereGeometry(3.6 + i * .8, 36, 24), new THREE.MeshStandardMaterial({ color: bodyCols[i], map, roughness: .48, metalness: i % 2 ? .46 : .13, emissive: bodyCols[i], emissiveIntensity: .1 }));
            group.add(planet);
            const ring = new THREE.Mesh(new THREE.TorusGeometry(6.2 + i * .6, .11, 5, 96), new THREE.MeshBasicMaterial({ color: 0xa6d6e7, transparent: true, opacity: .47 }));
            ring.rotation.x = .36 + i * .24;
            group.add(ring);
            const phase = new THREE.Mesh(new THREE.TorusGeometry(8.8 + i * .7, .045, 4, 112), new THREE.MeshBasicMaterial({ color: ART.copper, transparent: true, opacity: .46 }));
            phase.rotation.set(.74, .25 * i, 0);
            group.add(phase);
            const halo = softGlow(i % 2 ? ART.lilac : ART.glacial, 20 + i * 2, .15);
            group.add(halo);
            this.worldGlows.push(halo);
            this.celestialBodies.push(group);
            this.scene.add(group);
        }
        const rng = mulberry32(6334);
        for (let i = 0; i < 20; i++) {
            const g = new THREE.Group();
            const a = i / 20 * TAU, r = 105 + (i % 4) * 16;
            g.position.set(Math.cos(a) * r, 20 + Math.sin(a * 3) * 17, Math.sin(a) * r - 28);
            const base = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 2.2, 17 + i % 3 * 5, 9), material(0x536471, .53, .61));
            base.position.y = 8;
            g.add(base);
            const ring = new THREE.Mesh(new THREE.TorusGeometry(8 + i % 4 * 2, .24, 6, 96), material(0x829faa, .35, .65));
            ring.rotation.set(rng() * TAU, rng() * TAU, rng() * TAU);
            ring.position.y = 20;
            g.add(ring);
            const fin = new THREE.Mesh(new THREE.ConeGeometry(2.3, 7, 5), material(0x73979b, .42, .73));
            fin.position.y = 20 + i % 4 * 2;
            g.add(fin);
            this.scene.add(g);
            this.mechanism.push(g);
        }
        // Giant inner armillary, intentionally astronomical rather than architectural.
        const worldOrrery = new THREE.Group();
        worldOrrery.position.set(0, 57, -133);
        for (let i = 0; i < 8; i++) {
            const torus = new THREE.Mesh(new THREE.TorusGeometry(29 + i * 3, .17 + i * .018, 8, 160), new THREE.MeshStandardMaterial({ color: i % 3 === 0 ? 0xb2d0d3 : 0x688f9c, metalness: .79, roughness: .25, emissive: 0x204a62, emissiveIntensity: .29 }));
            torus.rotation.set(i * .19, i * .57, i * .23);
            worldOrrery.add(torus);
        }
        this.scene.add(worldOrrery);
        this.mechanism.push(worldOrrery);
        labelObject(worldOrrery, 'THE ASTRAL ORRERY · The same pattern as the Observatory');
        worldOrrery.userData.clueId = 'garden-orrery';
        this.inspectionObjects.push(worldOrrery);
        // Actual selectable constellation points and lines.
        this.scene.add(this.lineGroup);
        STAR_POINTS.forEach(([x, y, z], i) => {
            const star = new THREE.Mesh(new THREE.IcosahedronGeometry(1.15, 1), new THREE.MeshBasicMaterial({ color: 0xd3f4e5 }));
            star.position.set(x, y, z);
            star.userData.starId = i;
            labelObject(star, `STAR ${i + 1} · Connect the constellation`, 'star');
            this.scene.add(star);
            this.starmesh.push(star);
            this.inspectionObjects.push(star);
            const halo = new THREE.Mesh(new THREE.SphereGeometry(2.7, 10, 8), new THREE.MeshBasicMaterial({ color: 0x9ec7ed, transparent: true, opacity: .095, depthWrite: false }));
            halo.position.copy(star.position);
            this.scene.add(halo);
        });
        // First-entry signature: the cosmic instruments resolve into an ABSTRACT correspondence
        // to the outer observatory's radial columns and dome, with no duplicated room geometry.
        const signatureMat = material(0x87b2be, .29, .67);
        for (let i = 0; i < 14; i++) {
            const g = new THREE.Group();
            const tall = new THREE.Mesh(new THREE.CylinderGeometry(.5, 1.45, 18 + (i % 4) * 3, 7), signatureMat);
            tall.position.y = 9;
            g.add(tall);
            const arc = new THREE.Mesh(new THREE.TorusGeometry(6.8, .18, 6, 56, Math.PI * .9), signatureMat);
            arc.rotation.z = i % 3 * .25;
            arc.position.y = 21;
            g.add(arc);
            const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(1.3 + i % 3 * .3, 0), new THREE.MeshStandardMaterial({ color: 0xb9e1dd, emissive: 0x438d9e, emissiveIntensity: .61 }));
            crystal.position.y = 26;
            g.add(crystal);
            const angle = i / 14 * TAU;
            const from = new THREE.Vector3(Math.cos(angle * 2.3) * 120, 38 + Math.sin(angle * 1.4) * 40, -160 + Math.sin(angle * 3) * 86);
            const to = new THREE.Vector3(Math.cos(angle) * 54, 33 + Math.sin(angle * 2) * 12, -165 + Math.sin(angle) * 41);
            g.position.copy(from);
            this.signature.add(g);
            this.signatureObjects.push({ object: g, from, to });
        }
        this.scene.add(this.signature);
        const constellationMist = makeDust(this.scene, s.quality === 'low' ? 700 : 1900, new THREE.Vector3(360, 130, 380), 3327, 0x9db8df);
        this.dust = constellationMist;
        // Soft camera-facing light scattering veils; avoid solid transparent nebula spheres.
        const veilCount = s.quality === 'low' ? 5 : 11;
        for (let i = 0; i < veilCount; i++) {
            const a = i / veilCount * TAU;
            const veil = softGlow(i % 3 === 0 ? 0x7271a6 : i % 2 === 0 ? 0x337e83 : 0x4f6c95, 140 + i % 3 * 43, .06);
            veil.position.set(Math.cos(a) * 176, 42 + Math.sin(a * 2) * 58, Math.sin(a) * 155 - 74);
            this.scene.add(veil);
            this.nebulaVeils.push(veil);
        }
        // An astronomer's halo above the central crossing links the nested scale motifs.
        const axis = new THREE.Group();
        axis.position.set(0, 47, -58);
        for (let i = 0; i < 4; i++) {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(15 + i * 5.6, .055 + i * .01, 6, 120), new THREE.MeshBasicMaterial({ color: i % 2 ? ART.lilac : ART.glacial, transparent: true, opacity: .24, depthWrite: false }));
            ring.rotation.set(i * .44, .9 + i * .4, i * .27);
            axis.add(ring);
        }
        this.scene.add(axis);
        this.breathingOrnaments.push(axis);
        this.sync(s);
    }
    getStarId(object) {
        let o = object;
        while (o) {
            if (typeof o.userData.starId === 'number')
                return o.userData.starId;
            o = o.parent;
        }
        return null;
    }
    sync(s) {
        if (this.astralSeal)
            this.astralSeal.material.opacity = .27 + .22 * Math.min(1, constellationPower(s));
        for (const g of this.flora)
            g.userData.bracts.material.emissiveIntensity = .28 + Math.min(1, constellationPower(s)) * .4;
        const hash = s.constellations.slice().sort().join('|');
        if (hash === this.lastEdgeHash)
            return;
        this.lastEdgeHash = hash;
        for (const old of [...this.lineGroup.children]) {
            this.lineGroup.remove(old);
            old.geometry?.dispose();
            if (old.material) {
                const m = old.material;
                if (m instanceof THREE.Material)
                    m.dispose();
            }
        }
        const visible = new Set();
        for (const edge of s.constellations) {
            if (!edge.startsWith('edge:') || visible.has(edge))
                continue;
            visible.add(edge);
            const found = /^edge:(\d+)-(\d+)$/.exec(edge);
            if (!found)
                continue;
            const a = Number(found[1]), b = Number(found[2]);
            if (!STAR_POINTS[a] || !STAR_POINTS[b])
                continue;
            const completed = constellationPower(s) > 0;
            const A = new THREE.Vector3(...STAR_POINTS[a]), B = new THREE.Vector3(...STAR_POINTS[b]);
            const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([A, B]), new THREE.LineBasicMaterial({ color: completed ? 0xa7fff2 : 0x81b7dd, transparent: true, opacity: .91 }));
            this.lineGroup.add(line);
            const arc = new THREE.Mesh(new THREE.TubeGeometry(new THREE.LineCurve3(A, B), 4, completed ? .13 : .08, 6), new THREE.MeshBasicMaterial({ color: completed ? 0x8fece6 : 0x6c9ecf, transparent: true, opacity: .43 }));
            this.lineGroup.add(arc);
        }
        for (const star of this.starmesh) {
            const m = star.material;
            m.color.set(s.constellations.some(e => e.includes(`${star.userData.starId}`)) ? 0xeaffdc : 0xd3f4e5);
        }
        this.glowingGarden.intensity = 5 + constellationPower(s) * 1.9 + (lightAligned(s) ? 1.1 : 0) + causalStage(s) * .6;
    }
    update(dt, elapsed, s, camera) {
        this.rig.update(dt, elapsed, s, camera);
        this.vistas.update(elapsed, s, camera);
        this.rig.stars.opacity = clamp(this.rig.stars.opacity + .35, .3, 1);
        this.water.material.uniforms.uTime.value = elapsed;
        this.water.material.uniforms.uRain.value = stormIntensity(s.weather);
        this.water.material.uniforms.uDay.value = .3 + .32 * Math.sin((s.time / 24) * Math.PI * 2);
        const motion = s.reducedMotion ? .16 : 1;
        this.returnGate.rotation.y = Math.sin(elapsed * .11) * .035 * motion;
        this.sanctuaries.forEach((site, i) => {
            const target = gardenAccess(s, i) && (i !== 2 || gravityAligned(s)) ? 1 : 0;
            site.progress += (target - site.progress) * Math.min(1, dt * (s.reducedMotion ? 2.2 : 1.1));
            site.root.position.y = site.target.y - 36 * (1 - site.progress);
            site.root.rotation.y = Math.sin(elapsed * .045 + i) * .025 * motion;
            site.root.visible = site.progress > .015;
            site.bridge.visible = site.progress > .73;
            site.bridge.material.opacity = Math.max(0, (site.progress - .73) / .27) * .91;
        });
        for (let i = 0; i < this.islands.length; i++) {
            const o = this.islands[i];
            o.position.y = Math.sin(elapsed * .21 + i * 1.5) * .55 * motion + ([0, 8, 9, 15, 16, 19, 25, 27, 35, 32][i]);
            o.rotation.y = Math.sin(elapsed * .06 + i) * .008 * motion;
        }
        this.celestialBodies.forEach((g, i) => {
            const angle = elapsed * (.018 + i * .003) * motion + i * 1.8;
            g.position.set(Math.cos(angle) * (85 + i * 16), 56 + i * 11 + Math.sin(elapsed * .09 + i) * 6, Math.sin(angle) * (81 + i * 20) - 120);
            g.rotation.z = Math.sin(elapsed * .09 + i) * .06;
            g.children[1].rotation.y += dt * .11 * motion;
        });
        this.mechanism.forEach((m, i) => { m.rotation.y += dt * (i % 2 ? .012 : -.018) * motion; });
        this.breathingOrnaments.forEach((m, i) => {
            m.rotation.y += dt * (i % 2 === 0 ? .024 : -.013) * motion;
            m.position.y += (Math.sin(elapsed * .12 + i) - Math.sin((elapsed - dt) * .12 + i)) * .14 * motion;
        });
        this.worldGlows.forEach(mesh => mesh.lookAt(camera.position));
        this.nebulaVeils.forEach((mesh, i) => {
            mesh.lookAt(camera.position);
            const shader = mesh.material;
            shader.uniforms.uOpacity.value = .035 + .018 * Math.sin(elapsed * .11 + i);
        });
        this.starmesh.forEach((m, i) => m.scale.setScalar(1 + Math.sin(elapsed * 1.6 + i * 2.31) * .095));
        this.flora.forEach((g, i) => {
            g.userData.blossoms.rotation.y = elapsed * .012 * motion + i * .24;
        });
        const orientation = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
        if (s.gardenVisited && orientation.y > .16 && s.reveal < 1) {
            s.reveal = clamp(s.reveal + dt * (s.reducedMotion ? .12 : .045), 0, 1);
        }
        const eased = s.reveal * s.reveal * (3 - 2 * s.reveal);
        this.signatureObjects.forEach(({ object, from, to }, i) => {
            object.position.copy(from).lerp(to, eased);
            object.rotation.y = lerp(i * .23, i / 14 * TAU, eased) + elapsed * .003 * motion;
            const m = object.children[2].material;
            m.emissiveIntensity = .36 + eased * .81 + constellationPower(s) * .13;
        });
        this.signature.position.y = Math.sin(elapsed * .065) * .6;
        this.dust.update(elapsed, s.gravity[0] * .35);
    }
    // Height sampling provides a constrained ground walk without adding an expensive physics engine.
    walkHeightAt(x, z) {
        for (let i = 0; i < this.islands.length; i++) {
            const group = this.islands[i];
            if (Math.hypot(x - group.position.x, z - group.position.z) < this.islandRadii[i] * .79)
                return group.position.y + 3.2;
        }
        for (let i = 0; i < this.sanctuaries.length; i++) {
            const site = this.sanctuaries[i];
            if (site.progress > .93 && Math.hypot(x - site.target.x, z - site.target.z) < (10 + i * 2) * .75)
                return site.root.position.y + 3.2;
        }
        const curves = [...this.authoredBridges, ...this.sanctuaryBridges.filter((_, i) => this.sanctuaries[i].progress > .97)];
        let closest = Infinity, altitude = null;
        for (const c of curves)
            for (let step = 0; step <= 24; step++) {
                const p = c.getPoint(step / 24);
                const d = Math.hypot(x - p.x, z - p.z);
                if (d < closest) {
                    closest = d;
                    altitude = p.y;
                }
            }
        return closest < 2.3 ? altitude : null;
    }
    dispose() { disposeScene(this.scene); }
}
