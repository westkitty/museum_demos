/** One action abstraction for keyboard and touch; no auto-repeat jump events. */
export class InputController {
 constructor(root=document){
   this.root=root;this.left=false;this.right=false;this.jumpHeld=false;this.pendingJump=false;this.justPause=false;
   this.keys=new Set();this.touch=new Map();this.disposed=false;
   this.down=e=>{
     // Do not steal native keyboard activation or select navigation from focused UI.
     const target=e.target;
     if(target && (['BUTTON','INPUT','SELECT','TEXTAREA'].includes(target.tagName) ||
         target.closest?.('button, input, select, textarea, [contenteditable], [role="button"], [role="checkbox"], [role="combobox"]')))return;
     const k=e.code; if(['ArrowLeft','ArrowRight','Space','ArrowUp','KeyA','KeyD','KeyW','KeyP','Escape'].includes(k))e.preventDefault();
     if(!this.keys.has(k)&&['Space','ArrowUp','KeyW'].includes(k))this.pendingJump=true;
     if(!this.keys.has(k)&&['Escape','KeyP'].includes(k))this.justPause=true;
     this.keys.add(k);this.refresh();
   };
   this.up=e=>{this.keys.delete(e.code);this.refresh();};
   this.blur=()=>this.clear();
   this.visibility=()=>{if(document.hidden)this.clear();};
   root.addEventListener('keydown',this.down);root.addEventListener('keyup',this.up);
   window.addEventListener('blur',this.blur);document.addEventListener('visibilitychange',this.visibility);
   this.touchButtons=[];
   for(const button of document.querySelectorAll('[data-action]')){
     const action=button.dataset.action;
     const begin=e=>{e.preventDefault();button.setPointerCapture?.(e.pointerId);this.touch.set(e.pointerId,action);if(action==='jump')this.pendingJump=true;this.refresh();};
     const end=e=>{this.touch.delete(e.pointerId);this.refresh();};
     button.addEventListener('pointerdown',begin);button.addEventListener('pointerup',end);button.addEventListener('pointercancel',end);button.addEventListener('lostpointercapture',end);
     this.touchButtons.push({button,begin,end});
   }
 }
 refresh(){const a=[...this.touch.values()];this.left=this.keys.has('ArrowLeft')||this.keys.has('KeyA')||a.includes('left');this.right=this.keys.has('ArrowRight')||this.keys.has('KeyD')||a.includes('right');this.jumpHeld=this.keys.has('Space')||this.keys.has('ArrowUp')||this.keys.has('KeyW')||a.includes('jump');}
 consume(){const frame={axis:Number(this.right)-Number(this.left),jumpHeld:this.jumpHeld,jumpPressed:this.pendingJump,pause:this.justPause};this.pendingJump=false;this.justPause=false;return frame;}
 clear(){this.keys.clear();this.touch.clear();this.pendingJump=false;this.justPause=false;this.refresh();}
 dispose(){if(this.disposed)return;this.disposed=true;this.root.removeEventListener('keydown',this.down);this.root.removeEventListener('keyup',this.up);window.removeEventListener('blur',this.blur);document.removeEventListener('visibilitychange',this.visibility);for(const b of this.touchButtons){b.button.removeEventListener('pointerdown',b.begin);for(const k of ['pointerup','pointercancel','lostpointercapture'])b.button.removeEventListener(k,b.end);}}
}
