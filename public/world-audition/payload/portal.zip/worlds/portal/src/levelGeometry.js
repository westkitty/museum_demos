export const PLAYER_RADIUS = 0.33;
const wall = (minX, maxX, minZ, maxZ, maxY = 15) => ({ minX, maxX, minZ, maxZ, maxY });
function pedestal(x, z, size = 0.79) {
    return wall(x - size, x + size, z - size, z + size, 1.5);
}
export function collisionsFor(chamber) {
    const blocks = [
        wall(-17.05, -15.65, -19.2, 19.2), wall(15.65, 17.05, -19.2, 19.2),
        wall(-17.1, 17.1, -19.65, -18.35), wall(-17.1, 17.1, 18.35, 19.65)
    ];
    const holes = chamber === 3
        ? [[-9.85, -6.15], [-2.15, 2.15], [6.15, 9.85]]
        : [[-9.85, -6.15], [6.15, 9.85]];
    let left = -16;
    for (const [a, b] of holes) {
        if (a > left)
            blocks.push(wall(left, a, -0.43, 0.43, 10.4));
        left = b;
    }
    if (left < 16)
        blocks.push(wall(left, 16, -0.43, 0.43, 10.4));
    // One collidable plane per fixed door, irrespective of fictional authority.
    blocks.push(wall(-9.73, -6.27, -0.39, 0.39, 6.2));
    blocks.push(wall(6.27, 9.73, -0.39, 0.39, 6.2));
    if (chamber === 3)
        blocks.push(wall(-1.995, 1.995, -0.39, 0.39, 6.2));
    // Decorative plinths are also solid, so physical movement matches the view.
    blocks.push(pedestal(-11, 10));
    if (chamber === 1) {
        blocks.push(pedestal(8, -15.6));
        blocks.push(wall(-3.8, -0.2, 9.2, 12.8, 5));
        blocks.push(wall(9.5, 14.5, -12.5, -7.5, 6));
    }
    if (chamber === 2) {
        blocks.push(pedestal(8, -9), pedestal(8, -15.6));
        blocks.push(wall(-4.0, 0.0, 10, 14, 6));
    }
    if (chamber === 3) {
        blocks.push(pedestal(0, 5), pedestal(8, -10), pedestal(8, -15.8));
        blocks.push(wall(-4.98, -1.02, 11.02, 14.98, 6));
        blocks.push(wall(9.66, 14.34, -13.34, -8.66, 6));
    }
    if (chamber < 3) {
        // Decorative exit gate occupies the wallward side of its control plinth.
        blocks.push(wall(5.78, 10.22, -17.65, -17.05, 5));
    }
    return blocks;
}
export function overlapsCircle(box, x, z, radius = PLAYER_RADIUS) {
    const nx = Math.max(box.minX, Math.min(x, box.maxX));
    const nz = Math.max(box.minZ, Math.min(z, box.maxZ));
    return (x - nx) ** 2 + (z - nz) ** 2 < radius * radius;
}
export function canStand(chamber, x, z) {
    return !collisionsFor(chamber).some(b => b.maxY >= PLAYER_RADIUS && overlapsCircle(b, x, z));
}
