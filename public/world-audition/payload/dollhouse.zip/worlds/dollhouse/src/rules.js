export const initialState = () => ({ entries: [{ id: 'R-018', text: 'The tiny brass door belongs to the east wall.', provenance: 'synthetic exhibit fixture', forgotten: true, marks: [] }], completed: { record: false, memory: false, door: false }, selected: 'continuity', carrying: false, doorPosition: 'floor', events: ['Exhibit initialized. All records are synthetic.'] });
export function act(s, task) {
    const entry = s.entries[0];
    if (task === 'record') {
        if (s.selected === 'moderation')
            return 'READ ONLY: Moderation can inspect the catalog, but cannot recover records.';
        if (s.selected !== 'continuity')
            return 'Companion cannot access the broader continuity index.';
        if (s.completed.record)
            return 'Record already recovered; its provenance remains visible.';
        entry.forgotten = false;
        s.completed.record = true;
        const msg = 'RECOVERED R-018 · source: synthetic exhibit fixture · recovery mark retained.';
        s.events.push(msg);
        return msg;
    }
    if (task === 'memory') {
        if (!s.completed.record)
            return 'Recover the missing record first.';
        if (s.selected === 'moderation')
            return 'READ ONLY: Moderation cannot modify memory.';
        if (s.selected !== 'companion')
            return 'Only Companion can append a provenance-bearing memory mark.';
        if (s.completed.memory)
            return 'The memory marker is already appended.';
        entry.marks.push('PINNED · appended by Companion · source R-018');
        s.completed.memory = true;
        const msg = 'APPENDED memory pin with provenance. Original record preserved.';
        s.events.push(msg);
        return msg;
    }
    if (!s.completed.memory)
        return 'Pin the recovered record before restoring the door.';
    if (s.selected !== 'continuity')
        return s.selected === 'moderation' ? 'READ ONLY: Moderation cannot authorize placement.' : 'Companion cannot authorize physical placement.';
    if (!s.carrying)
        return 'Pick up the toy door first.';
    s.carrying = false;
    s.doorPosition = 'frame';
    s.completed.door = true;
    const msg = 'DOOR RESTORED. The dollhouse bureaucracy has declared a national holiday.';
    s.events.push(msg);
    return msg;
}
export function pickup(s) { if (s.completed.door)
    return 'The door is already installed.'; if (s.carrying)
    return 'You are carrying the door.'; s.carrying = true; return 'Toy door picked up. Take it to the glowing frame.'; }
export function allDone(s) { return Object.values(s.completed).every(Boolean); }
