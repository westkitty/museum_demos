/** World-owned, deliberately sparse atmospheric landmarks. Their coordinates belong to
 * the existing geography, not the camera HUD. No textures or third-party dependencies. */
import * as THREE from 'three';
import { causalStage } from '../core/simulation.js';
import { clamp, heightAt, mulberry32, riverX, TAU } from '../core/math.js';
const PALETTES = [0xc7d9b4, 0x9ad9cb, 0xb1c2f0];
export class CinematicVistas {
    kind;
    time = { value: 0 };
    drift = { value: 0 };
    energy = { value: .3 };
    lowClouds = [];
    cloudAlpha = { value: 0 };
    astralRibbons = [];
    constructor(scene, kind, s) {
        this.kind = kind;
        const rng = mulberry32(7309 + kind * 103), count = s.quality === 'low' ? 84 : s.quality === 'medium' ? 210 : 340;
        const positions = new Float32Array(count * 3), phases = new Float32Array(count), sizes = new Float32Array(count);
        for (let i = 0; i < count; i++) {
            let x = 0, y = 0, z = 0;
            const phase = rng() * TAU, radial = rng();
            if (kind === 0) {
                const radius = 7 + radial * 31, angle = i * .184 + phase * .3;
                x = Math.cos(angle) * radius;
                z = Math.sin(angle) * radius;
                y = 6 + radial * 37 + Math.sin(angle * 2.4) * 3;
            }
            else if (kind === 1) {
                z = -74 + rng() * 132;
                x = riverX(z) + (rng() - .5) * 8.2;
                y = heightAt(x, z, s) + 1.2 + rng() * 3.5;
            }
            else {
                const along = i / count * TAU * 3.6 + phase * .22, range = 18 + rng() * 49;
                x = Math.cos(along) * range;
                z = -100 + Math.sin(along * .69) * 67;
                y = 30 + Math.sin(along) * 18 + rng() * 48;
            }
            positions.set([x, y, z], i * 3);
            phases[i] = phase;
            sizes[i] = .48 + rng() * .95;
        }
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
        geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
        const material = new THREE.ShaderMaterial({
            uniforms: { uTime: this.time, uDrift: this.drift, uEnergy: this.energy, uColor: { value: new THREE.Color(PALETTES[kind]) }, uKind: { value: kind } },
            vertexShader: `attribute float aPhase;attribute float aSize;
        uniform float uTime,uDrift,uEnergy,uKind;varying float vIntensity;
        void main(){
          vec3 p=position;
          float motion=uDrift;
          if(uKind<.5){p.y+=sin(uTime*.46+aPhase+p.x*.17)*.56*motion;}
          else if(uKind<1.5){p.x+=sin(uTime*.57+aPhase)*.35*motion;p.y+=sin(uTime*.78+aPhase)*.26*motion;}
          else{p.y+=sin(uTime*.39+aPhase+p.z*.018)*.91*motion;p.x+=cos(uTime*.34+aPhase)*1.2*motion;}
          vIntensity=(.55+.45*sin(uTime*.64+aPhase*2.))*uEnergy;
          vec4 mv=modelViewMatrix*vec4(p,1.);
          gl_Position=projectionMatrix*mv;
          gl_PointSize=clamp(aSize*135./max(1.,-mv.z),1.4,6.0);
        }`,
            fragmentShader: `uniform vec3 uColor;varying float vIntensity;
        void main(){float r=length(gl_PointCoord-.5)*2.;
          float halo=pow(max(0.,1.-smoothstep(.07,1.,r)),2.);
          gl_FragColor=vec4(uColor,halo*clamp(vIntensity,0.,.53));}`,
            transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false
        });
        const motes = new THREE.Points(geometry, material);
        motes.frustumCulled = false;
        motes.name = ['Clockwork dust', 'Silvercourse river glints', 'Astral filament dust'][kind];
        motes.userData.feature = 'cinematic-vista';
        scene.add(motes);
        if (kind === 1) {
            // Shallow valley banks with soft elliptical density, ordered between terrain and mountain.
            // The planes use depth test, so they do not draw through nearby trees or hills.
            const fogMaterial = new THREE.ShaderMaterial({
                uniforms: { uAlpha: this.cloudAlpha, uTime: this.time, uColor: { value: new THREE.Color(0xa2c4c1) } },
                vertexShader: `varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
                fragmentShader: `uniform float uAlpha,uTime;uniform vec3 uColor;varying vec2 vUv;
          void main(){vec2 p=vUv-.5;
            float r=length(vec2(p.x*.91,p.y*2.4));
            float fine=sin(p.x*18.+uTime*.12)*sin(p.y*13.-uTime*.06)*.025;
            float mask=1.-smoothstep(.12,.52,r+fine);
            gl_FragColor=vec4(uColor,mask*uAlpha);}`,
                transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false
            });
            const banks = s.quality === 'low' ? 3 : s.quality === 'medium' ? 6 : 9;
            for (let i = 0; i < banks; i++) {
                const z = -62 + i * (98 / Math.max(1, banks - 1)), x = riverX(z) + (i % 2 ? -12 : 11);
                const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), fogMaterial);
                m.position.set(x, heightAt(x, z, s) + 6, z);
                m.scale.set(30 + i % 3 * 14, 7 + i % 2 * 4, 1);
                m.userData.feature = 'valley-mist';
                m.renderOrder = 1;
                this.lowClouds.push(m);
                scene.add(m);
            }
        }
        if (kind === 2) {
            // Three distant luminous arcs guide the eye toward the garden's actual orrery.
            for (let layer = 0; layer < 3; layer++) {
                const points = [];
                for (let i = 0; i <= 96; i++) {
                    const t = i / 96, a = t * TAU * (1.35 + layer * .3), r = 38 + layer * 20 + t * 27;
                    points.push(new THREE.Vector3(Math.cos(a) * r, 40 + Math.sin(a * 1.3) * 12 + layer * 16, -130 + Math.sin(a) * r * .63));
                }
                const curve = new THREE.CatmullRomCurve3(points);
                const path = new THREE.Line(new THREE.BufferGeometry().setFromPoints(curve.getPoints(128)), new THREE.LineBasicMaterial({ color: 0x8eb4c7, transparent: true, opacity: .17, depthWrite: false, blending: THREE.AdditiveBlending }));
                path.name = 'Astral latitude ' + (layer + 1);
                path.userData.feature = 'astral-latitude';
                this.astralRibbons.push(path);
                scene.add(path);
            }
        }
    }
    update(elapsed, s, camera) {
        const night = clamp(1 - (Math.sin((s.time - 6) * Math.PI / 12) + .15) * 2, 0, 1);
        const storm = s.weather === 'Thunderstorm' ? 1 : s.weather === 'Rain' ? .7 : s.weather === 'Fog' ? .5 : 0;
        const stage = causalStage(s);
        this.time.value = elapsed;
        this.drift.value = s.reducedMotion ? .12 : 1;
        this.energy.value = this.kind === 0 ? .16 + stage * .11 + night * .15 :
            this.kind === 1 ? .08 + night * .32 + (s.weather === 'Clear' ? .13 : 0) : .17 + stage * .11;
        this.cloudAlpha.value = .09 + storm * .08 + (s.weather === 'Fog' ? .14 : 0) + (night ? .04 : 0);
        for (const bank of this.lowClouds)
            bank.quaternion.copy(camera.quaternion);
        this.astralRibbons.forEach((r, i) => {
            const material = r.material;
            material.opacity = .10 + stage * .035;
            r.position.y = Math.sin(elapsed * .055 + i) * .35 * (s.reducedMotion ? .06 : 1);
        });
    }
}
