(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))i(n);new MutationObserver(n=>{for(const s of n)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function e(n){const s={};return n.integrity&&(s.integrity=n.integrity),n.referrerPolicy&&(s.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?s.credentials="include":n.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(n){if(n.ep)return;n.ep=!0;const s=e(n);fetch(n.href,s)}})();const Xa="187",Qn={ROTATE:0,DOLLY:1,PAN:2},on={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},du=0,Pl=1,fu=2,Ls=1,pu=2,As=3,cn=0,Je=1,ae=2,ts=0,Yi=1,Ne=2,Ll=3,Dl=4,mu=5,Jn=100,gu=101,vu=102,_u=103,xu=104,yu=200,Mu=201,Su=202,wu=203,th=204,eh=205,bu=206,Eu=207,Tu=208,Au=209,Ru=210,Cu=211,Pu=212,Lu=213,Du=214,Ko=0,Zo=1,Jo=2,Fs=3,jo=4,Qo=5,ta=6,ea=7,ih=0,Iu=1,Nu=2,$i=0,nh=1,sh=2,rh=3,qa=4,oh=5,ah=6,lh=7,ch=300,ns=301,Os=302,Nr=303,co=304,En=1e3,Ii=1001,ia=1002,Xe=1003,Uu=1004,Qs=1005,Ze=1006,ho=1007,an=1008,pi=1009,hh=1010,uh=1011,Bs=1012,Ya=1013,Fi=1014,Ei=1015,Oi=1016,$a=1017,Ka=1018,ss=1020,dh=35902,fh=35899,ph=1021,mh=1022,Ni=1023,hn=1026,ln=1027,Za=1028,Ja=1029,Tn=1030,ja=1031,Qa=1033,Ur=33776,Fr=33777,Or=33778,Br=33779,na=35840,sa=35841,ra=35842,oa=35843,aa=36196,la=37492,ca=37496,ha=37488,ua=37489,Gr=37490,da=37491,fa=37808,pa=37809,ma=37810,ga=37811,va=37812,_a=37813,xa=37814,ya=37815,Ma=37816,Sa=37817,wa=37818,ba=37819,Ea=37820,Ta=37821,Aa=36492,Ra=36494,Ca=36495,Pa=36283,La=36284,Hr=36285,Da=36286,Fu=3200,Ia=0,Ou=1,qi="",ni="srgb",Vr="srgb-linear",Wr="linear",he="srgb",uo=7680,Bu=519,zu=512,ku=513,Gu=514,gh=515,Hu=516,Vu=517,vh=518,_h=519,xh=35044,Il="300 es",Ti=2e3,zs=2001;function Wu(r){for(let t=r.length-1;t>=0;--t)if(r[t]>=65535)return!0;return!1}function Xr(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function Xu(){const r=Xr("canvas");return r.style.display="block",r}const Nl={};function qr(...r){const t="THREE."+r.shift();console.log(t,...r)}function yh(r){const t=r[0];if(typeof t=="string"&&t.startsWith("TSL:")){const e=r[1];e&&e.isStackTrace?r[0]+=" "+e.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function Bt(...r){r=yh(r);const t="THREE."+r.shift();{const e=r[0];e&&e.isStackTrace?console.warn(e.getError(t)):console.warn(t,...r)}}function se(...r){r=yh(r);const t="THREE."+r.shift();{const e=r[0];e&&e.isStackTrace?console.error(e.getError(t)):console.error(t,...r)}}function es(...r){const t=r.join(" ");t in Nl||(Nl[t]=!0,Bt(...r))}function qu(r,t,e){return new Promise(function(i,n){function s(){switch(r.clientWaitSync(t,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:n();break;case r.TIMEOUT_EXPIRED:setTimeout(s,e);break;default:i()}}setTimeout(s,e)})}const Yu={[Ko]:Ko,[Jo]:ta,[jo]:jo,[Fs]:Qo,[Zo]:Zo,[ta]:Jo,[ea]:ea,[Qo]:Fs};class fn{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[t]===void 0&&(i[t]=[]),i[t].indexOf(e)===-1&&i[t].push(e)}hasEventListener(t,e){const i=this._listeners;return i===void 0?!1:i[t]!==void 0&&i[t].indexOf(e)!==-1}removeEventListener(t,e){const i=this._listeners;if(i===void 0)return;const n=i[t];if(n!==void 0){const s=n.indexOf(e);s!==-1&&n.splice(s,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const i=e[t.type];if(i!==void 0){t.target=this;const n=i.slice(0);for(let s=0,o=n.length;s<o;s++)n[s].call(this,t);t.target=null}}}const $e=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],zr=Math.PI/180,Yr=180/Math.PI;function pn(){const r=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return($e[r&255]+$e[r>>8&255]+$e[r>>16&255]+$e[r>>24&255]+"-"+$e[t&255]+$e[t>>8&255]+"-"+$e[t>>16&15|64]+$e[t>>24&255]+"-"+$e[e&63|128]+$e[e>>8&255]+"-"+$e[e>>16&255]+$e[e>>24&255]+$e[i&255]+$e[i>>8&255]+$e[i>>16&255]+$e[i>>24&255]).toLowerCase()}function Xt(r,t,e){return Math.max(t,Math.min(e,r))}function $u(r,t){return(r%t+t)%t}function fo(r,t,e){return(1-e)*r+e*t}function Ku(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Qr(r){switch(r.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function Mh(r,t){if(t.constructor===Float32Array)return r;const e=Qr(t);if(e===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(r/e,-1)}function Sh(r,t){if(t.constructor===Float32Array)return r;const e=Qr(t);if(e===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(r*e)}const Zu={DEG2RAD:zr},ml=class ml{constructor(t=0,e=0){this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,i=this.y,n=t.elements;return this.x=n[0]*e+n[3]*i+n[6],this.y=n[1]*e+n[4]*i+n[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this}clampLength(t,e){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Xt(i,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const i=this.dot(t)/e;return Math.acos(Xt(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,i=this.y-t.y;return e*e+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const i=Math.cos(e),n=Math.sin(e),s=this.x-t.x,o=this.y-t.y;return this.x=s*i-o*n+t.x,this.y=s*n+o*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};ml.prototype.isVector2=!0;let Q=ml;class un{constructor(t=0,e=0,i=0,n=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=n}static slerpFlat(t,e,i,n,s,o,a){let l=i[n+0],c=i[n+1],h=i[n+2],u=i[n+3],d=s[o+0],f=s[o+1],p=s[o+2],v=s[o+3];if(u!==v||l!==d||c!==f||h!==p){let m=l*d+c*f+h*p+u*v;m<0&&(d=-d,f=-f,p=-p,v=-v,m=-m);let g=1-a;if(m<.9995){const _=Math.acos(m),M=Math.sin(_);g=Math.sin(g*_)/M,a=Math.sin(a*_)/M,l=l*g+d*a,c=c*g+f*a,h=h*g+p*a,u=u*g+v*a}else{l=l*g+d*a,c=c*g+f*a,h=h*g+p*a,u=u*g+v*a;const _=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=_,c*=_,h*=_,u*=_}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,i,n,s,o){const a=i[n],l=i[n+1],c=i[n+2],h=i[n+3],u=s[o],d=s[o+1],f=s[o+2],p=s[o+3];return t[e]=a*p+h*u+l*f-c*d,t[e+1]=l*p+h*d+c*u-a*f,t[e+2]=c*p+h*f+a*d-l*u,t[e+3]=h*p-a*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,i,n){return this._x=t,this._y=e,this._z=i,this._w=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const i=t._x,n=t._y,s=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(i/2),h=a(n/2),u=a(s/2),d=l(i/2),f=l(n/2),p=l(s/2);switch(o){case"XYZ":this._x=d*h*u+c*f*p,this._y=c*f*u-d*h*p,this._z=c*h*p+d*f*u,this._w=c*h*u-d*f*p;break;case"YXZ":this._x=d*h*u+c*f*p,this._y=c*f*u-d*h*p,this._z=c*h*p-d*f*u,this._w=c*h*u+d*f*p;break;case"ZXY":this._x=d*h*u-c*f*p,this._y=c*f*u+d*h*p,this._z=c*h*p+d*f*u,this._w=c*h*u-d*f*p;break;case"ZYX":this._x=d*h*u-c*f*p,this._y=c*f*u+d*h*p,this._z=c*h*p-d*f*u,this._w=c*h*u+d*f*p;break;case"YZX":this._x=d*h*u+c*f*p,this._y=c*f*u+d*h*p,this._z=c*h*p-d*f*u,this._w=c*h*u-d*f*p;break;case"XZY":this._x=d*h*u-c*f*p,this._y=c*f*u-d*h*p,this._z=c*h*p+d*f*u,this._w=c*h*u+d*f*p;break;default:Bt("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const i=e/2,n=Math.sin(i);return this._x=t.x*n,this._y=t.y*n,this._z=t.z*n,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,i=e[0],n=e[4],s=e[8],o=e[1],a=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=i+a+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(s-c)*f,this._z=(o-n)*f}else if(i>a&&i>u){const f=2*Math.sqrt(1+i-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(n+o)/f,this._z=(s+c)/f}else if(a>u){const f=2*Math.sqrt(1+a-i-u);this._w=(s-c)/f,this._x=(n+o)/f,this._y=.25*f,this._z=(l+h)/f}else{const f=2*Math.sqrt(1+u-i-a);this._w=(o-n)/f,this._x=(s+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let i=t.dot(e)+1;return i<1e-8?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=i):(this._x=0,this._y=-t.z,this._z=t.y,this._w=i)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=i),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Xt(this.dot(t),-1,1)))}rotateTowards(t,e){const i=this.angleTo(t);if(i===0)return this;const n=Math.min(1,e/i);return this.slerp(t,n),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const i=t._x,n=t._y,s=t._z,o=t._w,a=e._x,l=e._y,c=e._z,h=e._w;return this._x=i*h+o*a+n*c-s*l,this._y=n*h+o*l+s*a-i*c,this._z=s*h+o*c+i*l-n*a,this._w=o*h-i*a-n*l-s*c,this._onChangeCallback(),this}slerp(t,e){let i=t._x,n=t._y,s=t._z,o=t._w,a=this.dot(t);a<0&&(i=-i,n=-n,s=-s,o=-o,a=-a);let l=1-e;if(a<.9995){const c=Math.acos(a),h=Math.sin(c);l=Math.sin(l*c)/h,e=Math.sin(e*c)/h,this._x=this._x*l+i*e,this._y=this._y*l+n*e,this._z=this._z*l+s*e,this._w=this._w*l+o*e,this._onChangeCallback()}else this._x=this._x*l+i*e,this._y=this._y*l+n*e,this._z=this._z*l+s*e,this._w=this._w*l+o*e,this.normalize();return this}slerpQuaternions(t,e,i){return this.copy(t).slerp(e,i)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),i=Math.random(),n=Math.sqrt(1-i),s=Math.sqrt(i);return this.set(n*Math.sin(t),n*Math.cos(t),s*Math.sin(e),s*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const gl=class gl{constructor(t=0,e=0,i=0){this.x=t,this.y=e,this.z=i}set(t,e,i){return i===void 0&&(i=this.z),this.x=t,this.y=e,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Ul.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Ul.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,i=this.y,n=this.z,s=t.elements;return this.x=s[0]*e+s[3]*i+s[6]*n,this.y=s[1]*e+s[4]*i+s[7]*n,this.z=s[2]*e+s[5]*i+s[8]*n,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,i=this.y,n=this.z,s=t.elements,o=1/(s[3]*e+s[7]*i+s[11]*n+s[15]);return this.x=(s[0]*e+s[4]*i+s[8]*n+s[12])*o,this.y=(s[1]*e+s[5]*i+s[9]*n+s[13])*o,this.z=(s[2]*e+s[6]*i+s[10]*n+s[14])*o,this}applyQuaternion(t){const e=this.x,i=this.y,n=this.z,s=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*n-a*i),h=2*(a*e-s*n),u=2*(s*i-o*e);return this.x=e+l*c+o*u-a*h,this.y=i+l*h+a*c-s*u,this.z=n+l*u+s*h-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,i=this.y,n=this.z,s=t.elements;return this.x=s[0]*e+s[4]*i+s[8]*n,this.y=s[1]*e+s[5]*i+s[9]*n,this.z=s[2]*e+s[6]*i+s[10]*n,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this.z=Xt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this.z=Xt(this.z,t,e),this}clampLength(t,e){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Xt(i,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const i=t.x,n=t.y,s=t.z,o=e.x,a=e.y,l=e.z;return this.x=n*l-s*a,this.y=s*o-i*l,this.z=i*a-n*o,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const i=t.dot(this)/e;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return po.copy(this).projectOnVector(t),this.sub(po)}reflect(t){return this.sub(po.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const i=this.dot(t)/e;return Math.acos(Xt(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,i=this.y-t.y,n=this.z-t.z;return e*e+i*i+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,i){const n=Math.sin(e)*t;return this.x=n*Math.sin(i),this.y=Math.cos(e)*t,this.z=n*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,i){return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),n=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=i,this.z=n,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,i=Math.sqrt(1-e*e);return this.x=i*Math.cos(t),this.y=e,this.z=i*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};gl.prototype.isVector3=!0;let R=gl;const po=new R,Ul=new un,vl=class vl{constructor(t,e,i,n,s,o,a,l,c){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,i,n,s,o,a,l,c)}set(t,e,i,n,s,o,a,l,c){const h=this.elements;return h[0]=t,h[1]=n,h[2]=a,h[3]=e,h[4]=s,h[5]=l,h[6]=i,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this}extractBasis(t,e,i){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const i=t.elements,n=e.elements,s=this.elements,o=i[0],a=i[3],l=i[6],c=i[1],h=i[4],u=i[7],d=i[2],f=i[5],p=i[8],v=n[0],m=n[3],g=n[6],_=n[1],M=n[4],y=n[7],E=n[2],T=n[5],x=n[8];return s[0]=o*v+a*_+l*E,s[3]=o*m+a*M+l*T,s[6]=o*g+a*y+l*x,s[1]=c*v+h*_+u*E,s[4]=c*m+h*M+u*T,s[7]=c*g+h*y+u*x,s[2]=d*v+f*_+p*E,s[5]=d*m+f*M+p*T,s[8]=d*g+f*y+p*x,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],i=t[1],n=t[2],s=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8];return e*o*h-e*a*c-i*s*h+i*a*l+n*s*c-n*o*l}invert(){const t=this.elements,e=t[0],i=t[1],n=t[2],s=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=h*o-a*c,d=a*l-h*s,f=c*s-o*l,p=e*u+i*d+n*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/p;return t[0]=u*v,t[1]=(n*c-h*i)*v,t[2]=(a*i-n*o)*v,t[3]=d*v,t[4]=(h*e-n*l)*v,t[5]=(n*s-a*e)*v,t[6]=f*v,t[7]=(i*l-c*e)*v,t[8]=(o*e-i*s)*v,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,i,n,s,o,a){const l=Math.cos(s),c=Math.sin(s);return this.set(i*l,i*c,-i*(l*o+c*a)+o+t,-n*c,n*l,-n*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return es("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(mo.makeScale(t,e)),this}rotate(t){return es("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(mo.makeRotation(-t)),this}translate(t,e){return es("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(mo.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,i,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,i=t.elements;for(let n=0;n<9;n++)if(e[n]!==i[n])return!1;return!0}fromArray(t,e=0){for(let i=0;i<9;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){const i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}};vl.prototype.isMatrix3=!0;let kt=vl;const mo=new kt,Fl=new kt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Ol=new kt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Ju(){const r={enabled:!0,workingColorSpace:Vr,spaces:{},convert:function(n,s,o){return this.enabled===!1||s===o||!s||!o||(this.spaces[s].transfer===he&&(n.r=Ki(n.r),n.g=Ki(n.g),n.b=Ki(n.b)),this.spaces[s].primaries!==this.spaces[o].primaries&&(n.applyMatrix3(this.spaces[s].toXYZ),n.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===he&&(n.r=is(n.r),n.g=is(n.g),n.b=is(n.b))),n},workingToColorSpace:function(n,s){return this.convert(n,this.workingColorSpace,s)},colorSpaceToWorking:function(n,s){return this.convert(n,s,this.workingColorSpace)},getPrimaries:function(n){return this.spaces[n].primaries},getTransfer:function(n){return n===qi?Wr:this.spaces[n].transfer},getToneMappingMode:function(n){return this.spaces[n].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(n,s=this.workingColorSpace){return n.fromArray(this.spaces[s].luminanceCoefficients)},define:function(n){Object.assign(this.spaces,n)},_getMatrix:function(n,s,o){return n.copy(this.spaces[o].fromXYZ).multiply(this.spaces[s].toXYZ)},_getDrawingBufferColorSpace:function(n){return this.spaces[n].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(n=this.workingColorSpace){return this.spaces[n].workingColorSpaceConfig.unpackColorSpace}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],i=[.3127,.329];return r.define({[Vr]:{primaries:t,whitePoint:i,transfer:Wr,toXYZ:Fl,fromXYZ:Ol,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:ni},outputColorSpaceConfig:{drawingBufferColorSpace:ni}},[ni]:{primaries:t,whitePoint:i,transfer:he,toXYZ:Fl,fromXYZ:Ol,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:ni}}}),r}const Qt=Ju();function Ki(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function is(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Dn;class ju{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let i;if(t instanceof HTMLCanvasElement)i=t;else{Dn===void 0&&(Dn=Xr("canvas")),Dn.width=t.width,Dn.height=t.height;const n=Dn.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),i=Dn}return i.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Xr("canvas");e.width=t.width,e.height=t.height;const i=e.getContext("2d");i.drawImage(t,0,0,t.width,t.height);const n=i.getImageData(0,0,t.width,t.height),s=n.data;for(let o=0;o<s.length;o++)s[o]=Ki(s[o]/255)*255;return i.putImageData(n,0,0),e}else if(t.data){const e=t.data.slice(0);for(let i=0;i<e.length;i++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[i]=Math.floor(Ki(e[i]/255)*255):e[i]=Ki(e[i]);return{data:e,width:t.width,height:t.height}}else return Bt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Qu=0;class tl{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Qu++}),this.uuid=pn(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):typeof VideoFrame<"u"&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):e!==null?t.set(e.width||0,e.height||0,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const i={uuid:this.uuid,url:""},n=this.data;if(n!==null){let s;if(Array.isArray(n)){s=[];for(let o=0,a=n.length;o<a;o++)n[o].isDataTexture?s.push(go(n[o].image)):s.push(go(n[o]))}else s=go(n);i.url=s}return e||(t.images[this.uuid]=i),i}}function go(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?ju.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(Bt("Texture: Unable to serialize Texture."),{})}let td=0;const vo=new R;class je extends fn{constructor(t=je.DEFAULT_IMAGE,e=je.DEFAULT_MAPPING,i=Ii,n=Ii,s=Ze,o=an,a=Ni,l=pi,c=je.DEFAULT_ANISOTROPY,h=qi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:td++}),this.uuid=pn(),this.name="",this.source=new tl(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=n,this.magFilter=s,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Q(0,0),this.repeat=new Q(1,1),this.center=new Q(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new kt,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(vo).x}get height(){return this.source.getSize(vo).y}get depth(){return this.source.getSize(vo).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.mipmapsAutoUpdate=t.mipmapsAutoUpdate,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isPMREMTexture=t.isPMREMTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const i=t[e];if(i===void 0){Bt(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const n=this[e];if(n===void 0){Bt(`Texture.setValues(): property '${e}' does not exist.`);continue}n&&i&&n.isVector2&&i.isVector2||n&&i&&n.isVector3&&i.isVector3||n&&i&&n.isMatrix3&&i.isMatrix3?n.copy(i):this[e]=i}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==ch)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case En:t.x=t.x-Math.floor(t.x);break;case Ii:t.x=t.x<0?0:1;break;case ia:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case En:t.y=t.y-Math.floor(t.y);break;case Ii:t.y=t.y<0?0:1;break;case ia:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}je.DEFAULT_IMAGE=null;je.DEFAULT_MAPPING=ch;je.DEFAULT_ANISOTROPY=1;const _l=class _l{constructor(t=0,e=0,i=0,n=1){this.x=t,this.y=e,this.z=i,this.w=n}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,i,n){return this.x=t,this.y=e,this.z=i,this.w=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,i=this.y,n=this.z,s=this.w,o=t.elements;return this.x=o[0]*e+o[4]*i+o[8]*n+o[12]*s,this.y=o[1]*e+o[5]*i+o[9]*n+o[13]*s,this.z=o[2]*e+o[6]*i+o[10]*n+o[14]*s,this.w=o[3]*e+o[7]*i+o[11]*n+o[15]*s,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,i,n,s;const l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],p=l[9],v=l[2],m=l[6],g=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-v)<.01&&Math.abs(p-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+v)<.1&&Math.abs(p+m)<.1&&Math.abs(c+f+g-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const M=(c+1)/2,y=(f+1)/2,E=(g+1)/2,T=(h+d)/4,x=(u+v)/4,w=(p+m)/4;return M>y&&M>E?M<.01?(i=0,n=.707106781,s=.707106781):(i=Math.sqrt(M),n=T/i,s=x/i):y>E?y<.01?(i=.707106781,n=0,s=.707106781):(n=Math.sqrt(y),i=T/n,s=w/n):E<.01?(i=.707106781,n=.707106781,s=0):(s=Math.sqrt(E),i=x/s,n=w/s),this.set(i,n,s,e),this}let _=Math.sqrt((m-p)*(m-p)+(u-v)*(u-v)+(d-h)*(d-h));return Math.abs(_)<.001&&(_=1),this.x=(m-p)/_,this.y=(u-v)/_,this.z=(d-h)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this.z=Xt(this.z,t.z,e.z),this.w=Xt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this.z=Xt(this.z,t,e),this.w=Xt(this.w,t,e),this}clampLength(t,e){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Xt(i,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};_l.prototype.isVector4=!0;let Me=_l;class ed extends fn{constructor(t=1,e=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ze,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},i),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=i.depth,this.scissor=new Me(0,0,t,e),this.scissorTest=!1,this.viewport=new Me(0,0,t,e),this.textures=[];const n=i.count;for(let s=0;s<n;s++)this.textures[s]=new je({width:t,height:e,depth:i.depth}),this.textures[s].isRenderTargetTexture=!0,this.textures[s].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveColorBuffer=i.resolveColorBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.storeMultisampledColorBuffer=i.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=i.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=i.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview,this.useArrayDepthTexture=i.useArrayDepthTexture}_setTextureOptions(t={}){const e={minFilter:Ze,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.mipmapsAutoUpdate!==void 0&&(e.mipmapsAutoUpdate=t.mipmapsAutoUpdate),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,i=1){if(this.width!==t||this.height!==e||this.depth!==i){this.width=t,this.height=e,this.depth=i;for(let n=0,s=this.textures.length;n<s;n++)this.textures[n].image.width=t,this.textures[n].image.height=e,this.textures[n].image.depth=i,this.textures[n].isData3DTexture!==!0&&(this.textures[n].isArrayTexture=this.textures[n].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,i=t.textures.length;e<i;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const n=Object.assign({},t.textures[e].image);this.textures[e].source=new tl(n)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){const e=t.depthTexture.clone();e.renderTarget=null,this.depthTexture=e}else this.depthTexture=t.depthTexture;else this.depthTexture=null;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ai extends ed{constructor(t=1,e=1,i={}){super(t,e,i),this.isWebGLRenderTarget=!0}}class wh extends je{constructor(t=null,e=1,i=1,n=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:n},this.magFilter=Xe,this.minFilter=Xe,this.wrapR=Ii,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class id extends je{constructor(t=null,e=1,i=1,n=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:n},this.magFilter=Xe,this.minFilter=Xe,this.wrapR=Ii,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}}const jr=class jr{constructor(t,e,i,n,s,o,a,l,c,h,u,d,f,p,v,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,i,n,s,o,a,l,c,h,u,d,f,p,v,m)}set(t,e,i,n,s,o,a,l,c,h,u,d,f,p,v,m){const g=this.elements;return g[0]=t,g[4]=e,g[8]=i,g[12]=n,g[1]=s,g[5]=o,g[9]=a,g[13]=l,g[2]=c,g[6]=h,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=v,g[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new jr().fromArray(this.elements)}copy(t){const e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this}copyPosition(t){const e=this.elements,i=t.elements;return e[12]=i[12],e[13]=i[13],e[14]=i[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,i){return this.determinantAffine()===0?(t.set(1,0,0),e.set(0,1,0),i.set(0,0,1),this):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this)}makeBasis(t,e,i){return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();const e=this.elements,i=t.elements,n=1/In.setFromMatrixColumn(t,0).length(),s=1/In.setFromMatrixColumn(t,1).length(),o=1/In.setFromMatrixColumn(t,2).length();return e[0]=i[0]*n,e[1]=i[1]*n,e[2]=i[2]*n,e[3]=0,e[4]=i[4]*s,e[5]=i[5]*s,e[6]=i[6]*s,e[7]=0,e[8]=i[8]*o,e[9]=i[9]*o,e[10]=i[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,i=t.x,n=t.y,s=t.z,o=Math.cos(i),a=Math.sin(i),l=Math.cos(n),c=Math.sin(n),h=Math.cos(s),u=Math.sin(s);if(t.order==="XYZ"){const d=o*h,f=o*u,p=a*h,v=a*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+p*c,e[5]=d-v*c,e[9]=-a*l,e[2]=v-d*c,e[6]=p+f*c,e[10]=o*l}else if(t.order==="YXZ"){const d=l*h,f=l*u,p=c*h,v=c*u;e[0]=d+v*a,e[4]=p*a-f,e[8]=o*c,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=f*a-p,e[6]=v+d*a,e[10]=o*l}else if(t.order==="ZXY"){const d=l*h,f=l*u,p=c*h,v=c*u;e[0]=d-v*a,e[4]=-o*u,e[8]=p+f*a,e[1]=f+p*a,e[5]=o*h,e[9]=v-d*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){const d=o*h,f=o*u,p=a*h,v=a*u;e[0]=l*h,e[4]=p*c-f,e[8]=d*c+v,e[1]=l*u,e[5]=v*c+d,e[9]=f*c-p,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){const d=o*l,f=o*c,p=a*l,v=a*c;e[0]=l*h,e[4]=v-d*u,e[8]=p*u+f,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-c*h,e[6]=f*u+p,e[10]=d-v*u}else if(t.order==="XZY"){const d=o*l,f=o*c,p=a*l,v=a*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+v,e[5]=o*h,e[9]=f*u-p,e[2]=p*u-f,e[6]=a*h,e[10]=v*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(nd,t,sd)}lookAt(t,e,i){const n=this.elements;return hi.subVectors(t,e),hi.lengthSq()===0&&(hi.z=1),hi.normalize(),Qi.crossVectors(i,hi),Qi.lengthSq()===0&&(Math.abs(i.z)===1?hi.x+=1e-4:hi.z+=1e-4,hi.normalize(),Qi.crossVectors(i,hi)),Qi.normalize(),tr.crossVectors(hi,Qi),n[0]=Qi.x,n[4]=tr.x,n[8]=hi.x,n[1]=Qi.y,n[5]=tr.y,n[9]=hi.y,n[2]=Qi.z,n[6]=tr.z,n[10]=hi.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const i=t.elements,n=e.elements,s=this.elements,o=i[0],a=i[4],l=i[8],c=i[12],h=i[1],u=i[5],d=i[9],f=i[13],p=i[2],v=i[6],m=i[10],g=i[14],_=i[3],M=i[7],y=i[11],E=i[15],T=n[0],x=n[4],w=n[8],P=n[12],C=n[1],U=n[5],B=n[9],V=n[13],D=n[2],H=n[6],Y=n[10],F=n[14],et=n[3],X=n[7],tt=n[11],it=n[15];return s[0]=o*T+a*C+l*D+c*et,s[4]=o*x+a*U+l*H+c*X,s[8]=o*w+a*B+l*Y+c*tt,s[12]=o*P+a*V+l*F+c*it,s[1]=h*T+u*C+d*D+f*et,s[5]=h*x+u*U+d*H+f*X,s[9]=h*w+u*B+d*Y+f*tt,s[13]=h*P+u*V+d*F+f*it,s[2]=p*T+v*C+m*D+g*et,s[6]=p*x+v*U+m*H+g*X,s[10]=p*w+v*B+m*Y+g*tt,s[14]=p*P+v*V+m*F+g*it,s[3]=_*T+M*C+y*D+E*et,s[7]=_*x+M*U+y*H+E*X,s[11]=_*w+M*B+y*Y+E*tt,s[15]=_*P+M*V+y*F+E*it,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],i=t[4],n=t[8],s=t[12],o=t[1],a=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],p=t[3],v=t[7],m=t[11],g=t[15],_=l*f-c*d,M=a*f-c*u,y=a*d-l*u,E=o*f-c*h,T=o*d-l*h,x=o*u-a*h;return e*(v*_-m*M+g*y)-i*(p*_-m*E+g*T)+n*(p*M-v*E+g*x)-s*(p*y-v*T+m*x)}determinantAffine(){const t=this.elements,e=t[0],i=t[4],n=t[8],s=t[1],o=t[5],a=t[9],l=t[2],c=t[6],h=t[10];return e*(o*h-a*c)-i*(s*h-a*l)+n*(s*c-o*l)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,i){const n=this.elements;return t.isVector3?(n[12]=t.x,n[13]=t.y,n[14]=t.z):(n[12]=t,n[13]=e,n[14]=i),this}invert(){const t=this.elements,e=t[0],i=t[1],n=t[2],s=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],p=t[12],v=t[13],m=t[14],g=t[15],_=e*a-i*o,M=e*l-n*o,y=e*c-s*o,E=i*l-n*a,T=i*c-s*a,x=n*c-s*l,w=h*v-u*p,P=h*m-d*p,C=h*g-f*p,U=u*m-d*v,B=u*g-f*v,V=d*g-f*m,D=_*V-M*B+y*U+E*C-T*P+x*w;if(D===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const H=1/D;return t[0]=(a*V-l*B+c*U)*H,t[1]=(n*B-i*V-s*U)*H,t[2]=(v*x-m*T+g*E)*H,t[3]=(d*T-u*x-f*E)*H,t[4]=(l*C-o*V-c*P)*H,t[5]=(e*V-n*C+s*P)*H,t[6]=(m*y-p*x-g*M)*H,t[7]=(h*x-d*y+f*M)*H,t[8]=(o*B-a*C+c*w)*H,t[9]=(i*C-e*B-s*w)*H,t[10]=(p*T-v*y+g*_)*H,t[11]=(u*y-h*T-f*_)*H,t[12]=(a*P-o*U-l*w)*H,t[13]=(e*U-i*P+n*w)*H,t[14]=(v*M-p*E-m*_)*H,t[15]=(h*E-u*M+d*_)*H,this}scale(t){const e=this.elements,i=t.x,n=t.y,s=t.z;return e[0]*=i,e[4]*=n,e[8]*=s,e[1]*=i,e[5]*=n,e[9]*=s,e[2]*=i,e[6]*=n,e[10]*=s,e[3]*=i,e[7]*=n,e[11]*=s,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],n=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,i,n))}makeTranslation(t,e,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),i=Math.sin(t);return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const i=Math.cos(e),n=Math.sin(e),s=1-i,o=t.x,a=t.y,l=t.z,c=s*o,h=s*a;return this.set(c*o+i,c*a-n*l,c*l+n*a,0,c*a+n*l,h*a+i,h*l-n*o,0,c*l-n*a,h*l+n*o,s*l*l+i,0,0,0,0,1),this}makeScale(t,e,i){return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,e,i,n,s,o){return this.set(1,i,s,0,t,1,o,0,e,n,1,0,0,0,0,1),this}compose(t,e,i){const n=this.elements,s=e._x,o=e._y,a=e._z,l=e._w,c=s+s,h=o+o,u=a+a,d=s*c,f=s*h,p=s*u,v=o*h,m=o*u,g=a*u,_=l*c,M=l*h,y=l*u,E=i.x,T=i.y,x=i.z;return n[0]=(1-(v+g))*E,n[1]=(f+y)*E,n[2]=(p-M)*E,n[3]=0,n[4]=(f-y)*T,n[5]=(1-(d+g))*T,n[6]=(m+_)*T,n[7]=0,n[8]=(p+M)*x,n[9]=(m-_)*x,n[10]=(1-(d+v))*x,n[11]=0,n[12]=t.x,n[13]=t.y,n[14]=t.z,n[15]=1,this}decompose(t,e,i){const n=this.elements;t.x=n[12],t.y=n[13],t.z=n[14];const s=this.determinantAffine();if(s===0)return i.set(1,1,1),e.identity(),this;let o=In.set(n[0],n[1],n[2]).length();const a=In.set(n[4],n[5],n[6]).length(),l=In.set(n[8],n[9],n[10]).length();s<0&&(o=-o),Si.copy(this);const c=1/o,h=1/a,u=1/l;return Si.elements[0]*=c,Si.elements[1]*=c,Si.elements[2]*=c,Si.elements[4]*=h,Si.elements[5]*=h,Si.elements[6]*=h,Si.elements[8]*=u,Si.elements[9]*=u,Si.elements[10]*=u,e.setFromRotationMatrix(Si),i.x=o,i.y=a,i.z=l,this}makePerspective(t,e,i,n,s,o,a=Ti,l=!1){const c=this.elements,h=2*s/(e-t),u=2*s/(i-n),d=(e+t)/(e-t),f=(i+n)/(i-n);let p,v;if(l)p=s/(o-s),v=o*s/(o-s);else if(a===Ti)p=-(o+s)/(o-s),v=-2*o*s/(o-s);else if(a===zs)p=-o/(o-s),v=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=v,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,i,n,s,o,a=Ti,l=!1){const c=this.elements,h=2/(e-t),u=2/(i-n),d=-(e+t)/(e-t),f=-(i+n)/(i-n);let p,v;if(l)p=1/(o-s),v=o/(o-s);else if(a===Ti)p=-2/(o-s),v=-(o+s)/(o-s);else if(a===zs)p=-1/(o-s),v=-s/(o-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=v,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,i=t.elements;for(let n=0;n<16;n++)if(e[n]!==i[n])return!1;return!0}fromArray(t,e=0){for(let i=0;i<16;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){const i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t}};jr.prototype.isMatrix4=!0;let te=jr;const In=new R,Si=new te,nd=new R(0,0,0),sd=new R(1,1,1),Qi=new R,tr=new R,hi=new R,Bl=new te,zl=new un;class dn{constructor(t=0,e=0,i=0,n=dn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=n}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,i,n=this._order){return this._x=t,this._y=e,this._z=i,this._order=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,i=!0){const n=t.elements,s=n[0],o=n[4],a=n[8],l=n[1],c=n[5],h=n[9],u=n[2],d=n[6],f=n[10];switch(e){case"XYZ":this._y=Math.asin(Xt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Xt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Xt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Xt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Xt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Xt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,s)):(this._x=Math.atan2(-h,f),this._y=0);break;default:Bt("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,i){return Bl.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Bl,e,i)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return zl.setFromEuler(this),this.setFromQuaternion(zl,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}dn.DEFAULT_ORDER="XYZ";class el{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let rd=0;const kl=new R,Nn=new un,ki=new te,er=new R,ps=new R,od=new R,ad=new un,Gl=new R(1,0,0),Hl=new R(0,1,0),Vl=new R(0,0,1),Wl={type:"added"},ld={type:"removed"},Un={type:"childadded",child:null},_o={type:"childremoved",child:null};class ue extends fn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:rd++}),this.uuid=pn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ue.DEFAULT_UP.clone();const t=new R,e=new dn,i=new un,n=new R(1,1,1);function s(){i.setFromEuler(e,!1)}function o(){e.setFromQuaternion(i,void 0,!1)}e._onChange(s),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:n},modelViewMatrix:{value:new te},normalMatrix:{value:new kt}}),this.matrix=new te,this.matrixWorld=new te,this.matrixAutoUpdate=ue.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ue.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new el,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Nn.setFromAxisAngle(t,e),this.quaternion.multiply(Nn),this}rotateOnWorldAxis(t,e){return Nn.setFromAxisAngle(t,e),this.quaternion.premultiply(Nn),this}rotateX(t){return this.rotateOnAxis(Gl,t)}rotateY(t){return this.rotateOnAxis(Hl,t)}rotateZ(t){return this.rotateOnAxis(Vl,t)}translateOnAxis(t,e){return kl.copy(t).applyQuaternion(this.quaternion),this.position.add(kl.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Gl,t)}translateY(t){return this.translateOnAxis(Hl,t)}translateZ(t){return this.translateOnAxis(Vl,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(ki.copy(this.matrixWorld).invert())}lookAt(t,e,i){t.isVector3?er.copy(t):er.set(t,e,i);const n=this.parent;this.updateWorldMatrix(!0,!1),ps.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ki.lookAt(ps,er,this.up):ki.lookAt(er,ps,this.up),this.quaternion.setFromRotationMatrix(ki),n&&(ki.extractRotation(n.matrixWorld),Nn.setFromRotationMatrix(ki),this.quaternion.premultiply(Nn.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(se("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Wl),Un.child=t,this.dispatchEvent(Un),Un.child=null):se("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(ld),_o.child=t,this.dispatchEvent(_o),_o.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),ki.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),ki.multiply(t.parent.matrixWorld)),t.applyMatrix4(ki),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Wl),Un.child=t,this.dispatchEvent(Un),Un.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let i=0,n=this.children.length;i<n;i++){const o=this.children[i].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,i=[]){this[t]===e&&i.push(this);const n=this.children;for(let s=0,o=n.length;s<o;s++)n[s].getObjectsByProperty(t,e,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ps,t,od),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ps,ad,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(t){t(this);const e=this.children;for(let i=0,n=e.length;i<n;i++)e[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let i=0,n=e.length;i<n;i++)e[i].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const e=t.x,i=t.y,n=t.z,s=this.matrix.elements;s[12]+=e-s[0]*e-s[4]*i-s[8]*n,s[13]+=i-s[1]*e-s[5]*i-s[9]*n,s[14]+=n-s[2]*e-s[6]*i-s[10]*n}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let i=0,n=e.length;i<n;i++)e[i].updateMatrixWorld(t)}updateWorldMatrix(t,e,i=!1){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||i)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,i=!0),e===!0){const s=this.children;for(let o=0,a=s.length;o<a;o++)s[o].updateWorldMatrix(!1,!0,i)}}toJSON(t){const e=t===void 0||typeof t=="string",i={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const n={};n.uuid=this.uuid,n.type=this.type,n.name=this.name,n.castShadow=this.castShadow,n.receiveShadow=this.receiveShadow,n.visible=this.visible,n.frustumCulled=this.frustumCulled,n.renderOrder=this.renderOrder,n.static=this.static,n.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(n.userData=this.userData),n.layers=this.layers.mask,n.matrix=this.matrix.toArray(),n.up=this.up.toArray(),this.pivot!==null&&(n.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(n.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(n.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(n.type="InstancedMesh",n.count=this.count,n.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(n.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(n.type="BatchedMesh",n.perObjectFrustumCulled=this.perObjectFrustumCulled,n.sortObjects=this.sortObjects,n.drawRanges=this._drawRanges,n.reservedRanges=this._reservedRanges,n.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),n.instanceInfo=this._instanceInfo.map(a=>({...a})),n.availableInstanceIds=this._availableInstanceIds.slice(),n.availableGeometryIds=this._availableGeometryIds.slice(),n.nextIndexStart=this._nextIndexStart,n.nextVertexStart=this._nextVertexStart,n.geometryCount=this._geometryCount,n.maxInstanceCount=this._maxInstanceCount,n.maxVertexCount=this._maxVertexCount,n.maxIndexCount=this._maxIndexCount,n.geometryInitialized=this._geometryInitialized,n.matricesTexture=this._matricesTexture.toJSON(t),n.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(n.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(n.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(n.boundingBox=this.boundingBox.toJSON()));function s(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?n.background=this.background.toJSON():this.background.isTexture&&(n.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(n.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){n.geometry=s(t.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];s(t.shapes,u)}else s(t.shapes,l)}}if(this.isSkinnedMesh&&(n.bindMode=this.bindMode,n.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(t.skeletons,this.skeleton),n.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(s(t.materials,this.material[l]));n.material=a}else n.material=s(t.materials,this.material);if(this.children.length>0){n.children=[];for(let a=0;a<this.children.length;a++)n.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){n.animations=[];for(let a=0;a<this.animations.length;a++){const l=this.animations[a];n.animations.push(s(t.animations,l))}}if(e){const a=o(t.geometries),l=o(t.materials),c=o(t.textures),h=o(t.images),u=o(t.shapes),d=o(t.skeletons),f=o(t.animations),p=o(t.nodes);a.length>0&&(i.geometries=a),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),d.length>0&&(i.skeletons=d),f.length>0&&(i.animations=f),p.length>0&&(i.nodes=p)}return i.object=n,i;function o(a){const l=[];for(const c in a){const h=a[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let i=0;i<t.children.length;i++){const n=t.children[i];this.add(n.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}ue.DEFAULT_UP=new R(0,1,0);ue.DEFAULT_MATRIX_AUTO_UPDATE=!0;ue.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class gt extends ue{constructor(){super(),this.isGroup=!0,this.type="Group"}}const cd={type:"move"};class xo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new gt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new gt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new gt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const i of t.hand.values())this._getHandJoint(e,i)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,i){let n=null,s=null,o=null;const a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(const v of t.hand.values()){const m=e.getJointPose(v,i),g=this._getHandJoint(c,v);m!==null&&(g.matrix.fromArray(m.transform.matrix),g.matrix.decompose(g.position,g.quaternion,g.scale),g.matrixWorldNeedsUpdate=!0,g.jointRadius=m.radius),g.visible=m!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,p=.005;c.inputState.pinching&&d>f+p?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-p&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(s=e.getPose(t.gripSpace,i),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:t,target:this})));a!==null&&(n=e.getPose(t.targetRaySpace,i),n===null&&s!==null&&(n=s),n!==null&&(a.matrix.fromArray(n.transform.matrix),a.matrix.decompose(a.position,a.quaternion,a.scale),a.matrixWorldNeedsUpdate=!0,n.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(n.linearVelocity)):a.hasLinearVelocity=!1,n.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(n.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(cd)))}return a!==null&&(a.visible=n!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const i=new gt;i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)}return t.joints[e.jointName]}}const bh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},tn={h:0,s:0,l:0},ir={h:0,s:0,l:0};function yo(r,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?r+(t-r)*6*e:e<1/2?t:e<2/3?r+(t-r)*6*(2/3-e):r}class ct{constructor(t,e,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)}set(t,e,i){if(e===void 0&&i===void 0){const n=t;n&&n.isColor?this.copy(n):typeof n=="number"?this.setHex(n):typeof n=="string"&&this.setStyle(n)}else this.setRGB(t,e,i);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=ni){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Qt.colorSpaceToWorking(this,e),this}setRGB(t,e,i,n=Qt.workingColorSpace){return this.r=t,this.g=e,this.b=i,Qt.colorSpaceToWorking(this,n),this}setHSL(t,e,i,n=Qt.workingColorSpace){if(t=$u(t,1),e=Xt(e,0,1),i=Xt(i,0,1),e===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+e):i+e-i*e,o=2*i-s;this.r=yo(o,s,t+1/3),this.g=yo(o,s,t),this.b=yo(o,s,t-1/3)}return Qt.colorSpaceToWorking(this,n),this}setStyle(t,e=ni){function i(s){s!==void 0&&parseFloat(s)<1&&Bt("Color: Alpha component of "+t+" will be ignored.")}let n;if(n=/^(\w+)\(([^\)]*)\)/.exec(t)){let s;const o=n[1],a=n[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(a))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,e);if(s=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(a))return i(s[4]),this.setRGB(Math.min(100,parseFloat(s[1]))/100,Math.min(100,parseFloat(s[2]))/100,Math.min(100,parseFloat(s[3]))/100,e);break;case"hsl":case"hsla":if(s=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(a))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,e);break;default:Bt("Color: Unknown color model "+t)}}else if(n=/^\#([A-Fa-f\d]+)$/.exec(t)){const s=n[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(s,16),e);Bt("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=ni){const i=bh[t.toLowerCase()];return i!==void 0?this.setHex(i,e):Bt("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Ki(t.r),this.g=Ki(t.g),this.b=Ki(t.b),this}copyLinearToSRGB(t){return this.r=is(t.r),this.g=is(t.g),this.b=is(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=ni){return Qt.workingToColorSpace(Ke.copy(this),t),Math.round(Xt(Ke.r*255,0,255))*65536+Math.round(Xt(Ke.g*255,0,255))*256+Math.round(Xt(Ke.b*255,0,255))}getHexString(t=ni){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Qt.workingColorSpace){Qt.workingToColorSpace(Ke.copy(this),e);const i=Ke.r,n=Ke.g,s=Ke.b,o=Math.max(i,n,s),a=Math.min(i,n,s);let l,c;const h=(a+o)/2;if(a===o)l=0,c=0;else{const u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case i:l=(n-s)/u+(n<s?6:0);break;case n:l=(s-i)/u+2;break;case s:l=(i-n)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=Qt.workingColorSpace){return Qt.workingToColorSpace(Ke.copy(this),e),t.r=Ke.r,t.g=Ke.g,t.b=Ke.b,t}getStyle(t=ni){Qt.workingToColorSpace(Ke.copy(this),t);const e=Ke.r,i=Ke.g,n=Ke.b;return t!==ni?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${n.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(i*255)},${Math.round(n*255)})`}offsetHSL(t,e,i){return this.getHSL(tn),this.setHSL(tn.h+t,tn.s+e,tn.l+i)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,i){return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this}lerpHSL(t,e){this.getHSL(tn),t.getHSL(ir);const i=fo(tn.h,ir.h,e),n=fo(tn.s,ir.s,e),s=fo(tn.l,ir.l,e);return this.setHSL(i,n,s),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,i=this.g,n=this.b,s=t.elements;return this.r=s[0]*e+s[3]*i+s[6]*n,this.g=s[1]*e+s[4]*i+s[7]*n,this.b=s[2]*e+s[5]*i+s[8]*n,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ke=new ct;ct.NAMES=bh;class il{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new ct(t),this.density=e}clone(){return new il(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class $r extends ue{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new dn,this.environmentIntensity=1,this.environmentRotation=new dn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),this.background=t.background!==null?t.background.clone():null,this.environment=t.environment!==null?t.environment.clone():null,this.fog=t.fog!==null?t.fog.clone():null,this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),this.overrideMaterial=t.overrideMaterial!==null?t.overrideMaterial.clone():null,this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),e.object.backgroundBlurriness=this.backgroundBlurriness,e.object.backgroundIntensity=this.backgroundIntensity,e.object.backgroundRotation=this.backgroundRotation.toArray(),e.object.environmentIntensity=this.environmentIntensity,e.object.environmentRotation=this.environmentRotation.toArray(),e}}const wi=new R,Gi=new R,Mo=new R,Hi=new R,Fn=new R,On=new R,Xl=new R,So=new R,wo=new R,bo=new R,Eo=new Me,To=new Me,Ao=new Me;class yi{constructor(t=new R,e=new R,i=new R){this.a=t,this.b=e,this.c=i}static getNormal(t,e,i,n){n.subVectors(i,e),wi.subVectors(t,e),n.cross(wi);const s=n.lengthSq();return s>0?n.multiplyScalar(1/Math.sqrt(s)):n.set(0,0,0)}static getBarycoord(t,e,i,n,s){wi.subVectors(n,e),Gi.subVectors(i,e),Mo.subVectors(t,e);const o=wi.dot(wi),a=wi.dot(Gi),l=wi.dot(Mo),c=Gi.dot(Gi),h=Gi.dot(Mo),u=o*c-a*a;if(u===0)return s.set(0,0,0),null;const d=1/u,f=(c*l-a*h)*d,p=(o*h-a*l)*d;return s.set(1-f-p,p,f)}static containsPoint(t,e,i,n){return this.getBarycoord(t,e,i,n,Hi)===null?!1:Hi.x>=0&&Hi.y>=0&&Hi.x+Hi.y<=1}static getInterpolation(t,e,i,n,s,o,a,l){return this.getBarycoord(t,e,i,n,Hi)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,Hi.x),l.addScaledVector(o,Hi.y),l.addScaledVector(a,Hi.z),l)}static getInterpolatedAttribute(t,e,i,n,s,o){return Eo.setScalar(0),To.setScalar(0),Ao.setScalar(0),Eo.fromBufferAttribute(t,e),To.fromBufferAttribute(t,i),Ao.fromBufferAttribute(t,n),o.setScalar(0),o.addScaledVector(Eo,s.x),o.addScaledVector(To,s.y),o.addScaledVector(Ao,s.z),o}static isFrontFacing(t,e,i,n){return wi.subVectors(i,e),Gi.subVectors(t,e),wi.cross(Gi).dot(n)<0}set(t,e,i){return this.a.copy(t),this.b.copy(e),this.c.copy(i),this}setFromPointsAndIndices(t,e,i,n){return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[n]),this}setFromAttributeAndIndices(t,e,i,n){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,n),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return wi.subVectors(this.c,this.b),Gi.subVectors(this.a,this.b),wi.cross(Gi).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return yi.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return yi.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,i,n,s){return yi.getInterpolation(t,this.a,this.b,this.c,e,i,n,s)}containsPoint(t){return yi.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return yi.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const i=this.a,n=this.b,s=this.c;let o,a;Fn.subVectors(n,i),On.subVectors(s,i),So.subVectors(t,i);const l=Fn.dot(So),c=On.dot(So);if(l<=0&&c<=0)return e.copy(i);wo.subVectors(t,n);const h=Fn.dot(wo),u=On.dot(wo);if(h>=0&&u<=h)return e.copy(n);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0&&l-h>0)return o=l/(l-h),e.copy(i).addScaledVector(Fn,o);bo.subVectors(t,s);const f=Fn.dot(bo),p=On.dot(bo);if(p>=0&&f<=p)return e.copy(s);const v=f*c-l*p;if(v<=0&&c>=0&&p<=0)return a=c/(c-p),e.copy(i).addScaledVector(On,a);const m=h*p-f*u;if(m<=0&&u-h>=0&&f-p>=0)return Xl.subVectors(s,n),a=(u-h)/(u-h+(f-p)),e.copy(n).addScaledVector(Xl,a);const g=1/(m+v+d);return o=v*g,a=d*g,e.copy(i).addScaledVector(Fn,o).addScaledVector(On,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class Cn{constructor(t=new R(1/0,1/0,1/0),e=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e+=3)this.expandByPoint(bi.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,i=t.count;e<i;e++)this.expandByPoint(bi.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const i=bi.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(i),this.max.copy(t).add(i),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const i=t.geometry;if(i!==void 0){const s=i.getAttribute("position");if(e===!0&&s!==void 0&&t.isInstancedMesh!==!0&&t.isBatchedMesh!==!0)for(let o=0,a=s.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,bi):bi.fromBufferAttribute(s,o),bi.applyMatrix4(t.matrixWorld),this.expandByPoint(bi);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),nr.copy(t.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),nr.copy(i.boundingBox)),nr.applyMatrix4(t.matrixWorld),this.union(nr)}const n=t.children;for(let s=0,o=n.length;s<o;s++)this.expandByObject(n[s],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,bi),bi.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,i;return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(ms),sr.subVectors(this.max,ms),Bn.subVectors(t.a,ms),zn.subVectors(t.b,ms),kn.subVectors(t.c,ms),en.subVectors(zn,Bn),nn.subVectors(kn,zn),_n.subVectors(Bn,kn);let e=[0,-en.z,en.y,0,-nn.z,nn.y,0,-_n.z,_n.y,en.z,0,-en.x,nn.z,0,-nn.x,_n.z,0,-_n.x,-en.y,en.x,0,-nn.y,nn.x,0,-_n.y,_n.x,0];return!Ro(e,Bn,zn,kn,sr)||(e=[1,0,0,0,1,0,0,0,1],!Ro(e,Bn,zn,kn,sr))?!1:(rr.crossVectors(en,nn),e=[rr.x,rr.y,rr.z],Ro(e,Bn,zn,kn,sr))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,bi).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(bi).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Vi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Vi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Vi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Vi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Vi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Vi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Vi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Vi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Vi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Vi=[new R,new R,new R,new R,new R,new R,new R,new R],bi=new R,nr=new Cn,Bn=new R,zn=new R,kn=new R,en=new R,nn=new R,_n=new R,ms=new R,sr=new R,rr=new R,xn=new R;function Ro(r,t,e,i,n){for(let s=0,o=r.length-3;s<=o;s+=3){xn.fromArray(r,s);const a=n.x*Math.abs(xn.x)+n.y*Math.abs(xn.y)+n.z*Math.abs(xn.z),l=t.dot(xn),c=e.dot(xn),h=i.dot(xn);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}const Ce=new R,or=new Q;let hd=0;class ee extends fn{constructor(t,e,i=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:hd++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=i,this.usage=xh,this.updateRanges=[],this.gpuType=Ei,this.version=0,this._normalizationScale=t!==void 0?Qr(t):void 0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this._normalizationScale=t._normalizationScale,this}copyAt(t,e,i){t*=this.itemSize,i*=e.itemSize;for(let n=0,s=this.itemSize;n<s;n++)this.array[t+n]=e.array[i+n];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,i=this.count;e<i;e++)or.fromBufferAttribute(this,e),or.applyMatrix3(t),this.setXY(e,or.x,or.y);else if(this.itemSize===3)for(let e=0,i=this.count;e<i;e++)Ce.fromBufferAttribute(this,e),Ce.applyMatrix3(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}applyMatrix4(t){for(let e=0,i=this.count;e<i;e++)Ce.fromBufferAttribute(this,e),Ce.applyMatrix4(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)Ce.fromBufferAttribute(this,e),Ce.applyNormalMatrix(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)Ce.fromBufferAttribute(this,e),Ce.transformDirection(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let i=this.array[t*this.itemSize+e];return this.normalized&&(i=this._denormalize(i)),i}setComponent(t,e,i){return this.normalized&&(i=this._normalize(i)),this.array[t*this.itemSize+e]=i,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=this._denormalize(e)),e}setX(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=this._denormalize(e)),e}setY(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=this._denormalize(e)),e}setZ(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=this._denormalize(e)),e}setW(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,i){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),i=this._normalize(i)),this.array[t+0]=e,this.array[t+1]=i,this}setXYZ(t,e,i,n){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),i=this._normalize(i),n=this._normalize(n)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=n,this}setXYZW(t,e,i,n,s){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),i=this._normalize(i),n=this._normalize(n),s=this._normalize(s)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=n,this.array[t+3]=s,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(t){const e=this._normalizationScale;return e!==void 0?Math.max(t/e,-1):Mh(t,this.array)}_normalize(t){const e=this._normalizationScale;return e!==void 0?Math.round(t*e):Sh(t,this.array)}}class Eh extends ee{constructor(t,e,i){super(new Uint16Array(t),e,i)}}class Th extends ee{constructor(t,e,i){super(new Uint32Array(t),e,i)}}class Kt extends ee{constructor(t,e,i){super(new Float32Array(t),e,i)}}const ud=new Cn,gs=new R,Co=new R;class cs{constructor(t=new R,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const i=this.center;e!==void 0?i.copy(e):ud.setFromPoints(t).getCenter(i);let n=0;for(let s=0,o=t.length;s<o;s++)n=Math.max(n,i.distanceToSquared(t[s]));return this.radius=Math.sqrt(n),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const i=this.center.distanceToSquared(t);return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;gs.subVectors(t,this.center);const e=gs.lengthSq();if(e>this.radius*this.radius){const i=Math.sqrt(e),n=(i-this.radius)*.5;this.center.addScaledVector(gs,n/i),this.radius+=n}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Co.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(gs.copy(t.center).add(Co)),this.expandByPoint(gs.copy(t.center).sub(Co))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let dd=0;const xi=new te,Po=new ue,Gn=new R,ui=new Cn,vs=new Cn,ke=new R;class de extends fn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:dd++}),this.uuid=pn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Wu(t)?Th:Eh)(t,1):this.index=t,this}setIndirect(t,e=0){return this.indirect=t,this.indirectOffset=e,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,i=0){this.groups.push({start:t,count:e,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new kt().getNormalMatrix(t);i.applyNormalMatrix(s),i.needsUpdate=!0}const n=this.attributes.tangent;return n!==void 0&&(n.transformDirection(t),n.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return xi.makeRotationFromQuaternion(t),this.applyMatrix4(xi),this}rotateX(t){return xi.makeRotationX(t),this.applyMatrix4(xi),this}rotateY(t){return xi.makeRotationY(t),this.applyMatrix4(xi),this}rotateZ(t){return xi.makeRotationZ(t),this.applyMatrix4(xi),this}translate(t,e,i){return xi.makeTranslation(t,e,i),this.applyMatrix4(xi),this}scale(t,e,i){return xi.makeScale(t,e,i),this.applyMatrix4(xi),this}lookAt(t){return Po.lookAt(t),Po.updateMatrix(),this.applyMatrix4(Po.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Gn).negate(),this.translate(Gn.x,Gn.y,Gn.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const i=[];for(let n=0,s=t.length;n<s;n++){const o=t[n];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Kt(i,3))}else{const i=Math.min(t.length,e.count);for(let n=0;n<i;n++){const s=t[n];e.setXYZ(n,s.x,s.y,s.z||0)}t.length>e.count&&Bt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Cn);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){se("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let i=0,n=e.length;i<n;i++){const s=e[i];ui.setFromBufferAttribute(s),this.morphTargetsRelative?(ke.addVectors(this.boundingBox.min,ui.min),this.boundingBox.expandByPoint(ke),ke.addVectors(this.boundingBox.max,ui.max),this.boundingBox.expandByPoint(ke)):(this.boundingBox.expandByPoint(ui.min),this.boundingBox.expandByPoint(ui.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&se('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new cs);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){se("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new R,1/0);return}if(t){const i=this.boundingSphere.center;if(ui.setFromBufferAttribute(t),e)for(let s=0,o=e.length;s<o;s++){const a=e[s];vs.setFromBufferAttribute(a),this.morphTargetsRelative?(ke.addVectors(ui.min,vs.min),ui.expandByPoint(ke),ke.addVectors(ui.max,vs.max),ui.expandByPoint(ke)):(ui.expandByPoint(vs.min),ui.expandByPoint(vs.max))}ui.getCenter(i);let n=0;for(let s=0,o=t.count;s<o;s++)ke.fromBufferAttribute(t,s),n=Math.max(n,i.distanceToSquared(ke));if(e)for(let s=0,o=e.length;s<o;s++){const a=e[s],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)ke.fromBufferAttribute(a,c),l&&(Gn.fromBufferAttribute(t,c),ke.add(Gn)),n=Math.max(n,i.distanceToSquared(ke))}this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&se('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){se("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=e.position,n=e.normal,s=e.uv;let o=this.getAttribute("tangent");(o===void 0||o.count!==i.count)&&(o=new ee(new Float32Array(4*i.count),4),this.setAttribute("tangent",o));const a=[],l=[],c=new Uint8Array(i.count);for(let P=0;P<i.count;P++)a[P]=new R,l[P]=new R;const h=new R,u=new R,d=new R,f=new Q,p=new Q,v=new Q,m=new R,g=new R;function _(P,C,U){c[P]=c[C]=c[U]=1,h.fromBufferAttribute(i,P),u.fromBufferAttribute(i,C),d.fromBufferAttribute(i,U),f.fromBufferAttribute(s,P),p.fromBufferAttribute(s,C),v.fromBufferAttribute(s,U),u.sub(h),d.sub(h),p.sub(f),v.sub(f);const B=1/(p.x*v.y-v.x*p.y);isFinite(B)&&(m.copy(u).multiplyScalar(v.y).addScaledVector(d,-p.y).multiplyScalar(B),g.copy(d).multiplyScalar(p.x).addScaledVector(u,-v.x).multiplyScalar(B),a[P].add(m),a[C].add(m),a[U].add(m),l[P].add(g),l[C].add(g),l[U].add(g))}let M=this.groups;M.length===0&&(M=[{start:0,count:t.count}]);for(let P=0,C=M.length;P<C;++P){const U=M[P],B=U.start,V=U.count;for(let D=B,H=B+V;D<H;D+=3)_(t.getX(D+0),t.getX(D+1),t.getX(D+2))}const y=new R,E=new R,T=new R,x=new R;function w(P){T.fromBufferAttribute(n,P),x.copy(T);const C=a[P];y.copy(C),y.sub(T.multiplyScalar(T.dot(C))).normalize(),E.crossVectors(x,C);const B=E.dot(l[P])<0?-1:1;o.setXYZW(P,y.x,y.y,y.z,B)}for(let P=0,C=i.count;P<C;++P)c[P]&&w(P);this._transformed=!0}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let i=this.getAttribute("normal");if(i===void 0||i.count!==e.count)i=new ee(new Float32Array(e.count*3),3),this.setAttribute("normal",i);else for(let d=0,f=i.count;d<f;d++)i.setXYZ(d,0,0,0);const n=new R,s=new R,o=new R,a=new R,l=new R,c=new R,h=new R,u=new R;if(t)for(let d=0,f=t.count;d<f;d+=3){const p=t.getX(d+0),v=t.getX(d+1),m=t.getX(d+2);n.fromBufferAttribute(e,p),s.fromBufferAttribute(e,v),o.fromBufferAttribute(e,m),h.subVectors(o,s),u.subVectors(n,s),h.cross(u),a.fromBufferAttribute(i,p),l.fromBufferAttribute(i,v),c.fromBufferAttribute(i,m),a.add(h),l.add(h),c.add(h),i.setXYZ(p,a.x,a.y,a.z),i.setXYZ(v,l.x,l.y,l.z),i.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)n.fromBufferAttribute(e,d+0),s.fromBufferAttribute(e,d+1),o.fromBufferAttribute(e,d+2),h.subVectors(o,s),u.subVectors(n,s),h.cross(u),i.setXYZ(d+0,h.x,h.y,h.z),i.setXYZ(d+1,h.x,h.y,h.z),i.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,i=t.count;e<i;e++)ke.fromBufferAttribute(t,e),ke.normalize(),t.setXYZ(e,ke.x,ke.y,ke.z)}toNonIndexed(){function t(a,l){const c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h);let f=0,p=0;for(let v=0,m=l.length;v<m;v++){a.isInterleavedBufferAttribute?f=l[v]*a.data.stride+a.offset:f=l[v]*h;for(let g=0;g<h;g++)d[p++]=c[f++]}return new ee(d,h,u)}if(this.index===null)return Bt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new de,i=this.index.array,n=this.attributes;for(const a in n){const l=n[a],c=t(l,i);e.setAttribute(a,c)}const s=this.morphAttributes;for(const a in s){const l=[],c=s[a];for(let h=0,u=c.length;h<u;h++){const d=c[h],f=t(d,i);l.push(f)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,l=o.length;a<l;a++){const c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const i=this.attributes;for(const l in i){const c=i[l];t.data.attributes[l]=c.toJSON(t.data)}const n={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(n[l]=h,s=!0)}s&&(t.data.morphAttributes=n,t.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(t.data.boundingSphere=a.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const i=t.index;i!==null&&this.setIndex(i.clone());const n=t.attributes;for(const c in n){const h=n[c];this.setAttribute(c,h.clone(e))}const s=t.morphAttributes;for(const c in s){const h=[],u=s[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;const o=t.groups;for(let c=0,h=o.length;c<h;c++){const u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}const a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());const l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class fd{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=xh,this.updateRanges=[],this.version=0,this.uuid=pn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,i){t*=this.stride,i*=e.stride;for(let n=0,s=this.stride;n<s;n++)this.array[t+n]=e.array[i+n];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={});const e=ql(this.array);t.arrayBuffers[e]===void 0&&(t.arrayBuffers[e]=this.array.slice(0).buffer);const i=new this.array.constructor(t.arrayBuffers[e]),n=new this.constructor(i,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){t.arrayBuffers===void 0&&(t.arrayBuffers={});const e=ql(this.array);t.arrayBuffers[e]===void 0&&(t.arrayBuffers[e]=Array.from(new Uint32Array(this.array.slice(0).buffer)));const i={uuid:this.uuid,buffer:e,type:this.array.constructor.name,stride:this.stride};return i.usage=this.usage,i}}function ql(r){return r.buffer._uuid===void 0&&(r.buffer._uuid=pn()),r.byteOffset===0&&r.byteLength===r.buffer.byteLength?r.buffer._uuid:r.buffer._uuid+":"+r.byteOffset+":"+r.byteLength}const ei=new R;class Kr{constructor(t,e,i,n=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=n,this._normalizationScale=t!==void 0?Qr(t.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,i=this.data.count;e<i;e++)ei.fromBufferAttribute(this,e),ei.applyMatrix4(t),this.setXYZ(e,ei.x,ei.y,ei.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)ei.fromBufferAttribute(this,e),ei.applyNormalMatrix(t),this.setXYZ(e,ei.x,ei.y,ei.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)ei.fromBufferAttribute(this,e),ei.transformDirection(t),this.setXYZ(e,ei.x,ei.y,ei.z);return this}getComponent(t,e){let i=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(i=this._denormalize(i)),i}setComponent(t,e,i){return this.normalized&&(i=this._normalize(i)),this.data.array[t*this.data.stride+this.offset+e]=i,this}setX(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=this._denormalize(e)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=this._denormalize(e)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=this._denormalize(e)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=this._denormalize(e)),e}setXY(t,e,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),i=this._normalize(i)),this.data.array[t+0]=e,this.data.array[t+1]=i,this}setXYZ(t,e,i,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),i=this._normalize(i),n=this._normalize(n)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=n,this}setXYZW(t,e,i,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),i=this._normalize(i),n=this._normalize(n),s=this._normalize(s)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=n,this.data.array[t+3]=s,this}clone(t){if(t===void 0){qr("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let i=0;i<this.count;i++){const n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[n+s])}return new ee(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new Kr(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){qr("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let i=0;i<this.count;i++){const n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[n+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}_denormalize(t){const e=this._normalizationScale;return e!==void 0?Math.max(t/e,-1):Mh(t,this.data.array)}_normalize(t){const e=this._normalizationScale;return e!==void 0?Math.round(t*e):Sh(t,this.data.array)}}const Lo=new R,pd=new R,md=new kt;class Xi{constructor(t=new R(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,i,n){return this.normal.set(t,e,i),this.constant=n,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,i){const n=Lo.subVectors(i,e).cross(pd.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(n,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e,i=!0){const n=t.delta(Lo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const o=-(t.start.dot(this.normal)+this.constant)/s;return i===!0&&(o<0||o>1)?null:e.copy(t.start).addScaledVector(n,o)}intersectsLine(t){const e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);return e<0&&i>0||i<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const i=e||md.getNormalMatrix(t),n=this.coplanarPoint(Lo).applyMatrix4(t),s=this.normal.applyMatrix3(i).normalize();return this.constant=-n.dot(s),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}}let gd=0;class Pn extends fn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:gd++}),this.uuid=pn(),this.name="",this.type="Material",this.blending=Yi,this.side=cn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=th,this.blendDst=eh,this.blendEquation=Jn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ct(0,0,0),this.blendAlpha=0,this.depthFunc=Fs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Bu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=uo,this.stencilZFail=uo,this.stencilZPass=uo,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const i=t[e];if(i===void 0){Bt(`Material: parameter '${e}' has value of undefined.`);continue}const n=this[e];if(n===void 0){Bt(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}n&&n.isColor?n.set(i):n&&n.isVector2&&i&&i.isVector2||n&&n.isEuler&&i&&i.isEuler||n&&n.isVector3&&i&&i.isVector3?n.copy(i):this[e]=i}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,i.blending=this.blending,i.side=this.side,i.shadowSide=this.shadowSide,i.vertexColors=this.vertexColors,i.opacity=this.opacity,i.transparent=this.transparent,i.blendSrc=this.blendSrc,i.blendDst=this.blendDst,i.blendEquation=this.blendEquation,i.blendSrcAlpha=this.blendSrcAlpha,i.blendDstAlpha=this.blendDstAlpha,i.blendEquationAlpha=this.blendEquationAlpha,i.blendColor=this.blendColor.getHex(),i.blendAlpha=this.blendAlpha,i.depthFunc=this.depthFunc,i.depthTest=this.depthTest,i.depthWrite=this.depthWrite,i.colorWrite=this.colorWrite,i.clipIntersection=this.clipIntersection,i.clipShadows=this.clipShadows,i.stencilWriteMask=this.stencilWriteMask,i.stencilFunc=this.stencilFunc,i.stencilRef=this.stencilRef,i.stencilFuncMask=this.stencilFuncMask,i.stencilFail=this.stencilFail,i.stencilZFail=this.stencilZFail,i.stencilZPass=this.stencilZPass,i.stencilWrite=this.stencilWrite,i.polygonOffset=this.polygonOffset,i.polygonOffsetFactor=this.polygonOffsetFactor,i.polygonOffsetUnits=this.polygonOffsetUnits,i.dithering=this.dithering,i.alphaTest=this.alphaTest,i.alphaHash=this.alphaHash,i.alphaToCoverage=this.alphaToCoverage,i.premultipliedAlpha=this.premultipliedAlpha,i.forceSinglePass=this.forceSinglePass,i.allowOverride=this.allowOverride,i.visible=this.visible,i.toneMapped=this.toneMapped,i.name=this.name,this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(i.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(i.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(t).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(i.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(i.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(i.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(i.clippingPlanes=this.clippingPlanes.map(s=>s.toJSON())),this.rotation!==void 0&&(i.rotation=this.rotation),this.depthPacking!==void 0&&(i.depthPacking=this.depthPacking),this.linewidth!==void 0&&(i.linewidth=this.linewidth),this.linecap!==void 0&&(i.linecap=this.linecap),this.linejoin!==void 0&&(i.linejoin=this.linejoin),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.wireframe!==void 0&&(i.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(i.flatShading=this.flatShading),this.fog!==void 0&&(i.fog=this.fog),Object.keys(this.userData).length>0&&(i.userData=this.userData);function n(s){const o=[];for(const a in s){const l=s[a];delete l.metadata,o.push(l)}return o}if(e){const s=n(t.textures),o=n(t.images);s.length>0&&(i.textures=s),o.length>0&&(i.images=o)}return i}fromJSON(t,e){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new ct().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.diffuseRoughness!==void 0&&(this.diffuseRoughness=t.diffuseRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=t.iridescenceThicknessMinimum),t.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=t.iridescenceThicknessMaximum),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=t.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=t.iridescenceThicknessRange[1]),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(i=>new Xi().fromJSON(i))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=e[t.map]||null),t.matcap!==void 0&&(this.matcap=e[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=e[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=e[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=e[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let i=t.normalScale;Array.isArray(i)===!1&&(i=[i,i]),this.normalScale=new Q().fromArray(i)}return t.displacementMap!==void 0&&(this.displacementMap=e[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=e[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=e[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=e[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=e[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=e[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=e[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=e[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=e[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=e[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=e[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=e[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=e[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=e[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Q().fromArray(t.clearcoatNormalScale)),t.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=e[t.diffuseRoughnessMap]||null),t.iridescenceMap!==void 0&&(this.iridescenceMap=e[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=e[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=e[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=e[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=e[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=e[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=e[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let i=null;if(e!==null){const n=e.length;i=new Array(n);for(let s=0;s!==n;++s)i[s]=e[s].clone()}return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class nl extends Pn{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new ct(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let Hn;const _s=new R,Vn=new R,Wn=new R,Xn=new Q,xs=new Q,Ah=new te,ar=new R,ys=new R,lr=new R,Yl=new Q,Do=new Q,$l=new Q;class Rh extends ue{constructor(t=new nl){if(super(),this.isSprite=!0,this.type="Sprite",Hn===void 0){Hn=new de;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new fd(e,5);Hn.setIndex([0,1,2,0,2,3]),Hn.setAttribute("position",new Kr(i,3,0,!1)),Hn.setAttribute("uv",new Kr(i,2,3,!1))}this.geometry=Hn,this.material=t,this.center=new Q(.5,.5),this.count=1}intersectsFrustum(t){return t.intersectsSprite(this)}raycast(t,e){t.camera===null&&se('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Vn.setFromMatrixScale(this.matrixWorld),Ah.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Wn.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Vn.multiplyScalar(-Wn.z);const i=this.material.rotation;let n,s;i!==0&&(s=Math.cos(i),n=Math.sin(i));const o=this.center;cr(ar.set(-.5,-.5,0),Wn,o,Vn,n,s),cr(ys.set(.5,-.5,0),Wn,o,Vn,n,s),cr(lr.set(.5,.5,0),Wn,o,Vn,n,s),Yl.set(0,0),Do.set(1,0),$l.set(1,1);let a=t.ray.intersectTriangle(ar,ys,lr,!1,_s);if(a===null&&(cr(ys.set(-.5,.5,0),Wn,o,Vn,n,s),Do.set(0,1),a=t.ray.intersectTriangle(ar,lr,ys,!1,_s),a===null))return;const l=t.ray.origin.distanceTo(_s);l<t.near||l>t.far||e.push({distance:l,point:_s.clone(),uv:yi.getInterpolation(_s,ar,ys,lr,Yl,Do,$l,new Q),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}toJSON(t){const e=super.toJSON(t);return e.object.center=this.center.toArray(),e}}function cr(r,t,e,i,n,s){Xn.subVectors(r,e).addScalar(.5).multiply(i),n!==void 0?(xs.x=s*Xn.x-n*Xn.y,xs.y=n*Xn.x+s*Xn.y):xs.copy(Xn),r.copy(t),r.x+=xs.x,r.y+=xs.y,r.applyMatrix4(Ah)}const Wi=new R,Io=new R,hr=new R,ur=new R;class to{constructor(t=new R,e=new R(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Wi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const i=e.dot(this.direction);return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=Wi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Wi.copy(this.origin).addScaledVector(this.direction,e),Wi.distanceToSquared(t))}distanceSqToSegment(t,e,i,n){Io.copy(t).add(e).multiplyScalar(.5),hr.copy(e).sub(t).normalize(),ur.copy(this.origin).sub(Io);const s=t.distanceTo(e)*.5,o=-this.direction.dot(hr),a=ur.dot(this.direction),l=-ur.dot(hr),c=ur.lengthSq(),h=Math.abs(1-o*o);let u,d,f,p;if(h>0)if(u=o*l-a,d=o*a-l,p=s*h,u>=0)if(d>=-p)if(d<=p){const v=1/h;u*=v,d*=v,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-p?(u=Math.max(0,-(-o*s+a)),d=u>0?-s:Math.min(Math.max(-s,-l),s),f=-u*u+d*(d+2*l)+c):d<=p?(u=0,d=Math.min(Math.max(-s,-l),s),f=d*(d+2*l)+c):(u=Math.max(0,-(o*s+a)),d=u>0?s:Math.min(Math.max(-s,-l),s),f=-u*u+d*(d+2*l)+c);else d=o>0?-s:s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,u),n&&n.copy(Io).addScaledVector(hr,d),f}intersectSphere(t,e){if(t.radius<0)return null;Wi.subVectors(t.center,this.origin);const i=Wi.dot(this.direction),n=Wi.dot(Wi)-i*i,s=t.radius*t.radius;if(n>s)return null;const o=Math.sqrt(s-n),a=i-o,l=i+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(t.normal)+t.constant)/e;return i>=0?i:null}intersectPlane(t,e){const i=this.distanceToPlane(t);return i===null?null:this.at(i,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let i,n,s,o,a,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(i=(t.min.x-d.x)*c,n=(t.max.x-d.x)*c):(i=(t.max.x-d.x)*c,n=(t.min.x-d.x)*c),h>=0?(s=(t.min.y-d.y)*h,o=(t.max.y-d.y)*h):(s=(t.max.y-d.y)*h,o=(t.min.y-d.y)*h),i>o||s>n||((s>i||isNaN(i))&&(i=s),(o<n||isNaN(n))&&(n=o),u>=0?(a=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(a=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),i>l||a>n)||((a>i||i!==i)&&(i=a),(l<n||n!==n)&&(n=l),n<0)?null:this.at(i>=0?i:n,e)}intersectsBox(t){return this.intersectBox(t,Wi)!==null}intersectTriangle(t,e,i,n,s){const o=this.origin,a=this.direction,l=a.x,c=a.y,h=a.z,u=t.x-o.x,d=t.y-o.y,f=t.z-o.z,p=e.x-o.x,v=e.y-o.y,m=e.z-o.z,g=i.x-o.x,_=i.y-o.y,M=i.z-o.z,y=Math.abs(l),E=Math.abs(c),T=Math.abs(h);let x,w,P,C,U,B,V,D,H,Y,F,et;if(y>=E&&y>=T?(P=l,B=u,H=p,et=g,l>=0?(x=c,w=h,C=d,U=f,V=v,D=m,Y=_,F=M):(x=h,w=c,C=f,U=d,V=m,D=v,Y=M,F=_)):E>=T?(P=c,B=d,H=v,et=_,c>=0?(x=h,w=l,C=f,U=u,V=m,D=p,Y=M,F=g):(x=l,w=h,C=u,U=f,V=p,D=m,Y=g,F=M)):(P=h,B=f,H=m,et=M,h>=0?(x=l,w=c,C=u,U=d,V=p,D=v,Y=g,F=_):(x=c,w=l,C=d,U=u,V=v,D=p,Y=_,F=g)),P===0)return null;const X=x/P,tt=w/P,it=1/P,Rt=C-X*B,Gt=U-tt*B,Z=V-X*H,yt=D-tt*H,Et=Y-X*et,Nt=F-tt*et,Mt=Et*yt-Nt*Z,Vt=Rt*Nt-Gt*Et,Ae=Z*Gt-yt*Rt;if(n){if(Mt<0||Vt<0||Ae<0)return null}else if((Mt<0||Vt<0||Ae<0)&&(Mt>0||Vt>0||Ae>0))return null;const Ot=Mt+Vt+Ae;if(Ot===0)return null;const le=it*(Mt*B+Vt*H+Ae*et);return(Ot>0?le<0:le>0)?null:this.at(le/Ot,s)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class li extends Pn{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ct(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new dn,this.combine=ih,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Kl=new te,yn=new to,dr=new cs,Zl=new R,fr=new R,pr=new R,mr=new R,No=new R,gr=new R,Jl=new R,vr=new R;class I extends ue{constructor(t=new de,e=new li){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){const n=e[i[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=n.length;s<o;s++){const a=n[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}getVertexPosition(t,e){const i=this.geometry,n=i.attributes.position,s=i.morphAttributes.position,o=i.morphTargetsRelative;e.fromBufferAttribute(n,t);const a=this.morphTargetInfluences;if(s&&a){gr.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const h=a[l],u=s[l];h!==0&&(No.fromBufferAttribute(u,t),o?gr.addScaledVector(No,h):gr.addScaledVector(No.sub(e),h))}e.add(gr)}return e}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const i=this.geometry,n=this.material,s=this.matrixWorld;n!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),dr.copy(i.boundingSphere),dr.applyMatrix4(s),yn.copy(t.ray).recast(t.near),!(dr.containsPoint(yn.origin)===!1&&(yn.intersectSphere(dr,Zl)===null||yn.origin.distanceToSquared(Zl)>(t.far-t.near)**2))&&(Kl.copy(s).invert(),yn.copy(t.ray).applyMatrix4(Kl),!(i.boundingBox!==null&&yn.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(t,e,yn)))}_computeIntersections(t,e,i){let n;const s=this.geometry,o=this.material,a=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,d=s.groups,f=s.drawRange;if(a!==null)if(Array.isArray(o))for(let p=0,v=d.length;p<v;p++){const m=d[p],g=o[m.materialIndex],_=Math.max(m.start,f.start),M=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let y=_,E=M;y<E;y+=3){const T=a.getX(y),x=a.getX(y+1),w=a.getX(y+2);n=_r(this,g,t,i,c,h,u,T,x,w),n&&(n.faceIndex=Math.floor(y/3),n.face.materialIndex=m.materialIndex,e.push(n))}}else{const p=Math.max(0,f.start),v=Math.min(a.count,f.start+f.count);for(let m=p,g=v;m<g;m+=3){const _=a.getX(m),M=a.getX(m+1),y=a.getX(m+2);n=_r(this,o,t,i,c,h,u,_,M,y),n&&(n.faceIndex=Math.floor(m/3),e.push(n))}}else if(l!==void 0)if(Array.isArray(o))for(let p=0,v=d.length;p<v;p++){const m=d[p],g=o[m.materialIndex],_=Math.max(m.start,f.start),M=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let y=_,E=M;y<E;y+=3){const T=y,x=y+1,w=y+2;n=_r(this,g,t,i,c,h,u,T,x,w),n&&(n.faceIndex=Math.floor(y/3),n.face.materialIndex=m.materialIndex,e.push(n))}}else{const p=Math.max(0,f.start),v=Math.min(l.count,f.start+f.count);for(let m=p,g=v;m<g;m+=3){const _=m,M=m+1,y=m+2;n=_r(this,o,t,i,c,h,u,_,M,y),n&&(n.faceIndex=Math.floor(m/3),e.push(n))}}}}function vd(r,t,e,i,n,s,o,a){let l;if(t.side===Je?l=i.intersectTriangle(o,s,n,!0,a):l=i.intersectTriangle(n,s,o,t.side===cn,a),l===null)return null;vr.copy(a),vr.applyMatrix4(r.matrixWorld);const c=e.ray.origin.distanceTo(vr);return c<e.near||c>e.far?null:{distance:c,point:vr.clone(),object:r}}function _r(r,t,e,i,n,s,o,a,l,c){r.getVertexPosition(a,fr),r.getVertexPosition(l,pr),r.getVertexPosition(c,mr);const h=vd(r,t,e,i,fr,pr,mr,Jl);if(h){const u=new R;yi.getBarycoord(Jl,fr,pr,mr,u),n&&(h.uv=yi.getInterpolatedAttribute(n,a,l,c,u,new Q)),s&&(h.uv1=yi.getInterpolatedAttribute(s,a,l,c,u,new Q)),o&&(h.normal=yi.getInterpolatedAttribute(o,a,l,c,u,new R),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));const d={a,b:l,c,normal:new R,materialIndex:0};yi.getNormal(fr,pr,mr,d.normal),h.face=d,h.barycoord=u}return h}class Ch extends je{constructor(t=null,e=1,i=1,n,s,o,a,l,c=Xe,h=Xe,u,d){super(null,o,a,l,c,h,n,s,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Na extends ee{constructor(t,e,i,n=1){super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=n}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const qn=new te,jl=new te,xr=[],Ql=new Cn,_d=new te,Ms=new I,Ss=new cs;class Rs extends I{constructor(t,e,i){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Na(new Float32Array(i*16),16),this.instanceColor=null,this.morphTexture=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let n=0;n<i;n++)this.setMatrixAt(n,_d)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Cn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,qn),Ql.copy(t.boundingBox).applyMatrix4(qn),this.boundingBox.union(Ql)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new cs),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,qn),Ss.copy(t.boundingSphere).applyMatrix4(qn),this.boundingSphere.union(Ss)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),this.morphTexture=t.morphTexture!==null?t.morphTexture.clone():null,this.instanceColor=t.instanceColor!==null?t.instanceColor.clone():null,this.count=t.count,this.boundingBox=t.boundingBox!==null?t.boundingBox.clone():null,this.boundingSphere=t.boundingSphere!==null?t.boundingSphere.clone():null,this}getColorAt(t,e){return this.instanceColor===null?e.setRGB(1,1,1):e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){return e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const i=e.morphTargetInfluences,n=this.morphTexture.source.data.data,s=i.length+1,o=t*s+1;for(let a=0;a<i.length;a++)i[a]=n[o+a]}raycast(t,e){const i=this.matrixWorld,n=this.count;if(Ms.geometry=this.geometry,Ms.material=this.material,Ms.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ss.copy(this.boundingSphere),Ss.applyMatrix4(i),t.ray.intersectsSphere(Ss)!==!1))for(let s=0;s<n;s++){this.getMatrixAt(s,qn),jl.multiplyMatrices(i,qn),Ms.matrixWorld=jl,Ms.raycast(t,xr);for(let o=0,a=xr.length;o<a;o++){const l=xr[o];l.instanceId=s,l.object=this,e.push(l)}xr.length=0}}setColorAt(t,e){return this.instanceColor===null&&(this.instanceColor=new Na(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3),this}setMatrixAt(t,e){return e.toArray(this.instanceMatrix.array,t*16),this}setMorphAt(t,e){const i=e.morphTargetInfluences,n=i.length+1;this.morphTexture===null&&(this.morphTexture=new Ch(new Float32Array(n*this.count),n,this.count,Za,Ei));const s=this.morphTexture.source.data.data;let o=0;for(let c=0;c<i.length;c++)o+=i[c];const a=this.geometry.morphTargetsRelative?1:1-o,l=n*t;return s[l]=a,s.set(i,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Mn=new cs,xd=new Q(.5,.5),yr=new R;class ks{constructor(t=new Xi,e=new Xi,i=new Xi,n=new Xi,s=new Xi,o=new Xi){this.planes=[t,e,i,n,s,o]}set(t,e,i,n,s,o){const a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(i),a[3].copy(n),a[4].copy(s),a[5].copy(o),this}copy(t){const e=this.planes;for(let i=0;i<6;i++)e[i].copy(t.planes[i]);return this}setFromProjectionMatrix(t,e=Ti,i=!1){const n=this.planes,s=t.elements,o=s[0],a=s[1],l=s[2],c=s[3],h=s[4],u=s[5],d=s[6],f=s[7],p=s[8],v=s[9],m=s[10],g=s[11],_=s[12],M=s[13],y=s[14],E=s[15];if(n[0].setComponents(c-o,f-h,g-p,E-_).normalize(),n[1].setComponents(c+o,f+h,g+p,E+_).normalize(),n[2].setComponents(c+a,f+u,g+v,E+M).normalize(),n[3].setComponents(c-a,f-u,g-v,E-M).normalize(),i)n[4].setComponents(l,d,m,y).normalize(),n[5].setComponents(c-l,f-d,g-m,E-y).normalize();else if(n[4].setComponents(c-l,f-d,g-m,E-y).normalize(),e===Ti)n[5].setComponents(c+l,f+d,g+m,E+y).normalize();else if(e===zs)n[5].setComponents(l,d,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Mn.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Mn.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Mn)}intersectsSprite(t){Mn.center.set(0,0,0);const e=xd.distanceTo(t.center);return Mn.radius=.7071067811865476+e,Mn.applyMatrix4(t.matrixWorld),this.intersectsSphere(Mn)}intersectsSphere(t){const e=this.planes,i=t.center,n=-t.radius;for(let s=0;s<6;s++)if(e[s].distanceToPoint(i)<n)return!1;return!0}intersectsBox(t){const e=this.planes;for(let i=0;i<6;i++){const n=e[i];if(yr.x=n.normal.x>0?t.max.x:t.min.x,yr.y=n.normal.y>0?t.max.y:t.min.y,yr.z=n.normal.z>0?t.max.z:t.min.z,n.distanceToPoint(yr)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let i=0;i<6;i++)if(e[i].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const tc=new te;class sl{constructor(){this.coordinateSystem=Ti,this._frustums=[],this._count=0}setFromArrayCamera(t){const e=t.cameras,i=this._frustums;for(let n=0;n<e.length;n++){const s=e[n];tc.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),i[n]===void 0&&(i[n]=new ks),i[n].setFromProjectionMatrix(tc,s.coordinateSystem,s.reversedDepth)}return this._count=e.length,this}getFrustum(t){return this._frustums[t]}intersectsObject(t){const e=this._frustums;for(let i=0;i<this._count;i++)if(e[i].intersectsObject(t))return!0;return!1}intersectsSprite(t){const e=this._frustums;for(let i=0;i<this._count;i++)if(e[i].intersectsSprite(t))return!0;return!1}intersectsSphere(t){const e=this._frustums;for(let i=0;i<this._count;i++)if(e[i].intersectsSphere(t))return!0;return!1}intersectsBox(t){const e=this._frustums;for(let i=0;i<this._count;i++)if(e[i].intersectsBox(t))return!0;return!1}containsPoint(t){const e=this._frustums;for(let i=0;i<this._count;i++)if(e[i].containsPoint(t))return!0;return!1}copy(t){this.coordinateSystem=t.coordinateSystem;const e=this._frustums,i=t._frustums;for(let n=0;n<t._count;n++)e[n]===void 0&&(e[n]=new ks),e[n].copy(i[n]);return this._count=t._count,this}clone(){return new sl().copy(this)}}class rl extends Pn{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new ct(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const ec=new te,Ua=new to,Mr=new cs,Sr=new R;class Gs extends ue{constructor(t=new de,e=new rl){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const i=this.geometry,n=this.matrixWorld,s=t.params.Points.threshold,o=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Mr.copy(i.boundingSphere),Mr.applyMatrix4(n),Mr.radius+=s,t.ray.intersectsSphere(Mr)===!1)return;ec.copy(n).invert(),Ua.copy(t.ray).applyMatrix4(ec);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=i.index,u=i.attributes.position;if(c!==null){const d=Math.max(0,o.start),f=Math.min(c.count,o.start+o.count);for(let p=d,v=f;p<v;p++){const m=c.getX(p);Sr.fromBufferAttribute(u,m),ic(Sr,m,l,n,t,e,this)}}else{const d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let p=d,v=f;p<v;p++)Sr.fromBufferAttribute(u,p),ic(Sr,p,l,n,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){const n=e[i[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=n.length;s<o;s++){const a=n[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function ic(r,t,e,i,n,s,o){const a=Ua.distanceSqToPoint(r);if(a<e){const l=new R;Ua.closestPointToPoint(r,l),l.applyMatrix4(i);const c=n.ray.origin.distanceTo(l);if(c<n.near||c>n.far)return;s.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}class Ph extends je{constructor(t=[],e=ns,i,n,s,o,a,l,c,h){super(t,e,i,n,s,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class ol extends je{constructor(t,e,i,n,s,o,a,l,c){super(t,e,i,n,s,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class rs extends je{constructor(t,e,i=Fi,n,s,o,a=Xe,l=Xe,c,h=hn,u=1){if(h!==hn&&h!==ln)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:t,height:e,depth:u};super(d,n,s,o,a,l,h,i,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new tl(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return e.compareFunction=this.compareFunction,e}}class Lh extends rs{constructor(t,e=Fi,i=ns,n,s,o=Xe,a=Xe,l,c=hn){const h={width:t,height:t,depth:1},u=[h,h,h,h,h,h];super(t,t,e,i,n,s,o,a,l,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class Dh extends je{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class ne extends de{constructor(t=1,e=1,i=1,n=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:n,heightSegments:s,depthSegments:o};const a=this;n=Math.floor(n),s=Math.floor(s),o=Math.floor(o);const l=[],c=[],h=[],u=[];let d=0,f=0;p("z","y","x",-1,-1,i,e,t,o,s,0),p("z","y","x",1,-1,i,e,-t,o,s,1),p("x","z","y",1,1,t,i,e,n,o,2),p("x","z","y",1,-1,t,i,-e,n,o,3),p("x","y","z",1,-1,t,e,i,n,s,4),p("x","y","z",-1,-1,t,e,-i,n,s,5),this.setIndex(l),this.setAttribute("position",new Kt(c,3)),this.setAttribute("normal",new Kt(h,3)),this.setAttribute("uv",new Kt(u,2));function p(v,m,g,_,M,y,E,T,x,w,P){const C=y/x,U=E/w,B=y/2,V=E/2,D=T/2,H=x+1,Y=w+1;let F=0,et=0;const X=new R;for(let tt=0;tt<Y;tt++){const it=tt*U-V;for(let Rt=0;Rt<H;Rt++){const Gt=Rt*C-B;X[v]=Gt*_,X[m]=it*M,X[g]=D,c.push(X.x,X.y,X.z),X[v]=0,X[m]=0,X[g]=T>0?1:-1,h.push(X.x,X.y,X.z),u.push(Rt/x),u.push(1-tt/w),F+=1}}for(let tt=0;tt<w;tt++)for(let it=0;it<x;it++){const Rt=d+it+H*tt,Gt=d+it+H*(tt+1),Z=d+(it+1)+H*(tt+1),yt=d+(it+1)+H*tt;l.push(Rt,Gt,yt),l.push(Gt,Z,yt),et+=6}a.addGroup(f,et,P),f+=et,d+=F}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ne(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class os extends de{constructor(t=1,e=1,i=4,n=8,s=1){super(),this.type="CapsuleGeometry",this.parameters={radius:t,height:e,capSegments:i,radialSegments:n,heightSegments:s},e=Math.max(0,e),i=Math.max(1,Math.floor(i)),n=Math.max(3,Math.floor(n)),s=Math.max(1,Math.floor(s));const o=[],a=[],l=[],c=[],h=e/2,u=Math.PI/2*t,d=e,f=2*u+d,p=i*2+s,v=n+1,m=new R,g=new R;for(let _=0;_<=p;_++){let M=0,y=0,E=0,T=0;if(_<=i){const P=_/i,C=P*Math.PI/2;y=-h-t*Math.cos(C),E=t*Math.sin(C),T=-t*Math.cos(C),M=P*u}else if(_<=i+s){const P=(_-i)/s;y=-h+P*e,E=t,T=0,M=u+P*d}else{const P=(_-i-s)/i,C=P*Math.PI/2;y=h+t*Math.sin(C),E=t*Math.cos(C),T=t*Math.sin(C),M=u+d+P*u}const x=Math.max(0,Math.min(1,M/f));let w=0;_===0?w=.5/n:_===p&&(w=-.5/n);for(let P=0;P<=n;P++){const C=P/n,U=C*Math.PI*2,B=Math.sin(U),V=Math.cos(U);g.x=-E*V,g.y=y,g.z=E*B,a.push(g.x,g.y,g.z),m.set(-E*V,T,E*B),m.normalize(),l.push(m.x,m.y,m.z),c.push(C+w,x)}if(_>0){const P=(_-1)*v;for(let C=0;C<n;C++){const U=P+C,B=P+C+1,V=_*v+C,D=_*v+C+1;o.push(U,B,V),o.push(B,D,V)}}}this.setIndex(o),this.setAttribute("position",new Kt(a,3)),this.setAttribute("normal",new Kt(l,3)),this.setAttribute("uv",new Kt(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new os(t.radius,t.height,t.capSegments,t.radialSegments,t.heightSegments)}}class si extends de{constructor(t=1,e=32,i=0,n=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:i,thetaLength:n},e=Math.max(3,e);const s=[],o=[],a=[],l=[],c=new R,h=new Q;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){const f=i+u/e*n;c.x=t*Math.cos(f),c.y=t*Math.sin(f),o.push(c.x,c.y,c.z),a.push(0,0,1),h.x=(o[d]/t+1)/2,h.y=(o[d+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new Kt(o,3)),this.setAttribute("normal",new Kt(a,3)),this.setAttribute("uv",new Kt(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new si(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class Ft extends de{constructor(t=1,e=1,i=1,n=32,s=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:n,heightSegments:s,openEnded:o,thetaStart:a,thetaLength:l};const c=this;n=Math.floor(n),s=Math.floor(s);const h=[],u=[],d=[],f=[];let p=0;const v=[],m=i/2;let g=0;_(),o===!1&&(t>0&&M(!0),e>0&&M(!1)),this.setIndex(h),this.setAttribute("position",new Kt(u,3)),this.setAttribute("normal",new Kt(d,3)),this.setAttribute("uv",new Kt(f,2));function _(){const y=new R,E=new R;let T=0;const x=(e-t)/i;for(let w=0;w<=s;w++){const P=[],C=w/s,U=C*(e-t)+t;for(let B=0;B<=n;B++){const V=B/n,D=V*l+a,H=Math.sin(D),Y=Math.cos(D);E.x=U*H,E.y=-C*i+m,E.z=U*Y,u.push(E.x,E.y,E.z),y.set(H,x,Y).normalize(),d.push(y.x,y.y,y.z),f.push(V,1-C),P.push(p++)}v.push(P)}for(let w=0;w<n;w++)for(let P=0;P<s;P++){const C=v[P][w],U=v[P+1][w],B=v[P+1][w+1],V=v[P][w+1];(t>0||P!==0)&&(h.push(C,U,V),T+=3),(e>0||P!==s-1)&&(h.push(U,B,V),T+=3)}c.addGroup(g,T,0),g+=T}function M(y){const E=p,T=new Q,x=new R;let w=0;const P=y===!0?t:e,C=y===!0?1:-1;for(let B=1;B<=n;B++)u.push(0,m*C,0),d.push(0,C,0),f.push(.5,.5),p++;const U=p;for(let B=0;B<=n;B++){const D=B/n*l+a,H=Math.cos(D),Y=Math.sin(D);x.x=P*Y,x.y=m*C,x.z=P*H,u.push(x.x,x.y,x.z),d.push(0,C,0),T.x=H*.5+.5,T.y=Y*.5*C+.5,f.push(T.x,T.y),p++}for(let B=0;B<n;B++){const V=E+B,D=U+B;y===!0?h.push(D,D+1,V):h.push(D+1,D,V),w+=3}c.addGroup(g,w,y===!0?1:2),g+=w}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ft(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class ci extends Ft{constructor(t=1,e=1,i=32,n=1,s=!1,o=0,a=Math.PI*2){super(0,t,e,i,n,s,o,a),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:n,openEnded:s,thetaStart:o,thetaLength:a}}static fromJSON(t){return new ci(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class $s extends de{constructor(t=[],e=[],i=1,n=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:n};const s=[],o=[];a(n),c(i),h(),this.setAttribute("position",new Kt(s,3)),this.setAttribute("normal",new Kt(s.slice(),3)),this.setAttribute("uv",new Kt(o,2)),n===0?this.computeVertexNormals():this.normalizeNormals();function a(_){const M=new R,y=new R,E=new R;for(let T=0;T<e.length;T+=3)f(e[T+0],M),f(e[T+1],y),f(e[T+2],E),l(M,y,E,_)}function l(_,M,y,E){const T=E+1,x=[];for(let w=0;w<=T;w++){x[w]=[];const P=_.clone().lerp(y,w/T),C=M.clone().lerp(y,w/T),U=T-w;for(let B=0;B<=U;B++)B===0&&w===T?x[w][B]=P:x[w][B]=P.clone().lerp(C,B/U)}for(let w=0;w<T;w++)for(let P=0;P<2*(T-w)-1;P++){const C=Math.floor(P/2);P%2===0?(d(x[w][C+1]),d(x[w+1][C]),d(x[w][C])):(d(x[w][C+1]),d(x[w+1][C+1]),d(x[w+1][C]))}}function c(_){const M=new R;for(let y=0;y<s.length;y+=3)M.x=s[y+0],M.y=s[y+1],M.z=s[y+2],M.normalize().multiplyScalar(_),s[y+0]=M.x,s[y+1]=M.y,s[y+2]=M.z}function h(){const _=new R;for(let M=0;M<s.length;M+=3){_.x=s[M+0],_.y=s[M+1],_.z=s[M+2];const y=m(_)/2/Math.PI+.5,E=g(_)/Math.PI+.5;o.push(y,1-E)}p(),u()}function u(){for(let _=0;_<o.length;_+=6){const M=o[_+0],y=o[_+2],E=o[_+4],T=Math.max(M,y,E),x=Math.min(M,y,E);T>.9&&x<.1&&(M<.2&&(o[_+0]+=1),y<.2&&(o[_+2]+=1),E<.2&&(o[_+4]+=1))}}function d(_){s.push(_.x,_.y,_.z)}function f(_,M){const y=_*3;M.x=t[y+0],M.y=t[y+1],M.z=t[y+2]}function p(){const _=new R,M=new R,y=new R,E=new R,T=new Q,x=new Q,w=new Q;for(let P=0,C=0;P<s.length;P+=9,C+=6){_.set(s[P+0],s[P+1],s[P+2]),M.set(s[P+3],s[P+4],s[P+5]),y.set(s[P+6],s[P+7],s[P+8]),T.set(o[C+0],o[C+1]),x.set(o[C+2],o[C+3]),w.set(o[C+4],o[C+5]),E.copy(_).add(M).add(y).divideScalar(3);const U=m(E);v(T,C+0,_,U),v(x,C+2,M,U),v(w,C+4,y,U)}}function v(_,M,y,E){E<0&&_.x===1&&(o[M]=_.x-1),y.x===0&&y.z===0&&(o[M]=E/2/Math.PI+.5)}function m(_){return Math.atan2(_.z,-_.x)}function g(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new $s(t.vertices,t.indices,t.radius,t.detail)}}class hs extends $s{constructor(t=1,e=0){const i=(1+Math.sqrt(5))/2,n=1/i,s=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-n,-i,0,-n,i,0,n,-i,0,n,i,-n,-i,0,-n,i,0,n,-i,0,n,i,0,-i,0,-n,i,0,-n,-i,0,n,i,0,n],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(s,o,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new hs(t.radius,t.detail)}}class Bi{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){Bt("Curve: .getPoint() not implemented.")}getPointAt(t,e){const i=this.getUtoTmapping(t);return this.getPoint(i,e)}getPoints(t=5){const e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return e}getSpacedPoints(t=5){const e=[];for(let i=0;i<=t;i++)e.push(this.getPointAt(i/t));return e}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const e=[];let i,n=this.getPoint(0),s=0;e.push(0);for(let o=1;o<=t;o++)i=this.getPoint(o/t),s+=i.distanceTo(n),e.push(s),n=i;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e=null){const i=this.getLengths();let n=0;const s=i.length;let o;e?o=e:o=t*i[s-1];let a=0,l=s-1,c;for(;a<=l;)if(n=Math.floor(a+(l-a)/2),c=i[n]-o,c<0)a=n+1;else if(c>0)l=n-1;else{l=n;break}if(n=l,i[n]===o)return n/(s-1);const h=i[n],d=i[n+1]-h,f=(o-h)/d;return(n+f)/(s-1)}getTangent(t,e){let n=t-1e-4,s=t+1e-4;n<0&&(n=0),s>1&&(s=1);const o=this.getPoint(n),a=this.getPoint(s),l=e||(o.isVector2?new Q:new R);return l.copy(a).sub(o).normalize(),l}getTangentAt(t,e){const i=this.getUtoTmapping(t);return this.getTangent(i,e)}computeFrenetFrames(t,e=!1){const i=new R,n=[],s=[],o=[],a=new R,l=new te;for(let f=0;f<=t;f++){const p=f/t;n[f]=this.getTangentAt(p,new R)}s[0]=new R,o[0]=new R;let c=Number.MAX_VALUE;const h=Math.abs(n[0].x),u=Math.abs(n[0].y),d=Math.abs(n[0].z);h<=c&&(c=h,i.set(1,0,0)),u<=c&&(c=u,i.set(0,1,0)),d<=c&&i.set(0,0,1),a.crossVectors(n[0],i).normalize(),s[0].crossVectors(n[0],a),o[0].crossVectors(n[0],s[0]);for(let f=1;f<=t;f++){if(s[f]=s[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(n[f-1],n[f]),a.length()>Number.EPSILON){a.normalize();const p=Math.acos(Xt(n[f-1].dot(n[f]),-1,1));s[f].applyMatrix4(l.makeRotationAxis(a,p))}o[f].crossVectors(n[f],s[f])}if(e===!0){let f=Math.acos(Xt(s[0].dot(s[t]),-1,1));f/=t,n[0].dot(a.crossVectors(s[0],s[t]))>0&&(f=-f);for(let p=1;p<=t;p++)s[p].applyMatrix4(l.makeRotationAxis(n[p],f*p)),o[p].crossVectors(n[p],s[p])}return{tangents:n,normals:s,binormals:o}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this.cacheArcLengths=null,this}toJSON(){const t={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this.cacheArcLengths=null,this}}class al extends Bi{constructor(t=0,e=0,i=1,n=1,s=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=n,this.aStartAngle=s,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(t,e=new Q){const i=e,n=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const o=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=n;for(;s>n;)s-=n;s<Number.EPSILON&&(o?s=0:s=n),this.aClockwise===!0&&!o&&(s===n?s=-n:s=s-n);const a=this.aStartAngle+t*s;let l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){const h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return i.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class yd extends al{constructor(t,e,i,n,s,o){super(t,e,i,i,n,s,o),this.isArcCurve=!0,this.type="ArcCurve"}}function ll(){let r=0,t=0,e=0,i=0;function n(s,o,a,l){r=s,t=a,e=-3*s+3*o-2*a-l,i=2*s-2*o+a+l}return{initCatmullRom:function(s,o,a,l,c){n(o,a,c*(a-s),c*(l-o))},initNonuniformCatmullRom:function(s,o,a,l,c,h,u){let d=(o-s)/c-(a-s)/(c+h)+(a-o)/h,f=(a-o)/h-(l-o)/(h+u)+(l-a)/u;d*=h,f*=h,n(o,a,d,f)},calc:function(s){const o=s*s,a=o*s;return r+t*s+e*o+i*a}}}const nc=new R,sc=new R,Uo=new ll,Fo=new ll,Oo=new ll;class Hs extends Bi{constructor(t=[],e=!1,i="centripetal",n=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=n}getPoint(t,e=new R){const i=e,n=this.points,s=n.length,o=(s-(this.closed?0:1))*t;let a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/s)+1)*s:l===0&&a===s-1&&(a=s-2,l=1);let c,h;this.closed||a>0?c=n[(a-1)%s]:(sc.subVectors(n[0],n[1]).add(n[0]),c=sc);const u=n[a%s],d=n[(a+1)%s];if(this.closed||a+2<s?h=n[(a+2)%s]:(nc.subVectors(n[s-1],n[s-2]).add(n[s-1]),h=nc),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let p=Math.pow(c.distanceToSquared(u),f),v=Math.pow(u.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(h),f);v<1e-4&&(v=1),p<1e-4&&(p=v),m<1e-4&&(m=v),Uo.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,p,v,m),Fo.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,p,v,m),Oo.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,p,v,m)}else this.curveType==="catmullrom"&&(Uo.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),Fo.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),Oo.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return i.set(Uo.calc(l),Fo.calc(l),Oo.calc(l)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){const n=t.points[e];this.points.push(n.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){const n=this.points[e];t.points.push(n.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){const n=t.points[e];this.points.push(new R().fromArray(n))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function rc(r,t,e,i,n){const s=(i-t)*.5,o=(n-e)*.5,a=r*r,l=r*a;return(2*e-2*i+s+o)*l+(-3*e+3*i-2*s-o)*a+s*r+e}function Md(r,t){const e=1-r;return e*e*t}function Sd(r,t){return 2*(1-r)*r*t}function wd(r,t){return r*r*t}function Ds(r,t,e,i){return Md(r,t)+Sd(r,e)+wd(r,i)}function bd(r,t){const e=1-r;return e*e*e*t}function Ed(r,t){const e=1-r;return 3*e*e*r*t}function Td(r,t){return 3*(1-r)*r*r*t}function Ad(r,t){return r*r*r*t}function Is(r,t,e,i,n){return bd(r,t)+Ed(r,e)+Td(r,i)+Ad(r,n)}class Ih extends Bi{constructor(t=new Q,e=new Q,i=new Q,n=new Q){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=n}getPoint(t,e=new Q){const i=e,n=this.v0,s=this.v1,o=this.v2,a=this.v3;return i.set(Is(t,n.x,s.x,o.x,a.x),Is(t,n.y,s.y,o.y,a.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class Rd extends Bi{constructor(t=new R,e=new R,i=new R,n=new R){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=n}getPoint(t,e=new R){const i=e,n=this.v0,s=this.v1,o=this.v2,a=this.v3;return i.set(Is(t,n.x,s.x,o.x,a.x),Is(t,n.y,s.y,o.y,a.y),Is(t,n.z,s.z,o.z,a.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class Nh extends Bi{constructor(t=new Q,e=new Q){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new Q){const i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new Q){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Cd extends Bi{constructor(t=new R,e=new R){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new R){const i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new R){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Uh extends Bi{constructor(t=new Q,e=new Q,i=new Q){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new Q){const i=e,n=this.v0,s=this.v1,o=this.v2;return i.set(Ds(t,n.x,s.x,o.x),Ds(t,n.y,s.y,o.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Fh extends Bi{constructor(t=new R,e=new R,i=new R){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new R){const i=e,n=this.v0,s=this.v1,o=this.v2;return i.set(Ds(t,n.x,s.x,o.x),Ds(t,n.y,s.y,o.y),Ds(t,n.z,s.z,o.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Oh extends Bi{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new Q){const i=e,n=this.points,s=(n.length-1)*t,o=Math.floor(s),a=s-o,l=n[o===0?o:o-1],c=n[o],h=n[o>n.length-2?n.length-1:o+1],u=n[o>n.length-3?n.length-1:o+2];return i.set(rc(a,l.x,c.x,h.x,u.x),rc(a,l.y,c.y,h.y,u.y)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){const n=t.points[e];this.points.push(n.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){const n=this.points[e];t.points.push(n.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){const n=t.points[e];this.points.push(new Q().fromArray(n))}return this}}var Fa=Object.freeze({__proto__:null,ArcCurve:yd,CatmullRomCurve3:Hs,CubicBezierCurve:Ih,CubicBezierCurve3:Rd,EllipseCurve:al,LineCurve:Nh,LineCurve3:Cd,QuadraticBezierCurve:Uh,QuadraticBezierCurve3:Fh,SplineCurve:Oh});class Pd extends Bi{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1,this.cacheLengths=null}add(t){this.curves.push(t)}closePath(){const t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){const i=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Fa[i](e,t))}return this}getPoint(t,e){const i=t*this.getLength(),n=this.getCurveLengths();let s=0;for(;s<n.length;){if(n[s]>=i){const o=n[s]-i,a=this.curves[s],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,e)}s++}return null}getLength(){const t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const t=[];let e=0;for(let i=0,n=this.curves.length;i<n;i++)e+=this.curves[i].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){const e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){const e=[];let i;for(let n=0,s=this.curves;n<s.length;n++){const o=s[n],a=o.isEllipseCurve?t*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?t*o.points.length:t,l=o.getPoints(a);for(let c=0;c<l.length;c++){const h=l[c];i&&i.equals(h)||(e.push(h),i=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){const n=t.curves[e];this.curves.push(n.clone())}return this.autoClose=t.autoClose,this.cacheLengths=null,this}toJSON(){const t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,i=this.curves.length;e<i;e++){const n=this.curves[e];t.curves.push(n.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){const n=t.curves[e];this.curves.push(new Fa[n.type]().fromJSON(n))}return this.cacheLengths=null,this}}class oc extends Pd{constructor(t){super(),this.type="Path",this.currentPoint=new Q,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,i=t.length;e<i;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){const i=new Nh(this.currentPoint.clone(),new Q(t,e));return this.curves.push(i),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,i,n){const s=new Uh(this.currentPoint.clone(),new Q(t,e),new Q(i,n));return this.curves.push(s),this.currentPoint.set(i,n),this}bezierCurveTo(t,e,i,n,s,o){const a=new Ih(this.currentPoint.clone(),new Q(t,e),new Q(i,n),new Q(s,o));return this.curves.push(a),this.currentPoint.set(s,o),this}splineThru(t){const e=[this.currentPoint.clone()].concat(t),i=new Oh(e);return this.curves.push(i),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,i,n,s,o){const a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+a,e+l,i,n,s,o),this}absarc(t,e,i,n,s,o){return this.absellipse(t,e,i,i,n,s,o),this}ellipse(t,e,i,n,s,o,a,l){const c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,i,n,s,o,a,l),this}absellipse(t,e,i,n,s,o,a,l){const c=new al(t,e,i,n,s,o,a,l);if(this.curves.length>0){const u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);const h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){const t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}}class Bh extends oc{constructor(t){super(t),this.uuid=pn(),this.type="Shape",this.holes=[]}getPointsHoles(t){const e=[];for(let i=0,n=this.holes.length;i<n;i++)e[i]=this.holes[i].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){const n=t.holes[e];this.holes.push(n.clone())}return this}toJSON(){const t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,i=this.holes.length;e<i;e++){const n=this.holes[e];t.holes.push(n.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){const n=t.holes[e];this.holes.push(new oc().fromJSON(n))}return this}}function Ld(r,t,e=2){const i=t&&t.length,n=i?t[0]*e:r.length;let s=zh(r,0,n,e,!0);const o=[];if(!s||s.next===s.prev)return o;let a,l,c;if(i&&(s=Fd(r,t,s,e)),r.length>80*e){a=r[0],l=r[1];let h=a,u=l;for(let d=e;d<n;d+=e){const f=r[d],p=r[d+1];f<a&&(a=f),p<l&&(l=p),f>h&&(h=f),p>u&&(u=p)}c=Math.max(h-a,u-l),c=c!==0?32767/c:0}return Vs(s,o,e,a,l,c,0),o}function zh(r,t,e,i,n){let s;if(n===Yd(r,t,e,i)>0)for(let o=t;o<e;o+=i)s=ac(o/i|0,r[o],r[o+1],s);else for(let o=e-i;o>=t;o-=i)s=ac(o/i|0,r[o],r[o+1],s);return s&&as(s,s.next)&&(Xs(s),s=s.next),s}function An(r,t){if(!r)return r;t||(t=r);let e=r,i;do if(i=!1,!e.steiner&&(as(e,e.next)||Se(e.prev,e,e.next)===0)){if(Xs(e),e=t=e.prev,e===e.next)break;i=!0}else e=e.next;while(i||e!==t);return t}function Vs(r,t,e,i,n,s,o){if(!r)return;!o&&s&&Gd(r,i,n,s);let a=r;for(;r.prev!==r.next;){const l=r.prev,c=r.next;if(s?Id(r,i,n,s):Dd(r)){t.push(l.i,r.i,c.i),Xs(r),r=c.next,a=c.next;continue}if(r=c,r===a){o?o===1?(r=Nd(An(r),t),Vs(r,t,e,i,n,s,2)):o===2&&Ud(r,t,e,i,n,s):Vs(An(r),t,e,i,n,s,1);break}}}function Dd(r){const t=r.prev,e=r,i=r.next;if(Se(t,e,i)>=0)return!1;const n=t.x,s=e.x,o=i.x,a=t.y,l=e.y,c=i.y,h=Math.min(n,s,o),u=Math.min(a,l,c),d=Math.max(n,s,o),f=Math.max(a,l,c);let p=i.next;for(;p!==t;){if(p.x>=h&&p.x<=d&&p.y>=u&&p.y<=f&&Cs(n,a,s,l,o,c,p.x,p.y)&&Se(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function Id(r,t,e,i){const n=r.prev,s=r,o=r.next;if(Se(n,s,o)>=0)return!1;const a=n.x,l=s.x,c=o.x,h=n.y,u=s.y,d=o.y,f=Math.min(a,l,c),p=Math.min(h,u,d),v=Math.max(a,l,c),m=Math.max(h,u,d),g=Oa(f,p,t,e,i),_=Oa(v,m,t,e,i);let M=r.prevZ,y=r.nextZ;for(;M&&M.z>=g&&y&&y.z<=_;){if(M.x>=f&&M.x<=v&&M.y>=p&&M.y<=m&&M!==n&&M!==o&&Cs(a,h,l,u,c,d,M.x,M.y)&&Se(M.prev,M,M.next)>=0||(M=M.prevZ,y.x>=f&&y.x<=v&&y.y>=p&&y.y<=m&&y!==n&&y!==o&&Cs(a,h,l,u,c,d,y.x,y.y)&&Se(y.prev,y,y.next)>=0))return!1;y=y.nextZ}for(;M&&M.z>=g;){if(M.x>=f&&M.x<=v&&M.y>=p&&M.y<=m&&M!==n&&M!==o&&Cs(a,h,l,u,c,d,M.x,M.y)&&Se(M.prev,M,M.next)>=0)return!1;M=M.prevZ}for(;y&&y.z<=_;){if(y.x>=f&&y.x<=v&&y.y>=p&&y.y<=m&&y!==n&&y!==o&&Cs(a,h,l,u,c,d,y.x,y.y)&&Se(y.prev,y,y.next)>=0)return!1;y=y.nextZ}return!0}function Nd(r,t){let e=r;do{const i=e.prev,n=e.next.next;!as(i,n)&&Gh(i,e,e.next,n)&&Ws(i,n)&&Ws(n,i)&&(t.push(i.i,e.i,n.i),Xs(e),Xs(e.next),e=r=n),e=e.next}while(e!==r);return An(e)}function Ud(r,t,e,i,n,s){let o=r;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Wd(o,a)){let l=Hh(o,a);o=An(o,o.next),l=An(l,l.next),Vs(o,t,e,i,n,s,0),Vs(l,t,e,i,n,s,0);return}a=a.next}o=o.next}while(o!==r)}function Fd(r,t,e,i){const n=[];for(let s=0,o=t.length;s<o;s++){const a=t[s]*i,l=s<o-1?t[s+1]*i:r.length,c=zh(r,a,l,i,!1);c===c.next&&(c.steiner=!0),n.push(Vd(c))}n.sort(Od);for(let s=0;s<n.length;s++)e=Bd(n[s],e);return e}function Od(r,t){let e=r.x-t.x;if(e===0&&(e=r.y-t.y,e===0)){const i=(r.next.y-r.y)/(r.next.x-r.x),n=(t.next.y-t.y)/(t.next.x-t.x);e=i-n}return e}function Bd(r,t){const e=zd(r,t);if(!e)return t;const i=Hh(e,r);return An(i,i.next),An(e,e.next)}function zd(r,t){let e=t;const i=r.x,n=r.y;let s=-1/0,o;if(as(r,e))return e;do{if(as(r,e.next))return e.next;if(n<=e.y&&n>=e.next.y&&e.next.y!==e.y){const u=e.x+(n-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(u<=i&&u>s&&(s=u,o=e.x<e.next.x?e:e.next,u===i))return o}e=e.next}while(e!==t);if(!o)return null;const a=o,l=o.x,c=o.y;let h=1/0;e=o;do{if(i>=e.x&&e.x>=l&&i!==e.x&&kh(n<c?i:s,n,l,c,n<c?s:i,n,e.x,e.y)){const u=Math.abs(n-e.y)/(i-e.x);Ws(e,r)&&(u<h||u===h&&(e.x>o.x||e.x===o.x&&kd(o,e)))&&(o=e,h=u)}e=e.next}while(e!==a);return o}function kd(r,t){return Se(r.prev,r,t.prev)<0&&Se(t.next,r,r.next)<0}function Gd(r,t,e,i){let n=r;do n.z===0&&(n.z=Oa(n.x,n.y,t,e,i)),n.prevZ=n.prev,n.nextZ=n.next,n=n.next;while(n!==r);n.prevZ.nextZ=null,n.prevZ=null,Hd(n)}function Hd(r){let t,e=1;do{let i=r,n;r=null;let s=null;for(t=0;i;){t++;let o=i,a=0;for(let c=0;c<e&&(a++,o=o.nextZ,!!o);c++);let l=e;for(;a>0||l>0&&o;)a!==0&&(l===0||!o||i.z<=o.z)?(n=i,i=i.nextZ,a--):(n=o,o=o.nextZ,l--),s?s.nextZ=n:r=n,n.prevZ=s,s=n;i=o}s.nextZ=null,e*=2}while(t>1);return r}function Oa(r,t,e,i,n){return r=(r-e)*n|0,t=(t-i)*n|0,r=(r|r<<8)&16711935,r=(r|r<<4)&252645135,r=(r|r<<2)&858993459,r=(r|r<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,r|t<<1}function Vd(r){let t=r,e=r;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==r);return e}function kh(r,t,e,i,n,s,o,a){return(n-o)*(t-a)>=(r-o)*(s-a)&&(r-o)*(i-a)>=(e-o)*(t-a)&&(e-o)*(s-a)>=(n-o)*(i-a)}function Cs(r,t,e,i,n,s,o,a){return!(r===o&&t===a)&&kh(r,t,e,i,n,s,o,a)}function Wd(r,t){return r.next.i!==t.i&&r.prev.i!==t.i&&!Xd(r,t)&&(Ws(r,t)&&Ws(t,r)&&qd(r,t)&&(Se(r.prev,r,t.prev)||Se(r,t.prev,t))||as(r,t)&&Se(r.prev,r,r.next)>0&&Se(t.prev,t,t.next)>0)}function Se(r,t,e){return(t.y-r.y)*(e.x-t.x)-(t.x-r.x)*(e.y-t.y)}function as(r,t){return r.x===t.x&&r.y===t.y}function Gh(r,t,e,i){const n=br(Se(r,t,e)),s=br(Se(r,t,i)),o=br(Se(e,i,r)),a=br(Se(e,i,t));return!!(n!==s&&o!==a||n===0&&wr(r,e,t)||s===0&&wr(r,i,t)||o===0&&wr(e,r,i)||a===0&&wr(e,t,i))}function wr(r,t,e){return t.x<=Math.max(r.x,e.x)&&t.x>=Math.min(r.x,e.x)&&t.y<=Math.max(r.y,e.y)&&t.y>=Math.min(r.y,e.y)}function br(r){return r>0?1:r<0?-1:0}function Xd(r,t){let e=r;do{if(e.i!==r.i&&e.next.i!==r.i&&e.i!==t.i&&e.next.i!==t.i&&Gh(e,e.next,r,t))return!0;e=e.next}while(e!==r);return!1}function Ws(r,t){return Se(r.prev,r,r.next)<0?Se(r,t,r.next)>=0&&Se(r,r.prev,t)>=0:Se(r,t,r.prev)<0||Se(r,r.next,t)<0}function qd(r,t){let e=r,i=!1;const n=(r.x+t.x)/2,s=(r.y+t.y)/2;do e.y>s!=e.next.y>s&&e.next.y!==e.y&&n<(e.next.x-e.x)*(s-e.y)/(e.next.y-e.y)+e.x&&(i=!i),e=e.next;while(e!==r);return i}function Hh(r,t){const e=Ba(r.i,r.x,r.y),i=Ba(t.i,t.x,t.y),n=r.next,s=t.prev;return r.next=t,t.prev=r,e.next=n,n.prev=e,i.next=e,e.prev=i,s.next=i,i.prev=s,i}function ac(r,t,e,i){const n=Ba(r,t,e);return i?(n.next=i.next,n.prev=i,i.next.prev=n,i.next=n):(n.prev=n,n.next=n),n}function Xs(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function Ba(r,t,e){return{i:r,x:t,y:e,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Yd(r,t,e,i){let n=0;for(let s=t,o=e-i;s<e;s+=i)n+=(r[o]-r[s])*(r[s+1]+r[o+1]),o=s;return n}class $d{static triangulate(t,e,i=2){return Ld(t,e,i)}}class Ns{static area(t){const e=t.length;let i=0;for(let n=e-1,s=0;s<e;n=s++)i+=t[n].x*t[s].y-t[s].x*t[n].y;return i*.5}static isClockWise(t){return Ns.area(t)<0}static triangulateShape(t,e){const i=[],n=[],s=[];lc(t),cc(i,t);let o=t.length;e.forEach(lc);for(let l=0;l<e.length;l++)n.push(o),o+=e[l].length,cc(i,e[l]);const a=$d.triangulate(i,n);for(let l=0;l<a.length;l+=3)s.push(a.slice(l,l+3));return s}}function lc(r){const t=r.length;t>2&&r[t-1].equals(r[0])&&r.pop()}function cc(r,t){for(let e=0;e<t.length;e++)r.push(t[e].x),r.push(t[e].y)}class Ks extends $s{constructor(t=1,e=0){const i=(1+Math.sqrt(5))/2,n=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(n,s,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Ks(t.radius,t.detail)}}class wn extends de{constructor(t=[new Q(0,-.5),new Q(.5,0),new Q(0,.5)],e=12,i=0,n=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:i,phiLength:n},e=Math.floor(e),n=Xt(n,0,Math.PI*2);const s=[],o=[],a=[],l=[],c=[],h=1/e,u=new R,d=new Q,f=new R,p=new R,v=new R;let m=0,g=0;for(let _=0;_<=t.length-1;_++)switch(_){case 0:m=t[_+1].x-t[_].x,g=t[_+1].y-t[_].y,f.x=g*1,f.y=-m,f.z=g*0,v.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case t.length-1:v.normalize(),l.push(v.x,v.y,v.z);break;default:m=t[_+1].x-t[_].x,g=t[_+1].y-t[_].y,f.x=g*1,f.y=-m,f.z=g*0,p.copy(f),f.x+=v.x,f.y+=v.y,f.z+=v.z,f.normalize(),l.push(f.x,f.y,f.z),v.copy(p)}for(let _=0;_<=e;_++){const M=i+_*h*n,y=Math.sin(M),E=Math.cos(M);for(let T=0;T<=t.length-1;T++){u.x=t[T].x*y,u.y=t[T].y,u.z=t[T].x*E,o.push(u.x,u.y,u.z),d.x=_/e,d.y=T/(t.length-1),a.push(d.x,d.y);const x=l[3*T+0]*y,w=l[3*T+1],P=l[3*T+0]*E;c.push(x,w,P)}}for(let _=0;_<e;_++)for(let M=0;M<t.length-1;M++){const y=M+_*t.length,E=y,T=y+t.length,x=y+t.length+1,w=y+1;s.push(E,T,w),s.push(x,w,T)}this.setIndex(s),this.setAttribute("position",new Kt(o,3)),this.setAttribute("uv",new Kt(a,2)),this.setAttribute("normal",new Kt(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new wn(t.points,t.segments,t.phiStart,t.phiLength)}}class cl extends $s{constructor(t=1,e=0){const i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],n=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,n,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new cl(t.radius,t.detail)}}class be extends de{constructor(t=1,e=1,i=1,n=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:n};const s=t/2,o=e/2,a=Math.floor(i),l=Math.floor(n),c=a+1,h=l+1,u=t/a,d=e/l,f=[],p=[],v=[],m=[];for(let g=0;g<h;g++){const _=g*d-o;for(let M=0;M<c;M++){const y=M*u-s;p.push(y,-_,0),v.push(0,0,1),m.push(M/a),m.push(1-g/l)}}for(let g=0;g<l;g++)for(let _=0;_<a;_++){const M=_+c*g,y=_+c*(g+1),E=_+1+c*(g+1),T=_+1+c*g;f.push(M,y,T),f.push(y,E,T)}this.setIndex(f),this.setAttribute("position",new Kt(p,3)),this.setAttribute("normal",new Kt(v,3)),this.setAttribute("uv",new Kt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new be(t.width,t.height,t.widthSegments,t.heightSegments)}}class Zr extends de{constructor(t=.5,e=1,i=32,n=1,s=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:n,thetaStart:s,thetaLength:o},i=Math.max(3,i),n=Math.max(1,n);const a=[],l=[],c=[],h=[];let u=t;const d=(e-t)/n,f=new R,p=new Q;for(let v=0;v<=n;v++){for(let m=0;m<=i;m++){const g=s+m/i*o;f.x=u*Math.cos(g),f.y=u*Math.sin(g),l.push(f.x,f.y,f.z),c.push(0,0,1),p.x=(f.x/e+1)/2,p.y=(f.y/e+1)/2,h.push(p.x,p.y)}u+=d}for(let v=0;v<n;v++){const m=v*(i+1);for(let g=0;g<i;g++){const _=g+m,M=_,y=_+i+1,E=_+i+2,T=_+1;a.push(M,y,T),a.push(y,E,T)}}this.setIndex(a),this.setAttribute("position",new Kt(l,3)),this.setAttribute("normal",new Kt(c,3)),this.setAttribute("uv",new Kt(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Zr(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class hl extends de{constructor(t=new Bh([new Q(0,.5),new Q(-.5,-.5),new Q(.5,-.5)]),e=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:e};const i=[],n=[],s=[],o=[];let a=0,l=0;if(Array.isArray(t)===!1)c(t);else for(let h=0;h<t.length;h++)c(t[h]),this.addGroup(a,l,h),a+=l,l=0;this.setIndex(i),this.setAttribute("position",new Kt(n,3)),this.setAttribute("normal",new Kt(s,3)),this.setAttribute("uv",new Kt(o,2));function c(h){const u=n.length/3,d=h.extractPoints(e);let f=d.shape;const p=d.holes;Ns.isClockWise(f)===!1&&(f=f.reverse());for(let m=0,g=p.length;m<g;m++){const _=p[m];Ns.isClockWise(_)===!0&&(p[m]=_.reverse())}const v=Ns.triangulateShape(f,p);for(let m=0,g=p.length;m<g;m++){const _=p[m];f=f.concat(_)}for(let m=0,g=f.length;m<g;m++){const _=f[m];n.push(_.x,_.y,0),s.push(0,0,1),o.push(_.x,_.y)}for(let m=0,g=v.length;m<g;m++){const _=v[m],M=_[0]+u,y=_[1]+u,E=_[2]+u;i.push(M,y,E),l+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON(),e=this.parameters.shapes;return Kd(e,t)}static fromJSON(t,e){const i=[];for(let n=0,s=t.shapes.length;n<s;n++){const o=e[t.shapes[n]];i.push(o)}return new hl(i,t.curveSegments)}}function Kd(r,t){if(t.shapes=[],Array.isArray(r))for(let e=0,i=r.length;e<i;e++){const n=r[e];t.shapes.push(n.uuid)}else t.shapes.push(r.uuid);return t}class It extends de{constructor(t=1,e=32,i=16,n=0,s=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:n,phiLength:s,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));const l=Math.min(o+a,Math.PI);let c=0;const h=[],u=new R,d=new R,f=[],p=[],v=[],m=[];for(let g=0;g<=i;g++){const _=[],M=g/i,y=o+M*a,E=t*Math.cos(y),T=Math.sqrt(t*t-E*E);let x=0;g===0&&o===0?x=.5/e:g===i&&l===Math.PI&&(x=-.5/e);for(let w=0;w<=e;w++){const P=w/e,C=n+P*s;u.x=-T*Math.cos(C),u.y=E,u.z=T*Math.sin(C),p.push(u.x,u.y,u.z),d.copy(u).normalize(),v.push(d.x,d.y,d.z),m.push(P+x,1-M),_.push(c++)}h.push(_)}for(let g=0;g<i;g++)for(let _=0;_<e;_++){const M=h[g][_+1],y=h[g][_],E=h[g+1][_],T=h[g+1][_+1];(g!==0||o>0)&&f.push(M,y,T),(g!==i-1||l<Math.PI)&&f.push(y,E,T)}this.setIndex(f),this.setAttribute("position",new Kt(p,3)),this.setAttribute("normal",new Kt(v,3)),this.setAttribute("uv",new Kt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new It(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class We extends de{constructor(t=1,e=.4,i=12,n=48,s=Math.PI*2,o=0,a=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:n,arc:s,thetaStart:o,thetaLength:a},i=Math.floor(i),n=Math.floor(n);const l=[],c=[],h=[],u=[],d=new R,f=new R,p=new R;for(let v=0;v<=i;v++){const m=o+v/i*a;for(let g=0;g<=n;g++){const _=g/n*s;f.x=(t+e*Math.cos(m))*Math.cos(_),f.y=(t+e*Math.cos(m))*Math.sin(_),f.z=e*Math.sin(m),c.push(f.x,f.y,f.z),d.x=t*Math.cos(_),d.y=t*Math.sin(_),p.subVectors(f,d).normalize(),h.push(p.x,p.y,p.z),u.push(g/n),u.push(v/i)}}for(let v=1;v<=i;v++)for(let m=1;m<=n;m++){const g=(n+1)*v+m-1,_=(n+1)*(v-1)+m-1,M=(n+1)*(v-1)+m,y=(n+1)*v+m;l.push(g,_,y),l.push(_,M,y)}this.setIndex(l),this.setAttribute("position",new Kt(c,3)),this.setAttribute("normal",new Kt(h,3)),this.setAttribute("uv",new Kt(u,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new We(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}}class eo extends de{constructor(t=new Fh(new R(-1,-1,0),new R(-1,1,0),new R(1,1,0)),e=64,i=1,n=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:i,radialSegments:n,closed:s};const o=t.computeFrenetFrames(e,s);this.tangents=o.tangents,this.normals=o.normals,this.binormals=o.binormals;const a=new R,l=new R,c=new Q;let h=new R;const u=[],d=[],f=[],p=[];v(),this.setIndex(p),this.setAttribute("position",new Kt(u,3)),this.setAttribute("normal",new Kt(d,3)),this.setAttribute("uv",new Kt(f,2));function v(){for(let M=0;M<e;M++)m(M);m(s===!1?e:0),_(),g()}function m(M){h=t.getPointAt(M/e,h);const y=o.normals[M],E=o.binormals[M];for(let T=0;T<=n;T++){const x=T/n*Math.PI*2,w=Math.sin(x),P=-Math.cos(x);l.x=P*y.x+w*E.x,l.y=P*y.y+w*E.y,l.z=P*y.z+w*E.z,l.normalize(),d.push(l.x,l.y,l.z),a.x=h.x+i*l.x,a.y=h.y+i*l.y,a.z=h.z+i*l.z,u.push(a.x,a.y,a.z)}}function g(){for(let M=1;M<=e;M++)for(let y=1;y<=n;y++){const E=(n+1)*(M-1)+(y-1),T=(n+1)*M+(y-1),x=(n+1)*M+y,w=(n+1)*(M-1)+y;p.push(E,T,w),p.push(T,x,w)}}function _(){for(let M=0;M<=e;M++)for(let y=0;y<=n;y++)c.x=M/e,c.y=y/n,f.push(c.x,c.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new eo(new Fa[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}function ls(r){const t={};for(const e in r){t[e]={};for(const i in r[e]){const n=r[e][i];if(hc(n))n.isRenderTargetTexture?(Bt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][i]=null):t[e][i]=n.clone();else if(Array.isArray(n))if(hc(n[0])){const s=[];for(let o=0,a=n.length;o<a;o++)s[o]=n[o].clone();t[e][i]=s}else t[e][i]=n.slice();else t[e][i]=n}}return t}function ii(r){const t={};for(let e=0;e<r.length;e++){const i=ls(r[e]);for(const n in i)t[n]=i[n]}return t}function hc(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function Zd(r){const t=[];for(let e=0;e<r.length;e++)t.push(r[e].clone());return t}function Vh(r){const t=r.getRenderTarget();return t===null?r.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Qt.workingColorSpace}const Jd={clone:ls,merge:ii};var jd=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Qd=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Qe extends Pn{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=jd,this.fragmentShader=Qd,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=ls(t.uniforms),this.uniformsGroups=Zd(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const n in this.uniforms){const o=this.uniforms[n].value;o&&o.isTexture?e.uniforms[n]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[n]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[n]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[n]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[n]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[n]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[n]={type:"m4",value:o.toArray()}:e.uniforms[n]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const i={};for(const n in this.extensions)this.extensions[n]===!0&&(i[n]=!0);return Object.keys(i).length>0&&(e.extensions=i),e}fromJSON(t,e){if(super.fromJSON(t,e),t.uniforms!==void 0)for(const i in t.uniforms){const n=t.uniforms[i];switch(this.uniforms[i]={},n.type){case"t":this.uniforms[i].value=e[n.value]||null;break;case"c":this.uniforms[i].value=new ct().setHex(n.value);break;case"v2":this.uniforms[i].value=new Q().fromArray(n.value);break;case"v3":this.uniforms[i].value=new R().fromArray(n.value);break;case"v4":this.uniforms[i].value=new Me().fromArray(n.value);break;case"m3":this.uniforms[i].value=new kt().fromArray(n.value);break;case"m4":this.uniforms[i].value=new te().fromArray(n.value);break;default:this.uniforms[i].value=n.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(const i in t.extensions)this.extensions[i]=t.extensions[i];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}}class tf extends Qe{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class st extends Pn{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new ct(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ct(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Ia,this.normalScale=new Q(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new dn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class qs extends st{constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Q(1,1),this.clearcoatNormalMap=null,this.diffuseRoughnessMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Xt(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessMinimum=100,this.iridescenceThicknessMaximum=400,this.iridescenceThicknessMap=null,this.sheenColor=new ct(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new ct(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new ct(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._diffuseRoughness=0,this._dispersion=0,this._iridescence=0,this._retroreflectivity=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get diffuseRoughness(){return this._diffuseRoughness}set diffuseRoughness(t){this._diffuseRoughness>0!=t>0&&this.version++,this._diffuseRoughness=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get retroreflectivity(){return this._retroreflectivity}set retroreflectivity(t){this._retroreflectivity>0!=t>0&&this.version++,this._retroreflectivity=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}get iridescenceThicknessRange(){return es('MeshPhysicalMaterial: The "iridescenceThicknessRange" property has been replaced by "iridescenceThicknessMinimum" and "iridescenceThicknessMaximum".'),[this.iridescenceThicknessMinimum,this.iridescenceThicknessMaximum]}set iridescenceThicknessRange(t){es('MeshPhysicalMaterial: The "iridescenceThicknessRange" property has been replaced by "iridescenceThicknessMinimum" and "iridescenceThicknessMaximum".'),this.iridescenceThicknessMinimum=t[0],this.iridescenceThicknessMaximum=t[1]}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.diffuseRoughness=t.diffuseRoughness,this.diffuseRoughnessMap=t.diffuseRoughnessMap,this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessMinimum=t.iridescenceThicknessMinimum,this.iridescenceThicknessMaximum=t.iridescenceThicknessMaximum,this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.retroreflectivity=t.retroreflectivity,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}}class ef extends Pn{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Fu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class nf extends Pn{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class io extends ue{static registerNode(t){this.prototype._lightNode=t}constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new ct(t),this.intensity=e}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,e}}class Bo extends io{constructor(t,e,i){super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ue.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ct(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}toJSON(t){const e=super.toJSON(t);return e.object.groundColor=this.groundColor.getHex(),e}}const zo=new te,uc=new R,dc=new R;class ul{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Q(512,512),this.mapType=pi,this.map=null,this.mapPass=null,this.matrix=new te,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new ks,this._frameExtents=new Q(1,1),this._viewportCount=1,this._viewports=[new Me(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera;uc.setFromMatrixPosition(t.matrixWorld),e.position.copy(uc),dc.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(dc),e.updateMatrixWorld(),this._updateMatrix(e,this.matrix,this._frustum)}_updateMatrix(t,e,i,n){zo.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),i.setFromProjectionMatrix(zo,t.coordinateSystem,t.reversedDepth);const s=this._frameExtents,o=n?n.z/s.x:1,a=n?n.w/s.y:1,l=n?n.x/s.x:0,c=n?n.y/s.y:0;t.coordinateSystem===zs||t.reversedDepth?e.set(.5*o,0,0,.5*o+l,0,.5*a,0,.5*a+c,0,0,1,0,0,0,0,1):e.set(.5*o,0,0,.5*o+l,0,.5*a,0,.5*a+c,0,0,.5,.5,0,0,0,1),e.multiply(zo)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.mapType=t.mapType,this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.mapType=this.mapType,t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const Er=new R,Tr=new un,Ci=new R;class Wh extends ue{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new te,this.projectionMatrix=new te,this.projectionMatrixInverse=new te,this.coordinateSystem=Ti,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(Er,Tr,Ci),Ci.x===1&&Ci.y===1&&Ci.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Er,Tr,Ci.set(1,1,1)).invert()}updateWorldMatrix(t,e,i=!1){super.updateWorldMatrix(t,e,i),this.matrixWorld.decompose(Er,Tr,Ci),Ci.x===1&&Ci.y===1&&Ci.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Er,Tr,Ci.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const sn=new R,fc=new Q,pc=new Q;class fi extends Wh{constructor(t=50,e=1,i=.1,n=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=n,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Yr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(zr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Yr*2*Math.atan(Math.tan(zr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,i){sn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(sn.x,sn.y).multiplyScalar(-t/sn.z),sn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(sn.x,sn.y).multiplyScalar(-t/sn.z)}getViewSize(t,e){return this.getViewBounds(t,fc,pc),e.subVectors(pc,fc)}setViewOffset(t,e,i,n,s,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(zr*.5*this.fov)/this.zoom,i=2*e,n=this.aspect*i,s=-.5*n;const o=this.view;if(this.view!==null&&this.view.enabled){const l=o.fullWidth,c=o.fullHeight;s+=o.offsetX*n/l,e-=o.offsetY*i/c,n*=o.width/l,i*=o.height/c}const a=this.filmOffset;a!==0&&(s+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+n,e,e-i,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}class sf extends ul{constructor(){super(new fi(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(t){const e=this.camera,i=Yr*2*t.angle*this.focus,n=this.mapSize.width/this.mapSize.height*this.aspect,s=t.distance||e.far;(i!==e.fov||n!==e.aspect||s!==e.far)&&(e.fov=i,e.aspect=n,e.far=s,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this.aspect=t.aspect,this}toJSON(){const t=super.toJSON();return t.focus=this.focus,t.aspect=this.aspect,t}}class za extends io{constructor(t,e,i=0,n=Math.PI/3,s=0,o=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(ue.DEFAULT_UP),this.updateMatrix(),this.target=new ue,this.distance=i,this.angle=n,this.penumbra=s,this.decay=o,this.map=null,this.shadow=new sf}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){super.dispose(),this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.map=t.map,this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.distance=this.distance,e.object.angle=this.angle,e.object.decay=this.decay,e.object.penumbra=this.penumbra,e.object.target=this.target.uuid,this.map&&this.map.isTexture&&(e.object.map=this.map.toJSON(t).uuid),e.object.shadow=this.shadow.toJSON(),e}}class rf extends ul{constructor(){super(new fi(90,1,.5,500)),this.isPointLightShadow=!0}}class Zi extends io{constructor(t,e,i=0,n=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=n,this.shadow=new rf}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.distance=this.distance,e.object.decay=this.decay,e.object.shadow=this.shadow.toJSON(),e}}class no extends Wh{constructor(t=-1,e=1,i=1,n=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=n,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,i,n,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,n=(this.top+this.bottom)/2;let s=i-t,o=i+t,a=n+e,l=n-e;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,o=s+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(s,o,a,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class of extends ul{constructor(){super(new no(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class ka extends io{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ue.DEFAULT_UP),this.updateMatrix(),this.target=new ue,this.shadow=new of}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.shadow=this.shadow.toJSON(),e.object.target=this.target.uuid,e}}const Yn=-90,$n=1;class Ga extends ue{constructor(t,e,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const n=new fi(Yn,$n,t,e);n.layers=this.layers,this.add(n);const s=new fi(Yn,$n,t,e);s.layers=this.layers,this.add(s);const o=new fi(Yn,$n,t,e);o.layers=this.layers,this.add(o);const a=new fi(Yn,$n,t,e);a.layers=this.layers,this.add(a);const l=new fi(Yn,$n,t,e);l.layers=this.layers,this.add(l);const c=new fi(Yn,$n,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[i,n,s,o,a,l]=e;for(const c of e)this.remove(c);if(t===Ti)i.up.set(0,1,0),i.lookAt(1,0,0),n.up.set(0,1,0),n.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===zs)i.up.set(0,-1,0),i.lookAt(-1,0,0),n.up.set(0,-1,0),n.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:n}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[s,o,a,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),p=t.xr.enabled;t.xr.enabled=!1;const v=i.texture.mipmapsAutoUpdate;i.texture.mipmapsAutoUpdate=!1;let m=!1;t.isWebGLRenderer===!0?m=t.state.buffers.depth.getReversed():m=t.reversedDepthBuffer,t.setRenderTarget(i,0,n),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,s),t.setRenderTarget(i,1,n),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,o),t.setRenderTarget(i,2,n),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,a),t.setRenderTarget(i,3,n),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,l),t.setRenderTarget(i,4,n),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,c),i.texture.mipmapsAutoUpdate=v,t.setRenderTarget(i,5,n),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=p,i.texture.needsPMREMUpdate=!0}}class af extends fi{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t,this.perCameraFrustumCulled=!1}}const mc=new te;class Xh{constructor(t,e,i=0,n=1/0){this.ray=new to(t,e),this.near=i,this.far=n,this.camera=null,this.layers=new el,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,e.projectionMatrix.elements[14]).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):se("Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return mc.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(mc),this}intersectObject(t,e=!0,i=[]){return Ha(t,this,i,e),i.sort(gc),i}intersectObjects(t,e=!0,i=[]){for(let n=0,s=t.length;n<s;n++)Ha(t[n],this,i,e);return i.sort(gc),i}}function gc(r,t){return r.distance-t.distance}function Ha(r,t,e,i){let n=!0;if(r.layers.test(t.layers)&&r.raycast(t,e)===!1&&(n=!1),n===!0&&i===!0){const s=r.children;for(let o=0,a=s.length;o<a;o++)Ha(s[o],t,e,!0)}}class vc{constructor(t=1,e=0,i=0){this.radius=t,this.phi=e,this.theta=i}set(t,e,i){return this.radius=t,this.phi=e,this.theta=i,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Xt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,i){return this.radius=Math.sqrt(t*t+e*e+i*i),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,i),this.phi=Math.acos(Xt(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class lf extends fn{constructor(t,e=null){super(),this.object=t,this.domElement=e,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(t){this.domElement!==null&&this.disconnect(),this.domElement=t}disconnect(){}dispose(){}update(){}}function _c(r,t,e,i){const n=cf(i);switch(e){case ph:return r*t;case Za:return r*t/n.components*n.byteLength;case Ja:return r*t/n.components*n.byteLength;case Tn:return r*t*2/n.components*n.byteLength;case ja:return r*t*2/n.components*n.byteLength;case mh:return r*t*3/n.components*n.byteLength;case Ni:return r*t*4/n.components*n.byteLength;case Qa:return r*t*4/n.components*n.byteLength;case Ur:case Fr:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case Or:case Br:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case sa:case oa:return Math.max(r,16)*Math.max(t,8)/4;case na:case ra:return Math.max(r,8)*Math.max(t,8)/2;case aa:case la:case ha:case ua:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case ca:case Gr:case da:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case fa:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case pa:return Math.floor((r+4)/5)*Math.floor((t+3)/4)*16;case ma:return Math.floor((r+4)/5)*Math.floor((t+4)/5)*16;case ga:return Math.floor((r+5)/6)*Math.floor((t+4)/5)*16;case va:return Math.floor((r+5)/6)*Math.floor((t+5)/6)*16;case _a:return Math.floor((r+7)/8)*Math.floor((t+4)/5)*16;case xa:return Math.floor((r+7)/8)*Math.floor((t+5)/6)*16;case ya:return Math.floor((r+7)/8)*Math.floor((t+7)/8)*16;case Ma:return Math.floor((r+9)/10)*Math.floor((t+4)/5)*16;case Sa:return Math.floor((r+9)/10)*Math.floor((t+5)/6)*16;case wa:return Math.floor((r+9)/10)*Math.floor((t+7)/8)*16;case ba:return Math.floor((r+9)/10)*Math.floor((t+9)/10)*16;case Ea:return Math.floor((r+11)/12)*Math.floor((t+9)/10)*16;case Ta:return Math.floor((r+11)/12)*Math.floor((t+11)/12)*16;case Aa:case Ra:case Ca:return Math.ceil(r/4)*Math.ceil(t/4)*16;case Pa:case La:return Math.ceil(r/4)*Math.ceil(t/4)*8;case Hr:case Da:return Math.ceil(r/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function cf(r){switch(r){case pi:case hh:return{byteLength:1,components:1};case Bs:case uh:case Oi:return{byteLength:2,components:1};case $a:case Ka:return{byteLength:2,components:4};case Fi:case Ya:case Ei:return{byteLength:4,components:1};case dh:case fh:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Xa}}));typeof window<"u"&&(window.__THREE__?Bt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Xa);function qh(){let r=null,t=!1,e=null,i=null;function n(s,o){i=r.requestAnimationFrame(n),e(s,o)}return{start:function(){t!==!0&&e!==null&&r!==null&&(i=r.requestAnimationFrame(n),t=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(s){e=s},setContext:function(s){r=s}}}function hf(r){const t=new WeakMap;function e(a,l){const c=a.array,h=a.usage,u=c.byteLength,d=r.createBuffer();r.bindBuffer(l,d),r.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=r.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=r.HALF_FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=r.HALF_FLOAT:f=r.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=r.SHORT;else if(c instanceof Uint32Array)f=r.UNSIGNED_INT;else if(c instanceof Int32Array)f=r.INT;else if(c instanceof Int8Array)f=r.BYTE;else if(c instanceof Uint8Array)f=r.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function i(a,l,c){const h=l.array,u=l.updateRanges;if(r.bindBuffer(c,a),u.length===0)r.bufferSubData(c,0,h);else{u.sort((f,p)=>f.start-p.start);let d=0;for(let f=1;f<u.length;f++){const p=u[d],v=u[f];v.start<=p.start+p.count+1?p.count=Math.max(p.count,v.start+v.count-p.start):(++d,u[d]=v)}u.length=d+1;for(let f=0,p=u.length;f<p;f++){const v=u[f];r.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function n(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function s(a){a.isInterleavedBufferAttribute&&(a=a.data);const l=t.get(a);l&&(r.deleteBuffer(l.buffer),t.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const c=t.get(a);if(c===void 0)t.set(a,e(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(c.buffer,a,l),c.version=a.version}}return{get:n,remove:s,update:o}}var uf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,df=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,ff=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,pf=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,mf=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,gf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,vf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,_f=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,xf=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,yf=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Mf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Sf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,wf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,bf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Ef=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Tf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Af=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Rf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Cf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Pf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Lf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Df=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,If=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Nf=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Uf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,Ff=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Of=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Bf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,zf=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,kf="gl_FragColor = linearToOutputTexel( gl_FragColor );",Gf=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Hf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Vf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,Wf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Xf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,qf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Yf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,$f=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Kf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Zf=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Jf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,jf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Qf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,tp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,ep=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,ip=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,np=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,sp=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,rp=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,op=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ap=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lp=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,cp=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,hp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,up=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,dp=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,fp=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,pp=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,mp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,gp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,vp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,_p=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,xp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,yp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Mp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Sp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,wp=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,bp=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Ep=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Tp=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Ap=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Rp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Cp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Pp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Lp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Dp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,Ip=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Np=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Up=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Fp=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Op=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Bp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,zp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,kp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Gp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Hp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Vp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Wp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Xp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,qp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Yp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,$p=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Kp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Zp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Jp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,jp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Qp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,t0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,e0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,i0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,n0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,s0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,r0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,o0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,a0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,l0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,c0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const h0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,u0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,d0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,f0=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,p0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,m0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,g0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,v0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,_0=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,x0=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,y0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,M0=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,S0=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,w0=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,b0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,E0=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,T0=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,A0=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,R0=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,C0=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,P0=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,L0=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,D0=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,I0=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,N0=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,U0=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,F0=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,O0=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,B0=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,z0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,k0=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,G0=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,H0=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,V0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Yt={alphahash_fragment:uf,alphahash_pars_fragment:df,alphamap_fragment:ff,alphamap_pars_fragment:pf,alphatest_fragment:mf,alphatest_pars_fragment:gf,aomap_fragment:vf,aomap_pars_fragment:_f,batching_pars_vertex:xf,batching_vertex:yf,begin_vertex:Mf,beginnormal_vertex:Sf,bsdfs:wf,iridescence_fragment:bf,bumpmap_pars_fragment:Ef,clipping_planes_fragment:Tf,clipping_planes_pars_fragment:Af,clipping_planes_pars_vertex:Rf,clipping_planes_vertex:Cf,color_fragment:Pf,color_pars_fragment:Lf,color_pars_vertex:Df,color_vertex:If,common:Nf,defaultnormal_vertex:Uf,displacementmap_pars_vertex:Ff,displacementmap_vertex:Of,emissivemap_fragment:Bf,emissivemap_pars_fragment:zf,colorspace_fragment:kf,colorspace_pars_fragment:Gf,envmap_fragment:Hf,envmap_common_pars_fragment:Vf,envmap_pars_fragment:Wf,envmap_pars_vertex:Xf,envmap_physical_pars_fragment:ip,envmap_vertex:qf,fog_vertex:Yf,fog_pars_vertex:$f,fog_fragment:Kf,fog_pars_fragment:Zf,gradientmap_pars_fragment:Jf,lightmap_pars_fragment:jf,lights_lambert_fragment:Qf,lights_lambert_pars_fragment:tp,lights_pars_begin:ep,lights_toon_fragment:np,lights_toon_pars_fragment:sp,lights_phong_fragment:rp,lights_phong_pars_fragment:op,lights_physical_fragment:ap,lights_physical_pars_fragment:lp,lights_fragment_begin:cp,lights_fragment_maps:hp,lights_fragment_end:up,lightprobes_pars_fragment:dp,logdepthbuf_fragment:fp,logdepthbuf_pars_fragment:pp,logdepthbuf_pars_vertex:mp,logdepthbuf_vertex:gp,map_fragment:vp,map_pars_fragment:_p,map_particle_fragment:xp,map_particle_pars_fragment:yp,metalnessmap_fragment:Mp,metalnessmap_pars_fragment:Sp,morphinstance_vertex:wp,morphcolor_vertex:bp,morphnormal_vertex:Ep,morphtarget_pars_vertex:Tp,morphtarget_vertex:Ap,normal_fragment_begin:Rp,normal_fragment_maps:Cp,normal_pars_fragment:Pp,normal_pars_vertex:Lp,normal_vertex:Dp,normalmap_pars_fragment:Ip,clearcoat_normal_fragment_begin:Np,clearcoat_normal_fragment_maps:Up,clearcoat_pars_fragment:Fp,iridescence_pars_fragment:Op,opaque_fragment:Bp,packing:zp,premultiplied_alpha_fragment:kp,project_vertex:Gp,dithering_fragment:Hp,dithering_pars_fragment:Vp,roughnessmap_fragment:Wp,roughnessmap_pars_fragment:Xp,shadowmap_pars_fragment:qp,shadowmap_pars_vertex:Yp,shadowmap_vertex:$p,shadowmask_pars_fragment:Kp,skinbase_vertex:Zp,skinning_pars_vertex:Jp,skinning_vertex:jp,skinnormal_vertex:Qp,specularmap_fragment:t0,specularmap_pars_fragment:e0,tonemapping_fragment:i0,tonemapping_pars_fragment:n0,transmission_fragment:s0,transmission_pars_fragment:r0,uv_pars_fragment:o0,uv_pars_vertex:a0,uv_vertex:l0,worldpos_vertex:c0,background_vert:h0,background_frag:u0,backgroundCube_vert:d0,backgroundCube_frag:f0,cube_vert:p0,cube_frag:m0,depth_vert:g0,depth_frag:v0,distance_vert:_0,distance_frag:x0,equirect_vert:y0,equirect_frag:M0,linedashed_vert:S0,linedashed_frag:w0,meshbasic_vert:b0,meshbasic_frag:E0,meshlambert_vert:T0,meshlambert_frag:A0,meshmatcap_vert:R0,meshmatcap_frag:C0,meshnormal_vert:P0,meshnormal_frag:L0,meshphong_vert:D0,meshphong_frag:I0,meshphysical_vert:N0,meshphysical_frag:U0,meshtoon_vert:F0,meshtoon_frag:O0,points_vert:B0,points_frag:z0,shadow_vert:k0,shadow_frag:G0,sprite_vert:H0,sprite_frag:V0},xt={common:{diffuse:{value:new ct(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new kt},alphaMap:{value:null},alphaMapTransform:{value:new kt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new kt}},envmap:{envMap:{value:null},envMapRotation:{value:new kt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new kt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new kt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new kt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new kt},normalScale:{value:new Q(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new kt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new kt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new kt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new kt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ct(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new ct(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new kt},alphaTest:{value:0},uvTransform:{value:new kt}},sprite:{diffuse:{value:new ct(16777215)},opacity:{value:1},center:{value:new Q(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new kt},alphaMap:{value:null},alphaMapTransform:{value:new kt},alphaTest:{value:0}}},Di={basic:{uniforms:ii([xt.common,xt.specularmap,xt.envmap,xt.aomap,xt.lightmap,xt.fog]),vertexShader:Yt.meshbasic_vert,fragmentShader:Yt.meshbasic_frag},lambert:{uniforms:ii([xt.common,xt.specularmap,xt.envmap,xt.aomap,xt.lightmap,xt.emissivemap,xt.bumpmap,xt.normalmap,xt.displacementmap,xt.fog,xt.lights,{emissive:{value:new ct(0)},envMapIntensity:{value:1}}]),vertexShader:Yt.meshlambert_vert,fragmentShader:Yt.meshlambert_frag},phong:{uniforms:ii([xt.common,xt.specularmap,xt.envmap,xt.aomap,xt.lightmap,xt.emissivemap,xt.bumpmap,xt.normalmap,xt.displacementmap,xt.fog,xt.lights,{emissive:{value:new ct(0)},specular:{value:new ct(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Yt.meshphong_vert,fragmentShader:Yt.meshphong_frag},standard:{uniforms:ii([xt.common,xt.envmap,xt.aomap,xt.lightmap,xt.emissivemap,xt.bumpmap,xt.normalmap,xt.displacementmap,xt.roughnessmap,xt.metalnessmap,xt.fog,xt.lights,{emissive:{value:new ct(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag},toon:{uniforms:ii([xt.common,xt.aomap,xt.lightmap,xt.emissivemap,xt.bumpmap,xt.normalmap,xt.displacementmap,xt.gradientmap,xt.fog,xt.lights,{emissive:{value:new ct(0)}}]),vertexShader:Yt.meshtoon_vert,fragmentShader:Yt.meshtoon_frag},matcap:{uniforms:ii([xt.common,xt.bumpmap,xt.normalmap,xt.displacementmap,xt.fog,{matcap:{value:null}}]),vertexShader:Yt.meshmatcap_vert,fragmentShader:Yt.meshmatcap_frag},points:{uniforms:ii([xt.points,xt.fog]),vertexShader:Yt.points_vert,fragmentShader:Yt.points_frag},dashed:{uniforms:ii([xt.common,xt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Yt.linedashed_vert,fragmentShader:Yt.linedashed_frag},depth:{uniforms:ii([xt.common,xt.displacementmap]),vertexShader:Yt.depth_vert,fragmentShader:Yt.depth_frag},normal:{uniforms:ii([xt.common,xt.bumpmap,xt.normalmap,xt.displacementmap,{opacity:{value:1}}]),vertexShader:Yt.meshnormal_vert,fragmentShader:Yt.meshnormal_frag},sprite:{uniforms:ii([xt.sprite,xt.fog]),vertexShader:Yt.sprite_vert,fragmentShader:Yt.sprite_frag},background:{uniforms:{uvTransform:{value:new kt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Yt.background_vert,fragmentShader:Yt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new kt}},vertexShader:Yt.backgroundCube_vert,fragmentShader:Yt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Yt.cube_vert,fragmentShader:Yt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Yt.equirect_vert,fragmentShader:Yt.equirect_frag},distance:{uniforms:ii([xt.common,xt.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Yt.distance_vert,fragmentShader:Yt.distance_frag},shadow:{uniforms:ii([xt.lights,xt.fog,{color:{value:new ct(0)},opacity:{value:1}}]),vertexShader:Yt.shadow_vert,fragmentShader:Yt.shadow_frag}};Di.physical={uniforms:ii([Di.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new kt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new kt},clearcoatNormalScale:{value:new Q(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new kt},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new kt},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new kt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new kt},sheen:{value:0},sheenColor:{value:new ct(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new kt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new kt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new kt},transmissionSamplerSize:{value:new Q},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new kt},attenuationDistance:{value:0},attenuationColor:{value:new ct(0)},specularColor:{value:new ct(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new kt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new kt},anisotropyVector:{value:new Q},anisotropyMap:{value:null},anisotropyMapTransform:{value:new kt}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag};const Ar={r:0,b:0,g:0},W0=new te,Yh=new kt;Yh.set(-1,0,0,0,1,0,0,0,1);function X0(r,t,e,i,n,s){const o=new ct(0);let a=n===!0?0:1,l,c,h=null,u=0,d=null;function f(_){let M=_.isScene===!0?_.background:null;if(M&&M.isTexture){const y=_.backgroundBlurriness>0;M=t.get(M,y)}return M}function p(_){let M=!1;const y=f(_);y===null?m(o,a):y&&y.isColor&&(m(y,1),M=!0);const E=r.xr.getEnvironmentBlendMode();E==="additive"?e.buffers.color.setClear(0,0,0,1,s):E==="alpha-blend"&&e.buffers.color.setClear(0,0,0,0,s),(r.autoClear||M)&&(e.buffers.depth.setTest(!0),e.buffers.depth.setMask(!0),e.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function v(_,M){const y=f(M);y&&y.isCubeTexture?(c===void 0&&(c=new I(new ne(1,1,1),new Qe({name:"BackgroundCubeMaterial",uniforms:ls(Di.backgroundCube.uniforms),vertexShader:Di.backgroundCube.vertexShader,fragmentShader:Di.backgroundCube.fragmentShader,side:Je,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(E,T,x){this.matrixWorld.copyPosition(x.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(c)),c.material.uniforms.envMap.value=y,c.material.uniforms.backgroundBlurriness.value=M.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(W0.makeRotationFromEuler(M.backgroundRotation)).transpose(),y.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Yh),c.material.toneMapped=Qt.getTransfer(y.colorSpace)!==he,(h!==y||u!==y.version||d!==r.toneMapping)&&(c.material.needsUpdate=!0,h=y,u=y.version,d=r.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new I(new be(2,2),new Qe({name:"BackgroundMaterial",uniforms:ls(Di.background.uniforms),vertexShader:Di.background.vertexShader,fragmentShader:Di.background.fragmentShader,side:cn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,l.material.toneMapped=Qt.getTransfer(y.colorSpace)!==he,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(h!==y||u!==y.version||d!==r.toneMapping)&&(l.material.needsUpdate=!0,h=y,u=y.version,d=r.toneMapping),l.layers.enableAll(),_.unshift(l,l.geometry,l.material,0,0,null))}function m(_,M){_.getRGB(Ar,Vh(r)),e.buffers.color.setClear(Ar.r,Ar.g,Ar.b,M,s)}function g(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return o},setClearColor:function(_,M=1){o.set(_),a=M,m(o,a)},getClearAlpha:function(){return a},setClearAlpha:function(_){a=_,m(o,a)},render:p,addToRenderList:v,dispose:g}}function q0(r,t){const e=r.getParameter(r.MAX_VERTEX_ATTRIBS),i={},n=d(null);let s=n,o=!1;function a(U,B,V,D,H){let Y=!1;const F=u(U,D,V,B);s!==F&&(s=F,c(s.object)),Y=f(U,D,V,H),Y&&p(U,D,V,H),H!==null&&t.update(H,r.ELEMENT_ARRAY_BUFFER),(Y||o)&&(o=!1,y(U,B,V,D),H!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(H).buffer))}function l(){return r.createVertexArray()}function c(U){return r.bindVertexArray(U)}function h(U){return r.deleteVertexArray(U)}function u(U,B,V,D){const H=D.wireframe===!0;let Y=i[B.id];Y===void 0&&(Y={},i[B.id]=Y);const F=U.isInstancedMesh===!0?U.id:0;let et=Y[F];et===void 0&&(et={},Y[F]=et);let X=et[V.id];X===void 0&&(X={},et[V.id]=X);let tt=X[H];return tt===void 0&&(tt=d(l()),X[H]=tt),tt}function d(U){const B=[],V=[],D=[];for(let H=0;H<e;H++)B[H]=0,V[H]=0,D[H]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:V,attributeDivisors:D,object:U,attributes:{},index:null}}function f(U,B,V,D){const H=s.attributes,Y=B.attributes;let F=0;const et=V.getAttributes();for(const X in et)if(et[X].location>=0){const it=H[X];let Rt=Y[X];if(Rt===void 0&&(X==="instanceMatrix"&&U.instanceMatrix&&(Rt=U.instanceMatrix),X==="instanceColor"&&U.instanceColor&&(Rt=U.instanceColor)),it===void 0||it.attribute!==Rt||Rt&&it.data!==Rt.data)return!0;F++}return s.attributesNum!==F||s.index!==D}function p(U,B,V,D){const H={},Y=B.attributes;let F=0;const et=V.getAttributes();for(const X in et)if(et[X].location>=0){let it=Y[X];it===void 0&&(X==="instanceMatrix"&&U.instanceMatrix&&(it=U.instanceMatrix),X==="instanceColor"&&U.instanceColor&&(it=U.instanceColor));const Rt={};Rt.attribute=it,it&&it.data&&(Rt.data=it.data),H[X]=Rt,F++}s.attributes=H,s.attributesNum=F,s.index=D}function v(){const U=s.newAttributes;for(let B=0,V=U.length;B<V;B++)U[B]=0}function m(U){g(U,0)}function g(U,B){const V=s.newAttributes,D=s.enabledAttributes,H=s.attributeDivisors;V[U]=1,D[U]===0&&(r.enableVertexAttribArray(U),D[U]=1),H[U]!==B&&(r.vertexAttribDivisor(U,B),H[U]=B)}function _(){const U=s.newAttributes,B=s.enabledAttributes;for(let V=0,D=B.length;V<D;V++)B[V]!==U[V]&&(r.disableVertexAttribArray(V),B[V]=0)}function M(U,B,V,D,H,Y,F){F===!0?r.vertexAttribIPointer(U,B,V,H,Y):r.vertexAttribPointer(U,B,V,D,H,Y)}function y(U,B,V,D){v();const H=D.attributes,Y=V.getAttributes(),F=B.defaultAttributeValues;for(const et in Y){const X=Y[et];if(X.location>=0){let tt=H[et];if(tt===void 0&&(et==="instanceMatrix"&&U.instanceMatrix&&(tt=U.instanceMatrix),et==="instanceColor"&&U.instanceColor&&(tt=U.instanceColor)),tt!==void 0){const it=tt.normalized,Rt=tt.itemSize,Gt=t.get(tt);if(Gt===void 0)continue;const Z=Gt.buffer,yt=Gt.type,Et=Gt.bytesPerElement,Nt=yt===r.INT||yt===r.UNSIGNED_INT||tt.gpuType===Ya;if(tt.isInterleavedBufferAttribute){const Mt=tt.data,Vt=Mt.isInterleavedBuffer===!0?Mt.stride:Mt.itemSize,Ae=tt.offset;if(Mt.isInstancedInterleavedBuffer||Mt.isInstancedBufferAttribute){for(let Ot=0;Ot<X.locationSize;Ot++)g(X.location+Ot,Mt.meshPerAttribute);U.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=Mt.meshPerAttribute*Mt.count)}else for(let Ot=0;Ot<X.locationSize;Ot++)m(X.location+Ot);r.bindBuffer(r.ARRAY_BUFFER,Z);for(let Ot=0;Ot<X.locationSize;Ot++)M(X.location+Ot,Rt/X.locationSize,yt,it,Vt*Et,(Ae+Rt/X.locationSize*Ot)*Et,Nt)}else{if(tt.isInstancedBufferAttribute){for(let Mt=0;Mt<X.locationSize;Mt++)g(X.location+Mt,tt.meshPerAttribute);U.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=tt.meshPerAttribute*tt.count)}else for(let Mt=0;Mt<X.locationSize;Mt++)m(X.location+Mt);r.bindBuffer(r.ARRAY_BUFFER,Z);for(let Mt=0;Mt<X.locationSize;Mt++)M(X.location+Mt,Rt/X.locationSize,yt,it,Rt*Et,Rt/X.locationSize*Mt*Et,Nt)}}else if(F!==void 0){const it=F[et];if(it!==void 0)switch(it.length){case 2:r.vertexAttrib2fv(X.location,it);break;case 3:r.vertexAttrib3fv(X.location,it);break;case 4:r.vertexAttrib4fv(X.location,it);break;default:r.vertexAttrib1fv(X.location,it)}}}}_()}function E(){P();for(const U in i){const B=i[U];for(const V in B){const D=B[V];for(const H in D){const Y=D[H];for(const F in Y)h(Y[F].object),delete Y[F];delete D[H]}}delete i[U]}}function T(U){if(i[U.id]===void 0)return;const B=i[U.id];for(const V in B){const D=B[V];for(const H in D){const Y=D[H];for(const F in Y)h(Y[F].object),delete Y[F];delete D[H]}}delete i[U.id]}function x(U){for(const B in i){const V=i[B];for(const D in V){const H=V[D];if(H[U.id]===void 0)continue;const Y=H[U.id];for(const F in Y)h(Y[F].object),delete Y[F];delete H[U.id]}}}function w(U){for(const B in i){const V=i[B],D=U.isInstancedMesh===!0?U.id:0,H=V[D];if(H!==void 0){for(const Y in H){const F=H[Y];for(const et in F)h(F[et].object),delete F[et];delete H[Y]}delete V[D],Object.keys(V).length===0&&delete i[B]}}}function P(){C(),o=!0,s!==n&&(s=n,c(s.object))}function C(){n.geometry=null,n.program=null,n.wireframe=!1}return{setup:a,reset:P,resetDefaultState:C,dispose:E,releaseStatesOfGeometry:T,releaseStatesOfObject:w,releaseStatesOfProgram:x,initAttributes:v,enableAttribute:m,disableUnusedAttributes:_}}function Y0(r,t,e){let i;function n(l){i=l}function s(l,c){r.drawArrays(i,l,c),e.update(c,i,1)}function o(l,c,h){h!==0&&(r.drawArraysInstanced(i,l,c,h),e.update(c,i,h))}function a(l,c,h){if(h===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,l,0,c,0,h);let d=0;for(let f=0;f<h;f++)d+=c[f];e.update(d,i,1)}this.setMode=n,this.render=s,this.renderInstances=o,this.renderMultiDraw=a}function $0(r,t,e,i){let n;function s(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){const x=t.get("EXT_texture_filter_anisotropic");n=r.getParameter(x.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function o(x){return!(x!==Ni&&i.convert(x)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(x){const w=x===Oi&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(x!==pi&&x!==Ei&&!w&&i.convert(x)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE))}function l(x){if(x==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";x="mediump"}return x==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp";const h=l(c);h!==c&&(Bt("WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),d=e.logarithmicDepthBuffer===!0&&u===!1;e.reversedDepthBuffer===!0&&u===!1&&Bt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),e.logarithmicDepthBuffer===!0&&u===!0&&Bt("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const f=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),p=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=r.getParameter(r.MAX_TEXTURE_SIZE),m=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),g=r.getParameter(r.MAX_VERTEX_ATTRIBS),_=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),M=r.getParameter(r.MAX_VARYING_VECTORS),y=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),E=r.getParameter(r.MAX_SAMPLES),T=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:d,reversedDepthBuffer:u,maxTextures:f,maxVertexTextures:p,maxTextureSize:v,maxCubemapSize:m,maxAttributes:g,maxVertexUniforms:_,maxVaryings:M,maxFragmentUniforms:y,maxSamples:E,samples:T}}function K0(r){const t=this;let e=null,i=0,n=!1,s=!1;const o=new Xi,a=new kt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||i!==0||n;return n=d,i=u.length,f},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){const p=u.clippingPlanes,v=u.clipIntersection,m=u.clipShadows,g=r.get(u);if(!n||p===null||p.length===0||s&&!m)s?h(null):c();else{const _=s?0:i,M=_*4;let y=g.clippingState||null;l.value=y,y=h(p,d,M,f);for(let E=0;E!==M;++E)y[E]=e[E];g.clippingState=y,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=_}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(u,d,f,p){const v=u!==null?u.length:0;let m=null;if(v!==0){if(m=l.value,p!==!0||m===null){const g=f+v*4,_=d.matrixWorldInverse;a.getNormalMatrix(_),(m===null||m.length<g)&&(m=new Float32Array(g));for(let M=0,y=f;M!==v;++M,y+=4)o.copy(u[M]).applyMatrix4(_,a),o.normal.toArray(m,y),m[y+3]=o.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=v,t.numIntersection=0,m}}class dl extends Ai{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const i={width:t,height:t,depth:1},n=[i,i,i,i,i,i];this.texture=new Ph(n),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},n=new ne(5,5,5),s=new Qe({name:"CubemapFromEquirect",uniforms:ls(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Je,blending:ts});s.uniforms.tEquirect.value=e;const o=new I(n,s),a=e.minFilter;return e.minFilter===an&&(e.minFilter=Ze),new Ga(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e=!0,i=!0,n=!0){const s=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,i,n);t.setRenderTarget(s)}}const xc=256,Z0=3,J0=20,$h=256,Kh=16,j0=3,Q0=new R,tm=new ct;class Ys{constructor(t){this._renderer=t,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Ga(1,10,null),this._boxMesh=new I(new ne(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(t,e=0,i=.1,n=100,s={}){const{size:o=256,position:a=Q0}=s,l=this._renderer;this._setSize(o);const c=this._allocateTarget(),h=this._getSourceTarget(!0);e>0&&(h.texture.mipmapsAutoUpdate=!1);const u=l.autoClear,d=l.autoClearColor,f=l.autoClearDepth,p=l.autoClearStencil,v=t.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,v===null&&(t.background=l.getClearColor(tm));const m=new Ga(i,n,h);return m.position.copy(a),m.update(l,t),l.autoClear=u,l.autoClearColor=d,l.autoClearDepth=f,l.autoClearStencil=p,t.background=v,e>0&&(h.texture.mipmapsAutoUpdate=!0,this._blur(c,e)),this._applyPMREM(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Sc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Mc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(t,e){return e>0?1-Math.sqrt(1-t/e):0}_setSize(t){this._cubeSize=Math.max(xc,Ku(t))}_fromTexture(t,e){t.mapping===ns||t.mapping===Os?this._setSize(t.image.length===0?xc:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4);const i=e||this._allocateTarget();return this._textureToCubemap(t),this._applyPMREM(i),i}_allocateTarget(){const t=this._cubeSize,e=yc(t,!1,!1),i=Math.log2(t)-Z0;for(let n=0;n<=i;n++)e.texture.mipmaps.push({width:t>>n,height:t>>n});return e.texture.name="PMREM",e.texture.isPMREMTexture=!0,e}_getSourceTarget(t=!1){const e=this._cubeSize,i=this._sourceTarget;return(i===null||i.width!==e||t&&i.depthBuffer===!1)&&(i!==null&&i.dispose(),this._sourceTarget=yc(e,!0,t)),this._sourceTarget}_compileMaterial(t){this._boxMesh.material=t,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(t,e,i){const n=this._boxMesh,s=this._cubeCamera;n.material=i,s.renderTarget=t,s.activeMipmapLevel=e;const o=t.width>>e;t.viewport.set(0,0,o,o),s.update(this._renderer,n),t.viewport.set(0,0,t.width,t.height)}_textureToCubemap(t){let e;t.mapping===ns||t.mapping===Os?(this._cubemapMaterial===null&&(this._cubemapMaterial=Sc()),e=this._cubemapMaterial,e.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=Mc()),e=this._equirectMaterial),e.uniforms.envMap.value=t,this._renderCube(this._getSourceTarget(),0,e)}_applyPMREM(t){this._ggxMaterial===null&&(this._ggxMaterial=em(),this._integrationMaterial=im());const e=this._cubeSize,i=t.texture.mipmaps.length-1,n=this._ggxMaterial.uniforms;n.envMap.value=this._sourceTarget.texture;const s=this._integrationMaterial.uniforms;s.envMap.value=this._sourceTarget.texture,s.sourceLod.value=Math.log2(e/Kh);for(let o=0;o<=i;o++){const a=Ys.lodToRoughness(o,i);if(o>i-j0)s.roughness.value=a,this._renderCube(t,o,this._integrationMaterial);else{const l=a>0?Math.log2(e)+.5*Math.log2(6/($h*Math.pow(a,4)))+.5:0;n.roughness.value=a,n.lodBias.value=l,this._renderCube(t,o,this._ggxMaterial)}}}_blur(t,e){this._blurMaterial===null&&(this._blurMaterial=nm());const i=this._blurMaterial,n=i.uniforms,s=this._sourceTarget;n.sigma.value=Math.min(e,Math.PI)/Math.SQRT2,n.envMap.value=s.texture,this._renderCube(t,0,i),n.envMap.value=t.texture,this._renderCube(s,0,i)}}function yc(r,t,e){return new dl(r,{minFilter:an,generateMipmaps:t,type:Oi,colorSpace:Vr,depthBuffer:e})}function Zs(r,t,e){return new Qe({name:r,uniforms:t,vertexShader:Yt.cube_vert,fragmentShader:e,side:Je,blending:ts,depthTest:!1,depthWrite:!1})}function em(){return Zs("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${$h}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function im(){return Zs("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:Kh}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function nm(){return Zs("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${J0}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function Mc(){return Zs("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function Sc(){return Zs("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function sm(r){let t=new WeakMap,e=new WeakMap,i=null;function n(d,f=!1){return d==null?null:f?o(d):s(d)}function s(d){if(d&&d.isTexture){const f=d.mapping;if(f===Nr||f===co)if(t.has(d)){const p=t.get(d).texture;return a(p,d.mapping)}else{const p=d.image;if(p&&p.height>0){const v=new dl(p.height);return v.fromEquirectangularTexture(r,d),t.set(d,v),d.addEventListener("dispose",c),a(v.texture,d.mapping)}else return null}}return d}function o(d){if(d&&d.isTexture&&d.isPMREMTexture!==!0){const f=d.mapping,p=f===Nr||f===co,v=f===ns||f===Os;if(p||v){let m=e.get(d);const g=m!==void 0?m.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==g)return i===null&&(i=new Ys(r)),m=p?i.fromEquirectangular(d,m):i.fromCubemap(d,m),m.texture.pmremVersion=d.pmremVersion,e.set(d,m),m.texture;if(m!==void 0)return m.texture;{const _=d.image;return p&&_&&_.height>0||v&&_&&l(_)?(i===null&&(i=new Ys(r)),m=p?i.fromEquirectangular(d):i.fromCubemap(d),m.texture.pmremVersion=d.pmremVersion,e.set(d,m),d.addEventListener("dispose",h),m.texture):null}}}return d}function a(d,f){return f===Nr?d.mapping=ns:f===co&&(d.mapping=Os),d}function l(d){let f=0;const p=6;for(let v=0;v<p;v++)d[v]!==void 0&&f++;return f===p}function c(d){const f=d.target;f.removeEventListener("dispose",c);const p=t.get(f);p!==void 0&&(t.delete(f),p.dispose())}function h(d){const f=d.target;f.removeEventListener("dispose",h);const p=e.get(f);p!==void 0&&(e.delete(f),p.dispose())}function u(){t=new WeakMap,e=new WeakMap,i!==null&&(i.dispose(),i=null)}return{get:n,dispose:u}}function rm(r){const t={};function e(i){if(t[i]!==void 0)return t[i];const n=r.getExtension(i);return t[i]=n,n}return{has:function(i){return e(i)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(i){const n=e(i);return n===null&&es("WebGLRenderer: "+i+" extension not supported."),n}}}function om(r,t,e,i){const n={},s=new WeakMap,o=new FinalizationRegistry(p=>delete n[p]);function a(p){l(p.target)}function l(p){p.index!==null&&t.remove(p.index);for(const m in p.attributes)t.remove(p.attributes[m]);p.removeEventListener("dispose",a),delete n[p.id],o.unregister(p);const v=s.get(p);v&&(t.remove(v),s.delete(p)),i.releaseStatesOfGeometry(p),p.isInstancedBufferGeometry===!0&&delete p._maxInstanceCount,e.memory.geometries--}function c(p,v){return n[v.id]!==void 0||(v.addEventListener("dispose",a),n[v.id]=new WeakRef(v),o.register(v,v.id,v),e.memory.geometries++),v}function h(p){const v=p.attributes;for(const m in v)t.update(v[m],r.ARRAY_BUFFER)}function u(p){const v=p.index,m=p.attributes.position;let g=0;if(m===void 0)return;const _=v!==null?v.array.length:m.array.length/3-1,M=m.count>=65535?Th:Eh,y=new M(Math.ceil(_/3)*6,1),E=y.array;if(v!==null){const x=v.array;g=v.version;for(let w=0,P=0;w<_;w+=3){const C=x[w+0],U=x[w+1],B=x[w+2];E[P++]=C,E[P++]=U,E[P++]=U,E[P++]=B,E[P++]=B,E[P++]=C}}else{g=m.version;for(let x=0,w=0;x<_;x+=3){const P=x+0,C=x+1,U=x+2;E[w++]=P,E[w++]=C,E[w++]=C,E[w++]=U,E[w++]=U,E[w++]=P}}y.version=g;const T=s.get(p);T&&t.remove(T),s.set(p,y)}function d(p){const v=s.get(p);if(v){const m=p.index;m!==null&&v.version<m.version&&u(p)}else u(p);return s.get(p)}function f(){for(const p in n){const v=n[p].deref();v!==void 0&&l(v)}}return{get:c,update:h,getWireframeAttribute:d,dispose:f}}function am(r,t,e){let i;function n(u){i=u}let s,o;function a(u){s=u.type,o=u.bytesPerElement}function l(u,d){r.drawElements(i,d,s,u*o),e.update(d,i,1)}function c(u,d,f){f!==0&&(r.drawElementsInstanced(i,d,s,u*o,f),e.update(d,i,f))}function h(u,d,f){if(f===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,d,0,s,u,0,f);let v=0;for(let m=0;m<f;m++)v+=d[m];e.update(v,i,1)}this.setMode=n,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h}function lm(r){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,o,a){switch(e.calls++,o){case r.TRIANGLES:e.triangles+=a*(s/3);break;case r.LINES:e.lines+=a*(s/2);break;case r.LINE_STRIP:e.lines+=a*(s-1);break;case r.LINE_LOOP:e.lines+=a*s;break;case r.POINTS:e.points+=a*s;break;default:se("WebGLInfo: Unknown draw mode:",o);break}}function n(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:n,update:i}}function cm(r,t,e){const i=new WeakMap,n=new Me;function s(o,a,l){const c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let d=i.get(a);if(d===void 0||d.count!==u){let C=function(){w.dispose(),i.delete(a),a.removeEventListener("dispose",C)};var f=C;d!==void 0&&d.texture.dispose();const p=a.morphAttributes.position!==void 0,v=a.morphAttributes.normal!==void 0,m=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],_=a.morphAttributes.normal||[],M=a.morphAttributes.color||[];let y=0;p===!0&&(y=1),v===!0&&(y=2),m===!0&&(y=3);let E=a.attributes.position.count*y,T=1;E>t.maxTextureSize&&(T=Math.ceil(E/t.maxTextureSize),E=t.maxTextureSize);const x=new Float32Array(E*T*4*u),w=new wh(x,E,T,u);w.type=Ei,w.needsUpdate=!0;const P=y*4;for(let U=0;U<u;U++){const B=g[U],V=_[U],D=M[U],H=E*T*4*U;for(let Y=0;Y<B.count;Y++){const F=Y*P;p===!0&&(n.fromBufferAttribute(B,Y),x[H+F+0]=n.x,x[H+F+1]=n.y,x[H+F+2]=n.z,x[H+F+3]=0),v===!0&&(n.fromBufferAttribute(V,Y),x[H+F+4]=n.x,x[H+F+5]=n.y,x[H+F+6]=n.z,x[H+F+7]=0),m===!0&&(n.fromBufferAttribute(D,Y),x[H+F+8]=n.x,x[H+F+9]=n.y,x[H+F+10]=n.z,x[H+F+11]=D.itemSize===4?n.w:1)}}d={count:u,texture:w,size:new Q(E,T)},i.set(a,d),a.addEventListener("dispose",C)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(r,"morphTexture",o.morphTexture,e);else{let p=0;for(let m=0;m<c.length;m++)p+=c[m];const v=a.morphTargetsRelative?1:1-p;l.getUniforms().setValue(r,"morphTargetBaseInfluence",v),l.getUniforms().setValue(r,"morphTargetInfluences",c)}l.getUniforms().setValue(r,"morphTargetsTexture",d.texture,e),l.getUniforms().setValue(r,"morphTargetsTextureSize",d.size)}return{update:s}}function hm(r,t,e,i,n){let s=new WeakMap;function o(c){const h=n.render.frame,u=c.geometry,d=t.get(c,u);if(s.get(d)!==h&&(t.update(d),s.set(d,h)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),s.get(c)!==h&&(e.update(c.instanceMatrix,r.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,r.ARRAY_BUFFER),s.set(c,h))),c.isSkinnedMesh){const f=c.skeleton;s.get(f)!==h&&(f.update(),s.set(f,h))}return d}function a(){s=new WeakMap}function l(c){const h=c.target;h.removeEventListener("dispose",l),i.releaseStatesOfObject(h),e.remove(h.instanceMatrix),h.instanceColor!==null&&e.remove(h.instanceColor)}return{update:o,dispose:a}}const um={[nh]:"LINEAR_TONE_MAPPING",[sh]:"REINHARD_TONE_MAPPING",[rh]:"CINEON_TONE_MAPPING",[qa]:"ACES_FILMIC_TONE_MAPPING",[ah]:"AGX_TONE_MAPPING",[lh]:"NEUTRAL_TONE_MAPPING",[oh]:"CUSTOM_TONE_MAPPING"};function dm(r,t,e,i,n,s){const o=new Ai(t,e,{type:r,depthBuffer:n,stencilBuffer:s,samples:i?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let a=null,l=null,c=null;const h=new de;h.setAttribute("position",new Kt([-1,3,0,-1,-1,0,3,-1,0],3)),h.setAttribute("uv",new Kt([0,2,0,0,2,0],2));const u=new tf({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new I(h,u),f=new no(-1,1,1,-1,0,1);let p=null,v=null,m=!1,g,_=null,M=[],y=!1;this.setSize=function(E,T){o.setSize(E,T),a!==null&&a.setSize(E,T),l!==null&&l.setSize(E,T);for(let x=0;x<M.length;x++){const w=M[x];w.setSize&&w.setSize(E,T)}},this.setEffects=function(E){M=E,y=M.length>0&&M[0].isRenderPass===!0;const T=o.width,x=o.height;M.length>0&&a===null&&(a=new Ai(T,x,{type:Oi,depthBuffer:!1,stencilBuffer:!1}),l=new Ai(T,x,{type:Oi,depthBuffer:!1,stencilBuffer:!1}));const w=n===!0&&M.some(P=>P.needsDepthTexture===!0);w!==(o.depthTexture!==null)&&(w===!0&&c===null&&(c=new rs(T,x),s===!0&&(c.format=ln,c.type=ss)),o.dispose(),o.depthTexture=w?c:null,o.resolveDepthBuffer=w,o.storeMultisampledDepthBuffer=w);for(let P=0;P<M.length;P++){const C=M[P];C.setSize&&C.setSize(T,x),w&&C.needsDepthTexture===!0&&C.setDepthTexture&&C.setDepthTexture(c)}},this.begin=function(E,T){if(m||E.toneMapping===$i&&M.length===0)return!1;if(_=T,T!==null){const x=T.width,w=T.height;(o.width!==x||o.height!==w)&&this.setSize(x,w)}return y===!1&&E.setRenderTarget(o),g=E.toneMapping,E.toneMapping=$i,!0},this.hasRenderPass=function(){return y},this.end=function(E,T){E.toneMapping=g,m=!0;let x=o,w=a;for(let P=0;P<M.length;P++){const C=M[P];C.enabled!==!1&&(C.render(E,w,x,T),C.needsSwap!==!1&&(x=w,w=w===a?l:a))}if(p!==E.outputColorSpace||v!==E.toneMapping){p=E.outputColorSpace,v=E.toneMapping,u.defines={},Qt.getTransfer(p)===he&&(u.defines.SRGB_TRANSFER="");const P=um[v];P&&(u.defines[P]=""),u.needsUpdate=!0}u.uniforms.tDiffuse.value=x.texture,E.setRenderTarget(_),E.render(d,f),_=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){o.dispose(),a!==null&&a.dispose(),l!==null&&l.dispose(),h.dispose(),u.dispose()}}const Zh=new je,Jh=new rs(1,1),jh=new Lh(1),Qh=new wh,tu=new id,eu=new Ph,wc=[],bc=[],Ec=new Float32Array(16),Tc=new Float32Array(9),Ac=new Float32Array(4);function us(r,t,e){const i=r[0];if(i<=0||i>0)return r;const n=t*e;let s=wc[n];if(s===void 0&&(s=new Float32Array(n),wc[n]=s),t!==0){i.toArray(s,0);for(let o=1,a=0;o!==t;++o)a+=e,r[o].toArray(s,a)}return s}function Ue(r,t){if(r.length!==t.length)return!1;for(let e=0,i=r.length;e<i;e++)if(r[e]!==t[e])return!1;return!0}function Fe(r,t){for(let e=0,i=t.length;e<i;e++)r[e]=t[e]}function so(r,t){let e=bc[t];e===void 0&&(e=new Int32Array(t),bc[t]=e);for(let i=0;i!==t;++i)e[i]=r.allocateTextureUnit();return e}function fm(r,t){const e=this.cache;e[0]!==t&&(r.uniform1f(this.addr,t),e[0]=t)}function pm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(r.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ue(e,t))return;r.uniform2fv(this.addr,t),Fe(e,t)}}function mm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(r.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(r.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ue(e,t))return;r.uniform3fv(this.addr,t),Fe(e,t)}}function gm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(r.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ue(e,t))return;r.uniform4fv(this.addr,t),Fe(e,t)}}function vm(r,t){const e=this.cache,i=t.elements;if(i===void 0){if(Ue(e,t))return;r.uniformMatrix2fv(this.addr,!1,t),Fe(e,t)}else{if(Ue(e,i))return;Ac.set(i),r.uniformMatrix2fv(this.addr,!1,Ac),Fe(e,i)}}function _m(r,t){const e=this.cache,i=t.elements;if(i===void 0){if(Ue(e,t))return;r.uniformMatrix3fv(this.addr,!1,t),Fe(e,t)}else{if(Ue(e,i))return;Tc.set(i),r.uniformMatrix3fv(this.addr,!1,Tc),Fe(e,i)}}function xm(r,t){const e=this.cache,i=t.elements;if(i===void 0){if(Ue(e,t))return;r.uniformMatrix4fv(this.addr,!1,t),Fe(e,t)}else{if(Ue(e,i))return;Ec.set(i),r.uniformMatrix4fv(this.addr,!1,Ec),Fe(e,i)}}function ym(r,t){const e=this.cache;e[0]!==t&&(r.uniform1i(this.addr,t),e[0]=t)}function Mm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(r.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ue(e,t))return;r.uniform2iv(this.addr,t),Fe(e,t)}}function Sm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(r.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ue(e,t))return;r.uniform3iv(this.addr,t),Fe(e,t)}}function wm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(r.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ue(e,t))return;r.uniform4iv(this.addr,t),Fe(e,t)}}function bm(r,t){const e=this.cache;e[0]!==t&&(r.uniform1ui(this.addr,t),e[0]=t)}function Em(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(r.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ue(e,t))return;r.uniform2uiv(this.addr,t),Fe(e,t)}}function Tm(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(r.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ue(e,t))return;r.uniform3uiv(this.addr,t),Fe(e,t)}}function Am(r,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(r.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ue(e,t))return;r.uniform4uiv(this.addr,t),Fe(e,t)}}function ro(r){return r.version===0&&(r.compareFunction=_h,r.needsUpdate=!0),r}function Rm(r,t,e){const i=this.cache,n=e.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n);let s;this.type===r.SAMPLER_2D_SHADOW?s=ro(Jh):s=Zh,e.setTexture2D(t||s,n)}function Cm(r,t,e){const i=this.cache,n=e.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),e.setTexture3D(t||tu,n)}function Pm(r,t,e){const i=this.cache,n=e.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n);let s;this.type===r.SAMPLER_CUBE_SHADOW?s=ro(jh):s=eu,e.setTextureCube(t||s,n)}function Lm(r,t,e){const i=this.cache,n=e.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),e.setTexture2DArray(t||Qh,n)}function Dm(r){switch(r){case 5126:return fm;case 35664:return pm;case 35665:return mm;case 35666:return gm;case 35674:return vm;case 35675:return _m;case 35676:return xm;case 5124:case 35670:return ym;case 35667:case 35671:return Mm;case 35668:case 35672:return Sm;case 35669:case 35673:return wm;case 5125:return bm;case 36294:return Em;case 36295:return Tm;case 36296:return Am;case 35678:case 36198:case 36298:case 36306:case 35682:return Rm;case 35679:case 36299:case 36307:return Cm;case 35680:case 36300:case 36308:case 36293:return Pm;case 36289:case 36303:case 36311:case 36292:return Lm}}function Im(r,t){r.uniform1fv(this.addr,t)}function Nm(r,t){const e=us(t,this.size,2);r.uniform2fv(this.addr,e)}function Um(r,t){const e=us(t,this.size,3);r.uniform3fv(this.addr,e)}function Fm(r,t){const e=us(t,this.size,4);r.uniform4fv(this.addr,e)}function Om(r,t){const e=us(t,this.size,4);r.uniformMatrix2fv(this.addr,!1,e)}function Bm(r,t){const e=us(t,this.size,9);r.uniformMatrix3fv(this.addr,!1,e)}function zm(r,t){const e=us(t,this.size,16);r.uniformMatrix4fv(this.addr,!1,e)}function km(r,t){r.uniform1iv(this.addr,t)}function Gm(r,t){r.uniform2iv(this.addr,t)}function Hm(r,t){r.uniform3iv(this.addr,t)}function Vm(r,t){r.uniform4iv(this.addr,t)}function Wm(r,t){r.uniform1uiv(this.addr,t)}function Xm(r,t){r.uniform2uiv(this.addr,t)}function qm(r,t){r.uniform3uiv(this.addr,t)}function Ym(r,t){r.uniform4uiv(this.addr,t)}function $m(r,t,e){const i=this.cache,n=t.length,s=so(e,n);Ue(i,s)||(r.uniform1iv(this.addr,s),Fe(i,s));let o;this.type===r.SAMPLER_2D_SHADOW?o=ro(Jh):o=Zh;for(let a=0;a!==n;++a)e.setTexture2D(t[a]||o,s[a])}function Km(r,t,e){const i=this.cache,n=t.length,s=so(e,n);Ue(i,s)||(r.uniform1iv(this.addr,s),Fe(i,s));for(let o=0;o!==n;++o)e.setTexture3D(t[o]||tu,s[o])}function Zm(r,t,e){const i=this.cache,n=t.length,s=so(e,n);Ue(i,s)||(r.uniform1iv(this.addr,s),Fe(i,s));let o;this.type===r.SAMPLER_CUBE_SHADOW?o=ro(jh):o=eu;for(let a=0;a!==n;++a)e.setTextureCube(t[a]||o,s[a])}function Jm(r,t,e){const i=this.cache,n=t.length,s=so(e,n);Ue(i,s)||(r.uniform1iv(this.addr,s),Fe(i,s));for(let o=0;o!==n;++o)e.setTexture2DArray(t[o]||Qh,s[o])}function jm(r){switch(r){case 5126:return Im;case 35664:return Nm;case 35665:return Um;case 35666:return Fm;case 35674:return Om;case 35675:return Bm;case 35676:return zm;case 5124:case 35670:return km;case 35667:case 35671:return Gm;case 35668:case 35672:return Hm;case 35669:case 35673:return Vm;case 5125:return Wm;case 36294:return Xm;case 36295:return qm;case 36296:return Ym;case 35678:case 36198:case 36298:case 36306:case 35682:return $m;case 35679:case 36299:case 36307:return Km;case 35680:case 36300:case 36308:case 36293:return Zm;case 36289:case 36303:case 36311:case 36292:return Jm}}class Qm{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.setValue=Dm(e.type)}}class tg{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=jm(e.type)}}class eg{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,i){const n=this.seq;for(let s=0,o=n.length;s!==o;++s){const a=n[s];a.setValue(t,e[a.id],i)}}}const ko=/(\w+)(\])?(\[|\.)?/g;function Rc(r,t){r.seq.push(t),r.map[t.id]=t}function ig(r,t,e){const i=r.name,n=i.length;for(ko.lastIndex=0;;){const s=ko.exec(i),o=ko.lastIndex;let a=s[1];const l=s[2]==="]",c=s[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===n){Rc(e,c===void 0?new Qm(a,r,t):new tg(a,r,t));break}else{let u=e.map[a];u===void 0&&(u=new eg(a),Rc(e,u)),e=u}}}class kr{constructor(t,e){this.seq=[],this.map={};const i=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let o=0;o<i;++o){const a=t.getActiveUniform(e,o),l=t.getUniformLocation(e,a.name);ig(a,l,this)}const n=[],s=[];for(const o of this.seq)o.type===t.SAMPLER_2D_SHADOW||o.type===t.SAMPLER_CUBE_SHADOW||o.type===t.SAMPLER_2D_ARRAY_SHADOW?n.push(o):s.push(o);n.length>0&&(this.seq=n.concat(s))}setValue(t,e,i,n){const s=this.map[e];s!==void 0&&s.setValue(t,i,n)}setOptional(t,e,i){const n=e[i];n!==void 0&&this.setValue(t,i,n)}static upload(t,e,i,n){for(let s=0,o=e.length;s!==o;++s){const a=e[s],l=i[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,n)}}static seqWithValue(t,e){const i=[];for(let n=0,s=t.length;n!==s;++n){const o=t[n];o.id in e&&i.push(o)}return i}}function Cc(r,t,e){const i=r.createShader(t);return r.shaderSource(i,e),r.compileShader(i),i}const ng=37297;let sg=0;function rg(r,t){const e=r.split(`
`),i=[],n=Math.max(t-6,0),s=Math.min(t+6,e.length);for(let o=n;o<s;o++){const a=o+1;i.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return i.join(`
`)}const Pc=new kt;function og(r){Qt._getMatrix(Pc,Qt.workingColorSpace,r);const t=`mat3( ${Pc.elements.map(e=>e.toFixed(4))} )`;switch(Qt.getTransfer(r)){case Wr:return[t,"LinearTransferOETF"];case he:return[t,"sRGBTransferOETF"];default:return Bt("WebGLProgram: Unsupported color space: ",r),[t,"LinearTransferOETF"]}}function Lc(r,t,e){const i=r.getShaderParameter(t,r.COMPILE_STATUS),s=(r.getShaderInfoLog(t)||"").trim();if(i&&s==="")return"";const o=/ERROR: 0:(\d+)/.exec(s);if(o){const a=parseInt(o[1]);return e.toUpperCase()+`

`+s+`

`+rg(r.getShaderSource(t),a)}else return s}function ag(r,t){const e=og(t);return[`vec4 ${r}( vec4 value ) {`,`	return ${e[1]}( vec4( ${e[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const lg={[nh]:"Linear",[sh]:"Reinhard",[rh]:"Cineon",[qa]:"ACESFilmic",[ah]:"AgX",[lh]:"Neutral",[oh]:"Custom"};function cg(r,t){const e=lg[t];return e===void 0?(Bt("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const Rr=new R;function hg(){Qt.getLuminanceCoefficients(Rr);const r=Rr.x.toFixed(4),t=Rr.y.toFixed(4),e=Rr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function ug(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ps).join(`
`)}function dg(r){const t=[];for(const e in r){const i=r[e];i!==!1&&t.push("#define "+e+" "+i)}return t.join(`
`)}function fg(r,t){const e={},i=r.getProgramParameter(t,r.ACTIVE_ATTRIBUTES);for(let n=0;n<i;n++){const s=r.getActiveAttrib(t,n),o=s.name;let a=1;s.type===r.FLOAT_MAT2&&(a=2),s.type===r.FLOAT_MAT3&&(a=3),s.type===r.FLOAT_MAT4&&(a=4),e[o]={type:s.type,location:r.getAttribLocation(t,o),locationSize:a}}return e}function Ps(r){return r!==""}function Dc(r,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return r.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,t.numLightProbeGrids)}function Ic(r,t){return r.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const pg=/^[ \t]*#include +<([\w\d./]+)>/gm;function Va(r){return r.replace(pg,mg)}function mg(r,t){const e=Yt[t];if(e===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">");return Va(e)}const gg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Nc(r){return r.replace(gg,vg)}function vg(r,t,e,i){let n="";for(let s=parseInt(t);s<parseInt(e);s++)n+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return n}function Uc(r){let t=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?t+=`
#define HIGH_PRECISION`:r.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const _g={[Ls]:"SHADOWMAP_TYPE_PCF",[As]:"SHADOWMAP_TYPE_VSM"};function xg(r){return _g[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const yg={[Os]:"ENVMAP_MODE_REFRACTION"};function Mg(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":yg[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const Sg={[ih]:"ENVMAP_BLENDING_MULTIPLY",[Iu]:"ENVMAP_BLENDING_MIX",[Nu]:"ENVMAP_BLENDING_ADD"};function wg(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":Sg[r.combine]||"ENVMAP_BLENDING_NONE"}function bg(r,t,e,i){const n=r.getContext(),s=e.defines;let o=e.vertexShader,a=e.fragmentShader;const l=xg(e),c=e.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",h=Mg(e),u=wg(e),d=ug(e),f=dg(s),p=n.createProgram();let v,m,g=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(v=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f].filter(Ps).join(`
`),v.length>0&&(v+=`
`),m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f].filter(Ps).join(`
`),m.length>0&&(m+=`
`)):(v=[Uc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+e.diffuseRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexNormals?"#define HAS_NORMAL":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ps).join(`
`),m=[Uc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",e.envMapPMREM?"#define ENVMAP_MAX_LOD "+e.envMapMaxLod+".0":"",e.envMapPMREM?"#define ENVMAP_SIZE "+e.envMapSize+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",e.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.retroreflection?"#define USE_RETROREFLECTION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas||e.batchingColor?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==$i?"#define TONE_MAPPING":"",e.toneMapping!==$i?Yt.tonemapping_pars_fragment:"",e.toneMapping!==$i?cg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Yt.colorspace_pars_fragment,ag("linearToOutputTexel",e.outputColorSpace),hg(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Ps).join(`
`)),o=Va(o),o=Dc(o,e),o=Ic(o,e),a=Va(a),a=Dc(a,e),a=Ic(a,e),o=Nc(o),a=Nc(a),e.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,v=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+v,m=["#define varying in",e.glslVersion===Il?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Il?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const _=g+v+o,M=g+m+a,y=Cc(n,n.VERTEX_SHADER,_),E=Cc(n,n.FRAGMENT_SHADER,M);n.attachShader(p,y),n.attachShader(p,E),e.index0AttributeName!==void 0?n.bindAttribLocation(p,0,e.index0AttributeName):e.hasPositionAttribute===!0&&n.bindAttribLocation(p,0,"position"),n.linkProgram(p);function T(C){if(r.debug.checkShaderErrors){const U=n.getProgramInfoLog(p)||"",B=n.getShaderInfoLog(y)||"",V=n.getShaderInfoLog(E)||"",D=U.trim(),H=B.trim(),Y=V.trim();let F=!0,et=!0;if(n.getProgramParameter(p,n.LINK_STATUS)===!1)if(F=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(n,p,y,E);else{const X=Lc(n,y,"vertex"),tt=Lc(n,E,"fragment");se("WebGLProgram: Shader Error "+n.getError()+" - VALIDATE_STATUS "+n.getProgramParameter(p,n.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+D+`
`+X+`
`+tt)}else D!==""?Bt("WebGLProgram: Program Info Log:",D):(H===""||Y==="")&&(et=!1);et&&(C.diagnostics={runnable:F,programLog:D,vertexShader:{log:H,prefix:v},fragmentShader:{log:Y,prefix:m}})}n.deleteShader(y),n.deleteShader(E),x=new kr(n,p),w=fg(n,p)}let x;this.getUniforms=function(){return x===void 0&&T(this),x};let w;this.getAttributes=function(){return w===void 0&&T(this),w};let P=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=n.getProgramParameter(p,ng)),P},this.destroy=function(){i.releaseStatesOfProgram(this),n.deleteProgram(p),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=sg++,this.cacheKey=t,this.usedTimes=1,this.program=p,this.vertexShader=y,this.fragmentShader=E,this}let Eg=0;class Tg{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,e,i){const n=this._getShaderCacheForMaterial(t);return n.has(e)===!1&&(n.add(e),e.usedTimes++),n.has(i)===!1&&(n.add(i),i.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const i of e)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let i=e.get(t);return i===void 0&&(i=new Set,e.set(t,i)),i}_getShaderStage(t){const e=this.shaderCache;let i=e.get(t);return i===void 0&&(i=new Ag(t),e.set(t,i)),i}}class Ag{constructor(t){this.id=Eg++,this.code=t,this.usedTimes=0}}function Rg(r){return r===Tn||r===Gr||r===Hr}function Cg(r,t,e,i,n,s){const o=new el,a=new Tg,l=new Set,c=[],h=new Map,u=i.logarithmicDepthBuffer,d={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(x){return l.add(x),x===0?"uv":`uv${x}`}function p(x,w,P,C,U,B){const V=C.fog,D=U.geometry,H=x.isMeshStandardMaterial||x.isMeshLambertMaterial||x.isMeshPhongMaterial?C.environment:null,Y=x.isMeshStandardMaterial||x.isMeshLambertMaterial&&!x.envMap||x.isMeshPhongMaterial&&!x.envMap,F=t.get(x.envMap||H,Y),et=d[x.type];let X=i.precision;x.precision!==null&&(X=i.getMaxPrecision(x.precision),X!==x.precision&&Bt("WebGLProgram.getParameters:",x.precision,"not supported, using",X,"instead."));const tt=D.morphAttributes.position||D.morphAttributes.normal||D.morphAttributes.color,it=tt!==void 0?tt.length:0;let Rt=0;D.morphAttributes.position!==void 0&&(Rt=1),D.morphAttributes.normal!==void 0&&(Rt=2),D.morphAttributes.color!==void 0&&(Rt=3);let Gt,Z,yt,Et;if(et){const _t=Di[et];Gt=_t.vertexShader,Z=_t.fragmentShader}else{Gt=x.vertexShader,Z=x.fragmentShader;const _t=a.getVertexShaderStage(x),ce=a.getFragmentShaderStage(x);a.update(x,_t,ce),yt=_t.id,Et=ce.id}const Nt=r.getRenderTarget(),Mt=r.state.buffers.depth.getReversed(),Vt=U.isInstancedMesh===!0,Ae=U.isBatchedMesh===!0,Ot=!!x.map,le=!!x.matcap,fe=!!F,Zt=fe&&F.isPMREMTexture===!0,He=!!x.aoMap,Pe=!!x.lightMap,ri=!!x.bumpMap&&x.wireframe===!1,xe=!!x.normalMap,Ri=!!x.displacementMap,Oe=!!x.emissiveMap,mi=!!x.metalnessMap,gi=!!x.roughnessMap,vi=x.anisotropy>0,O=x.clearcoat>0,_i=x.diffuseRoughness>0,ge=x.dispersion>0,ve=x.retroreflectivity>0,vt=x.iridescence>0,Le=x.sheen>0,Ut=x.transmission>0,zt=vi&&!!x.anisotropyMap,A=O&&!!x.clearcoatMap,S=O&&!!x.clearcoatNormalMap,k=O&&!!x.clearcoatRoughnessMap,nt=_i&&!!x.diffuseRoughnessMap,j=vt&&!!x.iridescenceMap,at=vt&&!!x.iridescenceThicknessMap,pt=Le&&!!x.sheenColorMap,$=Le&&!!x.sheenRoughnessMap,K=!!x.specularMap,ht=!!x.specularColorMap,L=!!x.specularIntensityMap,J=Ut&&!!x.transmissionMap,q=Ut&&!!x.thicknessMap,ut=!!x.gradientMap,ot=!!x.alphaMap,lt=x.alphaTest>0,Pt=!!x.alphaHash,qt=!!x.extensions;let rt=$i;x.toneMapped&&(Nt===null||Nt.isXRRenderTarget===!0)&&(rt=r.toneMapping);const Dt=Zt?F.isCompressedCubeTexture?F.image[0].mipmaps:F.mipmaps:null,Wt={shaderID:et,shaderType:x.type,shaderName:x.name,vertexShader:Gt,fragmentShader:Z,defines:x.defines,customVertexShaderID:yt,customFragmentShaderID:Et,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:X,batching:Ae,batchingColor:Ae&&U._colorsTexture!==null,instancing:Vt,instancingColor:Vt&&U.instanceColor!==null,instancingMorph:Vt&&U.morphTexture!==null,outputColorSpace:Nt===null?r.outputColorSpace:Nt.isXRRenderTarget===!0?Nt.texture.colorSpace:Qt.workingColorSpace,alphaToCoverage:!!x.alphaToCoverage,map:Ot,matcap:le,envMap:fe,envMapMode:fe&&F.mapping,envMapPMREM:Zt,envMapMaxLod:Zt?Dt.length-1:null,envMapSize:Zt?Dt[0].width:null,aoMap:He,lightMap:Pe,bumpMap:ri,normalMap:xe,displacementMap:Ri,emissiveMap:Oe,normalMapObjectSpace:xe&&x.normalMapType===Ou,normalMapTangentSpace:xe&&x.normalMapType===Ia,packedNormalMap:xe&&x.normalMapType===Ia&&Rg(x.normalMap.format),metalnessMap:mi,roughnessMap:gi,anisotropy:vi,anisotropyMap:zt,clearcoat:O,clearcoatMap:A,clearcoatNormalMap:S,clearcoatRoughnessMap:k,diffuseRoughness:_i,diffuseRoughnessMap:nt,dispersion:ge,retroreflection:ve,iridescence:vt,iridescenceMap:j,iridescenceThicknessMap:at,sheen:Le,sheenColorMap:pt,sheenRoughnessMap:$,specularMap:K,specularColorMap:ht,specularIntensityMap:L,transmission:Ut,transmissionMap:J,thicknessMap:q,gradientMap:ut,opaque:x.transparent===!1&&x.blending===Yi&&x.alphaToCoverage===!1,alphaMap:ot,alphaTest:lt,alphaHash:Pt,combine:x.combine,mapUv:Ot&&f(x.map.channel),aoMapUv:He&&f(x.aoMap.channel),lightMapUv:Pe&&f(x.lightMap.channel),bumpMapUv:ri&&f(x.bumpMap.channel),normalMapUv:xe&&f(x.normalMap.channel),displacementMapUv:Ri&&f(x.displacementMap.channel),emissiveMapUv:Oe&&f(x.emissiveMap.channel),metalnessMapUv:mi&&f(x.metalnessMap.channel),roughnessMapUv:gi&&f(x.roughnessMap.channel),anisotropyMapUv:zt&&f(x.anisotropyMap.channel),clearcoatMapUv:A&&f(x.clearcoatMap.channel),clearcoatNormalMapUv:S&&f(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:k&&f(x.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:nt&&f(x.diffuseRoughnessMap.channel),iridescenceMapUv:j&&f(x.iridescenceMap.channel),iridescenceThicknessMapUv:at&&f(x.iridescenceThicknessMap.channel),sheenColorMapUv:pt&&f(x.sheenColorMap.channel),sheenRoughnessMapUv:$&&f(x.sheenRoughnessMap.channel),specularMapUv:K&&f(x.specularMap.channel),specularColorMapUv:ht&&f(x.specularColorMap.channel),specularIntensityMapUv:L&&f(x.specularIntensityMap.channel),transmissionMapUv:J&&f(x.transmissionMap.channel),thicknessMapUv:q&&f(x.thicknessMap.channel),alphaMapUv:ot&&f(x.alphaMap.channel),vertexTangents:!!D.attributes.tangent&&(xe||vi),vertexNormals:!!D.attributes.normal,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!D.attributes.color&&D.attributes.color.itemSize===4,pointsUvs:U.isPoints===!0&&!!D.attributes.uv&&(Ot||ot),fog:!!V,useFog:x.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:x.wireframe===!1&&(x.flatShading===!0||D.attributes.normal===void 0&&xe===!1&&(x.isMeshLambertMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isMeshPhysicalMaterial)),sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:Mt,skinning:U.isSkinnedMesh===!0,hasPositionAttribute:D.attributes.position!==void 0,morphTargets:D.morphAttributes.position!==void 0,morphNormals:D.morphAttributes.normal!==void 0,morphColors:D.morphAttributes.color!==void 0,morphTargetsCount:it,morphTextureStride:Rt,numSunLights:w.sun.length,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numSunLightShadows:w.sunShadowMap.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numLightProbeGrids:B.filter(_t=>_t.texture!==null).length,numClippingPlanes:s.numPlanes,numClipIntersection:s.numIntersection,dithering:x.dithering,shadowMapEnabled:r.shadowMap.enabled&&P.length>0,shadowMapType:r.shadowMap.type,toneMapping:rt,decodeVideoTexture:Ot&&x.map.isVideoTexture===!0&&Qt.getTransfer(x.map.colorSpace)===he,decodeVideoTextureEmissive:Oe&&x.emissiveMap.isVideoTexture===!0&&Qt.getTransfer(x.emissiveMap.colorSpace)===he,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===ae,flipSided:x.side===Je,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:qt&&x.extensions.clipCullDistance===!0&&e.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(qt&&x.extensions.multiDraw===!0||Ae)&&e.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:e.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return Wt.vertexUv1s=l.has(1),Wt.vertexUv2s=l.has(2),Wt.vertexUv3s=l.has(3),l.clear(),Wt}function v(x){const w=[];if(x.shaderID?w.push(x.shaderID):(w.push(x.customVertexShaderID),w.push(x.customFragmentShaderID)),x.defines!==void 0)for(const P in x.defines)w.push(P),w.push(x.defines[P]);return x.isRawShaderMaterial===!1&&(m(w,x),g(w,x),w.push(r.outputColorSpace)),w.push(x.customProgramCacheKey),w.join()}function m(x,w){x.push(w.precision),x.push(w.outputColorSpace),x.push(w.envMapMode),x.push(w.envMapPMREM),x.push(w.envMapMaxLod),x.push(w.envMapSize),x.push(w.mapUv),x.push(w.alphaMapUv),x.push(w.lightMapUv),x.push(w.aoMapUv),x.push(w.bumpMapUv),x.push(w.normalMapUv),x.push(w.displacementMapUv),x.push(w.emissiveMapUv),x.push(w.metalnessMapUv),x.push(w.roughnessMapUv),x.push(w.anisotropyMapUv),x.push(w.clearcoatMapUv),x.push(w.clearcoatNormalMapUv),x.push(w.clearcoatRoughnessMapUv),x.push(w.diffuseRoughnessMapUv),x.push(w.iridescenceMapUv),x.push(w.iridescenceThicknessMapUv),x.push(w.sheenColorMapUv),x.push(w.sheenRoughnessMapUv),x.push(w.specularMapUv),x.push(w.specularColorMapUv),x.push(w.specularIntensityMapUv),x.push(w.transmissionMapUv),x.push(w.thicknessMapUv),x.push(w.combine),x.push(w.fogExp2),x.push(w.sizeAttenuation),x.push(w.morphTargetsCount),x.push(w.numSunLights),x.push(w.numDirLights),x.push(w.numPointLights),x.push(w.numSpotLights),x.push(w.numSpotLightMaps),x.push(w.numHemiLights),x.push(w.numRectAreaLights),x.push(w.numSunLightShadows),x.push(w.numDirLightShadows),x.push(w.numPointLightShadows),x.push(w.numSpotLightShadows),x.push(w.numSpotLightShadowsWithMaps),x.push(w.numLightProbes),x.push(w.numLightProbeGrids),x.push(w.shadowMapType),x.push(w.toneMapping),x.push(w.numClippingPlanes),x.push(w.numClipIntersection),x.push(w.depthPacking)}function g(x,w){o.disableAll(),w.instancing&&o.enable(0),w.instancingColor&&o.enable(1),w.instancingMorph&&o.enable(2),w.matcap&&o.enable(3),w.envMap&&o.enable(4),w.normalMapObjectSpace&&o.enable(5),w.normalMapTangentSpace&&o.enable(6),w.clearcoat&&o.enable(7),w.iridescence&&o.enable(8),w.alphaTest&&o.enable(9),w.vertexColors&&o.enable(10),w.vertexAlphas&&o.enable(11),w.vertexUv1s&&o.enable(12),w.vertexUv2s&&o.enable(13),w.vertexUv3s&&o.enable(14),w.vertexTangents&&o.enable(15),w.anisotropy&&o.enable(16),w.alphaHash&&o.enable(17),w.batching&&o.enable(18),w.dispersion&&o.enable(19),w.retroreflection&&o.enable(24),w.diffuseRoughness&&o.enable(25),w.batchingColor&&o.enable(20),w.gradientMap&&o.enable(21),w.packedNormalMap&&o.enable(22),w.vertexNormals&&o.enable(23),x.push(o.mask),o.disableAll(),w.fog&&o.enable(0),w.useFog&&o.enable(1),w.flatShading&&o.enable(2),w.logarithmicDepthBuffer&&o.enable(3),w.reversedDepthBuffer&&o.enable(4),w.skinning&&o.enable(5),w.morphTargets&&o.enable(6),w.morphNormals&&o.enable(7),w.morphColors&&o.enable(8),w.premultipliedAlpha&&o.enable(9),w.shadowMapEnabled&&o.enable(10),w.doubleSided&&o.enable(11),w.flipSided&&o.enable(12),w.useDepthPacking&&o.enable(13),w.dithering&&o.enable(14),w.transmission&&o.enable(15),w.sheen&&o.enable(16),w.opaque&&o.enable(17),w.pointsUvs&&o.enable(18),w.decodeVideoTexture&&o.enable(19),w.decodeVideoTextureEmissive&&o.enable(20),w.alphaToCoverage&&o.enable(21),w.numLightProbeGrids>0&&o.enable(22),w.hasPositionAttribute&&o.enable(23),x.push(o.mask)}function _(x){const w=d[x.type];let P;if(w){const C=Di[w];P=Jd.clone(C.uniforms)}else P=x.uniforms;return P}function M(x,w){let P=h.get(w);return P!==void 0?++P.usedTimes:(P=new bg(r,w,x,n),c.push(P),h.set(w,P)),P}function y(x){if(--x.usedTimes===0){const w=c.indexOf(x);c[w]=c[c.length-1],c.pop(),h.delete(x.cacheKey),x.destroy()}}function E(x){a.remove(x)}function T(){a.dispose()}return{getParameters:p,getProgramCacheKey:v,getUniforms:_,acquireProgram:M,releaseProgram:y,releaseShaderCache:E,programs:c,dispose:T}}function Pg(){let r=new WeakMap;function t(o){return r.has(o)}function e(o){let a=r.get(o);return a===void 0&&(a={},r.set(o,a)),a}function i(o){r.delete(o)}function n(o,a,l){r.get(o)[a]=l}function s(){r=new WeakMap}return{has:t,get:e,remove:i,update:n,dispose:s}}function Lg(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.material.id!==t.material.id?r.material.id-t.material.id:r.materialVariant!==t.materialVariant?r.materialVariant-t.materialVariant:r.z!==t.z?r.z-t.z:r.id-t.id}function Fc(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.z!==t.z?t.z-r.z:r.id-t.id}function Oc(){const r=[];let t=0;const e=[],i=[],n=[];function s(){t=0,e.length=0,i.length=0,n.length=0}function o(d){let f=0;return d.isInstancedMesh&&(f+=2),d.isSkinnedMesh&&(f+=1),f}function a(d,f,p,v,m,g){let _=r[t];return _===void 0?(_={id:d.id,object:d,geometry:f,material:p,materialVariant:o(d),groupOrder:v,renderOrder:d.renderOrder,z:m,group:g},r[t]=_):(_.id=d.id,_.object=d,_.geometry=f,_.material=p,_.materialVariant=o(d),_.groupOrder=v,_.renderOrder=d.renderOrder,_.z=m,_.group=g),t++,_}function l(d,f,p,v,m,g,_){_.reversedDepth===!0&&(m=-m);const M=a(d,f,p,v,m,g);p.transmission>0?i.push(M):p.transparent===!0?n.push(M):e.push(M)}function c(d,f,p,v,m,g){const _=a(d,f,p,v,m,g);p.transmission>0?i.unshift(_):p.transparent===!0?n.unshift(_):e.unshift(_)}function h(d,f){e.length>1&&e.sort(d||Lg),i.length>1&&i.sort(f||Fc),n.length>1&&n.sort(f||Fc)}function u(){for(let d=t,f=r.length;d<f;d++){const p=r[d];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:e,transmissive:i,transparent:n,init:s,push:l,unshift:c,finish:u,sort:h}}function Dg(){let r=new WeakMap;function t(i,n){const s=r.get(i);let o;return s===void 0?(o=new Oc,r.set(i,[o])):n>=s.length?(o=new Oc,s.push(o)):o=s[n],o}function e(){r=new WeakMap}return{get:t,dispose:e}}function Ig(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={direction:new R,color:new ct};break;case"SpotLight":e={position:new R,direction:new R,color:new ct,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new R,color:new ct,distance:0,decay:0};break;case"HemisphereLight":e={direction:new R,skyColor:new ct,groundColor:new ct};break;case"RectAreaLight":e={color:new ct,position:new R,halfWidth:new R,halfHeight:new R};break}return r[t.id]=e,e}}}function Ng(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Q};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Q};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Q,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[t.id]=e,e}}}let Ug=0;function Fg(r,t){return(t.castShadow?2:0)-(r.castShadow?2:0)+(t.map?1:0)-(r.map?1:0)}function Og(r){const t=new Ig,e=Ng(),i={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)i.probe.push(new R);const n=new R,s=new te,o=new te;function a(c){let h=0,u=0,d=0;for(let B=0;B<9;B++)i.probe[B].set(0,0,0);let f=0,p=0,v=0,m=0,g=0,_=0,M=0,y=0,E=0,T=0,x=0,w=0,P=0,C=0;c.sort(Fg);for(let B=0,V=c.length;B<V;B++){const D=c[B],H=D.color,Y=D.intensity,F=D.distance;let et=null;if(D.shadow&&D.shadow.map&&(D.shadow.map.texture.format===Tn?et=D.shadow.map.texture:et=D.shadow.map.depthTexture||D.shadow.map.texture),D.isAmbientLight)h+=H.r*Y,u+=H.g*Y,d+=H.b*Y;else if(D.isLightProbe){for(let X=0;X<9;X++)i.probe[X].addScaledVector(D.sh.coefficients[X],Y);C++}else if(D.isSunLight){const X=t.get(D);if(X.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const tt=D.shadow,it=e.get(D);it.shadowIntensity=tt.intensity,it.shadowBias=tt.bias,it.shadowNormalBias=tt.normalBias,it.shadowRadius=tt.radius,it.shadowMapSize.copy(tt.mapSize).multiply(tt.getFrameExtents()),i.sunShadow[p]=it,i.sunShadowMap[p]=et;const Rt=tt.getViewportCount();for(let Gt=0;Gt<Rt;Gt++)i.sunShadowMatrix[v+Gt]=tt.getMatrix(Gt),i.sunShadowCascade[v+Gt]=tt._cascadeData[Gt];v+=Rt,p++}i.sun[f]=X,f++}else if(D.isDirectionalLight){const X=t.get(D);if(X.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const tt=D.shadow,it=e.get(D);it.shadowIntensity=tt.intensity,it.shadowBias=tt.bias,it.shadowNormalBias=tt.normalBias,it.shadowRadius=tt.radius,it.shadowMapSize=tt.mapSize,i.directionalShadow[m]=it,i.directionalShadowMap[m]=et,i.directionalShadowMatrix[m]=D.shadow.matrix,E++}i.directional[m]=X,m++}else if(D.isSpotLight){const X=t.get(D);X.position.setFromMatrixPosition(D.matrixWorld),X.color.copy(H).multiplyScalar(Y),X.distance=F,X.coneCos=Math.cos(D.angle),X.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),X.decay=D.decay,i.spot[_]=X;const tt=D.shadow;if(D.map&&(i.spotLightMap[w]=D.map,w++,tt.updateMatrices(D),D.castShadow&&P++),i.spotLightMatrix[_]=tt.matrix,D.castShadow){const it=e.get(D);it.shadowIntensity=tt.intensity,it.shadowBias=tt.bias,it.shadowNormalBias=tt.normalBias,it.shadowRadius=tt.radius,it.shadowMapSize=tt.mapSize,i.spotShadow[_]=it,i.spotShadowMap[_]=et,x++}_++}else if(D.isRectAreaLight){const X=t.get(D);X.color.copy(H).multiplyScalar(Y),X.halfWidth.set(D.width*.5,0,0),X.halfHeight.set(0,D.height*.5,0),i.rectArea[M]=X,M++}else if(D.isPointLight){const X=t.get(D);if(X.color.copy(D.color).multiplyScalar(D.intensity),X.distance=D.distance,X.decay=D.decay,D.castShadow){const tt=D.shadow,it=e.get(D);it.shadowIntensity=tt.intensity,it.shadowBias=tt.bias,it.shadowNormalBias=tt.normalBias,it.shadowRadius=tt.radius,it.shadowMapSize=tt.mapSize,it.shadowCameraNear=tt.camera.near,it.shadowCameraFar=tt.camera.far,i.pointShadow[g]=it,i.pointShadowMap[g]=et,i.pointShadowMatrix[g]=D.shadow.matrix,T++}i.point[g]=X,g++}else if(D.isHemisphereLight){const X=t.get(D);X.skyColor.copy(D.color).multiplyScalar(Y),X.groundColor.copy(D.groundColor).multiplyScalar(Y),i.hemi[y]=X,y++}}M>0&&(r.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=xt.LTC_FLOAT_1,i.rectAreaLTC2=xt.LTC_FLOAT_2):(i.rectAreaLTC1=xt.LTC_HALF_1,i.rectAreaLTC2=xt.LTC_HALF_2)),i.ambient[0]=h,i.ambient[1]=u,i.ambient[2]=d;const U=i.hash;(U.sunLength!==f||U.directionalLength!==m||U.pointLength!==g||U.spotLength!==_||U.rectAreaLength!==M||U.hemiLength!==y||U.numSunShadows!==p||U.numDirectionalShadows!==E||U.numPointShadows!==T||U.numSpotShadows!==x||U.numSpotMaps!==w||U.numLightProbes!==C)&&(i.sun.length=f,i.directional.length=m,i.spot.length=_,i.rectArea.length=M,i.point.length=g,i.hemi.length=y,i.sunShadow.length=p,i.sunShadowMap.length=p,i.sunShadowMatrix.length=v,i.sunShadowCascade.length=v,i.directionalShadow.length=E,i.directionalShadowMap.length=E,i.directionalShadowMatrix.length=E,i.pointShadow.length=T,i.pointShadowMap.length=T,i.pointShadowMatrix.length=T,i.spotShadow.length=x,i.spotShadowMap.length=x,i.spotLightMatrix.length=x+w-P,i.spotLightMap.length=w,i.numSpotLightShadowsWithMaps=P,i.numLightProbes=C,U.sunLength=f,U.directionalLength=m,U.pointLength=g,U.spotLength=_,U.rectAreaLength=M,U.hemiLength=y,U.numSunShadows=p,U.numDirectionalShadows=E,U.numPointShadows=T,U.numSpotShadows=x,U.numSpotMaps=w,U.numLightProbes=C,i.version=Ug++)}function l(c,h){let u=0,d=0,f=0,p=0,v=0,m=0;const g=h.matrixWorldInverse;for(let _=0,M=c.length;_<M;_++){const y=c[_];if(y.isSunLight){const E=i.sun[u];E.direction.setFromMatrixPosition(y.matrixWorld),E.direction.transformDirection(g),u++}else if(y.isDirectionalLight){const E=i.directional[d];E.direction.setFromMatrixPosition(y.matrixWorld),n.setFromMatrixPosition(y.target.matrixWorld),E.direction.sub(n),E.direction.transformDirection(g),d++}else if(y.isSpotLight){const E=i.spot[p];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(g),E.direction.setFromMatrixPosition(y.matrixWorld),n.setFromMatrixPosition(y.target.matrixWorld),E.direction.sub(n),E.direction.transformDirection(g),p++}else if(y.isRectAreaLight){const E=i.rectArea[v];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(g),o.identity(),s.copy(y.matrixWorld),s.premultiply(g),o.extractRotation(s),E.halfWidth.set(y.width*.5,0,0),E.halfHeight.set(0,y.height*.5,0),E.halfWidth.applyMatrix4(o),E.halfHeight.applyMatrix4(o),v++}else if(y.isPointLight){const E=i.point[f];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(g),f++}else if(y.isHemisphereLight){const E=i.hemi[m];E.direction.setFromMatrixPosition(y.matrixWorld),E.direction.transformDirection(g),m++}}}return{setup:a,setupView:l,state:i}}function Bc(r){const t=new Og(r),e=[],i=[],n=[];function s(u){h.camera=u,e.length=0,i.length=0,n.length=0}function o(u){u.isLightProbeGrid?n.push(u):e.push(u)}function a(u){i.push(u)}function l(){t.setup(e),n.sort((u,d)=>u.priority-d.priority||u.id-d.id)}function c(u){t.setupView(e,u)}const h={lightsArray:e,shadowsArray:i,lightProbeGridArray:n,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:s,state:h,setupLights:l,setupLightsView:c,pushLight:o,pushShadow:a}}function Bg(r){let t=new WeakMap;function e(n,s=0){const o=t.get(n);let a;return o===void 0?(a=new Bc(r),t.set(n,[a])):s>=o.length?(a=new Bc(r),o.push(a)):a=o[s],a}function i(){t=new WeakMap}return{get:e,dispose:i}}const zg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,kg=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Gg=[new R(1,0,0),new R(-1,0,0),new R(0,1,0),new R(0,-1,0),new R(0,0,1),new R(0,0,-1)],Hg=[new R(0,-1,0),new R(0,-1,0),new R(0,0,1),new R(0,0,-1),new R(0,-1,0),new R(0,-1,0)],zc=new te,ws=new R,Go=new R;function Vg(r,t,e){let i=new ks;const n=new Q,s=new Q,o=new Me,a=new ef,l=new nf,c={},h=e.maxTextureSize,u={[cn]:Je,[Je]:cn,[ae]:ae},d=new Qe({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Q},radius:{value:4}},vertexShader:zg,fragmentShader:kg}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const p=new de;p.setAttribute("position",new ee(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new I(p,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ls;let g=this.type;this.render=function(T,x,w){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||T.length===0)return;this.type===pu&&(Bt("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Ls);const P=r.getRenderTarget(),C=r.getActiveCubeFace(),U=r.getActiveMipmapLevel(),B=r.state;B.setBlending(ts),B.buffers.depth.getReversed()===!0?B.buffers.color.setClear(0,0,0,0):B.buffers.color.setClear(1,1,1,1),B.buffers.depth.setTest(!0),B.setScissorTest(!1);const V=g!==this.type;V&&x.traverse(function(D){D.material&&(Array.isArray(D.material)?D.material.forEach(H=>H.needsUpdate=!0):D.material.needsUpdate=!0)});for(let D=0,H=T.length;D<H;D++){const Y=T[D],F=Y.shadow;if(F===void 0){Bt("WebGLShadowMap:",Y,"has no shadow.");continue}if(F.autoUpdate===!1&&F.needsUpdate===!1)continue;n.copy(F.mapSize);const et=F.getFrameExtents();n.multiply(et),s.copy(F.mapSize),(n.x>h||n.y>h)&&(n.x>h&&(s.x=Math.floor(h/et.x),n.x=s.x*et.x,F.mapSize.x=s.x),n.y>h&&(s.y=Math.floor(h/et.y),n.y=s.y*et.y,F.mapSize.y=s.y));const X=r.state.buffers.depth.getReversed();if(F.camera._reversedDepth=X,F.map===null||V===!0){if(F.map!==null&&(F.map.depthTexture!==null&&(F.map.depthTexture.dispose(),F.map.depthTexture=null),F.map.dispose()),this.type===As){if(Y.isPointLight){Bt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}F.map=new Ai(n.x,n.y,{format:Tn,type:Oi,minFilter:Ze,magFilter:Ze,generateMipmaps:!1}),F.map.texture.name=Y.name+".shadowMap",F.map.depthTexture=new rs(n.x,n.y,Ei),F.map.depthTexture.name=Y.name+".shadowMapDepth",F.map.depthTexture.format=hn,F.map.depthTexture.compareFunction=null,F.map.depthTexture.minFilter=Xe,F.map.depthTexture.magFilter=Xe}else Y.isPointLight?(F.map=new dl(n.x),F.map.depthTexture=new Lh(n.x,Fi)):(F.map=new Ai(n.x,n.y),F.map.depthTexture=new rs(n.x,n.y,Fi)),F.map.depthTexture.name=Y.name+".shadowMap",F.map.depthTexture.format=hn,this.type===Ls?(F.map.depthTexture.compareFunction=X?vh:gh,F.map.depthTexture.minFilter=Ze,F.map.depthTexture.magFilter=Ze):(F.map.depthTexture.compareFunction=null,F.map.depthTexture.minFilter=Xe,F.map.depthTexture.magFilter=Xe);F.camera.updateProjectionMatrix()}F.map.isWebGLCubeRenderTarget!==!0&&(F.map.width!==n.x||F.map.height!==n.y)&&F.map.setSize(n.x,n.y);const tt=F.map.isWebGLCubeRenderTarget?6:F.getViewportCount();Y.isPointLight!==!0&&F.updateMatrices(Y,w);const it=(F.camera.layers.mask&4294967294)!==0?F.camera.layers:w.layers;for(let Rt=0;Rt<tt;Rt++){const Gt=F.getCamera(Rt);if(Y.isPointLight){const Z=F.camera,yt=F.matrix,Et=Y.distance||Z.far;Et!==Z.far&&(Z.far=Et,Z.updateProjectionMatrix()),ws.setFromMatrixPosition(Y.matrixWorld),Z.position.copy(ws),Go.copy(Z.position),Go.add(Gg[Rt]),Z.up.copy(Hg[Rt]),Z.lookAt(Go),Z.updateMatrixWorld(),yt.makeTranslation(-ws.x,-ws.y,-ws.z),zc.multiplyMatrices(Z.projectionMatrix,Z.matrixWorldInverse),F._frustum.setFromProjectionMatrix(zc,Z.coordinateSystem,Z.reversedDepth)}if(F.map.isWebGLCubeRenderTarget)r.setRenderTarget(F.map,Rt),r.clear();else{Rt===0&&(r.setRenderTarget(F.map),r.clear());const Z=F.getViewport(Rt);o.set(s.x*Z.x,s.y*Z.y,s.x*Z.z,s.y*Z.w),B.viewport(o)}i=F.getFrustum(Rt),y(x,w,Gt,Y,it,this.type)}F.isPointLightShadow!==!0&&this.type===As&&_(F,w),F.needsUpdate=!1}g=this.type,m.needsUpdate=!1,r.setRenderTarget(P,C,U)};function _(T,x){const w=t.update(v);d.defines.VSM_SAMPLES!==T.blurSamples&&(d.defines.VSM_SAMPLES=T.blurSamples,f.defines.VSM_SAMPLES=T.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),T.mapPass===null?T.mapPass=new Ai(n.x,n.y,{format:Tn,type:Oi}):(T.mapPass.width!==T.map.width||T.mapPass.height!==T.map.height)&&T.mapPass.setSize(T.map.width,T.map.height),d.uniforms.shadow_pass.value=T.map.depthTexture,d.uniforms.resolution.value.set(T.map.width,T.map.height),d.uniforms.radius.value=T.radius,r.setRenderTarget(T.mapPass),r.clear(),r.renderBufferDirect(x,null,w,d,v,null),f.uniforms.shadow_pass.value=T.mapPass.texture,f.uniforms.resolution.value.set(T.map.width,T.map.height),f.uniforms.radius.value=T.radius,r.setRenderTarget(T.map),r.clear(),r.renderBufferDirect(x,null,w,f,v,null)}function M(T,x,w,P){let C=null;const U=w.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(U!==void 0)C=U;else if(C=w.isPointLight===!0?l:a,r.localClippingEnabled&&x.clipShadows===!0&&Array.isArray(x.clippingPlanes)&&x.clippingPlanes.length!==0||x.displacementMap&&x.displacementScale!==0||x.alphaMap&&x.alphaTest>0||x.map&&x.alphaTest>0||x.alphaToCoverage===!0){const B=C.uuid,V=x.uuid;let D=c[B];D===void 0&&(D={},c[B]=D);let H=D[V];H===void 0&&(H=C.clone(),D[V]=H,x.addEventListener("dispose",E)),C=H}if(C.visible=x.visible,C.wireframe=x.wireframe,P===As?C.side=x.shadowSide!==null?x.shadowSide:x.side:C.side=x.shadowSide!==null?x.shadowSide:u[x.side],C.alphaMap=x.alphaMap,C.alphaTest=x.alphaToCoverage===!0?.5:x.alphaTest,C.map=x.map,C.clipShadows=x.clipShadows,C.clippingPlanes=x.clippingPlanes,C.clipIntersection=x.clipIntersection,C.displacementMap=x.displacementMap,C.displacementScale=x.displacementScale,C.displacementBias=x.displacementBias,C.wireframeLinewidth=x.wireframeLinewidth,C.linewidth=x.linewidth,w.isPointLight===!0&&C.isMeshDistanceMaterial===!0){const B=r.properties.get(C);B.light=w}return C}function y(T,x,w,P,C,U){if(T.visible===!1)return;if(T.layers.test(C)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&U===As)&&(!T.frustumCulled||T.intersectsFrustum(i))){T.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,T.matrixWorld);const D=t.update(T),H=T.material;if(Array.isArray(H)){const Y=D.groups;for(let F=0,et=Y.length;F<et;F++){const X=Y[F],tt=H[X.materialIndex];if(tt&&tt.visible){const it=M(T,tt,P,U);T.onBeforeShadow(r,T,x,w,D,it,X),r.renderBufferDirect(w,null,D,it,T,X),T.onAfterShadow(r,T,x,w,D,it,X)}}}else if(H.visible){const Y=M(T,H,P,U);T.onBeforeShadow(r,T,x,w,D,Y,null),r.renderBufferDirect(w,null,D,Y,T,null),T.onAfterShadow(r,T,x,w,D,Y,null)}}const V=T.children;for(let D=0,H=V.length;D<H;D++)y(V[D],x,w,P,C,U)}function E(T){T.target.removeEventListener("dispose",E);for(const w in c){const P=c[w],C=T.target.uuid;C in P&&(P[C].dispose(),delete P[C])}}}function Wg(r,t){function e(){let L=!1;const J=new Me;let q=null;const ut=new Me(0,0,0,0);return{setMask:function(ot){q!==ot&&!L&&(r.colorMask(ot,ot,ot,ot),q=ot)},setLocked:function(ot){L=ot},setClear:function(ot,lt,Pt,qt,rt){rt===!0&&(ot*=qt,lt*=qt,Pt*=qt),J.set(ot,lt,Pt,qt),ut.equals(J)===!1&&(r.clearColor(ot,lt,Pt,qt),ut.copy(J))},reset:function(){L=!1,q=null,ut.set(-1,0,0,0)}}}function i(){let L=!1,J=!1,q=null,ut=null,ot=null;return{setReversed:function(lt){if(J!==lt){const Pt=t.get("EXT_clip_control");lt?Pt.clipControlEXT(Pt.LOWER_LEFT_EXT,Pt.ZERO_TO_ONE_EXT):Pt.clipControlEXT(Pt.LOWER_LEFT_EXT,Pt.NEGATIVE_ONE_TO_ONE_EXT),J=lt;const qt=ot;ot=null,this.setClear(qt)}},getReversed:function(){return J},setTest:function(lt){lt?Mt(r.DEPTH_TEST):Vt(r.DEPTH_TEST)},setMask:function(lt){q!==lt&&!L&&(r.depthMask(lt),q=lt)},setFunc:function(lt){if(J&&(lt=Yu[lt]),ut!==lt){switch(lt){case Ko:r.depthFunc(r.NEVER);break;case Zo:r.depthFunc(r.ALWAYS);break;case Jo:r.depthFunc(r.LESS);break;case Fs:r.depthFunc(r.LEQUAL);break;case jo:r.depthFunc(r.EQUAL);break;case Qo:r.depthFunc(r.GEQUAL);break;case ta:r.depthFunc(r.GREATER);break;case ea:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}ut=lt}},setLocked:function(lt){L=lt},setClear:function(lt){ot!==lt&&(ot=lt,J&&(lt=1-lt),r.clearDepth(lt))},reset:function(){L=!1,q=null,ut=null,ot=null,J=!1}}}function n(){let L=!1,J=null,q=null,ut=null,ot=null,lt=null,Pt=null,qt=null,rt=null;return{setTest:function(Dt){L||(Dt?Mt(r.STENCIL_TEST):Vt(r.STENCIL_TEST))},setMask:function(Dt){J!==Dt&&!L&&(r.stencilMask(Dt),J=Dt)},setFunc:function(Dt,Wt,_t){(q!==Dt||ut!==Wt||ot!==_t)&&(r.stencilFunc(Dt,Wt,_t),q=Dt,ut=Wt,ot=_t)},setOp:function(Dt,Wt,_t){(lt!==Dt||Pt!==Wt||qt!==_t)&&(r.stencilOp(Dt,Wt,_t),lt=Dt,Pt=Wt,qt=_t)},setLocked:function(Dt){L=Dt},setClear:function(Dt){rt!==Dt&&(r.clearStencil(Dt),rt=Dt)},reset:function(){L=!1,J=null,q=null,ut=null,ot=null,lt=null,Pt=null,qt=null,rt=null}}}const s=new e,o=new i,a=new n;let l={};const c=new WeakMap;let h={},u={},d={},f=new WeakMap,p=[],v=null,m=!1,g=null,_=null,M=null,y=null,E=null,T=null,x=null,w=new ct(0,0,0),P=0,C=!1,U=null,B=null,V=null,D=null,H=null;const Y=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let F=!1,et=0;const X=r.getParameter(r.VERSION);X.indexOf("WebGL")!==-1?(et=parseFloat(/^WebGL (\d)/.exec(X)[1]),F=et>=1):X.indexOf("OpenGL ES")!==-1&&(et=parseFloat(/^OpenGL ES (\d)/.exec(X)[1]),F=et>=2);let tt=null,it={};const Rt=r.getParameter(r.SCISSOR_BOX),Gt=r.getParameter(r.VIEWPORT),Z=new Me().fromArray(Rt),yt=new Me().fromArray(Gt);function Et(L,J,q,ut){const ot=new Uint8Array(4),lt=r.createTexture();r.bindTexture(L,lt),r.texParameteri(L,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(L,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let Pt=0;Pt<q;Pt++)L===r.TEXTURE_3D||L===r.TEXTURE_2D_ARRAY?r.texImage3D(J,0,r.RGBA,1,1,ut,0,r.RGBA,r.UNSIGNED_BYTE,ot):r.texImage2D(J+Pt,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,ot);return lt}const Nt={};Nt[r.TEXTURE_2D]=Et(r.TEXTURE_2D,r.TEXTURE_2D,1),Nt[r.TEXTURE_CUBE_MAP]=Et(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),Nt[r.TEXTURE_2D_ARRAY]=Et(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),Nt[r.TEXTURE_3D]=Et(r.TEXTURE_3D,r.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),a.setClear(0),Mt(r.DEPTH_TEST),o.setFunc(Fs),ri(!1),xe(Pl),Mt(r.CULL_FACE),He(ts);function Mt(L){h[L]!==!0&&(r.enable(L),h[L]=!0)}function Vt(L){h[L]!==!1&&(r.disable(L),h[L]=!1)}function Ae(L,J){return d[L]!==J?(r.bindFramebuffer(L,J),d[L]=J,L===r.DRAW_FRAMEBUFFER&&(d[r.FRAMEBUFFER]=J),L===r.FRAMEBUFFER&&(d[r.DRAW_FRAMEBUFFER]=J),!0):!1}function Ot(L,J){let q=p,ut=!1;if(L){q=f.get(J),q===void 0&&(q=[],f.set(J,q));const ot=L.textures;if(q.length!==ot.length||q[0]!==r.COLOR_ATTACHMENT0){for(let lt=0,Pt=ot.length;lt<Pt;lt++)q[lt]=r.COLOR_ATTACHMENT0+lt;q.length=ot.length,ut=!0}}else q[0]!==r.BACK&&(q[0]=r.BACK,ut=!0);ut&&r.drawBuffers(q)}function le(L){return v!==L?(r.useProgram(L),v=L,!0):!1}const fe={[Jn]:r.FUNC_ADD,[gu]:r.FUNC_SUBTRACT,[vu]:r.FUNC_REVERSE_SUBTRACT};fe[_u]=r.MIN,fe[xu]=r.MAX;const Zt={[yu]:r.ZERO,[Mu]:r.ONE,[Su]:r.SRC_COLOR,[th]:r.SRC_ALPHA,[Ru]:r.SRC_ALPHA_SATURATE,[Tu]:r.DST_COLOR,[bu]:r.DST_ALPHA,[wu]:r.ONE_MINUS_SRC_COLOR,[eh]:r.ONE_MINUS_SRC_ALPHA,[Au]:r.ONE_MINUS_DST_COLOR,[Eu]:r.ONE_MINUS_DST_ALPHA,[Cu]:r.CONSTANT_COLOR,[Pu]:r.ONE_MINUS_CONSTANT_COLOR,[Lu]:r.CONSTANT_ALPHA,[Du]:r.ONE_MINUS_CONSTANT_ALPHA};function He(L,J,q,ut,ot,lt,Pt,qt,rt,Dt){if(L===ts){m===!0&&(Vt(r.BLEND),m=!1);return}if(m===!1&&(Mt(r.BLEND),m=!0),L!==mu){if(L!==g||Dt!==C){if((_!==Jn||E!==Jn)&&(r.blendEquation(r.FUNC_ADD),_=Jn,E=Jn),Dt)switch(L){case Yi:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Ne:r.blendFunc(r.ONE,r.ONE);break;case Ll:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case Dl:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:se("WebGLState: Invalid blending: ",L);break}else switch(L){case Yi:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Ne:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case Ll:se("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Dl:se("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:se("WebGLState: Invalid blending: ",L);break}M=null,y=null,T=null,x=null,w.set(0,0,0),P=0,g=L,C=Dt}return}ot=ot||J,lt=lt||q,Pt=Pt||ut,(J!==_||ot!==E)&&(r.blendEquationSeparate(fe[J],fe[ot]),_=J,E=ot),(q!==M||ut!==y||lt!==T||Pt!==x)&&(r.blendFuncSeparate(Zt[q],Zt[ut],Zt[lt],Zt[Pt]),M=q,y=ut,T=lt,x=Pt),(qt.equals(w)===!1||rt!==P)&&(r.blendColor(qt.r,qt.g,qt.b,rt),w.copy(qt),P=rt),g=L,C=!1}function Pe(L,J){L.side===ae?Vt(r.CULL_FACE):Mt(r.CULL_FACE);let q=L.side===Je;J&&(q=!q),ri(q),L.blending===Yi&&L.transparent===!1?He(ts):He(L.blending,L.blendEquation,L.blendSrc,L.blendDst,L.blendEquationAlpha,L.blendSrcAlpha,L.blendDstAlpha,L.blendColor,L.blendAlpha,L.premultipliedAlpha),o.setFunc(L.depthFunc),o.setTest(L.depthTest),o.setMask(L.depthWrite),s.setMask(L.colorWrite);const ut=L.stencilWrite;a.setTest(ut),ut&&(a.setMask(L.stencilWriteMask),a.setFunc(L.stencilFunc,L.stencilRef,L.stencilFuncMask),a.setOp(L.stencilFail,L.stencilZFail,L.stencilZPass)),Oe(L.polygonOffset,L.polygonOffsetFactor,L.polygonOffsetUnits),L.alphaToCoverage===!0?Mt(r.SAMPLE_ALPHA_TO_COVERAGE):Vt(r.SAMPLE_ALPHA_TO_COVERAGE)}function ri(L){U!==L&&(L?r.frontFace(r.CW):r.frontFace(r.CCW),U=L)}function xe(L){L!==du?(Mt(r.CULL_FACE),L!==B&&(L===Pl?r.cullFace(r.BACK):L===fu?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Vt(r.CULL_FACE),B=L}function Ri(L){L!==V&&(F&&r.lineWidth(L),V=L)}function Oe(L,J,q){L?(Mt(r.POLYGON_OFFSET_FILL),(D!==J||H!==q)&&(D=J,H=q,o.getReversed()&&(J=-J,q=-q),r.polygonOffset(J,q))):Vt(r.POLYGON_OFFSET_FILL)}function mi(L){L?Mt(r.SCISSOR_TEST):Vt(r.SCISSOR_TEST)}function gi(L){L===void 0&&(L=r.TEXTURE0+Y-1),tt!==L&&(r.activeTexture(L),tt=L)}function vi(L,J,q){q===void 0&&(tt===null?q=r.TEXTURE0+Y-1:q=tt);let ut=it[q];ut===void 0&&(ut={type:void 0,texture:void 0},it[q]=ut),(ut.type!==L||ut.texture!==J)&&(tt!==q&&(r.activeTexture(q),tt=q),r.bindTexture(L,J||Nt[L]),ut.type=L,ut.texture=J)}function O(){const L=it[tt];L!==void 0&&L.type!==void 0&&(r.bindTexture(L.type,null),L.type=void 0,L.texture=void 0)}function _i(){try{r.compressedTexImage2D(...arguments)}catch(L){se("WebGLState:",L)}}function ge(){try{r.compressedTexImage3D(...arguments)}catch(L){se("WebGLState:",L)}}function ve(){try{r.texSubImage2D(...arguments)}catch(L){se("WebGLState:",L)}}function vt(){try{r.texSubImage3D(...arguments)}catch(L){se("WebGLState:",L)}}function Le(){try{r.compressedTexSubImage2D(...arguments)}catch(L){se("WebGLState:",L)}}function Ut(){try{r.compressedTexSubImage3D(...arguments)}catch(L){se("WebGLState:",L)}}function zt(){try{r.texStorage2D(...arguments)}catch(L){se("WebGLState:",L)}}function A(){try{r.texStorage3D(...arguments)}catch(L){se("WebGLState:",L)}}function S(){try{r.texImage2D(...arguments)}catch(L){se("WebGLState:",L)}}function k(){try{r.texImage3D(...arguments)}catch(L){se("WebGLState:",L)}}function nt(L){return u[L]!==void 0?u[L]:r.getParameter(L)}function j(L,J){u[L]!==J&&(r.pixelStorei(L,J),u[L]=J)}function at(L){Z.equals(L)===!1&&(r.scissor(L.x,L.y,L.z,L.w),Z.copy(L))}function pt(L){yt.equals(L)===!1&&(r.viewport(L.x,L.y,L.z,L.w),yt.copy(L))}function $(L,J){let q=c.get(J);q===void 0&&(q=new WeakMap,c.set(J,q));let ut=q.get(L);ut===void 0&&(ut=r.getUniformBlockIndex(J,L.name),r.uniformBlockBinding(J,ut,ut),q.set(L,ut))}function K(L,J,q){const ot=c.get(J).get(L);l[ot]!==q&&(r.bindBufferBase(r.UNIFORM_BUFFER,ot,q),l[ot]=q)}function ht(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),o.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),h={},u={},tt=null,it={},d={},l={},f=new WeakMap,p=[],v=null,m=!1,g=null,_=null,M=null,y=null,E=null,T=null,x=null,w=new ct(0,0,0),P=0,C=!1,U=null,B=null,V=null,D=null,H=null,Z.set(0,0,r.canvas.width,r.canvas.height),yt.set(0,0,r.canvas.width,r.canvas.height),s.reset(),o.reset(),a.reset()}return{buffers:{color:s,depth:o,stencil:a},enable:Mt,disable:Vt,bindFramebuffer:Ae,drawBuffers:Ot,useProgram:le,setBlending:He,setMaterial:Pe,setFlipSided:ri,setCullFace:xe,setLineWidth:Ri,setPolygonOffset:Oe,setScissorTest:mi,activeTexture:gi,bindTexture:vi,unbindTexture:O,compressedTexImage2D:_i,compressedTexImage3D:ge,texImage2D:S,texImage3D:k,pixelStorei:j,getParameter:nt,updateUBOMapping:$,uniformBlockBinding:K,texStorage2D:zt,texStorage3D:A,texSubImage2D:ve,texSubImage3D:vt,compressedTexSubImage2D:Le,compressedTexSubImage3D:Ut,scissor:at,viewport:pt,reset:ht}}function Xg(r,t,e,i,n,s,o){const a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Q,h=new WeakMap,u=new Set;let d;const f=new WeakMap,p=new Set,v=new FinalizationRegistry(A=>p.delete(A));let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,S){return m?new OffscreenCanvas(A,S):Xr("canvas")}function _(A,S,k){let nt=1;const j=zt(A);if((j.width>k||j.height>k)&&(nt=k/Math.max(j.width,j.height)),nt<1)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){const at=Math.floor(nt*j.width),pt=Math.floor(nt*j.height);d===void 0&&(d=g(at,pt));const $=S?g(at,pt):d;return $.width=at,$.height=pt,$.getContext("2d").drawImage(A,0,0,at,pt),Bt("WebGLRenderer: Texture has been resized from ("+j.width+"x"+j.height+") to ("+at+"x"+pt+")."),$}else return"data"in A&&Bt("WebGLRenderer: Image in DataTexture is too big ("+j.width+"x"+j.height+")."),A;return A}function M(A){return A.generateMipmaps}function y(A){r.generateMipmap(A)}function E(A){return A.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?r.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function T(A,S,k,nt,j,at=!1){if(A!==null){if(r[A]!==void 0)return r[A];Bt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let pt;nt&&(pt=t.get("EXT_texture_norm16"),pt||Bt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let $=S;if(S===r.RED&&(k===r.FLOAT&&($=r.R32F),k===r.HALF_FLOAT&&($=r.R16F),k===r.UNSIGNED_BYTE&&($=r.R8),k===r.UNSIGNED_SHORT&&pt&&($=pt.R16_EXT),k===r.SHORT&&pt&&($=pt.R16_SNORM_EXT)),S===r.RED_INTEGER&&(k===r.UNSIGNED_BYTE&&($=r.R8UI),k===r.UNSIGNED_SHORT&&($=r.R16UI),k===r.UNSIGNED_INT&&($=r.R32UI),k===r.BYTE&&($=r.R8I),k===r.SHORT&&($=r.R16I),k===r.INT&&($=r.R32I)),S===r.RG&&(k===r.FLOAT&&($=r.RG32F),k===r.HALF_FLOAT&&($=r.RG16F),k===r.UNSIGNED_BYTE&&($=r.RG8),k===r.UNSIGNED_SHORT&&pt&&($=pt.RG16_EXT),k===r.SHORT&&pt&&($=pt.RG16_SNORM_EXT)),S===r.RG_INTEGER&&(k===r.UNSIGNED_BYTE&&($=r.RG8UI),k===r.UNSIGNED_SHORT&&($=r.RG16UI),k===r.UNSIGNED_INT&&($=r.RG32UI),k===r.BYTE&&($=r.RG8I),k===r.SHORT&&($=r.RG16I),k===r.INT&&($=r.RG32I)),S===r.RGB_INTEGER&&(k===r.UNSIGNED_BYTE&&($=r.RGB8UI),k===r.UNSIGNED_SHORT&&($=r.RGB16UI),k===r.UNSIGNED_INT&&($=r.RGB32UI),k===r.BYTE&&($=r.RGB8I),k===r.SHORT&&($=r.RGB16I),k===r.INT&&($=r.RGB32I)),S===r.RGBA_INTEGER&&(k===r.UNSIGNED_BYTE&&($=r.RGBA8UI),k===r.UNSIGNED_SHORT&&($=r.RGBA16UI),k===r.UNSIGNED_INT&&($=r.RGBA32UI),k===r.BYTE&&($=r.RGBA8I),k===r.SHORT&&($=r.RGBA16I),k===r.INT&&($=r.RGBA32I)),S===r.RGB&&(k===r.UNSIGNED_SHORT&&pt&&($=pt.RGB16_EXT),k===r.SHORT&&pt&&($=pt.RGB16_SNORM_EXT),k===r.UNSIGNED_INT_5_9_9_9_REV&&($=r.RGB9_E5),k===r.UNSIGNED_INT_10F_11F_11F_REV&&($=r.R11F_G11F_B10F)),S===r.RGBA){const K=at?Wr:Qt.getTransfer(j);k===r.FLOAT&&($=r.RGBA32F),k===r.HALF_FLOAT&&($=r.RGBA16F),k===r.UNSIGNED_BYTE&&($=K===he?r.SRGB8_ALPHA8:r.RGBA8),k===r.UNSIGNED_SHORT&&pt&&($=pt.RGBA16_EXT),k===r.SHORT&&pt&&($=pt.RGBA16_SNORM_EXT),k===r.UNSIGNED_SHORT_4_4_4_4&&($=r.RGBA4),k===r.UNSIGNED_SHORT_5_5_5_1&&($=r.RGB5_A1)}return($===r.R16F||$===r.R32F||$===r.RG16F||$===r.RG32F||$===r.RGBA16F||$===r.RGBA32F)&&t.get("EXT_color_buffer_float"),$}function x(A,S){let k;return A?S===null||S===Fi||S===ss?k=r.DEPTH24_STENCIL8:S===Ei?k=r.DEPTH32F_STENCIL8:S===Bs&&(k=r.DEPTH24_STENCIL8,Bt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):S===null||S===Fi||S===ss?k=r.DEPTH_COMPONENT24:S===Ei?k=r.DEPTH_COMPONENT32F:S===Bs&&(k=r.DEPTH_COMPONENT16),k}function w(A,S){return M(A)===!0||A.isFramebufferTexture&&A.minFilter!==Xe&&A.minFilter!==Ze?Math.log2(Math.max(S.width,S.height))+1:A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?S.mipmaps.length:1}function P(A){const S=new WeakRef(A);i.get(A).__ref=S,p.add(S),v.register(A,S,S)}function C(A){const S=i.get(A).__ref;S!==void 0&&(p.delete(S),v.unregister(S))}function U(A){V(A.target)}function B(A){D(A.target)}function V(A){A.removeEventListener("dispose",U),C(A),Y(A),A.isVideoTexture&&h.delete(A),A.isHTMLTexture&&u.delete(A)}function D(A){A.removeEventListener("dispose",B),C(A),et(A)}function H(){for(const A of p){const S=A.deref();S!==void 0&&(S.isRenderTarget===!0?D(S):V(S))}p.clear(),u.clear()}function Y(A){const S=i.get(A);if(S.__webglInit===void 0)return;const k=A.source,nt=f.get(k);if(nt){const j=nt[S.__cacheKey];j.usedTimes--,j.usedTimes===0&&F(A),Object.keys(nt).length===0&&f.delete(k)}i.remove(A)}function F(A){const S=i.get(A);r.deleteTexture(S.__webglTexture);const k=A.source,nt=f.get(k);delete nt[S.__cacheKey],o.memory.textures--}function et(A){const S=i.get(A);S.__depthDisposeCallback&&S.__depthDisposeCallback();const k=A.depthTexture;if(k&&k.renderTarget===A&&V(k),A.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(S.__webglFramebuffer[j]))for(let at=0;at<S.__webglFramebuffer[j].length;at++)r.deleteFramebuffer(S.__webglFramebuffer[j][at]);else r.deleteFramebuffer(S.__webglFramebuffer[j]);S.__webglDepthbuffer&&r.deleteRenderbuffer(S.__webglDepthbuffer[j])}else{if(Array.isArray(S.__webglFramebuffer))for(let j=0;j<S.__webglFramebuffer.length;j++)r.deleteFramebuffer(S.__webglFramebuffer[j]);else r.deleteFramebuffer(S.__webglFramebuffer);if(S.__webglDepthbuffer&&r.deleteRenderbuffer(S.__webglDepthbuffer),S.__webglMultisampledFramebuffer&&r.deleteFramebuffer(S.__webglMultisampledFramebuffer),S.__webglColorRenderbuffer)for(let j=0;j<S.__webglColorRenderbuffer.length;j++)S.__webglColorRenderbuffer[j]&&r.deleteRenderbuffer(S.__webglColorRenderbuffer[j]);S.__webglDepthRenderbuffer&&r.deleteRenderbuffer(S.__webglDepthRenderbuffer)}const nt=A.textures;for(let j=0,at=nt.length;j<at;j++){const pt=i.get(nt[j]);pt.__webglTexture&&(r.deleteTexture(pt.__webglTexture),o.memory.textures--),i.remove(nt[j])}i.remove(A)}let X=0;function tt(){X=0}function it(){return X}function Rt(A){X=A}function Gt(){const A=X;return A>=n.maxTextures&&Bt("WebGLTextures: Trying to use "+(A+1)+" texture units while this GPU supports only "+n.maxTextures),X+=1,A}function Z(A){const S=[];return S.push(A.wrapS),S.push(A.wrapT),S.push(A.wrapR||0),S.push(A.magFilter),S.push(A.minFilter),S.push(A.anisotropy),S.push(A.internalFormat),S.push(A.format),S.push(A.type),S.push(A.generateMipmaps),S.push(A.mipmapsAutoUpdate),S.push(A.premultiplyAlpha),S.push(A.flipY),S.push(A.unpackAlignment),S.push(A.colorSpace),S.join()}function yt(A,S){const k=i.get(A);if(A.isVideoTexture&&Le(A),A.isRenderTargetTexture===!1&&A.isExternalTexture!==!0&&A.version>0&&k.__version!==A.version){const nt=A.image;if(nt===null)Bt("WebGLRenderer: Texture marked for update but no image data found.");else if(nt.complete===!1)Bt("WebGLRenderer: Texture marked for update but image is incomplete");else{Pe(k,A,S);return}}else A.isExternalTexture&&(k.__webglTexture=A.sourceTexture?A.sourceTexture:null);e.bindTexture(r.TEXTURE_2D,k.__webglTexture,r.TEXTURE0+S)}function Et(A,S){const k=i.get(A);if(A.isRenderTargetTexture===!1&&A.version>0&&k.__version!==A.version){Pe(k,A,S);return}else A.isExternalTexture&&(k.__webglTexture=A.sourceTexture?A.sourceTexture:null);e.bindTexture(r.TEXTURE_2D_ARRAY,k.__webglTexture,r.TEXTURE0+S)}function Nt(A,S){const k=i.get(A);if(A.isRenderTargetTexture===!1&&A.version>0&&k.__version!==A.version){Pe(k,A,S);return}e.bindTexture(r.TEXTURE_3D,k.__webglTexture,r.TEXTURE0+S)}function Mt(A,S){const k=i.get(A);if(A.version>0&&k.__version!==A.version){ri(k,A,S);return}e.bindTexture(r.TEXTURE_CUBE_MAP,k.__webglTexture,r.TEXTURE0+S)}const Vt={[En]:r.REPEAT,[Ii]:r.CLAMP_TO_EDGE,[ia]:r.MIRRORED_REPEAT},Ae={[Xe]:r.NEAREST,[Uu]:r.NEAREST_MIPMAP_NEAREST,[Qs]:r.NEAREST_MIPMAP_LINEAR,[Ze]:r.LINEAR,[ho]:r.LINEAR_MIPMAP_NEAREST,[an]:r.LINEAR_MIPMAP_LINEAR},Ot={[zu]:r.NEVER,[_h]:r.ALWAYS,[ku]:r.LESS,[gh]:r.LEQUAL,[Gu]:r.EQUAL,[vh]:r.GEQUAL,[Hu]:r.GREATER,[Vu]:r.NOTEQUAL};function le(A,S){if(S.type===Ei&&t.has("OES_texture_float_linear")===!1&&(S.magFilter===Ze||S.magFilter===ho||S.magFilter===Qs||S.magFilter===an||S.minFilter===Ze||S.minFilter===ho||S.minFilter===Qs||S.minFilter===an)&&Bt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(A,r.TEXTURE_WRAP_S,Vt[S.wrapS]),r.texParameteri(A,r.TEXTURE_WRAP_T,Vt[S.wrapT]),(A===r.TEXTURE_3D||A===r.TEXTURE_2D_ARRAY)&&r.texParameteri(A,r.TEXTURE_WRAP_R,Vt[S.wrapR]),r.texParameteri(A,r.TEXTURE_MAG_FILTER,Ae[S.magFilter]),r.texParameteri(A,r.TEXTURE_MIN_FILTER,Ae[S.minFilter]),S.compareFunction&&(r.texParameteri(A,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(A,r.TEXTURE_COMPARE_FUNC,Ot[S.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(S.magFilter===Xe||S.minFilter!==Qs&&S.minFilter!==an||S.type===Ei&&t.has("OES_texture_float_linear")===!1)return;if(S.anisotropy>1||i.get(S).__currentAnisotropy){const k=t.get("EXT_texture_filter_anisotropic");r.texParameterf(A,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(S.anisotropy,n.getMaxAnisotropy())),i.get(S).__currentAnisotropy=S.anisotropy}}}function fe(A,S){let k=!1;A.__webglInit===void 0&&(A.__webglInit=!0,S.addEventListener("dispose",U),P(S));const nt=S.source;let j=f.get(nt);j===void 0&&(j={},f.set(nt,j));const at=Z(S);if(at!==A.__cacheKey){j[at]===void 0&&(j[at]={texture:r.createTexture(),usedTimes:0},o.memory.textures++,k=!0),j[at].usedTimes++;const pt=j[A.__cacheKey];pt!==void 0&&(j[A.__cacheKey].usedTimes--,pt.usedTimes===0&&F(S)),A.__cacheKey=at,A.__webglTexture=j[at].texture}return k}function Zt(A,S,k){return Math.floor(Math.floor(A/k)/S)}function He(A,S,k,nt){const at=A.updateRanges;if(at.length===0)e.texSubImage2D(r.TEXTURE_2D,0,0,0,S.width,S.height,k,nt,S.data);else{at.sort((L,J)=>L.start-J.start);let pt=0;for(let L=1;L<at.length;L++){const J=at[pt],q=at[L],ut=J.start+J.count,ot=Zt(q.start,S.width,4),lt=Zt(J.start,S.width,4);q.start<=ut+1&&ot===lt&&Zt(q.start+q.count-1,S.width,4)===ot?J.count=Math.max(J.count,q.start+q.count-J.start):(++pt,at[pt]=q)}at.length=pt+1;const $=e.getParameter(r.UNPACK_ROW_LENGTH),K=e.getParameter(r.UNPACK_SKIP_PIXELS),ht=e.getParameter(r.UNPACK_SKIP_ROWS);e.pixelStorei(r.UNPACK_ROW_LENGTH,S.width);for(let L=0,J=at.length;L<J;L++){const q=at[L],ut=Math.floor(q.start/4),ot=Math.ceil(q.count/4),lt=ut%S.width,Pt=Math.floor(ut/S.width),qt=ot,rt=1;e.pixelStorei(r.UNPACK_SKIP_PIXELS,lt),e.pixelStorei(r.UNPACK_SKIP_ROWS,Pt),e.texSubImage2D(r.TEXTURE_2D,0,lt,Pt,qt,rt,k,nt,S.data)}A.clearUpdateRanges(),e.pixelStorei(r.UNPACK_ROW_LENGTH,$),e.pixelStorei(r.UNPACK_SKIP_PIXELS,K),e.pixelStorei(r.UNPACK_SKIP_ROWS,ht)}}function Pe(A,S,k){let nt=r.TEXTURE_2D;(S.isDataArrayTexture||S.isCompressedArrayTexture)&&(nt=r.TEXTURE_2D_ARRAY),S.isData3DTexture&&(nt=r.TEXTURE_3D);const j=fe(A,S),at=S.source;e.bindTexture(nt,A.__webglTexture,r.TEXTURE0+k);const pt=i.get(at);if(at.version!==pt.__version||j===!0){if(e.activeTexture(r.TEXTURE0+k),(typeof ImageBitmap<"u"&&S.image instanceof ImageBitmap)===!1){const rt=Qt.getPrimaries(Qt.workingColorSpace),Dt=S.colorSpace===qi?null:Qt.getPrimaries(S.colorSpace),Wt=S.colorSpace===qi||rt===Dt?r.NONE:r.BROWSER_DEFAULT_WEBGL;e.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,S.flipY),e.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),e.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Wt)}e.pixelStorei(r.UNPACK_ALIGNMENT,S.unpackAlignment);let K=_(S.image,!1,n.maxTextureSize);K=Ut(S,K);const ht=s.convert(S.format,S.colorSpace),L=s.convert(S.type);let J=T(S.internalFormat,ht,L,S.normalized,S.colorSpace,S.isVideoTexture);le(nt,S);let q;const ut=S.mipmaps,ot=S.isVideoTexture!==!0,lt=pt.__version===void 0||j===!0,Pt=at.dataReady,qt=w(S,K);if(S.isDepthTexture)J=x(S.format===ln,S.type),lt&&(ot?e.texStorage2D(r.TEXTURE_2D,1,J,K.width,K.height):e.texImage2D(r.TEXTURE_2D,0,J,K.width,K.height,0,ht,L,null));else if(S.isDataTexture)if(ut.length>0){ot&&lt&&e.texStorage2D(r.TEXTURE_2D,qt,J,ut[0].width,ut[0].height);for(let rt=0,Dt=ut.length;rt<Dt;rt++)q=ut[rt],ot?Pt&&e.texSubImage2D(r.TEXTURE_2D,rt,0,0,q.width,q.height,ht,L,q.data):e.texImage2D(r.TEXTURE_2D,rt,J,q.width,q.height,0,ht,L,q.data);S.generateMipmaps=!1}else ot?(lt&&e.texStorage2D(r.TEXTURE_2D,qt,J,K.width,K.height),Pt&&He(S,K,ht,L)):e.texImage2D(r.TEXTURE_2D,0,J,K.width,K.height,0,ht,L,K.data);else if(S.isCompressedTexture)if(S.isCompressedArrayTexture){ot&&lt&&e.texStorage3D(r.TEXTURE_2D_ARRAY,qt,J,ut[0].width,ut[0].height,K.depth);for(let rt=0,Dt=ut.length;rt<Dt;rt++)if(q=ut[rt],S.format!==Ni)if(ht!==null)if(ot){if(Pt)if(S.layerUpdates.size>0){const Wt=_c(q.width,q.height,S.format,S.type);for(const _t of S.layerUpdates){const ce=q.data.subarray(_t*Wt/q.data.BYTES_PER_ELEMENT,(_t+1)*Wt/q.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,rt,0,0,_t,q.width,q.height,1,ht,ce)}}else e.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,rt,0,0,0,q.width,q.height,K.depth,ht,q.data)}else e.compressedTexImage3D(r.TEXTURE_2D_ARRAY,rt,J,q.width,q.height,K.depth,0,q.data,0,0);else Bt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else ot?Pt&&e.texSubImage3D(r.TEXTURE_2D_ARRAY,rt,0,0,0,q.width,q.height,K.depth,ht,L,q.data):e.texImage3D(r.TEXTURE_2D_ARRAY,rt,J,q.width,q.height,K.depth,0,ht,L,q.data);S.layerUpdates.size>0&&S.clearLayerUpdates()}else{ot&&lt&&e.texStorage2D(r.TEXTURE_2D,qt,J,ut[0].width,ut[0].height);for(let rt=0,Dt=ut.length;rt<Dt;rt++)q=ut[rt],S.format!==Ni?ht!==null?ot?Pt&&e.compressedTexSubImage2D(r.TEXTURE_2D,rt,0,0,q.width,q.height,ht,q.data):e.compressedTexImage2D(r.TEXTURE_2D,rt,J,q.width,q.height,0,q.data):Bt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ot?Pt&&e.texSubImage2D(r.TEXTURE_2D,rt,0,0,q.width,q.height,ht,L,q.data):e.texImage2D(r.TEXTURE_2D,rt,J,q.width,q.height,0,ht,L,q.data)}else if(S.isDataArrayTexture)if(ot){if(lt&&e.texStorage3D(r.TEXTURE_2D_ARRAY,qt,J,K.width,K.height,K.depth),Pt)if(S.layerUpdates.size>0){const rt=_c(K.width,K.height,S.format,S.type);for(const Dt of S.layerUpdates){const Wt=K.data.subarray(Dt*rt/K.data.BYTES_PER_ELEMENT,(Dt+1)*rt/K.data.BYTES_PER_ELEMENT);e.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,Dt,K.width,K.height,1,ht,L,Wt)}S.clearLayerUpdates()}else e.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,K.width,K.height,K.depth,ht,L,K.data)}else e.texImage3D(r.TEXTURE_2D_ARRAY,0,J,K.width,K.height,K.depth,0,ht,L,K.data);else if(S.isData3DTexture)ot?(lt&&e.texStorage3D(r.TEXTURE_3D,qt,J,K.width,K.height,K.depth),Pt&&e.texSubImage3D(r.TEXTURE_3D,0,0,0,0,K.width,K.height,K.depth,ht,L,K.data)):e.texImage3D(r.TEXTURE_3D,0,J,K.width,K.height,K.depth,0,ht,L,K.data);else if(S.isFramebufferTexture){if(lt)if(ot)e.texStorage2D(r.TEXTURE_2D,qt,J,K.width,K.height);else{let rt=K.width,Dt=K.height;for(let Wt=0;Wt<qt;Wt++)e.texImage2D(r.TEXTURE_2D,Wt,J,rt,Dt,0,ht,L,null),rt>>=1,Dt>>=1}}else if(S.isHTMLTexture){if("texElementImage2D"in r){const rt=r.canvas;if(rt.hasAttribute("layoutsubtree")||rt.setAttribute("layoutsubtree","true"),K.parentNode!==rt){rt.appendChild(K),u.add(S),rt.onpaint=Dt=>{const Wt=Dt.changedElements;for(const _t of u)Wt.includes(_t.image)&&(_t.needsUpdate=!0)},rt.requestPaint();return}if(r.texElementImage2D.length===3)r.texElementImage2D(r.TEXTURE_2D,r.RGBA8,K);else{const Wt=r.RGBA,_t=r.RGBA,ce=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,0,Wt,_t,ce,K)}r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(ut.length>0){if(ot&&lt){const rt=zt(ut[0]);e.texStorage2D(r.TEXTURE_2D,qt,J,rt.width,rt.height)}for(let rt=0,Dt=ut.length;rt<Dt;rt++)q=ut[rt],ot?Pt&&e.texSubImage2D(r.TEXTURE_2D,rt,0,0,ht,L,q):e.texImage2D(r.TEXTURE_2D,rt,J,ht,L,q);S.generateMipmaps=!1}else if(ot){if(lt){const rt=zt(K);e.texStorage2D(r.TEXTURE_2D,qt,J,rt.width,rt.height)}Pt&&e.texSubImage2D(r.TEXTURE_2D,0,0,0,ht,L,K)}else e.texImage2D(r.TEXTURE_2D,0,J,ht,L,K);M(S)&&S.mipmapsAutoUpdate===!0&&y(nt),pt.__version=at.version,S.onUpdate&&S.onUpdate(S)}A.__version=S.version}function ri(A,S,k){if(S.image.length!==6)return;const nt=fe(A,S),j=S.source;e.bindTexture(r.TEXTURE_CUBE_MAP,A.__webglTexture,r.TEXTURE0+k);const at=i.get(j);if(j.version!==at.__version||nt===!0){e.activeTexture(r.TEXTURE0+k);const pt=Qt.getPrimaries(Qt.workingColorSpace),$=S.colorSpace===qi?null:Qt.getPrimaries(S.colorSpace),K=S.colorSpace===qi||pt===$?r.NONE:r.BROWSER_DEFAULT_WEBGL;e.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,S.flipY),e.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),e.pixelStorei(r.UNPACK_ALIGNMENT,S.unpackAlignment),e.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,K);const ht=S.isCompressedTexture||S.image[0].isCompressedTexture,L=S.image[0]&&S.image[0].isDataTexture,J=[];for(let _t=0;_t<6;_t++)!ht&&!L?J[_t]=_(S.image[_t],!0,n.maxCubemapSize):J[_t]=L?S.image[_t].image:S.image[_t],J[_t]=Ut(S,J[_t]);const q=J[0],ut=s.convert(S.format,S.colorSpace),ot=s.convert(S.type);let lt=T(S.internalFormat,ut,ot,S.normalized,S.colorSpace);const Pt=S.isVideoTexture!==!0,qt=at.__version===void 0||nt===!0,rt=j.dataReady;let Dt=w(S,q);le(r.TEXTURE_CUBE_MAP,S);let Wt;if(S.isDepthTexture){if(lt=x(S.format===ln,S.type),qt)if(Pt)e.texStorage2D(r.TEXTURE_CUBE_MAP,1,lt,q.width,q.height);else for(let _t=0;_t<6;_t++)e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,lt,q.width,q.height,0,ut,ot,null)}else if(ht){Pt&&qt&&e.texStorage2D(r.TEXTURE_CUBE_MAP,Dt,lt,q.width,q.height);for(let _t=0;_t<6;_t++){Wt=J[_t].mipmaps;for(let ce=0;ce<Wt.length;ce++){const Be=Wt[ce];S.format!==Ni?ut!==null?Pt?rt&&e.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce,0,0,Be.width,Be.height,ut,Be.data):e.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce,lt,Be.width,Be.height,0,Be.data):Bt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Pt?rt&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce,0,0,Be.width,Be.height,ut,ot,Be.data):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce,lt,Be.width,Be.height,0,ut,ot,Be.data)}}}else{if(Wt=S.mipmaps,Pt&&qt){Wt.length>0&&Dt++;const _t=zt(J[0]);e.texStorage2D(r.TEXTURE_CUBE_MAP,Dt,lt,_t.width,_t.height)}for(let _t=0;_t<6;_t++)if(L){Pt?rt&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,J[_t].width,J[_t].height,ut,ot,J[_t].data):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,lt,J[_t].width,J[_t].height,0,ut,ot,J[_t].data);for(let ce=0;ce<Wt.length;ce++){const Ji=Wt[ce].image[_t].image;Pt?rt&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce+1,0,0,Ji.width,Ji.height,ut,ot,Ji.data):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce+1,lt,Ji.width,Ji.height,0,ut,ot,Ji.data)}}else{Pt?rt&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,ut,ot,J[_t]):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,lt,ut,ot,J[_t]);for(let ce=0;ce<Wt.length;ce++){const Be=Wt[ce];Pt?rt&&e.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce+1,0,0,ut,ot,Be.image[_t]):e.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+_t,ce+1,lt,ut,ot,Be.image[_t])}}}M(S)&&S.mipmapsAutoUpdate===!0&&y(r.TEXTURE_CUBE_MAP),at.__version=j.version,S.onUpdate&&S.onUpdate(S)}A.__version=S.version}function xe(A,S,k,nt,j,at){const pt=s.convert(k.format,k.colorSpace),$=s.convert(k.type),K=T(k.internalFormat,pt,$,k.normalized,k.colorSpace),ht=i.get(S),L=i.get(k);if(L.__renderTarget=S,!ht.__hasExternalTextures){const J=Math.max(1,S.width>>at),q=Math.max(1,S.height>>at);j===r.TEXTURE_3D||j===r.TEXTURE_2D_ARRAY?e.texImage3D(j,at,K,J,q,S.depth,0,pt,$,null):e.texImage2D(j,at,K,J,q,0,pt,$,null)}e.bindFramebuffer(r.FRAMEBUFFER,A),vt(S)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,nt,j,L.__webglTexture,0,ve(S)):(j===r.TEXTURE_2D||j>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&j<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,nt,j,L.__webglTexture,at),e.bindFramebuffer(r.FRAMEBUFFER,null)}function Ri(A,S,k){if(r.bindRenderbuffer(r.RENDERBUFFER,A),S.depthBuffer){const nt=S.depthTexture,j=nt&&nt.isDepthTexture?nt.type:null,at=x(S.stencilBuffer,j),pt=S.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;vt(S)?a.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ve(S),at,S.width,S.height):k?r.renderbufferStorageMultisample(r.RENDERBUFFER,ve(S),at,S.width,S.height):r.renderbufferStorage(r.RENDERBUFFER,at,S.width,S.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,pt,r.RENDERBUFFER,A)}else{const nt=S.textures;for(let j=0;j<nt.length;j++){const at=nt[j],pt=s.convert(at.format,at.colorSpace),$=s.convert(at.type),K=T(at.internalFormat,pt,$,at.normalized,at.colorSpace);vt(S)?a.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ve(S),K,S.width,S.height):k?r.renderbufferStorageMultisample(r.RENDERBUFFER,ve(S),K,S.width,S.height):r.renderbufferStorage(r.RENDERBUFFER,K,S.width,S.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function Oe(A,S,k){const nt=S.isWebGLCubeRenderTarget===!0;if(e.bindFramebuffer(r.FRAMEBUFFER,A),!(S.depthTexture&&S.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const j=i.get(S.depthTexture);j.__renderTarget=S;const at=nt?S.depthTexture.image[0]:S.depthTexture.image;(!j.__webglTexture||at.width!==S.width||at.height!==S.height)&&(at.width=S.width,at.height=S.height,S.depthTexture.needsUpdate=!0),nt?Mt(S.depthTexture,0):yt(S.depthTexture,0);const pt=j.__webglTexture,$=ve(S),K=nt?r.TEXTURE_CUBE_MAP_POSITIVE_X+k:r.TEXTURE_2D,ht=S.depthTexture.format===ln?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(S.depthTexture.format===hn)vt(S)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ht,K,pt,0,$):r.framebufferTexture2D(r.FRAMEBUFFER,ht,K,pt,0);else if(S.depthTexture.format===ln)vt(S)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ht,K,pt,0,$):r.framebufferTexture2D(r.FRAMEBUFFER,ht,K,pt,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function mi(A){const S=i.get(A),k=A.isWebGLCubeRenderTarget===!0;if(S.__boundDepthTexture!==A.depthTexture){const nt=A.depthTexture;if(S.__depthDisposeCallback&&S.__depthDisposeCallback(),nt){const j=()=>{delete S.__boundDepthTexture,delete S.__depthDisposeCallback,nt.removeEventListener("dispose",j)};nt.addEventListener("dispose",j),S.__depthDisposeCallback=j}S.__boundDepthTexture=nt}if(A.depthTexture&&!S.__autoAllocateDepthBuffer)if(k)for(let nt=0;nt<6;nt++)Oe(S.__webglFramebuffer[nt],A,nt);else A.texture.mipmaps.length>0?Oe(S.__webglFramebuffer[0],A,0):Oe(S.__webglFramebuffer,A,0);else if(k){S.__webglDepthbuffer=[];for(let nt=0;nt<6;nt++)if(e.bindFramebuffer(r.FRAMEBUFFER,S.__webglFramebuffer[nt]),S.__webglDepthbuffer[nt]===void 0)S.__webglDepthbuffer[nt]=r.createRenderbuffer(),Ri(S.__webglDepthbuffer[nt],A,!1);else{const j=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,at=S.__webglDepthbuffer[nt];r.bindRenderbuffer(r.RENDERBUFFER,at),r.framebufferRenderbuffer(r.FRAMEBUFFER,j,r.RENDERBUFFER,at)}}else if(A.texture.mipmaps.length>0?e.bindFramebuffer(r.FRAMEBUFFER,S.__webglFramebuffer[0]):e.bindFramebuffer(r.FRAMEBUFFER,S.__webglFramebuffer),S.__webglDepthbuffer===void 0)S.__webglDepthbuffer=r.createRenderbuffer(),Ri(S.__webglDepthbuffer,A,!1);else{const j=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,at=S.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,at),r.framebufferRenderbuffer(r.FRAMEBUFFER,j,r.RENDERBUFFER,at)}e.bindFramebuffer(r.FRAMEBUFFER,null)}function gi(A,S,k){const nt=i.get(A);S!==void 0&&xe(nt.__webglFramebuffer,A,A.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),k!==void 0&&mi(A)}function vi(A){const S=A.texture,k=i.get(A),nt=i.get(S);A.addEventListener("dispose",B),P(A);const j=A.textures,at=A.isWebGLCubeRenderTarget===!0,pt=j.length>1;if(pt||(nt.__webglTexture===void 0&&(nt.__webglTexture=r.createTexture()),nt.__version=S.version,o.memory.textures++),at){k.__webglFramebuffer=[];for(let $=0;$<6;$++)if(S.mipmaps.length>0){k.__webglFramebuffer[$]=[];for(let K=0;K<S.mipmaps.length;K++)k.__webglFramebuffer[$][K]=r.createFramebuffer()}else k.__webglFramebuffer[$]=r.createFramebuffer()}else{if(S.mipmaps.length>0){k.__webglFramebuffer=[];for(let $=0;$<S.mipmaps.length;$++)k.__webglFramebuffer[$]=r.createFramebuffer()}else k.__webglFramebuffer=r.createFramebuffer();if(pt)for(let $=0,K=j.length;$<K;$++){const ht=i.get(j[$]);ht.__webglTexture===void 0&&(ht.__webglTexture=r.createTexture(),o.memory.textures++)}if(A.samples>0&&vt(A)===!1){k.__webglMultisampledFramebuffer=r.createFramebuffer(),k.__webglColorRenderbuffer=[],e.bindFramebuffer(r.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let $=0;$<j.length;$++){const K=j[$];k.__webglColorRenderbuffer[$]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,k.__webglColorRenderbuffer[$]);const ht=s.convert(K.format,K.colorSpace),L=s.convert(K.type),J=T(K.internalFormat,ht,L,K.normalized,K.colorSpace,A.isXRRenderTarget===!0),q=ve(A);r.renderbufferStorageMultisample(r.RENDERBUFFER,q,J,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+$,r.RENDERBUFFER,k.__webglColorRenderbuffer[$])}r.bindRenderbuffer(r.RENDERBUFFER,null),A.depthBuffer&&(k.__webglDepthRenderbuffer=r.createRenderbuffer(),Ri(k.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(r.FRAMEBUFFER,null)}}if(at){e.bindTexture(r.TEXTURE_CUBE_MAP,nt.__webglTexture),le(r.TEXTURE_CUBE_MAP,S);for(let $=0;$<6;$++)if(S.mipmaps.length>0)for(let K=0;K<S.mipmaps.length;K++)xe(k.__webglFramebuffer[$][K],A,S,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+$,K);else xe(k.__webglFramebuffer[$],A,S,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+$,0);M(S)?y(r.TEXTURE_CUBE_MAP):S.mipmaps.length>0&&r.texParameteri(r.TEXTURE_CUBE_MAP,r.TEXTURE_MAX_LEVEL,S.mipmaps.length-1),e.unbindTexture()}else if(pt){for(let $=0,K=j.length;$<K;$++){const ht=j[$],L=i.get(ht);let J=r.TEXTURE_2D;(A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(J=A.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),e.bindTexture(J,L.__webglTexture),le(J,ht),xe(k.__webglFramebuffer,A,ht,r.COLOR_ATTACHMENT0+$,J,0),M(ht)&&y(J)}e.unbindTexture()}else{let $=r.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&($=A.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),e.bindTexture($,nt.__webglTexture),le($,S),S.mipmaps.length>0)for(let K=0;K<S.mipmaps.length;K++)xe(k.__webglFramebuffer[K],A,S,r.COLOR_ATTACHMENT0,$,K);else xe(k.__webglFramebuffer,A,S,r.COLOR_ATTACHMENT0,$,0);M(S)?y($):S.mipmaps.length>0&&r.texParameteri($,r.TEXTURE_MAX_LEVEL,S.mipmaps.length-1),e.unbindTexture()}A.depthBuffer&&mi(A)}function O(A){const S=A.textures;for(let k=0,nt=S.length;k<nt;k++){const j=S[k];if(M(j)&&j.mipmapsAutoUpdate===!0){const at=E(A),pt=i.get(j).__webglTexture;e.bindTexture(at,pt),y(at),e.unbindTexture()}}}const _i=[];function ge(A){if(A.samples>0){if(vt(A)===!1){const S=A.textures,k=A.width,nt=A.height;let j=r.COLOR_BUFFER_BIT;const at=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,pt=i.get(A),$=S.length>1;if($)for(let ht=0;ht<S.length;ht++)e.bindFramebuffer(r.FRAMEBUFFER,pt.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ht,r.RENDERBUFFER,null),e.bindFramebuffer(r.FRAMEBUFFER,pt.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ht,r.TEXTURE_2D,null,0);e.bindFramebuffer(r.READ_FRAMEBUFFER,pt.__webglMultisampledFramebuffer),A.texture.mipmaps.length>0?e.bindFramebuffer(r.DRAW_FRAMEBUFFER,pt.__webglFramebuffer[0]):e.bindFramebuffer(r.DRAW_FRAMEBUFFER,pt.__webglFramebuffer);for(let ht=0;ht<S.length;ht++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(j|=r.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(j|=r.STENCIL_BUFFER_BIT)),$){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,pt.__webglColorRenderbuffer[ht]);const L=i.get(S[ht]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,L,0)}r.blitFramebuffer(0,0,k,nt,0,0,k,nt,j,r.NEAREST),l===!0&&(_i.length=0,_i.push(r.COLOR_ATTACHMENT0+ht),A.depthBuffer&&A.storeMultisampledDepthBuffer===!1&&_i.push(at),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,_i))}if(e.bindFramebuffer(r.READ_FRAMEBUFFER,null),e.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),$)for(let ht=0;ht<S.length;ht++){e.bindFramebuffer(r.FRAMEBUFFER,pt.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ht,r.RENDERBUFFER,pt.__webglColorRenderbuffer[ht]);const L=i.get(S[ht]).__webglTexture;e.bindFramebuffer(r.FRAMEBUFFER,pt.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ht,r.TEXTURE_2D,L,0)}e.bindFramebuffer(r.DRAW_FRAMEBUFFER,pt.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.storeMultisampledDepthBuffer===!1&&l){const S=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[S])}}}function ve(A){return Math.min(n.maxSamples,A.samples)}function vt(A){const S=i.get(A);return A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&S.__useRenderToTexture!==!1}function Le(A){const S=o.render.frame;h.get(A)!==S&&(h.set(A,S),A.update())}function Ut(A,S){const k=A.colorSpace,nt=A.format,j=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||k!==Vr&&k!==qi&&(Qt.getTransfer(k)===he?(nt!==Ni||j!==pi)&&Bt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):se("WebGLTextures: Unsupported texture color space:",k)),S}function zt(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=Gt,this.resetTextureUnits=tt,this.getTextureUnits=it,this.setTextureUnits=Rt,this.setTexture2D=yt,this.setTexture2DArray=Et,this.setTexture3D=Nt,this.setTextureCube=Mt,this.rebindTextures=gi,this.setupRenderTarget=vi,this.updateRenderTargetMipmap=O,this.updateMultisampleRenderTarget=ge,this.setupDepthRenderbuffer=mi,this.setupFrameBufferTexture=xe,this.useMultisampledRTT=vt,this.dispose=H}function qg(r,t){function e(i,n=qi){let s;const o=Qt.getTransfer(n);if(i===pi)return r.UNSIGNED_BYTE;if(i===$a)return r.UNSIGNED_SHORT_4_4_4_4;if(i===Ka)return r.UNSIGNED_SHORT_5_5_5_1;if(i===dh)return r.UNSIGNED_INT_5_9_9_9_REV;if(i===fh)return r.UNSIGNED_INT_10F_11F_11F_REV;if(i===hh)return r.BYTE;if(i===uh)return r.SHORT;if(i===Bs)return r.UNSIGNED_SHORT;if(i===Ya)return r.INT;if(i===Fi)return r.UNSIGNED_INT;if(i===Ei)return r.FLOAT;if(i===Oi)return r.HALF_FLOAT;if(i===ph)return r.ALPHA;if(i===mh)return r.RGB;if(i===Ni)return r.RGBA;if(i===hn)return r.DEPTH_COMPONENT;if(i===ln)return r.DEPTH_STENCIL;if(i===Za)return r.RED;if(i===Ja)return r.RED_INTEGER;if(i===Tn)return r.RG;if(i===ja)return r.RG_INTEGER;if(i===Qa)return r.RGBA_INTEGER;if(i===Ur||i===Fr||i===Or||i===Br)if(o===he)if(s=t.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(i===Ur)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===Fr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===Or)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===Br)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=t.get("WEBGL_compressed_texture_s3tc"),s!==null){if(i===Ur)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===Fr)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===Or)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===Br)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===na||i===sa||i===ra||i===oa)if(s=t.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(i===na)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===sa)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===ra)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===oa)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===aa||i===la||i===ca||i===ha||i===ua||i===Gr||i===da)if(s=t.get("WEBGL_compressed_texture_etc"),s!==null){if(i===aa||i===la)return o===he?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(i===ca)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC;if(i===ha)return s.COMPRESSED_R11_EAC;if(i===ua)return s.COMPRESSED_SIGNED_R11_EAC;if(i===Gr)return s.COMPRESSED_RG11_EAC;if(i===da)return s.COMPRESSED_SIGNED_RG11_EAC}else return null;if(i===fa||i===pa||i===ma||i===ga||i===va||i===_a||i===xa||i===ya||i===Ma||i===Sa||i===wa||i===ba||i===Ea||i===Ta)if(s=t.get("WEBGL_compressed_texture_astc"),s!==null){if(i===fa)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===pa)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===ma)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===ga)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===va)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===_a)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===xa)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===ya)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===Ma)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===Sa)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===wa)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===ba)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===Ea)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===Ta)return o===he?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Aa||i===Ra||i===Ca)if(s=t.get("EXT_texture_compression_bptc"),s!==null){if(i===Aa)return o===he?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===Ra)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===Ca)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===Pa||i===La||i===Hr||i===Da)if(s=t.get("EXT_texture_compression_rgtc"),s!==null){if(i===Pa)return s.COMPRESSED_RED_RGTC1_EXT;if(i===La)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===Hr)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===Da)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===ss?r.UNSIGNED_INT_24_8:r[i]!==void 0?r[i]:null}return{convert:e}}const Yg=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,$g=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Kg{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const i=new Dh(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=i}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,i=new Qe({vertexShader:Yg,fragmentShader:$g,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new I(new be(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Zg extends fn{constructor(t,e){super();const i=this;let n=null,s=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,p=null;const v=typeof XRWebGLBinding<"u",m=new Kg,g={},_=e.getContextAttributes();let M=null,y=null;const E=[],T=[],x=new Q;let w=null,P=null;const C=new fi;C.viewport=new Me;const U=new fi;U.viewport=new Me;const B=[C,U],V=new af;let D=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let yt=E[Z];return yt===void 0&&(yt=new xo,E[Z]=yt),yt.getTargetRaySpace()},this.getControllerGrip=function(Z){let yt=E[Z];return yt===void 0&&(yt=new xo,E[Z]=yt),yt.getGripSpace()},this.getHand=function(Z){let yt=E[Z];return yt===void 0&&(yt=new xo,E[Z]=yt),yt.getHandSpace()};function Y(Z){const yt=T.indexOf(Z.inputSource);if(yt===-1)return;const Et=E[yt];Et!==void 0&&(Et.update(Z.inputSource,Z.frame,c||o),Et.dispatchEvent({type:Z.type,data:Z.inputSource}))}function F(){n.removeEventListener("select",Y),n.removeEventListener("selectstart",Y),n.removeEventListener("selectend",Y),n.removeEventListener("squeeze",Y),n.removeEventListener("squeezestart",Y),n.removeEventListener("squeezeend",Y),n.removeEventListener("end",F),n.removeEventListener("inputsourceschange",et);for(let Z=0;Z<E.length;Z++){const yt=T[Z];yt!==null&&(T[Z]=null,E[Z].disconnect(yt))}D=null,H=null,m.reset();for(const Z in g)delete g[Z];if(t.setRenderTarget(M),f=null,d=null,u=null,n=null,y=null,Gt.stop(),i.isPresenting=!1,t.setPixelRatio(w),t.setSize(x.width,x.height,!1),P!==null){const Z=P.camera;Z.fov=P.fov,Z.zoom=P.zoom,Z.updateProjectionMatrix(),P=null}i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){s=Z,i.isPresenting===!0&&Bt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){a=Z,i.isPresenting===!0&&Bt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(Z){c=Z},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u===null&&v&&(u=new XRWebGLBinding(n,e)),u},this.getFrame=function(){return p},this.getSession=function(){return n},this.setSession=async function(Z){if(n=Z,n!==null){if(M=t.getRenderTarget(),n.addEventListener("select",Y),n.addEventListener("selectstart",Y),n.addEventListener("selectend",Y),n.addEventListener("squeeze",Y),n.addEventListener("squeezestart",Y),n.addEventListener("squeezeend",Y),n.addEventListener("end",F),n.addEventListener("inputsourceschange",et),_.xrCompatible!==!0&&await e.makeXRCompatible(),w=t.getPixelRatio(),t.getSize(x),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let Et=null,Nt=null,Mt=null;_.depth&&(Mt=_.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,Et=_.stencil?ln:hn,Nt=_.stencil?ss:Fi);const Vt={colorFormat:e.RGBA8,depthFormat:Mt,scaleFactor:s};u=this.getBinding(),d=u.createProjectionLayer(Vt),n.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),y=new Ai(d.textureWidth,d.textureHeight,{format:Ni,type:pi,depthTexture:new rs(d.textureWidth,d.textureHeight,Nt,void 0,void 0,void 0,void 0,void 0,void 0,Et),stencilBuffer:_.stencil,colorSpace:t.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{const Et={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(n,e,Et),n.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new Ai(f.framebufferWidth,f.framebufferHeight,{format:Ni,type:pi,colorSpace:t.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await n.requestReferenceSpace(a),Gt.setContext(n),Gt.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(n!==null)return n.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function et(Z){for(let yt=0;yt<Z.removed.length;yt++){const Et=Z.removed[yt],Nt=T.indexOf(Et);Nt>=0&&(T[Nt]=null,E[Nt].disconnect(Et))}for(let yt=0;yt<Z.added.length;yt++){const Et=Z.added[yt];let Nt=T.indexOf(Et);if(Nt===-1){for(let Vt=0;Vt<E.length;Vt++)if(Vt>=T.length){T.push(Et),Nt=Vt;break}else if(T[Vt]===null){T[Vt]=Et,Nt=Vt;break}if(Nt===-1)break}const Mt=E[Nt];Mt&&Mt.connect(Et)}}function X(Z,yt){yt===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(yt.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(n===null)return;let yt=Z.near,Et=Z.far;m.texture!==null&&(m.depthNear>0&&(yt=m.depthNear),m.depthFar>0&&(Et=m.depthFar)),V.near=U.near=C.near=yt,V.far=U.far=C.far=Et,(D!==V.near||H!==V.far)&&(n.updateRenderState({depthNear:V.near,depthFar:V.far}),D=V.near,H=V.far),V.layers.mask=Z.layers.mask|6,C.layers.mask=V.layers.mask&-5,U.layers.mask=V.layers.mask&-3;const Nt=Z.parent,Mt=V.cameras;X(V,Nt);for(let Vt=0;Vt<Mt.length;Vt++)X(Mt[Vt],Nt);V.projectionMatrix.copy(C.projectionMatrix),V.projectionMatrixInverse.copy(C.projectionMatrixInverse),P===null&&Z.isPerspectiveCamera&&(P={camera:Z,fov:Z.fov,zoom:Z.zoom}),tt(Z,V,Nt)};function tt(Z,yt,Et){Et===null?Z.matrix.copy(yt.matrixWorld):(Z.matrix.copy(Et.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(yt.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(yt.projectionMatrix),Z.projectionMatrixInverse.copy(yt.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=Yr*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(Z){l=Z,d!==null&&(d.fixedFoveation=Z),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Z)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(V)},this.getCameraTexture=function(Z){return g[Z]};let it=null;function Rt(Z,yt){if(h=yt.getViewerPose(c||o),p=yt,h!==null){const Et=h.views;f!==null&&(t.setRenderTargetFramebuffer(y,f.framebuffer),t.setRenderTarget(y));let Nt=!1;Et.length!==V.cameras.length&&(V.cameras.length=0,Nt=!0);for(let Ot=0;Ot<Et.length;Ot++){const le=Et[Ot];let fe=null;if(f!==null)fe=f.getViewport(le);else{const He=u.getViewSubImage(d,le);fe=He.viewport,Ot===0&&(t.setRenderTargetTextures(y,He.colorTexture,He.depthStencilTexture),t.setRenderTarget(y))}let Zt=B[Ot];Zt===void 0&&(Zt=new fi,Zt.layers.enable(Ot),Zt.viewport=new Me,B[Ot]=Zt),Zt.matrix.fromArray(le.transform.matrix),Zt.matrix.decompose(Zt.position,Zt.quaternion,Zt.scale),Zt.projectionMatrix.fromArray(le.projectionMatrix),Zt.projectionMatrixInverse.copy(Zt.projectionMatrix).invert(),Zt.viewport.set(fe.x,fe.y,fe.width,fe.height),Ot===0&&(V.matrix.copy(Zt.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),Nt===!0&&V.cameras.push(Zt)}const Mt=n.enabledFeatures;if(Mt&&Mt.includes("depth-sensing")&&n.depthUsage=="gpu-optimized"&&v){u=i.getBinding();const Ot=u.getDepthInformation(Et[0]);Ot&&Ot.isValid&&Ot.texture&&m.init(Ot,n.renderState)}if(Mt&&Mt.includes("camera-access")&&v){t.state.unbindTexture(),u=i.getBinding();for(let Ot=0;Ot<Et.length;Ot++){const le=Et[Ot].camera;if(le){let fe=g[le];fe||(fe=new Dh,g[le]=fe);const Zt=u.getCameraImage(le);fe.sourceTexture=Zt}}}}for(let Et=0;Et<E.length;Et++){const Nt=T[Et],Mt=E[Et];Nt!==null&&Mt!==void 0&&Mt.update(Nt,yt,c||o)}it&&it(Z,yt),yt.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:yt}),p=null}const Gt=new qh;Gt.setAnimationLoop(Rt),this.setAnimationLoop=function(Z){it=Z},this.dispose=function(){}}}const Jg=new te,iu=new kt;iu.set(-1,0,0,0,1,0,0,0,1);function jg(r,t){function e(m,g){m.matrixAutoUpdate===!0&&m.updateMatrix(),g.value.copy(m.matrix)}function i(m,g){g.color.getRGB(m.fogColor.value,Vh(r)),g.isFog?(m.fogNear.value=g.near,m.fogFar.value=g.far):g.isFogExp2&&(m.fogDensity.value=g.density)}function n(m,g,_,M,y){g.isNodeMaterial?g.uniformsNeedUpdate=!1:g.isMeshBasicMaterial?s(m,g):g.isMeshLambertMaterial?(s(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshToonMaterial?(s(m,g),u(m,g)):g.isMeshPhongMaterial?(s(m,g),h(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshStandardMaterial?(s(m,g),d(m,g),g.isMeshPhysicalMaterial&&f(m,g,y)):g.isMeshMatcapMaterial?(s(m,g),p(m,g)):g.isMeshDepthMaterial?s(m,g):g.isMeshDistanceMaterial?(s(m,g),v(m,g)):g.isMeshNormalMaterial?s(m,g):g.isLineBasicMaterial?(o(m,g),g.isLineDashedMaterial&&a(m,g)):g.isPointsMaterial?l(m,g,_,M):g.isSpriteMaterial?c(m,g):g.isShadowMaterial?(m.color.value.copy(g.color),m.opacity.value=g.opacity):g.isShaderMaterial&&(g.uniformsNeedUpdate=!1)}function s(m,g){m.opacity.value=g.opacity,g.color&&m.diffuse.value.copy(g.color),g.emissive&&m.emissive.value.copy(g.emissive).multiplyScalar(g.emissiveIntensity),g.map&&(m.map.value=g.map,e(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,e(g.alphaMap,m.alphaMapTransform)),g.bumpMap&&(m.bumpMap.value=g.bumpMap,e(g.bumpMap,m.bumpMapTransform),m.bumpScale.value=g.bumpScale,g.side===Je&&(m.bumpScale.value*=-1)),g.normalMap&&(m.normalMap.value=g.normalMap,e(g.normalMap,m.normalMapTransform),m.normalScale.value.copy(g.normalScale),g.side===Je&&m.normalScale.value.negate()),g.displacementMap&&(m.displacementMap.value=g.displacementMap,e(g.displacementMap,m.displacementMapTransform),m.displacementScale.value=g.displacementScale,m.displacementBias.value=g.displacementBias),g.emissiveMap&&(m.emissiveMap.value=g.emissiveMap,e(g.emissiveMap,m.emissiveMapTransform)),g.specularMap&&(m.specularMap.value=g.specularMap,e(g.specularMap,m.specularMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest);const _=t.get(g),M=_.envMap,y=_.envMapRotation;M&&(m.envMap.value=M,m.envMapRotation.value.setFromMatrix4(Jg.makeRotationFromEuler(y)).transpose(),M.isCubeTexture&&M.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(iu),m.reflectivity.value=g.reflectivity,m.ior.value=g.ior,m.refractionRatio.value=g.refractionRatio),g.lightMap&&(m.lightMap.value=g.lightMap,m.lightMapIntensity.value=g.lightMapIntensity,e(g.lightMap,m.lightMapTransform)),g.aoMap&&(m.aoMap.value=g.aoMap,m.aoMapIntensity.value=g.aoMapIntensity,e(g.aoMap,m.aoMapTransform))}function o(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,g.map&&(m.map.value=g.map,e(g.map,m.mapTransform))}function a(m,g){m.dashSize.value=g.dashSize,m.totalSize.value=g.dashSize+g.gapSize,m.scale.value=g.scale}function l(m,g,_,M){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.size.value=g.size*_,m.scale.value=M*.5,g.map&&(m.map.value=g.map,e(g.map,m.uvTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,e(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function c(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.rotation.value=g.rotation,g.map&&(m.map.value=g.map,e(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,e(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function h(m,g){m.specular.value.copy(g.specular),m.shininess.value=Math.max(g.shininess,1e-4)}function u(m,g){g.gradientMap&&(m.gradientMap.value=g.gradientMap)}function d(m,g){m.metalness.value=g.metalness,g.metalnessMap&&(m.metalnessMap.value=g.metalnessMap,e(g.metalnessMap,m.metalnessMapTransform)),m.roughness.value=g.roughness,g.roughnessMap&&(m.roughnessMap.value=g.roughnessMap,e(g.roughnessMap,m.roughnessMapTransform)),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)}function f(m,g,_){m.ior.value=g.ior,g.diffuseRoughness>0&&(m.diffuseRoughness.value=g.diffuseRoughness,g.diffuseRoughnessMap&&(m.diffuseRoughnessMap.value=g.diffuseRoughnessMap,e(g.diffuseRoughnessMap,m.diffuseRoughnessMapTransform))),g.sheen>0&&(m.sheenColor.value.copy(g.sheenColor).multiplyScalar(g.sheen),m.sheenRoughness.value=g.sheenRoughness,g.sheenColorMap&&(m.sheenColorMap.value=g.sheenColorMap,e(g.sheenColorMap,m.sheenColorMapTransform)),g.sheenRoughnessMap&&(m.sheenRoughnessMap.value=g.sheenRoughnessMap,e(g.sheenRoughnessMap,m.sheenRoughnessMapTransform))),g.clearcoat>0&&(m.clearcoat.value=g.clearcoat,m.clearcoatRoughness.value=g.clearcoatRoughness,g.clearcoatMap&&(m.clearcoatMap.value=g.clearcoatMap,e(g.clearcoatMap,m.clearcoatMapTransform)),g.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=g.clearcoatRoughnessMap,e(g.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),g.clearcoatNormalMap&&(m.clearcoatNormalMap.value=g.clearcoatNormalMap,e(g.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(g.clearcoatNormalScale),g.side===Je&&m.clearcoatNormalScale.value.negate())),g.dispersion>0&&(m.dispersion.value=g.dispersion),g.retroreflectivity>0&&(m.retroreflectivity.value=g.retroreflectivity),g.iridescence>0&&(m.iridescence.value=g.iridescence,m.iridescenceIOR.value=g.iridescenceIOR,m.iridescenceThicknessMinimum.value=g.iridescenceThicknessMinimum,m.iridescenceThicknessMaximum.value=g.iridescenceThicknessMaximum,g.iridescenceMap&&(m.iridescenceMap.value=g.iridescenceMap,e(g.iridescenceMap,m.iridescenceMapTransform)),g.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=g.iridescenceThicknessMap,e(g.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),g.transmission>0&&(m.transmission.value=g.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),g.transmissionMap&&(m.transmissionMap.value=g.transmissionMap,e(g.transmissionMap,m.transmissionMapTransform)),m.thickness.value=g.thickness,g.thicknessMap&&(m.thicknessMap.value=g.thicknessMap,e(g.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=g.attenuationDistance,m.attenuationColor.value.copy(g.attenuationColor)),g.anisotropy>0&&(m.anisotropyVector.value.set(g.anisotropy*Math.cos(g.anisotropyRotation),g.anisotropy*Math.sin(g.anisotropyRotation)),g.anisotropyMap&&(m.anisotropyMap.value=g.anisotropyMap,e(g.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=g.specularIntensity,m.specularColor.value.copy(g.specularColor),g.specularColorMap&&(m.specularColorMap.value=g.specularColorMap,e(g.specularColorMap,m.specularColorMapTransform)),g.specularIntensityMap&&(m.specularIntensityMap.value=g.specularIntensityMap,e(g.specularIntensityMap,m.specularIntensityMapTransform))}function p(m,g){g.matcap&&(m.matcap.value=g.matcap)}function v(m,g){const _=t.get(g).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:n}}function Qg(r,t,e,i){let n={},s={};function o(_,M){const y=M.program;i.uniformBlockBinding(_,y,n[_.id])}function a(_,M){let y=n[_.id];y===void 0&&(p(_),y=l(_),n[_.id]=y,_.addEventListener("dispose",m));const E=M.program;i.updateUBOMapping(_,E);const T=t.render.frame;s[_.id]!==T&&(c(_),s[_.id]=T)}function l(_){const M=r.createBuffer(),y=_.__size,E=_.usage;return r.bindBuffer(r.UNIFORM_BUFFER,M),r.bufferData(r.UNIFORM_BUFFER,y,E),r.bindBuffer(r.UNIFORM_BUFFER,null),M}function c(_){const M=n[_.id],y=_.uniforms,E=_.__cache;r.bindBuffer(r.UNIFORM_BUFFER,M);for(let T=0,x=y.length;T<x;T++){const w=y[T];if(Array.isArray(w))for(let P=0,C=w.length;P<C;P++)h(w[P],T,P,E);else h(w,T,0,E)}r.bindBuffer(r.UNIFORM_BUFFER,null)}function h(_,M,y,E){if(d(_,M,y,E)===!0){const T=_.__offset,x=_.value;if(Array.isArray(x)){let w=0;for(let P=0;P<x.length;P++){const C=x[P],U=v(C,!0);u(C,_.__data,w),w+=U.storage/Float32Array.BYTES_PER_ELEMENT}}else u(x,_.__data,0);r.bufferSubData(r.UNIFORM_BUFFER,T,_.__data)}}function u(_,M,y){typeof _=="number"||typeof _=="boolean"?M[y]=_:_.isMatrix3?(M[y]=_.elements[0],M[y+1]=_.elements[1],M[y+2]=_.elements[2],M[y+3]=0,M[y+4]=_.elements[3],M[y+5]=_.elements[4],M[y+6]=_.elements[5],M[y+7]=0,M[y+8]=_.elements[6],M[y+9]=_.elements[7],M[y+10]=_.elements[8],M[y+11]=0):ArrayBuffer.isView(_)?M.set(_.subarray(0,M.length-y),y):_.toArray(M,y)}function d(_,M,y,E){const T=_.value,x=M+"_"+y;if(Array.isArray(T)){E[x]===void 0&&(E[x]=[]);const w=E[x];let P=!1;for(let C=0;C<T.length;C++)f(T[C],w,C)===!0&&(P=!0);return P}return f(T,E,x)}function f(_,M,y){if(M[y]===void 0)return typeof _=="number"||typeof _=="boolean"?M[y]=_:ArrayBuffer.isView(_)?M[y]=_.slice():M[y]=_.clone(),!0;{const E=M[y];if(typeof _=="number"||typeof _=="boolean"){if(E!==_)return M[y]=_,!0}else{if(ArrayBuffer.isView(_))return!0;if(E.equals(_)===!1)return E.copy(_),!0}}return!1}function p(_){const M=_.uniforms;let y=0;const E=16;for(let x=0,w=M.length;x<w;x++){const P=Array.isArray(M[x])?M[x]:[M[x]];for(let C=0,U=P.length;C<U;C++){const B=P[C],V=Array.isArray(B.value)?B.value:[B.value],D=Array.isArray(M[x])||Array.isArray(B.value);let H=y;for(let F=0,et=V.length;F<et;F++){const X=V[F],tt=v(X,D),it=y%E,Rt=it%tt.boundary,Gt=it+Rt;y+=Rt,Gt!==0&&E-Gt<tt.storage&&(y+=E-Gt),F===0&&(H=y),y+=tt.storage}const Y=B.type==="int"?Int32Array:B.type==="uint"?Uint32Array:Float32Array;B.__data=new Y((y-H)/Float32Array.BYTES_PER_ELEMENT),B.__offset=H}}const T=y%E;return T>0&&(y+=E-T),_.__size=y,_.__cache={},this}function v(_,M){const y={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(y.boundary=4,y.storage=4):_.isVector2?(y.boundary=8,y.storage=8):_.isVector3||_.isColor?(y.boundary=16,y.storage=12):_.isVector4?(y.boundary=16,y.storage=16):_.isMatrix3?(y.boundary=16,y.storage=48):_.isMatrix4?(y.boundary=16,y.storage=64):_.isTexture?Bt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(_)?(y.boundary=16,y.storage=_.byteLength):Bt("WebGLRenderer: Unsupported uniform value type.",_),M===!0&&(y.boundary=16,y.storage=Math.ceil(y.storage/16)*16),y}function m(_){const M=_.target;M.removeEventListener("dispose",m),r.deleteBuffer(n[M.id]),delete n[M.id],delete s[M.id]}function g(){for(const _ in n)r.deleteBuffer(n[_]);n={},s={}}return{bind:o,update:a,dispose:g}}const tv=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Pi=null;function ev(){return Pi===null&&(Pi=new Ch(tv,16,16,Tn,Oi),Pi.name="DFG_LUT",Pi.minFilter=Ze,Pi.magFilter=Ze,Pi.wrapS=Ii,Pi.wrapT=Ii,Pi.generateMipmaps=!1,Pi.needsUpdate=!0),Pi}class iv{constructor(t={}){const{canvas:e=Xu(),context:i=null,depth:n=!0,stencil:s=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=pi}=t;this.isWebGLRenderer=!0;let p;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=i.getContextAttributes().alpha}else p=o;const v=f,m=new Set([Qa,ja,Ja]),g=new Set([pi,Fi,Bs,ss,$a,Ka]),_=new Uint32Array(4),M=new Int32Array(4),y={textures:[],min:[],max:[],resolution:[]};let E=null,T=null;const x=[],w=[];let P=null;this.domElement=e,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=$i,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const C=this;let U=!1,B=null,V=null,D=null,H=null;this._outputColorSpace=ni;let Y=0,F=0,et=null,X=-1,tt=null;const it=new Me,Rt=new Me;let Gt=null;const Z=new ct(0);let yt=0,Et=e.width,Nt=e.height,Mt=1,Vt=null,Ae=null;const Ot=new Me(0,0,Et,Nt),le=new Me(0,0,Et,Nt);let fe=!1;const Zt=new ks,He=new sl;let Pe=!1,ri=!1;const xe=new te,Ri=new R,Oe=new Me,mi={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let gi=!1;function vi(){return et===null?Mt:1}let O=i;function _i(b,N){return e.getContext(b,N)}let ge,ve,vt,Le,Ut,zt,A,S,k,nt,j,at,pt,$,K,ht,L,J,q,ut,ot,lt,Pt;try{const b={alpha:!0,depth:n,stencil:s,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Xa}`),e.addEventListener("webglcontextlost",Dt,!1),e.addEventListener("webglcontextrestored",Wt,!1),e.addEventListener("webglcontextcreationerror",_t,!1),O===null){const N="webgl2";if(O=_i(N,b),O===null)throw _i(N)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}qt()}catch(b){throw e.removeEventListener("webglcontextlost",Dt,!1),e.removeEventListener("webglcontextrestored",Wt,!1),e.removeEventListener("webglcontextcreationerror",_t,!1),se("WebGLRenderer: "+b.message),b}function qt(){ge=new rm(O),ge.init(),ot=new qg(O,ge),ve=new $0(O,ge,t,ot),vt=new Wg(O,ge),ve.reversedDepthBuffer&&d&&vt.buffers.depth.setReversed(!0),V=O.createFramebuffer(),D=O.createFramebuffer(),H=O.createFramebuffer(),Le=new lm(O),Ut=new Pg,zt=new Xg(O,ge,vt,Ut,ve,ot,Le),A=new sm(C),S=new hf(O),lt=new q0(O,S),k=new om(O,S,Le,lt),nt=new hm(O,k,S,lt,Le),J=new cm(O,ve,zt),K=new K0(Ut),j=new Cg(C,A,ge,ve,lt,K),at=new jg(C,Ut),pt=new Dg,$=new Bg(ge),L=new X0(C,A,vt,nt,p,l),ht=new Vg(C,nt,ve),Pt=new Qg(O,Le,ve,vt),q=new Y0(O,ge,Le),ut=new am(O,ge,Le),Le.programs=j.programs,C.capabilities=ve,C.extensions=ge,C.properties=Ut,C.renderLists=pt,C.shadowMap=ht,C.state=vt,C.info=Le}v!==pi&&(P=new dm(v,e.width,e.height,a,n,s));const rt=new Zg(C,O);this.xr=rt,this.getContext=function(){return O},this.getContextAttributes=function(){return O.getContextAttributes()},this.forceContextLoss=function(){const b=ge.get("WEBGL_lose_context");b&&b.loseContext()},this.forceContextRestore=function(){const b=ge.get("WEBGL_lose_context");b&&b.restoreContext()},this.getPixelRatio=function(){return Mt},this.setPixelRatio=function(b){b!==void 0&&(Mt=b,this.setSize(Et,Nt,!1))},this.getSize=function(b){return b.set(Et,Nt)},this.setSize=function(b,N,W=!0){if(rt.isPresenting){Bt("WebGLRenderer: Can't change size while VR device is presenting.");return}Et=b,Nt=N,e.width=Math.floor(b*Mt),e.height=Math.floor(N*Mt),W===!0&&(e.style.width=b+"px",e.style.height=N+"px"),P!==null&&P.setSize(e.width,e.height),this.setViewport(0,0,b,N)},this.getDrawingBufferSize=function(b){return b.set(Et*Mt,Nt*Mt).floor()},this.setDrawingBufferSize=function(b,N,W){Et=b,Nt=N,Mt=W,e.width=Math.floor(b*W),e.height=Math.floor(N*W),this.setViewport(0,0,b,N)},this.setEffects=function(b){if(v===pi){se("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(b){for(let N=0;N<b.length;N++)if(b[N].isOutputPass===!0){Bt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}P.setEffects(b||[])},this.getCurrentViewport=function(b){return b.copy(it)},this.getViewport=function(b){return b.copy(Ot)},this.setViewport=function(b,N,W,z){b.isVector4?Ot.set(b.x,b.y,b.z,b.w):Ot.set(b,N,W,z),vt.viewport(it.copy(Ot).multiplyScalar(vi()).round())},this.getScissor=function(b){return b.copy(le)},this.setScissor=function(b,N,W,z){b.isVector4?le.set(b.x,b.y,b.z,b.w):le.set(b,N,W,z),vt.scissor(Rt.copy(le).multiplyScalar(vi()).round())},this.getScissorTest=function(){return fe},this.setScissorTest=function(b){vt.setScissorTest(fe=b)},this.setOpaqueSort=function(b){Vt=b},this.setTransparentSort=function(b){Ae=b},this.getClearColor=function(b){return b.copy(L.getClearColor())},this.setClearColor=function(){L.setClearColor(...arguments)},this.getClearAlpha=function(){return L.getClearAlpha()},this.setClearAlpha=function(){L.setClearAlpha(...arguments)},this.clear=function(b=!0,N=!0,W=!0){let z=0;if(b){let G=!1;if(et!==null){const mt=et.texture.format;G=m.has(mt)}if(G){const mt=et.texture.type,bt=g.has(mt),dt=L.getClearColor(),St=L.getClearAlpha(),Ct=dt.r,Ht=dt.g,Jt=dt.b;bt?(_[0]=Ct,_[1]=Ht,_[2]=Jt,_[3]=St,O.clearBufferuiv(O.COLOR,0,_)):(M[0]=Ct,M[1]=Ht,M[2]=Jt,M[3]=St,O.clearBufferiv(O.COLOR,0,M))}else z|=O.COLOR_BUFFER_BIT}N&&(z|=O.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),W&&(z|=O.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),z!==0&&O.clear(z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(b){b.setRenderer(this),B=b},this.dispose=function(){e.removeEventListener("webglcontextlost",Dt,!1),e.removeEventListener("webglcontextrestored",Wt,!1),e.removeEventListener("webglcontextcreationerror",_t,!1),L.dispose(),pt.dispose(),$.dispose(),zt.dispose(),Ut.dispose(),A.dispose(),nt.dispose(),k.dispose(),lt.dispose(),Pt.dispose(),j.dispose(),rt.dispose(),rt.removeEventListener("sessionstart",yl),rt.removeEventListener("sessionend",Ml),mn.stop()};function Dt(b){b.preventDefault(),qr("WebGLRenderer: Context Lost."),U=!0}function Wt(){qr("WebGLRenderer: Context Restored."),U=!1;const b=Le.autoReset,N=ht.enabled,W=ht.autoUpdate,z=ht.needsUpdate,G=ht.type;qt(),Le.autoReset=b,ht.enabled=N,ht.autoUpdate=W,ht.needsUpdate=z,ht.type=G}function _t(b){se("WebGLRenderer: A WebGL context could not be created. Reason: ",b.statusMessage)}function ce(b){const N=b.target;N.removeEventListener("dispose",ce),Be(N)}function Be(b){Ji(b),Ut.remove(b)}function Ji(b){const N=Ut.get(b).programs;N!==void 0&&(N.forEach(function(W){j.releaseProgram(W)}),b.isShaderMaterial&&j.releaseShaderCache(b))}this.renderBufferDirect=function(b,N,W,z,G,mt){N===null&&(N=mi);const bt=G.isMesh&&G.matrixWorld.determinantAffine()<0,dt=cu(b,N,W,z,G);vt.setMaterial(z,bt);let St=W.index,Ct=1;if(z.wireframe===!0){if(St=k.getWireframeAttribute(W),St===void 0)return;Ct=2}const Ht=W.drawRange,Jt=W.attributes.position;let Tt=Ht.start*Ct,jt=(Ht.start+Ht.count)*Ct;mt!==null&&(Tt=Math.max(Tt,mt.start*Ct),jt=Math.min(jt,(mt.start+mt.count)*Ct)),St!==null?(Tt=Math.max(Tt,0),jt=Math.min(jt,St.count)):Jt!=null&&(Tt=Math.max(Tt,0),jt=Math.min(jt,Jt.count));const Re=jt-Tt;if(Re<0||Re===1/0)return;lt.setup(G,z,dt,W,St);let me,pe=q;if(St!==null&&(me=S.get(St),pe=ut,pe.setIndex(me)),G.isMesh)z.wireframe===!0?(vt.setLineWidth(z.wireframeLinewidth*vi()),pe.setMode(O.LINES)):pe.setMode(O.TRIANGLES);else if(G.isLine){let qe=z.linewidth;qe===void 0&&(qe=1),vt.setLineWidth(qe*vi()),G.isLineSegments?pe.setMode(O.LINES):G.isLineLoop?pe.setMode(O.LINE_LOOP):pe.setMode(O.LINE_STRIP)}else G.isPoints?pe.setMode(O.POINTS):G.isSprite&&pe.setMode(O.TRIANGLES);if(G.isBatchedMesh)if(ge.get("WEBGL_multi_draw"))pe.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else{const qe=G._multiDrawStarts,At=G._multiDrawCounts,ti=G._multiDrawCount,re=St?S.get(St).bytesPerElement:1,gn=Ut.get(z).currentProgram.getUniforms();for(let Ye=0;Ye<ti;Ye++)gn.setValue(O,"_gl_DrawID",Ye),pe.render(qe[Ye]/re,At[Ye])}else if(G.isInstancedMesh)pe.renderInstances(Tt,Re,G.count);else if(W.isInstancedBufferGeometry){const qe=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,At=Math.min(W.instanceCount,qe);pe.renderInstances(Tt,Re,At)}else pe.render(Tt,Re)};function xl(b,N,W,z){B!==null&&b.isNodeMaterial&&B.setObject(z,b),Pe===!0&&K.setState(b,W,!1),b.transparent===!0&&b.side===ae&&b.forceSinglePass===!1?(b.side=Je,b.needsUpdate=!0,fs(b,N,z),b.side=cn,b.needsUpdate=!0,fs(b,N,z),b.side=ae):fs(b,N,z)}this.compile=function(b,N,W=null){W===null&&(W=b),B!==null&&B.renderStart(b,N,W),T=$.get(W),T.init(N),w.push(T),W.traverseVisible(function(G){G.isLight&&G.layers.test(N.layers)&&(T.pushLight(G),G.castShadow&&T.pushShadow(G))}),b!==W&&b.traverseVisible(function(G){G.isLight&&G.layers.test(N.layers)&&(T.pushLight(G),G.castShadow&&T.pushShadow(G))}),T.setupLights(),B!==null&&B.updateLights(T.state.lightsArray),ri=this.localClippingEnabled,Pe=K.init(this.clippingPlanes,ri),Pe===!0&&K.setGlobalState(this.clippingPlanes,N),B!==null&&ht.render(T.state.shadowsArray,W,N);const z=new Set;return b.traverse(function(G){if(!(G.isMesh||G.isPoints||G.isLine||G.isSprite))return;const mt=G.material;if(mt)if(Array.isArray(mt))for(let bt=0;bt<mt.length;bt++){const dt=mt[bt];xl(dt,W,N,G),z.add(dt)}else xl(mt,W,N,G),z.add(mt)}),T=w.pop(),B!==null&&B.renderEnd(),z},this.compileAsync=function(b,N,W=null){const z=this.compile(b,N,W);return new Promise(G=>{function mt(){if(z.forEach(function(bt){const St=Ut.get(bt).currentProgram;(St===void 0||St.isReady())&&z.delete(bt)}),z.size===0){G(b);return}setTimeout(mt,10)}ge.get("KHR_parallel_shader_compile")!==null?mt():setTimeout(mt,10)})};let ao=null;function au(b){ao&&ao(b)}function yl(){mn.stop()}function Ml(){mn.start()}const mn=new qh;mn.setAnimationLoop(au),typeof self<"u"&&mn.setContext(self),this.setAnimationLoop=function(b){ao=b,rt.setAnimationLoop(b),b===null?mn.stop():mn.start()},rt.addEventListener("sessionstart",yl),rt.addEventListener("sessionend",Ml),this.render=function(b,N){if(N!==void 0&&N.isCamera!==!0){se("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(U===!0)return;B!==null&&B.renderStart(b,N);const W=rt.enabled===!0&&rt.isPresenting===!0,z=P!==null&&(et===null||W)&&P.begin(C,et);if(b.matrixWorldAutoUpdate===!0&&b.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),rt.enabled===!0&&rt.isPresenting===!0&&(P===null||P.isCompositing()===!1)&&(rt.cameraAutoUpdate===!0&&rt.updateCamera(N),N=rt.getCamera()),b.isScene===!0&&b.onBeforeRender(C,b,N,et),T=$.get(b,w.length),T.init(N),T.state.textureUnits=zt.getTextureUnits(),w.push(T),xe.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),N.isArrayCamera?He.setFromArrayCamera(N):Zt.setFromProjectionMatrix(xe,Ti,N.reversedDepth),ri=this.localClippingEnabled,Pe=K.init(this.clippingPlanes,ri),E=pt.get(b,x.length),E.init(),x.push(E),this.info.render.frame++,rt.enabled===!0&&rt.isPresenting===!0){const bt=C.xr.getDepthSensingMesh();bt!==null&&lo(bt,N,-1/0,C.sortObjects)}lo(b,N,0,C.sortObjects),E.finish(),B!==null&&B.updateLights(T.state.lightsArray),C.sortObjects===!0&&E.sort(Vt,Ae),gi=rt.enabled===!1||rt.isPresenting===!1||rt.hasDepthSensing()===!1,gi&&L.addToRenderList(E,b),this.info.autoReset===!0&&this.info.reset(),Pe===!0&&K.beginShadows();const G=T.state.shadowsArray;if(ht.render(G,b,N),Pe===!0&&K.endShadows(),(z&&P.hasRenderPass())===!1){const bt=E.opaque,dt=E.transmissive;if(T.setupLights(),N.isArrayCamera){const St=N.cameras;if(dt.length>0)for(let Ct=0,Ht=St.length;Ct<Ht;Ct++){const Jt=St[Ct];wl(bt,dt,b,Jt)}gi&&L.render(b);for(let Ct=0,Ht=St.length;Ct<Ht;Ct++){const Jt=St[Ct];Sl(E,b,Jt,Jt.viewport)}}else dt.length>0&&wl(bt,dt,b,N),gi&&L.render(b),Sl(E,b,N)}et!==null&&F===0&&(zt.updateMultisampleRenderTarget(et),zt.updateRenderTargetMipmap(et)),z&&P.end(C),b.isScene===!0&&b.onAfterRender(C,b,N),lt.resetDefaultState(),X=-1,tt=null,w.pop(),w.length>0?(T=w[w.length-1],zt.setTextureUnits(T.state.textureUnits),Pe===!0&&K.setGlobalState(C.clippingPlanes,T.state.camera)):T=null,x.pop(),x.length>0?E=x[x.length-1]:E=null,B!==null&&B.renderEnd()};function lo(b,N,W,z){if(b.visible===!1)return;if(b.layers.test(N.layers)){if(b.isGroup)W=b.renderOrder;else if(b.isLOD)b.autoUpdate===!0&&b.update(N);else if(b.isLight)T.pushLight(b),b.castShadow&&T.pushShadow(b);else if(b.isSprite){const bt=N.isArrayCamera?He:Zt;if(!b.frustumCulled||b.intersectsFrustum(bt)){z&&Oe.setFromMatrixPosition(b.matrixWorld).applyMatrix4(xe);const dt=nt.update(b),St=b.material;St.visible&&E.push(b,dt,St,W,Oe.z,null,N)}}else if(b.isMesh||b.isLine||b.isPoints){const bt=N.isArrayCamera?He:Zt;if(!b.frustumCulled||b.intersectsFrustum(bt)){const dt=nt.update(b),St=b.material;if(z&&(b.boundingSphere!==void 0?(b.boundingSphere===null&&b.computeBoundingSphere(),Oe.copy(b.boundingSphere.center)):(dt.boundingSphere===null&&dt.computeBoundingSphere(),Oe.copy(dt.boundingSphere.center)),Oe.applyMatrix4(b.matrixWorld).applyMatrix4(xe)),Array.isArray(St)){const Ct=dt.groups;for(let Ht=0,Jt=Ct.length;Ht<Jt;Ht++){const Tt=Ct[Ht],jt=St[Tt.materialIndex];jt&&jt.visible&&E.push(b,dt,jt,W,Oe.z,Tt,N)}}else St.visible&&E.push(b,dt,St,W,Oe.z,null,N)}}}const mt=b.children;for(let bt=0,dt=mt.length;bt<dt;bt++)lo(mt[bt],N,W,z)}function Sl(b,N,W,z){const{opaque:G,transmissive:mt,transparent:bt}=b;T.setupLightsView(W),Pe===!0&&K.setGlobalState(C.clippingPlanes,W),z&&vt.viewport(it.copy(z)),G.length>0&&Js(G,N,W),mt.length>0&&Js(mt,N,W),bt.length>0&&Js(bt,N,W),vt.buffers.depth.setTest(!0),vt.buffers.depth.setMask(!0),vt.buffers.color.setMask(!0),vt.setPolygonOffset(!1)}function wl(b,N,W,z){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;if(T.state.transmissionRenderTarget[z.id]===void 0){const Tt=ge.has("EXT_color_buffer_half_float")||ge.has("EXT_color_buffer_float");T.state.transmissionRenderTarget[z.id]=new Ai(1,1,{generateMipmaps:!0,type:Tt?Oi:pi,minFilter:an,samples:Math.max(4,ve.samples),stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Qt.workingColorSpace})}const mt=T.state.transmissionRenderTarget[z.id],bt=z.viewport||it;mt.setSize(bt.z*C.transmissionResolutionScale,bt.w*C.transmissionResolutionScale);const dt=C.getRenderTarget(),St=C.getActiveCubeFace(),Ct=C.getActiveMipmapLevel();C.setRenderTarget(mt),C.getClearColor(Z),yt=C.getClearAlpha(),yt<1&&C.setClearColor(16777215,.5),C.clear(),gi&&L.render(W);const Ht=C.toneMapping;C.toneMapping=$i;const Jt=z.viewport;if(z.viewport!==void 0&&(z.viewport=void 0),T.setupLightsView(z),Pe===!0&&K.setGlobalState(C.clippingPlanes,z),Js(b,W,z),zt.updateMultisampleRenderTarget(mt),zt.updateRenderTargetMipmap(mt),ge.has("WEBGL_multisampled_render_to_texture")===!1){let Tt=!1;for(let jt=0,Re=N.length;jt<Re;jt++){const me=N[jt],{object:pe,geometry:qe,material:At,group:ti}=me;if(At.side===ae&&pe.layers.test(z.layers)){const re=At.side;At.side=Je,At.needsUpdate=!0,bl(pe,W,z,qe,At,ti),At.side=re,At.needsUpdate=!0,Tt=!0}}Tt===!0&&(zt.updateMultisampleRenderTarget(mt),zt.updateRenderTargetMipmap(mt))}C.setRenderTarget(dt,St,Ct),C.setClearColor(Z,yt),Jt!==void 0&&(z.viewport=Jt),C.toneMapping=Ht}function Js(b,N,W){const z=N.isScene===!0?N.overrideMaterial:null;for(let G=0,mt=b.length;G<mt;G++){const bt=b[G],{object:dt,geometry:St,group:Ct}=bt;let Ht=bt.material;Ht.allowOverride===!0&&z!==null&&(Ht=z),dt.layers.test(W.layers)&&bl(dt,N,W,St,Ht,Ct)}}function bl(b,N,W,z,G,mt){B!==null&&G.isNodeMaterial&&B.setObject(b,G),b.onBeforeRender(C,N,W,z,G,mt),b.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,b.matrixWorld),b.normalMatrix.getNormalMatrix(b.modelViewMatrix),G.onBeforeRender(C,N,W,z,b,mt),G.transparent===!0&&G.side===ae&&G.forceSinglePass===!1?(G.side=Je,G.needsUpdate=!0,C.renderBufferDirect(W,N,z,G,b,mt),G.side=cn,G.needsUpdate=!0,C.renderBufferDirect(W,N,z,G,b,mt),G.side=ae):C.renderBufferDirect(W,N,z,G,b,mt),b.onAfterRender(C,N,W,z,G,mt)}function El(b){let N=0;for(const W of b)W.texture!==null&&N++;return N}function fs(b,N,W){N.isScene!==!0&&(N=mi);const z=Ut.get(b),G=T.state.lights,mt=T.state.shadowsArray,bt=G.state.version,dt=j.getParameters(b,G.state,mt,N,W,T.state.lightProbeGridArray),St=j.getProgramCacheKey(dt);let Ct=z.programs;z.environment=b.isMeshStandardMaterial||b.isMeshLambertMaterial||b.isMeshPhongMaterial?N.environment:null,z.fog=N.fog;const Ht=b.isMeshStandardMaterial||b.isMeshLambertMaterial&&!b.envMap||b.isMeshPhongMaterial&&!b.envMap;z.envMap=A.get(b.envMap||z.environment,Ht),z.envMapRotation=z.environment!==null&&b.envMap===null?N.environmentRotation:b.envMapRotation,Ct===void 0&&(b.addEventListener("dispose",ce),Ct=new Map,z.programs=Ct,z.programVariants=new Map);let Jt=Ct.get(St);if(Jt!==void 0){if(z.currentProgram===Jt&&z.lightsStateVersion===bt)return Al(b,dt),Jt}else dt.uniforms=j.getUniforms(b),B!==null&&b.isNodeMaterial&&B.build(b,W,dt),b.onBeforeCompile(dt,C),Jt=j.acquireProgram(dt,St),Ct.set(St,Jt),z.uniforms=dt.uniforms;const Tt=z.uniforms;return(!b.isShaderMaterial&&!b.isRawShaderMaterial||b.clipping===!0)&&(Tt.clippingPlanes=K.uniform),Al(b,dt),z.needsLights=uu(b),z.lightsStateVersion=bt,z.needsLights&&(Tt.ambientLightColor.value=G.state.ambient,Tt.lightProbe.value=G.state.probe,Tt.sunLights.value=G.state.sun,Tt.sunLightShadows.value=G.state.sunShadow,Tt.directionalLights.value=G.state.directional,Tt.directionalLightShadows.value=G.state.directionalShadow,Tt.spotLights.value=G.state.spot,Tt.spotLightShadows.value=G.state.spotShadow,Tt.rectAreaLights.value=G.state.rectArea,Tt.ltc_1.value=G.state.rectAreaLTC1,Tt.ltc_2.value=G.state.rectAreaLTC2,Tt.pointLights.value=G.state.point,Tt.pointLightShadows.value=G.state.pointShadow,Tt.hemisphereLights.value=G.state.hemi,Tt.sunShadowMatrix.value=G.state.sunShadowMatrix,Tt.sunShadowCascade.value=G.state.sunShadowCascade,Tt.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Tt.spotLightMatrix.value=G.state.spotLightMatrix,Tt.spotLightMap.value=G.state.spotLightMap,Tt.pointShadowMatrix.value=G.state.pointShadowMatrix),z.numLightProbeGrids=El(T.state.lightProbeGridArray),z.currentProgram=Jt,z.uniformsList=null,Jt}function lu(b,N,W,z,G){const mt=Ut.get(b),bt=mt.currentProgram.id+","+z+","+G;let dt=mt.programVariants.get(bt);return dt===void 0?(dt=fs(b,N,W),mt.programVariants.set(bt,dt)):(mt.currentProgram=dt,mt.uniformsList=null,mt.outputColorSpace=z,mt.toneMapping=G),dt}function Tl(b){if(b.uniformsList===null){const N=b.currentProgram.getUniforms();b.uniformsList=kr.seqWithValue(N.seq,b.uniforms)}return b.uniformsList}function Al(b,N){const W=Ut.get(b);W.outputColorSpace=N.outputColorSpace,W.batching=N.batching,W.batchingColor=N.batchingColor,W.instancing=N.instancing,W.instancingColor=N.instancingColor,W.instancingMorph=N.instancingMorph,W.skinning=N.skinning,W.morphTargets=N.morphTargets,W.morphNormals=N.morphNormals,W.morphColors=N.morphColors,W.morphTargetsCount=N.morphTargetsCount,W.numClippingPlanes=N.numClippingPlanes,W.numIntersection=N.numClipIntersection,W.vertexAlphas=N.vertexAlphas,W.vertexTangents=N.vertexTangents,W.toneMapping=N.toneMapping}function cu(b,N,W,z,G){N.isScene!==!0&&(N=mi),zt.resetTextureUnits();const mt=N.fog,bt=z.isMeshStandardMaterial||z.isMeshLambertMaterial||z.isMeshPhongMaterial?N.environment:null,dt=et===null?C.outputColorSpace:et.isXRRenderTarget===!0?et.texture.colorSpace:Qt.workingColorSpace,St=z.isMeshStandardMaterial||z.isMeshLambertMaterial&&!z.envMap||z.isMeshPhongMaterial&&!z.envMap,Ct=A.get(z.envMap||bt,St),Ht=z.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,Jt=!!W.attributes.tangent&&(!!z.normalMap||z.anisotropy>0),Tt=!!W.morphAttributes.position,jt=!!W.morphAttributes.normal,Re=!!W.morphAttributes.color;let me=$i;z.toneMapped&&(et===null||et.isXRRenderTarget===!0)&&(me=C.toneMapping);const pe=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,qe=pe!==void 0?pe.length:0,At=Ut.get(z),ti=T.state.lights;if(Pe===!0&&(ri===!0||b!==tt)){const ye=b===tt&&z.id===X;K.setState(z,b,ye)}let re=!1,gn=!1;z.version===At.__version?At.needsLights&&At.lightsStateVersion!==ti.state.version||G.isBatchedMesh&&At.batching===!1||!G.isBatchedMesh&&At.batching===!0||G.isBatchedMesh&&At.batchingColor===!0&&G._colorsTexture===null||G.isBatchedMesh&&At.batchingColor===!1&&G._colorsTexture!==null||G.isInstancedMesh&&At.instancing===!1||!G.isInstancedMesh&&At.instancing===!0||G.isSkinnedMesh&&At.skinning===!1||!G.isSkinnedMesh&&At.skinning===!0||G.isInstancedMesh&&At.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&At.instancingColor===!1&&G.instanceColor!==null||G.isInstancedMesh&&At.instancingMorph===!0&&G.morphTexture===null||G.isInstancedMesh&&At.instancingMorph===!1&&G.morphTexture!==null||At.envMap!==Ct||z.fog===!0&&At.fog!==mt||At.numClippingPlanes!==void 0&&(At.numClippingPlanes!==K.numPlanes||At.numIntersection!==K.numIntersection)||At.vertexAlphas!==Ht||At.vertexTangents!==Jt||At.morphTargets!==Tt||At.morphNormals!==jt||At.morphColors!==Re||At.morphTargetsCount!==qe||At.numLightProbeGrids!==El(T.state.lightProbeGridArray)?re=!0:(At.outputColorSpace!==dt||At.toneMapping!==me)&&(gn=!0):(re=!0,At.__version=z.version);let Ye=At.currentProgram;(re===!0||gn===!0)&&(Ye=gn===!0?lu(z,N,G,dt,me):fs(z,N,G),B&&z.isNodeMaterial&&B.onUpdateProgram(z,Ye,At));let js=!1,ji=!1,vn=!1;const ie=Ye.getUniforms(),Ve=At.uniforms;if(vt.useProgram(Ye.program)&&(js=!0,ji=!0,vn=!0),z.id!==X&&(X=z.id,ji=!0),js||tt!==b){vt.buffers.depth.getReversed()&&b.reversedDepth!==!0&&(b._reversedDepth=!0,b.updateProjectionMatrix()),ie.setValue(O,"projectionMatrix",b.projectionMatrix),ie.setValue(O,"viewMatrix",b.matrixWorldInverse);const ze=ie.map.cameraPosition;ze!==void 0&&ze.setValue(O,Ri.setFromMatrixPosition(b.matrixWorld)),ve.logarithmicDepthBuffer&&ie.setValue(O,"logDepthBufFC",2/(Math.log(b.far+1)/Math.LN2)),(z.isMeshPhongMaterial||z.isMeshToonMaterial||z.isMeshLambertMaterial||z.isMeshBasicMaterial||z.isMeshStandardMaterial||z.isShaderMaterial)&&ie.setValue(O,"isOrthographic",b.isOrthographicCamera===!0),tt!==b&&(tt=b,ji=!0,vn=!0)}if(At.needsLights&&(ti.state.sunShadowMap.length>0&&ie.setValue(O,"sunShadowMap",ti.state.sunShadowMap,zt),ti.state.directionalShadowMap.length>0&&ie.setValue(O,"directionalShadowMap",ti.state.directionalShadowMap,zt),ti.state.spotShadowMap.length>0&&ie.setValue(O,"spotShadowMap",ti.state.spotShadowMap,zt),ti.state.pointShadowMap.length>0&&ie.setValue(O,"pointShadowMap",ti.state.pointShadowMap,zt)),G.isSkinnedMesh){ie.setOptional(O,G,"bindMatrix"),ie.setOptional(O,G,"bindMatrixInverse");const ye=G.skeleton;ye&&(ye.boneTexture===null&&ye.computeBoneTexture(),ie.setValue(O,"boneTexture",ye.boneTexture,zt))}G.isBatchedMesh&&(ie.setOptional(O,G,"batchingTexture"),ie.setValue(O,"batchingTexture",G._matricesTexture,zt),ie.setOptional(O,G,"batchingIdTexture"),ie.setValue(O,"batchingIdTexture",G._indirectTexture,zt),ie.setOptional(O,G,"batchingColorTexture"),G._colorsTexture!==null&&ie.setValue(O,"batchingColorTexture",G._colorsTexture,zt));const Mi=W.morphAttributes;if((Mi.position!==void 0||Mi.normal!==void 0||Mi.color!==void 0)&&J.update(G,W,Ye),(ji||At.receiveShadow!==G.receiveShadow)&&(At.receiveShadow=G.receiveShadow,ie.setValue(O,"receiveShadow",G.receiveShadow)),(z.isMeshStandardMaterial||z.isMeshLambertMaterial||z.isMeshPhongMaterial)&&z.envMap===null&&N.environment!==null&&(Ve.envMapIntensity.value=N.environmentIntensity),Ve.dfgLUT!==void 0&&(Ve.dfgLUT.value=ev()),ji){if(ie.setValue(O,"toneMappingExposure",C.toneMappingExposure),At.needsLights&&hu(Ve,vn),mt&&z.fog===!0&&at.refreshFogUniforms(Ve,mt),at.refreshMaterialUniforms(Ve,z,Mt,Nt,T.state.transmissionRenderTarget[b.id]),At.needsLights&&At.numLightProbeGrids>0){const ye=y;let ze=0;for(const zi of T.state.lightProbeGridArray)zi.texture!==null&&(ye.textures[ze]=zi.texture,ye.min[ze]=zi.boundingBox.min,ye.max[ze]=zi.boundingBox.max,ye.resolution[ze]=zi.resolution,ze++);for(const zi in ye)ye[zi].length=ze;Ve.probesSH.value=ye.textures,Ve.probesMin.value=ye.min,Ve.probesMax.value=ye.max,Ve.probesResolution.value=ye.resolution}kr.upload(O,Tl(At),Ve,zt)}if(z.isShaderMaterial&&z.uniformsNeedUpdate===!0&&(kr.upload(O,Tl(At),Ve,zt),z.uniformsNeedUpdate=!1),z.isSpriteMaterial&&ie.setValue(O,"center",G.center),ie.setValue(O,"modelViewMatrix",G.modelViewMatrix),ie.setValue(O,"normalMatrix",G.normalMatrix),ie.setValue(O,"modelMatrix",G.matrixWorld),z.uniformsGroups!==void 0){const ye=z.uniformsGroups;for(let ze=0,zi=ye.length;ze<zi;ze++){const Cl=ye[ze];Pt.update(Cl,Ye),Pt.bind(Cl,Ye)}}return Ye}function hu(b,N){b.ambientLightColor.needsUpdate=N,b.lightProbe.needsUpdate=N,b.sunLights.needsUpdate=N,b.sunLightShadows.needsUpdate=N,b.directionalLights.needsUpdate=N,b.directionalLightShadows.needsUpdate=N,b.pointLights.needsUpdate=N,b.pointLightShadows.needsUpdate=N,b.spotLights.needsUpdate=N,b.spotLightShadows.needsUpdate=N,b.rectAreaLights.needsUpdate=N,b.hemisphereLights.needsUpdate=N}function uu(b){return b.isMeshLambertMaterial||b.isMeshToonMaterial||b.isMeshPhongMaterial||b.isMeshStandardMaterial||b.isShadowMaterial||b.isShaderMaterial&&b.lights===!0}this.getActiveCubeFace=function(){return Y},this.getActiveMipmapLevel=function(){return F},this.getRenderTarget=function(){return et},this.setRenderTargetTextures=function(b,N,W){const z=Ut.get(b);z.__autoAllocateDepthBuffer=b.resolveDepthBuffer===!1,z.__autoAllocateDepthBuffer===!1&&(z.__useRenderToTexture=!1),Ut.get(b.texture).__webglTexture=N,Ut.get(b.depthTexture).__webglTexture=z.__autoAllocateDepthBuffer?void 0:W,z.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(b,N){const W=Ut.get(b);W.__webglFramebuffer=N,W.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(b,N=0,W=0){et=b,Y=N,F=W;let z=null,G=!1,mt=!1;if(b){const dt=Ut.get(b);if(dt.__useDefaultFramebuffer!==void 0){vt.bindFramebuffer(O.FRAMEBUFFER,dt.__webglFramebuffer),it.copy(b.viewport),Rt.copy(b.scissor),Gt=b.scissorTest,vt.viewport(it),vt.scissor(Rt),vt.setScissorTest(Gt),X=-1;return}else if(dt.__webglFramebuffer===void 0)zt.setupRenderTarget(b);else if(dt.__hasExternalTextures)zt.rebindTextures(b,Ut.get(b.texture).__webglTexture,Ut.get(b.depthTexture).__webglTexture);else if(b.depthBuffer){const Ht=b.depthTexture;if(dt.__boundDepthTexture!==Ht){if(Ht!==null&&Ut.has(Ht)&&(b.width!==Ht.image.width||b.height!==Ht.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");zt.setupDepthRenderbuffer(b)}}const St=b.texture;(St.isData3DTexture||St.isDataArrayTexture||St.isCompressedArrayTexture)&&(mt=!0);const Ct=Ut.get(b).__webglFramebuffer;b.isWebGLCubeRenderTarget?(Array.isArray(Ct[N])?z=Ct[N][W]:z=Ct[N],G=!0):b.samples>0&&zt.useMultisampledRTT(b)===!1?z=Ut.get(b).__webglMultisampledFramebuffer:Array.isArray(Ct)?z=Ct[W]:z=Ct,it.copy(b.viewport),Rt.copy(b.scissor),Gt=b.scissorTest}else it.copy(Ot).multiplyScalar(Mt).floor(),Rt.copy(le).multiplyScalar(Mt).floor(),Gt=fe;if(W!==0&&(z=V),vt.bindFramebuffer(O.FRAMEBUFFER,z)&&vt.drawBuffers(b,z),vt.viewport(it),vt.scissor(Rt),vt.setScissorTest(Gt),G){const dt=Ut.get(b.texture);O.framebufferTexture2D(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0,O.TEXTURE_CUBE_MAP_POSITIVE_X+N,dt.__webglTexture,W)}else if(mt){const dt=N;for(let St=0;St<b.textures.length;St++){const Ct=Ut.get(b.textures[St]);O.framebufferTextureLayer(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0+St,Ct.__webglTexture,W,dt)}}else if(b!==null&&W!==0){const dt=Ut.get(b.texture);O.framebufferTexture2D(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0,O.TEXTURE_2D,dt.__webglTexture,W)}X=-1};function Rl(b){const N=Ut.get(b);return(N.__readFormat!==b.format||N.__readType!==b.type)&&(N.__readFormat=b.format,N.__readType=b.type,N.__formatReadable=ve.textureFormatReadable(b.format),N.__typeReadable=ve.textureTypeReadable(b.type)),N}this.readRenderTargetPixels=function(b,N,W,z,G,mt,bt,dt=0){if(!(b&&b.isWebGLRenderTarget)){se("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let St=Ut.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&bt!==void 0&&(St=St[bt],Array.isArray(St)&&(St=St[0])),St){vt.bindFramebuffer(O.FRAMEBUFFER,St);try{const Ct=b.textures[dt],Ht=Ct.format,Jt=Ct.type;b.textures.length>1&&O.readBuffer(O.COLOR_ATTACHMENT0+dt);const Tt=Rl(Ct);if(Tt.__formatReadable===!1){se("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Tt.__typeReadable===!1){se("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=b.width-z&&W>=0&&W<=b.height-G&&O.readPixels(N,W,z,G,ot.convert(Ht),ot.convert(Jt),mt)}finally{const Ct=et!==null?Ut.get(et).__webglFramebuffer:null;vt.bindFramebuffer(O.FRAMEBUFFER,Ct)}}},this.readRenderTargetPixelsAsync=async function(b,N,W,z,G,mt,bt,dt=0){if(!(b&&b.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let St=Ut.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&bt!==void 0&&(St=St[bt],Array.isArray(St)&&(St=St[0])),St)if(N>=0&&N<=b.width-z&&W>=0&&W<=b.height-G){vt.bindFramebuffer(O.FRAMEBUFFER,St);const Ct=b.textures[dt],Ht=Ct.format,Jt=Ct.type;b.textures.length>1&&O.readBuffer(O.COLOR_ATTACHMENT0+dt);const Tt=Rl(Ct);if(Tt.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Tt.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const jt=O.createBuffer();O.bindBuffer(O.PIXEL_PACK_BUFFER,jt),O.bufferData(O.PIXEL_PACK_BUFFER,mt.byteLength,O.STREAM_READ),O.readPixels(N,W,z,G,ot.convert(Ht),ot.convert(Jt),0),O.bindBuffer(O.PIXEL_PACK_BUFFER,null);const Re=et!==null?Ut.get(et).__webglFramebuffer:null;vt.bindFramebuffer(O.FRAMEBUFFER,Re);const me=O.fenceSync(O.SYNC_GPU_COMMANDS_COMPLETE,0);return O.flush(),await qu(O,me,4),O.bindBuffer(O.PIXEL_PACK_BUFFER,jt),O.getBufferSubData(O.PIXEL_PACK_BUFFER,0,mt),O.bindBuffer(O.PIXEL_PACK_BUFFER,null),O.deleteBuffer(jt),O.deleteSync(me),mt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(b,N=null,W=0){const z=Math.pow(2,-W),G=Math.floor(b.image.width*z),mt=Math.floor(b.image.height*z),bt=N!==null?N.x:0,dt=N!==null?N.y:0;zt.setTexture2D(b,0),O.copyTexSubImage2D(O.TEXTURE_2D,W,0,0,bt,dt,G,mt),vt.unbindTexture()},this.copyTextureToTexture=function(b,N,W=null,z=null,G=0,mt=0){let bt,dt,St,Ct,Ht,Jt,Tt,jt,Re;const me=b.isCompressedTexture?b.mipmaps[mt]:b.image;if(W!==null)bt=W.max.x-W.min.x,dt=W.max.y-W.min.y,St=W.isBox3?W.max.z-W.min.z:1,Ct=W.min.x,Ht=W.min.y,Jt=W.isBox3?W.min.z:0;else{const ie=Math.pow(2,-G);bt=Math.floor(me.width*ie),dt=Math.floor(me.height*ie),b.isDataArrayTexture?St=me.depth:b.isData3DTexture?St=Math.floor(me.depth*ie):St=1,Ct=0,Ht=0,Jt=0}z!==null?(Tt=z.x,jt=z.y,Re=z.z):(Tt=0,jt=0,Re=0);const pe=ot.convert(N.format),qe=ot.convert(N.type);let At;N.isData3DTexture?(zt.setTexture3D(N,0),At=O.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(zt.setTexture2DArray(N,0),At=O.TEXTURE_2D_ARRAY):(zt.setTexture2D(N,0),At=O.TEXTURE_2D),vt.activeTexture(O.TEXTURE0),vt.pixelStorei(O.UNPACK_FLIP_Y_WEBGL,N.flipY),vt.pixelStorei(O.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),vt.pixelStorei(O.UNPACK_ALIGNMENT,N.unpackAlignment);const ti=vt.getParameter(O.UNPACK_ROW_LENGTH),re=vt.getParameter(O.UNPACK_IMAGE_HEIGHT),gn=vt.getParameter(O.UNPACK_SKIP_PIXELS),Ye=vt.getParameter(O.UNPACK_SKIP_ROWS),js=vt.getParameter(O.UNPACK_SKIP_IMAGES);vt.pixelStorei(O.UNPACK_ROW_LENGTH,me.width),vt.pixelStorei(O.UNPACK_IMAGE_HEIGHT,me.height),vt.pixelStorei(O.UNPACK_SKIP_PIXELS,Ct),vt.pixelStorei(O.UNPACK_SKIP_ROWS,Ht),vt.pixelStorei(O.UNPACK_SKIP_IMAGES,Jt);const ji=b.isDataArrayTexture||b.isData3DTexture,vn=N.isDataArrayTexture||N.isData3DTexture;if(b.isDepthTexture){const ie=Ut.get(b),Ve=Ut.get(N),Mi=Ut.get(ie.__renderTarget),ye=Ut.get(Ve.__renderTarget);vt.bindFramebuffer(O.READ_FRAMEBUFFER,Mi.__webglFramebuffer),vt.bindFramebuffer(O.DRAW_FRAMEBUFFER,ye.__webglFramebuffer);for(let ze=0;ze<St;ze++)ji&&(O.framebufferTextureLayer(O.READ_FRAMEBUFFER,O.COLOR_ATTACHMENT0,Ut.get(b).__webglTexture,G,Jt+ze),O.framebufferTextureLayer(O.DRAW_FRAMEBUFFER,O.COLOR_ATTACHMENT0,Ut.get(N).__webglTexture,mt,Re+ze)),O.blitFramebuffer(Ct,Ht,Ct+bt,Ht+dt,Tt,jt,Tt+bt,jt+dt,O.DEPTH_BUFFER_BIT,O.NEAREST);vt.bindFramebuffer(O.READ_FRAMEBUFFER,null),vt.bindFramebuffer(O.DRAW_FRAMEBUFFER,null)}else if(G!==0||b.isRenderTargetTexture||Ut.has(b)){const ie=Ut.get(b),Ve=Ut.get(N);vt.bindFramebuffer(O.READ_FRAMEBUFFER,D),vt.bindFramebuffer(O.DRAW_FRAMEBUFFER,H);for(let Mi=0;Mi<St;Mi++)ji?O.framebufferTextureLayer(O.READ_FRAMEBUFFER,O.COLOR_ATTACHMENT0,ie.__webglTexture,G,Jt+Mi):O.framebufferTexture2D(O.READ_FRAMEBUFFER,O.COLOR_ATTACHMENT0,O.TEXTURE_2D,ie.__webglTexture,G),vn?O.framebufferTextureLayer(O.DRAW_FRAMEBUFFER,O.COLOR_ATTACHMENT0,Ve.__webglTexture,mt,Re+Mi):O.framebufferTexture2D(O.DRAW_FRAMEBUFFER,O.COLOR_ATTACHMENT0,O.TEXTURE_2D,Ve.__webglTexture,mt),G!==0?O.blitFramebuffer(Ct,Ht,Ct+bt,Ht+dt,Tt,jt,Tt+bt,jt+dt,O.COLOR_BUFFER_BIT,O.NEAREST):vn?O.copyTexSubImage3D(At,mt,Tt,jt,Re+Mi,Ct,Ht,bt,dt):O.copyTexSubImage2D(At,mt,Tt,jt,Ct,Ht,bt,dt);vt.bindFramebuffer(O.READ_FRAMEBUFFER,null),vt.bindFramebuffer(O.DRAW_FRAMEBUFFER,null)}else vn?b.isDataTexture||b.isData3DTexture?O.texSubImage3D(At,mt,Tt,jt,Re,bt,dt,St,pe,qe,me.data):N.isCompressedArrayTexture?O.compressedTexSubImage3D(At,mt,Tt,jt,Re,bt,dt,St,pe,me.data):O.texSubImage3D(At,mt,Tt,jt,Re,bt,dt,St,pe,qe,me):b.isDataTexture?O.texSubImage2D(O.TEXTURE_2D,mt,Tt,jt,bt,dt,pe,qe,me.data):b.isCompressedTexture?O.compressedTexSubImage2D(O.TEXTURE_2D,mt,Tt,jt,me.width,me.height,pe,me.data):O.texSubImage2D(O.TEXTURE_2D,mt,Tt,jt,bt,dt,pe,qe,me);vt.pixelStorei(O.UNPACK_ROW_LENGTH,ti),vt.pixelStorei(O.UNPACK_IMAGE_HEIGHT,re),vt.pixelStorei(O.UNPACK_SKIP_PIXELS,gn),vt.pixelStorei(O.UNPACK_SKIP_ROWS,Ye),vt.pixelStorei(O.UNPACK_SKIP_IMAGES,js),mt===0&&N.generateMipmaps===!0&&N.mipmapsAutoUpdate===!0&&O.generateMipmap(At),vt.unbindTexture()},this.initRenderTarget=function(b){Ut.get(b).__webglFramebuffer===void 0&&zt.setupRenderTarget(b)},this.initTexture=function(b){b.isCubeTexture?zt.setTextureCube(b,0):b.isData3DTexture?zt.setTexture3D(b,0):b.isDataArrayTexture||b.isCompressedArrayTexture?zt.setTexture2DArray(b,0):zt.setTexture2D(b,0),vt.unbindTexture()},this.resetState=function(){Y=0,F=0,et=null,vt.reset(),lt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ti}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=Qt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Qt._getUnpackColorSpace()}}const ft=(r,t=0,e=1)=>Math.min(e,Math.max(t,r)),Lt=(r,t,e)=>r+(t-r)*e,Ie=(r,t,e)=>{const i=ft((e-r)/(t-r));return i*i*(3-2*i)},nu=r=>r<.5?4*r*r*r:1-Math.pow(-2*r+2,3)/2,kc=r=>r<.5?16*r**5:1-Math.pow(-2*r+2,5)/2,Ee=(r,t,e,i)=>Lt(r,t,1-Math.exp(-e*i));function $t(r){let t=r>>>0;return function(){t|=0,t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}const Cr=(r,t)=>{let e=Math.imul(r|0,374761393)^Math.imul(t|0,668265263);return e=Math.imul(e^e>>>13,1274126177),((e^e>>>16)>>>0)/4294967296};function su(r,t){const e=Math.floor(r),i=Math.floor(t),n=r-e,s=t-i,o=n*n*(3-2*n),a=s*s*(3-2*s),l=Cr(e,i),c=Cr(e+1,i),h=Cr(e,i+1),u=Cr(e+1,i+1);return Lt(Lt(l,c,o),Lt(h,u,o),a)}function jn(r,t,e=4,i=2,n=.5){let s=0,o=.5,a=1;for(let l=0;l<e;l++)s+=o*su(r*a,t*a),a*=i,o*=n;return s}function Te(r,t){const e=document.createElement("canvas");return e.width=r,e.height=t,e}function we(r,{srgb:t=!0,repeat:e=null,aniso:i=4}={}){const n=new ol(r);return n.colorSpace=t?ni:qi,n.anisotropy=i,e&&(n.wrapS=n.wrapT=En,n.repeat.set(e[0],e[1])),n.needsUpdate=!0,n}function rn(r=128,t="rgba(255,255,255,1)",e="rgba(255,255,255,0)",i=null){const n=Te(r,r),s=n.getContext("2d"),o=s.createRadialGradient(r/2,r/2,0,r/2,r/2,r/2);return i?i.forEach(([a,l])=>o.addColorStop(a,l)):(o.addColorStop(0,t),o.addColorStop(.35,"rgba(255,255,255,0.55)"),o.addColorStop(1,e)),s.fillStyle=o,s.fillRect(0,0,r,r),n}class Rn{constructor(t,e,i,n=nu){this.t=0,this.duration=Math.max(1e-4,t),this.onUpdate=e,this.onComplete=i,this.ease=n,this.done=!1}update(t){this.done||(this.t=Math.min(1,this.t+t/this.duration),this.onUpdate(this.ease(this.t),this.t),this.t>=1&&(this.done=!0,this.onComplete&&this.onComplete()))}}const nv=["clear","cloudy","rain","storm","snow","mist"],Gc={clear:{sun:1,humidity:.44,rain:0,snow:0,wind:.2,fog:.1,cloud:.06,temp:.62,boltRate:0},cloudy:{sun:.42,humidity:.58,rain:0,snow:0,wind:.38,fog:.22,cloud:.72,temp:.48,boltRate:0},rain:{sun:.24,humidity:.84,rain:1,snow:0,wind:.46,fog:.3,cloud:.86,temp:.42,boltRate:0},storm:{sun:.14,humidity:.9,rain:1.25,snow:0,wind:.92,fog:.34,cloud:.96,temp:.36,boltRate:.22},snow:{sun:.46,humidity:.7,rain:0,snow:1,wind:.3,fog:.26,cloud:.68,temp:-.35,boltRate:0},mist:{sun:.34,humidity:.78,rain:0,snow:0,wind:.1,fog:.95,cloud:.45,temp:.4,boltRate:0}},sv=600;class rv{constructor(){this.listeners=new Map,this.time=14.5,this.day=1,this.paused=!1,this.timeScale=24/sv,this.usedSlider=!1,this.weatherName="clear",this.w={...Gc.clear},this.targetWeather="clear",this.blendRate=.55,this.humidity=.46,this.condensation=.1,this.snowAccum=0,this.wind=.22,this.temperature=.6,this.lidOpen=0,this.lidTarget=0,this.bioSpeed=1,this.wetness={},this.sunAlt=0,this.sunAz=0,this.night=0,this.golden=0,this.boltTimer=2+Math.random()*4,this.boltFlash=0,this.events=[],this.elapsed=0}on(t,e){return this.listeners.has(t)||this.listeners.set(t,new Set),this.listeners.get(t).add(e),()=>this.listeners.get(t).delete(e)}emit(t,e){const i=this.listeners.get(t);i&&i.forEach(n=>n(e))}setWeather(t,e=!1){nv.includes(t)&&(this.targetWeather=t,e||this.emit("weather",t))}setTime(t){this.time=(t%24+24)%24}togglePause(){this.paused=!this.paused,this.emit("pause",this.paused)}toggleLid(){return this.lidTarget=this.lidTarget>.5?0:1,this.emit("lid",this.lidTarget),this.lidTarget}setBioSpeed(t){this.bioSpeed=t,this.emit("bio",t)}flash(){this.boltFlash=1,this.emit("bolt")}update(t){if(this.elapsed+=t,!this.paused){const d=this.time;this.time+=t*this.timeScale,this.time>=24&&(this.time-=24,this.day++,this.emit("newday",this.day)),d<6&&this.time>=6&&this.emit("dawn"),d<18&&this.time>=18&&this.emit("dusk")}const e=Gc[this.targetWeather],i=1-Math.exp(-this.blendRate*t);for(const d of Object.keys(e))this.w[d]=Lt(this.w[d],e[d],i);this.targetWeather==="storm"&&Math.random()<this.w.boltRate*t&&this.flash(),this.boltFlash=Math.max(0,this.boltFlash-t*2.4);const n=(this.time-6)/24*Math.PI*2;this.sunAlt=Math.sin(n),this.sunAz=n*.92-Math.PI*.15,this.night=Ie(.06,-.17,this.sunAlt),this.golden=ft(1-Math.abs(this.sunAlt)*3.2)*Ie(-.16,0,this.sunAlt),this.lidOpen=Ee(this.lidOpen,this.lidTarget,2.2,t);const s=1-this.lidOpen,o=ft(this.w.humidity*.72+this.w.rain*.14+this.snowAccum*.05+(s-.5)*.34,.12,1);this.humidity=Ee(this.humidity,o,this.lidOpen>.1?.55:.11,t);const a=ft((this.humidity-.5)*1.9)*(1-this.lidOpen*.85);this.condensation=Ee(this.condensation,a,.16+this.lidOpen*.5,t);const l=.5+.5*Math.sin(this.elapsed*.37)*Math.sin(this.elapsed*.13+1.7),c=this.windOverride!=null?this.windOverride:this.w.wind;this.wind=c*(.65+l*.7)*(1-this.lidOpen*.4);const h=ft(this.sunAlt*.5+.5)*.55;this.temperature=Ee(this.temperature,this.w.temp*.6+h-.08,.3,t);const u=this.w.snow*(this.temperature<.18?1:Math.max(0,.3-this.temperature));this.snowAccum=ft(Ee(this.snowAccum,u,.05,t)),this.events.length=0}get isNight(){return this.night>.5}get condensationPct(){return Math.round(this.condensation*100)}get phaseLabel(){const t=this.time;return t<4.5?"deep night":t<6.2?"first light":t<8?"dawn":t<11?"morning":t<14?"midday":t<17?"afternoon":t<19.4?"golden hour":t<21.5?"dusk":t<24?"night":"deep night"}}const Hc={type:"change"},fl={type:"start"},ru={type:"end"},Pr=new to,Vc=new Xi,ov=Math.cos(70*Zu.DEG2RAD),De=new R,oi=2*Math.PI,oe={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},Ho=1e-6;class av extends lf{constructor(t,e=null){super(t,e),this.state=oe.NONE,this.target=new R,this.cursor=new R,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Qn.ROTATE,MIDDLE:Qn.DOLLY,RIGHT:Qn.PAN},this.touches={ONE:on.ROTATE,TWO:on.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new R,this._lastQuaternion=new un,this._lastTargetPosition=new R,this._quat=new un().setFromUnitVectors(t.up,new R(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new vc,this._sphericalDelta=new vc,this._scale=1,this._panOffset=new R,this._rotateStart=new Q,this._rotateEnd=new Q,this._rotateDelta=new Q,this._panStart=new Q,this._panEnd=new Q,this._panDelta=new Q,this._dollyStart=new Q,this._dollyEnd=new Q,this._dollyDelta=new Q,this._dollyDirection=new R,this._mouse=new Q,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=cv.bind(this),this._onPointerDown=lv.bind(this),this._onPointerUp=hv.bind(this),this._onContextMenu=vv.bind(this),this._onMouseWheel=fv.bind(this),this._onKeyDown=pv.bind(this),this._onTouchStart=mv.bind(this),this._onTouchMove=gv.bind(this),this._onMouseDown=uv.bind(this),this._onMouseMove=dv.bind(this),this._interceptControlDown=_v.bind(this),this._interceptControlUp=xv.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(t){this._cursorStyle=t,t==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(t){super.connect(t),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.ownerDocument.addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.state=oe.NONE,this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.ownerDocument.removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.ownerDocument.removeEventListener("keyup",this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction="",this.domElement.style.cursor="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(t){t.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=t}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Hc),this.update(),this.state=oe.NONE}pan(t,e){this._pan(t,e),this.update()}dollyIn(t){this._dollyIn(t),this.update()}dollyOut(t){this._dollyOut(t),this.update()}rotateLeft(t){this._rotateLeft(t),this.update()}rotateUp(t){this._rotateUp(t),this.update()}update(t=null){const e=this.object.position;De.copy(e).sub(this.target),De.applyQuaternion(this._quat),this._spherical.setFromVector3(De),this.autoRotate&&this.state===oe.NONE&&this._rotateLeft(this._getAutoRotationAngle(t)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let i=this.minAzimuthAngle,n=this.maxAzimuthAngle;isFinite(i)&&isFinite(n)&&(i<-Math.PI?i+=oi:i>Math.PI&&(i-=oi),n<-Math.PI?n+=oi:n>Math.PI&&(n-=oi),i<=n?this._spherical.theta=Math.max(i,Math.min(n,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(i+n)/2?Math.max(i,this._spherical.theta):Math.min(n,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let s=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),s=o!=this._spherical.radius}if(De.setFromSpherical(this._spherical),De.applyQuaternion(this._quatInverse),e.copy(this.target).add(De),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const a=De.length();o=this._clampDistance(a*this._scale);const l=a-o;this.object.position.addScaledVector(this._dollyDirection,l),this.object.updateMatrixWorld(),s=!!l}else if(this.object.isOrthographicCamera){const a=new R(this._mouse.x,this._mouse.y,0);a.unproject(this.object);const l=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),s=l!==this.object.zoom;const c=new R(this._mouse.x,this._mouse.y,0);c.unproject(this.object),this.object.position.sub(c).add(a),this.object.updateMatrixWorld(),o=De.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(Pr.origin.copy(this.object.position),Pr.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Pr.direction))<ov?this.object.lookAt(this.target):(Vc.setFromNormalAndCoplanarPoint(this.object.up,this.target),Pr.intersectPlane(Vc,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),s=!0)}return this._scale=1,this._performCursorZoom=!1,s||this._lastPosition.distanceToSquared(this.object.position)>Ho||8*(1-this._lastQuaternion.dot(this.object.quaternion))>Ho||this._lastTargetPosition.distanceToSquared(this.target)>Ho?(this.dispatchEvent(Hc),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(t){return t!==null?oi/60*this.autoRotateSpeed*t:oi/60/60*this.autoRotateSpeed}_getZoomScale(t){const e=Math.abs(t*.01);return Math.pow(.95,this.zoomSpeed*e)}_rotateLeft(t){this._sphericalDelta.theta-=t}_rotateUp(t){this._sphericalDelta.phi-=t}_panLeft(t,e){De.setFromMatrixColumn(e,0),De.multiplyScalar(-t),this._panOffset.add(De)}_panUp(t,e){this.screenSpacePanning===!0?De.setFromMatrixColumn(e,1):(De.setFromMatrixColumn(e,0),De.crossVectors(this.object.up,De)),De.multiplyScalar(t),this._panOffset.add(De)}_pan(t,e){const i=this.domElement;if(this.object.isPerspectiveCamera){const n=this.object.position;De.copy(n).sub(this.target);let s=De.length();s*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*t*s/i.clientHeight,this.object.matrix),this._panUp(2*e*s/i.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(t*(this.object.right-this.object.left)/this.object.zoom/i.clientWidth,this.object.matrix),this._panUp(e*(this.object.top-this.object.bottom)/this.object.zoom/i.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(t,e){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const i=this.domElement.getBoundingClientRect(),n=t-i.left,s=e-i.top,o=i.width,a=i.height;this._mouse.x=n/o*2-1,this._mouse.y=-(s/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(t){return Math.max(this.minDistance,Math.min(this.maxDistance,t))}_handleMouseDownRotate(t){this._rotateStart.set(t.clientX,t.clientY)}_handleMouseDownDolly(t){this._updateZoomParameters(t.clientX,t.clientY),this._dollyStart.set(t.clientX,t.clientY)}_handleMouseDownPan(t){this._panStart.set(t.clientX,t.clientY)}_handleMouseMoveRotate(t){this._rotateEnd.set(t.clientX,t.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(oi*this._rotateDelta.x/e.clientHeight),this._rotateUp(oi*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(t){this._dollyEnd.set(t.clientX,t.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.zoomToCursor&&(this._performCursorZoom=!0,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()),this.update()}_handleMouseMovePan(t){this._panEnd.set(t.clientX,t.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(t){this._updateZoomParameters(t.clientX,t.clientY),t.deltaY<0?this._dollyIn(this._getZoomScale(t.deltaY)):t.deltaY>0&&this._dollyOut(this._getZoomScale(t.deltaY)),this.update()}_handleKeyDown(t){let e=!1;switch(t.code){case this.keys.UP:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(oi*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),e=!0;break;case this.keys.BOTTOM:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(-oi*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),e=!0;break;case this.keys.LEFT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(oi*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),e=!0;break;case this.keys.RIGHT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(-oi*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),e=!0;break}e&&(t.preventDefault(),this.update())}_handleTouchStartRotate(t){if(this._pointers.length===1)this._rotateStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),i=.5*(t.pageX+e.x),n=.5*(t.pageY+e.y);this._rotateStart.set(i,n)}}_handleTouchStartPan(t){if(this._pointers.length===1)this._panStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),i=.5*(t.pageX+e.x),n=.5*(t.pageY+e.y);this._panStart.set(i,n)}}_handleTouchStartDolly(t){const e=this._getSecondPointerPosition(t),i=t.pageX-e.x,n=t.pageY-e.y,s=Math.sqrt(i*i+n*n);this._dollyStart.set(0,s)}_handleTouchStartDollyPan(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enablePan&&this._handleTouchStartPan(t)}_handleTouchStartDollyRotate(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enableRotate&&this._handleTouchStartRotate(t)}_handleTouchMoveRotate(t){if(this._pointers.length==1)this._rotateEnd.set(t.pageX,t.pageY);else{const i=this._getSecondPointerPosition(t),n=.5*(t.pageX+i.x),s=.5*(t.pageY+i.y);this._rotateEnd.set(n,s)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(oi*this._rotateDelta.x/e.clientHeight),this._rotateUp(oi*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(t){if(this._pointers.length===1)this._panEnd.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),i=.5*(t.pageX+e.x),n=.5*(t.pageY+e.y);this._panEnd.set(i,n)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(t){const e=this._getSecondPointerPosition(t),i=t.pageX-e.x,n=t.pageY-e.y,s=Math.sqrt(i*i+n*n);this._dollyEnd.set(0,s),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(t.pageX+e.x)*.5,a=(t.pageY+e.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enablePan&&this._handleTouchMovePan(t)}_handleTouchMoveDollyRotate(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enableRotate&&this._handleTouchMoveRotate(t)}_addPointer(t){this._pointers.push(t.pointerId)}_removePointer(t){delete this._pointerPositions[t.pointerId];for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId){this._pointers.splice(e,1);return}}_isTrackingPointer(t){for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId)return!0;return!1}_trackPointer(t){let e=this._pointerPositions[t.pointerId];e===void 0&&(e=new Q,this._pointerPositions[t.pointerId]=e),e.set(t.pageX,t.pageY)}_getSecondPointerPosition(t){const e=t.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[e]}_customWheelEvent(t){const e=t.deltaMode,i={clientX:t.clientX,clientY:t.clientY,deltaY:t.deltaY};switch(e){case 1:i.deltaY*=16;break;case 2:i.deltaY*=100;break}return t.ctrlKey&&!this._controlActive&&(i.deltaY*=10),i}}function lv(r){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(r.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(r)&&(this._addPointer(r),r.pointerType==="touch"?this._onTouchStart(r):this._onMouseDown(r),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function cv(r){this.enabled!==!1&&(r.pointerType==="touch"?this._onTouchMove(r):this._onMouseMove(r))}function hv(r){switch(this._removePointer(r),this._pointers.length){case 0:this.domElement.releasePointerCapture(r.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(ru),this.state=oe.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:const t=this._pointers[0],e=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:e.x,pageY:e.y});break}}function uv(r){let t;switch(r.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Qn.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(r),this.state=oe.DOLLY;break;case Qn.ROTATE:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=oe.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=oe.ROTATE}break;case Qn.PAN:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=oe.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=oe.PAN}break;default:this.state=oe.NONE}this.state!==oe.NONE&&this.dispatchEvent(fl)}function dv(r){switch(this.state){case oe.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(r);break;case oe.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(r);break;case oe.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(r);break}}function fv(r){this.enabled===!1||this.enableZoom===!1||this.state!==oe.NONE||(r.preventDefault(),this.dispatchEvent(fl),this._handleMouseWheel(this._customWheelEvent(r)),this.dispatchEvent(ru))}function pv(r){this.enabled!==!1&&this._handleKeyDown(r)}function mv(r){switch(this._trackPointer(r),this._pointers.length){case 1:switch(this.touches.ONE){case on.ROTATE:if(this.enableRotate===!1){this.state=oe.NONE;break}this._handleTouchStartRotate(r),this.state=oe.TOUCH_ROTATE;break;case on.PAN:if(this.enablePan===!1){this.state=oe.NONE;break}this._handleTouchStartPan(r),this.state=oe.TOUCH_PAN;break;default:this.state=oe.NONE}break;case 2:switch(this.touches.TWO){case on.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(r),this.state=oe.TOUCH_DOLLY_PAN;break;case on.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(r),this.state=oe.TOUCH_DOLLY_ROTATE;break;default:this.state=oe.NONE}break;default:this.state=oe.NONE}this.state!==oe.NONE&&this.dispatchEvent(fl)}function gv(r){switch(this._trackPointer(r),this.state){case oe.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(r),this.update();break;case oe.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(r),this.update();break;case oe.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(r),this.update();break;case oe.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(r),this.update();break;default:this.state=oe.NONE}}function vv(r){this.enabled!==!1&&r.preventDefault()}function _v(r){r.key==="Control"&&(this._controlActive=!0,this.domElement.ownerDocument.addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function xv(r){r.key==="Control"&&(this._controlActive=!1,this.domElement.ownerDocument.removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const wt={glassRadius:20,glassHeight:30,glassBottomY:14.6,soilRadius:18.6,soilTopAtCenter:.9};function yv(){const t=Te(1024,1024),e=t.getContext("2d"),i=$t(99);e.fillStyle="#4a2f1c",e.fillRect(0,0,1024,1024);for(let n=0;n<26;n++){const s=n/26*1024+i()*20,o=e.createLinearGradient(0,s-30,0,s+30),a=i()>.5;o.addColorStop(0,"rgba(0,0,0,0)"),o.addColorStop(.5,a?"rgba(28,14,6,0.35)":"rgba(120,76,42,0.22)"),o.addColorStop(1,"rgba(0,0,0,0)"),e.fillStyle=o,e.fillRect(0,s-30,1024,60)}for(let n=0;n<90;n++){const s=i()*1024,o=i()*1024,a=20+i()*160,l=.25+i()*.5;e.strokeStyle=`rgba(${20+i()*30},${10+i()*16},${4+i()*8},${.1+i()*.16})`,e.lineWidth=.8+i()*2.2,e.beginPath(),e.ellipse(s,o,a,a*l,i()*.4,0,Math.PI*2),e.stroke(),i()>.7&&(e.beginPath(),e.ellipse(s,o,a*.72,a*.72*l,i()*.4,0,Math.PI*2),e.stroke())}for(let n=0;n<2600;n++){const s=i()*1024,o=i()*1024,a=3+i()*26;e.strokeStyle=`rgba(${i()>.75?150:16},${i()>.75?104:8},${i()>.75?60:3},${.05+i()*.14})`,e.lineWidth=.5+i()*1.1,e.beginPath(),e.moveTo(s,o),e.lineTo(s+a,o+(i()-.5)*3),e.stroke()}for(let n=0;n<5;n++){const s=i()*1024,o=i()*1024;for(let a=2;a<22;a+=2.2)e.strokeStyle=`rgba(18,8,3,${.5-a*.016})`,e.lineWidth=1.4,e.beginPath(),e.ellipse(s,o,a*(1+i()*.3),a*.6,.3,0,Math.PI*2),e.stroke()}return we(t,{repeat:[1,1],aniso:8})}function Mv(){const t=Te(512,512),e=t.getContext("2d");e.fillStyle="#8a8a8a",e.fillRect(0,0,512,512);const i=$t(7);for(let n=0;n<2200;n++){const s=i()*512,o=i()*512,a=60+i()*140;e.fillStyle=`rgba(${a},${a},${a},${.1+i()*.2})`,e.beginPath(),e.arc(s,o,1+i()*7,0,Math.PI*2),e.fill()}for(let n=8;n<300;n+=7)e.strokeStyle=`rgba(${180+i()*40},${180+i()*40},${180+i()*40},0.07)`,e.lineWidth=1,e.beginPath(),e.arc(512/2,512/2,n,0,Math.PI*2),e.stroke();return we(t,{srgb:!1,repeat:[3,1]})}function Sv(){const t=Te(512,512),e=t.getContext("2d"),i=e.createImageData(512,512),n=$t(55),s=new Float32Array(512*512);for(let l=0;l<512*512;l++)s[l]=n();const o=(l,c)=>s[(c+512)%512*512+(l+512)%512];for(let l=0;l<512;l++)for(let c=0;c<512;c++){const h=(o(c+1,l)-o(c-1,l))*5,u=(o(c,l+1)-o(c,l-1))*5,d=(l*512+c)*4;i.data[d]=ft(128+h*90,0,255),i.data[d+1]=ft(128+u*90,0,255),i.data[d+2]=255,i.data[d+3]=255}e.putImageData(i,0,0);for(let l=0;l<40;l++){const c=n()*512,h=n()*512,u=1+n()*3,d=e.createRadialGradient(c,h,0,c,h,u);d.addColorStop(0,"rgba(255,255,255,0.9)"),d.addColorStop(.6,"rgba(140,140,140,0.4)"),d.addColorStop(1,"rgba(128,128,128,0)"),e.fillStyle=d,e.beginPath(),e.arc(c,h,u*2,0,Math.PI*2),e.fill()}return we(t,{srgb:!1,repeat:[2,2]})}function wv(){const r=Te(512,160),t=r.getContext("2d");t.fillStyle="#c9a866",t.fillRect(0,0,512,160);const e=$t(3);for(let i=0;i<5e3;i++)t.fillStyle=`rgba(${e()>.5?255:90},${e()>.5?235:80},${e()>.5?190:60},${e()*.08})`,t.fillRect(e()*512,e()*160,12+e()*40,1);return t.strokeStyle="rgba(70,50,20,0.85)",t.lineWidth=5,t.strokeRect(10,10,492,140),t.fillStyle="rgba(52,38,16,0.95)",t.font="600 54px Georgia, serif",t.textAlign="center",t.textBaseline="middle",t.fillText("VESPERGLASS",256,66),t.font="24px Georgia, serif",t.fillStyle="rgba(62,46,20,0.85)",t.fillText("HORTUS  ·  No. 7  ·  A.D. 1893",256,112),we(r)}function bv(){const r=Te(256,256),t=r.getContext("2d"),e=t.createRadialGradient(128,128,10,128,128,128);e.addColorStop(0,"#efe3c4"),e.addColorStop(.8,"#d6c49a"),e.addColorStop(1,"#9c8656"),t.fillStyle=e,t.beginPath(),t.arc(128,128,126,0,Math.PI*2),t.fill(),t.strokeStyle="rgba(70,52,22,0.8)",t.lineWidth=3;for(let i=0;i<=24;i++){const n=-Math.PI*.75+i/24*Math.PI*1.5,s=i%4===0?96:108;t.beginPath(),t.moveTo(128+Math.cos(n)*s,128+Math.sin(n)*s),t.lineTo(128+Math.cos(n)*120,128+Math.sin(n)*120),t.stroke()}return t.fillStyle="rgba(60,44,18,0.9)",t.font="italic 20px Georgia, serif",t.textAlign="center",t.fillText("HUMID.",128,84),t.font="12px Georgia, serif",t.fillText("DRY",62,160),t.fillText("WET",194,160),we(r)}class Ev{constructor(t,e,i,n="high"){this.scene=t,this.state=e,this.lighting=i,this.quality=n,this.group=new gt,this.group.name="vessel",t.add(this.group),this.walnut=yv(),this.brassRough=Mv(),this.buildPedestal(),this.buildPlinth(),this.buildGlass(),this.buildLid(),this.buildFittings(),this.buildInteriorLight(),this.lidAnim=0,this.lidTarget=0;const s=-20*.985,o=wt.glassBottomY+wt.glassHeight-2.2;this.lidPivot=new gt,this.lidPivot.position.set(s,o,0),this.lidGroup.position.set(-s,-o,0),this.lidPivot.add(this.lidGroup),this.group.add(this.lidPivot)}buildPedestal(){const t=new gt;this.pedestal=t;const e=new st({map:this.walnut,color:14201997,roughness:.5,metalness:0,envMapIntensity:.5}),i=new st({map:this.walnut,color:10255194,roughness:.58,metalness:0,envMapIntensity:.4}),n=[[0,0],[7.6,0],[8.4,.6],[8.6,2],[7.4,3.2],[5.4,4.4],[4.5,5.6],[4.8,7],[6.4,8.4],[6.6,9.6],[5.6,10.6],[4.2,11.6],[4,13],[5,14.2],[7.2,15.6],[8,17],[7.4,18.2],[5.2,19.2],[4.6,20.6],[5.4,22],[7.6,23.4],[8.8,24.8],[9,26],[7.6,27.2],[9.8,28.6],[13.4,29.4],[15.2,30.2],[15.2,31.6],[0,31.6]].map(([E,T])=>new Q(E*1.02,T*.42)),s=new wn(n,64),o=new I(s,e);o.castShadow=!0,o.receiveShadow=!0,t.add(o);const a=new I(new Ft(16.4,16.6,1.4,64),e);a.position.y=13.5,a.castShadow=!0,a.receiveShadow=!0,t.add(a);const l=new I(new We(14.4,.24,8,72),new st({color:13214814,metalness:1,roughness:.32,envMapIntensity:1}));l.rotation.x=Math.PI/2,l.position.y=14.25,t.add(l);const c=new I(new Ft(18,18.4,1.2,64),i);c.position.y=.6,c.castShadow=!0,c.receiveShadow=!0,t.add(c);const h=new st({color:13607247,metalness:1,roughness:.3,roughnessMap:this.brassRough,envMapIntensity:1.1});this.brassMat=h;for(let E=0;E<3;E++){const T=E/3*Math.PI*2+.4,x=new gt,w=new I(new Ft(1.5,.72,4.4,10),i);w.position.y=2.2,w.rotation.z=Math.cos(T)*.16,w.rotation.x=-Math.sin(T)*.16,w.castShadow=!0;const P=new I(new It(.95,12,8,0,Math.PI*2,0,Math.PI/2),h);P.position.y=.2,P.rotation.x=Math.PI,P.castShadow=!0,x.add(w,P),x.position.set(Math.cos(T)*14.5,0,Math.sin(T)*14.5),t.add(x)}const u=new I(new ne(10.4,3.4,.4),new st({map:wv(),color:16777215,metalness:.85,roughness:.36,envMapIntensity:.9}));u.position.set(0,9.4,6),u.rotation.x=-.16,t.add(u);const d=new I(new si(2.6,40),new st({map:bv(),roughness:.5,metalness:.15})),f=new I(new Ft(2.9,2.9,.7,40),h);f.rotation.x=Math.PI/2,d.position.z=.4;const p=new gt;p.add(f,d),p.position.set(5.6,7.4,5.05),p.rotation.y=Math.PI/2-.5,p.rotation.x=-.1,t.add(p);const v=new I(new ne(.16,2,.1),new st({color:2759948,metalness:.6,roughness:.5}));v.position.z=.45,v.position.y=.85,v.geometry.translate(0,.9,0);const m=new gt;m.add(v),m.position.set(5.6+Math.cos(.5)*0,7.4,5.05),p.add(m),m.position.set(0,0,.5),m.rotation.z=0,this.needle=m;const g=new gt,_=new I(new Ft(.14,.14,3.2,6),h);_.rotation.z=Math.PI/2;const M=new I(new We(.55,.14,6,16),h);M.position.x=-1.85;const y=new I(new ne(.5,.9,.12),h);y.position.set(1.5,-.35,0),g.add(_,M,y),g.position.set(4.4,.85,13.4),g.rotation.y=.7,g.children.forEach(E=>E.castShadow=!0),t.add(g),this.pedestalKey=g,this.group.add(t)}buildPlinth(){const t=new gt,e=this.brassMat,i=[[0,0],[17.2,0],[17.6,.18],[17.7,.5],[0,.5]].map(([h,u])=>new Q(h,u+13.82)),n=new I(new wn(i,48),new st({map:this.walnut,color:12886138,roughness:.52}));n.castShadow=!0,n.receiveShadow=!0,t.add(n);const s=new I(new We(19.1,.55,10,64),e);s.rotation.x=Math.PI/2,s.position.y=wt.glassBottomY+.15,s.castShadow=!0,t.add(s);const o=new I(new Ft(18.8,18.8,.7,64,1,!0),e);o.position.y=wt.glassBottomY+.35,t.add(o);const a=new It(.2,6,5),l=new Rs(a,e,12),c=new ue;for(let h=0;h<12;h++){const u=h/12*Math.PI*2;c.position.set(Math.cos(u)*19.1,wt.glassBottomY+.6,Math.sin(u)*19.1),c.updateMatrix(),l.setMatrixAt(h,c.matrix)}t.add(l),this.group.add(t),this.plinth=t}buildGlass(){const t=wt.glassRadius,e=wt.glassHeight,i=wt.glassBottomY,n=[],s=.8;for(let g=0;g<=40;g++){const _=g/40;let M;if(_<s)M=t*(.995+.005*Math.sin(_*Math.PI));else{const y=(_-s)/(1-s);M=t*(1-.075*y*y)}n.push(new Q(M,_*e*.045+_*(e-2.4)))}n.unshift(new Q(t*1.012,0)),n.push(new Q(t*.982,e-2.05)),n.push(new Q(t*.965,e-2.4));const o=new wn(n,96),a=Sv();a.repeat.set(3,2);const l=new Qe({transparent:!0,depthWrite:!1,side:ae,blending:Yi,uniforms:{uSky:{value:new ct("#2b3540")},uSunDir:{value:new R(.4,.8,.2)},uSunColor:{value:new ct("#fff2d8")},uRim:{value:new ct("#cfe6d8")},uTint:{value:new ct("#dfefdf")},uCondensation:{value:0},uTime:{value:0},uFlash:{value:0},uNormalMap:{value:a},uImperfection:{value:1}},vertexShader:`
        varying vec3 vWPos;
        varying vec3 vWNrm;
        varying vec2 vUv;
        void main() {
          vUv = uv;
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWPos = wp.xyz;
          vWNrm = normalize(mat3(modelMatrix) * normal);
          gl_Position = projectionMatrix * viewMatrix * wp;
        }`,fragmentShader:`
        precision highp float;
        uniform vec3 uSunDir, uSunColor, uSky, uRim, uTint;
        uniform float uCondensation, uTime, uFlash;
        uniform sampler2D uNormalMap;
        uniform float uImperfection;
        varying vec3 vWPos; varying vec3 vWNrm; varying vec2 vUv;

        float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
        float noise(vec2 p){
          vec2 i = floor(p), f = fract(p);
          f = f*f*(3.0-2.0*f);
          return mix(mix(hash(i), hash(i+vec2(1.0,0.0)), f.x),
                     mix(hash(i+vec2(0.0,1.0)), hash(i+vec2(1.0,1.0)), f.x), f.y);
        }
        vec3 envColor(vec3 r) {
          float y = clamp(r.y * 0.5 + 0.5, 0.0, 1.0);
          vec3 col = mix(vec3(0.035,0.04,0.05), uSky, pow(y, 1.4));
          col += vec3(0.9,0.72,0.42) * pow(max(0.0, 1.0 - abs(r.y - 0.12) * 6.0), 3.0) * 0.20;
          float a = atan(r.z, r.x);
          float w = pow(max(0.0, cos(a * 2.0 + 0.6)), 24.0) * smoothstep(0.55, 0.05, abs(r.y - 0.08));
          col += vec3(1.0, 0.95, 0.82) * w * 0.45;
          return col;
        }

        void main() {
          vec3 nrm = normalize(vWNrm);
          // The shell is DoubleSide: the far wall is a back face, and its
          // geometric normal points away from us. Without this flip the
          // entire rear of the vessel evaluates at grazing incidence and
          // reads as a solid white wall.
          if (!gl_FrontFacing) nrm = -nrm;
          vec2 nu = texture2D(uNormalMap, vUv * vec2(3.0, 2.0)).xy * 2.0 - 1.0;
          nrm = normalize(nrm + vec3(nu.x, 0.0, nu.y) * 0.05);

          vec3 V = normalize(cameraPosition - vWPos);
          float ndv = clamp(dot(nrm, V), 0.0, 1.0);
          float fres = pow(1.0 - ndv, 5.0);
          float refl = 0.045 + 0.955 * fres;

          float edge = pow(1.0 - ndv, 2.2);
          vec3 body = mix(vec3(0.80, 0.90, 0.84), vec3(0.48, 0.74, 0.55), edge * 0.6);

          vec3 R = reflect(-V, nrm);
          vec3 reflCol = envColor(R);
          float sunSpot = pow(max(dot(R, normalize(uSunDir)), 0.0), 200.0);
          reflCol += uSunColor * sunSpot * 2.2;
          reflCol += uSky * 0.22 * smoothstep(0.0, 0.9, R.y);
          reflCol += vec3(1.0) * uFlash * 1.5;

          // ---- imperfections: a hand-blown pane is never perfect ----
          // panel seams: faint joins where the sheets of glass meet
          float seamU = abs(fract(vUv.x * 12.0 + 0.5) - 0.5) * 12.0;
          float seam = (1.0 - smoothstep(0.0, 0.035, seamU)) * 0.10;
          // micro-scratches: long, low streaks catching the light
          float streak = noise(vec2(vUv.x * 180.0, vUv.y * 4.0));
          float scratch = smoothstep(0.80, 0.92, streak) * 0.10;
          // bubbles: sparse trapped air, drawn as a ring with a catch-light
          vec2 bc = vUv * vec2(60.0, 40.0);
          vec2 cell = floor(bc);
          float bh = hash(cell + 7.3);
          vec2 cen = cell + 0.5 + (vec2(hash(cell + 1.7), hash(cell + 4.1)) - 0.5) * 0.5;
          float bd = length(bc - cen);
          float hasBubble = step(0.986, bh);
          float ring = smoothstep(0.07, 0.0, abs(bd - 0.2)) * hasBubble;
          float catch_ = smoothstep(0.09, 0.0, length(bc - cen - vec2(-0.07, 0.07))) * hasBubble;
          float imp = uImperfection;
          reflCol += vec3(1.0, 0.97, 0.9) * (scratch * 0.8 + catch_ * 0.9 + ring * 0.35) * imp;

          float grain = noise(vUv * vec2(30.0, 22.0) + uTime * 0.02);
          float fog = smoothstep(0.30, 0.80, grain) * uCondensation;
          vec3 fogCol = vec3(0.74, 0.80, 0.78) * (0.55 + 0.45 * ndv);

          vec3 col = mix(body * 0.55, reflCol, clamp(refl * 1.2, 0.0, 0.9));
          col *= 1.0 - seam * imp;
          col += vec3(0.02, 0.025, 0.02) * ring * imp;
          col = mix(col, fogCol, clamp(fog * 0.7, 0.0, 0.8));
          col += uRim * pow(fres, 3.0) * 0.30;

          float alpha = clamp(refl * 1.05 + 0.035, 0.0, 0.78);
          alpha = max(alpha, fog * 0.55);
          alpha += pow(fres, 4.0) * 0.45;
          gl_FragColor = vec4(col, clamp(alpha, 0.02, 0.94));
          #include <colorspace_fragment>
        }`});this.glassMat=l;const c=new I(o,l);c.position.y=i,c.renderOrder=2,this.glass=c,this.group.add(c);const h=new I(new Ft(t*1.012,t*1.02,1.1,96,1,!0),new qs({color:15661041,roughness:.05,metalness:0,transparent:!0,opacity:.3,clearcoat:.6,side:ae,envMapIntensity:1.2,depthWrite:!1}));h.position.y=i+.55,h.renderOrder=2,this.group.add(h),this.footRing=h;const u=new I(new We(t*.985,.34,12,96),this.brassMat);u.rotation.x=Math.PI/2,u.position.y=i+e-2.2,u.castShadow=!0,this.group.add(u),this.mouthRing=u;const d=Te(512,64),f=d.getContext("2d");for(let g=0;g<26;g++){const _=g/26*512;f.strokeStyle="rgba(255,255,255,0.6)",f.lineWidth=1.6,f.beginPath(),f.moveTo(_+8,22),f.lineTo(_+2,32),f.lineTo(_+8,42),f.stroke()}const p=we(d);p.wrapS=En;const v=new li({map:p,transparent:!0,opacity:.14,depthWrite:!1,blending:Ne,side:ae}),m=new I(new Ft(t*.965,t*.975,2.2,96,1,!0),v);m.position.y=i+e*.76,m.renderOrder=3,this.group.add(m)}buildLid(){const t=new gt;this.lidGroup=t;const e=wt.glassRadius*.985,i=wt.glassBottomY+wt.glassHeight-2.2,n=[];for(let d=0;d<=28;d++){const f=d/28,p=e*Math.cos(f*Math.PI*.5)**.72;n.push(new Q(Math.max(.001,p),f*6.2))}const s=new I(new wn(n,96),this.glassMat);s.position.y=i,s.renderOrder=2,t.add(s);const o=new I(new We(e,.36,12,96),this.brassMat);o.rotation.x=Math.PI/2,o.position.y=i,o.castShadow=!0,t.add(o);const a=new I(new Ft(e*1.006,e*1.012,1,96,1,!0),this.brassMat);a.position.y=i-.5,t.add(a);const l=[[0,0],[1.9,.05],[1.5,.55],[.8,1.25],[.72,2.3],[1.1,3],[.9,3.7],[.45,4.35],[.55,4.7],[0,4.9]].map(([d,f])=>new Q(d,f)),c=new I(new wn(l,40),new st({map:this.walnut,color:11570274,roughness:.36,metalness:.04,envMapIntensity:.9}));c.position.y=i+6,c.castShadow=!0,t.add(c);const h=new I(new Ft(1.25,1.55,.5,32),this.brassMat);h.position.y=i+6.05,t.add(h);const u=new I(new It(.72,20,14),this.brassMat);u.position.y=i+11.2,u.castShadow=!0,t.add(u);for(let d=0;d<3;d++){const f=d/3*Math.PI*2+.3,p=new Hs([new R(Math.cos(f)*e*.998,i,Math.sin(f)*e*.998),new R(Math.cos(f)*e*.82,i+2.4,Math.sin(f)*e*.82),new R(Math.cos(f)*e*.46,i+4.9,Math.sin(f)*e*.46),new R(0,i+6,0)]),v=new I(new eo(p,24,.15,6,!1),this.brassMat);v.castShadow=!0,t.add(v)}for(let d=-1;d<=1;d+=2){const f=new I(new Ft(.42,.42,1.5,12),this.brassMat);f.rotation.z=Math.PI/2,f.rotation.y=Math.PI/2,f.position.set(-e*.995,i-.1,d*2.4),t.add(f)}for(let d=0;d<8;d++){const f=d/8*Math.PI*2,p=new I(new Ft(.3,.3,.2,8),this.brassMat);p.position.set(Math.cos(f)*e*.42,i+4.55,Math.sin(f)*e*.42),t.add(p)}this.lidBuildRimY=i}buildFittings(){const t=new gt,e=wt.glassRadius;for(let n=0;n<3;n++){const s=n/3*Math.PI*2+Math.PI*.5+.35,o=new gt,a=new I(new ne(2.4,3.2,.6),new st({color:13607247,metalness:1,roughness:.28,roughnessMap:this.brassRough})),l=new I(new We(.5,.15,5,10,Math.PI),this.brassMat);l.position.set(0,1.5,0),l.rotation.z=0,o.add(a,l),o.position.set(Math.cos(s)*(e+.14),wt.glassBottomY+wt.glassHeight-2.9,Math.sin(s)*(e+.14)),o.rotation.y=-s+Math.PI/2,o.children.forEach(c=>c.castShadow=!0),t.add(o)}const i=new I(new ne(.9,4.4,3.4),this.brassMat);i.position.set(-20.22,wt.glassBottomY+wt.glassHeight-2.4,0),i.castShadow=!0,t.add(i),this.group.add(t),this.fittings=t}buildInteriorLight(){this.lanterns=[];const t=[{x:0,y:wt.glassBottomY+9.5,z:.6,len:11.5,color:16761466,base:.9},{x:4.6,y:wt.glassBottomY+13.6,z:-3.2,len:8,color:16756838,base:.55}],e=new st({color:9071157,metalness:.9,roughness:.42}),i=new qs({color:16773588,emissive:16763012,emissiveIntensity:2.2,roughness:.18,metalness:0,transparent:!0,opacity:.85,transparent:!0,opacity:.92,ior:1.4});this.orbMat=i,t.forEach((n,s)=>{const o=new gt,a=wt.glassBottomY+wt.glassHeight-2.6,l=new I(new Ft(.045,.045,a-n.y,5),e);l.position.y=(a+n.y)/2,o.add(l);const c=new I(new ci(.55,.5,10),e);c.position.y=n.y+.42,o.add(c);const h=new I(new It(.44,18,14),i);h.position.y=n.y-.05,o.add(h);const u=new I(new We(.3,.06,5,14),e);u.rotation.x=Math.PI/2,u.position.y=n.y-.44,o.add(u);const d=new Rh(new nl({map:this.haloTex||(this.haloTex=(()=>{const p=Te(64,64),v=p.getContext("2d"),m=v.createRadialGradient(32,32,1,32,32,32);return m.addColorStop(0,"rgba(255,226,170,0.95)"),m.addColorStop(.4,"rgba(255,196,120,0.28)"),m.addColorStop(1,"rgba(255,180,90,0)"),v.fillStyle=m,v.fillRect(0,0,64,64),we(p)})()),transparent:!0,depthWrite:!1,blending:Ne,color:n.color}));d.position.y=n.y-.05,d.scale.setScalar(4.2),o.add(d);const f=new Zi(n.color,n.base,30,0);f.position.y=n.y-.05,o.add(f),o.position.set(n.x,0,n.z),this.group.add(o),this.lanterns.push({group:o,light:f,halo:d,def:n,phase:s*2.1})}),this.glassFill=new Zi(16773848,.5,40,0),this.glassFill.position.set(1,wt.glassBottomY+7,9),this.scene.add(this.glassFill),this.innerLight=this.glassFill}setShadowQuality(t){const e=t!=="off";this.pedestal.traverse(i=>{i.isMesh&&(i.castShadow=e)})}update(t,e){if(this.glassMat&&this.glassMat.uniforms){const l=this.glassMat.uniforms;l.uCondensation.value=ft(t.condensation*1.15,0,1),l.uTime.value=t.elapsed,l.uFlash.value=t.boltFlash,l.uImperfection&&(l.uImperfection.value=this.quality==="low"?.5:1),t.sunDir&&l.uSunDir.value.copy(t.sunDir),t.sunTint&&l.uSunColor.value.copy(t.sunTint).lerp(new ct("#fff6e0"),.5),t.skyTint&&l.uSky.value.copy(t.skyTint).multiplyScalar(.35),l.uSky.value.lerp(new ct("#0b1220"),t.night*.85)}this.lidAnim=Ee(this.lidAnim,t.lidTarget,2.1,e);const i=this.lidAnim;this.lidPivot.rotation.z=i*1.35,this.lidPivot.rotation.x=Math.sin(i*Math.PI)*.02;const n=t.humidity;this.needle&&(this.needle.rotation.z=Lt(-Math.PI*.72,Math.PI*.72,n));const s=t.night,o=.94+Math.sin(performance.now()*.0023)*.04+Math.sin(performance.now()*.0071)*.02;this.lanterns.forEach((l,c)=>{const h=Lt(.55,1,s)*o*(c===1?.8:1);l.light.intensity=l.def.base*h*(1-ft(i*.3)),l.halo.material.opacity=.16+s*.6,l.halo.scale.setScalar(3.6+s*1.8)}),this.orbMat.emissiveIntensity=Lt(1.1,3.4,s)*o,this.orbMat.emissive.setHex(t.boltFlash>.05?14674687:16763012),this.glassFill.intensity=.42+t.boltFlash*1.4;const a=t.condensation;this.condensationUniform&&(this.condensationUniform.value=a),this.glassMat.roughness=.045+a*.1,this.glassMat.attenuationDistance=Lt(6,2,t.humidity*.5),this.footRing.material.roughness=.04+a*.05}get soilCenterY(){return wt.glassBottomY+wt.soilTopAtCenter}get lidWorldPos(){return new R(0,wt.glassBottomY+wt.glassHeight+12,0)}}const Tv=1.55;class Av{constructor(t,e){this.renderer=t,this.scene=e,this.camera=new fi(38,1,.1,700),this.camera.position.set(70,46,84),this.controls=new av(this.camera,t.domElement);const i=this.controls;i.target.set(0,22,0),i.enableDamping=!0,i.dampingFactor=.06,i.rotateSpeed=.55,i.panSpeed=.6,i.zoomSpeed=.85,i.minDistance=34,i.maxDistance=210,i.minPolarAngle=.18,i.maxPolarAngle=Math.PI*.52,i.enablePan=!0,i.screenSpacePanning=!1,i.touches={ONE:on.ROTATE,TWO:on.DOLLY_PAN},i.autoRotate=!1,this.mode="orbit",this.cinematic=null,this.inside={pos:new R(1.2,wt.glassBottomY+1.9,9.5),yaw:Math.PI,pitch:-.08,vel:new Q,keys:{},walkSpeed:5.2,bob:0},this.eyeTarget=new Q(0,0),this.onModeChange=null,this.reduceMotion=!1,this.raycaster=new Xh,this._bindInsideControls(),this.resize()}resize(){const t=window.innerWidth,e=window.innerHeight;this.camera.aspect=t/e,this.camera.updateProjectionMatrix(),this.renderer.setSize(t,e,!1)}_bindInsideControls(){const t=this.renderer.domElement;let e=!1,i=0,n=0,s=null;t.addEventListener("pointerdown",a=>{this.mode==="inside"&&a.button===0&&(e=!0,s=a.pointerId,i=a.clientX,n=a.clientY)},{capture:!0}),window.addEventListener("pointermove",a=>{if(this.mode!=="inside"||!e||a.pointerId!==s)return;const l=a.clientX-i,c=a.clientY-n;i=a.clientX,n=a.clientY,this.inside.yaw-=l*.0032,this.inside.pitch=ft(this.inside.pitch-c*.0028,-1.1,.9)});const o=a=>{a.pointerId===s&&(e=!1,s=null)};window.addEventListener("pointerup",o),window.addEventListener("pointercancel",o)}goInside(t){if(this.mode==="inside")return;this.mode="cinematic",this.controls.enabled=!1;const e=this.camera.position.clone(),i=this.controls.target.clone(),n=new R(.35,.45,1).normalize();new R(Math.sin(0)*0+n.x*40,28,n.z*42);const s=new R(1.4,wt.glassBottomY+2,11.8),o=new R(0,wt.glassBottomY+wt.glassHeight+3,34),a={v:0};this.cinematic={dur:this.reduceMotion?.9:3,update:l=>{a.v=Math.min(1,a.v+l/this.cinematic.dur);const c=kc(a.v),h=e.clone().lerp(o,c*.85),u=o.clone().lerp(s,Math.max(0,(c-.25)/.75)),d=h.lerp(u,Ie(.15,1,c));this.camera.position.copy(d);const f=i.clone().lerp(new R(0,wt.glassBottomY+4,0),c);this.camera.lookAt(f),a.v>=1&&(this.mode="inside",this.inside.pos.copy(s),this.inside.yaw=Math.PI,this.inside.pitch=-.06,this.cinematic=null,this.controls.enabled=!1,this.onModeChange&&this.onModeChange("inside"),t&&t())}}}goOutside(t){if(this.mode!=="inside")return;this.mode="cinematic",this.controls.enabled=!1;const e=this.camera.position.clone();this.camera.quaternion.clone();const i=new R(70,46,84),n=new R(0,wt.glassBottomY+wt.glassHeight+8,42),s={v:0};this.cinematic={dur:this.reduceMotion?.9:2.6,update:o=>{s.v=Math.min(1,s.v+o/this.cinematic.dur);const a=kc(s.v),l=new R().lerpVectors(e,n,Ie(0,.55,a));l.lerp(i,Ie(.4,1,a)),this.camera.position.copy(l),this.camera.lookAt(new R(0,22,0)),s.v>=1&&(this.mode="orbit",this.cinematic=null,this.controls.target.set(0,22,0),this.camera.position.copy(i),this.controls.enabled=!0,this.onModeChange&&this.onModeChange("orbit"),t&&t())}}}flyTo(t,e,i=2.2){if(this.mode==="inside")return;this.mode="cinematic",this.controls.enabled=!1;const n=this.camera.position.clone(),s=this.controls.target.clone(),o={v:0};this.cinematic={dur:this.reduceMotion?.6:i,update:a=>{o.v=Math.min(1,o.v+a/this.cinematic.dur);const l=nu(o.v);this.camera.position.lerpVectors(n,t,l),this.controls.target.lerpVectors(s,e,l),this.camera.lookAt(this.controls.target),o.v>=1&&(this.mode="orbit",this.controls.enabled=!0,this.cinematic=null,this.onModeChange&&this.onModeChange("orbit"))}}}onKey(t,e){const i=this.inside,n=t.code;e?i.keys[n]=!0:delete i.keys[n]}getInsideCameraState(){const t=this.inside;return{yaw:t.yaw,pitch:t.pitch,pos:t.pos.clone()}}updateInside(t){const e=this.inside,i=e.keys,n=e.walkSpeed*(i.ShiftLeft||i.ShiftRight?1.7:1);let s=0,o=0;(i.KeyW||i.ArrowUp)&&(s+=1),(i.KeyS||i.ArrowDown)&&(s-=1),(i.KeyA||i.ArrowLeft)&&(o-=1),(i.KeyD||i.ArrowRight)&&(o+=1),Math.sin(e.yaw),Math.cos(e.yaw);const a=-Math.sin(e.yaw),l=-Math.cos(e.yaw),c=Math.cos(e.yaw),h=-Math.sin(e.yaw);let u=a*s+c*o,d=l*s+h*o;const f=Math.hypot(u,d);if(f>.001&&(u/=f,d/=f),e.vel.x=Ee(e.vel.x,u*n,8,t),e.vel.y=Ee(e.vel.y,d*n,8,t),this.state){const v=this.state.terrain;if(v){e.pos.x+=e.vel.x*t,e.pos.z+=e.vel.y*t;const m=Math.hypot(e.pos.x,e.pos.z),g=wt.soilRadius-1.2;m>g&&(e.pos.x*=g/m,e.pos.z*=g/m);const _=v.heightAt(e.pos.x,e.pos.z)+Tv;e.pos.y=Ee(e.pos.y,_,7,t);const M=Math.hypot(e.vel.x,e.vel.y)>.4;e.bob+=t*(M?9:2);const y=M?.035:.008;this.camera.position.set(e.pos.x,e.pos.y+Math.sin(e.bob)*y+Math.sin(this.clock||0)*.004,e.pos.z)}}const p=new R(e.pos.x-Math.sin(e.yaw)*Math.cos(e.pitch)*6,e.pos.y+Math.sin(e.pitch)*6,e.pos.z-Math.cos(e.yaw)*Math.cos(e.pitch)*6);this.camera.lookAt(p)}update(t){if(this.clock=(this.clock||0)+t,this.cinematic){this.cinematic.update(t);return}if(this.mode==="inside")this.updateInside(t);else if(this.mode==="orbit"){this.controls.update();const e=this.controls.target;e.x=ft(e.x,-25,25),e.y=ft(e.y,2,46),e.z=ft(e.z,-25,25)}}screenPointToRay(t,e){const i=new Q(t/window.innerWidth*2-1,-(e/window.innerHeight)*2+1);return this.raycaster.setFromCamera(i,this.camera),this.raycaster}}const Ln=r=>new ct(r),Rv=Ln("#ffb37a"),Cv=Ln("#fff3dc"),Pv=Ln("#ff9a5c"),Wc=Ln("#9fb6e6"),Xc=Ln("#c9d8d5"),Lv=Ln("#26324e"),Dv=Ln("#ffd9ad");class Iv{constructor(t,e){this.scene=t,this.renderer=e,this.ambient=new Bo(Xc,2892824,1.05),t.add(this.ambient),this.sun=new ka(16773336,3.4),this.sun.position.set(60,80,40),this.sun.castShadow=!0;const i=this.sun.shadow;i.mapSize.set(1024,1024),i.camera.left=-58,i.camera.right=58,i.camera.top=58,i.camera.bottom=-58,i.camera.near=10,i.camera.far=220,i.bias=-4e-4,i.normalBias=.035,i.radius=3.2,t.add(this.sun),t.add(this.sun.target),this.moon=new ka(Wc,0),this.moon.position.set(-40,60,-30),this.moon.castShadow=!1,t.add(this.moon),t.add(this.moon.target),this.innerKey=new Zi(16767392,0,26,0),this.innerKey.position.set(4,14,6),t.add(this.innerKey),this.lampFill=new Zi(16761968,0,40,0),this.lampFill.position.set(0,12,0),t.add(this.lampFill),this.roomFill=new Bo(7306378,1183498,.25),t.add(this.roomFill),this.paneLight=new za(16773327,0,120,.7,.75,0),this.paneLight.position.set(14,78,22),this.paneLight.target.position.set(0,16,0),this.paneLight.castShadow=!1,t.add(this.paneLight,this.paneLight.target),this.skylight=new za(14477823,0,130,1.05,1,0),this.skylight.position.set(0,86,2),this.skylight.target.position.set(0,16,0),this.skylight.castShadow=!1,t.add(this.skylight,this.skylight.target),this.bounce=new Bo(7035452,1712149,0),t.add(this.bounce),this.skyCol=new ct,this.tmp=new ct,this.buildEnvironment(),this.dirFog=new ct("#0d120e"),this.caustic={uCaustic:{value:0},uCausticOffset:{value:new Q(0,0)},uCausticScale:{value:1}},this.beam={pos:new Q(0,0),radius:{value:9},strength:{value:0}}}buildEnvironment(){const t=new Ys(this.renderer),e=new $r,i=new It(60,32,16),n=new Qe({side:Je,uniforms:{top:{value:new ct("#dfe9df")},bottom:{value:new ct("#4c4632")},sunDir:{value:new R(.5,.8,.4).normalize()},warm:{value:1}},vertexShader:`
        varying vec3 vDir;
        void main() {
          vDir = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,fragmentShader:`
        varying vec3 vDir;
        uniform vec3 top; uniform vec3 bottom; uniform vec3 sunDir; uniform float warm;
        void main() {
          float h = clamp(vDir.y * 0.5 + 0.5, 0.0, 1.0);
          vec3 col = mix(bottom, top, pow(h, 0.85));
          float s = pow(max(dot(normalize(vDir), normalize(sunDir)), 0.0), 90.0);
          col += vec3(1.0, 0.82, 0.55) * s * 7.0 * warm;
          float band = pow(max(0.0, 1.0 - abs(vDir.y - 0.06) * 7.0), 3.0);
          col += vec3(0.35, 0.4, 0.3) * band * 0.5;
          gl_FragColor = vec4(col, 1.0);
        }`});e.add(new I(i,n));const s=new li({color:16774362,side:ae});for(let a=0;a<4;a++){const l=new I(new be(6,14),s),c=a/4*Math.PI*2+.5;l.position.set(Math.cos(c)*34,10,Math.sin(c)*34),l.lookAt(0,10,0),e.add(l)}const o=t.fromScene(e,.02,.1,200);this.envMap=o.texture,this.scene.environment=this.envMap,this.scene.environmentIntensity=.5,this.roomScene=e,this.roomSkyMat=n,i.dispose(),s.dispose(),t.dispose()}setShadowQuality(t){t==="off"?this.sun.castShadow=!1:t==="low"?(this.sun.castShadow=!0,this.sun.shadow.mapSize.set(512,512),this.sun.shadow.map&&(this.sun.shadow.map.dispose(),this.sun.shadow.map=null),this.sun.shadow.radius=2):(this.sun.castShadow=!0,this.sun.shadow.mapSize.set(1024,1024),this.sun.shadow.map&&(this.sun.shadow.map.dispose(),this.sun.shadow.map=null),this.sun.shadow.radius=3.2)}update(t,e,i){const n=t.time,s=t.sunAlt,o=t.night,a=t.w.cloud,l=t.w.fog,c=t.w.sun,h=t.sunAz,u=Math.max(-.4,s),d=90,f=Math.cos(h)*Math.cos(u)*d,p=Math.sin(u)*d,v=Math.sin(h)*Math.cos(u)*d+14;this.sun.position.set(f,Math.max(2,p),v),this.sun.target.position.set(0,3,0),this.moon.position.set(-f*.9,Math.max(6,-p*.8+30),-v*.7),this.moon.target.position.set(0,3,0);const m=t.golden,g=this.tmp.copy(Cv).lerp(Rv,ft(m*1.15));n>12&&g.lerp(Pv,ft(m*1)),g.lerp(Wc,o*.92),this.sun.color.copy(g),this.sun.intensity=Lt(3.6,.3,o)*c*Lt(1,.55,a),this.moon.intensity=o*.42*(1-a*.55),this.moon.visible=o>.02;const M=this.tmp.copy(Xc).lerp(Dv,m*.75).clone().lerp(Lv,o);this.ambient.color.copy(M),this.ambient.groundColor.set(o>.5?1119502:3483674),this.ambient.intensity=Lt(1.12,.34,o)*Lt(1,.82,a),this.innerKey.intensity=Lt(.18,.9,o)*(.8+t.w.rain*.2),this.innerKey.color.setHex(16763274),this.lampFill.intensity=o*.7+t.condensation*.1,this.roomFill.intensity=Lt(.32,.1,o);const y=t.boltFlash;y>.01?(this.innerKey.color.setHex(13952255),this.innerKey.intensity+=y*26,this.ambient.intensity+=y*2.4,this.sun.intensity+=y*2):this.innerKey.color.setHex(16763274),this.scene.environmentIntensity=Lt(.75,.18,o),this.skyTint=new ct("#f0d7ae").lerp(new ct("#ff9c6b"),m*.8).lerp(new ct("#1c2842"),o).lerp(new ct("#7d8a86"),a*.45).lerp(new ct("#cfd6cc"),l*.3);const E=ft(1-o*1.15),T=1-a*.82,x=1-l*.7,w=Math.cos(h),P=Math.sin(h),C=ft(s,.05,1),U=62;this.paneLight.position.set(w*U*(1.1-C*.5),46+C*34,P*U*(1.1-C*.5)+8),this.paneLight.target.position.set(w*-3,16,P*-3+2),this.paneLight.intensity=E*T*x*Lt(2.2,6.4,ft(s)),this.paneLight.angle=Lt(.92,.58,ft(s*1.2)),this.paneLight.color.copy(g).lerp(new ct("#fff4dd"),.35);const B=ft(w*-11*(1-C*.45),-13,13),V=ft(P*-11*(1-C*.45)+2,-13,13);this.beam.pos.set(B,V),this.beam.radius.value=Lt(11.5,7,ft(s)),this.beam.strength.value=E*T*x*ft(s*1.25+.18);const D=Lt(.35,1,ft(s*1.4));this.skylight.intensity=(.55+E*2.35*D)*Lt(1,.62,a)*Lt(1,.8,l),this.skylight.color.copy(new ct("#cfe0ff")).lerp(g,.35*E),this.bounce.intensity=E*.62+o*.06,this.caustic.uCaustic.value=E*T*x*ft(s*1.6+.12),this.caustic.uCausticOffset.value.x=this.beam.pos.x*.12+t.elapsed*.05,this.caustic.uCausticOffset.value.y=this.beam.pos.y*.12+t.elapsed*.037,this.caustic.uCausticScale.value=Lt(1.35,.95,ft(s)),this.goldenF=m,this.nightF=o,this.flashF=y,this.daynessF=E}}class Nv{constructor(t,e,i){this.scene=t,this.state=i,this.renderer=e,this.group=new gt,this.group.name="study",t.add(this.group),this.buildFloor(),this.buildBackdrop(),this.buildWindow(),this.buildShafts(),this.buildDust(),this.buildRimObjects(),this.buildCeiling(),this.buildKeyLight(),this.time=0}buildFloor(){const e=Te(512,512),i=e.getContext("2d");i.fillStyle="#171310",i.fillRect(0,0,512,512);const n=$t(11),s=512/6;for(let p=0;p<6;p++){const v=p*s,m=20+n()*16;i.fillStyle=`rgb(${m+12},${m+6},${m-2})`,i.fillRect(0,v,512,s-1);for(let _=0;_<70;_++){const M=v+n()*s;i.strokeStyle=`rgba(${n()>.5?60:8},${n()>.5?44:6},${n()>.5?26:4},${.05+n()*.12})`,i.lineWidth=.6+n()*1.6,i.beginPath();const y=n()*512,E=60+n()*220;i.moveTo(y,M),i.bezierCurveTo(y+E*.3,M+(n()-.5)*4,y+E*.7,M+(n()-.5)*4,y+E,M+(n()-.5)*3),i.stroke()}i.fillStyle="rgba(0,0,0,0.55)",i.fillRect(0,v+s-2,512,2);const g=n()*512;i.fillRect(g,v,2,s)}const o=i.createRadialGradient(512/2,512/2,40,512/2,512/2,512*.7);o.addColorStop(0,"rgba(0,0,0,0)"),o.addColorStop(1,"rgba(0,0,0,0.6)"),i.fillStyle=o,i.fillRect(0,0,512,512);const a=we(e,{repeat:[3,3],aniso:8}),l=new st({map:a,color:9075302,roughness:.82,metalness:.05,envMapIntensity:.15}),c=new I(new be(220,220),l);c.rotation.x=-Math.PI/2,c.receiveShadow=!0,this.floor=c,this.group.add(c);const h=Te(256,256),u=h.getContext("2d");u.fillStyle="#22180f",u.fillRect(0,0,256,256);const d=$t(4);for(let p=0;p<5;p++)u.strokeStyle=`rgba(${90+p*14},${52+p*8},${30+p*6},0.35)`,u.lineWidth=2+d()*3,u.beginPath(),u.arc(128,128,30+p*20,0,Math.PI*2),u.stroke();for(let p=0;p<900;p++)u.fillStyle=`rgba(${d()*60},${d()*40},${d()*25},0.2)`,u.fillRect(d()*256,d()*256,2,2);const f=new I(new si(34,48),new st({map:we(h),color:10061943,roughness:.95,metalness:0}));f.rotation.x=-Math.PI/2,f.position.y=.02,f.receiveShadow=!0,this.group.add(f)}buildBackdrop(){const i=Te(2048,1024),n=i.getContext("2d"),s=n.createLinearGradient(0,0,0,1024);s.addColorStop(0,"#05060a"),s.addColorStop(.45,"#080a09"),s.addColorStop(.75,"#0c0e0a"),s.addColorStop(1,"#080907"),n.fillStyle=s,n.fillRect(0,0,2048,1024);const o=$t(23);for(let u=0;u<46;u++){const d=o()*2048,f=10+o()*54,p=210+o()*180,v=1024-p,m=12+o()*14,g=n.createLinearGradient(d,p,d,p+v);g.addColorStop(0,`rgba(${m+8},${m+5},${m},0.85)`),g.addColorStop(1,`rgba(${m-4},${m-4},${m-5},0.6)`),n.fillStyle=g,n.fillRect(d,p,f,v)}for(let u=0;u<5;u++){const d=260+u*150;n.fillStyle="rgba(0,0,0,0.55)",n.fillRect(0,d,2048,7),n.fillStyle="rgba(70,58,40,0.10)",n.fillRect(0,d+7,2048,3)}for(let u=0;u<9;u++){const d=o()*2048,f=300+o()*520,p=90+o()*200,v=n.createRadialGradient(d,f,0,d,f,p),m=o()>.35;v.addColorStop(0,m?"rgba(255,196,108,0.20)":"rgba(120,160,150,0.10)"),v.addColorStop(.5,m?"rgba(255,170,90,0.06)":"rgba(100,140,130,0.03)"),v.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=v,n.fillRect(d-p,f-p,p*2,p*2)}n.strokeStyle="rgba(6,7,5,0.9)";for(let u=0;u<14;u++){const d=o()*2048,f=120+o()*140;n.lineWidth=1.5+o()*2.5,n.beginPath(),n.moveTo(d,f);const p=70+o()*190;n.quadraticCurveTo(d+(o()-.5)*40,f+p*.6,d+(o()-.5)*70,f+p),n.stroke();for(let v=0;v<5;v++){n.beginPath(),n.lineWidth=.8;const m=v/5;n.moveTo(d+(o()-.5)*20,f+p*m),n.lineTo(d+(o()-.5)*60,f+p*(m+.15)),n.stroke()}}const a=Te(2048,1024);a.getContext("2d").drawImage(i,0,0),n.clearRect(0,0,2048,1024),n.filter="blur(6px)",n.drawImage(a,0,0),n.filter="none";const l=n.createRadialGradient(2048/2,1024*.55,1024*.2,2048/2,1024*.55,2048*.62);l.addColorStop(0,"rgba(0,0,0,0)"),l.addColorStop(1,"rgba(0,0,0,0.82)"),n.fillStyle=l,n.fillRect(0,0,2048,1024);const c=we(i);c.mapping=Nr;const h=new I(new It(170,48,24),new li({map:c,side:Je,depthWrite:!1,fog:!1}));h.rotation.y=Math.PI*.2,this.scene.add(h),this.backdrop=h}buildWindow(){const t=new gt;new li({color:13623551,transparent:!0,opacity:0,depthWrite:!1,blending:Ne});const e=Te(256,256),i=e.getContext("2d"),n=i.createRadialGradient(128,128,10,128,128,128);n.addColorStop(0,"rgba(255,244,214,1)"),n.addColorStop(.5,"rgba(255,226,170,0.4)"),n.addColorStop(1,"rgba(255,220,160,0)"),i.fillStyle=n,i.fillRect(0,0,256,256);const s=new li({map:we(e),transparent:!0,opacity:.5,blending:Ne,depthWrite:!1,fog:!1}),o=new I(new be(58,78),s);o.position.set(-52,26,-66),o.lookAt(0,16,0),this.windowGlow=o,this.group.add(o);const a=new st({color:854793,roughness:.95}),l=(u,d,f,p)=>{const v=new I(new ne(u,d,1.2),a);v.position.set(f,p,0),t.add(v)};l(46,1.4,0,0),l(46,1.4,0,54),l(1.4,54,-23,27),l(1.4,54,23,27),l(1.1,52,0,27),l(44,1.1,0,27),t.position.set(-52,4,-66),t.lookAt(0,16,0),this.group.add(t),this.windowFrame=t;const c=new li({color:658184}),h=new gt;for(let u=0;u<7;u++){const d=new I(new be(2.2+Math.random()*2.4,1.1),c);d.position.set((Math.random()-.5)*9,Math.random()*10,0),d.rotation.z=Math.random()*Math.PI,h.add(d)}h.position.set(-52,26,-64.5),h.lookAt(0,16,0),this.group.add(h),this.windowBranch=h}buildShafts(){this.shafts=new gt;const t=`
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,e=`
      varying vec2 vUv;
      uniform vec3 color; uniform float opacity; uniform float time;
      void main() {
        float edge = smoothstep(0.0, 0.22, vUv.x) * smoothstep(1.0, 0.78, vUv.x);
        float len = smoothstep(0.0, 0.12, vUv.y) * smoothstep(1.0, 0.55, vUv.y);
        float flick = 0.9 + 0.1 * sin(time * 0.5 + vUv.y * 6.0);
        float a = edge * len * opacity * flick;
        gl_FragColor = vec4(color, a);
      }`;for(let i=0;i<3;i++){const n=new Qe({transparent:!0,depthWrite:!1,blending:Ne,side:ae,uniforms:{color:{value:new ct("#ffdfae")},opacity:{value:.05},time:{value:0}},vertexShader:t,fragmentShader:e}),s=new be(7+i*5,66),o=new I(s,n);o.position.set(-30+i*12,28,-30+i*5),o.rotation.set(.5,-.5+i*.12,.42),this.shafts.add(o),o.userData.mat=n}this.group.add(this.shafts)}buildDust(){const e=new de,i=new Float32Array(700*3),n=new Float32Array(700),s=$t(31);for(let a=0;a<700;a++)i[a*3+0]=(s()-.5)*120,i[a*3+1]=s()*55,i[a*3+2]=(s()-.5)*110-10,n[a]=s();e.setAttribute("position",new ee(i,3)),e.setAttribute("aSeed",new ee(n,1));const o=new Qe({transparent:!0,depthWrite:!1,blending:Ne,uniforms:{uTime:{value:0},uMap:{value:new ol(rn(64))},uOpacity:{value:.5},uWarm:{value:new ct("#ffe6b8")},uScale:{value:typeof window<"u"?window.devicePixelRatio:1.5}},vertexShader:`
        attribute float aSeed;
        varying float vA;
        uniform float uTime; uniform float uScale;
        void main() {
          vec3 p = position;
          float s = aSeed * 6.2831;
          p.x += sin(uTime * (0.05 + aSeed * 0.06) + s) * 2.4;
          p.y += sin(uTime * (0.03 + aSeed * 0.04) + s * 2.0) * 1.4 + mod(uTime * (0.1 + aSeed * 0.25), 4.0);
          p.z += cos(uTime * (0.04 + aSeed * 0.05) + s) * 2.0;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = (0.7 + aSeed * 1.8) * uScale * (60.0 / -mv.z);
          vA = smoothstep(0.0, 8.0, -mv.z) * (0.25 + aSeed * 0.75);
        }`,fragmentShader:`
        varying float vA; uniform sampler2D uMap; uniform float uOpacity; uniform vec3 uWarm;
        void main() {
          vec4 t = texture2D(uMap, gl_PointCoord);
          gl_FragColor = vec4(uWarm, t.a * vA * uOpacity * 0.55);
        }`});this.dust=new Gs(e,o),this.dust.frustumCulled=!1,this.group.add(this.dust)}buildRimObjects(){const t=$t(77),e=new gt,n=[3811868,2765350,3351583,2369582].map(d=>new st({color:d,roughness:.85}));let s=0;for(let d=0;d<4;d++){const f=7+t()*3,p=.9+t()*.7,v=5+t()*2,m=new I(new ne(f,p,v),n[d%4]);m.position.set(-46+t()*2,s+p/2,30+t()*3),m.rotation.y=t()*.5-.25,m.castShadow=!0,m.receiveShadow=!0,e.add(m),s+=p}const o=new I(new Ft(.16,.24,20,6),new st({color:9071162,metalness:.9,roughness:.34}));o.position.set(-49,8,27.5),o.rotation.z=.9,o.castShadow=!0,e.add(o);const a=new qs({color:14214880,roughness:.06,metalness:0,transparent:!0,opacity:.22,thickness:.6,ior:1.5,transparent:!0,opacity:1,attenuationColor:new ct("#9fb8a0"),attenuationDistance:.6});[[46,26,3.4],[52,33,2.9],[41,35,3.1]].forEach(([d,f,p],v)=>{const m=new gt,g=new I(new Ft(p,p,p*1.7,20,1,!0),a);g.position.y=p*.85;const _=new I(new Ft(p*.7,p*.72,.8,20),new st({color:7033384,metalness:.7,roughness:.4}));_.position.y=p*1.7+.4,m.add(g,_);const M=new I(new Ks(p*.42,1),new st({color:v===1?5926463:4870976,roughness:1,flatShading:!0}));M.position.y=p*.5,M.castShadow=!0,m.add(M),m.position.set(d,0,f),e.add(m)});const c=new I(new Ft(2.2,3.2,9,12),new st({color:3943712,roughness:.6,metalness:.05}));c.position.set(58,4.5,-10),c.castShadow=!0,e.add(c);const h=new st({color:2892824,roughness:.95,flatShading:!0});for(let d=0;d<5;d++){const f=16+t()*20,p=new I(new Ft(.06,.22,f,5),h);p.position.set(58+(t()-.5)*3,9+f/2,-10+(t()-.5)*3),p.rotation.set((t()-.5)*.4,0,(t()-.5)*.5),p.castShadow=!0,e.add(p)}const u=new I(new ne(9,.5,3),new st({color:9400637,metalness:.85,roughness:.38}));u.position.set(0,.25,52),u.rotation.y=.06,u.receiveShadow=!0,e.add(u),this.group.add(e)}buildKeyLight(){const t=new za(16767400,3.2,260,.78,.9,0);t.position.set(-70,96,62),t.target.position.set(0,20,0),t.castShadow=!1,this.group.add(t,t.target),this.keyLight=t;const e=new ka(10467016,.55);e.position.set(60,40,-90),this.group.add(e),this.rimLight=e}buildCeiling(){const t=new I(new be(240,240),new st({color:658185,roughness:1,metalness:0,side:ae}));t.rotation.x=Math.PI/2,t.position.y=82,this.group.add(t)}buildCurtains(){}update(t,e,i){this.time+=i;const n=t.night,s=t.golden,o=t.w.cloud,a=new ct("#ffe7b8").lerp(new ct("#ff9c62"),s*.9).lerp(new ct("#7e93c4"),n*.95).lerp(new ct("#88938c"),o*.4);this.windowGlow.material.color.copy(a),this.windowGlow.material.opacity=Lt(.32,.1,n)*Lt(1,.55,o)*Lt(1,1.3,t.w.fog*.4),this.windowGlow.material.opacity+=t.boltFlash*1.8,this.keyLight&&(this.keyLight.intensity=Lt(5.2,1.6,n)*Lt(1,.65,o)),this.rimLight&&(this.rimLight.intensity=Lt(.25,.85,n)),this.shafts.children.forEach((c,h)=>{const u=c.userData.mat;u.uniforms.time.value=this.time,u.uniforms.color.value.copy(a),u.uniforms.opacity.value=(Lt(.035,.008,n)+s*.03)*Lt(1,.4,o)*(.8+Math.sin(this.time*.2+h)*.2)+t.boltFlash*.25});const l=this.dust.material;l.uniforms.uTime.value=this.time,l.uniforms.uWarm.value.copy(a),l.uniforms.uOpacity.value=Lt(.4,.22,n)*Lt(1,.7,o),this.curtain&&(this.curtain.rotation.y=.4+Math.sin(this.time*.05)*.01)}}const di=18.4,Uv=108,Li={hill:new Q(-7.6,-7.2),pond:new Q(7,6.8),spring:new Q(-6.4,-6.2)};class Fv{constructor(t,e,i={}){this.scene=t,this.state=e,this.group=new gt,this.group.position.y=wt.glassBottomY+.32,t.add(this.group),this.n=Uv,this.size=di*2,this.heights=new Float32Array(this.n*this.n),this.wetness=new Float32Array(this.n*this.n),this.moss=new Float32Array(this.n*this.n),this.rng=$t(1234),this.dirtyColor=!0,this.patches=[],this.blightPatches=[],this.userScale=i.quality==="low"?.7:1,this.buildHeightField(),this.buildSoilMesh(),this.buildWater(),this.buildRocks(),this.buildPathStones(),this.buildSpringPool(),this.buildFallenLog(),this.buildRingMarkers(),this.buildBlightPatches(),this.buildPlantPatches()}baseHeight(t,e){const i=Li.hill,n=Math.hypot(t-i.x,e-i.y);let s=.35;s+=3.4*Math.exp(-(n*n)/(2*5.6*5.6));const o=Math.hypot(t+3.2,e-10.2);s+=1.3*Math.exp(-(o*o)/(2*4.4*4.4));const a=Math.hypot(t-11.4,e+6.4);s+=1.1*Math.exp(-(a*a)/32);const l=Math.hypot(t-Li.pond.x,e-Li.pond.y);s-=1.75*Math.exp(-(l*l)/(2*4.3*4.3)),s-=this.streamCarve(t,e),s+=(jn(t*.28+10,e*.28+4,4)-.5)*.55,s+=(su(t*1.1,e*1.1)-.5)*.12;const c=Math.hypot(t,e),h=Ie(di*.78,di*.99,c);s+=h*.55;const u=Math.hypot(t-Li.spring.x,e-Li.spring.y);return s+=.55*Math.exp(-(u*u)/(2*3.2*3.2)),s}streamCurve(){if(this._streamCurve)return this._streamCurve;const t=[new R(-6.6,0,-6.3),new R(-4.9,0,-4.6),new R(-3.1,0,-3.4),new R(-1.4,0,-2.3),new R(.4,0,-.4),new R(2.1,0,1.5),new R(4.2,0,3.6),new R(6.9,0,6.7)];return this._streamCurve=new Hs(t,!1,"catmullrom",.5),this._streamSamples=this._streamCurve.getPoints(120),this._streamCurve}streamCarve(t,e){const i=this._streamSamples||(this.streamCurve(),this._streamSamples);let n=1e9;for(let u=0;u<i.length;u+=2){const d=i[u],f=(d.x-t)**2+(d.z-e)**2;f<n&&(n=f)}const s=Math.sqrt(n);let a=(1-Ie(0,1.5*2.4,s))*.5;const l=t-Li.spring.x,c=e-Li.spring.y,h=Math.hypot(l,c);return h<3.2&&(a*=Ie(1,2.6,h)*.7+.3*Ie(.5,2.2,h)),a}buildHeightField(){const t=this.n;for(let e=0;e<t;e++)for(let i=0;i<t;i++){const n=i/(t-1),s=e/(t-1),o=(n-.5)*this.size,a=(s-.5)*this.size,l=Math.hypot(o,a);let c=this.baseHeight(o,a);c=Lt(c,.1,Ie(di*.94,di*1.06,l)),this.heights[e*t+i]=c}}heightAt(t,e){const i=this.n,n=ft(t/this.size+.5,0,.999),s=ft(e/this.size+.5,0,.999),o=n*(i-1),a=s*(i-1),l=Math.floor(o),c=Math.floor(a),h=Math.min(i-1,l+1),u=Math.min(i-1,c+1),d=o-l,f=a-c,p=this.heights[c*i+l],v=this.heights[c*i+h],m=this.heights[u*i+l],g=this.heights[u*i+h];return Lt(Lt(p,v,d),Lt(m,g,d),f)}wetnessAt(t,e){const i=this.n,n=ft(t/this.size+.5,0,.999),s=ft(e/this.size+.5,0,.999),o=Math.round(n*(i-1)),a=Math.round(s*(i-1));return this.wetness[a*i+o]}buildSoilMesh(){const t=this.n,e=new de,i=new Float32Array(t*t*3),n=new Float32Array(t*t*3),s=new Float32Array(t*t*2),o=[];for(let p=0;p<t;p++)for(let v=0;v<t;v++){const m=p*t+v,g=v/(t-1),_=p/(t-1),M=(g-.5)*this.size,y=(_-.5)*this.size;i[m*3]=M,i[m*3+1]=this.heights[m],i[m*3+2]=y,s[m*2]=g,s[m*2+1]=_}for(let p=0;p<t-1;p++)for(let v=0;v<t-1;v++){const m=p*t+v,g=m+1,_=m+t,M=_+1;o.push(m,_,g,g,_,M)}e.setAttribute("position",new ee(i,3)),e.setAttribute("color",new ee(n,3)),e.setAttribute("uv",new ee(s,2)),e.setIndex(o),e.computeVertexNormals();const a=512,l=Te(a,a),c=l.getContext("2d"),h=$t(8);c.fillStyle="#3a2b1d",c.fillRect(0,0,a,a);for(let p=0;p<9e3;p++){const v=h();c.fillStyle=v>.85?`rgba(${70+h()*40},${58+h()*30},${40+h()*20},0.6)`:`rgba(${22+h()*26},${16+h()*18},${10+h()*12},0.55)`;const m=1+h()*4.5;c.beginPath(),c.arc(h()*a,h()*a,m,0,Math.PI*2),c.fill()}for(let p=0;p<700;p++){c.strokeStyle=`rgba(${60+h()*30},${50+h()*30},${34+h()*16},0.25)`,c.lineWidth=.5,c.beginPath();const v=h()*a,m=h()*a;c.moveTo(v,m),c.lineTo(v+(h()-.5)*18,m+(h()-.5)*18),c.stroke()}this.soilTex=we(l,{repeat:[5,5],aniso:8});const u=new st({map:this.soilTex,vertexColors:!0,color:16777215,roughness:.96,metalness:0,envMapIntensity:.25});u.userData.uniforms={uSnow:{value:0},uWet:{value:0},uCaustic:{value:0},uCausticOffset:{value:new Q(0,0)},uCausticScale:{value:1},uBeamPos:{value:new Q(0,0)},uBeamRadius:{value:9},uBeamStrength:{value:0}},u.onBeforeCompile=p=>{Object.assign(p.uniforms,u.userData.uniforms),this._soilShader=p,p.vertexShader=p.vertexShader.replace("#include <common>",`#include <common>
          attribute float aWet;
          varying float vWet;
          varying float vUp;
          varying vec3 vWorldPos;`).replace("#include <begin_vertex>",`#include <begin_vertex>
          vWet = aWet;
          vUp = normalize(objectNormal).y;
          vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),p.fragmentShader=p.fragmentShader.replace("#include <common>",`#include <common>
          uniform float uSnow; uniform float uWet;
          uniform float uCaustic; uniform vec2 uCausticOffset; uniform float uCausticScale;
          uniform vec2 uBeamPos; uniform float uBeamRadius; uniform float uBeamStrength;
          varying float vWet; varying float vUp; varying vec3 vWorldPos;

          // cheap 2-layer voronoi-ish caustic; bright web of light on the soil
          float causticPattern(vec2 p) {
            vec2 i = floor(p), f = fract(p);
            float md = 8.0, md2 = 8.0;
            for (int y = -1; y <= 1; y++) {
              for (int x = -1; x <= 1; x++) {
                vec2 g = vec2(float(x), float(y));
                vec2 o = fract(vec2(sin(dot(i + g, vec2(12.9898, 78.233))) * 43758.5453,
                                   sin(dot(i + g, vec2(39.3468, 11.1351))) * 24634.6345));
                vec2 r = g + o - f;
                float d = dot(r, r);
                if (d < md) { md2 = md; md = d; }
                else if (d < md2) { md2 = d; }
              }
            }
            return sqrt(md2) - sqrt(md);
          }`).replace("#include <color_fragment>",`#include <color_fragment>
          float wet = clamp(vWet * 1.4 + uWet, 0.0, 1.0);
          diffuseColor.rgb *= mix(1.0, 0.55, wet);
          float snow = clamp(uSnow * smoothstep(0.25, 0.85, vUp), 0.0, 1.0);
          diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.86, 0.9, 0.94), snow * 0.85);`).replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
          roughnessFactor = mix(roughnessFactor, 0.55, clamp(vWet,0.0,1.0) * 0.7);
          roughnessFactor = mix(roughnessFactor, 0.95, clamp(uSnow,0.0,1.0));`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
          {
            vec2 cp = vWorldPos.xz * uCausticScale * 0.42 + uCausticOffset;
            float c1 = causticPattern(cp);
            float c2 = causticPattern(cp * 1.9 + vec2(3.7, 1.3));
            // shallow-water caustic filaments
            float web = smoothstep(0.055, 0.0, c1) * 0.55 + smoothstep(0.05, 0.0, c2) * 0.30;
            // the patch of bed the beam lands on
            float d = distance(vWorldPos.xz, uBeamPos);
            float foot = smoothstep(uBeamRadius, uBeamRadius * 0.15, d);
            // keep it under a candle's worth of extra light; it should read
            // as a highlight, not as a second lamp
            float ca = clamp(web, 0.0, 1.0) * uCaustic * foot;
            totalEmissiveRadiance += vec3(1.0, 0.90, 0.70) * ca * 0.16;
            // and lift the diffuse under the beam so the lit side reads warm
            diffuseColor.rgb *= 1.0 + foot * uBeamStrength * 0.30;
          }`)},this.soilMat=u;const d=new I(e,u);d.castShadow=!1,d.receiveShadow=!0,d.name="soil",this.soilMesh=d,this.group.add(d);const f=new Float32Array(t*t);e.setAttribute("aWet",new ee(f,1)),this.wetAttr=e.attributes.aWet,this.wetVerts=f,this.updateSoilColors()}syncCaustic(t){if(!this.soilMat||!t)return;const e=this.soilMat.userData.uniforms;e.uCaustic.value=t.caustic.uCaustic.value,e.uCausticOffset.value.copy(t.caustic.uCausticOffset.value),e.uCausticScale.value=t.caustic.uCausticScale.value,e.uBeamPos.value.copy(t.beam.pos),e.uBeamRadius.value=t.beam.radius.value,e.uBeamStrength.value=t.beam.strength.value}hydro(t,e){const i=this.n,n=this.wetness,s=e.w.rain,o=e.lidOpen,a=1-o*.92;if(s>.02){const g=s*t*1.15*a;for(let _=0;_<i;_++)for(let M=0;M<i;M++){const y=_*i+M,E=(M/(i-1)-.5)*this.size,T=(_/(i-1)-.5)*this.size;if(E*E+T*T>di*di)continue;const x=.55+.45*jn(E*.22+11,T*.22-4,2);n[y]=ft(n[y]+g*x)}}if(e.condensation>.25){const g=(e.condensation-.25)*t*.05;for(let _=0;_<n.length;_+=3)n[_]=ft(n[_]+g)}const l=ft(e.sunAlt,0,1),c=ft(e.wind,0,1.2),h=(.0045+l*.0055+c*.0025)*(1-o*.5)*t;for(let g=0;g<i;g++)for(let _=0;_<i;_++){const M=g*i+_,y=n[M];if(y<=1e-4)continue;const E=(_/(i-1)-.5)*this.size,T=(g/(i-1)-.5)*this.size,x=Math.hypot(E-7,T-6.8)<5.2||this.streamCarve(E,T)>.12,w=h*(x?.6:1);n[M]=Math.max(0,y-w)}if(this._hydroTick=(this._hydroTick||0)+1,this._hydroTick%2===0){const g=this.wetAttr;if(g){for(let _=0;_<n.length;_++)g.array[_]=n[_];g.needsUpdate=!0}}let u=0,d=0,f=0,p=0;const v=di*di,m=3;for(let g=0;g<i;g+=m){const _=(g/(i-1)-.5)*this.size;for(let M=0;M<i;M+=m){const y=(M/(i-1)-.5)*this.size;if(y*y+_*_>v)continue;const E=n[g*i+M];u+=E,p++,E>.35&&d++,E<.05&&f++}}p>0&&(this.meanWetness=u/p,this.wetFraction=d/p,this.dryFraction=f/p),this.wetVerts=n}rebuildFromHeights(){const t=this.n,e=this.soilMesh.geometry,i=e.attributes.position.array;for(let n=0;n<t*t;n++)i[n*3+1]=this.heights[n];e.attributes.position.needsUpdate=!0,e.computeVertexNormals(),this.updateSoilColors(),this.updatePatches?.(),this.pondMesh&&this.rebuildWater?.(),this._needsGeometryUpdate=!0}accumulateSnow(t,e){this.n;const i=e.w.snow,n=ft((e.temperature-.12)*.9,0,1),s=this.soilMesh.geometry,o=s.attributes.position.array;this.snowField||(this.snowField=new Float32Array(this.heights.length));let a=!1;if(i>.02){const l=i*t*.24*(1-e.lidOpen*.9);for(let c=0;c<this.snowField.length;c+=2)this.snowField[c]=Math.min(1.5,this.snowField[c]+l);a=!0}if(n>.01){const l=n*t*.05;let c=0;for(let h=0;h<this.snowField.length;h+=2){if(this.snowField[h]<=0)continue;const u=Math.min(this.snowField[h],l);this.snowField[h]-=u,c+=u,a=!0}if(c>0){const h=ft(c/(this.snowField.length*.02),0,.02);for(let u=0;u<this.wetness.length;u+=3)this.wetness[u]=ft(this.wetness[u]+h)}}if(a){for(let l=0;l<this.heights.length;l++)o[l*3+1]=this.heights[l]+this.snowField[l];s.attributes.position.needsUpdate=!0,this._needsGeometryUpdate=!0,this.snowDepth=0;for(let l=0;l<this.snowField.length;l+=4)this.snowDepth+=this.snowField[l];this.snowDepth/=Math.ceil(this.snowField.length/4)}}updateSoilColors(){const t=this.n,e=this.soilMesh.geometry,i=e.attributes.color.array;for(let n=0;n<t;n++)for(let s=0;s<t;s++){const o=n*t+s,a=(s/(t-1)-.5)*this.size,l=(n/(t-1)-.5)*this.size,c=this.heights[o],h=Math.hypot(a,l),u=jn(a*.16+3,l*.16+7,4),d=ft(1-(c-.1)*.38)*ft(.4+u),f=ft((d-.25)*1.6+this.moss[o]*1.4)*(1-Ie(di*.9,di,h)),p=Ie(.45,.7,jn(a*.5+12,l*.5,3));let v=.42,m=.32,g=.21;v=Lt(v,.2,p*.5),m=Lt(m,.15,p*.5),g=Lt(g,.1,p*.5);const _=.3+u*.13,M=.43+u*.18,y=.21+u*.07;v=Lt(v,_,ft(f)*.85),m=Lt(m,M,ft(f)*.85),g=Lt(g,y,ft(f)*.85);const E=ft((c-1.7)*.5);v=Lt(v,.34,E*.5),m=Lt(m,.32,E*.5),g=Lt(g,.28,E*.5),i[o*3]=v,i[o*3+1]=m,i[o*3+2]=g}e.attributes.color.needsUpdate=!0,this.dirtyColor=!1}rebuildSoilGeometry(){const t=this.n,e=this.soilMesh.geometry,i=e.attributes.position.array;for(let n=0;n<t;n++)for(let s=0;s<t;s++){const o=n*t+s;i[o*3+1]=this.heights[o]}e.attributes.position.needsUpdate=!0,e.computeVertexNormals(),this.updateSoilColors(),this.rebuildWater()}waterMaterialShared(){if(this._waterMat)return this._waterMat;const t=new Qe({transparent:!0,depthWrite:!1,uniforms:{uTime:{value:0},uSunDir:{value:new R(.5,.8,.3)},uSunColor:{value:new ct("#ffe8c0")},uSkyColor:{value:new ct("#9fb6a8")},uDeep:{value:new ct("#1a2a24")},uSnow:{value:0},uNight:{value:0}},vertexShader:`
        varying vec3 vWorld;
        varying vec2 vUv;
        attribute float aShore;
        varying float vShore;
        void main() {
          vUv = uv;
          vShore = aShore;
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorld = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }`,fragmentShader:`
        varying vec3 vWorld;
        varying vec2 vUv;
        varying float vShore;
        uniform float uTime; uniform vec3 uSunDir; uniform vec3 uSunColor;
        uniform vec3 uSkyColor; uniform vec3 uDeep; uniform float uSnow; uniform float uNight;

        float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
        float noise(vec2 p){
          vec2 i = floor(p), f = fract(p);
          vec2 u = f*f*(3.0-2.0*f);
          return mix(mix(hash(i), hash(i+vec2(1,0)), u.x),
                     mix(hash(i+vec2(0,1)), hash(i+vec2(1,1)), u.x), u.y);
        }
        void main() {
          vec2 p = vWorld.xz * 1.6;
          float t = uTime;
          // layered ripples
          float r = noise(p * 1.1 + vec2(t * 0.35, t * 0.21)) * 0.6
                  + noise(p * 2.3 - vec2(t * 0.22, t * 0.4)) * 0.3
                  + noise(p * 4.7 + vec2(t * 0.7, -t * 0.3)) * 0.1;
          float e = 0.08;
          float rx = noise((p + vec2(e,0.0)) * 1.1 + vec2(t*0.35,t*0.21)) - noise((p - vec2(e,0.0)) * 1.1 + vec2(t*0.35,t*0.21));
          float rz = noise((p + vec2(0.0,e)) * 1.1 + vec2(t*0.35,t*0.21)) - noise((p - vec2(0.0,e)) * 1.1 + vec2(t*0.35,t*0.21));
          vec3 n = normalize(vec3(-rx * 2.2, 1.0, -rz * 2.2));

          vec3 viewDir = normalize(cameraPosition - vWorld);
          float fres = pow(1.0 - max(dot(n, viewDir), 0.0), 3.0);
          vec3 col = mix(uDeep, uSkyColor, 0.22 + fres * 0.42);

          // sun glitter
          vec3 L = normalize(uSunDir);
          vec3 H = normalize(L + viewDir);
          float spec = pow(max(dot(n, H), 0.0), 120.0);
          float sparkle = pow(max(dot(n, H), 0.0), 700.0) * (0.5 + 0.5 * sin(uTime * 8.0 + r * 40.0));
          col += uSunColor * (spec * 0.35 + sparkle * 1.1) * (1.0 - uNight * 0.75);

          // moonpath at night
          col += vec3(0.42, 0.52, 0.75) * pow(max(dot(n, H), 0.0), 60.0) * uNight * 0.8;

          // wet shoreline: fade the sheet out where it meets the soil
          float shoreFade = smoothstep(0.62, 0.98, vShore);
          float alpha = (0.72 + fres * 0.22) * (1.0 - shoreFade * 0.9);
          col = mix(col, vec3(0.3, 0.24, 0.17), shoreFade * 0.5);
          alpha = mix(alpha, 1.0, uSnow * 0.9);
          col = mix(col, vec3(0.88, 0.92, 0.96), uSnow * 0.92);
          gl_FragColor = vec4(col, alpha);
        }`});return this._waterMat=t,t}buildWater(){this.waterGroup=new gt,this.group.add(this.waterGroup);{const u=new Float32Array(3672),d=new Float32Array(1224),f=new Float32Array(1224*2),p=[];for(let g=0;g<=16;g++)for(let _=0;_<72;_++){const M=g*72+_,y=_/72*Math.PI*2;f[M*2]=(Math.cos(y)*.5+.5)*4,f[M*2+1]=(Math.sin(y)*.5+.5)*4,d[M]=g/16}for(let g=0;g<16;g++)for(let _=0;_<72;_++){const M=(_+1)%72,y=g*72+_,E=g*72+M,T=(g+1)*72+_,x=(g+1)*72+M;p.push(y,T,E,E,T,x)}const v=new de;v.setAttribute("position",new ee(u,3)),v.setAttribute("uv",new ee(f,2)),v.setAttribute("aShore",new ee(d,1)),v.setIndex(p);const m=this.waterMaterialShared();this.pondMesh=new I(v,m),this.waterGroup.add(this.pondMesh)}const t=this.streamCurve(),e=120,i=1.35,n=new Float32Array((e+1)*2*3),s=new Float32Array((e+1)*2*2),o=[];for(let c=0;c<=e;c++){const h=c/e,u=t.getPointAt(h),d=t.getTangentAt(h),f=-d.z,p=d.x,v=i*(.8+.5*Math.sin(h*7+1));for(let m=0;m<2;m++){const g=m===0?-1:1,_=c*2+m;n[_*3]=u.x+f*v*g,n[_*3+1]=0,n[_*3+2]=u.z+p*v*g,s[_*2]=h*8,s[_*2+1]=m}if(c<e){const m=c*2,g=m+1,_=m+2,M=m+3;o.push(m,_,g,g,_,M)}}const a=new de;a.setAttribute("position",new ee(n,3)),a.setAttribute("uv",new ee(s,2));const l=new Float32Array((e+1)*2);for(let c=0;c<=e;c++)l[c*2]=.18,l[c*2+1]=.18;a.setAttribute("aShore",new ee(l,1)),a.setIndex(o),a.computeVertexNormals(),this.streamMesh=new I(a,this.waterMaterialShared()),this.waterGroup.add(this.streamMesh),this.streamCurveRef=t,this.buildWaterfall(),this.rebuildWater()}rebuildWater(){if(!this.streamMesh)return;const t=this.findWaterLevel();this.pondLevel=t.level;const e=Li.pond,i=t.radius*1.02;this.pondMesh.position.set(e.x,0,e.y);const n=this.pondMesh.geometry.attributes.position.array,s=this.pondMesh.geometry.attributes.aShore.array,o=72,a=16;for(let d=0;d<=a;d++)for(let f=0;f<o;f++){const p=d*o+f,v=f/o*Math.PI*2,m=d/a*i,g=Math.cos(v)*m,_=Math.sin(v)*m,M=this.heightAt(e.x+g,e.y+_);Math.max(t.level,M+.05);const y=Math.min(1,Math.max(0,(M-t.level)/.35));n[p*3]=g,n[p*3+1]=t.level+y*(M-t.level)+(y>.001,0),n[p*3+2]=_,s[p]=d/a*(.55+Math.max(0,M-t.level)*2.2)}this.pondMesh.geometry.attributes.position.needsUpdate=!0,this.pondMesh.geometry.attributes.aShore.needsUpdate=!0,this.pondMesh.geometry.computeVertexNormals();const l=this.streamCurveRef,c=120,h=this.streamMesh.geometry.attributes.position.array,u=.04;for(let d=0;d<=c;d++){const f=d/c,p=l.getPointAt(f);let v=this.heightAt(p.x,p.z)+u;for(let m=0;m<2;m++){const g=(d*2+m)*3+1;h[g]=v}}if(this.streamMesh.geometry.attributes.position.needsUpdate=!0,this.streamMesh.geometry.computeVertexNormals(),this.waterfall){const d=l.getPointAt(.16),f=this.heightAt(d.x,d.z)+.1,p=this.heightAt(d.x+1.4,d.z+1.4)+.1;this.waterfall.visible=f-p>.25,this.waterfall.position.set(d.x,(f+p)/2,d.z),this.waterfall.scale.y=Math.max(.2,f-p)}}findWaterLevel(){const t=Li.pond;let i=this.heightAt(t.x,t.y)+.28,n=1;for(let s=0;s<32;s++){const o=s/32*Math.PI*2;let a=.5;for(let l=0;l<200;l++){a+=.08;const c=t.x+Math.cos(o)*a,h=t.y+Math.sin(o)*a;if(this.heightAt(c,h)>i)break;n=Math.max(n,a)}}return{level:i,radius:ft(n,1.2,5.2)}}buildWaterfall(){const t=Te(64,256),e=t.getContext("2d"),i=e.createLinearGradient(0,0,0,256);i.addColorStop(0,"rgba(230,245,250,0.95)"),i.addColorStop(.6,"rgba(210,232,240,0.5)"),i.addColorStop(1,"rgba(200,225,235,0.75)"),e.fillStyle=i,e.fillRect(0,0,64,256);const n=$t(21);for(let p=0;p<130;p++){e.strokeStyle=`rgba(255,255,255,${.15+n()*.35})`,e.lineWidth=.5+n()*1.6;const v=n()*64,m=n()*256;e.beginPath(),e.moveTo(v,m),e.lineTo(v+(n()-.5)*4,m+12+n()*32),e.stroke()}const s=we(t,{repeat:[1,2]});s.wrapS=s.wrapT=En;const o=new li({map:s,transparent:!0,opacity:.85,depthWrite:!1,side:ae,blending:Ne}),a=new be(2,1,8,8),l=a.attributes.position;for(let p=0;p<l.count;p++){const v=l.getX(p);l.setZ(p,Math.cos(v/2*Math.PI)*.35)}a.computeVertexNormals();const c=new I(a,o);c.rotation.y=Math.atan2(-(this.streamCurveRef.getPointAt(.2).x-this.streamCurveRef.getPointAt(.12).x),-(this.streamCurveRef.getPointAt(.2).z-this.streamCurveRef.getPointAt(.12).z)),this.waterfall=c,this.waterfallTex=s,this.waterGroup.add(c);const h=Te(64,64),u=h.getContext("2d"),d=u.createRadialGradient(32,32,2,32,32,32);d.addColorStop(0,"rgba(255,255,255,0.55)"),d.addColorStop(1,"rgba(255,255,255,0)"),u.fillStyle=d,u.fillRect(0,0,64,64);const f=new nl({map:we(h),transparent:!0,opacity:.3,depthWrite:!1,blending:Ne});this.fallMist=new Rh(f),this.fallMist.scale.set(4.4,2.6,1),this.waterGroup.add(this.fallMist)}buildSpringPool(){const t=Li.spring,e=this.heightAt(t.x,t.y)+.12;this.springPool=new ue,this.springPool.position.set(t.x,e,t.y),this.waterGroup.add(this.springPool);const i=$t(31),n=new st({color:7038552,roughness:.92,flatShading:!0});for(let s=0;s<12;s++){const o=s/12*Math.PI*2,a=1.9+i()*.5,l=new I(new hs(.28+i()*.3,0),n);l.position.set(t.x+Math.cos(o)*a,e-.15,t.y+Math.sin(o)*a),l.rotation.set(i()*3,i()*3,i()*3),l.castShadow=!1,l.receiveShadow=!0,this.group.add(l)}}buildRocks(){const t=$t(64),e=new st({color:7827551,roughness:.9,flatShading:!0}),i=new st({color:6053714,roughness:.86,flatShading:!0,metalness:.02});this.rockMats=[e,i],this.rocks=new gt,this.group.add(this.rocks);const n=(a,l,c,h)=>{const u=new Ks(c,1),d=u.attributes.position,f=$t(Math.floor(a*91+l*17+1e3)),p=new R;for(let m=0;m<d.count;m++){p.fromBufferAttribute(d,m);const g=.72+f()*.5;p.multiplyScalar(g),p.y*=.68,d.setXYZ(m,p.x,p.y,p.z)}u.computeVertexNormals();const v=new I(u,h);return v.position.set(a,this.heightAt(a,l)+c*.25,l),v.rotation.y=f()*Math.PI,v.castShadow=!0,v.receiveShadow=!0,v};for(let a=0;a<26;a++){const l=t()*Math.PI*2,c=3+Math.sqrt(t())*(di-4.5),h=Math.cos(l)*c,u=Math.sin(l)*c;if(this.streamCarve(h,u)>.25)continue;const d=.22+t()*t()*1;this.rocks.add(n(h,u,d,t()>.45?e:i))}const s=this.streamCurveRef.getPointAt(.1);for(let a=0;a<5;a++){const l=-.6+a*.34,c=s.x+Math.cos(l)*(2+a*.22),h=s.z+Math.sin(l)*(2+a*.22);this.rocks.add(n(c,h,.55+t()*.45,a%2?i:e))}const o=n(s.x+1.5,s.z+1.4,1.35,i);o.position.y=this.heightAt(s.x+1.5,s.z+1.4)+.1,this.rocks.add(o)}buildPathStones(){const t=new gt,e=new st({color:9142898,roughness:.83,flatShading:!0}),i=new Hs([new R(-3.4,0,8.8),new R(-.6,0,7.4),new R(2,0,7.8),new R(4.6,0,9.4),new R(7.4,0,11)]);for(let n=0;n<9;n++){const s=i.getPointAt(n/8),o=new I(new Ft(.44,.5,.16,7),e);o.position.set(s.x+Math.sin(n*4)*.2,this.heightAt(s.x,s.z)+.06,s.z+Math.cos(n*3)*.2),o.rotation.y=n,o.receiveShadow=!0,t.add(o)}this.group.add(t),this.path=t}buildFallenLog(){const t=new gt,e=new st({color:4864552,roughness:.95,flatShading:!0}),i=new I(new Ft(.42,.5,4.6,8),e);i.rotation.z=Math.PI/2,i.rotation.y=.5,i.position.set(-4.2,this.heightAt(-4.2,5)+.42,5),i.castShadow=!0,i.receiveShadow=!0,t.add(i);const n=new st({color:10189907,roughness:.9}),s=new I(new si(.42,16),n);s.position.set(-2.05,this.heightAt(-4.2,5)+.42+.06,5+.25),s.rotation.y=Math.PI/2+.5,t.add(s);const o=new st({color:13152394,roughness:.8}),a=new st({color:9194034,roughness:.6}),l=$t(17);for(let c=0;c<6;c++){const h=-4.2+(l()-.5)*3.4,u=5+(l()-.5)*.36,d=this.heightAt(-4.2,5)+.86,f=new I(new Ft(.05,.07,.22,5),o);f.position.set(h,d,u);const p=new I(new It(.14,8,6,0,Math.PI*2,0,Math.PI/2),a);p.position.set(h,d+.11,u),p.scale.y=.62,t.add(f,p)}this.group.add(t),this.logGroup=t}buildRingMarkers(){const t=new li({color:15978892,transparent:!0,opacity:0,depthWrite:!1,side:ae,blending:Ne});this.ringMat=t,this.rings=[];for(let i=0;i<18;i++){const n=new I(new Zr(1.28,1.42,32),t);n.rotation.x=-Math.PI/2,n.visible=!1,this.group.add(n),this.rings.push(n)}const e=new li({color:15978892,transparent:!0,opacity:.45,depthWrite:!1,blending:Ne,side:ae});this.brushRing=new I(new Zr(1.5,1.72,40),e),this.brushRing.rotation.x=-Math.PI/2,this.brushRing.visible=!1,this.group.add(this.brushRing)}buildPlantPatches(){const t=[{x:-2.6,z:3.4,r:1.5,type:"loam",name:"shaded loam"},{x:3,z:-1.6,r:1.5,type:"loam",name:"hill loam"},{x:-5.4,z:1.2,r:1.4,type:"loam",name:"spring bank"},{x:1,z:5.4,r:1.35,type:"sandy",name:"pond shore"},{x:8.6,z:2.8,r:1.4,type:"sandy",name:"dry bench"},{x:-8.2,z:-2,r:1.5,type:"loam",name:"hill foot"},{x:6,z:-4.4,r:1.35,type:"mossy",name:"moss hollow"},{x:-1.6,z:-5.6,r:1.3,type:"mossy",name:"fern dell"},{x:10.2,z:6.2,r:1.3,type:"sandy",name:"sun shelf"},{x:-9.6,z:5.2,r:1.4,type:"loam",name:"west hollow"},{x:4.6,z:9.8,r:1.3,type:"sandy",name:"front bench"},{x:-4.4,z:-9.4,r:1.35,type:"mossy",name:"north shade"}];this.patches=t.map((e,i)=>({...e,index:i,occupied:!1,ring:this.rings[i]})),this.patches.forEach(e=>{e.ring.position.set(e.x,this.heightAt(e.x,e.z)+.05,e.z),e.ring.scale.setScalar(e.r)})}buildBlightPatches(){const t=[{x:6.4,z:-8.6,r:2,name:"ash blight"},{x:11.2,z:-.8,r:1.8,name:"eroded bank"},{x:-11.6,z:8.6,r:2,name:"scorched ground"},{x:.4,z:-9.8,r:1.7,name:"withered hollow"}];this.blightPatches=t.map((e,i)=>{const n=new gt,s=this.heightAt(e.x,e.z);n.position.set(e.x,s+.02,e.z);const o=new I(new si(e.r,24),new st({color:1840912,roughness:1,transparent:!0,opacity:.85}));o.rotation.x=-Math.PI/2,o.position.y=.02,n.add(o);const a=new st({color:3813672,roughness:1}),l=$t(200+i*7);for(let h=0;h<7;h++){const u=new I(new Ft(.015,.05,.5+l()*.7,4),a),d=l()*Math.PI*2,f=l()*e.r*.7;u.position.set(Math.cos(d)*f,.25,Math.sin(d)*f),u.rotation.set((l()-.5)*.8,0,(l()-.5)*.8),n.add(u)}const c=new I(new si(e.r*1.05,24),new li({color:9056031,transparent:!0,opacity:.06,depthWrite:!1,blending:Ne}));return c.rotation.x=-Math.PI/2,c.position.y=.03,n.add(c),this.group.add(n),{...e,group:n,restored:!1,aura:c,disc:o,baseR:e.r,spread:0,spawned:!1}})}updateBlight(t,e,i){const n=ft(1-(this.meanWetness||0)*4.2);this.blightPatches.forEach(o=>{if(o.restored)return;o.spread=ft((o.spread||0)+t*.012*n-t*.004);const a=o.baseR*(1+o.spread*.35);o.disc.scale.setScalar(a/o.baseR),o.aura.scale.setScalar(a/o.baseR),o.aura.material.opacity=.04+n*.07+Math.sin(this.time*1.4+o.x)*.02}),this._liveBlight||(this._liveBlight=[]);const s=this._liveBlight;(e.plants||[]).forEach(o=>{if(o.hp>.35||!o.obj||o.x==null)return;let a=s.find(l=>Math.hypot(l.x-o.x,l.z-o.z)<1.6);if(o._blightNear=!!a,a)a.host=o,a.spread=ft(a.spread+t*.02*(1-o.hp));else if(s.length<14&&(o._sickT=(o._sickT||0)+t,o._sickT>6)){const l=new gt,c=this.heightAt(o.x,o.z);l.position.set(o.x,c+.02,o.z);const h=new I(new si(.9,18),new st({color:2365970,roughness:1,transparent:!0,opacity:0}));h.rotation.x=-Math.PI/2,l.add(h),this.group.add(l),s.push({x:o.x,z:o.z,r:.9,baseR:.9,spread:0,group:l,disc:h,host:o,live:!0,faded:0}),o._sickT=0}});for(let o=s.length-1;o>=0;o--){const a=s[o];a.host&&a.host.hp>.6?a.faded+=t:a.faded=Math.max(0,a.faded-t);const c=ft(a.spread/.5);a.disc.material.opacity=ft(c*.8)*ft(1-a.faded*.5),a.disc.scale.setScalar(Lt(.5,1.5,c)),a.faded>2.2&&(a.group.removeFromParent(),a.disc.geometry.dispose(),a.disc.material.dispose(),s.splice(o,1))}}setPatchMarkers(t,e=!1){this.patches.forEach(i=>{i.ring.visible=t&&(e?!i.occupied:!0),i.ring.material.opacity=0}),this._markersOn=t,this._markersPlantedOnly=e}sculpt(t,e,i,n){const s=this.n,o=Math.max(0,Math.floor((t/this.size+.5)*(s-1)-i/this.size*(s-1))),a=Math.min(s-1,Math.ceil((t/this.size+.5)*(s-1)+i/this.size*(s-1))),l=Math.max(0,Math.floor((e/this.size+.5)*(s-1)-i/this.size*(s-1))),c=Math.min(s-1,Math.ceil((e/this.size+.5)*(s-1)+i/this.size*(s-1)));let h=!1;for(let u=l;u<=c;u++)for(let d=o;d<=a;d++){const f=(d/(s-1)-.5)*this.size,p=(u/(s-1)-.5)*this.size,v=Math.hypot(f-t,p-e);if(v>i)continue;const m=Ie(i,0,v),g=u*s+d;this.heights[g]=ft(this.heights[g]+n*m,-1.6,4.2),h=!0}return h&&(this.dirtyColor=!0,this._needsGeometryUpdate=!0),h}wet(t,e,i,n){const s=this.n,o=Math.max(0,Math.floor((t/this.size+.5)*(s-1)-i/this.size*(s-1))),a=Math.min(s-1,Math.ceil((t/this.size+.5)*(s-1)+i/this.size*(s-1))),l=Math.max(0,Math.floor((e/this.size+.5)*(s-1)-i/this.size*(s-1))),c=Math.min(s-1,Math.ceil((e/this.size+.5)*(s-1)+i/this.size*(s-1)));let h=0;for(let u=l;u<=c;u++)for(let d=o;d<=a;d++){const f=(d/(s-1)-.5)*this.size,p=(u/(s-1)-.5)*this.size,v=Math.hypot(f-t,p-e);if(v>i)continue;const m=u*s+d,g=Ie(i,0,v);this.wetness[m]=ft(this.wetness[m]+n*g),h+=g}return this.wetAttr.needsUpdate=!0,this.wetVerts=this.wetness,h}growMoss(t,e,i){const n=this.n;for(let s=0;s<n;s++)for(let o=0;o<n;o++){const a=(o/(n-1)-.5)*this.size,l=(s/(n-1)-.5)*this.size,c=Math.hypot(a-t,l-e);if(c<i){const h=s*n+o;this.moss[h]=ft(this.moss[h]+Ie(i,0,c)*.5)}}this.dirtyColor=!0}update(t,e,i){const n=t.elapsed,s=this._waterMat;s&&(s.uniforms.uTime.value=n,s.uniforms.uNight.value=t.night,s.uniforms.uSnow.value=t.snowAccum,s.uniforms.uSunDir.value.copy(this.state.sunDir||new R(.4,.9,.3)),s.uniforms.uSunColor.value.copy(t.sunTint||s.uniforms.uSunColor.value),s.uniforms.uSkyColor.value.copy(t.skyTint||s.uniforms.uSkyColor.value));const o=this.soilMat.userData.uniforms;if(o.uSnow.value=Ee(o.uSnow.value,t.snowAccum,2,e),o.uWet.value=t.w.rain*.35,this.waterfallTex&&(this.waterfallTex.offset.y-=e*1.6),this.fallMist&&(this.fallMist.material.opacity=.16+Math.sin(n*2.1)*.06+t.w.rain*.12),this.hydro(e,t),this._markersOn){const a=.28+Math.sin(n*3)*.12;this.ringMat.opacity=a}else this.ringMat.opacity=Math.max(0,this.ringMat.opacity-e*2);this.blightPatches.forEach((a,l)=>{a.restored||(a.aura.material.opacity=.05+Math.sin(n*1.4+l)*.025)}),this._needsGeometryUpdate?(this._geoDebounce=(this._geoDebounce||0)+e,this._geoDebounce>.08&&(this._geoDebounce=0,this._needsGeometryUpdate=!1,this.rebuildSoilGeometry())):this.dirtyColor&&this.updateSoilColors()}}function Wa(r,t=!1){const e=r[0].index!==null,i=new Set(Object.keys(r[0].attributes)),n=new Set(Object.keys(r[0].morphAttributes)),s={},o={},a=r[0].morphTargetsRelative,l=new de;l.morphTargetsRelative=a;let c=0;for(let h=0;h<r.length;++h){const u=r[h];let d=0,f=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const p in u.attributes){if(!i.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;s[p]===void 0&&(s[p]=[]),s[p].push(u.attributes[p]),d++}if(d!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const p in u.morphAttributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;if(u.morphAttributes[p].length!==r[0].morphAttributes[p].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have the same number of morph targets for the "'+p+'" morph attribute.'),null;o[p]===void 0&&(o[p]=[]),o[p].push(u.morphAttributes[p]),f++}if(f!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of morph attributes."),null;if(t){let p;if(e)p=u.index.count;else if(u.attributes.position!==void 0)p=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,p,h),c+=p}}if(e){let h=0;const u=[];for(let d=0;d<r.length;++d){const f=r[d].index;for(let p=0;p<f.count;++p)u.push(f.getX(p)+h);h+=r[d].attributes.position.count}l.setIndex(u)}for(const h in s){const u=qc(s[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(const h in o){const u=o[h][0].length;if(u!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){const f=[];for(let v=0;v<o[h].length;++v)f.push(o[h][v][d]);const p=qc(f);if(!p)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(p)}}}return l}function qc(r){let t,e,i,n=-1,s=0;for(let c=0;c<r.length;++c){const h=r[c];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=h.normalized),i!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(n===-1&&(n=h.gpuType),n!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=h.count*e}const o=new t(s),a=new ee(o,e,i);let l=0;for(let c=0;c<r.length;++c){const h=r[c];if(h.isInterleavedBufferAttribute){const u=l/e;for(let d=0,f=h.count;d<f;d++)for(let p=0;p<e;p++){const v=h.getComponent(d,p);a.setComponent(d+u,p,v)}}else o.set(h.array,l);l+=h.count*e}return n!==void 0&&(a.gpuType=n),a}function Ov(r,{colorKey:t="color"}={}){r.updateWorldMatrix(!0,!0);const e=[],i=new te().copy(r.matrixWorld).invert();if(r.traverse(s=>{if(!s.isMesh)return;let o=s.geometry.index?s.geometry.toNonIndexed():s.geometry.clone();const a=new Set(["position","normal","uv","color"]);for(const f of Object.keys(o.attributes))a.has(f)||o.deleteAttribute(f);if(!o.attributes.uv){const f=o.attributes.position.count;o.setAttribute("uv",new ee(new Float32Array(f*2),2))}o.attributes.normal||o.computeVertexNormals();const l=new te().multiplyMatrices(i,s.matrixWorld);o.applyMatrix4(l);const c=Array.isArray(s.material)?s.material[0]:s.material,h=c&&c[t]?c[t]:new ct(16777215),u=o.attributes.position.count,d=new Float32Array(u*3);for(let f=0;f<u;f++)d[f*3]=h.r,d[f*3+1]=h.g,d[f*3+2]=h.b;o.setAttribute("color",new ee(d,3)),e.push(o)}),!e.length)return null;const n=Wa(e,!1);return e.forEach(s=>s.dispose()),n}function Bv(r,t,{castShadow:e=!1,receiveShadow:i=!0}={}){const n=Ov(r);if(!n)return null;const s=new I(n,t);return s.castShadow=e,s.receiveShadow=i,s}function ai(r,{castShadow:t=!0,receiveShadow:e=!0}={}){r.updateWorldMatrix(!0,!0);const i=new te().copy(r.matrixWorld).invert(),n=new Map;if(r.traverse(u=>{if(!u.isMesh)return;const d=Array.isArray(u.material)?u.material[0]:u.material;n.has(d)||n.set(d,[]);let f=u.geometry.index?u.geometry.toNonIndexed():u.geometry.clone();const p=new Set(["position","normal","uv"]);for(const g of Object.keys(f.attributes))p.has(g)||f.deleteAttribute(g);const v=f.attributes.position.count;f.attributes.uv||f.setAttribute("uv",new ee(new Float32Array(v*2),2)),f.attributes.normal||f.computeVertexNormals();const m=new te().multiplyMatrices(i,u.matrixWorld);f.applyMatrix4(m),n.get(d).push(f)}),!n.size)return null;const s=[],o=[];let a=0;const l=[];for(const[u,d]of n){const f=Wa(d,!1);if(d.forEach(v=>v.dispose()),!f)continue;o.push(f),s.push(u);const p=f.attributes.position.count;l.push({start:a,count:p,materialIndex:s.length-1}),a+=p}if(!o.length)return null;const c=Wa(o,!0);if(o.forEach(u=>u.dispose()),!c)return null;c.clearGroups(),l.forEach(u=>c.addGroup(u.start,u.count,u.materialIndex));const h=new I(c,s);return h.castShadow=t,h.receiveShadow=e,h}const _e=Math.PI*2,Us={uTime:{value:0},uWind:{value:.2},uDir:{value:new Q(1,.35).normalize()}};function Sn(r,{amp:t=.12,height:e=4,phase:i=0,biome:n=0,glow:s=0}={}){return r.userData.wind={amp:t,height:e,phase:i,biome:n},r.userData.glow={value:s},`${Math.random().toString(36).slice(2)}`,r.onBeforeCompile=o=>{o.uniforms.uTime=Us.uTime,o.uniforms.uWind=Us.uWind,o.uniforms.uDir=Us.uDir,o.uniforms.uGlow=r.userData.glow,r.userData.shader=o,o.vertexShader=o.vertexShader.replace("#include <common>",`#include <common>
        uniform float uTime; uniform float uWind; uniform vec2 uDir;
        varying float vSway;`).replace("#include <begin_vertex>",`#include <begin_vertex>
        float hgt = clamp(position.y / ${e.toFixed(2)}, 0.0, 1.0);
        float sway = sin(uTime * 1.6 + ${i.toFixed(2)} + position.x * 0.7 + position.z * 0.6) * 0.6
                   + sin(uTime * 3.1 + ${i.toFixed(2)} * 2.0 + position.z) * 0.25;
        float bend = pow(hgt, 1.6) * ${t.toFixed(3)} * (0.15 + uWind * 1.5);
        transformed.x += uDir.x * sway * bend * 6.0;
        transformed.z += uDir.y * sway * bend * 6.0;
        transformed.y += abs(sway) * bend * 1.2;
        vSway = bend;`),s>0&&(o.uniforms.uNight=r.userData.night||{value:0})},r}function Kn(r,t,{intensity:e=1.2}={}){const i=r.clone();return i.emissive=new ct(t),i.emissiveIntensity=0,i.userData.night={value:0},i.userData.glowColor=t,i.userData.glowIntensity=e,i}function zv(r=3,t=.06,e=.5,i=.25){const n=new be(t,e,1,r);n.translate(0,e/2,0);const s=n.attributes.position;for(let o=0;o<s.count;o++){const l=s.getY(o)/e;s.setZ(o,l*l*i),s.setX(o,s.getX(o)*(1-l*.85))}return n.computeVertexNormals(),n}const kv=new ct("#8a7a3e"),Gv=new ct("#4a4030");class Hv{constructor(t,e,i,n={}){this.scene=t,this.state=e,this.terrain=i,this.group=new gt,this.group.position.y=wt.glassBottomY+.32,t.add(this.group),this.rng=$t(2024),this.quality=n.quality||"high",this.qMul=this.quality==="low"?.55:1,this.plants=[],this.cutClusters=[],this.heroPlants=[],this.glowThings=[],this.blighted=!1,this.time=0,this.buildMaterials(),this.buildGroundCover(),this.buildMossPillows(),this.buildFerns(),this.buildHeroTrees(),this.buildShrubs(),this.buildMushrooms(),this.buildGlowFlowers(),this.buildVines()}buildMaterials(){const t=this.mat={};t.grass=Sn(new st({color:16777215,roughness:.86,side:ae}),{amp:.06,height:.9,phase:1.1}),t.moss=Sn(new st({color:16777215,roughness:.95,flatShading:!0}),{amp:.02,height:.3,phase:2.2}),t.fern=Sn(new st({color:16777215,roughness:.78,side:ae}),{amp:.1,height:1.6,phase:3.1}),t.leaf=Sn(new st({color:16777215,roughness:.72,side:ae,vertexColors:!0}),{amp:.16,height:5,phase:.7}),t.bark=new st({color:5916210,roughness:.95,flatShading:!0}),t.conifer=Sn(new st({color:4087356,roughness:.85,flatShading:!0}),{amp:.08,height:7,phase:5}),t.reed=Sn(new st({color:9081941,roughness:.8,side:ae}),{amp:.09,height:2.2,phase:4})}bakeStatic(){const t=new Set(this.flowers||[]);let e=0,i=0,n=0;const s=o=>{let a=0;return o.traverse(l=>{l.isMesh&&a++}),a};return[...this.group.children].forEach(o=>{if(!o.isGroup||t.has(o)||o.userData.head||o.userData.foliage||o.userData.trunk)return;const a=s(o);if(a<2)return;i+=a;const l=ai(o,{castShadow:!0,receiveShadow:!0});l&&(o.clear(),o.add(l),n+=1,e++)}),{groups:e,meshesBefore:i,meshesAfter:n}}buildGroundCover(){const t=wt.soilRadius,e=zv(3,.055,.42,.2),i=Math.floor(2600*this.qMul),n=new Rs(e,this.mat.grass,i);n.castShadow=!1,n.receiveShadow=!0;const s=new ue,o=new ct,a=$t(88);let l=0,c=0;for(;l<i&&c<i*8;){c++;const m=a()*_e,g=Math.sqrt(a())*t*.97,_=Math.cos(m)*g,M=Math.sin(m)*g;if(this.terrain.wetnessAt(_,M),this.terrain.streamCarve(_,M)>.2||Math.hypot(_-7,M-6.8)<4.6)continue;const E=this.terrain.heightAt(_,M);if(E<.1&&a()>.2||jn(_*.7+5,M*.7+9,3)<.42&&a()>.1)continue;s.position.set(_,E+.01,M),s.rotation.set((a()-.5)*.25,a()*_e,(a()-.5)*.25);const x=.5+a()*1;s.scale.set(x*(.7+a()*.5),x*(.6+a()*.9),x),s.updateMatrix(),n.setMatrixAt(l,s.matrix);const w=.205+a()*.075,P=.34+a()*.22,C=.16+a()*.14-this.terrain.wetnessAt(_,M)*.05;o.setHSL(w,P,C),n.setColorAt(l,o),l++}n.count=l,n.instanceMatrix.needsUpdate=!0,n.instanceColor&&(n.instanceColor.needsUpdate=!0),this.grassInst=n,this.group.add(n);const h=new Ks(.13,0),u=Math.floor(1400*this.qMul),d=new Rs(h,this.mat.moss,u);d.receiveShadow=!0;const f=$t(91);let p=0,v=0;for(;p<u&&v<u*6;){v++;const m=f()*_e,g=Math.sqrt(f())*t*.98,_=Math.cos(m)*g,M=Math.sin(m)*g;if(this.terrain.streamCarve(_,M)>.3||Math.hypot(_-7,M-6.8)<4.2||jn(_*.9+1,M*.9+7,3)<.5&&f()>.25)continue;const T=this.terrain.heightAt(_,M);s.position.set(_,T+.02,M),s.rotation.set(f()*3,f()*3,f()*3);const x=.5+f()*1;s.scale.set(x,x*.4,x),s.updateMatrix(),d.setMatrixAt(p,s.matrix);const w=.16+f()*.16;o.setRGB(w*.62,w,w*.3),d.setColorAt(p,o),p++}d.count=p,d.instanceMatrix.needsUpdate=!0,d.instanceColor&&(d.instanceColor.needsUpdate=!0),this.mossInst=d,this.group.add(d)}buildMossPillows(){}makeFern(t=1,e=7){const i=new gt,n=7,s=$t(300+e);for(let o=0;o<n;o++){const a=o/n*_e+s()*.5,l=new gt,c=.9+s()*.7,h=6;let u=l;for(let d=0;d<h;d++){const f=d/h,p=new gt;p.position.y=d===0?0:c/h,p.rotation.z=.22+f*.12,p.rotation.x=-.1-f*.12;const v=new be(.36*(1-f*.6),.14,1,1);v.translate(.18*(1-f*.6),0,0);for(let g=-1;g<=1;g+=2){const _=new I(v,this.mat.fern);_.rotation.y=g>0?0:Math.PI,_.rotation.x=.06,p.add(_)}const m=new be(.26*(1-f*.5),.1);m.translate(.13*(1-f*.5),0,0);for(let g=-1;g<=1;g+=2){const _=new I(m,this.mat.fern);_.rotation.y=g>0?0:Math.PI,_.rotation.x=.9,_.rotation.z=.2,p.add(_)}u.add(p),u=p}l.rotation.y=a,l.scale.setScalar(.7+s()*.5),i.add(l)}for(let o=0;o<3;o++){const a=new I(new We(.1,.02,4,12,Math.PI*1.6),this.mat.fern);a.position.set((s()-.5)*.3,.12,(s()-.5)*.3),a.rotation.y=s()*_e,i.add(a)}return i.scale.setScalar(t),i}buildFerns(){const t=$t(410),e=[[-1.6,-5.6],[-2.8,-4.4],[-9,3.6],[6,-4.4],[-7.6,-9.2],[5.4,-6],[-3.6,6.4],[9.4,-3.4],[-10.6,-1.2],[2.4,-7.4],[-1.2,-9.6],[11,3]],i=new be(.34,.13);i.translate(.17,0,0);const n=[],s=[],o=new ue,a=new ct;new te;const l=new ue;l.rotation.order="XYZ",e.forEach(([u,d],f)=>{const p=this.terrain.heightAt(u,d),v=1+t()*.5,m=7;for(let g=0;g<m;g++){const _=g/m*_e+t()*.5,M=(.9+t()*.7)*v,y=5;let E=0,T=0,x=0,w=.22;for(let P=0;P<y;P++){const C=M/y;w+=.12+P*.03;const U=Math.cos(w)*C,B=Math.sin(w)*C;E+=Math.cos(_)*B,x+=Math.sin(_)*B,T+=U;const V=P/y;for(let D=-1;D<=1;D+=2)for(let H=0;H<2;H++){o.position.set(u+E,p+T,d+x),o.rotation.set(.1+H*.9,_+(D>0?0:Math.PI),D*.15);const Y=v*(1-V*.55)*(H===0?1:.7);o.scale.set(Y,Y,Y),o.updateMatrix(),n.push(o.matrix.clone()),a.setHSL(.26+t()*.03,.5,.13+t()*.08),s.push(a.r,a.g,a.b)}}}this.heroPlants.push({type:"fern",obj:null,x:u,z:d,hp:1,growth:1,fernIndex:f})});const c=new Rs(i,this.mat.fern,n.length);n.forEach((u,d)=>c.setMatrixAt(d,u));const h=new Na(new Float32Array(s),3);c.instanceColor=h,c.instanceColor.needsUpdate=!0,c.instanceMatrix.needsUpdate=!0,c.receiveShadow=!0,c.frustumCulled=!0,this.fernInst=c,this.group.add(c)}makeFernMesh(t,e){const i=this.makeFern(t,e);return Bv(i,new st({color:16777215,roughness:.78,side:ae,vertexColors:!0}))}buildHeroTrees(){const t=(i,n,s=1,o=.23,a=1,l=!1)=>{const c=$t(a),h=new gt,u=(l?4.2:3.6)*s,d=new I(new Ft(.09*s,.22*s,u,6),this.mat.bark);d.position.y=u/2,d.castShadow=!1,h.add(d);const f=new gt,p=this.quality==="low"?7:12,v=new It(.5,5,4);for(let g=0;g<p;g++){const _=c()*_e,M=.25+c()*.7,y=(.6+c()*1.5)*s,E=u*(.45+c()*.55),T=new R(Math.cos(_)*y,E+M*.7*s,Math.sin(_)*y),x=new I(new Ft(.012*s,.035*s,1,4),this.mat.bark);x.position.copy(T).multiplyScalar(.55).setY(E),x.scale.y=y+.4,x.lookAt(T),x.rotateX(Math.PI/2),h.add(x);const w=new I(v,this.mat.leaf.clone()),P=w.material;P.color.setHSL(o+(c()-.5)*.04,.36+c()*.2,.24+c()*.13),P.emissive=new ct(o,.3,.1),P.emissiveIntensity=0,P.userData.night={value:0},w.position.copy(T),w.scale.setScalar((.4+c()*.5)*s),w.castShadow=!1,w.userData.baseScale=w.scale.x,f.add(w)}f.scale.setScalar(.001);const m=ai(f,{castShadow:!1,receiveShadow:!0});return m&&(f.clear(),f.add(m)),h.add(f),h.userData.foliage=f,h.userData.trunk=d,h};[{x:-6.8,z:-8,s:1.35,conifer:!1,seed:12,hue:.24},{x:-8.8,z:-5.6,s:.95,conifer:!1,seed:15,hue:.28},{x:7.6,z:-6.4,s:1.2,conifer:!0,seed:18,hue:.31},{x:10.4,z:-8.4,s:.9,conifer:!0,seed:21,hue:.28},{x:-12.2,z:1,s:1,conifer:!1,seed:24,hue:.2},{x:.4,z:-11.4,s:1.05,conifer:!0,seed:27,hue:.33},{x:12.6,z:8.4,s:.88,conifer:!1,seed:30,hue:.22}].forEach(i=>{const n=this.terrain.heightAt(i.x,i.z);let s;if(i.conifer){s=new gt;const a=$t(i.seed),l=5.2*i.s,c=new I(new Ft(.07*i.s,.2*i.s,l,6),this.mat.bark);c.position.y=l/2,c.castShadow=!1,s.add(c);const h=new gt,u=7;for(let f=0;f<u;f++){const p=f/u,v=(1.5-p*1.25)*i.s,m=new ci(v,1.4*i.s,7,1),g=this.mat.conifer.clone();g.color.setHSL(i.hue+(a()-.5)*.03,.34,.24+a()*.11);const _=new I(m,g);_.position.y=l*(.28+p*.72),_.rotation.y=a()*_e,_.castShadow=!1,_.userData.baseScale=1,h.add(_),this.glowThings.push({obj:_,kind:"leaf"})}h.scale.setScalar(.001);const d=ai(h,{castShadow:!1,receiveShadow:!0});d&&(h.clear(),h.add(d)),s.add(h),s.userData.foliage=h,s.userData.trunk=c}else s=t(i.x,i.z,i.s,i.hue,i.seed,!1);s.position.set(i.x,n-.05,i.z),s.rotation.y=i.seed*.7,this.group.add(s);const o={type:i.conifer?"conifer":"broadleaf",obj:s,x:i.x,z:i.z,hp:1,growth:0,foliage:s.userData.foliage,swayPhase:Math.random()*_e,matureAt:22};this.plants.push(o),this.heroPlants.push(o)}),this.treeLamp=new Zi(16768416,0,26,0),this.treeLamp.castShadow=!1,this.treeLamp.position.set(-2,wt.glassBottomY+12,-4),this.scene.add(this.treeLamp)}buildShrubs(){[[3.4,-3.6],[-4,2.6],[1.2,8.4],[-8.8,7.6],[8.2,.4],[-2.2,.8],[6.8,-6.8],[-6.2,-6.6]].forEach(([e,i],n)=>{const s=this.terrain.heightAt(e,i),o=new gt,a=$t(700+n),l=new gt,c=this.quality==="low"?5:9,h=n%3===0?.3:n%3===1?.24:.13;for(let m=0;m<c;m++){const g=new It(.22+a()*.24,6,5),_=this.mat.leaf.clone();_.color.setHSL(h+(a()-.5)*.05,.5,.17+a()*.1),_.emissive=new ct(16742314),_.emissiveIntensity=0,_.userData.night={value:0};const M=new I(g,_);M.position.set((a()-.5)*1.4,.2+a()*.7,(a()-.5)*1.4),M.scale.y=.72,M.castShadow=!1,l.add(M),this.glowThings.push({obj:M,kind:n%3===0?"shrubGlow":"leaf"})}const u=[16748456,14262527,16766074][n%3],d=Kn(new st({color:u,roughness:.55,side:ae}),u,{intensity:.8}),f=new si(.09,5);for(let m=0;m<(this.quality==="low"?10:22);m++){const g=a()*_e,_=a()*1.1,M=new I(f,d);M.position.set(Math.cos(g)*_,.5+a()*1.1,Math.sin(g)*_),M.rotation.set(a()*3,a()*3,a()*3),l.add(M)}this.glowThings.push({obj:l,kind:"blossom",mat:d,baseColor:u});const p=ai(l,{castShadow:!1,receiveShadow:!0});p&&(p.userData.glowThing=!0,l.clear(),l.add(p)),o.add(l),o.position.set(e,s,i),o.rotation.y=a()*_e,o.scale.setScalar(.001),this.group.add(o);const v={type:"shrub",obj:o,x:e,z:i,hp:1,growth:0,foliage:l,phase:a()*_e,blossomMat:d};this.plants.push(v)})}buildMushrooms(){const t=$t(810),e=[[-5.6,.8],[-6.4,-.4],[5.8,-5.2],[6.6,-4],[-1.4,-6],[9.2,6],[-9.8,4.2],[3.2,6],[-3.4,-8.4],[12,5.6],[-11.4,9.8],[1.8,-9.2]];this.mushroomGroup=new gt;const i=Kn(new st({color:7324848,roughness:.4,emissive:3658416,emissiveIntensity:0}),6291408,{intensity:2.2});i.userData.night={value:0};const n=new st({color:14208432,roughness:.7}),s=new st({color:15005162,roughness:.5,side:ae});this.mushroomMats=[i],e.forEach(([o,a],l)=>{const c=this.terrain.heightAt(o,a),h=new gt,u=2+Math.floor(t()*4);for(let f=0;f<u;f++){const p=.55+t()*.9,v=new gt,m=.4*p,g=new I(new Ft(.03*p,.05*p,m,5),n);g.position.y=m/2;const _=new I(new It(.17*p,10,6,0,_e,0,Math.PI/2),i);_.scale.y=.68,_.position.y=m;const M=new I(new si(.16*p,10),s);M.rotation.x=Math.PI/2,M.position.y=m-.005,v.add(g,_,M),v.position.set((t()-.5)*.9,0,(t()-.5)*.9),v.rotation.y=t()*_e,v.userData.baseY=0,h.add(v)}h.position.set(o,c,a);const d=ai(h,{castShadow:!1,receiveShadow:!0});d&&(h.clear(),h.add(d)),this.mushroomGroup.add(h),this.plants.push({type:"mushroom",obj:h,x:o,z:a,hp:1,growth:1})}),this.group.add(this.mushroomGroup),this.mushroomLight=new Zi(5636044,0,18,0),this.mushroomLight.position.set(-5.8,wt.glassBottomY+2.4,.2),this.scene.add(this.mushroomLight)}buildGlowFlowers(){const t=$t(920),e=Kn(new st({color:10475775,roughness:.4,side:ae,transparent:!0,opacity:.95}),7325951,{intensity:2});e.userData.night={value:0};const i=Kn(new st({color:16773808,roughness:.5}),16770688,{intensity:1.6});i.userData.night={value:0},this.flowerMats=[e,i],this.flowers=[];for(let n=0;n<26;n++){const s=t()*_e,o=Math.sqrt(t())*15,a=Math.cos(s)*o,l=Math.sin(s)*o;if(this.terrain.streamCarve(a,l)>.2||Math.hypot(a-7,l-6.8)<4.4)continue;const c=this.terrain.heightAt(a,l),h=new gt,u=.3+t()*.35,d=new I(new Ft(.012,.018,u,4),this.mat.grass);d.position.y=u/2,h.add(d);const f=new gt;f.position.y=u;const p=new si(.075,6);for(let g=0;g<5;g++){const _=new I(p,e),M=g/5*_e;_.position.set(Math.cos(M)*.075,0,Math.sin(M)*.075),_.rotation.set(-Math.PI/2+.5,0,M),f.add(_)}const v=new I(new It(.05,8,6),i);f.add(v),h.add(f),h.position.set(a,c,l),h.rotation.y=t()*_e,h.userData.head=f,h.userData.phase=t()*_e;const m=ai(f,{castShadow:!1,receiveShadow:!1});m&&(f.clear(),f.add(m),h.userData.head=f),this.group.add(h),this.flowers.push(h),this.plants.push({type:"flower",obj:h,x:a,z:l,hp:1,growth:1})}}buildVines(){const t=$t(1024),e=Sn(new st({color:4612154,roughness:.82,side:ae}),{amp:.05,height:10,phase:6}),i=new be(.22,.13),n=new gt;for(let o=0;o<5;o++){const a=o/5*_e+t()*.4,l=wt.glassRadius*.93,c=[],h=9+t()*9;for(let f=0;f<=10;f++){const p=f/10,v=a+Math.sin(p*3.2+o)*.1+p*.32,m=l*(1-p*.02)*(.985-Math.pow(p,6)*.15);c.push(new R(Math.cos(v)*m,p*h,Math.sin(v)*m))}const u=new Hs(c),d=new I(new eo(u,22,.018,4,!1),e);n.add(d);for(let f=0;f<16;f++){const p=(f+.5)/16,v=u.getPoint(p),m=new I(i,e);m.position.copy(v),m.rotation.set(t()*.6-.3,Math.atan2(v.z,v.x)+Math.PI/2,t()*.6-.3),m.scale.setScalar(.5+t()*.5),n.add(m)}}const s=ai(n,{castShadow:!1,receiveShadow:!1});s&&this.group.add(s)}clearPlanted(){const t=[];this.plants.forEach(e=>{if(!e.seedId){t.push(e);return}e.obj&&(e.obj.removeFromParent(),e.obj.traverse?.(i=>{i.isMesh&&i.geometry?.dispose?.()}))}),this.plants=t}pruneAt(t,e=1.2){let i=null,n=1/0;if(this.heroPlants.forEach(d=>{if(!d.obj)return;const f=d.obj.position.x-t.x,p=d.obj.position.z-t.z,v=Math.hypot(f,p);v<n&&(n=v,i=d)}),!i||n>6)return null;const s=i.foliage;if(!s)return null;const o=s.children.filter(d=>!d.userData.cut&&d.visible);if(!o.length)return s.children.forEach(d=>{d.userData.cut=!1,d.visible=!0}),i.hp=1,{regrown:!0,plant:i};let a=o[0],l=1/0;const c=new R;o.forEach(d=>{d.getWorldPosition(c);const f=c.distanceTo(t);f<l&&(l=f,a=d)});const h=a.scale.clone();a.userData.cut=!0;const u=new Rn(.45,d=>{a.scale.copy(h).multiplyScalar(1-d),a.position.y=(a.userData.baseY??a.position.y)-d*.5},()=>{a.visible=!1,a.scale.copy(h)});return this.pruneTweens=this.pruneTweens||[],this.pruneTweens.push(u),i.hp=Math.max(.2,i.hp-.22),{plant:i,cut:a,fallPos:t}}plantSeed(t,e,i,n={}){const s=this.terrain.heightAt(t,e),o=new gt,a=$t(Math.floor(t*31+e*17+999)),l=i.kind,c={type:l,obj:o,x:t,z:e,hp:1,growth:n.growth??0,foliage:null,seed:i,seedId:i?.id,phase:a()*_e};if(l==="broadleaf"||l==="conifer"){const u=new I(new Ft(.05,.16,3.4,6),this.mat.bark);u.position.y=3.4/2,u.castShadow=!1,o.add(u);const d=new gt,f=new It(.5,5,4),p=l==="conifer"?8:12;for(let m=0;m<p;m++){const g=a()*_e,_=.4+a()*(l==="conifer"?.9:1.4),M=3.4*(.4+a()*.65),y=new R(Math.cos(g)*_,M,Math.sin(g)*_),E=this.mat.leaf.clone(),T=i.hue??.25;E.color.setHSL(T+(a()-.5)*.05,.4,.24+a()*.12),E.emissive=new ct(T,.35,.12),E.emissiveIntensity=0,E.userData.night={value:0};const x=new I(f,E);x.position.copy(y);const w=(l==="conifer"?.4:.42)+a()*.4;x.scale.setScalar(w),x.userData.baseScale=w,x.castShadow=!1,d.add(x)}d.scale.setScalar(.001);const v=ai(d,{castShadow:!1,receiveShadow:!0});v&&(d.clear(),d.add(v)),o.add(d),c.foliage=d,o.scale.setScalar(.001),c.matureAt=i.matureAt||26}else if(l==="flower"){const h=new gt;for(let f=0;f<7;f++){const p=new I(new It(.22+a()*.18,5,4),this.mat.leaf.clone());p.material.color.setHSL(i.hue??.22,.42,.3),p.position.set((a()-.5)*.9,.15+a()*.5,(a()-.5)*.9),h.add(p)}const u=Kn(new st({color:i.bloom||16756936,roughness:.5,side:ae}),i.bloom||16756936,{intensity:1.4});u.userData.night={value:0};for(let f=0;f<12;f++){const p=new I(new si(.08,5),u);p.position.set((a()-.5)*1.2,.4+a()*.7,(a()-.5)*1.2),p.rotation.set(a()*3,a()*3,a()*3),h.add(p)}c.blossomMat=u;const d=ai(h,{castShadow:!1,receiveShadow:!0});d&&(h.clear(),h.add(d)),o.add(h),c.foliage=h,o.scale.setScalar(.001),c.matureAt=14}else if(l==="fungus"){const h=Kn(new st({color:i.cap||9426687,roughness:.4}),i.cap||9426687,{intensity:2.2});h.userData.night={value:0},c.capMat=h;for(let u=0;u<4;u++){const d=new gt,f=.3+a()*.3,p=new I(new Ft(.03,.05,f,5),new st({color:14208432,roughness:.7}));p.position.y=f/2;const v=new I(new It(.16,10,6,0,_e,0,Math.PI/2),h);v.scale.y=.65,v.position.y=f,d.add(p,v),d.position.set((a()-.5)*.8,0,(a()-.5)*.8),Vv(o,d)}o.scale.setScalar(.001),c.matureAt=9}else if(l==="fern"){const h=this.makeFernMesh(.9,42);c.foliage=h,o.add(h),o.scale.setScalar(.001),c.matureAt=12}return o.position.set(t,s-.02,e),o.rotation.y=a()*_e,this.group.add(o),this.plants.push(c),c.growth=0,c}restorePatchVisual(t,e,i){const n=$t(Math.floor(t*7+e*3)),s=new gt,o=this.terrain.heightAt(t,e),a=26,l=new It(.16,5,4),c=new Rs(l,this.mat.moss,a),h=new ue,u=new ct;for(let f=0;f<a;f++){const p=n()*_e,v=Math.sqrt(n())*i,m=t+Math.cos(p)*v,g=e+Math.sin(p)*v;h.position.set(Math.cos(p)*v,this.terrain.heightAt(m,g)-o+.02,Math.sin(p)*v),h.rotation.set(n()*3,n()*3,n()*3);const _=.7+n()*1.6;h.scale.set(_,_*.5,_),h.updateMatrix(),c.setMatrixAt(f,h.matrix);const M=.3+n()*.28;u.setRGB(M*.5,M,M*.32),c.setColorAt(f,u)}c.instanceMatrix.needsUpdate=!0,c.instanceColor&&(c.instanceColor.needsUpdate=!0),c.receiveShadow=!0,s.add(c);const d=new I(new hs(.5+n()*.3,0),new st({color:7827551,roughness:.9,flatShading:!0}));return d.position.set(i*.4,.2,-i*.3),d.rotation.set(n(),n(),n()),d.castShadow=!0,s.add(d),s.position.set(t,o,e),this.group.add(s),this.terrain.growMoss(t,e,i),s}surge(t){t&&(t.boost=(t.boost||0)+3.5)}findPlantNear(t,e=3){let i=null,n=1/0;return this.plants.forEach(s=>{if(!s.obj)return;const o=Math.hypot(s.obj.position.x-t.x,s.obj.position.z-t.z);o<n&&o<e&&(n=o,i=s)}),i}update(t,e,i){this.time+=e,Us.uTime.value=this.time,Us.uWind.value=t.wind;const n=t.night,s=t.golden,o=t.bioSpeed,a=e*(.08+o*.35);this.lifeTick=(this.lifeTick||0)+e;const l=this.lifeTick>.5;if(l&&(this.lifeTick=0),this.plants.forEach(h=>{if(l&&h.obj&&h.x!=null){const u=this.terrain.wetnessAt(h.x,h.z);h.wet=u;const d=u<.055,f=u>.88,p=h.type==="moss"||h.type==="mushroom"||h.type==="fern"||h.type==="reed";let v=0;d?v-=p?.04:.062:f&&!p?v-=.012:v+=.02,h.hp=ft((h.hp??1)+v),h.growth>=.98&&(h.type==="shrub"||h.type==="broadleaf"||h.type==="fern")&&(h.overgrowth=ft((h.overgrowth||0)+e*.012*(.4+h.hp)),h.overgrowth>.35&&(h.hp=ft(h.hp-e*.02)));const m=1-h.hp;if(h.wilts!==m){h.wilts=m;const g=[];h.obj.traverse(_=>{if(!_.isMesh||!_.material)return;(Array.isArray(_.material)?_.material:[_.material]).forEach(y=>{y&&y.color&&!y.userData.glowThing&&g.push(y)})}),h._baseTint||(h._baseTint=g.map(_=>_.color.clone())),g.forEach((_,M)=>{const y=h._baseTint[M];if(!y)return;const E=ft(m*1.6);_.color.copy(y).lerp(kv,E*.85).lerp(Gv,Math.max(0,m-.55)*1.4)})}if(h.hp<.45&&h.obj){const g=(.45-h.hp)*.9;h.obj.rotation.z=Math.sin(this.time*.7+(h.swayPhase||0))*.02+g*.35,(h.type==="shrub"||h.type==="broadleaf")&&h.obj.scale.setScalar(Math.max(.55,1-g*.28))}}if(h.obj&&h.growth<1){const u=a/(h.matureAt||20);h.growth=ft(h.growth+u+(h.boost||0)*e*.25),h.boost&&(h.boost=Math.max(0,h.boost-e*2));const d=Ie(0,1,h.growth);h.obj&&h.obj.scale.setScalar(h.type==="fern"?Lt(.45,1,d):Math.max(.001,d)),h.foliage&&h.type!=="fern"&&h.foliage.scale.setScalar(Math.max(.001,Ie(.25,.9,h.growth))),h.growth>=1&&(h.bloom=!0,this.state.emit("plantMature",h))}if(h.foliage&&(h.type==="broadleaf"||h.type==="conifer"||h.type==="shrub")){const u=h.phase??h.swayPhase??0;h.foliage.rotation.z=Math.sin(this.time*.8+u)*.02*t.wind,h.foliage.rotation.x=Math.cos(this.time*.6+u)*.018*t.wind}}),this.pruneTweens)for(let h=this.pruneTweens.length-1;h>=0;h--)this.pruneTweens[h].update(e),this.pruneTweens[h].done&&this.pruneTweens.splice(h,1);const c=n*(.6+Math.sin(this.time*1.7)*.12);this.mushroomMats.forEach(h=>{h.userData&&(h.emissiveIntensity=c*(h.userData.glowIntensity||1.6))}),this.flowerMats.forEach(h=>{h.emissiveIntensity=c*h.userData.glowIntensity*.9}),this.mushroomLight.intensity=c*1.1,this.treeLamp.intensity=n*.55,this.glowThings.forEach((h,u)=>{if(h.kind==="blossom"&&h.mat){const d=.5+.5*Math.sin(this.time*1.4+u);h.mat.emissiveIntensity=c*(.4+d*.9)}else h.kind==="leaf"&&h.obj&&h.obj.material&&(Array.isArray(h.obj.material)?h.obj.material:[h.obj.material]).forEach(f=>{f&&f.userData&&f.userData.night&&(f.emissiveIntensity=n*.04)})}),this.flowers.forEach(h=>{const u=h.userData.head;u&&(u.rotation.z=Math.sin(this.time*1.3+h.userData.phase)*.14*(.3+t.wind),u.rotation.x=Math.cos(this.time*1.1+h.userData.phase)*.1*(.3+t.wind))}),t.w.fog,this.group.traverse(h=>{h.isMesh&&h.material&&(Array.isArray(h.material)?h.material:[h.material]).forEach(d=>{d&&d.userData&&d.userData.night&&(d.userData.night.value=n)})}),this.mat.leaf.emissive&&(this.mat.leaf.emissive.setRGB(1,.7,.35),this.mat.leaf.emissiveIntensity=s*.06)}}function Vv(r,t){r.add(t)}function Lr(r=3){const e=Te(512,512),i=e.getContext("2d"),n=$t(r);i.fillStyle="#8a7f6a",i.fillRect(0,0,512,512);for(let s=0;s<420;s++){const o=n()*512,a=n()*512,l=12+n()*30,c=8+n()*20,h=90+n()*80;i.fillStyle=`rgb(${h},${h*.92},${h*.8})`,i.beginPath(),i.ellipse(o,a,l/2,c/2,n()*.6-.3,0,Math.PI*2),i.fill(),i.strokeStyle=`rgba(40,34,24,${.25+n()*.3})`,i.lineWidth=1+n(),i.stroke()}for(let s=0;s<700;s++)i.fillStyle=`rgba(${40+n()*40},${70+n()*50},${30+n()*30},${n()*.22})`,i.fillRect(n()*512,n()*512,1+n()*3,1+n()*3);return we(e,{repeat:[1,1]})}function Yc(){const t=Te(512,512),e=t.getContext("2d"),i=$t(17);e.fillStyle="#6a5731",e.fillRect(0,0,512,512);for(let n=0;n<5e3;n++){const s=i()*512,o=i()*512,a=10+i()*34,l=i();e.strokeStyle=l>.6?`rgba(${150+i()*50},${120+i()*40},${60+i()*30},0.35)`:`rgba(${50+i()*40},${40+i()*30},${18+i()*16},0.4)`,e.lineWidth=.8+i()*1.6,e.beginPath(),e.moveTo(s,o),e.lineTo(s+(i()-.5)*6,o+a),e.stroke()}return we(t,{repeat:[2,2]})}class Wv{constructor(t,e,i){this.scene=t,this.state=e,this.terrain=i,this.group=new gt,this.group.position.y=wt.glassBottomY+.32,t.add(this.group),this.rng=$t(77),this.time=0,this.buildCottage(),this.buildBridge(),this.buildLanterns(),this.buildMill(),this.buildRuins()}buildCottage(){const i=this.terrain.heightAt(9.6,-10.4),n=new gt;this.rng;const s=new st({map:Lr(4),color:13616299,roughness:.94}),o=new st({map:Yc(),color:12165750,roughness:.96,flatShading:!0}),a=new st({color:4863268,roughness:.85}),l=new st({color:2958360,roughness:.8}),c=new I(new ne(3.6,2.4,2.8),s);c.position.y=1.2,c.castShadow=!0,c.receiveShadow=!0,n.add(c);const h=new gt,u=new I(new Ft(2.7,2.9,.5,8),o);u.position.y=2.55,u.rotation.y=Math.PI/8,u.castShadow=!1,h.add(u);const d=new I(new ci(2.6,1.9,8),o);d.position.y=3.6,d.rotation.y=Math.PI/8,d.castShadow=!1,h.add(d);for(let F=0;F<8;F++){const et=F/8*Math.PI*2,X=new I(new It(.28,5,4),o);X.position.set(Math.cos(et)*2.5,2.85,Math.sin(et)*2.5),X.scale.y=.7,h.add(X)}n.add(h);const f=new I(new ne(.5,1.7,.5),s);f.position.set(1.1,4,-.6),f.castShadow=!1,n.add(f);const p=new I(new ne(.66,.18,.66),l);p.position.set(1.1,4.9,-.6),n.add(p);const v=new Bh,m=.5,g=.95;v.moveTo(-m,0),v.lineTo(-m,g),v.absarc(0,g,m,Math.PI,0,!0),v.lineTo(m,0),v.lineTo(-m,0);const _=new hl(v,8),M=new I(_,new st({color:3811864,roughness:.85}));M.position.set(-.5,0,1.405),n.add(M);const y=new I(new We(.5,.065,6,16,Math.PI),l);y.position.set(-.5,.95,1.41),n.add(y);for(let F=-1;F<=1;F+=2){const et=new I(new ne(.09,.95,.08),l);et.position.set(-.5+F*.52,.475,1.41),n.add(et)}const E=new I(new We(.52,.075,8,28),l);E.position.set(.85,1.5,1.41),n.add(E);const T=new st({color:1710610,emissive:16758622,emissiveIntensity:.6,roughness:.3}),x=new I(new si(.5,28),T);x.position.set(.85,1.5,1.4),n.add(x);for(let F=0;F<2;F++){const et=new I(new ne(.045,.98,.02),l);et.position.set(.85,1.5,1.42),et.rotation.z=F/2*Math.PI,n.add(et)}this.cottageWindow=T;const w=T.clone(),P=new I(new si(.26,16),w);P.position.set(-1.8,1.5,.2),P.rotation.y=-Math.PI/2,n.add(P),this.cottageWindow2=w;const C=new I(new ne(1.1,.16,.2),a);C.position.set(.85,.86,1.48),n.add(C);const U=$t(19),B=new st({color:16751280,emissive:16738960,emissiveIntensity:.15,roughness:.6});for(let F=0;F<8;F++){const et=new I(new It(.055,6,4),B);et.position.set(.4+F*.13,.98+U()*.1,1.49),n.add(et)}this.cottageFlowers=B,this.cottageLight=new Zi(16757598,0,16,0),this.cottageLight.position.set(.85,1.7,2.4),n.add(this.cottageLight);const V=new st({color:5850414,roughness:.9});for(let F=0;F<9;F++){const et=-4.4+F*.62,X=new I(new ne(.08,.6,.08),V),tt=2.6+Math.sin(F*2)*.1,it=this.terrain.heightAt(9.6+et,-10.4+tt)-i;X.position.set(et,it+.3,tt),n.add(X)}for(let F=0;F<2;F++){const et=new I(new ne(5.1,.05,.05),V);et.position.set(-1.9,.32+F*.22,2.6),n.add(et)}n.position.set(9.6,i-.05,-10.4),n.rotation.y=-.5;const D=[];n.traverse(F=>{F.isLight&&D.push(F),F.isMesh&&(F.material===T||F.material===w||F.material===B)&&D.push(F)});const H=new gt;n.children.slice().forEach(F=>{F.isLight||D.includes(F)||H.add(F)});const Y=ai(H,{castShadow:!0,receiveShadow:!0});Y&&(H.removeFromParent(),n.add(Y)),this.group.add(n),this.cottage=n,this.cottageY=i}buildBridge(){const t=this.terrain.streamCurve().getPointAt(.62),e=this.terrain.heightAt(t.x,t.z),i=new gt,n=new st({map:Lr(9),color:12103840,roughness:.93,flatShading:!0}),s=1.55;for(let c=0;c<9;c++){const h=Math.PI*(.12+c/8*.76),u=new I(new ne(.42,.34,1.9),n);u.position.set(Math.cos(h)*s,Math.sin(h)*s*.72+.35,0),u.rotation.z=h-Math.PI/2,u.castShadow=!1,u.receiveShadow=!0,i.add(u)}const o=new I(new ne(3.5,.14,1.9),n);o.position.set(0,1.3,0),o.castShadow=!1,i.add(o);for(let c=-1;c<=1;c+=2){const h=new I(new ne(3.4,.09,.09),n);h.position.set(0,1.62,c*.9),i.add(h);for(let u=0;u<5;u++){const d=new I(new ne(.1,.32,.1),n);d.position.set(-1.5+u*.75,1.46,c*.9),i.add(d)}}const a=ai(i,{castShadow:!0,receiveShadow:!0});a&&(i.clear(),i.add(a));const l=this.terrain.streamCurve().getTangentAt(.62);i.position.set(t.x,e,t.z),i.rotation.y=Math.atan2(l.x,l.z),this.group.add(i),this.bridge=i}buildLanterns(){this.lanterns=[];const t=[[5.6,2.4],[-2.6,10],[-10,-6.8]],e=new st({color:8020534,metalness:.85,roughness:.4}),i=new st({color:16771512,emissive:16760418,emissiveIntensity:.2,transparent:!0,opacity:.85,roughness:.2});t.forEach(([n,s],o)=>{const a=this.terrain.heightAt(n,s),l=new gt,c=new I(new Ft(.05,.075,2.3,7),e);c.position.y=1.15,c.castShadow=!1,l.add(c);const h=new I(new ci(.3,.3,6),e);h.position.y=2.75,l.add(h);const u=new I(new Ft(.17,.2,.4,6),i.clone());u.position.y=2.42,l.add(u);const d=new I(new We(.2,.025,4,12),e);d.rotation.x=Math.PI/2,d.position.y=2.2,l.add(d);const f=new I(new hs(.28,0),new st({color:7235672,roughness:.9,flatShading:!0}));f.position.y=.1,f.scale.y=.6,l.add(f);const p=new Zi(16758882,0,12,0);p.position.y=2.42,l.add(p),l.position.set(n,a,s),l.rotation.y=o*2.1;const v=new gt;[c,h,d,f].forEach(g=>{l.remove(g),v.add(g)});const m=ai(v,{castShadow:!1,receiveShadow:!0});m&&l.add(m),this.group.add(l),this.lanterns.push({group:l,light:p,glass:u,phase:o*2.4,base:a})})}buildMill(){const i=this.terrain.heightAt(-12.4,-8.6),n=new gt,s=new st({map:Lr(12),color:12892320,roughness:.94}),o=new st({color:5915177,roughness:.85}),a=new st({map:Yc(),color:11047528,roughness:.96,flatShading:!0}),l=new I(new Ft(.75,1.15,3.4,9),s);l.position.y=1.7,l.castShadow=!0,l.receiveShadow=!0,n.add(l);const c=new I(new ci(1,1.15,9),a);c.position.y=3.9,c.castShadow=!1,n.add(c);const h=new I(new ne(.4,.62,.1),o);h.position.set(0,.32,1),n.add(h);const u=new I(new si(.18,12),new st({color:1579536,emissive:16760944,emissiveIntensity:.4}));u.position.set(0,2.3,.82),u.rotation.x=-.14,n.add(u),this.millWindow=u.material;const d=new gt;d.position.set(0,3,1.02);const f=new I(new Ft(.07,.07,.3,6),o);f.rotation.x=Math.PI/2,d.add(f);const p=new gt;for(let g=0;g<4;g++){const _=new gt,M=new I(new ne(.07,2.4,.05),o);M.position.y=1.25,_.add(M);const y=new I(new be(.52,1.9),new st({color:13351832,roughness:.9,side:ae}));y.position.set(.3,1.5,0),_.add(y);for(let E=0;E<5;E++){const T=new I(new ne(.56,.03,.03),o);T.position.set(.3,.7+E*.4,.01),_.add(T)}_.rotation.z=g/4*Math.PI*2,p.add(_)}d.add(p),n.add(d),this.millSails=p;const v=new gt;[l,c,h].forEach(g=>{n.remove(g),v.add(g)});const m=ai(v,{castShadow:!0,receiveShadow:!0});m&&n.add(m),n.position.set(-12.4,i-.05,-8.6),n.rotation.y=.8,this.group.add(n),this.mill=n}buildRuins(){const t=new st({map:Lr(21),color:11577237,roughness:.95,flatShading:!0}),e=12.2,i=3.6,n=this.terrain.heightAt(e,i),s=new gt;for(let a=0;a<5;a++){const l=Math.PI*(.05+a/5*.4),c=new I(new ne(.5,.42,.8),t);c.position.set(Math.cos(l)*1.3,Math.sin(l)*1.15,0),c.rotation.z=l-Math.PI/2,c.castShadow=!1,c.receiveShadow=!0,s.add(c)}const o=$t(44);for(let a=0;a<4;a++){const l=new I(new ne(.4+o()*.3,.28,.5),t);l.position.set(1.2+o()*1.2,.14,(o()-.5)*1.4),l.rotation.set(o()*.4,o()*3,o()*.4),l.castShadow=!1,s.add(l)}s.position.set(e,n-.05,i),s.rotation.y=-1.1,this.group.add(s),this.ruins=s}update(t,e,i){this.time+=e;const n=t.night,s=t.w.cloud,o=ft(Math.max(n*1.15,s*.55,t.w.rain*.4)),a=.9+Math.sin(this.time*7.3)*.03+Math.sin(this.time*13.1)*.02;this.cottageWindow.emissiveIntensity=(.15+o*1.6)*a,this.cottageWindow2.emissiveIntensity=(.1+o*1.2)*a,this.cottageLight.intensity=o*1.1*a,this.millWindow.emissiveIntensity=.08+o*1.5,this.cottageFlowers.emissiveIntensity=o*.5,this.lanterns.forEach(l=>{const c=ft(n*1.2+t.w.fog*.5),h=.85+Math.sin(this.time*5.1+l.phase)*.1+Math.sin(this.time*11.7+l.phase*2)*.05;l.light.intensity=c*.8*h,l.glass.material.emissiveIntensity=.15+c*1.4*h}),this.millSails.rotation.z+=e*(.15+t.wind*1.6)}}const bn=Math.PI*2;function Ui(r,t=.9){return new st({color:r,roughness:t,metalness:0,flatShading:!0})}function oo(r=.05){const t=new st({color:657928,roughness:.25,metalness:.1}),e=new I(new It(r,8,6),t),i=new I(new It(r*.35,6,4),new li({color:16777215}));return i.position.set(r*.4,r*.4,r*.7),e.add(i),e}class ds{constructor(t,e,i={}){this.state=t,this.terrain=e,this.group=new gt,this.group.name=i.name||"creature",this.t=Math.random()*100,this.home=new Q(i.x??0,i.z??0),this.radius=i.radius??4,this.speed=i.speed??.5,this.currentTween=null,this.reacting=0,this.hopPhase=Math.random()*bn,this.dir=Math.random()*bn,this.pauseTimer=Math.random()*3,this.paused=!1,this.isCreature=!0,this.name=i.name||"creature",this.displayName=i.displayName||"Creature",this.phase=Math.random()*bn,this.baseScale=1,this.nightSleepy=i.nocturnal?1:0}placeOnTerrain(t=0,e=0){const i=this.position2?this.position2.x:this.home.x,n=this.position2?this.position2.y:this.home.y,s=this.terrain.heightAt(i,n);return this.group.position.set(i,s,n),s}updateCommon(t){this.t+=t,this.reacting=Math.max(0,this.reacting-t),this.currentTween&&(this.currentTween.update(t),this.currentTween.done&&(this.currentTween=null))}wander(t,{glide:e=.4,pauseChance:i=.6,activeMul:n=1}={}){if(this.reacting>0)return;const s=this.state.night,a=(1-(this.nightSleepy?s:0))*n*(.4+this.state.w.sun*.6);if(this.paused){this.pauseTimer-=t,this.pauseTimer<=0&&(this.paused=!1,this.dir=Math.random()*bn),this.group.rotation.y+=Math.sin(this.t*.7+this.phase)*t*.3;return}Math.random()<t*.25*(.5+i)&&(this.paused=!0,this.pauseTimer=1.5+Math.random()*4),this.position2||(this.position2=this.home.clone());const l=this.speed*a*e,c=Math.cos(this.dir)*l*t,h=Math.sin(this.dir)*l*t;let u=this.position2.x+c,d=this.position2.y+h;(Math.hypot(u-this.home.x,d-this.home.y)>this.radius||this.terrain.streamCarve(u,d)>.3)&&(this.dir+=Math.PI*(.6+Math.random()*.8)),this.position2.set(u,d);const p=this.terrain.heightAt(u,d);this.group.position.set(u,p,d);const v=-this.dir+Math.PI/2;this.group.rotation.y=Ee(this.group.rotation.y,v,3,t)}}class Xv extends ds{constructor(t,e,i){super(t,e,{...i,displayName:"Doe",speed:.45,radius:3.2,name:"deer"}),this.build(),this.group.children.forEach(n=>n.scale.multiplyScalar(3.4)),this.baseScale=1}build(){const t=Ui(11041362),e=Ui(7162414),i=Ui(14271648),n=this.group,s=new I(new It(.52,10,8),t);s.scale.set(1.05,.82,1.4),s.position.y=.78,s.castShadow=!1,n.add(s);for(let d=-1;d<=1;d+=2){const f=new I(new It(.32,8,6),t);f.position.set(d*.32,.68,-.42),f.scale.set(.9,1,1.1),f.castShadow=!1,n.add(f);const p=new I(new It(.26,8,6),t);p.position.set(d*.3,.78,.4),n.add(p)}const o=new I(new Ft(.17,.26,.72,7),t);o.position.set(0,1.18,.5),o.rotation.x=.42,n.add(o);const a=new gt;a.position.set(0,1.52,.76);const l=new I(new It(.23,10,8),t);l.scale.set(.8,.9,1.25),a.add(l);const c=new I(new It(.13,8,6),i);c.scale.set(.8,.75,1.5),c.position.set(0,-.07,.25),a.add(c);const h=new I(new It(.045,6,4),new st({color:2300436,roughness:.4}));h.position.set(0,-.05,.42),a.add(h);for(let d=-1;d<=1;d+=2){const f=oo(.045);f.position.set(d*.15,.06,.17),a.add(f);const p=new I(new ci(.1,.3,5),e);p.position.set(d*.19,.22,-.02),p.rotation.z=d*.55,p.rotation.x=-.2,a.add(p),this["ear"+(d>0?"R":"L")]=p}for(let d=-1;d<=1;d+=2){const f=new I(new Ft(.014,.026,.42,4),i);f.position.set(d*.1,.42,0),f.rotation.z=d*.35,f.rotation.x=-.15,a.add(f);const p=new I(new Ft(.01,.018,.2,4),i);p.position.set(d*.17,.53,.03),p.rotation.z=d*.9,a.add(p)}this.head=a,n.add(a),this.legs=[];for(let d=0;d<4;d++){const f=d<2?-1:1,p=d%2===0?.38:-.4,v=new gt,m=new I(new Ft(.055,.045,.42,5),t);m.position.y=-.21;const g=new I(new Ft(.04,.03,.4,5),e);g.position.y=-.6;const _=new I(new It(.045,5,4),new st({color:2366484,roughness:.6}));_.position.y=-.82,v.add(m,g,_),v.position.set(f*.28,.66,p),v.castShadow=!1,n.add(v),this.legs.push({leg:v,baseZ:p,side:f,phase:d*(Math.PI/2)})}const u=new I(new It(.1,6,4),i);u.position.set(0,.9,-.73),u.scale.set(.7,1.1,.7),n.add(u),this.tail=u,this.setPick()}setPick(){this.group.traverse(t=>{t.isMesh&&(t.userData.creature=this)})}idle(t){const e=this.t,i=Ie(.4,.9,Math.sin(e*.25+this.phase)*.5+.5);this.head&&(this.head.rotation.x=Lt(0,.85,i*(this.paused?1:.25))+Math.sin(e*1.3)*.03);const n=Math.sin(e*6.1)>.97?.5:0;this.earR&&(this.earR.rotation.z=.55+n),this.earL&&(this.earL.rotation.z=-.55-n*.5),this.tail&&(this.tail.rotation.x=Math.sin(e*3)*.25);const s=!this.paused&&this.reacting<=0;this.legs.forEach(({leg:o,phase:a})=>{s?o.rotation.x=Math.sin(e*6+a)*.32:o.rotation.x=Ee(o.rotation.x,0,6,t)}),s&&(this.group.position.y+=Math.sin(e*12)*.004)}react(){this.reacting=2.2,this.paused=!0,this.pauseTimer=2.4;const t=this.group.position.y;return this.currentTween=new Rn(.9,e=>{const i=Math.sin(e*Math.PI)*.55;this.group.position.y=t+i,this.head&&(this.head.rotation.x=-.35*Math.sin(e*Math.PI)),this.group.rotation.y+=Math.sin(e*Math.PI*2)*.02},()=>{this.group.position.y=this.terrain.heightAt(this.group.position.x,this.group.position.z),this.head&&(this.head.rotation.x=0)}),"The doe startles, then bows her head — as if apologising for the fright."}}class qv extends ds{constructor(t,e,i){super(t,e,{...i,displayName:"Fox",speed:1.1,radius:5.5,name:"fox",nocturnal:!1}),this.build(),this.group.children.forEach(n=>n.scale.multiplyScalar(2.6))}build(){const t=Ui(12865836),e=Ui(15721682),i=Ui(2891800),n=this.group,s=new I(new os(.22,.6,4,8),t);s.rotation.x=Math.PI/2,s.position.y=.42,s.castShadow=!1,n.add(s);const o=new I(new It(.22,8,6),e);o.position.set(0,.38,.32),o.scale.set(.9,1.1,.9),n.add(o);const a=new gt;a.position.set(0,.62,.48);const l=new I(new It(.17,8,6),t);l.scale.set(.95,.9,1.1),a.add(l);const c=new I(new ci(.09,.3,6),t);c.rotation.x=Math.PI/2,c.position.set(0,-.04,.24),a.add(c);const h=new I(new It(.04,5,4),i);h.position.set(0,-.04,.39),a.add(h);for(let p=-1;p<=1;p+=2){const v=new I(new ci(.09,.26,4),t);v.position.set(p*.11,.2,-.02),v.rotation.z=p*.2,a.add(v);const m=new I(new ci(.055,.18,4),i);m.position.set(p*.11,.19,.01),m.rotation.z=p*.2,a.add(m);const g=oo(.033);g.position.set(p*.1,.03,.12),a.add(g)}this.head=a,n.add(a),this.legs=[];for(let p=0;p<4;p++){const v=p<2?-1:1,m=new I(new Ft(.035,.03,.34,4),i);m.position.set(v*.13,.17,p%2===0?.28:-.26),n.add(m),this.legs.push(m)}const u=new gt;u.position.set(0,.45,-.52);const d=new I(new os(.1,.55,4,6),t);d.rotation.x=-.9,d.position.z=-.3,u.add(d);const f=new I(new It(.1,6,4),e);f.position.set(0,.13,-.62),u.add(f),this.tail=u,n.add(u),this.group.traverse(p=>{p.isMesh&&(p.userData.creature=this)})}idle(t){const e=this.t;this.tail&&(this.tail.rotation.y=Math.sin(e*2.6)*.4,this.tail.rotation.z=Math.sin(e*1.7)*.12),this.head&&(this.head.rotation.y=Math.sin(e*.8+this.phase)*.35*(this.paused?1:.3),this.head.rotation.x=Math.sin(e*1.9)*.06);const i=!this.paused&&this.reacting<=0;this.legs.forEach((n,s)=>{n.rotation.x=i?Math.sin(e*10+s*Math.PI/2)*.5:Ee(n.rotation.x,0,6,t)})}react(){this.reacting=2,this.paused=!0,this.pauseTimer=2;const t=this.group.position.y;return this.currentTween=new Rn(1.1,e=>{this.group.position.y=t+Math.abs(Math.sin(e*Math.PI*2))*.24,this.group.rotation.y+=e*.4},()=>{this.group.position.y=this.terrain.heightAt(this.group.position.x,this.group.position.z)}),"The fox spins a tight circle, tail alight, then sits as though nothing happened."}}class Vo extends ds{constructor(t,e,i){super(t,e,{...i,displayName:"Rabbit",speed:1,radius:3.4,name:"rabbit"}),this.build(),this.group.children.forEach(n=>n.scale.multiplyScalar(2.4))}build(){const t=Ui(9075302),e=Ui(13483944),i=this.group,n=new I(new It(.2,8,6),t);n.scale.set(.9,.85,1.2),n.position.y=.2,n.castShadow=!1,i.add(n);const s=new gt;s.position.set(0,.32,.18);const o=new I(new It(.15,8,6),t);s.add(o);for(let c=-1;c<=1;c+=2){const h=new I(new os(.035,.24,3,5),t);h.position.set(c*.06,.24,-.03),h.rotation.z=c*.18,h.rotation.x=-.15,s.add(h),this["ear"+(c>0?"R":"L")]=h;const u=oo(.028);u.position.set(c*.09,.03,.1),s.add(u)}const a=new I(new It(.025,5,4),new st({color:13208192,roughness:.5}));a.position.set(0,-.02,.15),s.add(a),this.head=s,i.add(s);const l=new I(new It(.07,6,4),e);l.position.set(0,.22,-.24),i.add(l),this.tail=l,this.group.traverse(c=>{c.isMesh&&(c.userData.creature=this)})}idle(t){const e=this.t;if(this.paused){const n=Math.abs(Math.sin(e*2.2))*.05;this.group.position.y=this.terrain.heightAt(this.group.position.x,this.group.position.z)+n}this.head.rotation.y=Math.sin(e*1.4+this.phase)*.4;const i=Math.sin(e*9)>.9?.3:0;this.earL.rotation.x=-.15+i,this.earR.rotation.x=-.15-i*.7,this.tail&&(this.tail.rotation.x=Math.sin(e*4)*.2)}react(){this.reacting=1.6;const t=this.terrain.heightAt(this.group.position.x,this.group.position.z);return this.currentTween=new Rn(1.2,e=>{this.group.position.y=t+Math.abs(Math.sin(e*Math.PI*3))*.32,this.group.rotation.y+=.1},()=>{this.group.position.y=t}),"The rabbit thumps the soil three times, ears tall, then bolts a hop and a half."}}class Dr extends ds{constructor(t,e,i){super(t,e,{...i,displayName:"Songbird",speed:0,radius:0,name:"bird"}),this.build(i.palette),this.perch=new R(i.px,i.py,i.pz),this.group.position.copy(this.perch),this.flying=!1,this.flyT=0,this.flyFrom=new R,this.flyTo=new R,this.singPhase=Math.random()*bn}build(t=0){this.birdPalette=t,this.scaleGroup=new gt,this.group.add(this.scaleGroup);const e=this.scaleGroup,i=[5930928,13145146,9062970][t%3],n=Ui(i,.75),s=Ui(14273972,.8),o=new st({color:14262846,roughness:.5}),a=new I(new It(.11,8,6),n);a.scale.set(.9,.95,1.25),a.castShadow=!1,e.add(a);const l=new I(new It(.08,6,5),s);l.position.set(0,-.03,.04),l.scale.set(.9,.8,1.1),e.add(l);const c=new gt;c.position.set(0,.1,.08);const h=new I(new It(.075,8,6),n);c.add(h);const u=new I(new ci(.025,.09,4),o);u.rotation.x=Math.PI/2,u.position.set(0,-.01,.1),c.add(u);for(let f=-1;f<=1;f+=2){const p=oo(.016);p.position.set(f*.05,.015,.045),c.add(p)}this.head=c,e.add(c),this.wings=[];for(let f=-1;f<=1;f+=2){const p=new I(new It(.1,6,4),n);p.scale.set(1.3,.18,.8),p.position.set(f*.11,.02,-.02),e.add(p),this.wings.push(p)}const d=new I(new ci(.05,.16,4),n);d.rotation.x=-Math.PI/2,d.position.set(0,.01,-.15),e.add(d);for(let f=-1;f<=1;f+=2){const p=new I(new Ft(.008,.008,.06,3),o);p.position.set(f*.04,-.11,.02),e.add(p)}this.scaleGroup.scale.setScalar(2.6),this.group.traverse(f=>{f.isMesh&&(f.userData.creature=this)})}idle(t){const e=this.t;if(this.flying){this.flyT+=t;const n=ft(this.flyT/1.6),s=Ie(0,1,n),o=Math.sin(s*Math.PI)*1.8;this.group.position.lerpVectors(this.flyFrom,this.flyTo,s),this.group.position.y+=o,this.wings.forEach((a,l)=>{a.rotation.z=Math.sin(e*30+l*Math.PI)*.9}),n>=1&&(this.flying=!1,this.perch.copy(this.flyTo),this.group.position.copy(this.perch),this.wings.forEach(a=>a.rotation.z=0));return}const i=Math.sin(e*2.4+this.singPhase);this.group.position.y=this.perch.y+Math.max(0,i)*.012,this.group.rotation.y=Math.sin(e*.5+this.singPhase)*.5,this.head.rotation.x=Math.sin(e*1.6+this.singPhase)*.1,i>.7&&(this.head.rotation.y=Math.sin(e*14)*.2),Math.random()<t*.045&&this.state.night<.4&&(this.flyTo.set(this.perch.x+(Math.random()-.5)*4,this.perch.y+(Math.random()-.3)*1.2,this.perch.z+(Math.random()-.5)*4),this.flyFrom.copy(this.perch),this.flying=!0,this.flyT=0)}react(){return this.flying=!0,this.flyT=0,this.flyFrom.copy(this.group.position),this.flyTo.set(this.perch.x+(Math.random()-.5)*5,this.perch.y+.6+Math.random()*1,this.perch.z+(Math.random()-.5)*5),"The bird startles into the air, scolding, then settles on a higher twig."}}class Wo extends ds{constructor(t,e,i){super(t,e,{...i,displayName:"Frog",speed:.25,radius:1.8,name:"frog"}),this.build(),this.group.children.forEach(n=>n.scale.multiplyScalar(3))}build(){const t=new st({color:6261314,roughness:.45,metalness:.05,flatShading:!0}),e=new st({color:12767124,roughness:.5}),i=this.group,n=new I(new It(.14,8,6),t);n.scale.set(1,.75,1.2),n.position.y=.1,n.castShadow=!1,i.add(n);const s=new I(new It(.11,6,5),e);s.position.set(0,.06,.03),s.scale.set(.95,.55,1.05),i.add(s);for(let o=-1;o<=1;o+=2){const a=new I(new It(.045,6,5),t);a.position.set(o*.07,.19,.06),i.add(a);const l=new I(new It(.026,6,4),new st({color:14266682,roughness:.3}));l.position.set(o*.07,.2,.09),i.add(l);const c=new I(new It(.014,4,3),new st({color:657925}));c.position.set(o*.07,.2,.112),i.add(c)}for(let o=-1;o<=1;o+=2){const a=new I(new It(.06,5,4),t);a.position.set(o*.13,.08,-.08),i.add(a)}this.group.traverse(o=>{o.isMesh&&(o.userData.creature=this)})}idle(t){const e=this.t,i=.92+Math.sin(e*6)*.08;this.group.scale.y=i,this.paused&&(this.group.position.y=this.terrain.heightAt(this.group.position.x,this.group.position.z)+.015)}react(){this.reacting=1.4;const t=this.terrain.heightAt(this.group.position.x,this.group.position.z);return this.currentTween=new Rn(.9,e=>{this.group.position.y=t+Math.sin(e*Math.PI)*.4,this.group.scale.set(1,1+Math.sin(e*Math.PI)*.15,1),this.position2&&(this.position2.x+=Math.cos(this.dir)*.012,this.position2.y+=Math.sin(this.dir)*.012)},()=>{this.group.scale.set(1,1,1)}),"The frog kicks off in a tidy arc and lands with an indignant plop."}}class $c extends ds{constructor(t,e,i){super(t,e,{...i,displayName:"Snail",speed:.06,radius:1.4,name:"snail"}),this.build(),this.group.children.forEach(n=>n.scale.multiplyScalar(2.8)),this.specks=[]}build(){const t=new st({color:10254926,roughness:.5,metalness:.1}),e=new st({color:9077862,roughness:.6}),i=this.group,n=new I(new os(.05,.22,4,6),e);n.rotation.x=Math.PI/2,n.position.set(0,.05,.02),i.add(n);const s=new I(new We(.09,.045,8,16),t);s.position.set(0,.13,-.05),i.add(s);const o=new I(new It(.05,8,6),t);o.position.set(0,.13,-.05),i.add(o);for(let a=-1;a<=1;a+=2){const l=new I(new Ft(.008,.012,.1,4),e);l.position.set(a*.03,.11,.14),l.rotation.x=.3,i.add(l);const c=new I(new It(.017,5,4),new st({color:1710612,roughness:.3}));c.position.set(a*.035,.16,.155),i.add(c)}this.group.traverse(a=>{a.isMesh&&(a.userData.creature=this)})}idle(t){const e=this.t;this.group.scale.y=1+Math.sin(e*3)*.02}react(){this.reacting=1.6;const t=this.group.scale.y;return this.currentTween=new Rn(.6,e=>{this.group.scale.y=t*(1-e*.5),this.group.scale.x=t*(1+e*.2)},()=>{this.group.scale.set(1,.5,1)}),setTimeout(()=>{this.currentTween=new Rn(1.2,e=>{this.group.scale.y=Lt(.5,1,e),this.group.scale.x=Lt(1.2,1,e)})},700),"The snail retracts, thinks it over, and slowly unfurls again."}}class Yv{constructor(t,e,i,n,s={}){this.scene=t,this.state=e,this.terrain=i,this.flora=n,this.list=[],this.group=new gt,this.group.position.y=wt.glassBottomY+.32,this.group.name="creatures",t.add(this.group);const o=s.quality||"high",a=c=>{const h=[c.group];for(;h.length;){const u=h.pop(),d=u.children.filter(f=>f.isMesh||f.isGroup);if(d.length>1&&u!==c.group){const f=ai(u,{castShadow:!0,receiveShadow:!0});if(f){const p=u.children.filter(v=>v.isMesh&&v.userData.keep);u.clear(),u.add(f),p.forEach(v=>u.add(v));continue}}d.forEach(f=>{f.isGroup&&h.push(f)})}},l=c=>{this.group.add(c.group),this.list.push(c);const h=new Q(c.home.x,c.home.y);c.position2=h.clone(),c.group.position.set(h.x,i.heightAt(h.x,h.y),h.y),c.group.rotation.y=Math.random()*bn,c.dir=Math.random()*bn;try{a(c)}catch{}};l(new Xv(e,i,{x:-1.2,z:-7.8,radius:3.4})),l(new qv(e,i,{x:8.2,z:1.2,radius:6.5})),l(new Vo(e,i,{x:-2.4,z:5.6,radius:3})),l(new Vo(e,i,{x:4.6,z:-3.2,radius:2.8})),l(new Vo(e,i,{x:-9.2,z:6.8,radius:2.6})),l(new Wo(e,i,{x:6.4,z:6.6,radius:1.6})),l(new Wo(e,i,{x:-5.9,z:-5,radius:1.4})),l(new $c(e,i,{x:-4,z:4.4,radius:1.6})),o!=="low"&&(l(new Dr(e,i,{x:0,z:0,px:-6.2,py:wt.glassBottomY+8.6,pz:-7,palette:0})),l(new Dr(e,i,{x:0,z:0,px:6.9,py:wt.glassBottomY+7.4,pz:-6.4,palette:1}))),l(new Dr(e,i,{x:0,z:0,px:-11,py:wt.glassBottomY+6,pz:-7.8,palette:2})),this.time=0}getPickables(){const t=[];return this.group.traverse(e=>{e.isMesh&&e.userData.creature&&t.push(e)}),t}getProxies(){if(!this.proxies){this.proxies=[];const t=new It(1,8,6),e=new li({visible:!1});this.list.forEach(i=>{const n=new I(t,e),s=i.name==="deer"?2.6:i.name==="fox"?1.9:i.name==="bird"?1.1:1.3;n.scale.setScalar(s),n.userData.creature=i,n.userData.isProxy=!0,this.group.add(n),this.proxies.push(n)})}return this.proxies.forEach(t=>{const e=t.userData.creature;t.position.copy(e.group.position),t.position.y+=e.name==="bird"?.1:.9}),this.proxies}update(t,e){this.time+=t;const i=this.state,n=i.w.rain,s=i.snowAccum??i.w.snow??0,o=i.wind??i.w.wind??0,a=ft(n*.7+Math.max(0,o-.55)*1.2),l=ft(s*1.1);this.list.forEach(c=>{c.updateCommon(t),c.shelter=Ee(c.shelter??0,a,.9,t),c.chill=Ee(c.chill??0,l,.6,t);const h=c.shelter;if(c instanceof Dr){c.idle(t);const u=1-h*.07-c.chill*.04;c.group.scale.y=Ee(c.group.scale.y,u,2.5,t),c.weatherTuck=h}else if(c instanceof Wo)c.wander(t,{glide:.6+n*1.3,pauseChance:.2}),c.idle(t),c.group.scale.y=Ee(c.group.scale.y,1-h*.05,2.5,t);else{const u=(1-h*.75)*(1-c.chill*.35);c.wander(t,{glide:u,pauseChance:.6+h*.35}),c.idle(t),c instanceof $c||(c.group.scale.y=Ee(c.group.scale.y,1-h*.06-c.chill*.03,2.5,t))}})}}const Ge=Math.PI*2;class $v{constructor(t,e){this.state=e,this.W=1024,this.H=512,this.canvas=Te(this.W,this.H),this.ctx=this.canvas.getContext("2d"),this.tex=we(this.canvas,{repeat:[1,1]}),this.tex.wrapS=En,this.tex.wrapT=Ii,this.drops=[],this.wipeMask=null,this.maskDirty=!0,this.dirty=!0,this.lastDraw=0,this.drawInterval=1/24;const i=wt.glassRadius*.995,n=wt.glassHeight*.97,s=new Ft(i,i,n,64,1,!0),o=new qs({map:this.tex,transparent:!0,opacity:.9,roughness:.42,metalness:0,side:cn,depthWrite:!1,color:14675688,emissive:16777215,emissiveMap:this.tex,emissiveIntensity:.035,alphaMap:this.tex});o.onBeforeCompile=l=>{l.fragmentShader=l.fragmentShader.replace("#include <dithering_fragment>",`#include <dithering_fragment>
         gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.82, 0.88, 0.86), 0.35);`)},this.mesh=new I(s,o),this.mesh.position.y=wt.glassBottomY+.6+n/2,this.mesh.renderOrder=4,this.mesh.visible=!1,t.add(this.mesh),this.baseFog=0,this.tint=new ct(16777215);const a=$t(42);for(let l=0;l<340;l++)this.drops.push(this.newDrop(a,!0));this.initWipeMask()}newDrop(t=Math.random,e=!1){return{u:t(),v:e?t():.9+t()*.15,r:1.2+t()*t()*4.6,speed:.006+t()*.03,wobble:t()*Ge,trail:0,life:0,slide:t()<.28}}initWipeMask(){const t=Te(this.W,this.H),e=t.getContext("2d");e.fillStyle="#fff",e.fillRect(0,0,this.W,this.H),this.wipeMask=t,this.maskCtx=e}wipeAt(t,e,i=46,n=.85){const s=this.maskCtx;s.globalCompositeOperation="destination-out";const o=t*this.W,a=(1-e)*this.H,l=s.createRadialGradient(o,a,0,o,a,i);l.addColorStop(0,`rgba(0,0,0,${n})`),l.addColorStop(.6,`rgba(0,0,0,${n*.6})`),l.addColorStop(1,"rgba(0,0,0,0)"),s.fillStyle=l,s.beginPath(),s.arc(o,a,i,0,Ge),s.fill(),this.drops.forEach(c=>{const h=Math.abs(c.u-t),u=Math.abs(c.v-e);Math.hypot(h*this.W,u*this.H)<i*1.4&&(c.life=1e-4)}),this.dirty=!0}update(t,e){const i=t.condensation;if(this.mesh.visible=i>.015,!this.mesh.visible){this.maskDirty!=="regen"&&this.regenMask(e,.5);return}this.regenMask(e,i);const n=t.w.rain,s=Math.floor(40+i*260+n*70);for(;this.drops.length<s;)this.drops.push(this.newDrop());this.drops.length>s&&(this.drops.length=s);const o=Math.random;this.drops.forEach(a=>{a.life=Math.min(1,a.life+e*2),a.slide?(a.v-=a.speed*e*(.6+i*1.4),a.u+=Math.sin(a.v*22+a.wobble)*6e-4*e*60,a.trail=Math.min(1,a.trail+e*2),a.v<.02&&Object.assign(a,this.newDrop(o))):(a.r+=e*.15,a.r>5.4&&(a.r=1.2,a.life=0))}),this.lastDraw+=e,!(this.lastDraw<this.drawInterval)&&(this.lastDraw=0,this.draw(t),this.mesh.material.color.copy(t.ambientTint||this.tint))}regenMask(t,e){const i=this.maskCtx;if(e<=.02)return;const n=Math.random,s=Math.ceil(e*16);for(let o=0;o<s;o++){const a=n()*this.W,l=n()*this.H,c=10+n()*40,h=i.createRadialGradient(a,l,0,a,l,c);h.addColorStop(0,`rgba(255,255,255,${.06*e})`),h.addColorStop(1,"rgba(255,255,255,0)"),i.globalCompositeOperation="source-over",i.fillStyle=h,i.beginPath(),i.arc(a,l,c,0,Ge),i.fill()}}draw(t){const e=this.ctx,i=this.W,n=this.H;e.globalCompositeOperation="source-over",e.clearRect(0,0,i,n);const s=t.condensation,o=this.fogCanvas||(this.fogCanvas=Te(i,n)),a=o.getContext("2d");a.clearRect(0,0,i,n);const l=$t(Math.floor(t.elapsed*.5)+7);for(let h=0;h<46;h++){const u=l()*i,d=l()*n,f=40+l()*150,p=a.createRadialGradient(u,d,0,u,d,f),v=.05+l()*.12;p.addColorStop(0,`rgba(255,255,255,${v})`),p.addColorStop(.7,`rgba(255,255,255,${v*.5})`),p.addColorStop(1,"rgba(255,255,255,0)"),a.fillStyle=p,a.beginPath(),a.arc(u,d,f,0,Ge),a.fill()}const c=a.createLinearGradient(0,n,0,n*.2);c.addColorStop(0,"rgba(255,255,255,0.22)"),c.addColorStop(1,"rgba(255,255,255,0)"),a.fillStyle=c,a.fillRect(0,0,i,n),a.globalCompositeOperation="destination-in",a.drawImage(this.wipeMask,0,0),a.globalCompositeOperation="source-over",e.globalAlpha=ft(s*1.35,0,.92),e.drawImage(o,0,0),e.globalAlpha=1,this.drops.forEach(h=>{if(h.life<=.01)return;const u=h.u*i,d=(1-h.v)*n,f=h.r*(.6+h.life*.4);if(h.slide&&h.trail>.05){const v=f*5*h.trail,m=e.createLinearGradient(0,d,0,d+v);m.addColorStop(0,"rgba(235,245,245,0.30)"),m.addColorStop(1,"rgba(235,245,245,0)"),e.strokeStyle=m,e.lineWidth=f*.75,e.beginPath(),e.moveTo(u,d),e.lineTo(u+Math.sin(h.wobble)*2,d+v),e.stroke()}const p=e.createRadialGradient(u-f*.3,d-f*.35,f*.1,u,d,f);p.addColorStop(0,"rgba(255,255,255,0.85)"),p.addColorStop(.55,"rgba(220,235,232,0.35)"),p.addColorStop(1,"rgba(200,220,218,0.05)"),e.fillStyle=p,e.beginPath(),e.ellipse(u,d,f,f*1.18,0,0,Ge),e.fill(),e.fillStyle="rgba(255,255,255,0.9)",e.beginPath(),e.arc(u-f*.35,d-f*.45,f*.18,0,Ge),e.fill()}),this.tex.needsUpdate=!0}projectHit(t,e){const i=e.worldToLocal(t.clone()),n=wt.glassBottomY+.6,s=wt.glassHeight*.97,o=ft((i.y-n)/s,0,1);let a=Math.atan2(i.z,i.x)/Ge;return a<0&&(a+=1),{u:1-a,v:o}}}function bs(r,{size:t=1,map:e,color:i=16777215,transparent:n=!0,blending:s=Yi,opacity:o=1}){const a=new de,l=new Float32Array(r*3),c=new Float32Array(r);for(let d=0;d<r;d++)c[d]=Math.random();a.setAttribute("position",new ee(l,3)),a.setAttribute("aSeed",new ee(c,1));const h=new rl({size:t,map:e,color:i,transparent:n,blending:s,opacity:o,depthWrite:!1,sizeAttenuation:!0,alphaTest:.001}),u=new Gs(a,h);return u.frustumCulled=!1,u}class Kv{constructor(t,e,i,n,s,o={}){this.scene=t,this.state=e,this.terrarium=i,this.terrain=n,this.lighting=s,this.low=o.quality==="low",this.group=new gt,this.group.name="atmosphere",t.add(this.group),this.sprites={rain:we(rn(64,null,null,[[0,"rgba(255,255,255,0.9)"],[.25,"rgba(210,230,245,0.35)"],[1,"rgba(200,220,240,0)"]])),snow:we(rn(64,null,null,[[0,"rgba(255,255,255,1)"],[.4,"rgba(255,255,255,0.75)"],[1,"rgba(255,255,255,0)"]])),mist:we(rn(128,null,null,[[0,"rgba(255,255,255,0.45)"],[.55,"rgba(255,255,255,0.14)"],[1,"rgba(255,255,255,0)"]])),glow:we(rn(64,null,null,[[0,"rgba(255,250,220,1)"],[.3,"rgba(255,235,170,0.6)"],[1,"rgba(255,220,130,0)"]])),dust:we(rn(64,null,null,[[0,"rgba(255,255,255,0.85)"],[.5,"rgba(255,255,255,0.25)"],[1,"rgba(255,255,255,0)"]]))};const a=this.low?.45:1;this.buildOutdoorRain(a),this.buildSnow(a),this.buildMist(a),this.buildFireflies(),this.buildInteriorRain(a),this.buildInteriorMotes(),this.buildLidSteam(),this.glassCond=new $v(this.terrarium.group,e),this.condUniform={value:0}}buildOutdoorRain(t){const e=Math.floor(900*t);this.outRain=bs(e,{size:.09,map:this.sprites.rain,opacity:0,blending:Ne,color:12571874}),this.outRainData=[];for(let i=0;i<e;i++)this.outRainData.push({x:(Math.random()-.5)*150,y:Math.random()*70,z:(Math.random()-.5)*140-10,v:26+Math.random()*20});this.group.add(this.outRain)}buildInteriorRain(t){const e=Math.floor(260*t);this.inRain=bs(e,{size:.055,map:this.sprites.rain,opacity:0,blending:Ne,color:13624558}),this.inRainData=[],this.resetInRain(!0),this.group.add(this.inRain)}resetInRain(t=!1){const e=wt.glassRadius*.86;this.inRainData=this.inRainData.length?this.inRainData:[];const i=this.inRain.geometry.attributes.position.count;for(;this.inRainData.length<i;)this.inRainData.push({});for(let n=0;n<i;n++){const s=this.inRainData[n],o=Math.random()*Ge,a=Math.sqrt(Math.random())*e;s.x=Math.cos(o)*a,s.z=Math.sin(o)*a,s.y=t?Math.random()*26:26+Math.random()*4,s.v=6+Math.random()*5}}buildSnow(t){const e=Math.floor(700*t);this.snow=bs(e,{size:.14,map:this.sprites.snow,opacity:0,color:15923195}),this.snowData=[];for(let i=0;i<e;i++)this.snowData.push({x:(Math.random()-.5)*150,y:Math.random()*70,z:(Math.random()-.5)*140-10,v:1.6+Math.random()*2.4,p:Math.random()*Ge,s:.4+Math.random()*1.4});this.group.add(this.snow)}buildMist(t){this.mistGroup=new gt,this.group.add(this.mistGroup),this.mistLayers=[];const e=this.low?9:16,i=new be(1,1);for(let n=0;n<e;n++){const s=new li({map:this.sprites.mist,transparent:!0,opacity:0,depthWrite:!1,color:14674146,blending:Yi}),o=new I(i,s);o.rotation.x=-Math.PI/2;const a=Math.random()*Ge,l=Math.sqrt(Math.random())*26;o.position.set(Math.cos(a)*l,16+Math.random()*6,Math.sin(a)*l),o.scale.setScalar(8+Math.random()*10),o.userData={drift:.1+Math.random()*.25,phase:Math.random()*Ge,baseY:o.position.y,baseOp:.16+Math.random()*.2},this.mistLayers.push(o),this.mistGroup.add(o)}}buildFireflies(){const t=this.low?26:54,e=new de,i=new Float32Array(t*3),n=new Float32Array(t),s=$t(5);this.ffHome=[];for(let a=0;a<t;a++){const l=s()*Ge,c=Math.sqrt(s())*(wt.soilRadius-2),h=Math.cos(l)*c,u=Math.sin(l)*c,d=wt.glassBottomY+2+s()*16;i[a*3]=h,i[a*3+1]=d,i[a*3+2]=u,n[a]=s(),this.ffHome.push({x:h,y:d,z:u,phase:s()*Ge,speed:.2+s()*.5})}e.setAttribute("position",new ee(i,3)),e.setAttribute("aSeed",new ee(n,1));const o=new Qe({transparent:!0,depthWrite:!1,blending:Ne,uniforms:{uTime:{value:0},uMap:{value:this.sprites.glow},uOpacity:{value:0},uColor:{value:new ct("#ffe9a8")},uScale:{value:Math.min(window.devicePixelRatio||1,2)}},vertexShader:`
        attribute float aSeed;
        varying float vGlow;
        uniform float uTime, uScale, uOpacity;
        void main() {
          vec3 p = position;
          float t = uTime * (0.25 + aSeed * 0.4);
          p.x += sin(t * 1.3 + aSeed * 20.0) * 1.6;
          p.y += sin(t * 0.9 + aSeed * 40.0) * 1.1;
          p.z += cos(t * 1.1 + aSeed * 30.0) * 1.6;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          float blink = pow(0.5 + 0.5 * sin(uTime * (1.2 + aSeed * 2.0) + aSeed * 30.0), 3.0);
          vGlow = blink;
          gl_PointSize = (2.0 + blink * 5.0) * uScale * (30.0 / -mv.z) * (0.5 + uOpacity);
        }`,fragmentShader:`
        varying float vGlow;
        uniform sampler2D uMap; uniform vec3 uColor; uniform float uOpacity;
        void main() {
          vec4 t = texture2D(uMap, gl_PointCoord);
          float a = t.a * vGlow * uOpacity;
          if (a < 0.003) discard;
          gl_FragColor = vec4(uColor * (1.0 + vGlow), a);
        }`});this.fireflies=new Gs(e,o),this.fireflies.frustumCulled=!1,this.group.add(this.fireflies),this.fireflyLight=new Zi(16772778,0,26,0),this.group.add(this.fireflyLight)}buildInteriorMotes(){const t=this.low?80:160;this.motes=bs(t,{size:.028,map:this.sprites.dust,color:16773840,opacity:.3,blending:Ne}),this.moteData=[];for(let e=0;e<t;e++){const i=Math.random()*Ge,n=Math.sqrt(Math.random())*wt.soilRadius;this.moteData.push({x:Math.cos(i)*n,y:wt.glassBottomY+1+Math.random()*24,z:Math.sin(i)*n,p:Math.random()*Ge})}this.group.add(this.motes)}buildLidSteam(){const t=this.low?40:90;this.steam=bs(t,{size:.5,map:this.sprites.mist,opacity:0,color:14279901,blending:Yi}),this.steamData=[];for(let e=0;e<t;e++)this.steamData.push({a:Math.random()*Ge,r:Math.random()*5,y:Math.random(),life:Math.random(),speed:.15+Math.random()*.2});this.group.add(this.steam),this.steamGroup=this.steam}wipe(t){const e=this.glassCond.projectHit(t,this.terrarium.group);return this.glassCond.wipeAt(e.u,e.v),e}get condensationTexture(){return this.glassCond.tex}update(t,e){const i=this.state,n=i.elapsed;e.position.y;const s=i.w.rain,o=i.w.snow,a=i.w.fog,l=i.night,c=ft(s*.55)*(1-i.lidOpen*0);if(this.outRain.material.opacity=c,this.outRain.visible=c>.01,this.outRain.visible){const v=this.outRain.geometry.attributes.position.array;for(let m=0;m<this.outRainData.length;m++){const g=this.outRainData[m];g.y-=g.v*t,g.y<-2&&(g.y=60+Math.random()*15,g.x=(Math.random()-.5)*150,g.z=(Math.random()-.5)*140-10),v[m*3]=g.x,v[m*3+1]=g.y,v[m*3+2]=g.z}this.outRain.geometry.attributes.position.needsUpdate=!0}const u=i.lidOpen*ft(s*1.2+.05)*.9;if(this.inRain.material.opacity=u,this.inRain.visible=u>.02,this.inRain.visible){const v=this.inRain.geometry.attributes.position.array;for(let m=0;m<this.inRainData.length;m++){const g=this.inRainData[m];if(g.y-=g.v*t,g.y<wt.glassBottomY+.5){const _=Math.random()*Ge,M=Math.sqrt(Math.random())*wt.glassRadius*.6;g.x=Math.cos(_)*M,g.z=Math.sin(_)*M,g.y=26+Math.random()*3}v[m*3]=g.x,v[m*3+1]=g.y,v[m*3+2]=g.z}this.inRain.geometry.attributes.position.needsUpdate=!0}if(this.snow.material.opacity=ft(o*.95),this.snow.visible=o>.02,this.snow.visible){const v=this.snow.geometry.attributes.position.array;for(let m=0;m<this.snowData.length;m++){const g=this.snowData[m];g.y-=g.v*t,g.p+=t*g.s,g.y<-1&&(g.y=60+Math.random()*15),v[m*3]=g.x+Math.sin(g.p)*2.2,v[m*3+1]=g.y,v[m*3+2]=g.z+Math.cos(g.p*.7)*2.2}this.snow.geometry.attributes.position.needsUpdate=!0}this.mistGroup.visible=a>.02||i.w.rain>.2,this.mistLayers.forEach((v,m)=>{const g=v.userData;v.material.opacity=Ee(v.material.opacity,(a*g.baseOp*.9+s*.05)*(1-l*.45),2,t),v.position.y=g.baseY+Math.sin(n*.2+g.phase)*.8,v.position.x+=Math.sin(n*.05+g.phase)*t*g.drift*2,v.position.z+=Math.cos(n*.06+g.phase*1.7)*t*g.drift*2,v.rotation.z=Math.sin(n*.04+m)*.4,v.scale.x,Math.abs(v.position.x)>34&&(v.position.x*=-.95),Math.abs(v.position.z)>34&&(v.position.z*=-.95)});const d=ft(l*1.2)*(1-ft(a*.4));if(this.fireflies.material.uniforms.uTime.value=n,this.fireflies.material.uniforms.uOpacity.value=d,this.fireflies.visible=d>.02,this.fireflies.visible){this.fireflyLight.intensity=d*.75*(.7+Math.sin(n*1.3)*.3),this.fireflies.geometry.attributes.position.array;let v=0,m=0,g=0;for(let M=0;M<this.ffHome.length;M++)v+=this.ffHome[M].x,m+=this.ffHome[M].y,g+=this.ffHome[M].z;const _=this.ffHome.length;this.fireflyLight.position.set(v/_,m/_,g/_)}const f=this.motes.geometry.attributes.position.array;for(let v=0;v<this.moteData.length;v++){const m=this.moteData[v];m.p+=t*(.2+i.wind*.6),f[v*3]=m.x+Math.sin(m.p)*.9+i.wind*.4,f[v*3+1]=m.y+Math.sin(m.p*.7+v)*.5,f[v*3+2]=m.z+Math.cos(m.p*.8)*.9}this.motes.geometry.attributes.position.needsUpdate=!0,this.motes.material.opacity=.08+i.golden*.18+l*.06,this.motes.material.color.setHex(l>.5?13623551:16773840);const p=i.lidOpen*(i.humidity*.8)*(1-ft(i.w.fog));if(this.steam.material.opacity=Ee(this.steam.material.opacity,p*.5,1.5,t),this.steam.visible=this.steam.material.opacity>.01,this.steam.visible){const v=this.steam.geometry.attributes.position.array,m=wt.glassBottomY+wt.glassHeight+2;for(let g=0;g<this.steamData.length;g++){const _=this.steamData[g];_.life+=t*_.speed,_.life>1&&(_.life=0,_.a=Math.random()*Ge,_.r=Math.random()*6),2+_.life*8,v[g*3]=Math.cos(_.a)*(_.r+_.life*2)*.6,v[g*3+1]=m+_.life*10,v[g*3+2]=Math.sin(_.a)*(_.r+_.life*2)*.6}this.steam.geometry.attributes.position.needsUpdate=!0,this.steam.material.opacity=p*.4}this.glassCond.update(i,t)}}const pl=[{id:"sow",label:"Sow",hint:"Choose a seed, then plant it in a glowing soil pocket.",key:"1"},{id:"grow",label:"Grow",hint:"Tap a plant to surge its growth, or raise biological time.",key:"2"},{id:"water",label:"Water",hint:"Drag the brass can over the soil to water it.",key:"3"},{id:"prune",label:"Prune",hint:"Click foliage clusters to trim them back. They regrow.",key:"4"},{id:"sculpt",label:"Sculpt",hint:"Drag over the soil to raise or lower it.",key:"5"},{id:"fauna",label:"Fauna",hint:"Tap any animal to see how it reacts to you.",key:"6"},{id:"wipe",label:"Wipe",hint:"Drag across the fogged glass to clear the condensation.",key:"7"},{id:"lid",label:"Lid",hint:"Open or close the lid. Air, humidity and rain respond.",key:"8"},{id:"lens",label:"Lens",hint:"A reading lens follows your pointer. Hover over anything.",key:"9"},{id:"restore",label:"Restore",hint:"Click a blighted patch to heal it with moss and habitat.",key:"0"}],Jr=[{id:"maple",name:"Maple",kind:"broadleaf",hue:.22,color:"#7fae5c",matureAt:24,cost:0,soil:["loam","mossy"]},{id:"cedar",name:"Cedar",kind:"conifer",hue:.32,color:"#4f7f56",matureAt:28,cost:0,soil:["loam","mossy"]},{id:"fern",name:"Fern",kind:"fern",hue:.26,color:"#5c8a4a",matureAt:12,cost:0,soil:["loam","mossy","sandy"]},{id:"bloom",name:"Bloom",kind:"flower",bloom:"#ff9dc0",color:"#ff9dc0",matureAt:14,cost:0,soil:["loam","sandy"]},{id:"glowcap",name:"Glowcap",kind:"fungus",cap:"#8ad4ff",color:"#8ad4ff",matureAt:9,cost:0,soil:["mossy","loam"]}],ou=[{id:"moss",name:"Moss",color:"#6f9a54"},{id:"stone",name:"Stone",color:"#8b8778"},{id:"habitat",name:"Habitat",color:"#c8a270"}];class Zv{constructor(t){this.app=t,this.state=t.state,this.terrain=t.terrain,this.flora=t.flora,this.creatures=t.creatures,this.atmosphere=t.atmosphere,this.terrarium=t.terrarium,this.rig=t.rig,this.renderer=t.renderer,this.scene=t.scene,this.tool="orbit",this.seedId="maple",this.restoreMat="moss",this.sculptMode="raise",this.pointer=new Q(-10,-10),this.pointerNDC=new Q,this.dragging=!1,this.dragStart=null,this.hovering=!1,this.lastSculpt=0,this.lastWater=0,this.lastWipe=0,this.hoveredCreature=null,this.hoverPoints=0,this.raycaster=new Xh,this.raycaster.far=500,this.buildWaterCan(),this.buildSpray(),this.buildShears(),this.buildLens(),this.bindEvents()}buildWaterCan(){const t=new gt,e=new st({color:12159813,metalness:.95,roughness:.32}),i=new I(new Ft(2.1,2.4,3.4,18),e);t.add(i);const n=new I(new It(2.15,18,10,0,Math.PI*2,0,Math.PI/2),e);n.position.y=1.7,t.add(n);const s=new I(new Ft(.14,.34,4.2,8),e);s.position.set(1.7,1.6,0),s.rotation.z=-.9,t.add(s);const o=new I(new Ft(.62,.3,.4,12),e);o.position.set(3.5,2.9,0),o.rotation.z=-.9,t.add(o);const a=new I(new We(1.2,.16,8,20,Math.PI),e);a.position.set(-.2,2.2,0),a.rotation.z=.15,t.add(a);const l=new I(new Ft(1.5,1.7,.5,16),e);l.position.y=2.9,t.add(l);const c=new I(new It(.4,10,8),e);c.position.y=3.4,t.add(c),t.traverse(h=>{h.isMesh&&(h.castShadow=!0)}),t.scale.setScalar(.55),t.visible=!1,this.scene.add(t),this.waterCan=t,this.spoutTip=new ue,this.spoutTip.position.set(3.9,3,0),t.add(this.spoutTip)}buildSpray(){const e=new de,i=new Float32Array(480),n=new Float32Array(160);for(let o=0;o<160;o++)n[o]=Math.random();e.setAttribute("position",new ee(i,3)),e.setAttribute("aSeed",new ee(n,1));const s=new Qe({transparent:!0,depthWrite:!1,blending:Ne,uniforms:{uMap:{value:new ol(rn(32,null,null,[[0,"rgba(220,240,255,0.9)"],[1,"rgba(200,230,255,0)"]]))},uOpacity:{value:0}},vertexShader:`
        attribute float aSeed;
        varying float vA;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = (0.3 + aSeed * 0.5) * (90.0 / -mv.z);
          vA = 0.4 + aSeed * 0.6;
        }`,fragmentShader:`
        varying float vA; uniform sampler2D uMap; uniform float uOpacity;
        void main() {
          vec4 t = texture2D(uMap, gl_PointCoord);
          gl_FragColor = vec4(vec3(0.85, 0.93, 1.0), t.a * vA * uOpacity);
        }`});this.spray=new Gs(e,s),this.spray.frustumCulled=!1,this.spray.visible=!1,this.scene.add(this.spray),this.sprayData=[];for(let o=0;o<160;o++)this.sprayData.push({life:Math.random(),vx:0,vy:0,vz:0})}buildShears(){const t=new gt,e=new st({color:9271900,metalness:.85,roughness:.35}),i=new st({color:3811866,roughness:.7});for(let n=-1;n<=1;n+=2){const s=new I(new ne(.18,.05,2.2),e);s.position.z=1,s.rotation.y=n*.16;const o=new I(new We(.5,.12,6,14),i);o.position.z=-.4,o.rotation.y=Math.PI/2,o.rotation.z=n*.3,t.add(s,o)}t.scale.setScalar(.5),t.visible=!1,this.scene.add(t),this.shears=t}buildLens(){this.lensEl=document.getElementById("lens"),this.lensCanvas=document.getElementById("lensCanvas"),this.lensVisible=!1,this._lensOn=!1,this.lensSize=280,this._lensCentre=new Q(-9999,-9999),this.lensPoint=new R(0,wt.glassBottomY+4,0),this.lensTargetPoint=this.lensPoint.clone(),this.lensScene=new $r,this.lensOrtho=new no(-1,1,1,-1,0,1);const t=Math.min(window.devicePixelRatio||1,2);this.lensRT=new Ai(Math.floor(window.innerWidth*t),Math.floor(window.innerHeight*t),{minFilter:Ze,magFilter:Ze,depthBuffer:!0}),this.lensRT.texture.colorSpace=ni,this.lensUniforms={uScene:{value:this.lensRT.texture},uRes:{value:new Q(window.innerWidth,window.innerHeight)},uCentre:{value:new Q(-9999,-9999)},uRadius:{value:140},uZoom:{value:2.35},uChroma:{value:.0032},uBarrel:{value:.16},uRim:{value:new ct("#d9c491")},uLight:{value:0}},this.lensMat=new Qe({uniforms:this.lensUniforms,transparent:!0,depthTest:!1,depthWrite:!1,vertexShader:`
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`,fragmentShader:`
        precision highp float;
        uniform sampler2D uScene;
        uniform vec2 uRes, uCentre;
        uniform float uRadius, uZoom, uChroma, uBarrel, uLight;
        uniform vec3 uRim;
        varying vec2 vUv;

        void main() {
          vec2 frag = vUv * uRes;
          vec2 d = frag - uCentre;
          float r = length(d) / uRadius;

          // outside the rim: transparent, so the untouched frame shows through
          if (r > 1.0) { discard; }

          // barrel distortion: the glass bends the image toward its edge
          float r2 = r * r;
          float bend = 1.0 + uBarrel * r2 * 0.55;
          vec2 off = d * bend;

          // magnification falls off toward the rim, like a real lens
          float mag = mix(uZoom, uZoom * 0.62, smoothstep(0.15, 0.92, r));
          vec2 src = uCentre - off / mag;

          // chromatic aberration, strongest at the edge
          float ca = uChroma * r2 * uRadius;
          vec2 dir = normalize(d + 1e-5);
          vec3 col;
          col.r = texture2D(uScene, (src + dir * ca).xy / uRes).r;
          col.g = texture2D(uScene, src / uRes).g;
          col.b = texture2D(uScene, (src - dir * ca).xy / uRes).b;

          // a lens is a little brighter than the eye alone, and cooler
          col *= mix(1.14, 0.97, smoothstep(0.7, 1.0, r));
          col = mix(col, col * vec3(0.985, 1.0, 1.015), 0.6);

          // the rim: a bright bevel, then a thin dark edge, then the brass
          float rim = smoothstep(0.955, 1.0, r);
          float bevel = smoothstep(0.90, 0.965, r) * (1.0 - smoothstep(0.965, 1.0, r));
          col += vec3(1.0) * bevel * 0.22;
          col = mix(col, uRim * 1.15, rim * 0.85);

          // a glassy highlight arc, upper left
          float arc = smoothstep(0.62, 0.80, r) * smoothstep(1.0, 0.90, r);
          float ang = atan(d.y, d.x);
          float hl = smoothstep(0.35, 1.0, cos(ang - 2.35)) * arc;
          col += vec3(1.0, 0.98, 0.92) * hl * 0.30;

          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`}),this.lensQuad=new I(new be(2,2),this.lensMat),this.lensQuad.frustumCulled=!1,this.lensScene.add(this.lensQuad),this.resizeLens()}resizeLens(){const t=Math.min(window.devicePixelRatio||1,2),e=Math.floor(window.innerWidth*t),i=Math.floor(window.innerHeight*t);this.lensRT?.setSize(e,i),this.lensUniforms?.uRes.value.set(window.innerWidth,window.innerHeight),this.lensUniforms&&(this.lensUniforms.uRadius.value=this.lensSize*.5)}bindEvents(){const t=this.renderer.domElement;matchMedia("(pointer: coarse)").matches,t.addEventListener("pointerdown",i=>{this.updatePointerFromEvent(i),this.pointerDown={x:i.clientX,y:i.clientY,t:performance.now()},this.dragging=!1,this._couldClick=!0,this._downAt=i.timeStamp||performance.now(),!(this.rig.mode==="inside"&&this.tool==="orbit")&&i.button!==2&&this.onPointerDown(i)},{capture:!0}),window.addEventListener("pointermove",i=>{if(this.updatePointerFromEvent(i),this.pointerDown){const n=i.clientX-this.pointerDown.x,s=i.clientY-this.pointerDown.y;Math.hypot(n,s)>10&&(this.dragging=!0)}this.onPointerMove(i)});const e=i=>{if(!this.pointerDown&&!this._couldClick)return;this.updatePointerFromEvent(i);const n=i.timeStamp||performance.now(),s=!!this._couldClick&&!this.dragging&&n-this._downAt<900;this.pointerDown=null,this._couldClick=!1,this.onPointerUp(i,s),this.dragging=!1};window.addEventListener("pointerup",e,{capture:!0}),window.addEventListener("pointercancel",e,{capture:!0}),t.addEventListener("contextmenu",i=>i.preventDefault())}updatePointerFromEvent(t){const e=this.renderer.domElement.getBoundingClientRect();this.pointer.set(t.clientX-e.left,t.clientY-e.top),this.pointerClient={x:t.clientX,y:t.clientY},this.pointerNDC.set(this.pointer.x/window.innerWidth*2-1,-(this.pointer.y/window.innerHeight)*2+1)}setTool(t){this.tool=t;const e=pl.find(i=>i.id===t);this.app.ui.setActiveTool(t),this.waterCan.visible=t==="water",this.shears.visible=t==="prune",this.terrain.brushRing.visible=t==="sculpt"||t==="water",t==="sow"?this.terrain.setPatchMarkers(!0,!0):this.terrain.setPatchMarkers(!1),t==="restore"?this._highlightRestore(!0):this._highlightRestore(!1),this.app.ui.showContextBar(t),e&&this.app.ui.hint(e.hint),this.renderer.domElement.style.cursor=t==="orbit"?"grab":t==="lens"?"none":"crosshair",t==="lid"&&(this.toggleLid(),setTimeout(()=>this.setTool("orbit"),700))}toggleLid(){this.sfx("lid");const t=this.state.toggleLid();this.terrarium.lidTarget=t,this.app.ui.toast(t>.5?"The lid is lifted":"The lid is sealed",t>.5?"air":"seal"),this.app.ui.updateLidToggle(t>.5)}_highlightRestore(t){this.terrain.blightPatches.forEach(e=>{e.restored||(e.aura.material.opacity=t?.18:.06,e.aura.material.color.setHex(t?7327882:9056031))})}raySoil(){this.raycaster.setFromCamera(this.pointerNDC,this.rig.camera);const t=this.terrain.soilMesh;t.updateWorldMatrix(!0,!1);const e=this.raycaster.intersectObject(t,!1);return e.length?e[0]:null}rayGlass(){this.raycaster.setFromCamera(this.pointerNDC,this.rig.camera);const t=this.raycaster.intersectObject(this.terrarium.glass,!1);return t.length?t[0]:null}rayPlants(){this.raycaster.setFromCamera(this.pointerNDC,this.rig.camera);const t=[];this.flora.plants.forEach(i=>{i.obj&&t.push(i.obj)});const e=this.raycaster.intersectObjects(t,!0);return e.length?e[0]:null}rayCreatures(){this.raycaster.setFromCamera(this.pointerNDC,this.rig.camera);const t=this.creatures.getProxies(),e=this.raycaster.intersectObjects(t,!1);if(e.length){const a=e[0].object.userData.creature;return{object:e[0].object,point:e[0].point,distance:e[0].distance,creature:a}}let i=null,n=46;const s=this.rig.camera,o=new R;return this.creatures.list.forEach(a=>{if(o.copy(a.group.position),o.y+=1.2,o.project(s),o.z>1)return;const l=(o.x*.5+.5)*window.innerWidth,c=(-o.y*.5+.5)*window.innerHeight,h=Math.hypot(l-this.pointer.x,c-this.pointer.y);h<n&&(n=h,i=a)}),i?{object:i.group,point:i.group.position.clone(),distance:0,creature:i}:null}rayBlight(){this.raycaster.setFromCamera(this.pointerNDC,this.rig.camera);const t=this.terrain.blightPatches.filter(a=>!a.restored);if(!t.length)return null;const e=this.raycaster.intersectObjects(t.map(a=>a.group),!0);if(e.length)return e[0];const i=this.rig.camera,n=new R;let s=null,o=70;return t.forEach(a=>{if(n.set(a.x,this.terrain.heightAt(a.x,a.z),a.z).project(i),n.z>1)return;const l=(n.x*.5+.5)*window.innerWidth,c=(-n.y*.5+.5)*window.innerHeight,h=Math.hypot(l-this.pointer.x,c-this.pointer.y);h<o&&(o=h,s=a)}),s?{object:s.group,point:new R(s.x,this.terrain.heightAt(s.x,s.z),s.z),distance:0}:null}rayPatches(){let t=null,e=3.4;const i=this.raySoil();if(i&&this.terrain.patches.forEach(l=>{if(l.occupied)return;const c=Math.hypot(l.x-i.point.x,l.z-i.point.z);c<e&&(e=c,t=l)}),t)return t;const n=this.rig.camera,s=new R;let o=null,a=55;return this.terrain.patches.forEach(l=>{if(l.occupied||(s.set(l.x,this.terrain.heightAt(l.x,l.z),l.z).project(n),s.z>1))return;const c=(s.x*.5+.5)*window.innerWidth,h=(-s.y*.5+.5)*window.innerHeight,u=Math.hypot(c-this.pointer.x,h-this.pointer.y);u<a&&(a=u,o=l)}),o}onPointerDown(t){const e=this.tool;if(!(e==="orbit"||e==="lens")){if(e==="wipe"){this.doWipe();return}if(e==="prune"){this.doPrune();return}e==="sculpt"&&this.app.history?.beginStroke()}}onPointerMove(t){const e=this.tool;if(performance.now(),e==="water"){const i=this.raySoil();i?(this.terrain.brushRing.visible=!0,this.terrain.brushRing.position.set(i.point.x,i.point.y+.04,i.point.z),this.terrain.brushRing.scale.setScalar(1.6),this.positionWaterCan(i.point)):this.terrain.brushRing.visible=!1;return}if(e==="sculpt"){const i=this.raySoil();if(i){this.terrain.brushRing.visible=!0,this.terrain.brushRing.position.set(i.point.x,i.point.y+.05,i.point.z),this.terrain.brushRing.scale.setScalar(2.2);const n=this.sculptMode==="raise"?10215562:15769712;this.terrain.brushRing.material.color.setHex(n)}else this.terrain.brushRing.visible=!1;return}if(e==="prune"){const i=this.rayPlants();i?(this.shears.visible=!0,this.shears.position.copy(i.point).add(new R(0,1.2,0)),this.shears.rotation.set(.6,.4,-.6),this.renderer.domElement.style.cursor="crosshair"):this.shears.visible=!1;return}if(e==="wipe"){this.renderer.domElement.style.cursor="crosshair";return}if(e==="lens"){this.updateLensPoint();return}if(e==="restore"){const i=this.rayBlight();this._restoreHover=!!i;return}if(e==="fauna"){const i=this.rayCreatures();this.hoveredCreature=i?i.creature:null,this.renderer.domElement.style.cursor=i?"pointer":"default";return}if(e==="grow"){const i=this.rayPlants();this.renderer.domElement.style.cursor=i?"pointer":"default";return}if(e==="sow"){const i=this.raySoil();this.terrain.patches.forEach(n=>{if(n.occupied){n.ring.visible=!1;return}const s=i&&Math.hypot(i.point.x-n.x,i.point.z-n.z)<2;n.ring.visible=!0,n.ring.material.color.setHex(s?16769162:15978892)}),this.renderer.domElement.style.cursor=i?"pointer":"default";return}}onPointerUp(t,e){if(window.__lastClick={wasClick:e,tool:this.tool},this.tool==="sculpt"&&this.app.history?.endStroke("Sculpt"),!e){this.dragging=!1;return}this.tool==="sow"&&(window.__sowCalled=(window.__sowCalled||0)+1);const i=this.tool;i==="sow"?this.doSow():i==="grow"?this.doGrow():i==="fauna"?this.doFauna():i==="restore"?this.doRestore():i==="prune"?this.doPrune():i==="wipe"&&this.doWipe()}doSow(){this.sfx("sow");const t=this.raySoil();if(!t)return;const e=this.rayPatches(),i=Jr.find(o=>o.id===this.seedId);let n=t.point.x,s=t.point.z;if(e)n=e.x,s=e.z,e.type;else if(Math.hypot(n,s)>di*.95||this.terrain.streamCarve(n,s)>.2||this.terrain.wetnessAt(n,s)>.85){this.app.ui.hint("Plant in a glowing soil pocket — they mark where life will take.");return}this.flora.plantSeed(n,s,i),e&&(e.occupied=!0),this.state.emit("sown",i),this.app.ui.toast(`${i.name} sown`,"sow"),this.app.ui.hint("Give it time — raise biological time to watch it grow."),this._sparkle(n,this.terrain.heightAt(n,s),s,i.color)}doGrow(){this.sfx("grow");const t=this.rayPlants();let e=t?t.point:null;if(!e){let n=null,s=60;const o=this.rig.camera,a=new R;this.flora.plants.forEach(l=>{if(!l.obj||(a.copy(l.obj.position),a.y+=1.6,a.project(o),a.z>1))return;const c=(a.x*.5+.5)*window.innerWidth,h=(-a.y*.5+.5)*window.innerHeight,u=Math.hypot(c-this.pointer.x,h-this.pointer.y);u<s&&(s=u,n=l)}),n&&(e=n.obj.position.clone())}if(e){const n=this.flora.findPlantNear(e,6);if(n){this.flora.surge(n),this.app.ui.toast("Growth surged","grow"),this._sparkle(n.obj.position.x,n.obj.position.y+1,n.obj.position.z,"#b5ff9a");return}}const i=ft(this.state.bioSpeed*2,.2,60);this.state.setBioSpeed(i),this.app.ui.setGrowth(i),this.app.ui.toast(`Biological time ${i.toFixed(1)}×`,"grow")}positionWaterCan(t){const e=performance.now()*.001,i=this.waterCan;i.position.set(t.x+3.4+Math.sin(e*1.3)*.2,t.y+9.5+Math.sin(e*1.7)*.3,t.z+1.2),i.rotation.set(0,Math.PI+.55,.12),this.waterCanTarget=t.clone()}doWater(){this.sfx("water");const t=this.raySoil();if(!t||t.point.y>wt.glassBottomY+wt.glassHeight)return;const e=t.point;this.terrain.wet(e.x,e.z,2.4,.22),this.flora.plants.forEach(i=>{Math.hypot(i.obj.position.x-e.x,i.obj.position.z-e.z)<3&&(i.boost=Math.max(i.boost||0,.6),i.hp=Math.min(1,(i.hp??1)+.05))}),this._emitSpray(e),this.state.emit("watered",e),this.app.ui.markWatered&&this.app.ui.markWatered()}sfx(t){this.sound&&this.sound.play(t),this.app.persistence?.markDirty()}doPrune(){this.sfx("prune");const t=this.rayPlants();let e=t?t.point:null;if(!e){let s=null,o=60;const a=this.rig.camera,l=new R;this.flora.plants.forEach(c=>{if(!c.obj||(l.copy(c.obj.position),l.y+=2,l.project(a),l.z>1))return;const h=(l.x*.5+.5)*window.innerWidth,u=(-l.y*.5+.5)*window.innerHeight,d=Math.hypot(h-this.pointer.x,u-this.pointer.y);d<o&&(o=d,s=c)}),s&&(e=s.obj.position.clone().setY(s.obj.position.y+2.2))}if(!e){this.app.ui.hint("Aim at a leafy cluster to prune it.");return}const i=e,n=this.flora.pruneAt(i,6);n&&(this.state.emit("pruned",i),n.regrown?this.app.ui.toast("Foliage regrown","prune"):(this.app.ui.toast("Branch pruned","prune"),this._fallingLeaves(i)))}doSculpt(){this.sfx("sculpt");const t=this.raySoil();if(!t)return;const e=this.sculptMode==="raise"?1:-1;this.terrain.sculpt(t.point.x,t.point.z,2.3,e*.16)&&(this.app.ui.setLidValue,this.state.emit("sculpt",t.point))}doFauna(){this.sfx("fauna");const t=this.rayCreatures();if(!t){this.app.ui.hint("Tap one of the small residents of the glass.");return}const e=t.creature||t.object.userData.creature,i=e.react();return this.state.emit("fauna",e.species||e.name||e.kind),this.app.ui.toast(i,e.displayName),this.app.ui.hint("Every animal has its own temperament — try the others."),navigator.vibrate&&navigator.vibrate(12),e}doWipe(){this.sfx("wipe");const t=this.rayGlass();let e=null;if(t&&Math.abs(t.face.normal.dot(this.rig.raycaster.ray.direction))>.05&&(e=t.point),!e){const i=this.rig.raycaster.ray,n=wt.glassRadius,s=i.origin,o=i.direction,a=o.x*o.x+o.z*o.z,l=2*(s.x*o.x+s.z*o.z),c=s.x*s.x+s.z*s.z-n*n,h=l*l-4*a*c;if(h<0)return;const u=(-l-Math.sqrt(h))/(2*a);if(u<0||(e=i.at(u,new R),e.y<wt.glassBottomY||e.y>wt.glassBottomY+wt.glassHeight))return}this.atmosphere.wipe(e),this.app.ui.markWiped(),this._sparkle(e.x,e.y,e.z,"#d8f0ff",5)}updateLensPoint(){this.rig.raycaster.setFromCamera(this.pointerNDC,this.rig.camera);const t=[this.terrain.soilMesh];this.flora.plants.forEach(i=>i.obj&&t.push(i.obj)),t.push(this.creatures.group);const e=this.rig.raycaster.intersectObjects(t,!0);if(e.length)this.lensTargetPoint.copy(e[0].point);else{const i=this.rayGlass();i&&this.lensTargetPoint.copy(i.point)}}doRestore(){this.sfx("restore");const t=this.rayBlight();if(!t){this.app.ui.hint("Find a dark, blighted patch of soil and restore it.");return}const e=this.terrain.blightPatches.find(o=>{let a=t.object;for(;a;){if(a===o.group)return!0;a=a.parent}return!1});if(!e||e.restored)return;e.restored=!0,e.aura.material.opacity=0,e.group.visible=!1,this.state.emit("restored",e),this.state.emit("blightRestored",e);const i=this.restoreMat,n=this.flora.restorePatchVisual(e.x,e.z,e.r);if(i==="stone"){const o=$t(Math.floor(e.x*13+e.z)),a=new st({color:8419946,roughness:.9,flatShading:!0});for(let l=0;l<4;l++){const c=new I(new hs(.3+o()*.35,0),a),h=o()*Math.PI*2,u=o()*e.r*.7;c.position.set(e.x+Math.cos(h)*u,this.terrain.heightAt(e.x+Math.cos(h)*u,e.z+Math.sin(h)*u)+.15,e.z+Math.sin(h)*u),c.rotation.set(o()*3,o()*3,o()*3),c.castShadow=!0,n.parent.add(c)}}else if(i==="habitat"){const o=new gt,a=new st({color:8024932,roughness:.92,flatShading:!0}),l=new I(new ne(.9,.32,.7),a);l.position.y=.16;const c=new I(new ci(.7,.45,4),new st({color:5204796,roughness:1}));c.position.y=.55,c.rotation.y=Math.PI/4;const h=new I(new ne(.24,.2,.05),new st({color:1315340}));h.position.set(0,.1,.36),o.add(l,c,h),o.position.set(e.x,this.terrain.heightAt(e.x,e.z)+.02,e.z),n.parent.add(o)}const s=this.terrain.blightPatches.filter(o=>!o.restored).length;this.app.ui.toast(s?`Patch restored · ${s} remain`:"The glass is whole again","restore"),this._sparkle(e.x,this.terrain.heightAt(e.x,e.z)+1,e.z,"#a8f0b8",24),s===0&&this.app.ui.celebrate()}_sparkle(t,e,i,n="#ffe0a0",s=14){if(!this.sparklePool){this.sparklePool=[];const l=new de,c=new Float32Array(600);l.setAttribute("position",new ee(c,3));const h=new rl({size:.35,map:we(rn(32)),color:16767370,transparent:!0,opacity:.9,depthWrite:!1,blending:Ne});this.sparkles=new Gs(l,h),this.sparkles.frustumCulled=!1,this.scene.add(this.sparkles);const u=new Float32Array(600),d=new Float32Array(200);l.setAttribute("aVel",new ee(u,3)),l.setAttribute("aLife",new ee(d,1)),this.sparkleData=[];for(let f=0;f<200;f++)this.sparkleData.push({vx:0,vy:0,vz:0,life:0});this.sparkleMat=h}const o=this.sparkles.geometry.attributes.position.array;let a=0;for(let l=0;l<this.sparkleData.length&&a<s;l++){const c=this.sparkleData[l];if(c.life>0)continue;const h=Math.random()*Math.PI*2,u=Math.random()*.8;o[l*3]=t+Math.cos(h)*u,o[l*3+1]=e+Math.random()*.5,o[l*3+2]=i+Math.sin(h)*u,c.vx=Math.cos(h)*(.4+Math.random()*1.2),c.vy=1+Math.random()*2.2,c.vz=Math.sin(h)*(.4+Math.random()*1.2),c.life=.8+Math.random()*.6,a++}this.sparkleMat.color.set(n),this.sparkles.geometry.attributes.position.needsUpdate=!0}_fallingLeaves(t){if(!this.leafFall){this.leafFall=[],this.leafGeo=new be(.22,.12),this.leafMat=new st({color:7313996,side:ae,roughness:.8}),this.leafGroup=new gt,this.scene.add(this.leafGroup),this.leafPool=[];for(let i=0;i<30;i++){const n=new I(this.leafGeo,this.leafMat);n.visible=!1,this.leafGroup.add(n),this.leafPool.push({mesh:n,life:0,vx:0,vy:0,vz:0,spin:0})}}let e=0;for(const i of this.leafPool){if(e>=8)break;i.life>0||(i.life=2.2,i.mesh.visible=!0,i.mesh.position.copy(t),i.mesh.position.x+=(Math.random()-.5)*1.5,i.mesh.position.y+=Math.random()*1,i.mesh.position.z+=(Math.random()-.5)*1.5,i.vx=(Math.random()-.5)*.6,i.vy=-.4-Math.random()*.5,i.vz=(Math.random()-.5)*.6,i.spin=(Math.random()-.5)*8,e++)}}_emitSpray(t){const e=this.spray.geometry.attributes.position.array,i=new R;this.spoutTip.getWorldPosition(i);let n=0;for(let s=0;s<this.sprayData.length&&n<16;s++){const o=this.sprayData[s];if(o.life>0)continue;e[s*3]=i.x+(Math.random()-.5)*.3,e[s*3+1]=i.y+(Math.random()-.5)*.3,e[s*3+2]=i.z+(Math.random()-.5)*.3;const a=1.1;o.vx=(t.x-i.x)/a+(Math.random()-.5)*.4,o.vy=(t.y-i.y)/a,o.vz=(t.z-i.z)/a+(Math.random()-.5)*.4,o.life=1.1,o.i=s,n++}this.spray.material.uniforms.uOpacity.value=1,this.spray.visible=!0,this.spray.geometry.attributes.position.needsUpdate=!0}update(t){const e=performance.now()*.001;if(this.pointerDown&&(this.tool==="water"&&e-this.lastWater>.1&&(this.doWater(),this.lastWater=e),this.tool==="sculpt"&&e-this.lastSculpt>.09&&(this.doSculpt(),this.lastSculpt=e),this.tool==="wipe"&&e-this.lastWipe>.05&&(this.doWipe(),this.lastWipe=e)),this.waterCan.visible&&(this.waterCan.position.y+=Math.sin(e*1.4)*t*.3,this.waterCan.rotation.z=.12+Math.sin(e*1.1)*.03,this.waterCan.traverse(i=>{i.isMesh&&(i.material.envMapIntensity=.8)})),this.spray.visible){const i=this.spray.geometry.attributes.position.array;let n=0;for(let s=0;s<this.sprayData.length;s++){const o=this.sprayData[s];o.life<=0||(n++,o.life-=t,o.vy-=18*t,i[s*3]+=o.vx*t,i[s*3+1]+=o.vy*t,i[s*3+2]+=o.vz*t)}this.spray.geometry.attributes.position.needsUpdate=!0,n||(this.spray.material.uniforms.uOpacity.value=Ee(this.spray.material.uniforms.uOpacity.value,0,4,t),this.spray.material.uniforms.uOpacity.value<.02&&(this.spray.visible=!1))}if(this.sparkles){const i=this.sparkles.geometry.attributes.position.array;let n=0;for(let s=0;s<this.sparkleData.length;s++){const o=this.sparkleData[s];o.life<=0||(n++,o.life-=t,o.vy-=2.2*t,i[s*3]+=o.vx*t,i[s*3+1]+=o.vy*t,i[s*3+2]+=o.vz*t,o.life<=0&&(i[s*3+1]=-999))}this.sparkles.geometry.attributes.position.needsUpdate=!0,this.sparkles.visible=n>0,this.sparkles.visible&&(this.sparkleMat.opacity=ft(.4+Math.sin(e*5)*.2,.2,.8))}if(this.leafPool&&this.leafPool.forEach(i=>{if(!(i.life<=0)){if(i.life-=t,i.vy-=1.2*t,i.mesh.position.x+=i.vx*t,i.mesh.position.y+=i.vy*t,i.mesh.position.z+=i.vz*t,i.mesh.rotation.x+=i.spin*t,i.mesh.rotation.y+=i.spin*.7*t,this.state.terrain){const n=this.state.terrain.heightAt(i.mesh.position.x,i.mesh.position.z);i.mesh.position.y<n+.05&&(i.life=Math.min(i.life,.5))}i.life<=0&&(i.mesh.visible=!1)}}),this.tool==="lens"&&this.rig.mode!=="inside"){this.lensEl.classList.remove("hidden"),this.lensVisible=!0;const i=this.pointerClient?this.pointerClient.x:-500,n=this.pointerClient?this.pointerClient.y:-500,s=this.lensSize||280;this.lensEl.style.left=`${i-s/2}px`,this.lensEl.style.top=`${n-s/2}px`,this.lensEl.style.width=`${s}px`,this.lensEl.style.height=`${s}px`,this._lensCentre.set(i,n),this._lensOn=!0}else this._lensOn&&(this.lensEl.classList.add("hidden"),this.lensVisible=!1,this._lensOn=!1);if(this.tool==="restore"&&this._highlightRestore(!0),this.tool==="sow"){const i=e;this.terrain.patches.forEach((n,s)=>{if(n.occupied)return;const o=n.r*(1+Math.sin(i*2.5+s)*.04);n.ring.scale.set(o,o,1)})}if(this.tool==="fauna"){const i=this.rayCreatures();this.renderer.domElement.style.cursor=i?"pointer":"default",i&&i.creature&&i.creature.group.scale.setScalar(1.04)}}static get SEEDS(){return Jr}static get RESTORE_MATS(){return ou}}const Kc={clear:'<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="3.4" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M10 2v2.2M10 15.8V18M2 10h2.2M15.8 10H18M4.3 4.3l1.6 1.6M14.1 14.1l1.6 1.6M15.7 4.3l-1.6 1.6M5.9 14.1l-1.6 1.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',cloudy:'<svg viewBox="0 0 20 20"><path d="M5.5 15h9a3 3 0 0 0 .4-6 4.6 4.6 0 0 0-8.9 1.1 2.6 2.6 0 0 0-.5 4.9z" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>',rain:'<svg viewBox="0 0 20 20"><path d="M5.5 12h9a3 3 0 0 0 .4-6 4.6 4.6 0 0 0-8.9 1.1 2.6 2.6 0 0 0-.5 4.9z" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M7 15l-.6 2M10.2 15l-.6 2M13.4 15l-.6 2" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',storm:'<svg viewBox="0 0 20 20"><path d="M5.5 12h9a3 3 0 0 0 .4-6 4.6 4.6 0 0 0-8.9 1.1 2.6 2.6 0 0 0-.5 4.9z" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M10.6 13.4 8.4 16.6h2.2l-1.1 2.2 3.3-3.6H10l.6-1.8z" fill="currentColor"/></svg>',snow:'<svg viewBox="0 0 20 20"><path d="M10 3v14M4 6.5l12 7M16 6.5l-12 7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><circle cx="10" cy="10" r="1.4" fill="currentColor"/></svg>',mist:'<svg viewBox="0 0 20 20"><path d="M3 7.5h14M4.5 11h11M3 14.5h14" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>'},Jv={sow:'<svg viewBox="0 0 24 24"><path d="M12 4c4.4 0 7.4 3.6 7.4 8.2 0 4.6-3.3 7.8-7.4 7.8s-7.4-3.2-7.4-7.8C4.6 7.6 7.6 4 12 4z" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M12 16v-5m0 2.4c0-1.8 1.8-2.9 3.4-2.2-.4 1.8-1.6 2.9-3.4 3.1z" fill="none" stroke="currentColor" stroke-width="1.1"/></svg>',grow:'<svg viewBox="0 0 24 24"><path d="M12 20V8m0 4c0-3.4 3-5.6 6-4.4-.6 3.6-2.8 5.4-6 5.6zm0 3.2c0-3.4-3-5.6-6-4.4.6 3.6 2.8 5.4 6 5.6z" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>',water:'<svg viewBox="0 0 24 24"><path d="M5 14h9l3-1.6M14 14l3.4-5.2m0 0 1.6-1M8 14V8h6l2 3" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 18c1 0 1.4 1 2.4 1" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>',prune:'<svg viewBox="0 0 24 24"><path d="M7 19c0-5 2-9 6-11m4 0c-1.5 3.5-1 6 1 8M8 5l3 3" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><circle cx="7.5" cy="7.5" r="2.2" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>',sculpt:'<svg viewBox="0 0 24 24"><path d="M3 17c2.5 0 3-3 5.5-3s3 2.5 5.5 2.5S17.5 14 21 14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><path d="M8 9l1.8-1.8M16 9l-1.8-1.8" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',fauna:'<svg viewBox="0 0 24 24"><path d="M7 9.5c0-2 1.6-3.5 3.5-3.5h3c2 0 3.5 1.6 3.5 3.5v4c0 2-1.6 3.5-3.5 3.5h-3A3.5 3.5 0 0 1 7 13.5v-4z" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="10.2" cy="11" r="1" fill="currentColor"/><circle cx="13.8" cy="11" r="1" fill="currentColor"/><path d="M10.5 13.4c.9.7 2.1.7 3 0" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/><path d="M7.5 7 6 5.4M16.5 7 18 5.4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',wipe:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.4" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="m15.8 15.8 3.4 3.4M8 11a3 3 0 0 1 3-3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',lid:'<svg viewBox="0 0 24 24"><path d="M5 15c0-3.9 3.1-7 7-7s7 3.1 7 7" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M4 15h16M12 8V5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><circle cx="12" cy="4" r="1.2" fill="currentColor"/></svg>',lens:'<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="5.6" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="m15 15 4.4 4.4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M8.6 8.2a2.6 2.6 0 0 1 2-1.4" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>',restore:'<svg viewBox="0 0 24 24"><path d="M12 20v-7m0 3.4c0-2.6 2.4-4.2 4.6-3.2-.5 2.6-2.2 4.1-4.6 4.3zM12 16c0-2.6-2.4-4.2-4.6-3.2.5 2.6 2.2 4.1 4.6 4.3z" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><path d="M5 20h14" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>'};class jv{constructor(t){this.app=t,this.state=t.state,this.el={intro:document.getElementById("intro"),enterBtn:document.getElementById("enterBtn"),loadBar:document.getElementById("loadBar"),loadLabel:document.getElementById("loadLabel"),toolList:document.getElementById("toolList"),weatherList:document.getElementById("weatherList"),timeSlider:document.getElementById("timeSlider"),timeSky:document.getElementById("timeSky"),clockBig:document.getElementById("clockBig"),dayLabel:document.getElementById("dayLabel"),clockLabel:document.getElementById("clockLabel"),clockPhase:document.getElementById("clockPhase"),clockIcon:document.getElementById("clockIcon"),playPause:document.getElementById("playPause"),iconPause:document.querySelector("#playPause .icon-pause"),iconPlay:document.querySelector("#playPause .icon-play"),growthRange:document.getElementById("growthRange"),growthVal:document.getElementById("growthVal"),windRange:document.getElementById("windRange"),windVal:document.getElementById("windVal"),humidityBar:document.querySelector("#humidityBar b"),humidityVal:document.getElementById("humidityVal"),condenseBar:document.querySelector("#condenseBar b"),condenseVal:document.getElementById("condenseVal"),lidBar:document.querySelector("#lidBar b"),lidVal:document.getElementById("lidVal"),lidToggle:document.getElementById("lidToggle"),motionToggle:document.getElementById("motionToggle"),shadowToggle:document.getElementById("shadowToggle"),qualityToggle:document.getElementById("qualityToggle"),panel:document.getElementById("atmospherePanel"),panelToggle:document.getElementById("atmosphereToggle"),seedbar:document.getElementById("seedbar"),restorebar:document.getElementById("restorebar"),sculptbar:document.getElementById("sculptbar"),hint:document.getElementById("hint"),toastwrap:document.getElementById("toastwrap"),btnOrbit:document.getElementById("btnOrbit"),btnInside:document.getElementById("btnInside"),btnMute:document.getElementById("btnMute"),waveA:document.getElementById("waveA"),waveB:document.getElementById("waveB"),muteX:document.getElementById("muteX"),btnLid:document.getElementById("btnLid"),btnHelp:document.getElementById("btnHelp"),helpSheet:document.getElementById("helpSheet"),journalToggle:document.getElementById("btnJournal"),helpClose:document.getElementById("helpClose"),toolbar:document.getElementById("toolbar"),toolbarCollapse:document.getElementById("toolbarCollapse"),timeTicks:document.getElementById("timeTicks"),brand:document.getElementById("brand"),vignette:document.getElementById("vignette")},this.hintTimer=null,this.wateredCount=0,this.wipedCount=0,this.buildToolbar(),this.buildWeather(),this.buildContextBars(),this.buildTicks(),this.bindUI(),this.bindState(),this.setToolAvailability("orbit")}buildToolbar(){pl.forEach((t,e)=>{const i=document.createElement("button");i.className="tool",i.dataset.tool=t.id,i.innerHTML=`${Jv[t.id]||""}<span>${t.label}</span><b class="tool-kbd">${e+1===10?"0":e+1}</b>`,i.title=t.hint,i.addEventListener("click",()=>this.app.selectTool(t.id)),this.el.toolList.appendChild(i)})}buildWeather(){const t={clear:"Clear",cloudy:"Cloudy",rain:"Rain",storm:"Storm",snow:"Snow",mist:"Mist"};Object.keys(Kc).forEach(e=>{const i=document.createElement("button");i.className="weather",i.dataset.weather=e,i.innerHTML=`${Kc[e]}<span>${t[e]}</span>`,i.addEventListener("click",()=>this.app.setWeather(e)),this.el.weatherList.appendChild(i)})}buildContextBars(){this.el.seedbar.innerHTML="",this.app.SEEDS.forEach(t=>{const e=document.createElement("button");e.className="seed",e.dataset.seed=t.id,e.innerHTML=`<i style="background:radial-gradient(circle at 35% 30%, #fff8, ${t.color})"></i>${t.name}`,e.addEventListener("click",()=>{this.app.interactions.seedId=t.id,this.refreshSeeds(),this.hint(`Sowing ${t.name}. Choose a glowing pocket.`)}),this.el.seedbar.appendChild(e)}),this.refreshSeeds(),this.el.restorebar.innerHTML="",this.app.RESTORE_MATS.forEach(t=>{const e=document.createElement("button");e.className="seed",e.dataset.mat=t.id,e.innerHTML=`<i style="background:radial-gradient(circle at 35% 30%, #fff7, ${t.color})"></i>${t.name}`,e.addEventListener("click",()=>{this.app.interactions.restoreMat=t.id,this.refreshRestore(),this.hint(`Placing ${t.name}. Click a dark blighted patch.`)}),this.el.restorebar.appendChild(e)}),this.refreshRestore(),this.el.sculptbar.querySelectorAll("[data-brush]").forEach(t=>{t.addEventListener("click",()=>{this.app.interactions.sculptMode=t.dataset.brush,this.el.sculptbar.querySelectorAll("[data-brush]").forEach(e=>e.classList.toggle("active",e===t))})})}refreshSeeds(){this.el.seedbar.querySelectorAll(".seed").forEach(t=>{t.classList.toggle("active",t.dataset.seed===this.app.interactions.seedId)})}refreshRestore(){this.el.restorebar.querySelectorAll(".seed").forEach(t=>{t.classList.toggle("active",t.dataset.mat===this.app.interactions.restoreMat)})}buildTicks(){this.el.timeTicks.innerHTML="";for(let t=0;t<=24;t+=3){const e=document.createElement("i");e.style.left=`${t/24*100}%`,this.el.timeTicks.appendChild(e)}}bindUI(){const{el:t,state:e,app:i}=this;t.timeSlider.addEventListener("input",n=>{const s=parseFloat(n.target.value);e.setTime(s),e.usedSlider=!0,this.updateClock(!0)}),t.timeSlider.addEventListener("pointerdown",()=>{this._sliderDrag=!0}),window.addEventListener("pointerup",()=>{this._sliderDrag=!1}),t.playPause.addEventListener("click",()=>{e.togglePause(),this.updatePlayPause()}),t.growthRange.addEventListener("input",n=>{const s=parseFloat(n.target.value);e.setBioSpeed(s),t.growthVal.textContent=`${s.toFixed(s<10?1:0)}×`}),t.windRange.addEventListener("input",n=>{const s=parseFloat(n.target.value);e.windOverride=s,e.w.ind=s,i.windOverride=s,t.windVal.textContent=s<.15?"still":s<.35?"light":s<.6?"breezy":s<.85?"gusty":"gale"}),t.lidToggle.addEventListener("click",()=>{i.interactions.toggleLid()}),t.motionToggle.addEventListener("click",()=>{i.toggleMotion(),t.motionToggle.querySelector("em").textContent=i.reduceMotion?"off":"on"}),t.shadowToggle.addEventListener("click",()=>{const n=i.cycleShadow();t.shadowToggle.querySelector("em").textContent=n}),t.qualityToggle.addEventListener("click",()=>{const n=i.cycleQuality();t.qualityToggle.querySelector("em").textContent=n}),t.panelToggle.addEventListener("click",()=>{const n=t.panel.classList.toggle("collapsed");t.panelToggle.setAttribute("aria-expanded",String(!n))}),t.toolbarCollapse.addEventListener("click",()=>{t.toolbar.classList.toggle("collapsed")}),t.btnOrbit.addEventListener("click",()=>i.setCameraMode("orbit")),t.btnInside.addEventListener("click",()=>i.setCameraMode("inside")),t.btnMute?.addEventListener("click",()=>i.toggleMute()),t.btnLid.addEventListener("click",()=>i.interactions.toggleLid()),t.btnHelp.addEventListener("click",()=>this.openHelp(!0)),t.helpClose.addEventListener("click",()=>this.openHelp(!1)),t.helpSheet.addEventListener("click",n=>{n.target===t.helpSheet&&this.openHelp(!1)})}bindState(){const{state:t,el:e}=this;t.on("weather",i=>{this.setWeatherActive(i),this.toast(`Weather: ${i}`,"weather")}),t.on("pause",()=>this.updatePlayPause()),t.on("lid",i=>{}),t.on("newday",i=>{e.dayLabel.textContent=`Day ${i} · ${t.phaseLabel}`}),t.on("dawn",()=>this.toast("Dawn comes to the glass","time")),t.on("dusk",()=>this.toast("Lamps are lit within","time"))}setActiveTool(t){this.el.toolList.querySelectorAll(".tool").forEach(i=>{i.classList.toggle("active",i.dataset.tool===t)});const e=t==="orbit";this.el.seedbar.classList.toggle("hidden",t!=="sow"),this.el.restorebar.classList.toggle("hidden",t!=="restore"),this.el.sculptbar.classList.toggle("hidden",t!=="sculpt"),document.body.classList.toggle("tool-active",!e)}setToolAvailability(t){}showContextBar(t){}setWeatherActive(t){this.el.weatherList.querySelectorAll(".weather").forEach(e=>{e.classList.toggle("active",e.dataset.weather===t)})}setGrowth(t){this.el.growthRange.value=t,this.el.growthVal.textContent=`${t.toFixed(t<10?1:0)}×`}updateLidToggle(t){this.el.lidToggle.querySelector("em").textContent=t?"open":"closed",this.el.lidVal.textContent=t?"open":"sealed",this.el.lidBar.style.width=t?"100%":"45%"}updatePlayPause(){const t=this.state.paused;this.el.iconPause.style.display=t?"none":"",this.el.iconPlay.style.display=t?"":"none",this.el.playPause.setAttribute("aria-label",t?"Resume time":"Pause time")}setMuted(t){const{btnMute:e,waveA:i,waveB:n,muteX:s}=this.el;e&&(e.setAttribute("aria-pressed",String(!!t)),e.classList.toggle("muted",!!t),i&&(i.style.display=t?"none":""),n&&(n.style.display=t?"none":""),s&&(s.style.display=t?"":"none"))}updateClock(t=!1){const e=this.state,i=e.time,n=Math.floor(i),s=Math.floor((i-n)*60),o=`${String(n).padStart(2,"0")}:${String(s).padStart(2,"0")}`;if(t||this._lastClock!==o){this._lastClock=o,this.el.clockBig.textContent=o,this.el.clockLabel.textContent=o,this.el.clockPhase.textContent=e.phaseLabel,this.el.dayLabel.textContent=`Day ${e.day} · ${e.phaseLabel}`,this._sliderDrag||(this.el.timeSlider.value=i);const a=e.night>.5,l=this.el.clockIcon;a?(l.style.background="radial-gradient(circle at 35% 30%, #e8eeff, #8e9dc8 60%, #4a5578)",l.style.boxShadow="0 0 10px rgba(160,180,255,0.55)"):e.golden>.4?(l.style.background="radial-gradient(circle at 35% 35%, #ffe0b0, #f0934e 60%, #a05a24)",l.style.boxShadow="0 0 12px rgba(255,170,90,0.7)"):(l.style.background="radial-gradient(circle at 35% 35%, #fff6d6, #f0c464 60%, #b98a2c)",l.style.boxShadow="0 0 10px rgba(255,220,140,0.6)")}}updateMeters(){const t=this.state,e=Math.round(t.humidity*100);this.el.humidityBar.style.width=`${e}%`,this.el.humidityVal.textContent=`${e}%`;const i=t.condensationPct;this.el.condenseBar.style.width=`${ft(i)}%`,this.el.condenseVal.textContent=`${i}%`,this.el.lidBar.style.width=t.lidOpen>.5?"100%":`${45+Math.sin(t.elapsed)*2}%`}update(t){this.updateClock(),this._metersTimer=(this._metersTimer||0)+t,this._metersTimer>.2&&(this._metersTimer=0,this.updateMeters()),this._hintAt&&performance.now()-this._hintAt>6e3&&(this.el.hint.classList.remove("show"),this._hintAt=0),document.body.classList.toggle("inside-mode",this.app.rig.mode==="inside")}hint(t){const e=this.el.hint;e.innerHTML=t,e.classList.add("show"),this._hintAt=performance.now()}toast(t,e=""){const i=document.createElement("div");i.className="toast",i.innerHTML=e?`<small>${e}</small>${t}`:t,this.el.toastwrap.appendChild(i),setTimeout(()=>i.remove(),3600)}celebrate(){this.toast("The terrarium is whole — thank you, keeper.","complete"),this.el.vignette.style.transition="box-shadow 1.2s",this.el.vignette.style.boxShadow="inset 0 0 160px rgba(240,200,120,0.35)",setTimeout(()=>{this.el.vignette.style.boxShadow="none"},2400)}markWatered(){this.wateredCount++,this.wateredCount===12&&this.toast("The soil drinks deeply","water")}markWiped(){this.wipedCount++,this.wipedCount===1&&this.toast("The glass clears","wipe")}openHelp(t){this.el.helpSheet.classList.toggle("hidden",!t),this.app.helpOpen=t}showIntroProgress(t,e){this.el.loadBar.style.width=`${Math.round(t*100)}%`,e&&(this.el.loadLabel.textContent=e)}hideIntro(){this.el.intro.classList.add("done"),setTimeout(()=>this.el.intro.classList.add("hidden"),1100)}}const Xo=r=>440*Math.pow(2,r/12);class Qv{constructor(t){this.state=t,this.ctx=null,this.ready=!1,this.enabled=!0,this.muted=!1,this.volume=.55,this.layers={},this._lastDrop=0,this._noiseBuf=null}async init(){if(this.ready)return;const t=window.AudioContext||window.webkitAudioContext;if(!t)return;this.ctx=new t,this.master=this.ctx.createGain(),this.master.gain.value=0;const e=this.ctx.createDynamicsCompressor();e.threshold.value=-18,e.knee.value=22,e.ratio.value=3.2,e.attack.value=.006,e.release.value=.25,this.master.connect(e),e.connect(this.ctx.destination),this._noiseBuf=this.makeNoise(3,"pink");const i=this.loopNoise(this._noiseBuf);this.bedFilter=this.ctx.createBiquadFilter(),this.bedFilter.type="bandpass",this.bedFilter.frequency.value=900,this.bedFilter.Q.value=.7,this.bedGain=this.ctx.createGain(),this.bedGain.gain.value=0,i.connect(this.bedFilter),this.bedFilter.connect(this.bedGain),this.bedGain.connect(this.master);const n=this.loopNoise(this._noiseBuf);this.rumbleFilter=this.ctx.createBiquadFilter(),this.rumbleFilter.type="lowpass",this.rumbleFilter.frequency.value=220,this.rumbleGain=this.ctx.createGain(),this.rumbleGain.gain.value=0,n.connect(this.rumbleFilter),this.rumbleFilter.connect(this.rumbleGain),this.rumbleGain.connect(this.master),this.drones=[],[-29,-22,-17,-5].forEach((l,c)=>{const h=this.ctx.createOscillator();h.type=c%2?"sine":"triangle",h.frequency.value=Xo(l)*(1+(c-1.5)*.0012);const u=this.ctx.createGain();u.gain.value=0;const d=this.ctx.createOscillator();d.frequency.value=.03+c*.017;const f=this.ctx.createGain();f.gain.value=.006,d.connect(f),f.connect(u.gain),h.connect(u),u.connect(this.master),h.start(),d.start(),this.drones.push({osc:h,g:u,base:.018-c*.002})});const o=this.ctx.createOscillator();o.type="sine",o.frequency.value=Xo(31);const a=this.ctx.createGain();a.gain.value=0,o.connect(a),a.connect(this.master),o.start(),this.shimmer={osc:o,g:a},this.ready=!0,this.fadeTo(this.muted?0:this.volume,1.2)}makeNoise(t,e="pink"){const i=this.ctx,n=Math.floor(i.sampleRate*t),s=i.createBuffer(1,n,i.sampleRate),o=s.getChannelData(0);if(e==="pink"){let a=0,l=0,c=0,h=0,u=0,d=0,f=0;for(let p=0;p<n;p++){const v=Math.random()*2-1;a=.99886*a+v*.0555179,l=.99332*l+v*.0750759,c=.969*c+v*.153852,h=.8665*h+v*.3104856,u=.55*u+v*.5329522,d=-.7616*d-v*.016898,o[p]=(a+l+c+h+u+d+f+v*.5362)*.11,f=v*.115926}}else for(let a=0;a<n;a++)o[a]=Math.random()*2-1;return s}loopNoise(t){const e=this.ctx.createBufferSource();return e.buffer=t,e.loop=!0,e.start(0,Math.random()*t.duration),e}fadeTo(t,e=1){if(!this.ready)return;const i=this.ctx.currentTime;this.master.gain.cancelScheduledValues(i),this.master.gain.setTargetAtTime(t,i,Math.max(.05,e/3))}setMuted(t){this.muted=t,this.fadeTo(t?0:this.volume,.5)}update(t,e){if(!this.ready||this.muted)return;const i=t.w,n=this.ctx.currentTime,s=t.volume??1,o=ft(i.rain,0,1.4),a=ft(i.snow,0,1);this.bedFilter.frequency.setTargetAtTime(Lt(700,3600,o)-a*300,n,.6),this.bedFilter.Q.setTargetAtTime(Lt(.7,1.5,o),n,.6),this.bedGain.gain.setTargetAtTime((.035+o*.13+a*.02)*s,n,.7);const l=ft(i.cloud*.4+i.fog*.5+i.rain*.35,0,1);this.rumbleGain.gain.setTargetAtTime(l*.075*s,n,.9),this.rumbleFilter.frequency.setTargetAtTime(Lt(180,380,i.fog),n,1.2);const c=t.night,h=1-t.lidOpen*.7;this.drones.forEach((u,d)=>{const f=(u.base*(.35+c*1.5)+.006)*h*s;u.g.gain.setTargetAtTime(f,n,1.4);const p=Math.sin(t.time*.26+d*1.7)*.35;u.osc.frequency.setTargetAtTime(Xo([-29,-22,-17,-5][d])*(1+p*.0012),n,2)}),this.shimmer.g.gain.setTargetAtTime(c*(1-i.cloud)*.006*s,n,2),t.condensation>.45&&this.ctx.currentTime-this._lastDrop>1.4+Math.random()*3&&(this._lastDrop=this.ctx.currentTime,this.drip(.35+Math.random()*.5))}env(t,e,i,n,s=1){const o=this.ctx.currentTime,a=e.gain;return a.cancelScheduledValues(o),a.setValueAtTime(1e-4,o),a.linearRampToValueAtTime(s,o+i),a.exponentialRampToValueAtTime(1e-4,o+i+n),o+i+n}blip(t,{type:e="sine",attack:i=.005,decay:n=.14,peak:s=.14,detune:o=0}={}){if(!this.ready||this.muted)return;const a=this.ctx.createOscillator(),l=this.ctx.createGain();a.type=e,a.frequency.value=t,a.detune.value=o,a.connect(l),l.connect(this.master);const c=this.env(a,l,i,n,s);a.start(),a.stop(c+.02)}noiseBurst({freq:t=1200,q:e=1.2,attack:i=.002,decay:n=.18,peak:s=.09,type:o="bandpass"}={}){if(!this.ready||this.muted)return;const a=this.ctx.createBufferSource();a.buffer=this._noiseBuf;const l=this.ctx.createBiquadFilter();l.type=o,l.frequency.value=t,l.Q.value=e;const c=this.ctx.createGain();a.connect(l),l.connect(c),c.connect(this.master);const h=this.env(a,c,i,n,s);a.start(0,Math.random()*2),a.stop(h+.02)}ring(t=620,{decay:e=.9,peak:i=.09}={}){!this.ready||this.muted||[1,2.76,5.4,8.9].forEach((n,s)=>{const o=this.ctx.createOscillator(),a=this.ctx.createGain();o.type="sine",o.frequency.value=t*n,o.connect(a),a.connect(this.master);const l=this.env(o,a,.002,e/(1+s*.9),i/(1+s*1.6));o.start(),o.stop(l+.02)})}drip(t=.5){this.blip(Lt(1400,520,t),{type:"sine",attack:.002,decay:.09,peak:.05})}play(t){if(!(!this.ready||this.muted))switch(t){case"sow":this.noiseBurst({freq:480,q:.8,decay:.16,peak:.07}),this.blip(520,{decay:.1,peak:.05,type:"triangle"});break;case"grow":this.blip(330,{decay:.22,peak:.05,type:"triangle"}),setTimeout(()=>this.blip(494,{decay:.26,peak:.045,type:"triangle"}),90),setTimeout(()=>this.blip(660,{decay:.34,peak:.04,type:"sine"}),180);break;case"water":this.noiseBurst({freq:1700,q:.6,decay:.3,peak:.055}),this.blip(880,{decay:.12,peak:.03,type:"sine"});break;case"prune":this.noiseBurst({freq:3200,q:3,decay:.06,peak:.06}),this.blip(1900,{decay:.05,peak:.035,type:"square"});break;case"sculpt":this.noiseBurst({freq:260,q:.7,decay:.24,peak:.075,type:"lowpass"});break;case"fauna":this.blip(660,{decay:.09,peak:.06,type:"triangle"}),this.blip(880,{decay:.13,peak:.045,type:"triangle",detune:20});break;case"wipe":this.noiseBurst({freq:2400,q:1.4,decay:.2,peak:.05});break;case"lid":this.ring(520,{decay:1.1,peak:.075}),this.noiseBurst({freq:340,q:.6,decay:.5,peak:.05,type:"lowpass"});break;case"lens":this.ring(1400,{decay:.28,peak:.035});break;case"restore":[392,494,587,784].forEach((e,i)=>setTimeout(()=>this.blip(e,{decay:.4,peak:.04,type:"sine"}),i*85));break;case"thunder":this.noiseBurst({freq:120,q:.4,decay:2.2,peak:.16,type:"lowpass",attack:.02}),setTimeout(()=>this.noiseBurst({freq:70,q:.3,decay:3,peak:.11,type:"lowpass",attack:.06}),220);break;case"ui":this.blip(1100,{decay:.04,peak:.022,type:"sine"});break;case"error":this.blip(220,{decay:.16,peak:.05,type:"square"});break}}}const t_=40;class e_{constructor(t){this.app=t,this.undoStack=[],this.redoStack=[],this.pending=null}get terrain(){return this.app.terrain}beginStroke(){this.pending||!this.terrain?.heights||(this.pending={before:this.terrain.heights.slice()})}endStroke(t="Sculpt"){const e=this.pending;if(this.pending=null,!e||!this.terrain?.heights)return!1;const i=this.terrain.heights;let n=!1;for(let s=0;s<i.length;s++)if(Math.abs(i[s]-e.before[s])>1e-4){n=!0;break}return n?(this.undoStack.push({label:t,before:e.before,after:i.slice()}),this.undoStack.length>t_&&this.undoStack.shift(),this.redoStack.length=0,this.app.persistence?.markDirty(),!0):!1}canUndo(){return this.undoStack.length>0}canRedo(){return this.redoStack.length>0}undo(){const t=this.undoStack.pop();return t?(this.redoStack.push(t),this.apply(t.before),this.app.ui?.toast(`Undid ${t.label.toLowerCase()}`,"history"),!0):(this.app.ui?.toast("Nothing to undo","history"),!1)}redo(){const t=this.redoStack.pop();return t?(this.undoStack.push(t),this.apply(t.after),this.app.ui?.toast(`Redid ${t.label.toLowerCase()}`,"history"),!0):(this.app.ui?.toast("Nothing to redo","history"),!1)}apply(t){this.terrain.heights.set(t),this.terrain.rebuildFromHeights(),this.app.persistence?.markDirty()}clear(){this.undoStack.length=0,this.redoStack.length=0,this.pending=null}}const Es={maple:{name:"Maple, dwarf",note:"Leaves turn early under glass. Sows true."},cedar:{name:"Cedar, mountain",note:"Slow. Smells of the drawer it came from."},fern:{name:"Fern, lady",note:"Unfurls in a spiral. Loves a wet foot."},bloom:{name:"Blossom, vesper",note:"Opens at dusk. Emits a faint light."},glowcap:{name:"Glowcap, pale",note:"Fruits in the dark. Cold to the touch."},fox:{name:"Fox, ember",note:"Bolts at a loud sound. Returns by dusk."},deer:{name:"Deer, pygmy",note:"Browses the moss. Startles at the lens."},bird:{name:"Wren, glasswing",note:"Sings only when the lid is shut."},beetle:{name:"Beetle, brass",note:"Travels the rim. Never leaves it."},rabbit:{name:"Hare, ash",note:"Sleeps in the fern. Wakes at the watering."},vole:{name:"Vole, common",note:"Tunnels. You will not see it often."}},Ts={storm:{name:"Lightning",note:"The bed lit blue for a heartbeat. Everything flinched."},snow:{name:"First snow",note:"The moss took it whole and turned to sugar."},mist:{name:"Valley mist",note:"Could not see the bridge from the door."},dawn:{name:"Dawn",note:"The lanterns went out one by one, on their own."},dusk:{name:"Dusk",note:"The flowers opened. I had forgotten they would."},night:{name:"Deep night",note:"The caps are brightest at three. I do not know why."},drought:{name:"Drought",note:"The loam has gone pale and drawn away from the glass."},rain:{name:"Long rain",note:"The stream found a new way down the north bank."},revive:{name:"Recovery",note:"Something grew back where I had given it up."},mature:{name:"First flowering",note:"It took. It actually took."}},Zn=[{id:"sow",label:"Sow a seed",ev:"sown"},{id:"water",label:"Water the soil",ev:"watered"},{id:"sculpt",label:"Reshape the land",ev:"sculpt"},{id:"prune",label:"Prune a branch",ev:"pruned"},{id:"dawn",label:"Watch a dawn",ev:"dawn"},{id:"restore",label:"Restore a blight patch",ev:"restored"}];class i_{constructor(t){this.app=t,this.state=t.state,this.seen=new Map,this.conditions=new Set,this.tasks=new Set,this.open=!1,this.el={root:document.getElementById("journal"),list:document.getElementById("journalList"),count:document.getElementById("journalCount"),epilogue:document.getElementById("journalEpilogue"),toggle:document.getElementById("btnJournal"),tasks:document.getElementById("journalTasks"),exportBtn:document.getElementById("btnJournalExport")},this.total=Object.keys(Es).length+Object.keys(Ts).length,this.el.toggle?.addEventListener("click",()=>this.toggle()),this.el.exportBtn?.addEventListener("click",()=>this.app.exportJournal?.()),this.bindEvents(),this.render()}totalEntries(){return Object.keys(Es).length+this.conditions.size}discover(t,e={}){if(this.seen.has(t)&&!e.force)return!1;const i=Es[t];return i?(this.seen.set(t,{...i,at:{day:this.state.day,time:this.state.time},...e}),this.render(),this.app.ui?.toast(`Recorded · ${i.name}`,"journal"),this.app.sound?.play("lens"),!0):!1}record(t){if(this.conditions.has(t))return!1;const e=Ts[t];return e?(this.conditions.add(t),this.seen.set("cond:"+t,{...e,at:{day:this.state.day,time:this.state.time}}),this.render(),this.app.ui?.toast(`Recorded · ${e.name}`,"journal"),!0):!1}bindEvents(){const t=this.state;t.on("sown",e=>this.discover(e?.id)),t.on("fauna",e=>this.discover(e)),t.on("weather",e=>{Ts[e]&&this.record(e)}),t.on("dawn",()=>this.record("dawn")),t.on("dusk",()=>this.record("dusk")),t.on("plantMature",()=>this.record("mature")),t.on("restored",()=>{this.record("revive"),this.checkArc()}),Zn.forEach(e=>t.on(e.ev,()=>this.completeTask(e.id)))}update(t){const e=this.state;if(this._t=(this._t||0)+t,this._t<.5)return;this._t=0,e.night>.85&&this.seen.has("cond:dusk")&&this.record("night"),(this.app.terrain?.meanWetness??.3)<.02&&(this.app.terrain?.dryFraction??0)>.9&&this.record("drought"),(e.w.rain??0)>.9&&e.elapsed>25?(this._rainT=(this._rainT||0)+.5,this._rainT>20&&this.record("rain")):this._rainT=0}checkArc(){const t=this.app.terrain;if(!t)return;t.blightPatches.every(i=>i.restored)&&!this.arcDone&&(this.arcDone=!0,this.app.ui?.toast("The last of the blight is gone.","vesperglass"),this.app.state.emit("arcComplete")),this.render()}toggle(t){this.open=t??!this.open,this.el.root?.classList.toggle("open",this.open),this.el.toggle?.classList.toggle("active",this.open),this.el.toggle?.setAttribute("aria-expanded",String(this.open)),this.app.sound?.play("ui")}completeTask(t){if(this.tasks.has(t))return;const e=Zn.find(i=>i.id===t);e&&(this.tasks.add(t),this.app.persistence?.markDirty(),this.app.ui?.toast(`${e.label} · noted`,"journal"),this.render())}toMarkdown(t=new Date){const e=[],i=this.app.terrain?.blightPatches||[],n=i.filter(s=>s.restored).length;return e.push("# Vesperglass · Field Journal",""),e.push(`Exported ${t.toISOString().slice(0,16).replace("T"," ")} (UTC)`,""),e.push(`Day ${this.state.day} · ${this.state.phaseLabel}`,""),e.push(`## Keeper's tasks (${this.tasks.size} / ${Zn.length})`,""),Zn.forEach(s=>e.push(`- [${this.tasks.has(s.id)?"x":" "}] ${s.label}`)),e.push("",`## Discoveries (${this.seen.size} / ${Object.keys(Es).length+Object.keys(Ts).length})`,""),[...this.seen.entries()].forEach(([,s])=>{const o=Math.floor(s.at?.time??12),a=Math.floor((s.at?.time??12)%1*60);e.push(`### ${s.name}`,`*Day ${s.at?.day??1}, ${String(o).padStart(2,"0")}:${String(a).padStart(2,"0")}*`,"",s.note,"")}),this.seen.size||e.push("Nothing recorded yet.",""),e.push("## The sentence",""),this.arcDone?e.push("Every wound in the glass has been made good again."):n>0?e.push(`${n} of ${i.length} wastes made good. The rest of the sentence is still waiting.`):e.push("The sentence is not yet begun."),e.join(`
`)+`
`}render(){const t=this.el.list;if(!t)return;const e=this.app.terrain?.blightPatches||[],i=e.filter(o=>o.restored).length;this.el.tasks&&(this.el.tasks.innerHTML=Zn.map(o=>`<li class="task${this.tasks.has(o.id)?" done":""}"><span class="task-box" aria-hidden="true"></span>${o.label}</li>`).join(""),this.el.tasks.setAttribute("aria-label",`Keeper's tasks, ${this.tasks.size} of ${Zn.length} done`)),t.innerHTML="",[...this.seen.entries()].forEach(([o,a])=>{const l=document.createElement("li");l.className="journal-entry";const c=a.at?.day??1,h=String(Math.floor(a.at?.time??12)).padStart(2,"0"),u=String(Math.floor((a.at?.time??12)%1*60)).padStart(2,"0");l.innerHTML=`<span class="je-name">${a.name}</span>
        <span class="je-when">day ${c} · ${h}:${u}</span>
        <span class="je-note">${a.note}</span>`,t.appendChild(l)});const n=Object.keys(Es).length+Object.keys(Ts).length,s=this.seen.size;this.el.count&&(this.el.count.textContent=`${s} / ${n}`),this.el.epilogue&&(this.arcDone?(this.el.epilogue.textContent="“Vesperglass is not a jar. It is a promise that a small world, tended, will outlive the one who sealed it.”",this.el.epilogue.classList.add("complete")):i>0?this.el.epilogue.textContent=`“${i} of ${e.length} wastes made good. The rest of the sentence is still waiting.”`:this.el.epilogue.textContent="“What I have not yet written, because I have not yet seen it — all of this, made good again, in my own hands.”")}}const qo="vesperglass.save.v1",Zc="vesperglass.save.backup",Jc=1;class jc{constructor(t){this.app=t,this.enabled=!0,this._dirty=!1,this._timer=0,this._lastSave=0,this.available=this.probe(),this.loaded=!1,this.available&&(window.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&this.save(!0)}),window.addEventListener("pagehide",()=>this.save(!0)),window.addEventListener("beforeunload",()=>this.save(!0)))}probe(){try{const t="__vg_probe__";return localStorage.setItem(t,"1"),localStorage.removeItem(t),!0}catch{return!1}}markDirty(){this._dirty=!0}snapshot(){const t=this.app,e=t.state,i=t.terrain,n=t.flora,s=new Uint8Array(i.heights.length);let o=1/0,a=-1/0;for(let u=0;u<i.heights.length;u++)i.heights[u]<o&&(o=i.heights[u]),i.heights[u]>a&&(a=i.heights[u]);const l=Math.max(.001,a-o);for(let u=0;u<i.heights.length;u++)s[u]=Math.round((i.heights[u]-o)/l*255);const c=[];let h=1;for(let u=1;u<=s.length;u++)u<s.length&&s[u]===s[u-1]&&h<255?h++:(c.push(s[u-1],h),h=1);return{v:Jc,t:+e.time.toFixed(3),day:e.day,weather:e.targetWeather,lid:e.lidTarget,bio:e.bioSpeed,hField:{n:i.n,min:+o.toFixed(3),span:+l.toFixed(3),rle:c},plants:n.plants.filter(u=>u.seedId).map(u=>({type:u.type,x:+u.x.toFixed(2),z:+u.z.toFixed(2),g:+(u.growth??1).toFixed(2),hp:+(u.hp??1).toFixed(2),over:+(u.overgrowth||0).toFixed(2),seed:u.seedId||void 0})),patches:i.patches.map(u=>u.occupied?1:0),blight:i.blightPatches.map(u=>u.restored?1:0),journal:{seen:[...t.journal.seen.entries()].map(([u,d])=>[u,d.name,d.note,d.at?.day??1,+(d.at?.time??12).toFixed(2)]),conditions:[...t.journal.conditions],arc:!!t.journal.arcDone,tasks:[...t.journal.tasks]},savedAt:Date.now()}}apply(t){if(!t||t.v!==Jc)return!1;const e=this.app,i=e.state,n=e.terrain,s=e.flora;try{if(typeof t.t=="number"&&(i.time=t.t),t.day&&(i.day=t.day),t.weather&&(i.setWeather(t.weather,!0),i.weatherName=t.weather),typeof t.lid=="number"&&(i.lidTarget=t.lid,i.lidOpen=t.lid),typeof t.bio=="number"&&(i.bioSpeed=t.bio),t.hField&&t.hField.n===n.n){const{min:o,span:a,rle:l}=t.hField;let c=0;for(let h=0;h+1<l.length&&c<n.heights.length;h+=2){const u=o+l[h]/255*a,d=l[h+1];for(let f=0;f<d&&c<n.heights.length;f++)n.heights[c++]=u}n.rebuildFromHeights?.()}return Array.isArray(t.patches)&&t.patches.forEach((o,a)=>{n.patches[a]&&(n.patches[a].occupied=!!o)}),Array.isArray(t.blight)&&t.blight.forEach((o,a)=>{const l=n.blightPatches[a];l&&o&&!l.restored&&(l.restored=!0,l.group&&(l.group.visible=!1),l.aura&&(l.aura.material.opacity=0))}),s.clearPlanted?.(),(t.plants||[]).forEach(o=>{const a=o.seed?e.SEEDS.find(c=>c.id===o.seed):null,l=s.plantSeed(o.x,o.z,a||{id:o.type,name:o.type,color:"#8ab"},{silent:!0});l&&(l.growth=o.g!=null?o.g:1,l.hp=o.hp!=null?o.hp:1,l.overgrowth=o.over||0)}),t.journal&&(e.journal.seen.clear(),(t.journal.seen||[]).forEach(([o,a,l,c,h])=>{e.journal.seen.set(o,{name:a,note:l,at:{day:c,time:h}})}),e.journal.conditions=new Set(t.journal.conditions||[]),e.journal.tasks=new Set((t.journal.tasks||[]).filter(o=>typeof o=="string")),e.journal.arcDone=!!t.journal.arc,e.journal.render()),this.loaded=!0,!0}catch(o){return console.warn("[vesperglass] could not restore save:",o),!1}}load(){if(!this.available)return!1;try{const t=localStorage.getItem(qo);return t?this.apply(JSON.parse(t)):!1}catch{return!1}}save(t=!1){if(!this.available||!this.enabled||!t&&!this._dirty)return!1;try{const e=this.snapshot();return localStorage.setItem(qo,JSON.stringify(e)),this._dirty=!1,this._lastSave=performance.now(),!0}catch{return this.available=!1,!1}}clear(){try{localStorage.removeItem(qo)}catch{}}backup(){try{return localStorage.setItem(Zc,JSON.stringify(this.snapshot())),!0}catch{return!1}}hasBackup(){try{return!!localStorage.getItem(Zc)}catch{return!1}}static parseSave(t){let e;try{e=JSON.parse(t)}catch{return null}if(!e||typeof e!="object")return null;const i=e.hField;return!i||!Number.isFinite(i.n)||i.n<8||i.n>512||!Array.isArray(i.rle)||i.rle.length%2!==0||!i.rle.every(Number.isFinite)||!Number.isFinite(i.min)||!Number.isFinite(i.span)?null:e}update(t){!this.available||!this.enabled||(this._timer+=t,!(this._timer<6)&&(this._timer=0,this._dirty&&this.save()))}}const Qc="vesperglass.views";class n_{constructor(t){this.app=t,this.slots=[null,null,null];try{const e=localStorage.getItem(Qc),i=e?JSON.parse(e):null;Array.isArray(i)&&(this.slots=[0,1,2].map(n=>this.valid(i[n])?i[n]:null))}catch{}}valid(t){return t&&Array.isArray(t.p)&&t.p.length===3&&Array.isArray(t.t)&&t.t.length===3&&[...t.p,...t.t].every(Number.isFinite)}save(t){const e=this.app.rig;if(e.mode!=="orbit")return this.app.ui.toast("Views are kept from the outside view","view"),!1;this.slots[t]={p:e.camera.position.toArray(),t:e.controls.target.toArray()};try{localStorage.setItem(Qc,JSON.stringify(this.slots))}catch{}return this.app.ui.toast(`View ${t+1} kept`,"view"),!0}recall(t){const e=this.slots[t];if(!e)return this.app.ui.toast(`View ${t+1} is empty · Alt+${t+1} keeps this view`,"view"),!1;const i=this.app.rig;return i.mode==="inside"?(this.app.ui.toast("Step out of the glass to glide to a view","view"),!1):i.mode==="cinematic"?!1:(i.flyTo(new R(...e.p),new R(...e.t),1.8),this.app.ui.toast(`View ${t+1}`,"view"),!0)}}const s_={broadleaf:"Broadleaf",conifer:"Conifer",shrub:"Shrub",flower:"Glow-flower",mushroom:"Mushroom",fern:"Fern"};class r_{constructor(t){if(this.app=t,this.el=document.getElementById("inspector"),this.lastAt=0,this.shown=null,!this.el)return;const e=t.renderer.domElement;e.addEventListener("pointermove",i=>this.onMove(i)),e.addEventListener("pointerleave",()=>this.hide()),e.addEventListener("pointerdown",()=>this.hide())}describe(t){if(this.app.interactions,!t)return null;const i=this.app.flora.plants.find(s=>{if(!s.obj)return!1;let o=t.object;for(;o;){if(o===s.obj)return!0;o=o.parent}return!1});if(i){const o=(i.seedId?Jr.find(h=>h.id===i.seedId):null)?.name||s_[i.type]||"Plant",a=Math.round(Math.min(1,i.growth??0)*100),l=Math.round(Math.max(0,Math.min(1,i.hp??1))*100),c=i.growth>=1?"mature":"growing";return{title:o,lines:[`${c} · ${a}% grown`,`health ${l}%`]}}const n=t.creature||t.object?.userData?.creature;return n?{title:n.displayName||"Resident",lines:["Tap to greet"]}:null}onMove(t){if(!this.el||t.pointerType!=="mouse")return this.hide();const e=performance.now();if(e-this.lastAt<90)return;this.lastAt=e;const i=this.app.interactions,n=this.app.rig;if(i.dragging||i.pointerDown||n.mode!=="orbit"||i.tool==="lens")return this.hide();i.updatePointerFromEvent(t);const s=i.rayPlants()||i.rayCreatures&&i.rayCreatures(),o=this.describe(s);if(!o)return this.hide();this.show(o,t.clientX,t.clientY)}show(t,e,i){const n=t.title+t.lines.join("|");this.shown!==n&&(this.el.innerHTML=`<b>${t.title}</b>`+t.lines.map(s=>`<span>${s}</span>`).join(""),this.shown=n),this.el.style.transform=`translate(${e+16}px, ${i+16}px)`,this.el.classList.add("show")}hide(){this.el&&(this.el.classList.remove("show"),this.shown=null)}}function Yo(r,t){const e=URL.createObjectURL(r),i=document.createElement("a");i.href=e,i.download=t,document.body.appendChild(i),i.click(),i.remove(),setTimeout(()=>URL.revokeObjectURL(e),4e3)}function $o(r=new Date){const t=e=>String(e).padStart(2,"0");return`${r.getFullYear()}-${t(r.getMonth()+1)}-${t(r.getDate())}_${t(r.getHours())}${t(r.getMinutes())}`}const Ir={low:{pixelRatio:1,shadows:"low",transmissionScale:.78,dust:.4,label:"low"},medium:{pixelRatio:1.35,shadows:"high",transmissionScale:.88,dust:.7,label:"medium"},high:{pixelRatio:2,shadows:"high",transmissionScale:1,dust:1,label:"high"},auto:{pixelRatio:1.8,shadows:"high",transmissionScale:.9,dust:1,label:"auto"}};class o_{constructor(){this.canvas=document.getElementById("scene"),this.state=new rv,this.reduceMotion=window.matchMedia("(prefers-reduced-motion: reduce)").matches,this.quality="auto",this.qualityPreset=Ir.auto,this.params=null,this.helpOpen=!1,this.started=!1,this.SEEDS=Jr,this.RESTORE_MATS=ou,this.frame=0,this.lastTime=performance.now(),this.fpsSamples=[],this.autoQualityLevel=2;const t=new URLSearchParams(location.search);t.get("q")&&(this.quality=t.get("q")),this.forcedShadows=t.get("shadows"),this.forcedPixel=t.get("pixel")?parseFloat(t.get("pixel")):null,t.get("time")&&(this.state.time=parseFloat(t.get("time"))),t.get("weather")&&(this.state.weatherName=t.get("weather"),this.state.targetWeather=t.get("weather")),t.get("motion")==="off"&&(this.reduceMotion=!0),this.initRenderer(),this.initCopier(),this.initScene(),this.buildWorld(),this.interactions=new Zv(this),this.sound=new Qv(this.state),this.interactions.sound=this.sound,this.state.on("bolt",()=>this.sound.play("thunder")),this.ui=new jv(this),this.ui.sound=this.sound,this.journal=new i_(this),this.history=new e_(this),this.persistence=new jc(this),this.views=new n_(this),this.inspector=new r_(this);const e=parseFloat(localStorage.getItem("vesperglass.volume"));Number.isFinite(e)&&(this.sound.volume=ft(e,0,1)),this.bindVisibility(),this.armAudio(),this.bindKeys(),this.bindButtons(),this.bindResize(),this.params,this.quality!=="auto"&&Ir[this.quality]&&this.applyQuality(this.quality),this.forcedShadows&&(this.lighting.setShadowQuality(this.forcedShadows),this.terrarium.setShadowQuality(this.forcedShadows)),this.ui.updateClock(!0),this.ui.updateMeters(),this.ui.updatePlayPause(),this.ui.setWeatherActive(this.state.weatherName),this.ui.setToolAvailability("orbit"),this.history.clear(),this.persistence.load()&&(this.ui.toast("Welcome back, keeper","vesperglass"),this.ui.setWeatherActive(this.state.targetWeather)),this.loop=this.loop.bind(this),requestAnimationFrame(this.loop)}trimShadowCasters(t){let e=0;return[this.flora.group,this.creatures.group,this.terrain.group].forEach(i=>{i&&i.traverse(n=>{if(!n.isMesh||!n.castShadow)return;n.geometry.computeBoundingSphere(),n.geometry.boundingSphere?.radius*Math.max(n.scale.x,n.scale.y,n.scale.z)<t&&(n.castShadow=!1,e++)})}),e}initCopier(){this.copierScene=new $r,this.copierCam=new no(-1,1,1,-1,0,1),this.copier=new Qe({uniforms:{tDiffuse:{value:null}},depthTest:!1,depthWrite:!1,vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",fragmentShader:`varying vec2 vUv; uniform sampler2D tDiffuse;
        void main(){ gl_FragColor = texture2D(tDiffuse, vUv);
        #include <colorspace_fragment>
        }`});const t=new I(new be(2,2),this.copier);t.frustumCulled=!1,this.copierScene.add(t)}initRenderer(){this.renderer=new iv({canvas:this.canvas,antialias:!0,powerPreference:"high-performance",alpha:!1,stencil:!1,preserveDrawingBuffer:!1}),this.renderer.setPixelRatio(this.forcedPixel??Math.min(window.devicePixelRatio,1.8)),this.renderer.setSize(window.innerWidth,window.innerHeight,!1),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=Ls,this.renderer.toneMapping=qa,this.renderer.toneMappingExposure=1.12,this.renderer.outputColorSpace=ni,this.renderer.transmissionResolutionScale=.9,this.renderer.info.autoReset=!0}initScene(){this.scene=new $r,this.scene.background=new ct("#07080a"),this.scene.fog=new il("#070809",.0028),this.rig=new Av(this.renderer,this.scene),this.rig.state=this}buildWorld(){this.lighting=new Iv(this.scene,this.renderer),this.environment=new Nv(this.scene,this.renderer,this.state),this.terrarium=new Ev(this.scene,this.state,this.lighting,this.quality),this.state.terrainInit=!0,this.terrain=new Fv(this.scene,this.state,{quality:this.quality}),this.flora=new Hv(this.scene,this.state,this.terrain,{quality:this.quality}),this.architecture=new Wv(this.scene,this.state,this.terrain),this.creatures=new Yv(this.scene,this.state,this.terrain,this.flora,{quality:this.quality}),this.flora.bakeStatic?.(),this.trimShadowCasters(this.quality==="low"?.42:.2),this.atmosphere=new Kv(this.scene,this.state,this.terrarium,this.terrain,this.lighting,{quality:this.quality}),this.rig.controls.target.set(0,22,0),this.rig.camera.position.set(70,46,84),this.rig.camera.lookAt(0,22,0),this.addIncidentals()}addIncidentals(){const t=new st({color:13146444,metalness:1,roughness:.3}),e=new gt,i=new I(new It(1.4,16,10,0,Math.PI*2,0,Math.PI/2),t);i.position.y=.4,i.rotation.x=Math.PI;const n=new I(new We(.6,.12,6,14,Math.PI),t);n.position.y=1.5,e.add(i,n),e.position.set(-16,14.6,8),this.terrarium.group.add(e);const s=new qs({color:14086374,roughness:.02,metalness:.1,transparent:!0,opacity:.75,ior:2,envMapIntensity:2.2,clearcoat:1,clearcoatRoughness:.02}),o=(()=>{let a=5;return()=>(a=a*16807%2147483647)/2147483647})();for(let a=0;a<7;a++){const l=new I(new cl(.1+o()*.16,0),s),c=o()*Math.PI*2,h=12+o()*5;l.position.set(Math.cos(c)*h,14,Math.sin(c)*h),l.rotation.set(o()*3,o()*3,o()*3),l.castShadow=!0,this.terrarium.group.add(l)}}armAudio(){const t=async()=>{try{await this.sound.init()}catch{}window.removeEventListener("pointerdown",t,!0),window.removeEventListener("keydown",t,!0)};window.addEventListener("pointerdown",t,{capture:!0}),window.addEventListener("keydown",t,{capture:!0})}bindButtons(){document.getElementById("enterBtn").addEventListener("click",()=>this.start()),document.getElementById("btnPhoto")?.addEventListener("click",()=>this.requestPhoto()),document.getElementById("btnExportSave")?.addEventListener("click",()=>this.exportSave()),document.getElementById("btnImportSave")?.addEventListener("click",()=>document.getElementById("importFile")?.click()),document.getElementById("importFile")?.addEventListener("change",t=>{const e=t.target.files?.[0];t.target.value="",e&&this.importSave(e)}),document.getElementById("btnNewTerrarium")?.addEventListener("click",()=>this.newTerrarium()),this.ui.el.seedbar.addEventListener("click",()=>{})}bindKeys(){window.addEventListener("keydown",t=>{if(t.target.tagName==="INPUT")return;if(this.ui&&!this.ui.el.helpSheet.classList.contains("hidden")){t.code==="Escape"&&this.ui.openHelp(!1);return}const e=t.code;if(t.altKey&&/^Digit[1-3]$/.test(e)){t.preventDefault();const i=parseInt(e.slice(5),10)-1;t.shiftKey?this.views.recall(i):this.views.save(i);return}if(e==="KeyP"&&!t.ctrlKey&&!t.metaKey&&!t.altKey){this.requestPhoto();return}if(e==="BracketLeft"||e==="BracketRight"){this.adjustVolume(e==="BracketRight"?.05:-.05);return}if((t.ctrlKey||t.metaKey)&&(e==="KeyZ"||e==="KeyY")){t.preventDefault(),e==="KeyY"||t.shiftKey?this.history.redo():this.history.undo();return}if(this.rig.mode==="inside"&&(this.rig.onKey(t,!0),e==="Escape")){this.setCameraMode("orbit");return}if(e==="KeyI"){this.setCameraMode(this.rig.mode==="inside"?"orbit":"inside");return}if(e==="KeyL"){this.interactions.toggleLid();return}if(e==="Space"){t.preventDefault(),this.state.togglePause();return}if(e==="Escape"){this.rig.mode==="inside"?this.setCameraMode("orbit"):this.appselectOrbit();return}if(e==="Tab"){t.preventDefault(),this.ui.el.toolbar.classList.toggle("collapsed");return}if(e==="KeyH"){this.ui.openHelp(this.ui.el.helpSheet.classList.contains("hidden"));return}if(e==="KeyM"){this.toggleMute();return}if(e==="KeyJ"){this.journal.toggle();return}if(t.shiftKey&&/^Digit[1-6]$/.test(e)){const i=parseInt(e.slice(5))-1,n=["clear","cloudy","rain","storm","snow","mist"];this.setWeather(n[i]);return}if(/^Digit[0-9]$/.test(e)){const i=e==="Digit0"?10:parseInt(e.slice(5)),n=pl[i-1];n&&this.selectTool(n.id);return}e==="ArrowRight"&&this.rig.mode!=="inside"&&t.target.tagName==="BODY"&&this.state.setTime(this.state.time+.25),e==="ArrowLeft"&&this.rig.mode!=="inside"&&t.target.tagName==="BODY"&&this.state.setTime(this.state.time-.25)}),window.addEventListener("keyup",t=>{this.rig.mode==="inside"&&this.rig.onKey(t,!1)})}appselectOrbit(){this.selectTool("orbit")}bindResize(){window.addEventListener("resize",()=>{this.rig.resize(),this.interactions?.resizeLens?.(),this.renderer&&(this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,this.qualityPreset.pixelRatio)),this.renderer.setSize(window.innerWidth,window.innerHeight,!1))})}stageReveal(){const t=["brand","clockChip","timebar","toolbar","weatherbar","atmospherePanel","btnJournal"],e=this.reduceMotion?0:420;t.forEach((i,n)=>{setTimeout(()=>document.getElementById(i)?.classList.add("in"),900+n*e)}),setTimeout(()=>document.body.classList.remove("staging"),900+t.length*e+600)}requestPhoto(){this._photo=!0}adjustVolume(t){const e=ft(Math.round((this.sound.volume+t)*20)/20,0,1);this.sound.volume=e;try{localStorage.setItem("vesperglass.volume",String(e))}catch{}if(this.sound.muted){this.ui.toast(`Volume ${Math.round(e*100)}% · sound is muted (M)`,"audio");return}this.sound.fadeTo(e,.3),this.ui.toast(`Volume ${Math.round(e*100)}%`,"audio")}exportSave(){const t=new Blob([JSON.stringify(this.persistence.snapshot())],{type:"application/json"});Yo(t,`vesperglass-save_${$o()}.json`),this.ui.toast("Save exported","save")}importSave(t){if(t.size>2e6){this.ui.toast("That file is too large to be a Vesperglass save","save");return}const e=new FileReader;e.onload=()=>{const i=jc.parseSave(String(e.result||""));if(!i){this.ui.toast("That file is not a Vesperglass save","save");return}const n=this.persistence.snapshot();this.persistence.backup();let s=!1;try{s=this.persistence.apply(i)}catch{s=!1}if(!s){try{this.persistence.apply(n)}catch{}this.ui.toast("That save could not be read. Your terrarium is unchanged.","save");return}this.history.clear(),this.ui.setWeatherActive(this.state.targetWeather),this.journal.render(),this.persistence.markDirty(),this.persistence.save(!0),this.ui.toast("Save restored · the previous one is kept as a backup","save")},e.onerror=()=>this.ui.toast("The file could not be read","save"),e.readAsText(t)}newTerrarium(){window.confirm(`Start a new terrarium?

The garden will return to its first state. The current one is kept as a backup. Export a save first if you want a copy you can carry around.`)&&(this.persistence.backup(),this.persistence.enabled=!1,this.persistence.clear(),location.reload())}exportJournal(){Yo(new Blob([this.journal.toMarkdown()],{type:"text/markdown"}),`vesperglass-journal_${$o()}.md`),this.ui.toast("Journal exported","journal")}bindVisibility(){document.addEventListener("visibilitychange",()=>{document.hidden?(this.state.paused||(this._autoPaused=!0,this.state.togglePause()),this.sound?.fadeTo(0,.3)):(this._autoPaused&&this.state.paused&&this.state.togglePause(),this._autoPaused=!1,this.sound&&!this.sound.muted&&this.sound.fadeTo(this.sound.volume,.8))})}start(){this.started||(this.started=!0,this.ui.hideIntro(),this.stageReveal(),this.rig.flyTo(new R(58,40,70),new R(0,22,0),4.5),setTimeout(()=>{this.ui.toast("Welcome, keeper","vesperglass"),this.ui.hint("Orbit with the mouse, then try <b>Enter the glass</b> to walk inside.")},1200))}selectTool(t){if(t==="orbit"){this.interactions.setTool("orbit"),this.ui.setActiveTool("orbit"),this.rig.controls.enabled=!0;return}this.rig.mode,this.interactions.setTool(t),this.ui.setActiveTool(t),t!=="orbit"&&this.ui.showContextBar(t)}setWeather(t){this.persistence?.markDirty(),this.state.setWeather(t),this.ui.setWeatherActive(t)}setCameraMode(t){t==="inside"?(this.rig.controls.enabled=!1,this.rig.goInside(()=>{this.ui.el.btnInside.classList.add("active"),this.ui.el.btnOrbit.classList.remove("active"),this.ui.hint("WASD or drag to look · <b>Esc</b> to step back out"),this.selectTool("orbit")})):this.rig.goOutside(()=>{this.ui.el.btnInside.classList.remove("active"),this.ui.el.btnOrbit.classList.add("active")})}toggleMute(){return this.sound.setMuted(!this.sound.muted),this.ui.setMuted(this.sound.muted),this.ui.toast(this.sound.muted?"Sound off":"Sound on","audio"),this.sound.muted}toggleMotion(){this.reduceMotion=!this.reduceMotion,document.body.classList.toggle("reduced-motion",this.reduceMotion),this.rig.reduceMotion=this.reduceMotion}cycleShadow(){const t=["high","low","off"],e=this.qualityPreset.shadows,i=t[(t.indexOf(e)+1)%t.length];return this.qualityPreset={...this.qualityPreset,shadows:i},this.lighting.setShadowQuality(i),this.terrarium.setShadowQuality(i),i}cycleQuality(){const t=["auto","high","medium","low"],e=(t.indexOf(this.quality)+1)%t.length;return this.quality=t[e],this.applyQuality(this.quality),this.quality}applyQuality(t){const e={...Ir[t]};this.qualityPreset=e,this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,e.pixelRatio)),this.renderer.transmissionResolutionScale=e.transmissionScale,this.lighting.setShadowQuality(e.shadows),this.terrarium.setShadowQuality(e.shadows)}setTimeOfDay(t){this.state.setTime(t),this.persistence?.markDirty()}loop(t){requestAnimationFrame(this.loop);const e=Math.min(.05,(t-this.lastTime)/1e3||.016);if(this.lastTime=t,this.frame++,this.fpsSamples.push(e),this.fpsSamples.length>90){const o=this.fpsSamples.reduce((l,c)=>l+c,0)/this.fpsSamples.length;this.fpsSamples.length=0;const a=1/o;if(this.quality==="auto"&&a<34&&this.autoQualityLevel>0){this.autoQualityLevel--;const l=["low","medium","high"],c={...Ir[l[this.autoQualityLevel]]};c.label="auto → "+l[this.autoQualityLevel],this.qualityPreset=c,this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,c.pixelRatio)),this.renderer.transmissionResolutionScale=c.transmissionScale,this.lighting.setShadowQuality(this.autoQualityLevel===0?"low":"high"),this.terrarium.setShadowQuality(this.autoQualityLevel===0?"low":"high"),this.autoQualityLevel===0&&this.ui.toast("Lowered quality to keep things smooth","auto")}}const i=this.reduceMotion?e*.55:e;this.state.update(i),this.lighting.update(this.state,i,this.rig.camera),this.state.sunDir=this.lighting.sun.position.clone().normalize(),this.state.sunTint=this.lighting.sun.color.clone().multiplyScalar(ft(this.lighting.sun.intensity/3.2)),this.state.skyTint=this.lighting.skyTint;const n=new ct("#070809"),s=this.lighting.skyTint.clone().multiplyScalar(.035);if(this.scene.fog.color.copy(n).add(s),this.scene.fog.density=Lt(.0026,.011,this.state.w.fog*.8+this.state.w.rain*.15),this.scene.background.copy(n).lerp(this.lighting.skyTint.clone().multiplyScalar(.03),.7),this.environment.update(this.state,this.rig.camera,i),this.terrarium.update(this.state,i),this.terrain.syncCaustic?.(this.lighting),this.terrain.update(this.state,i,this.rig.camera),this.flora.update(this.state,i,this.rig.camera),this.terrain.updateBlight?.(i,this.flora,this.state),this.terrain.accumulateSnow?.(i,this.state),this.architecture.update(this.state,i,this.rig.camera),this.creatures.update(i,this.rig.camera),this.atmosphere.update(i,this.rig.camera),this.rig.update(i),this.interactions.update(i),this.ui.update(i),this.sound.update(this.state,i),this.journal.update(i),this.persistence.update(i),this.interactions._lensOn){this.renderer.setRenderTarget(this.interactions.lensRT),this.renderer.render(this.scene,this.rig.camera);const o=this.interactions.lensUniforms,a=this.renderer.getPixelRatio();o.uCentre.value.set(this.interactions._lensCentre.x*a,(window.innerHeight-this.interactions._lensCentre.y)*a),o.uRadius.value=this.interactions.lensSize*.5*a,this.renderer.setRenderTarget(null),this.copier.uniforms.tDiffuse.value=this.interactions.lensRT.texture,this.renderer.autoClear=!1,this.renderer.render(this.copierScene,this.copierCam),this.renderer.render(this.interactions.lensScene,this.interactions.lensOrtho),this.renderer.autoClear=!0}else this.renderer.render(this.scene,this.rig.camera);this._photo&&(this._photo=!1,this.renderer.domElement.toBlob(o=>{o&&Yo(o,`vesperglass_${$o()}.png`)},"image/png"),this.ui.toast("Photograph taken","photo"))}}const a_=new o_;window.__vesperglass=a_;window.addEventListener("load",()=>{setTimeout(()=>{const r=document.getElementById("loadBar");r&&(r.style.width="100%");const t=document.getElementById("loadLabel");t&&(t.textContent="ready");const e=document.getElementById("enterBtn");e&&(e.disabled=!1)},600)});
