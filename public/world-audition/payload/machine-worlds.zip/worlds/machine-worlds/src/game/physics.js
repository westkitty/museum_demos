import { END, PLATFORMS, START, pose } from './route.js';
export const FIXED_STEP = 1 / 60;
export const RUN_SPEED = 5.65;
export const JUMP_SPEED = 10.6;
export const GRAVITY = 23.5;
export const PLAYER_HALF_WIDTH = 0.39;
export const CAMERALEAD = 1.8;
const COYOTE_SECONDS = 0.12;
const BUFFER_SECONDS = 0.16;
const FALL_MARGIN = 13;
export class GameSimulation {
    player = {
        x: START.x, y: START.y, vx: 0, vy: 0, facing: 1,
        groundedId: START.platformId, act: 0, finished: false,
    };
    lifts = [0, 0, 0];
    liftActive = [false, false, false];
    time = 0;
    reducedMotion = false;
    checkpoints = [
        { ...START, act: 0 },
    ];
    onEvent;
    coyote = COYOTE_SECONDS;
    jumpBuffer = 0;
    jumpLatch = false;
    interactLatch = false;
    respawnLatch = false;
    constructor(onEvent = () => { }) {
        this.onEvent = onEvent;
    }
    getPlatformPose(spec, t = this.time) {
        return pose(spec, t, spec.kind === 'lift' ? this.lifts[spec.act] : 0, this.reducedMotion);
    }
    getSpec(id) { return PLATFORMS.find(p => p.id === id); }
    rememberCheckpoint(spec) {
        if (!spec.checkpoint)
            return;
        const prior = this.checkpoints.at(-1);
        const rank = (act, index) => act * 100 + index;
        const previousSpec = this.getSpec(prior.platformId);
        if (rank(spec.act, spec.index) <= rank(previousSpec.act, previousSpec.index))
            return;
        // Checkpoint is always static/ledge, stable on reload.
        this.checkpoints.push({ x: spec.x, y: spec.top, platformId: spec.id, act: spec.act });
        this.onEvent({ type: 'checkpoint', act: spec.act, platformId: spec.id });
    }
    resetToCheckpoint() {
        const last = this.checkpoints.at(-1);
        this.player.x = last.x;
        this.player.y = last.y;
        this.player.vx = 0;
        this.player.vy = 0;
        this.player.facing = 1;
        this.player.groundedId = last.platformId;
        this.player.act = last.act;
        this.player.finished = false;
        this.jumpBuffer = 0;
        this.coyote = COYOTE_SECONDS;
        // Lifts below the checkpoint remain completed, preventing invalid stage topology.
        for (let i = 0; i < 3; i++) {
            if (i < last.act) {
                this.lifts[i] = 1;
                this.liftActive[i] = false;
            }
        }
        this.onEvent({ type: 'respawn', act: last.act });
    }
    resetFull() {
        this.checkpoints.length = 0;
        this.checkpoints.push({ ...START, act: 0 });
        for (let i = 0; i < 3; i++) {
            this.lifts[i] = 0;
            this.liftActive[i] = false;
        }
        this.time = 0;
        this.resetToCheckpoint();
    }
    step(dt, input) {
        if (this.player.finished)
            return;
        this.time += dt;
        const p = this.player;
        const prevX = p.x;
        const prevY = p.y;
        if (input.respawn && !this.respawnLatch)
            this.resetToCheckpoint();
        this.respawnLatch = input.respawn;
        if (input.jump && !this.jumpLatch)
            this.jumpBuffer = BUFFER_SECONDS;
        this.jumpLatch = input.jump;
        this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);
        // Platform motion first. Safe, collision-authoritative, carries standing riders.
        const footSpec = this.getSpec(p.groundedId);
        const footBefore = footSpec ? this.getPlatformPose(footSpec, this.time - dt) : null;
        for (let i = 0; i < this.lifts.length; i++) {
            if (this.liftActive[i] && this.lifts[i] < 1) {
                this.lifts[i] = this.reducedMotion ? 1 : Math.min(1, this.lifts[i] + dt / 7.6);
                if (this.lifts[i] >= 1) {
                    this.liftActive[i] = false;
                    this.onEvent({ type: 'lift-end', act: i });
                }
            }
        }
        if (footSpec && footBefore && p.groundedId) {
            const footAfter = this.getPlatformPose(footSpec);
            p.x += footAfter.x - footBefore.x;
            p.y += footAfter.top - footBefore.top;
        }
        if (input.interact && !this.interactLatch && footSpec?.kind === 'lift' && p.groundedId && !this.liftActive[footSpec.act] && this.lifts[footSpec.act] < 1) {
            this.liftActive[footSpec.act] = true;
            this.onEvent({ type: 'lift-start', act: footSpec.act });
        }
        this.interactLatch = input.interact;
        const direction = Number(input.right) - Number(input.left);
        const acceleration = p.groundedId ? 35 : 24;
        const targetSpeed = direction * RUN_SPEED;
        p.vx += Math.max(-acceleration * dt, Math.min(acceleration * dt, targetSpeed - p.vx));
        if (direction !== 0)
            p.facing = direction;
        if (p.groundedId)
            this.coyote = COYOTE_SECONDS;
        else
            this.coyote = Math.max(0, this.coyote - dt);
        if (this.jumpBuffer > 0 && this.coyote > 0) {
            p.vy = JUMP_SPEED;
            p.groundedId = null;
            this.coyote = 0;
            this.jumpBuffer = 0;
        }
        p.x = Math.max(-17.8, Math.min(17.8, p.x + p.vx * dt));
        if (!p.groundedId) {
            p.vy = Math.max(-19, p.vy - GRAVITY * dt);
            p.y += p.vy * dt;
        }
        else {
            const platform = this.getSpec(p.groundedId);
            if (!platform)
                p.groundedId = null;
            else {
                const support = this.getPlatformPose(platform);
                if (Math.abs(p.x - support.x) > support.width / 2 + PLAYER_HALF_WIDTH * 0.7)
                    p.groundedId = null;
                else
                    p.y = support.top;
            }
        }
        // One-way surfaces; landing only from above while descending.
        if (!p.groundedId && p.vy <= 0) {
            const candidates = PLATFORMS.filter(spec => {
                const top = this.getPlatformPose(spec);
                return prevY >= top.top - 0.12 && p.y <= top.top + 0.08 && Math.abs(p.x - top.x) <= top.width / 2 + PLAYER_HALF_WIDTH;
            }).sort((a, b) => this.getPlatformPose(b).top - this.getPlatformPose(a).top);
            const landing = candidates[0];
            if (landing) {
                p.y = this.getPlatformPose(landing).top;
                p.vy = 0;
                p.groundedId = landing.id;
                this.rememberCheckpoint(landing);
                if (landing.act !== p.act) {
                    p.act = landing.act;
                    this.onEvent({ type: 'act', act: p.act });
                }
                if (landing.kind === 'overlook') {
                    p.finished = true;
                    this.onEvent({ type: 'complete' });
                }
            }
        }
        if (p.y < this.checkpoints.at(-1).y - FALL_MARGIN)
            this.resetToCheckpoint();
        // Fail-safe on numerical runaway / lost collision state.
        if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || Math.abs(p.y) > END.y + 800)
            this.resetToCheckpoint();
        void prevX;
    }
}
