import * as THREE from 'three';
/**
 * Authored, collision-free scenic layer for E09. The physics platform manifest in
 * level.ts remains the sole authority for walkable surfaces. These structures
 * are visual interpretations, never reconstructions claimed to be historical.
 * No network textures, per-frame object allocation or additional render loop.
 */
const ERA_COLORS = [0xe8cb93, 0xb8a2f5, 0x6dd9f3, 0xc6a56d];
const COLOR_STOPS = [0x0e1729, 0x130f2d, 0x0a1a2b, 0x071c28];
const TOP_STOPS = [0x172034, 0x1c1542, 0x08203a, 0x0a3040];
const GROUND_STOPS = [0x34251e, 0x211b35, 0x142837, 0x183a3c];
const rand = (n) => {
    const v = Math.sin(n * 53.119 + 11.29) * 92341.734;
    return v - Math.floor(v);
};
const mat = (color, roughness = .62, metalness = .16, glow = 0) => new THREE.MeshStandardMaterial({
    color, roughness, metalness, emissive: glow ? color : 0x000000,
    emissiveIntensity: glow, side: THREE.DoubleSide,
});
const glow = (color, opacity = 1) => new THREE.MeshBasicMaterial({
    color, transparent: opacity < 1, opacity, depthWrite: opacity >= 1,
    side: THREE.DoubleSide,
});
const add = (parent, geometry, material, x = 0, y = 0, z = 0, cast = true) => {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(x, y, z);
    mesh.castShadow = cast;
    mesh.receiveShadow = cast;
    parent.add(mesh);
    return mesh;
};
const box = (parent, x, y, z, w, h, d, material) => add(parent, new THREE.BoxGeometry(w, h, d), material, x, y, z);
const cylinder = (parent, x, y, z, rt, rb, h, segments, material) => add(parent, new THREE.CylinderGeometry(rt, rb, h, segments), material, x, y, z);
const torus = (parent, x, y, z, radius, thickness, material) => add(parent, new THREE.TorusGeometry(radius, thickness, 8, 96), material, x, y, z, false);
const curve = (parent, points, radius, material, tubularSegments = 42) => add(parent, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), tubularSegments, radius, 5), material, 0, 0, 0, false);
export class ArtDirection {
    root = new THREE.Group();
    distant = new THREE.Group();
    textures = [];
    movers = [];
    pulses = [];
    sky;
    horizon;
    zenith;
    nadir;
    water;
    horizonTargets = COLOR_STOPS.map(color => new THREE.Color(color));
    topTargets = TOP_STOPS.map(color => new THREE.Color(color));
    groundTargets = GROUND_STOPS.map(color => new THREE.Color(color));
    beacons = [];
    time = 0;
    lowEffects = false;
    constructor(parent) {
        this.root.name = 'E09 authored scenic finish / never collision authoritative';
        parent.add(this.root);
        this.root.add(this.distant);
        this.horizon = new THREE.Color(COLOR_STOPS[0]);
        this.zenith = new THREE.Color(TOP_STOPS[0]);
        this.nadir = new THREE.Color(GROUND_STOPS[0]);
        this.sky = new THREE.ShaderMaterial({
            depthWrite: false, side: THREE.BackSide, fog: false,
            uniforms: {
                uHorizon: { value: this.horizon },
                uZenith: { value: this.zenith },
                uNadir: { value: this.nadir },
            },
            vertexShader: `varying vec3 vLocal; void main(){ vLocal=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
            fragmentShader: `varying vec3 vLocal; uniform vec3 uHorizon; uniform vec3 uZenith; uniform vec3 uNadir;
        void main(){ float h=normalize(vLocal).y; vec3 sky=mix(uHorizon,uZenith,smoothstep(0.0,0.88,h));
          sky=mix(uNadir,sky,smoothstep(-0.55,0.08,h));
          gl_FragColor=vec4(sky,1.0); }`,
        });
        add(this.root, new THREE.SphereGeometry(470, 40, 24), this.sky, 0, 0, -100, false).name = 'Atmospheric gradient / source eras';
        this.makePaper();
        this.makeRooms();
        this.makeMonolith();
        this.water = this.makeBecoming();
        this.makeAmbient();
        this.makePulses();
    }
    parchmentTexture() {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 512;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas is required for locally generated paper texture');
        ctx.fillStyle = '#e6d8bc';
        ctx.fillRect(0, 0, 512, 512);
        // Ink-only and fibrous marks; deterministic, no faux historical records.
        for (let i = 0; i < 1200; i++) {
            const x = rand(i + 110) * 512, y = rand(i + 400) * 512;
            ctx.strokeStyle = i % 4 === 0 ? '#8d795433' : '#fff4d027';
            ctx.lineWidth = i % 5 === 0 ? .8 : .45;
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + 3 + rand(i + 13) * 17, y - 1);
            ctx.stroke();
        }
        for (let i = 0; i < 14; i++) {
            const y = 48 + i * 31;
            ctx.fillStyle = i % 5 === 0 ? '#7b624a99' : '#72665269';
            ctx.fillRect(70, y, 320 - rand(i + 194) * 85, 2);
        }
        ctx.strokeStyle = '#a17f5b80';
        ctx.lineWidth = 3;
        ctx.strokeRect(21, 21, 470, 470);
        ctx.strokeStyle = '#a17f5b50';
        ctx.lineWidth = 1;
        ctx.strokeRect(31, 31, 450, 450);
        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.anisotropy = 4;
        this.textures.push(tex);
        return tex;
    }
    bentPage(width, height, bend) {
        const geo = new THREE.PlaneGeometry(width, height, 32, 24);
        const pos = geo.getAttribute('position');
        for (let i = 0; i < pos.count; i++) {
            const x = pos.getX(i), y = pos.getY(i);
            pos.setZ(i, Math.sin(x / width * Math.PI * 1.4) * bend + Math.sin(y / height * Math.PI) * bend * .45 + (x * x / (width * width)) * .38);
        }
        pos.needsUpdate = true;
        geo.computeVertexNormals();
        return geo;
    }
    makePaper() {
        const paper = new THREE.MeshStandardMaterial({ map: this.parchmentTexture(), color: 0xf8e7c8, roughness: .92,
            metalness: 0, side: THREE.DoubleSide, transparent: false });
        const binding = mat(0x9a7145, .42, .67), gilded = mat(0xf5c982, .37, .72, .06);
        const ink = mat(0x493b37, .83, 0), illum = glow(0xffdfac, .72);
        // The valley between huge independent document pages is the first playable space.
        for (let i = 0; i < 9; i++) {
            const side = i % 2 ? -1 : 1, z = 11 - i * 4.8;
            const g = new THREE.Group();
            g.position.set(side * (12.3 + rand(i) * 3.6), 7 + rand(i + 21) * 3, z);
            g.rotation.y = side * (.32 + rand(i + 44) * .3);
            const page = add(g, this.bentPage(8.2, 12.0, 1.1 + rand(i + 7) * .5), paper);
            page.rotation.y = side * .18;
            page.castShadow = true;
            box(g, -3.95, 0, .5, .15, 12.3, .2, binding);
            box(g, 0, -6.0, .4, 8.3, .17, .2, gilded);
            const corner = torus(g, 3.12, 4.9, .4, .34, .065, gilded);
            corner.rotation.z = Math.PI / 4;
            this.root.add(g);
            this.movers.push({ object: g, origin: g.position.y, amplitude: .22, speed: .38, phase: i * .7 });
        }
        // Oversized archive binding hoops establish human scale and a cohesive landmark.
        for (let i = 0; i < 6; i++) {
            const z = 7 - i * 6.2, side = i % 2 === 0 ? -1 : 1;
            const ring = torus(this.root, side * 10, 9, z, 4.4, .24, binding);
            ring.rotation.y = Math.PI / 2 + side * .35;
            torus(this.root, side * 10, 9, z, 4.6, .035, gilded).rotation.y = ring.rotation.y;
        }
        // Lithographic line-work grows into actual columns and cornices.
        for (let i = 0; i < 16; i++) {
            const z = 10 - i * 2.65, side = i % 2 ? -1 : 1, x = side * (6.6 + rand(i + 250) * 2.2);
            const base = cylinder(this.root, x, 1.45, z, .76, .91, 2.9, 10, paper);
            base.rotation.y = i * .13;
            cylinder(this.root, x, 3.05, z, .91, .82, .22, 10, gilded);
            cylinder(this.root, x, 3.45, z, .11, .11, .52, 8, binding);
            torus(this.root, x, 3.78, z, .24, .065, illum).rotation.x = Math.PI / 2;
        }
        // Three concentric half-open chapter gates look architectural but are non-colliding.
        for (let k = 0; k < 3; k++) {
            const z = -6 - k * 9;
            for (const side of [-1, 1]) {
                const x = side * 5.8;
                box(this.root, x, 5.3, z, .52, 9.4, 1.0, paper);
                box(this.root, x, 10.25, z, .79, .18, 1.2, gilded);
                curve(this.root, [new THREE.Vector3(x, 10.1, z), new THREE.Vector3(side * 3.6, 12.0, z), new THREE.Vector3(0, 13.1, z)], .11, gilded, 28);
            }
        }
        // Floating print proofs occupy the deep left field as an environmental focal sculpture.
        const book = new THREE.Group();
        book.position.set(-26, 9, -16);
        for (let p = 0; p < 9; p++) {
            const leaf = add(book, this.bentPage(8.3, 11.6, .9), paper, (p - 4) * .58, 0, (p - 4) * .36);
            leaf.rotation.y = .12 + p * .07;
        }
        box(book, -.2, -6.3, .0, 6, .6, 4, binding);
        this.root.add(book);
        const smallGlyphs = new THREE.InstancedMesh(new THREE.BoxGeometry(.6, .04, .06), ink, 132);
        const instance = new THREE.Object3D();
        for (let i = 0; i < 132; i++) {
            const side = i % 2 === 0 ? -1 : 1, col = i % 11, row = Math.floor(i / 11);
            instance.position.set(side * (12.7 + col * .26), 2.2 + row * .52, 11 - col * 4.5);
            instance.rotation.set(0, side * .1, 0);
            instance.scale.set(.4 + rand(i + 17) * 1.3, 1, 1);
            instance.updateMatrix();
            smallGlyphs.setMatrixAt(i, instance.matrix);
        }
        smallGlyphs.instanceMatrix.needsUpdate = true;
        smallGlyphs.castShadow = false;
        this.distant.add(smallGlyphs);
    }
    arch(parent, w, h, thickness, material) {
        const outer = new THREE.Shape();
        const half = w / 2, spring = h - half * .67;
        outer.moveTo(-half, -.4);
        outer.lineTo(half, -.4);
        outer.lineTo(half, spring);
        outer.absarc(0, spring, half, 0, Math.PI, false);
        outer.lineTo(-half, -.4);
        const hole = new THREE.Path();
        const inner = half - thickness;
        hole.moveTo(-inner, -1);
        hole.lineTo(-inner, spring);
        hole.absarc(0, spring, inner, Math.PI, 0, true);
        hole.lineTo(inner, -1);
        hole.closePath();
        outer.holes.push(hole);
        const geo = new THREE.ExtrudeGeometry(outer, { depth: .65, steps: 1, bevelEnabled: true,
            bevelSegments: 2, bevelThickness: .09, bevelSize: .07, curveSegments: 20 });
        geo.computeVertexNormals();
        return add(parent, geo, material);
    }
    makeRooms() {
        const purple = mat(0x47405c, .42, .42), pewter = mat(0xb3a4d3, .3, .74), window = glow(0xa1bce9, .34), internal = glow(0xdfc4ff, .7), dark = mat(0x151625, .65, .32);
        for (let i = 0; i < 6; i++) {
            const side = i % 2 ? -1 : 1, z = -39 - i * 6.6, x = side * (13 + rand(i + 82) * 3);
            const gallery = new THREE.Group();
            gallery.position.set(x, 1.2 + rand(i) * 3, z);
            gallery.rotation.y = side * .2;
            this.arch(gallery, 9.2, 10.8, .83, purple).position.set(-4.6, 0, 2.9);
            box(gallery, 0, -.17, 0, 9.8, .35, 8.8, dark);
            for (let r = 0; r < 4; r++) {
                const zz = -3.4 + r * 2.2;
                const arch = this.arch(gallery, 6.6, 7.7, .32, pewter);
                arch.position.set(-3.3, .0, zz);
                arch.scale.set(.67, .71, .6);
            }
            torus(gallery, 0, 7.5, 0, 2.5, .15, pewter);
            torus(gallery, 0, 7.5, .03, 2.2, .045, internal);
            const pane = box(gallery, 0, 4.2, -3.9, 5.8, 6.4, .07, window);
            pane.castShadow = false;
            pane.receiveShadow = false;
            for (let k = 0; k < 4; k++)
                box(gallery, -2.1 + k * 1.4, 4.4, -3.85, .07, 5.7, .13, pewter);
            box(gallery, 0, 4.4, -3.84, 5.8, .07, .13, pewter);
            this.root.add(gallery);
            this.movers.push({ object: gallery, origin: gallery.position.y, amplitude: .14, speed: .48, phase: i * 1.7 });
        }
        // Suspended bridges indicate that separated scenes are beginning to find each other.
        for (let i = 0; i < 7; i++) {
            const z = -42 - i * 4.6, side = i % 2 === 0 ? -1 : 1;
            const chain = [new THREE.Vector3(side * 18, 11, z + 1), new THREE.Vector3(side * 12, 13, z),
                new THREE.Vector3(side * 7, 12, z - 1)];
            curve(this.root, chain, .10, pewter, 32);
            const knob = torus(this.root, side * 12.0, 12.7, z, 1.6, .055, internal);
            knob.rotation.y = .15;
        }
        // One coherent vault above the central line hints at what the next generation will restore.
        for (let i = 0; i < 3; i++) {
            const z = -43 - i * 12;
            for (const side of [-1, 1]) {
                box(this.root, side * 6.2, 5.4, z, .5, 9, .75, purple);
                curve(this.root, [new THREE.Vector3(side * 6.2, 9.6, z), new THREE.Vector3(side * 3.9, 12.0, z), new THREE.Vector3(0, 13.1, z)], .12, pewter);
            }
            cylinder(this.root, 0, 13.5, z, .4, .6, .4, 12, internal);
        }
    }
    makeMonolith() {
        const basalt = mat(0x182538, .33, .62), silver = mat(0x7ea2b6, .27, .83), cyan = mat(0x7ce5ec, .26, .38, .6), obsidian = mat(0x090e19, .18, .65), vellum = mat(0x314558, .61, .3);
        // Colonnaded approach: huge compression ribs mirror the one-file artifact's scale.
        for (let i = 0; i < 14; i++) {
            const z = -78 - i * 3.45;
            for (const side of [-1, 1]) {
                const x = side * (10.8 + rand(i + 25) * 1.8), height = 8.5 + (i % 4) * 1.25;
                cylinder(this.root, x, height / 2, z, .58, .83, height, 8, basalt);
                cylinder(this.root, x, height + .24, z, 1.14, .82, .48, 8, silver);
                box(this.root, x, height + .6, z, 2.1, .2, 1.5, cyan);
            }
            if (i % 2 === 0) {
                curve(this.root, [new THREE.Vector3(-10.7, 10.0, z), new THREE.Vector3(-6, 13.5, z),
                    new THREE.Vector3(0, 15.3, z), new THREE.Vector3(6, 13.5, z), new THREE.Vector3(10.7, 10.0, z)], .17, silver);
            }
        }
        // A second, broken-open slab exposes layered page edges, not an invented machine.
        const stack = new THREE.Group();
        stack.position.set(19, 10, -101);
        stack.rotation.y = -.25;
        box(stack, 0, 7, 0, 12, 32, 3.6, obsidian);
        for (let i = 0; i < 42; i++) {
            box(stack, -5.7 + i * .275, 7, 2.03, .035, 30 + (i % 9) * .24, .04, i % 7 === 0 ? cyan : silver);
        }
        for (let i = 0; i < 9; i++) {
            const y = -6 + i * 3.3;
            box(stack, 0, y, 2.12, 11.5, .055, .045, vellum);
        }
        torus(stack, 0, 15, 2.42, 5.2, .16, cyan);
        torus(stack, 0, 15, 2.43, 4.5, .045, silver);
        this.root.add(stack);
        const hover = new THREE.Group();
        hover.position.set(-23, 20, -95);
        const core = add(hover, new THREE.OctahedronGeometry(5.2, 0), obsidian);
        core.rotation.z = .22;
        torus(hover, 0, 0, 0, 8.4, .2, silver);
        torus(hover, 0, 0, 0, 7.1, .07, cyan).rotation.y = .45;
        this.root.add(hover);
        this.movers.push({ object: hover, origin: hover.position.y, amplitude: .35, speed: .35, phase: 1.8 });
        // Compressed dark margin leaves the traversable path bright and readable.
        for (let i = 0; i < 8; i++) {
            const x = i % 2 ? -7.8 : 7.8, z = -80 - i * 5.1;
            box(this.root, x, 1.9, z, .7, 3.8, 1.3, obsidian);
            box(this.root, x, 4, z, 1.1, .23, 1.6, cyan);
        }
    }
    makeBecoming() {
        const bronze = mat(0xb99b6a, .38, .78), dark = mat(0x0c1e2b, .4, .7), cyan = mat(0x70d6df, .25, .54, .65), glass = glow(0x8df1f3, .46), stone = mat(0x45595a, .92, .1);
        const construction = new THREE.Group();
        construction.position.set(0, -9, -253);
        this.root.add(construction);
        // Architectural legibility: radial dome ribs, lantern, central colonnade.
        for (let i = 0; i < 18; i++) {
            const a = i * Math.PI / 9, x = Math.cos(a) * 15.1, z = Math.sin(a) * 15.1;
            cylinder(construction, x, 7.7, z, .36, .48, 11.1, 8, bronze);
            cylinder(construction, x, 14, z, .55, .55, .45, 10, cyan);
        }
        for (let i = 0; i < 12; i++) {
            const a = i * Math.PI / 6, fx = Math.cos(a), fz = Math.sin(a);
            curve(construction, [new THREE.Vector3(fx * 13, 15, fz * 13), new THREE.Vector3(fx * 12.3, 20.5, fz * 12.3),
                new THREE.Vector3(fx * 8.6, 24.8, fz * 8.6), new THREE.Vector3(0, 27.3, 0)], .19, bronze, 48);
        }
        cylinder(construction, 0, 28, 0, 1.8, 3.0, 2.9, 12, bronze);
        cylinder(construction, 0, 30.2, 0, .48, .6, 1.5, 10, cyan);
        // Distinct volumes for six wings: decorative fascia, stepped roof, inset glazing.
        const wings = [
            { x: 0, z: -26, w: 16, d: 32, h: 13 }, { x: 0, z: 26, w: 16, d: 31, h: 13 },
            { x: -26, z: 0, w: 30, d: 16, h: 13 }, { x: 26, z: 0, w: 30, d: 16, h: 13 },
            { x: -22, z: -22, w: 15, d: 13, h: 11 }, { x: 22, z: 22, w: 15, d: 13, h: 11 },
        ];
        for (let i = 0; i < wings.length; i++) {
            const w = wings[i];
            box(construction, w.x, 15.3 + w.h * .16, w.z, w.w + 2, .22, w.d + 2, bronze);
            box(construction, w.x, 15.6 + w.h * .16, w.z, w.w - 2, .16, w.d - 2, dark);
            for (let k = 0; k < Math.max(3, Math.floor(w.d / 5)); k++) {
                const zz = w.z - w.d / 2 + 2.5 + k * 5;
                box(construction, w.x - w.w / 2 - .22, 7.1, zz, .24, 6.1, 2.5, glass);
                box(construction, w.x + w.w / 2 + .22, 7.1, zz, .24, 6.1, 2.5, glass);
            }
            // Exterior structural reliefs and restrained cornices.
            for (let k = 0; k < Math.max(2, Math.floor(w.w / 5)); k++) {
                const xx = w.x - w.w / 2 + 2.5 + k * 5;
                box(construction, xx, 6.9, w.z - w.d / 2 - .25, 2.4, 5.8, .28, glass);
                box(construction, xx, 6.9, w.z + w.d / 2 + .25, 2.4, 5.8, .28, glass);
            }
        }
        // The unbuilt eastern bay is a translucent incomplete lattice, clearly different from the finished structure.
        const skeletal = new THREE.Group();
        skeletal.position.set(45, 0, -13);
        construction.add(skeletal);
        for (let col = 0; col < 5; col++) {
            const x = (col - 2) * 4;
            box(skeletal, x, 13, 0, .22, 22, .24, bronze);
            for (let row = 0; row < 5; row++) {
                box(skeletal, x, 4 + row * 4, 0, 4, .12, .2, row % 2 ? cyan : bronze);
            }
        }
        const schematic = box(skeletal, 0, 14.5, .08, 15, 13, .045, glass);
        schematic.castShadow = false;
        schematic.receiveShadow = false;
        // Layered coast without any claim to an exact surveyed island shoreline.
        const coast = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1, 0), stone, 150);
        const dummy = new THREE.Object3D();
        for (let i = 0; i < 150; i++) {
            const angle = rand(i + 690) * Math.PI * 2, r = 66 + rand(i + 500) * 10;
            dummy.position.set(Math.cos(angle) * r, 1 + rand(i + 90) * 1.1, Math.sin(angle) * r);
            dummy.rotation.set(rand(i + 71) * .2, rand(i + 200) * 6.28, rand(i + 901) * .18);
            dummy.scale.set(1.4 + rand(i) * 2.9, .65 + rand(i + 31) * 1.8, 1.0 + rand(i + 22) * 2.1);
            dummy.updateMatrix();
            coast.setMatrixAt(i, dummy.matrix);
        }
        coast.instanceMatrix.needsUpdate = true;
        coast.castShadow = false;
        coast.receiveShadow = true;
        construction.add(coast);
        const trees = new THREE.InstancedMesh(new THREE.ConeGeometry(1, 3, 7), mat(0x325449, .95), 116);
        const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(.16, .22, 1, 6), mat(0x594535, .96), 116);
        for (let i = 0; i < 116; i++) {
            const a = rand(i + 170) * Math.PI * 2, r = 43 + rand(i + 240) * 23;
            const x = Math.cos(a) * r, z = Math.sin(a) * r;
            const h = 3.5 + rand(i + 61) * 3.8;
            dummy.position.set(x, 4 + h * .5, z);
            dummy.rotation.set(0, rand(i + 16) * Math.PI * 2, 0);
            dummy.scale.set(1.2 + rand(i + 42) * 1.1, h / 2.6, 1.2 + rand(i + 110) * 1.1);
            dummy.updateMatrix();
            trees.setMatrixAt(i, dummy.matrix);
            dummy.position.set(x, 3.9, z);
            dummy.rotation.set(0, 0, 0);
            dummy.scale.set(1, h * 1.3, 1);
            dummy.updateMatrix();
            trunks.setMatrixAt(i, dummy.matrix);
        }
        trunks.instanceMatrix.needsUpdate = true;
        trees.instanceMatrix.needsUpdate = true;
        trees.castShadow = false;
        trees.receiveShadow = false;
        trunks.castShadow = false;
        construction.add(trunks, trees);
        // Gold spire, lagoon and pier remain recognizable visual anchors from vNext.
        const spire = torus(construction, -35, 33, -30, 4.1, .12, bronze);
        spire.rotation.x = Math.PI / 2;
        cylinder(construction, -35, 40, -30, .15, .8, 7, 8, cyan);
        torus(construction, 34, 2.4, 30, 21, .11, glass).rotation.x = Math.PI / 2;
        for (let i = 0; i < 14; i++) {
            const z = 55 + i * 4.3;
            for (const side of [-1, 1]) {
                cylinder(construction, side * 4.2, 3.5, z, .15, .2, 2.1, 8, bronze);
                cylinder(construction, side * 4.2, 4.5, z, .28, .28, .2, 8, cyan);
            }
        }
        // Water is present as readable patterned surface, not another physics layer.
        const waterMaterial = new THREE.MeshStandardMaterial({ color: 0x0a4861, transparent: true, opacity: .43,
            metalness: .34, roughness: .21, emissive: 0x167e95, emissiveIntensity: .11, side: THREE.DoubleSide, depthWrite: false });
        const surface = add(construction, new THREE.PlaneGeometry(180, 180, 1, 1), waterMaterial, 0, -1.65, 0, false);
        surface.rotation.x = -Math.PI / 2;
        surface.name = 'Night water caustic accent';
        surface.renderOrder = 1;
        // Prominent arrival sequence: constructed road-side lantern pylons, no extra gameplay objects.
        this.beacons.push(cyan);
        for (let i = 0; i < 11; i++) {
            const z = -130 - i * 5.5;
            for (const side of [-1, 1]) {
                const x = side * 7.2;
                box(this.root, x, 3.8, z, .32, 6.2, .36, dark);
                box(this.root, x, 6.95, z, .94, .16, .72, bronze);
                const lamp = box(this.root, x, 6.65, z, .45, .3, .4, cyan);
            }
        }
        // Massive drafting rings pull the eye into the final rotunda instead of fragmenting the scene.
        for (let i = 0; i < 5; i++) {
            const z = -152 - i * 8.0;
            const ring = torus(this.root, i % 2 ? -13 : 13, 12.2, z, 5.8, .13, bronze);
            ring.rotation.y = .36;
            const arc = torus(this.root, i % 2 ? -13 : 13, 12.2, z, 6.1, .04, cyan);
            arc.rotation.y = .36;
        }
        return surface;
    }
    makeAmbient() {
        const phases = [{ a: 17, b: -31, color: 0xffd6a0 }, { a: -33, b: -77, color: 0xcbb5fa },
            { a: -78, b: -124, color: 0x86e6ef }, { a: -125, b: -195, color: 0x9ed9c8 }];
        for (let k = 0; k < phases.length; k++) {
            const phase = phases[k], verts = [], colors = [];
            const base = new THREE.Color(phase.color);
            for (let i = 0; i < 210; i++) {
                const z = phase.b + rand(i + k * 110) * Math.max(1, phase.a - phase.b);
                const side = i % 2 ? -1 : 1, x = side * (7 + rand(i + k * 120 + 80) * 30), y = 2 + rand(i + k * 100 + 19) * 22;
                verts.push(x, y, z);
                const c = base.clone().lerp(new THREE.Color(0xffffff), rand(i + 22) * .45);
                colors.push(c.r, c.g, c.b);
            }
            const geo = new THREE.BufferGeometry();
            geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
            geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
            const particleMaterial = new THREE.PointsMaterial({ size: k === 0 ? .14 : .19, transparent: true,
                opacity: .68, depthWrite: false, vertexColors: true, sizeAttenuation: true });
            const points = new THREE.Points(geo, particleMaterial);
            points.name = `Phase ${k + 1} atmospheric motes`;
            points.frustumCulled = false;
            this.distant.add(points);
        }
        // Large hazy silhouettes are softly layered, not enormous light-emitting particle clouds.
        const haze = glow(0x38697d, .09);
        for (let i = 0; i < 8; i++) {
            const z = -41 - i * 24, x = (i % 2 ? -1 : 1) * (30 + rand(i) * 16);
            const disk = add(this.distant, new THREE.CircleGeometry(9 + rand(i + 91) * 6, 48), haze, x, 11, z, false);
            disk.rotation.y = Math.PI / 2;
        }
    }
    makePulses() {
        const geometry = new THREE.RingGeometry(.5, .74, 40);
        for (let i = 0; i < 8; i++) {
            const material = glow(ERA_COLORS[0], 0);
            const mesh = add(this.root, geometry, material, 0, -1000, 0, false);
            mesh.rotation.x = -Math.PI / 2;
            mesh.visible = false;
            mesh.renderOrder = 3;
            this.pulses.push({ mesh, age: 99, duration: 1.1, size: 3.1, opacity: .72 });
        }
    }
    pulse(x, y, z, kind) {
        let pulse = this.pulses.find(p => p.age >= p.duration);
        if (!pulse)
            pulse = this.pulses.reduce((a, b) => a.age > b.age ? a : b);
        const phase = z > -32 ? 0 : z > -78 ? 1 : z > -124 ? 2 : 3;
        pulse.age = 0;
        pulse.mesh.position.set(x, y + .075, z);
        pulse.mesh.scale.setScalar(.7);
        pulse.duration = kind === 'step' ? .48 : 1.1;
        pulse.size = kind === 'step' ? .85 : 3.1;
        pulse.opacity = kind === 'step' ? .30 : kind === 'land' ? .66 : .8;
        pulse.mesh.material.color.setHex(kind === 'recover' ? 0xf4a59a : ERA_COLORS[phase]);
        pulse.mesh.material.opacity = pulse.opacity;
        pulse.mesh.visible = true;
    }
    setLowEffects(low) { this.lowEffects = low; this.distant.visible = !low; }
    reset() {
        this.time = 0;
        for (const mover of this.movers)
            mover.object.position.y = mover.origin;
        for (const pulse of this.pulses) {
            pulse.age = 99;
            pulse.mesh.visible = false;
        }
    }
    update(elapsed, playerZ, reducedMotion) {
        const dt = Math.max(0, Math.min(.05, elapsed - this.time));
        this.time = elapsed;
        const phase = playerZ > -32 ? 0 : playerZ > -78 ? 1 : playerZ > -124 ? 2 : 3;
        const lerp = Math.min(1, dt * 1.7);
        this.horizon.lerp(this.horizonTargets[phase], lerp);
        this.zenith.lerp(this.topTargets[phase], lerp);
        this.nadir.lerp(this.groundTargets[phase], lerp);
        for (const m of this.movers) {
            m.object.position.y = reducedMotion ? m.origin : m.origin + Math.sin(elapsed * m.speed + m.phase) * m.amplitude;
        }
        for (let i = 0; i < this.beacons.length; i++) {
            this.beacons[i].emissiveIntensity = reducedMotion ? .54 : .54 + Math.sin(elapsed * 1.1 + i * .35) * .16;
        }
        this.water.material.emissiveIntensity = reducedMotion ? .08 : .11 + Math.sin(elapsed * .25) * .035;
        for (const pulse of this.pulses) {
            if (pulse.age >= pulse.duration)
                continue;
            pulse.age += dt;
            if (reducedMotion || this.lowEffects) {
                pulse.mesh.visible = false;
                continue;
            }
            const t = Math.min(1, pulse.age / pulse.duration);
            pulse.mesh.scale.setScalar((pulse.size < 1 ? .24 : .72) + t * pulse.size);
            pulse.mesh.material.opacity = (1 - t) * (1 - t) * pulse.opacity;
            pulse.mesh.visible = t < 1;
        }
    }
    dispose() { this.textures.forEach(t => t.dispose()); this.textures.length = 0; }
}
