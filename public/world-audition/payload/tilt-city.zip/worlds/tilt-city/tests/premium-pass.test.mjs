import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { interpolatePose, districtAtX } from '../.test-compiled/presentation.js';

const text=(file)=>readFileSync(file,'utf8');
test('interpolated render pose smooths fixed simulation steps without touching gameplay',()=>{
  const a={x:1,y:2,z:-1,vx:3,vy:0,vz:0,grounded:true};
  const b={x:2,y:2,z:-1,vx:4,vy:0,vz:0,grounded:true};
  assert.equal(interpolatePose(a,b,.5).x,1.5);
  assert.equal(interpolatePose(a,b,.5).vx,3.5);
  assert.equal(interpolatePose(a,b,2).x,2);
  assert.equal(interpolatePose(a,b,-5).x,1);
  assert.equal(interpolatePose(a,b,NaN).x,2);
  assert.equal(a.x,1);assert.equal(b.x,2);
});
test('visual interpolation never smears a fall recovery or large teleport',()=>{
  const a={x:170,y:-16,z:0,vx:0,vy:-18,vz:0,grounded:false};
  const b={x:140,y:0,z:0,vx:0,vy:0,vz:0,grounded:true};
  assert.deepEqual(interpolatePose(a,b,.1),b);
  assert.equal(interpolatePose(a,{...a,y:-16.2,grounded:false},.5).grounded,false);
});
test('four visual districts have deterministic bounds and no additional gameplay route',()=>{
  assert.deepEqual([-30,10,49.999,50,90,130,300].map(districtAtX),[0,0,0,1,2,3,3]);
  const scene=text('src/street-finishes.ts');
  assert.match(scene,/COURSE_FLOORS/);
  assert.match(scene,/non-colliding visual surfaces/);
  assert.match(scene,/setGateAngle\(index:number,angle:number\)/);
  assert.doesNotMatch(scene,/\.surfaces\s*\(|\.request\s*\(|new\s+PlayerPhysics/);
});
test('visual polish cannot dispatch real DexTilt commands or fetch third-party assets',()=>{
  for(const file of ['src/presentation.ts','src/street-finishes.ts']){
    assert.doesNotMatch(text(file),/\bfetch\s*\(|WebSocket|XMLHttpRequest|postMessage|sendBeacon|child_process|AudioContext/);
  }
  const main=text('src/main.ts');
  assert.match(main,/interpolatePose\(previousSim,physics\.state/);
  assert.match(main,/world\.fx\.footsteps/);
  assert.match(main,/refreshProgress\(\)/);
  assert.match(text('src/scene.ts'),/new StreetFinishes\(this\.scene\)/);
});
test('expanded details obey reduced motion, economy graphics, and restart',()=>{
  const source=text('src/street-finishes.ts');
  assert.match(source,/if\(reduced\)return;/);
  assert.match(source,/this\.optional\.visible=mode==='high'/);
  assert.match(source,/reset\(\):void/);
  const actor=text('src/scene.ts');
  assert.match(actor,/this\.jumpJets\.forEach/);
  assert.match(actor,/this\.street\.reset\(\)/);
  assert.match(actor,/this\.street\.setQuality\(mode\)/);
  assert.match(actor,/this\.street\.update\(seconds,reduced\)/);
});
test('route HUD presents progress semantically while obeying layout breakpoints',()=>{
  const html=text('index.html');
  assert.match(html,/role="progressbar"[^>]+aria-valuemax="100"/);
  assert.match(html,/id="progress-fill"/);
  const css=text('src/style.css');
  assert.match(css,/\.progress-meter/);
  assert.match(css,/@media\(max-height:550px\),\(max-width:640px\)/);
});
