/**
 * E02's four source-grounded process functions. Process ≠ biological archetype.
 * Coordinates and pacing here are gameplay abstractions, not Starsilk geography.
 */
export const ACTS = [
    {
        id: 'fault-tongue', name: 'FAULT-TONGUE', number: '01',
        function: 'Geological fracture',
        narration: 'The terrain opens along immense deliberate faults. Black strata separate; the material is not yet refined.',
        color: 0xf18b56,
    },
    {
        id: 'cloudmaw', name: 'CLOUDMAW', number: '02',
        function: 'Redistribution of existing water',
        narration: 'Existing water is raised, channeled and redistributed. Nothing here implies water is created from nothing.',
        color: 0x69d5e8,
    },
    {
        id: 'gorevault', name: 'GOREVAULT', number: '03',
        function: 'Matter gathering and refinement',
        narration: 'Matter converges, sorts and refines in a vast material-processing stage. This is not the extrusion function.',
        color: 0xf0b66f,
    },
    {
        id: 'ringthroat', name: 'RINGTHROAT', number: '04',
        function: 'Downstream extrusion and sky/orbital construction',
        narration: 'Refined material moves downstream and extrudes into immense structures rising into the modeled sky.',
        color: 0xa7aeff,
    },
];
const MASTER_PATH = [
    -12, -7, -2, 3, 8, 12, 8, 3, -2, -7, -11, -6, -1, 4, 9, 12, 8, 3, -2, -7,
    -11, -6, -1, 4, 9, 12, 8, 3, -2, -7, -11, -6, -1, 4, 9, 12, 8, 3, -2, -7,
];
export const ROUTE_STEP = 1.2;
export const LIFT_RISE = 10.5;
export const ZONE_RISE = (MASTER_PATH.length - 1) * ROUTE_STEP + LIFT_RISE + ROUTE_STEP;
export const ROUTE_WIDTH = 36;
export const PADS_PER_ACT = MASTER_PATH.length;
// Rotated, continuity-preserving paths. Each section starts directly above the
// preceding lift, but uses its own lateral hairpins and height progression.
const ROUTES = [];
let previousEnd = MASTER_PATH[0];
for (let act = 0; act < ACTS.length; act++) {
    const offset = act === 0 ? 0 : MASTER_PATH.findIndex(v => v === previousEnd);
    if (offset < 0)
        throw new Error('The next process has no continuous start.');
    const route = MASTER_PATH.map((_, i) => MASTER_PATH[(i + offset) % MASTER_PATH.length]);
    ROUTES.push(route);
    previousEnd = route.at(-1);
}
export const PLATFORMS = ROUTES.flatMap((path, act) => path.map((x, index) => ({
    id: `a${act}-p${index}`,
    act,
    index,
    x,
    top: act * ZONE_RISE + index * ROUTE_STEP,
    width: index === 0 ? 7.8 : index === PADS_PER_ACT - 1 ? 7 : index % 12 === 0 ? 5.4 : 4.4,
    kind: index === PADS_PER_ACT - 1 ? (act === ACTS.length - 1 ? 'overlook' : 'lift') : index % 11 === 4 ? 'moving' : 'ledge',
    phase: index * 0.82 + act * 0.5,
    rise: index === PADS_PER_ACT - 1 && act < 3 ? LIFT_RISE : 0,
    checkpoint: index % 12 === 0,
})));
export function pose(spec, time, liftProgress = 0, reducedMotion = false) {
    const sway = spec.kind === 'moving' && !reducedMotion ? Math.sin(time * 0.95 + spec.phase) * 0.54 : 0;
    return { x: spec.x + sway, top: spec.top + spec.rise * Math.min(1, Math.max(0, liftProgress)), width: spec.width };
}
export const START = { x: ROUTES[0][0], y: PLATFORMS[0].top, platformId: PLATFORMS[0].id };
export const END = { x: PLATFORMS[PLATFORMS.length - 1].x, y: PLATFORMS[PLATFORMS.length - 1].top };
export function processForHeight(y) {
    if (y >= 3 * ZONE_RISE)
        return 3;
    if (y >= 2 * ZONE_RISE)
        return 2;
    if (y >= ZONE_RISE)
        return 1;
    return 0;
}
