/** INFINITUM's authored visual language: patinated brass, glacier glass, slate and living moss.
 * Procedural materials and geometries ship with the source; no external assets or network requests.
 */
import * as THREE from 'three';
import { TAU, clamp, mulberry32 } from '../core/math.js';
export const ART = {
    obsidian: 0x101e27, basalt: 0x374954, slate: 0x52616c,
    copper: 0xb79a6c, gold: 0xd9bf89, frost: 0xc4e6e4,
    glacial: 0x64c4bf, moss: 0x557661, deepMoss: 0x234e48,
    lilac: 0x897fab, pearl: 0xe3e5d1
};
export function grainTexture(seed, size = 128, contrast = .5) {
    const rng = mulberry32(seed);
    const data = new Uint8Array(size * size * 4);
    const phases = Array.from({ length: 8 }, () => rng() * TAU);
    for (let y = 0; y < size; y++)
        for (let x = 0; x < size; x++) {
            const u = x / size * TAU, v = y / size * TAU;
            const low = (Math.sin(u * 3 + phases[0]) * Math.cos(v * 3 + phases[1]) +
                Math.sin(u * 7 + v * 5 + phases[2]) * .48 + Math.cos(u * 13 - v * 11 + phases[3]) * .24) / 1.72;
            const grain = (rng() - .5) * .18;
            const shade = clamp(.83 + (low * .26 + grain) * contrast, .53, 1.0);
            const j = (y * size + x) * 4;
            const channel = Math.round(shade * 255);
            data[j] = channel;
            data[j + 1] = Math.round(channel * .986);
            data[j + 2] = Math.round(channel * .955);
            data[j + 3] = 255;
        }
    const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.generateMipmaps = true;
    tex.needsUpdate = true;
    return tex;
}
/** Derive a small tiled tangent-space normal map from the same authored stone grain.
 * This uses zero network textures and stays paired with its owning PBR material. */
export function reliefTexture(source) {
    const { data, width, height } = source.image;
    const pixels = new Uint8Array(width * height * 4);
    const h = (x, y) => data[((y + height) % height * width + (x + width) % width) * 4] / 255;
    for (let y = 0; y < height; y++)
        for (let x = 0; x < width; x++) {
            const dx = (h(x + 1, y) - h(x - 1, y)) * 1.15;
            const dy = (h(x, y + 1) - h(x, y - 1)) * 1.15;
            const inv = 1 / Math.hypot(dx, dy, 1), i = (y * width + x) * 4;
            pixels[i] = Math.round((-.5 * dx * inv + .5) * 255);
            pixels[i + 1] = Math.round((-.5 * dy * inv + .5) * 255);
            pixels[i + 2] = Math.round((.5 * inv + .5) * 255);
            pixels[i + 3] = 255;
        }
    const normal = new THREE.DataTexture(pixels, width, height, THREE.RGBAFormat, THREE.UnsignedByteType);
    normal.wrapS = normal.wrapT = THREE.RepeatWrapping;
    normal.repeat.copy(source.repeat);
    normal.generateMipmaps = true;
    normal.minFilter = THREE.LinearMipmapLinearFilter;
    normal.magFilter = THREE.LinearFilter;
    normal.needsUpdate = true;
    return normal;
}
export function stoneSurface(color, seed, repeat = 4, rough = .9) {
    const map = grainTexture(seed);
    map.repeat.set(repeat, repeat);
    const normalMap = reliefTexture(map);
    return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: .04, map, normalMap, normalScale: new THREE.Vector2(.28, .28) });
}
/** One draw call for soft contact shadows at selected structural anchors. */
export function contactShadows(places) {
    const geo = new THREE.PlaneGeometry(1, 1);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1,
        vertexShader: `varying vec2 vUv; void main(){vUv=uv;vec4 p=vec4(position,1.);
      #ifdef USE_INSTANCING
        p=instanceMatrix*p;
      #endif
      gl_Position=projectionMatrix*modelViewMatrix*p;}`,
        fragmentShader: `varying vec2 vUv;void main(){float r=length((vUv-.5)*2.);float a=pow(1.-smoothstep(.03,1.,r),2.)*.43;gl_FragColor=vec4(.025,.05,.065,a);}`
    });
    const mesh = new THREE.InstancedMesh(geo, mat, places.length), tmp = new THREE.Object3D();
    places.forEach((p, i) => {
        tmp.position.set(p.x, p.y + .035, p.z);
        tmp.scale.set(p.r * 2 * (p.strength ?? 1), 1, p.r * 2 * (p.strength ?? 1));
        tmp.rotation.set(0, 0, 0);
        tmp.updateMatrix();
        mesh.setMatrixAt(i, tmp.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    mesh.renderOrder = 1;
    return mesh;
}
/** A serrated evergreen crown, rather than a scaled cone; intentionally low polygon and instancing-friendly. */
export function coniferCrown() {
    const radial = 10, levels = 14, positions = [], colors = [], indices = [];
    const dark = new THREE.Color(0x637d72), tip = new THREE.Color(0xa2b5a1);
    for (let j = 0; j < levels; j++) {
        const t = j / (levels - 1), y = t * 8;
        const branchTier = (j % 3 === 0 ? 1.11 : j % 3 === 1 ? .92 : .76);
        const radius = Math.max(.04, (1 - t) * 2.6 * branchTier);
        for (let i = 0; i < radial; i++) {
            const a = i / radial * TAU, scatter = 1 + .095 * Math.sin(a * 7 + j * 2.6);
            positions.push(Math.cos(a) * radius * scatter, y, Math.sin(a) * radius * scatter);
            const col = dark.clone().lerp(tip, t * .6 + .14 * Math.sin(a * 3 + j));
            colors.push(col.r, col.g, col.b);
        }
    }
    for (let j = 0; j < levels - 1; j++)
        for (let i = 0; i < radial; i++) {
            const a = j * radial + i, b = j * radial + (i + 1) % radial, c = (j + 1) * radial + i, d = (j + 1) * radial + (i + 1) % radial;
            indices.push(a, c, b, b, c, d);
        }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    geo.translate(0, 2.1, 0);
    return geo;
}
export function broadleafCrown(seed) {
    const rng = mulberry32(seed), g = new THREE.IcosahedronGeometry(3.1, 1), a = g.getAttribute('position');
    for (let i = 0; i < a.count; i++) {
        const x = a.getX(i), y = a.getY(i), z = a.getZ(i), dist = Math.hypot(x, y, z);
        const scale = .88 + .14 * Math.sin(x * 1.8 + z * 2.7) + rng() * .11;
        a.setXYZ(i, x * scale, y * (.73 + .12 * Math.cos(z)) + 1.7, z * scale);
        void dist;
    }
    g.computeVertexNormals();
    g.translate(0, 3.6, 0);
    return g;
}
/** Irregular mountain mass with cliff-banded, snowline-colored vertices. */
export function mountainGeometry(width, height, seed) {
    const rng = mulberry32(seed), radial = 14, layers = 10;
    const verts = [], colors = [], indices = [];
    const rock = new THREE.Color(0x4d6267), ridge = new THREE.Color(0x728a89), snow = new THREE.Color(0xc4d3cf);
    const angular = Array.from({ length: radial }, (_, i) => .72 + rng() * .52 + Math.sin(i * 2.1 + seed) * .08);
    for (let j = 0; j < layers; j++) {
        const t = j / (layers - 1);
        const y = t * height;
        const profile = Math.pow(1 - t, .96) * (1 + .10 * Math.sin(t * 30 + seed));
        for (let i = 0; i < radial; i++) {
            const a = i / radial * TAU, r = width * Math.max(.006, profile) * angular[i];
            const fracture = Math.sin(a * 9 + t * 29 + seed) * width * .028 * (1 - t);
            verts.push(Math.cos(a) * (r + fracture), y + Math.sin(a * 4 + t * 16 + seed) * height * .019 * (1 - t), Math.sin(a) * (r + fracture) * .73);
            const face = rock.clone().lerp(ridge, Math.max(.0, Math.sin(a * 4 + t * 19)) * .22 + t * .24);
            face.lerp(snow, clamp((t - .68) * 5 + .12 * Math.sin(a * 6 + seed), 0, 1));
            colors.push(face.r, face.g, face.b);
        }
    }
    for (let j = 0; j < layers - 1; j++)
        for (let i = 0; i < radial; i++) {
            const a = j * radial + i, b = j * radial + (i + 1) % radial, c = a + radial, d = b + radial;
            indices.push(a, c, b, b, c, d);
        }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
}
/** Broad overlapping eaves, two roof planes, ridge, and real triangular gable ends. */
export function gableRoof(width, depth, rise = 2.7) {
    const w = width * .59, d = depth * .59;
    const A = [-w, 0, -d], B = [-w, 0, d], C = [0, rise, -d], D = [0, rise, d], E = [w, 0, -d], F = [w, 0, d];
    const verts = [], push = (a, b, c) => verts.push(...a, ...b, ...c);
    push(A, B, D);
    push(A, D, C);
    push(C, D, F);
    push(C, F, E);
    push(A, C, E);
    push(B, F, D);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    // Explicit planar UVs permit the authored shingle texture to read on sloped roof planes.
    const uvs = [];
    for (let i = 0; i < verts.length; i += 3) {
        uvs.push((verts[i + 2] + d) / (2 * d), (verts[i] + w) / (2 * w));
    }
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.computeVertexNormals();
    return g;
}
export function leafBlade() {
    const vertices = [0, 0, 0, -.35, .1, .25, 0, .22, .4, .35, .1, .25,
        -.56, .13, .8, 0, .3, 1.1, .56, .13, .8, 0, .04, 1.5];
    const indices = [0, 1, 2, 0, 2, 3, 1, 4, 5, 1, 5, 2, 2, 5, 6, 2, 6, 3, 4, 7, 5, 5, 7, 6];
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
}
export function softGlow(color, size, opacity = .5) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.ShaderMaterial({
        uniforms: { uColor: { value: new THREE.Color(color) }, uOpacity: { value: opacity } },
        transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
        vertexShader: `varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
        fragmentShader: `uniform vec3 uColor;uniform float uOpacity;varying vec2 vUv;void main(){float r=length((vUv-.5)*2.);float v=pow(1.-smoothstep(0.,1.,r),3.);gl_FragColor=vec4(uColor,v*uOpacity);}`
    }));
    mesh.renderOrder = 2;
    return mesh;
}
/** Camera-independent interior sky dome: aurora, twilight horizon and low-frequency cosmic structure. */
export class ArtSky {
    mesh;
    uniforms = { uDay: { value: .2 }, uTime: { value: 0 }, uStorm: { value: 0 }, uCosmic: { value: 0 }, uSunDir: { value: new THREE.Vector3(0, 1, 0) } };
    constructor(scene, cosmic = false, low = false) {
        this.uniforms.uCosmic.value = cosmic ? 1 : 0;
        this.mesh = new THREE.Mesh(new THREE.SphereGeometry(740, low ? 32 : 56, low ? 20 : 36), new THREE.ShaderMaterial({
            uniforms: this.uniforms, side: THREE.BackSide, depthWrite: false, fog: false,
            vertexShader: `varying vec3 vDirection;void main(){vDirection=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
            fragmentShader: `uniform float uDay,uTime,uStorm,uCosmic;uniform vec3 uSunDir;varying vec3 vDirection;
      float hash(vec3 x){return fract(sin(dot(x,vec3(127.1,311.7,74.7)))*43758.5453);}
      void main(){float h=clamp(vDirection.y*.5+.5,0.,1.);
        vec3 deep=mix(vec3(.012,.032,.072),vec3(.125,.24,.33),uDay*.68);
        vec3 horizon=mix(vec3(.052,.106,.158),vec3(.51,.59,.54),uDay*.83);
        vec3 col=mix(horizon,deep,smoothstep(.05,.91,h));
        float twilight=(1.-smoothstep(.02,.27,abs(uDay-.18)))*smoothstep(.25,.67,h);
        col+=vec3(.16,.068,.055)*twilight;
        float facing=max(0.,dot(normalize(vDirection),normalize(uSunDir)));
        float warm=pow(facing,22.)*(.16+.12*uDay)*(1.-uStorm*.62);
        float core=pow(facing,170.)*.28*uDay;
        float moon=max(0.,dot(normalize(vDirection),-normalize(uSunDir)));
        col+=vec3(.66,.34,.13)*warm+vec3(.34,.26,.14)*core;
        col+=vec3(.08,.12,.23)*pow(moon,50.)*(1.-uDay)*.19;
        float sw=sin(vDirection.x*15.+sin(vDirection.z*7.+uTime*.005)*2.3)*sin(vDirection.y*21.-uTime*.009);
        float aurora=pow(max(.0,sw),3.)*smoothstep(.42,.8,h)*(.08+uCosmic*.14);
        col+=vec3(.04,.17,.16)*aurora;
        if(uCosmic>.5){
          float ribbon=sin(vDirection.x*11.+vDirection.z*6.+sin(vDirection.y*13.+uTime*.004)*2.);
          float neb=pow(max(0.,ribbon),2.)*smoothstep(.35,.78,h);
          col+=vec3(.095,.067,.155)*neb*.28+vec3(.025,.12,.13)*neb*.18;
          float center=sin(vDirection.x*4.1+vDirection.z*2.7+uTime*.0011)*.20;
          float stream=exp(-pow((vDirection.y-center)*6.8,2.));
          float fibers=.5+.5*sin(vDirection.x*44.+vDirection.z*21.+uTime*.0025);
          col+=stream*(vec3(.065,.098,.16)+vec3(.04,.02,.07)*fibers)*.42;
        }
        col=mix(col,vec3(.07,.095,.122),uStorm*.22);
        gl_FragColor=vec4(col,1.);
      }`
        }));
        this.mesh.frustumCulled = false;
        this.mesh.renderOrder = -1000;
        scene.add(this.mesh);
    }
    update(day, time, storm, sunDir) {
        this.uniforms.uDay.value = day;
        this.uniforms.uTime.value = time;
        this.uniforms.uStorm.value = storm;
        if (sunDir)
            this.uniforms.uSunDir.value.copy(sunDir).normalize();
    }
}
