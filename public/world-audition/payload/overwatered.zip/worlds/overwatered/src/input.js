export class GameInput {
    cameraYaw = 0;
    pressed = new Set();
    jumpPulse = false;
    glidePulse = false;
    waterPulse = false;
    dragId = null;
    lastX = 0;
    handlers = [];
    constructor(canvas, touchRoot) {
        const keydown = (event) => {
            const key = event.code;
            // Gameplay shortcuts must not steal Space/arrow activation from a focused menu control.
            const target = event.target;
            if (target instanceof HTMLElement && target.closest('button,input,select,textarea,a,[role="button"]'))
                return;
            if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyG', 'KeyE', 'KeyQ', 'KeyR'].includes(key))
                event.preventDefault();
            if (event.repeat)
                return;
            if (key === 'Space')
                this.jumpPulse = true;
            if (key === 'KeyG')
                this.glidePulse = true;
            if (key === 'KeyE')
                this.waterPulse = true;
            this.pressed.add(key);
        };
        const keyup = (event) => { this.pressed.delete(event.code); };
        const blur = () => this.reset();
        window.addEventListener('keydown', keydown);
        window.addEventListener('keyup', keyup);
        window.addEventListener('blur', blur);
        this.handlers.push(() => window.removeEventListener('keydown', keydown), () => window.removeEventListener('keyup', keyup), () => window.removeEventListener('blur', blur));
        const pointerdown = (event) => {
            if (event.button !== 0 && event.pointerType === 'mouse')
                return;
            this.dragId = event.pointerId;
            this.lastX = event.clientX;
            canvas.setPointerCapture(event.pointerId);
        };
        const pointermove = (event) => {
            if (this.dragId !== event.pointerId)
                return;
            this.cameraYaw -= Math.max(-60, Math.min(60, event.clientX - this.lastX)) * .004;
            this.lastX = event.clientX;
        };
        const pointerup = (event) => { if (this.dragId === event.pointerId)
            this.dragId = null; };
        canvas.addEventListener('pointerdown', pointerdown);
        canvas.addEventListener('pointermove', pointermove);
        canvas.addEventListener('pointerup', pointerup);
        canvas.addEventListener('pointercancel', pointerup);
        this.handlers.push(() => canvas.removeEventListener('pointerdown', pointerdown), () => canvas.removeEventListener('pointermove', pointermove), () => canvas.removeEventListener('pointerup', pointerup), () => canvas.removeEventListener('pointercancel', pointerup));
        for (const b of Array.from(touchRoot.querySelectorAll('button'))) {
            const hold = b.dataset.hold, action = b.dataset.action;
            const down = (e) => {
                e.preventDefault();
                b.setPointerCapture(e.pointerId);
                if (hold) {
                    this.pressed.add('touch-' + hold);
                    if (hold === 'jump')
                        this.jumpPulse = true;
                }
                if (action === 'water')
                    this.waterPulse = true;
                if (action === 'glide')
                    this.glidePulse = true;
            };
            const up = (e) => { e.preventDefault(); if (hold)
                this.pressed.delete('touch-' + hold); };
            b.addEventListener('pointerdown', down);
            b.addEventListener('pointerup', up);
            b.addEventListener('pointercancel', up);
            b.addEventListener('lostpointercapture', up);
            this.handlers.push(() => b.removeEventListener('pointerdown', down), () => b.removeEventListener('pointerup', up), () => b.removeEventListener('pointercancel', up), () => b.removeEventListener('lostpointercapture', up));
        }
    }
    reset() { this.pressed.clear(); this.jumpPulse = false; this.glidePulse = false; this.waterPulse = false; }
    sample(dt) {
        const has = (...keys) => keys.some(k => this.pressed.has(k));
        if (has('KeyQ'))
            this.cameraYaw -= dt * 1.6;
        if (has('KeyR'))
            this.cameraYaw += dt * 1.6;
        const forward = Number(has('KeyW', 'ArrowUp', 'touch-forward')) - Number(has('KeyS', 'ArrowDown', 'touch-back'));
        const right = Number(has('KeyD', 'ArrowRight', 'touch-right')) - Number(has('KeyA', 'ArrowLeft', 'touch-left'));
        const value = { forward, right, cameraYaw: this.cameraYaw, jumpHeld: has('Space', 'touch-jump'), jumpPressed: this.jumpPulse, glidePressed: this.glidePulse, waterPressed: this.waterPulse };
        this.jumpPulse = false;
        this.glidePulse = false;
        this.waterPulse = false;
        return value;
    }
    dispose() { this.reset(); this.handlers.forEach(fn => fn()); this.handlers = []; }
}
