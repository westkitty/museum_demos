export const LANDMARKS = [
    { id: 'threshold', world: 0, name: 'The First Threshold', position: [0, 12.6, 0], approach: 12, note: 'The opening into a wider interior.' },
    { id: 'astrolabes', world: 0, name: 'The Brass Instruments', position: [29, 10, 24], approach: 14, note: 'The outer sky measures an inner pattern.' },
    { id: 'dome', world: 0, name: 'The Celestial Dome', position: [0, 89, 0], approach: 26, note: 'Stars older than the room itself.' },
    { id: 'tree', world: 1, name: 'The Heart Tree', position: [17, 25, -2], approach: 25, note: 'Water and growth produce another threshold.' },
    { id: 'settlement', world: 1, name: 'Lantern Settlement', position: [-29, 12, 28], approach: 22, note: 'Lives continue beyond the observer.' },
    { id: 'waterfall', world: 1, name: 'The Silvercourse Falls', position: [-18, 17, -37], approach: 22, note: 'The watershed descends through the valley.' },
    { id: 'ruin', world: 1, name: 'The Light Receivers', position: [30, 15, 44], approach: 17, note: 'Ruined architecture awaiting alignment.' },
    { id: 'shore', world: 1, name: 'The Tidal Shore', position: [0, 5, 82], approach: 25, note: 'The moon exposes and conceals the coast.' },
    { id: 'garden-gate', world: 2, name: 'The Inner Membrane', position: [0, 9, 6], approach: 12, note: 'The only physical way back.' },
    { id: 'islands', world: 2, name: 'The Floating Causeway', position: [28, 16, -27], approach: 28, note: 'Pathways are written in starlight.' },
    { id: 'orrery', world: 2, name: 'The Celestial Orrery', position: [0, 49, -70], approach: 40, note: 'Astronomy that remembers the Observatory.' },
    { id: 'sanctuary', world: 2, name: 'The Distant Sanctuary', position: [0, 38, -150], approach: 30, note: 'An ancient alignment among distant isles.' }
];
export const landmarksIn = (world) => LANDMARKS.filter(l => l.world === world);
export const landmarkById = (id) => LANDMARKS.find(l => l.id === id);
const KEY = 'infinitum.explorer.v1';
const boundedVector = (p) => Array.isArray(p) && p.length === 3 && p.every(v => typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= 1500);
export function validExplorer(p) {
    if (!p || typeof p !== 'object')
        return false;
    const e = p;
    return e.schema === 1 && (e.world === 0 || e.world === 1 || e.world === 2) &&
        (e.mode === 'orbit' || e.mode === 'fly' || e.mode === 'walk') && boundedVector(e.position) && boundedVector(e.target);
}
export function loadExplorer() {
    try {
        const raw = localStorage.getItem(KEY);
        if (!raw)
            return null;
        const data = JSON.parse(raw);
        return validExplorer(data) ? data : null;
    }
    catch {
        return null;
    }
}
export function saveExplorer(e) {
    if (!validExplorer(e))
        return false;
    try {
        localStorage.setItem(KEY, JSON.stringify(e));
        return true;
    }
    catch {
        return false;
    }
}
export function clearExplorer() { try {
    localStorage.removeItem(KEY);
}
catch { /* storage denied */ } }
