/** Pure, deterministic, fixed-step player simulation with platform collision. */
export const RULES = Object.freeze({
  speed: 7.55, accel: 42, groundDrag: 43, airDrag: 26,
  gravity: 28, maxFall: 23, jump: 11.9, doubleJump: 11.05,
  wallJumpX: 8.2, wallJumpY: 11.25, wallSlide: 3.25,
  coyote: 0.11, buffer: 0.16, playerWidth: 0.64, playerHeight: 1.18,
});
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const approach=(v,target,delta)=>v<target?Math.min(target,v+delta):Math.max(target,v-delta);
const overlap=(a0,a1,b0,b1)=>a1>b0+0.0001 && a0<b1-0.0001;
export function createPlayer(x=2.1,y=1.0){return {
  x,y,prevX:x,prevY:y,vx:0,vy:0,grounded:true,wall:0,face:1,
  coyote:RULES.coyote,buffer:0,doubleAvailable:true,wallLock:0,landedAt:0,
};}
export function simulate(player, input, platforms, dt=1/60){
  if(dt<=0||dt>0.05)throw new Error('Physics requires a fixed, bounded timestep');
  const p=player, R=RULES;
  p.prevX=p.x; p.prevY=p.y;
  const events=[];
  const axis=clamp(Number(input.axis)||0,-1,1);
  if(input.jumpPressed)p.buffer=R.buffer;
  else p.buffer=Math.max(0,p.buffer-dt);
  p.wallLock=Math.max(0,p.wallLock-dt);
  const wasGrounded=p.grounded;
  if(p.grounded)p.coyote=R.coyote;
  else p.coyote=Math.max(0,p.coyote-dt);
  if(axis!==0){if(p.wallLock===0){p.vx=approach(p.vx,axis*R.speed,R.accel*dt); p.face=axis>0?1:-1;}}
  else p.vx=approach(p.vx,0,(p.grounded?R.groundDrag:R.airDrag)*dt);
  // Jumps are buffered and evaluated with last step's ground/wall state.
  if(p.buffer>0){
    if(p.grounded||p.coyote>0){p.vy=R.jump;p.grounded=false;p.coyote=0;p.doubleAvailable=true;p.buffer=0;events.push('jump');}
    else if(p.wall!==0){p.vy=R.wallJumpY;p.vx=-p.wall*R.wallJumpX;p.face=-p.wall;p.wallLock=0.17;p.wall=0;p.buffer=0;events.push('walljump');}
    else if(p.doubleAvailable){p.vy=R.doubleJump;p.doubleAvailable=false;p.buffer=0;events.push('doublejump');}
  }
  // Optional shorter jumps when released, without changing deterministic timing.
  const gravScale=(input.jumpHeld&&p.vy>0)?0.78:1;
  p.vy=clamp(p.vy-R.gravity*gravScale*dt,-R.maxFall,25);
  const half=R.playerWidth/2;
  p.x+=p.vx*dt;
  p.wall=0;
  for(const b of platforms){
    if(!overlap(p.y+0.03,p.y+R.playerHeight-0.03,b.top-b.thickness,b.top))continue;
    if(!overlap(p.x-half,p.x+half,b.x,b.x+b.w))continue;
    if(p.vx>0 && p.prevX+half<=b.x+0.14){p.x=b.x-half;p.vx=0;p.wall=1;}
    else if(p.vx<0 && p.prevX-half>=b.x+b.w-0.14){p.x=b.x+b.w+half;p.vx=0;p.wall=-1;}
  }
  if(p.wall && !p.grounded && p.vy< -R.wallSlide)p.vy=-R.wallSlide;
  const oldY=p.y;
  p.y+=p.vy*dt;
  p.grounded=false;
  for(const b of platforms){
    if(!overlap(p.x-half+0.03,p.x+half-0.03,b.x,b.x+b.w))continue;
    if(p.vy<=0 && oldY >= b.top-0.09 && p.y <= b.top && p.y+R.playerHeight>b.top-b.thickness){
      p.y=b.top;p.vy=0;p.grounded=true;p.doubleAvailable=true;p.coyote=R.coyote;
      if(!wasGrounded)events.push('land');
    }else if(p.vy>0 && oldY+R.playerHeight<=b.top-b.thickness+0.12 && p.y+R.playerHeight>=b.top-b.thickness){
      p.y=b.top-b.thickness-R.playerHeight;p.vy=0;events.push('headbonk');
    }
  }
  if(!p.grounded&&wasGrounded)p.coyote=R.coyote;
  if(p.y<-13)events.push('fall');
  return events;
}
export function resetPlayer(p,x,y){Object.assign(p,createPlayer(x,y));}
