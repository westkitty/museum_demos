import * as THREE from 'three';
import { ACTS, PLATFORMS, ZONE_RISE, LIFT_RISE } from './route.js';
import { STAGE_ART, proceduralSurface, glowTexture, atmosphericBackdrop, planetSurface } from './design.js';
import { VISIBLE_PROCESS_SPINE_X } from './framing.js';
/** A scene-scoped deterministic procedural illustration. Nothing depicts Drakken anatomy. */
export class ProcessWorld {
    scene = new THREE.Scene();
    geometries = new Set();
    materials = new Set();
    textures = new Set();
    matCache = new Map();
    platformGroups = new Map();
    batches = [];
    stageRoots = [new THREE.Group(), new THREE.Group(), new THREE.Group(), new THREE.Group()];
    lastBatchTime = -1;
    lastReducedState = null;
    lastLiftSignature = '';
    dynamicPlatforms = [];
    processSignals = [];
    staticSceneryBatches = [];
    staticMeshesReplaced = 0;
    landingGuide = new THREE.Group();
    landingGuideRing;
    landingGuideCore;
    landingGuideGlow;
    runTraces = [];
    liftBeams = [];
    thresholds = [];
    lastKnownPlatform = PLATFORMS[0].id;
    checkpointSignals = [];
    lastCheckpointLitCount = -1;
    overview = false;
    backShaders = [];
    qualityGroups = [];
    rings = [];
    glowSprites = [];
    surface;
    glowMap;
    lightKey;
    lightRim;
    leftLeg;
    rightLeg;
    leftArm;
    rightArm;
    visor;
    contact;
    landingEnergy = 0;
    lastGround = null;
    visualClock = 0;
    eco = false;
    contrast = false;
    sparks = [];
    sparkPositions;
    sparkColors;
    sparkGeometry;
    planetShader;
    animated = [];
    floating = [];
    falls = [];
    boxGeo = this.geo(new THREE.BoxGeometry(1, 1, 1));
    cylinderGeo = this.geo(new THREE.CylinderGeometry(0.5, 0.5, 1, 12, 1));
    icoGeo = this.geo(new THREE.IcosahedronGeometry(1, 0));
    octGeo = this.geo(new THREE.OctahedronGeometry(1, 0));
    sphereGeo = this.geo(new THREE.SphereGeometry(1, 24, 14));
    torusGeo = this.geo(new THREE.TorusGeometry(1, 0.035, 6, 72));
    diskGeo = this.geo(new THREE.CylinderGeometry(1, 1, 1, 32));
    backdrops = [];
    instanceDummy = new THREE.Object3D();
    vecA = new THREE.Vector3();
    vecB = new THREE.Vector3();
    vecDir = new THREE.Vector3();
    up = new THREE.Vector3(0, 1, 0);
    stageBackgrounds = STAGE_ART.map(stage => new THREE.Color(stage.ink));
    stageRims = ACTS.map(stage => new THREE.Color(stage.color));
    stageKey = [0xffc6a1, 0xc5f4f4, 0xffd29d, 0xb2c9fb].map(hex => new THREE.Color(hex));
    spectator;
    portal;
    constructor() {
        this.surface = { stone: proceduralSurface('stone'), metal: proceduralSurface('metal'), ceramic: proceduralSurface('ceramic') };
        this.glowMap = glowTexture();
        for (const texture of [...Object.values(this.surface), this.glowMap])
            this.textures.add(texture);
        this.scene.background = new THREE.Color(STAGE_ART[0].ink);
        this.scene.fog = new THREE.FogExp2(STAGE_ART[0].ink, 0.006);
        for (const root of this.stageRoots)
            this.scene.add(root);
        this.scene.add(new THREE.HemisphereLight(0xd3e4fa, 0x251724, 1.75));
        this.lightKey = new THREE.DirectionalLight(0xffdfbe, 2.5);
        this.lightKey.position.set(-22, 35, 29);
        this.scene.add(this.lightKey);
        this.lightRim = new THREE.DirectionalLight(0x74b8fb, 1.8);
        this.lightRim.position.set(20, 74, -16);
        this.scene.add(this.lightRim);
        this.makeBackdrops();
        this.makeCanyon();
        this.makeWaterworks();
        this.makeFoundry();
        this.makeOrbit();
        this.makeStageSculptures();
        this.makeProcessSpine();
        this.makePlatforms();
        this.makeThresholds();
        this.portal = this.makePortal();
        this.spectator = this.makeSpectator();
        this.makeSparks();
        this.makeLandingGuide();
        this.makeRunTraces();
        this.makeLiftBeams();
        // Collapse repeated STATIC scene meshes only after all moving references are registered.
        // No platform collider, checkpoint, lift, animated, quality-switched or portal subtree is batched.
        this.batchStaticScenery();
    }
    geo(geometry) { this.geometries.add(geometry); return geometry; }
    mat(color, opts = {}) {
        const key = JSON.stringify([color, opts]);
        const cached = this.matCache.get(key);
        if (cached)
            return cached;
        const m = new THREE.MeshStandardMaterial({
            color, roughness: opts.roughness ?? 0.75, metalness: opts.metalness ?? 0,
            map: opts.finish ? this.surface[opts.finish] : null,
            emissive: opts.emissive ?? 0x000000,
            emissiveIntensity: opts.emissiveIntensity ?? 0,
            transparent: opts.transparent ?? false,
            opacity: opts.opacity ?? 1,
            side: opts.side ?? THREE.FrontSide,
            flatShading: opts.flatShading ?? false,
            depthWrite: !(opts.transparent ?? false),
        });
        this.matCache.set(key, m);
        this.materials.add(m);
        return m;
    }
    basic(color, opacity = 1) {
        const m = new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity, depthWrite: opacity >= 1, side: THREE.DoubleSide });
        this.materials.add(m);
        return m;
    }
    mesh(group, geo, mat, p, s) {
        const obj = new THREE.Mesh(geo, mat);
        obj.position.set(...p);
        obj.scale.set(...s);
        group.add(obj);
        return obj;
    }
    box(group, p, s, color, opts = {}) {
        return this.mesh(group, this.boxGeo, this.mat(color, opts), p, s);
    }
    cylinder(group, p, s, color, opts = {}) {
        return this.mesh(group, this.cylinderGeo, this.mat(color, opts), p, s);
    }
    oct(group, p, s, color, opts = {}) {
        return this.mesh(group, this.octGeo, this.mat(color, opts), p, s);
    }
    torus(group, p, sx, sy, color, opts = {}) {
        return this.mesh(group, this.torusGeo, this.mat(color, opts), p, [sx, sy, (sx + sy) * 0.5]);
    }
    span(group, a, b, w, d, color, opts = {}) {
        const av = new THREE.Vector3(...a), bv = new THREE.Vector3(...b);
        const mid = av.clone().add(bv).multiplyScalar(.5);
        const v = bv.sub(av);
        const m = this.box(group, [mid.x, mid.y, mid.z], [w, v.length(), d], color, opts);
        m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v.normalize());
        return m;
    }
    seeded(i) { return (Math.sin(i * 127.1 + 78.233) * 43758.5453) % 1; }
    rand(i) { const v = this.seeded(i); return v - Math.floor(v); }
    glow(parent, x, y, z, diameter, color, opacity = .36) {
        const material = new THREE.SpriteMaterial({ map: this.glowMap, color, opacity, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, depthTest: true });
        this.materials.add(material);
        const sprite = new THREE.Sprite(material);
        sprite.position.set(x, y, z);
        sprite.scale.set(diameter, diameter, 1);
        parent.add(sprite);
        this.glowSprites.push(sprite);
        return sprite;
    }
    /** A 2D route mounted inside a monumental, physically deep space; decoration owns no collision. */
    makeBackdrops() {
        for (let act = 0; act < 4; act++) {
            const floor = act * ZONE_RISE - 11;
            const palette = STAGE_ART[act];
            const shader = atmosphericBackdrop(act);
            this.materials.add(shader);
            this.backShaders.push(shader);
            const geo = this.geo(new THREE.PlaneGeometry(170, ZONE_RISE + 23));
            const backdrop = new THREE.Mesh(geo, shader);
            backdrop.position.set(0, floor + (ZONE_RISE + 23) / 2, -68);
            backdrop.frustumCulled = false;
            this.stageRoots[act].add(backdrop);
            this.backdrops.push(backdrop);
            // Architectural tiers at separate depths replace an undifferentiated wall of boxes.
            const architecture = new THREE.Group();
            this.stageRoots[act].add(architecture);
            for (let i = 0; i < 13; i++) {
                const x = -80 + i * 13;
                const period = this.rand(act * 91 + i);
                const height = 20 + period * 47;
                this.box(architecture, [x, floor + height / 2, -51 + i % 3 * 3], [1.5 + period * 2.7, height, 3.4], palette.stone, { metalness: .23, roughness: .72, finish: 'stone' });
                this.box(architecture, [x, floor + height - .6, -49 + i % 3 * 3], [3.4 + period * 2.4, .45, .35], palette.rim, { emissive: palette.halo, emissiveIntensity: .42 });
            }
            // A single immense circular mechanism gives every chapter the same pictorial grammar.
            const ring = this.torus(architecture, [act % 2 ? 19 : -18, floor + 31, -45], 30, 30, palette.rim, { emissive: palette.halo, emissiveIntensity: .5, metalness: .58, transparent: true, opacity: .28 });
            ring.scale.z *= .6;
            ring.rotation.y = .13;
            const secondary = this.torus(architecture, [act % 2 ? 19 : -18, floor + 31, -44], 24, 24, palette.rim, { emissive: palette.halo, emissiveIntensity: .4, metalness: .58, transparent: true, opacity: .23 });
            secondary.scale.z *= .6;
            // Broad shafts of reflected light establish the immense central process column.
            const glow = this.glow(architecture, act % 2 ? 19 : -18, floor + 29, -40, 83, palette.halo, .18);
            this.qualityGroups.push(glow);
            for (let i = 0; i < 16; i++) {
                const x = -67 + i * 8.8;
                const seed = this.rand(act * 33 + i);
                const h = 3 + seed * 24;
                this.box(architecture, [x, floor + h / 2, -39], [.08 + seed * .13, h, .08], palette.rim, { emissive: palette.halo, emissiveIntensity: .68, transparent: true, opacity: .35 });
            }
        }
    }
    makeCanyon() {
        const g = new THREE.Group();
        this.stageRoots[0].add(g);
        // Continental fault walls: abstract strata, not creature anatomy.
        for (const side of [-1, 1]) {
            for (let i = 0; i < 36; i++) {
                const y = -6 + i * 1.6;
                const distance = 17.5 + 2.2 * Math.sin(i * .57 + side) + this.rand(i * 3 + side * 14) * 2;
                const x = side * distance;
                const w = 4 + this.rand(i + 51) * 8;
                const rock = this.mesh(g, this.icoGeo, this.mat(i % 3 === 0 ? 0x202631 : i % 3 === 1 ? 0x10151d : 0x30313a, { metalness: .1, flatShading: true }), [x, y, -13 - (i % 4) * 2], [w, 2.8 + this.rand(i) * 1.8, 4.2]);
                rock.rotation.z = this.rand(i + 9) * .36;
                rock.rotation.y = this.rand(i + 15) * .27;
                if (i % 2 === 0)
                    this.span(g, [x - side * 1.5, y - 1, -9], [x - side * 2.6, y + 1.1, -8], .12, .19, 0xd56d40, { emissive: 0xdd4e28, emissiveIntensity: 2.0 });
            }
            for (let i = 0; i < 13; i++) {
                const x = side * (20 + i * .6), y = i * 3.4 - 7;
                const rock = this.oct(g, [x, y, -21], [4, 4 + this.rand(i + 30) * 4, 4], 0x101820, { flatShading: true });
                rock.rotation.z = .2 + i * .08;
            }
        }
        // Tectonic scar: staggered molten-glass chasm beneath the path.
        const floor = this.box(g, [0, -11, -9], [39, 5, 17], 0x0a0d13, { metalness: .4 });
        floor.rotation.z = .04;
        for (let i = 0; i < 18; i++) {
            const x = -16 + i * 1.9;
            const y = -8 + Math.sin(i * .48) * 1.6;
            const frac = this.box(g, [x, y, -5], [1.22, .11, .08], 0xf08150, { emissive: 0xff6326, emissiveIntensity: 2.5 });
            frac.rotation.z = .35 * Math.sin(i * 1.7);
        }
        for (let i = 0; i < 14; i++) {
            const x = -14 + i * 2.3;
            const mon = this.oct(g, [x, -2 + this.rand(i + 100) * 25, -26], [1.4, 4 + this.rand(i + 150) * 10, 1.2], 0x2b2c39, { metalness: .18, flatShading: true });
            mon.rotation.z = .2 - this.rand(i + 10) * .4;
        }
        for (let i = 0; i < 9; i++) {
            const beam = this.span(g, [-27, -3 + i * 5, -29], [27, -2 + i * 5, -29], .14, .14, 0x554139, { emissive: 0x5f2823, emissiveIntensity: .36 });
            beam.rotation.z = (i % 2 ? -.05 : .05);
        }
        this.makeParticulate(g, 0x9d6d60, 85, [-22, 24], [-9, 44], -5, 1);
    }
    makeWaterShader() {
        const m = new THREE.ShaderMaterial({
            uniforms: { uTime: { value: 0 }, uTint: { value: new THREE.Color(0x6edaff) } },
            vertexShader: `varying vec2 vUv; varying float vGlow; uniform float uTime;
      void main(){vUv=uv; vec3 p=position;
        float w=sin(uv.y*26.0+uTime*3.7+uv.x*6.0)*.16 + sin(uv.y*49.0-uTime*2.2)*.07;
        p.z += w * (0.5+uv.y*.4);
        vGlow=0.5+0.5*sin(uv.y*32.0+uTime*3.0+uv.x*9.0);
        gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);}`,
            fragmentShader: `uniform vec3 uTint; varying vec2 vUv; varying float vGlow;
      void main(){float stripe=pow(max(0.0,sin(vUv.x*35.0+vUv.y*10.0)),18.0);
        float white=0.2+vGlow*.3+stripe*.3;
        vec3 c=mix(uTint,vec3(.92,.98,1.),white);
        float edge=smoothstep(0.0,.08,vUv.x)*(1.0-smoothstep(.92,1.0,vUv.x));
        gl_FragColor=vec4(c, (.28+vGlow*.28)*edge);}`,
            transparent: true, depthWrite: false, side: THREE.DoubleSide,
        });
        this.materials.add(m);
        this.falls.push(m);
        return m;
    }
    makeWaterworks() {
        const g = new THREE.Group();
        this.stageRoots[1].add(g);
        const base = ZONE_RISE;
        // Multiple complete reservoirs and watercourses. Explicit redistribution only.
        for (let bank = 0; bank < 4; bank++) {
            const y = base + 4 + bank * 7.3;
            this.box(g, [0, y, -21 - bank * 2], [63, 1.5, 6], bank % 2 ? 0x204456 : 0x1d3747, { metalness: .46, roughness: .45 });
            this.box(g, [0, y + .75, -19 - bank * 2], [63, .18, 5], 0x3a8f9c, { emissive: 0x155767, emissiveIntensity: .62, transparent: true, opacity: .78 });
            for (const side of [-1, 1]) {
                const arch = this.torus(g, [side * 23, y - 1, -20 - bank * 2], 8, 4.4, 0x547d86, { metalness: .72, roughness: .31 });
                arch.rotation.x = .1;
                this.box(g, [side * 23, y - 5, -20 - bank * 2], [2, 9, 3], 0x183f50, { metalness: .57 });
            }
        }
        const waterGeometry = this.geo(new THREE.PlaneGeometry(3.6, 28, 6, 96));
        const waterMat = this.makeWaterShader();
        for (let i = 0; i < 13; i++) {
            const x = -27 + i * 4.5;
            const span = 22 + this.rand(i + 40) * 20;
            const falls = this.mesh(g, waterGeometry, waterMat, [x, base + span * .5, -10 - (i % 3) * 3], [.65 + this.rand(i) * .75, span / 28, 1]);
            falls.rotation.y = ((i % 5) - 2) * .025;
            this.box(g, [x, base + span * .08, -11], [3, 0.16, .8], 0xa5dce8, { emissive: 0x3e9bbd, emissiveIntensity: 1.5, transparent: true, opacity: .7 });
        }
        for (let i = 0; i < 30; i++) {
            const x = -28 + (i % 10) * 6.3, y = base - 3 + Math.floor(i / 10) * 14;
            const rip = this.torus(g, [x, y, -8 - (i % 3) * 2], .9 + this.rand(i) * 1.6, .2, 0x65bed2, { emissive: 0x12718b, emissiveIntensity: .8, transparent: true, opacity: .27 });
            rip.rotation.x = Math.PI / 2;
            this.floating.push({ object: rip, base: y, phase: i, amplitude: .25 });
        }
        this.makeParticulate(g, 0x82d8ed, 110, [-30, 30], [32, 69], -7, 2);
        for (let i = 0; i < 4; i++) {
            const pipe = this.cylinder(g, [-20 + i * 14, base + 17, -24], [3, 24, 3], 0x244f5c, { metalness: .65 });
            pipe.rotation.z = (i % 2 === 0 ? 1 : -1) * .36;
        }
    }
    makeGear(g, x, y, z, radius, rate) {
        const rotor = new THREE.Group();
        rotor.position.set(x, y, z);
        g.add(rotor);
        this.torus(rotor, [0, 0, 0], radius, radius, 0x9d7056, { metalness: .82, roughness: .25 });
        this.torus(rotor, [0, 0, .23], radius * .69, radius * .69, 0x4b6870, { metalness: .85, roughness: .25 });
        this.cylinder(rotor, [0, 0, .35], [radius * .6, .55, radius * .6], 0x1c2834, { metalness: .84 });
        for (let i = 0; i < 12; i++) {
            const a = i * Math.PI / 6;
            const spoke = this.span(rotor, [0, 0, .1], [Math.cos(a) * radius, Math.sin(a) * radius, .1], .14, .22, 0x967e6d, { metalness: .72 });
            spoke.rotation.z += 0;
            const bolt = this.box(rotor, [Math.cos(a) * radius, Math.sin(a) * radius, .16], [.62, .76, .5], 0xd89d59, { metalness: .65, roughness: .3 });
            bolt.rotation.z = a;
        }
        this.animated.push({ object: rotor, rate, axis: 'z', phase: x * .1 });
    }
    makeFoundry() {
        const g = new THREE.Group();
        this.stageRoots[2].add(g);
        const base = ZONE_RISE * 2;
        // Deep layered industrial hall. Collection/refinement, never extrusion.
        for (let i = 0; i < 8; i++) {
            const x = -38 + i * 11;
            this.box(g, [x, base + 11, -33], [2.8, 40, 3], 0x393238, { metalness: .75, roughness: .4 });
            this.box(g, [x, base + 31, -33], [4, 2.5, 4], 0x69594e, { metalness: .68 });
            this.box(g, [x, base - 8, -31], [6, 18, 7], 0x342b2c, { metalness: .7 });
        }
        for (let i = 0; i < 3; i++) {
            const yy = base + 6 + i * 11;
            this.box(g, [0, yy, -25], [76, 3.2, 9], i % 2 ? 0x45372e : 0x2e3035, { metalness: .66 });
            for (let j = 0; j < 16; j++) {
                const x = -32 + j * 4.3;
                this.box(g, [x, yy + 1.8, -20.2], [2.6, .28, 1.7], 0x7f624c, { metalness: .7 });
            }
            this.makeGear(g, -23 + i * 18, yy + 5.2, -15, 5.4 - i * .7, (i % 2 ? -.18 : .22));
        }
        for (let i = 0; i < 18; i++) {
            const x = -33 + (i % 9) * 8;
            const y = base + 2 + Math.floor(i / 9) * 16;
            this.box(g, [x, y, -14], [1.1, 6.2, 2.3], 0xd88948, { emissive: 0xe56d2c, emissiveIntensity: 1.2, metalness: .35 });
            const press = this.box(g, [x, y + 4, -13], [4, 1.1, 3.6], 0x7b7870, { metalness: .8 });
            this.floating.push({ object: press, base: y + 4, phase: i * .64, amplitude: .48 });
        }
        for (let i = 0; i < 10; i++) {
            const x = -37 + i * 8;
            this.span(g, [x, base - 15, -32], [x + (i % 2 ? 5 : -5), base + 33, -34], .24, .4, 0x69605a, { metalness: .66 });
        }
        for (let i = 0; i < 36; i++) {
            const x = -31 + (i % 9) * 7.6, y = base - 5 + Math.floor(i / 9) * 9;
            this.oct(g, [x, y, -17], [.45, .75, .6], 0xfbb56e, { emissive: 0xed8a39, emissiveIntensity: 2.2 });
        }
        this.makeParticulate(g, 0xb99070, 90, [-30, 30], [65, 101], -8, 3);
    }
    makeOrbit() {
        const g = new THREE.Group();
        this.stageRoots[3].add(g);
        const base = ZONE_RISE * 3;
        // Orbital stage is an abstract assembly diagram, not a historical Blood Ring event.
        for (let i = 0; i < 13; i++) {
            const x = -43 + i * 7.2;
            const height = 37 + this.rand(i + 77) * 42;
            this.span(g, [x, base - 9, -24], [x + Math.sin(i) * 4, base + height, -27], .33, .55, 0x617da1, { metalness: .75, roughness: .33 });
            this.span(g, [x, base + height * .5, -23], [x + 7, base + height * .5 + 8, -22], .16, .22, 0x8ca9c4, { metalness: .7 });
        }
        for (let i = 0; i < 12; i++) {
            const y = base + 5 + i * 5;
            const radius = 12 + i * 2.15;
            const ring = this.torus(g, [3, y, -33], radius, radius * .24, 0x91a8e4, { emissive: 0x32468e, emissiveIntensity: .5, metalness: .53, transparent: true, opacity: .59 });
            ring.rotation.x = .4 + Math.sin(i * .45) * .22;
            ring.rotation.y = .2 + i * .12;
            this.animated.push({ object: ring, rate: .016 + (i % 3) * .006, axis: i % 2 ? 'x' : 'z', phase: i });
        }
        // Giant mechanical extrusion conduits, visibly downstream of foundry.
        for (let i = 0; i < 8; i++) {
            const x = -25 + i * 7.2;
            const core = this.cylinder(g, [x, base + 17, -26], [.8, 46, .8], 0x8f9ec2, { metalness: .75, roughness: .22 });
            core.rotation.z = .04 * i;
            this.cylinder(g, [x, base + 16, -26], [.25, 44, .25], 0xb8ddff, { emissive: 0x7c9fff, emissiveIntensity: 1.3 });
        }
        this.planetShader = planetSurface();
        this.materials.add(this.planetShader);
        const planet = this.mesh(g, this.geo(new THREE.SphereGeometry(1, 48, 28)), this.planetShader, [-48, 175, -109], [81, 81, 81]);
        planet.rotation.z = .23;
        const atmosphere = this.mesh(g, this.sphereGeo, this.basic(0x3f638e, .09), [-48, 175, -111], [84, 84, 84]);
        atmosphere.material.depthWrite = false;
        const limb = this.torus(g, [-48, 175, -106], 83, 83, 0x557ee5, { emissive: 0x446acb, emissiveIntensity: .7, transparent: true, opacity: .16 });
        limb.rotation.y = .23;
        const halo = this.torus(g, [23, base + 50, -51], 38, 15, 0xadbff4, { emissive: 0x5b70d4, emissiveIntensity: 1.2, transparent: true, opacity: .22 });
        halo.rotation.x = .6;
        this.animated.push({ object: halo, rate: .011, axis: 'z', phase: 0 });
        this.makeStars(g);
        this.makeParticulate(g, 0xc6d6ff, 60, [-30, 30], [99, 166], -13, 4);
    }
    tube(parent, points, radius, color, glow = 0) {
        const curve = new THREE.CatmullRomCurve3(points.map(v => new THREE.Vector3(...v)));
        const geo = this.geo(new THREE.TubeGeometry(curve, Math.max(20, points.length * 7), radius, 5, false));
        return this.mesh(parent, geo, this.mat(color, { emissive: color, emissiveIntensity: glow, metalness: .18 }), [0, 0, 0], [1, 1, 1]);
    }
    /** Monumental art landmarks span all 160 authored platforms, not only the opening view. */
    makeStageSculptures() {
        this.sculptFault();
        this.sculptWater();
        this.sculptRefinery();
        this.sculptOrbit();
    }
    sculptFault() {
        const g = new THREE.Group();
        this.stageRoots[0].add(g);
        for (const side of [-1, 1]) {
            for (let layer = 0; layer < 3; layer++) {
                const depth = -10 - layer * 9;
                const edge = 19 + layer * 7;
                const vertices = [[side * (edge + 9), -18]];
                for (let j = 0; j < 18; j++) {
                    const y = -14 + j * 4.55;
                    const x = side * (edge + this.rand(j + layer * 31 + side * 8) * 5.6);
                    vertices.push([x, y]);
                }
                vertices.push([side * (edge + 13), 66]);
                // Reverse winding for the left wall, so one-way front faces remain visible.
                const path = side > 0 ? vertices : vertices.slice().reverse();
                const shape = new THREE.Shape();
                shape.moveTo(path[0][0], path[0][1]);
                for (let j = 1; j < path.length; j++)
                    shape.lineTo(path[j][0], path[j][1]);
                shape.closePath();
                const geo = this.geo(new THREE.ExtrudeGeometry(shape, { depth: 3.6 - layer * .7, bevelEnabled: false, steps: 1 }));
                const slab = this.mesh(g, geo, this.mat(layer === 0 ? 0x22222a : layer === 1 ? 0x181b26 : 0x101624, { roughness: .94, flatShading: true, finish: 'stone' }), [0, 0, depth], [1, 1, 1]);
                slab.rotation.z = (side * layer) * .008;
                for (let seam = 0; seam < 4; seam++) {
                    const yy = seam * 16 + this.rand(layer * 12 + seam) * 4 - 6;
                    this.tube(g, [
                        [side * (edge + 2), yy - 11, depth + 4],
                        [side * (edge + 3.3), yy - 3, depth + 4.03],
                        [side * (edge + 1.6), yy + 4, depth + 4.03],
                        [side * (edge + 4.7), yy + 12, depth + 4.03]
                    ], .07, layer === 0 ? 0xfc8e59 : 0x8e4e3b, layer === 0 ? 2.4 : .48);
                }
            }
        }
        // A shattered tectonic bridge behind the route conveys separation without obstructing jumps.
        for (let i = 0; i < 11; i++) {
            const x = -24 + i * 4.9, y = 8 + Math.sin(i * 1.4) * 5 + i * .5;
            const shard = this.oct(g, [x, y, -18], [2.1 + this.rand(i) * 3, 7 + this.rand(i + 5) * 9, 2.1], i % 3 === 0 ? 0x34323c : 0x1d232e, { flatShading: true, finish: 'stone' });
            shard.rotation.z = .12 * Math.cos(i * .9);
        }
        for (let level = 0; level < 4; level++) {
            const y = 3 + level * 15;
            const warm = this.glow(g, level % 2 ? 25 : -27, y, -15, 31, 0xec6f40, .21);
            this.qualityGroups.push(warm);
        }
    }
    sculptWater() {
        const g = new THREE.Group();
        this.stageRoots[1].add(g);
        const b = ZONE_RISE;
        // The source is pre-existing stored water: tanks, spillways and transfer conduits.
        for (let i = 0; i < 7; i++) {
            const x = -44 + i * 14.5;
            const y = b + 8 + (i % 3) * 11;
            this.box(g, [x, y - 6, -34], [6, 26, 6], 0x163d50, { metalness: .6, roughness: .36, finish: 'metal' });
            for (let ring = 0; ring < 3; ring++) {
                const tor = this.torus(g, [x, y - 15 + ring * 9, -27.6], 4.25, 4.25, 0x5eafba, { metalness: .78, roughness: .3, emissive: 0x195b75, emissiveIntensity: .4 });
                tor.scale.z = .25;
            }
            this.box(g, [x, y + 8, -31], [8, 1.1, 9], 0x83c7ca, { metalness: .4, roughness: .27, emissive: 0x275966, emissiveIntensity: .54 });
            this.tube(g, [
                [x, y + 8, -30],
                [x + (i % 2 ? 6 : -5), y + 13, -24],
                [x + (i % 2 ? 9 : -8), y + 21, -24],
                [x + (i % 2 ? 13 : -12), y + 25, -23]
            ], .43, 0x427889, .12);
        }
        for (let j = 0; j < 6; j++) {
            const x = -34 + j * 12.7;
            this.tube(g, [[x, b - 4, -14], [x - 2, b + 15, -14], [x + 2, b + 29, -14], [x + 1, b + 55, -13]], .2, 0x8ddcef, 1.25);
            this.tube(g, [[x + .5, b - 3, -14], [x - 1.5, b + 14, -14], [x + 2.4, b + 30, -14], [x + 1.5, b + 53, -13]], .052, 0xe5ffff, 2.1);
            const glow = this.glow(g, x, b + 29, -16, 21, 0x5fe7f5, .24);
            this.qualityGroups.push(glow);
        }
        const emblem = this.torus(g, [0, b + 25, -36], 24, 24, 0x9ee7ed, { metalness: .72, roughness: .3, emissive: 0x277790, emissiveIntensity: 1.1, transparent: true, opacity: .4 });
        emblem.scale.z = .6;
        this.animated.push({ object: emblem, rate: .025, axis: 'y', phase: 0 });
    }
    sculptRefinery() {
        const g = new THREE.Group();
        this.stageRoots[2].add(g);
        const b = ZONE_RISE * 2;
        const bronze = this.mat(0x8e755f, { metalness: .8, roughness: .31, finish: 'metal' });
        for (let core = 0; core < 4; core++) {
            const x = -37 + core * 24;
            const y = b + 9 + (core % 2) * 19;
            const housing = new THREE.Group();
            housing.position.set(x, y, -30);
            g.add(housing);
            this.mesh(housing, this.diskGeo, bronze, [0, 0, 0], [6.1, 17, 5]);
            this.cylinder(housing, [0, 0, 1.8], [3.8, 17.7, 3.8], 0x24252e, { metalness: .76, roughness: .35, finish: 'metal' });
            for (let plate = 0; plate < 5; plate++) {
                const yy = -6.5 + plate * 3.35;
                this.box(housing, [0, yy, 5], [10.2, .48, 1.3], 0xb7a38d, { metalness: .71, roughness: .3, finish: 'metal' });
                for (const end of [-1, 1])
                    this.oct(housing, [end * 4.4, yy, 5.6], [.3, .32, .2], 0xffcc86, { emissive: 0xfaa35b, emissiveIntensity: 1.7 });
            }
            this.box(housing, [0, 0, 5.15], [1.4, 12.6, .25], 0xf2ab5d, { emissive: 0xf5a34e, emissiveIntensity: 2.1, transparent: true, opacity: .78 });
            const lamp = this.glow(housing, 0, 0, 5.3, 19, 0xffa759, .23);
            this.qualityGroups.push(lamp);
            // Orthogonal material intake lines stop here; no extrusion in Gorevault.
            this.tube(g, [[x - 13, b - 4, -33], [x - 10, y + 4, -31], [x - 7, y + 6, -30], [x - 5, y + 6, -27]], .4, 0x5a6570, .02);
        }
        for (let i = 0; i < 8; i++) {
            const x = -35 + i * 10;
            this.box(g, [x, b + 51, -38], [1.7, 17, 2.2], 0x47404a, { metalness: .6 });
            this.box(g, [x, b + 43, -34], [.12, 16, .14], 0xedab67, { emissive: 0xcc7738, emissiveIntensity: .9 });
        }
        const lamp = this.glow(g, 5, b + 26, -32, 80, 0xda7846, .18);
        this.qualityGroups.push(lamp);
    }
    sculptOrbit() {
        const g = new THREE.Group();
        this.stageRoots[3].add(g);
        const b = ZONE_RISE * 3;
        // Exposed orbital assembly: long tension spars, suspended rib stations, and abstract orbital arches.
        for (let i = 0; i < 11; i++) {
            const x = -48 + i * 9.8;
            const height = 33 + (i % 4) * 12;
            this.span(g, [x, b - 9, -29], [x + Math.sin(i * 3.4) * 10, b + height, -37], .43, .65, 0x5a7ca8, { metalness: .75, roughness: .3, finish: 'metal' });
            this.span(g, [x + 3, b + height * .23, -30], [x - 6, b + height * .62, -36], .16, .18, 0xa5c0ee, { metalness: .6, roughness: .3 });
            this.oct(g, [x, b + height, -34], [1.1, 2.9, .8], 0xc9d9fc, { emissive: 0x4561b5, emissiveIntensity: .75 });
        }
        for (let ring = 0; ring < 4; ring++) {
            const r = 21 + ring * 8.5;
            const a = this.torus(g, [0, b + 28, -45 - ring * 2], r, r * .77, 0xa9c3f8, { metalness: .44, emissive: 0x4266a0, emissiveIntensity: .75, transparent: true, opacity: .35 - ring * .045 });
            a.rotation.y = .28 + ring * .08;
            this.animated.push({ object: a, rate: .02 + ring * .006, axis: 'z', phase: ring });
        }
        for (let j = 0; j < 15; j++) {
            const x = -41 + j * 5.8;
            this.tube(g, [[x, b + 1, -37], [x + 8, b + 19, -35], [x - 8, b + 41, -33], [x, b + 66, -28]], .055, 0x92afe9, .95);
        }
        const glow = this.glow(g, 0, b + 46, -44, 96, 0x8ba7f4, .15);
        this.qualityGroups.push(glow);
    }
    makeStars(g) {
        const starMat = this.basic(0xdceaff, .95);
        const mesh = new THREE.InstancedMesh(this.octGeo, starMat, 430);
        const temp = new THREE.Object3D();
        for (let i = 0; i < 430; i++) {
            temp.position.set(-90 + this.rand(i * 3 + 10) * 180, 86 + this.rand(i * 3 + 22) * 142, -65 - this.rand(i * 3 + 28) * 36);
            const s = .045 + this.rand(i * 3 + 35) * .19;
            temp.scale.set(s, s * 1.45, s);
            temp.rotation.z = this.rand(i * 5) * Math.PI;
            temp.updateMatrix();
            mesh.setMatrixAt(i, temp.matrix);
        }
        mesh.instanceMatrix.needsUpdate = true;
        g.add(mesh);
        this.qualityGroups.push(mesh);
    }
    makeParticulate(g, color, count, xs, ys, depth, seed) {
        const particles = new THREE.InstancedMesh(this.octGeo, this.mat(color, { emissive: color, emissiveIntensity: .6, transparent: true, opacity: .36 }), count);
        const o = new THREE.Object3D();
        for (let i = 0; i < count; i++) {
            o.position.set(xs[0] + this.rand(seed * 1000 + i * 3) * (xs[1] - xs[0]), ys[0] + this.rand(seed * 2000 + i * 7) * (ys[1] - ys[0]), depth - this.rand(seed * 500 + i * 11) * 12);
            const s = .025 + this.rand(seed * 600 + i * 2) * .12;
            o.scale.set(s, s, s);
            o.rotation.set(this.rand(i + seed), 0, this.rand(i + seed * 70));
            o.updateMatrix();
            particles.setMatrixAt(i, o.matrix);
        }
        particles.instanceMatrix.needsUpdate = true;
        g.add(particles);
        this.qualityGroups.push(particles);
    }
    /**
     * One vertical datum turns four enormous spaces into a single legible visual process.
     * Its geometry is a deliberately abstract interpretation, not a Drakken body or machine blueprint.
     * Positioned behind the jumping plane, so it cannot conceal the player or change collision.
     */
    makeProcessSpine() {
        // Keep the principal machine datum inside ordinary landscape gameplay framing.
        // The former x=28 datum was frequently off-screen in the actual camera frustum.
        const spineX = VISIBLE_PROCESS_SPINE_X;
        const spineZ = -27;
        for (let stage = 0; stage < 4; stage++) {
            const root = this.stageRoots[stage];
            const base = stage * ZONE_RISE;
            const rim = ACTS[stage].color;
            const palette = STAGE_ART[stage];
            const support = this.mat(palette.stone, { metalness: .53, roughness: .51, finish: 'metal' });
            // A repeated datum with different physical treatment in each process section.
            for (const side of [-1, 1]) {
                this.mesh(root, this.cylinderGeo, support, [spineX + side * 3.45, base + ZONE_RISE / 2, spineZ - 2], [.34, ZONE_RISE + 3, .34]);
            }
            this.tube(root, [
                [spineX, base - 1, spineZ], [spineX - .9, base + ZONE_RISE * .25, spineZ],
                [spineX + 1.05, base + ZONE_RISE * .69, spineZ], [spineX, base + ZONE_RISE + 1, spineZ]
            ], stage === 0 ? .18 : stage === 1 ? .26 : stage === 2 ? .32 : .2, rim, .84);
            const tickMaterial = this.mat(rim, { metalness: .23, emissive: rim, emissiveIntensity: .86 });
            const ticks = new THREE.InstancedMesh(this.boxGeo, tickMaterial, 22);
            const dummy = new THREE.Object3D();
            for (let i = 0; i < 22; i++) {
                const y = base + 1.4 + i * (ZONE_RISE - 2.8) / 21;
                const side = i % 2 === 0 ? 1 : -1;
                dummy.position.set(spineX + side * (2.75 + (i % 3) * .12), y, spineZ + .4);
                dummy.rotation.set(0, 0, stage === 0 ? side * .38 : stage === 1 ? side * .2 : stage === 2 ? side * .11 : 0);
                dummy.scale.set(stage === 2 ? 1.2 : .63, .09, .19);
                dummy.updateMatrix();
                ticks.setMatrixAt(i, dummy.matrix);
            }
            ticks.instanceMatrix.needsUpdate = true;
            root.add(ticks);
            const medallion = new THREE.Group();
            medallion.position.set(spineX, base + ZONE_RISE * .52, spineZ + 2.25);
            root.add(medallion);
            const arc = this.torus(medallion, [0, 0, 0], 5.3, 5.3, rim, { emissive: rim, emissiveIntensity: .35, metalness: .68, roughness: .32, transparent: true, opacity: .45 });
            arc.rotation.y = .12;
            if (stage === 0) {
                for (const side of [-1, 1]) {
                    const shard = this.oct(medallion, [side * 2.1, 0, .8], [1.4, 5.1, .65], 0x535762, { flatShading: true, finish: 'stone' });
                    shard.rotation.z = side * .3;
                }
                this.span(medallion, [-1.7, -3.2, 1.5], [1.7, 3.2, 1.5], .11, .14, rim, { emissive: rim, emissiveIntensity: 1.45 });
            }
            else if (stage === 1) {
                for (let i = 0; i < 3; i++) {
                    const band = this.torus(medallion, [0, -2.0 + i * 2.0, .9], 3.9 - i * .9, 1.6, rim, { emissive: rim, emissiveIntensity: .53, transparent: true, opacity: .56 });
                    band.rotation.x = Math.PI / 2 + .18;
                }
            }
            else if (stage === 2) {
                for (let i = 0; i < 8; i++) {
                    const a = i * Math.PI / 4;
                    this.span(medallion, [Math.cos(a) * 4.1, Math.sin(a) * 4.1, .8], [Math.cos(a) * 1.3, Math.sin(a) * 1.3, 1.5], .26, .19, 0xc6a88d, { metalness: .67 });
                }
                this.mesh(medallion, this.octGeo, this.mat(0xf0c28a, { metalness: .57, emissive: rim, emissiveIntensity: 1.2 }), [0, 0, 1.8], [1.35, 1.8, .75]);
            }
            else {
                for (let i = 0; i < 8; i++) {
                    const a = i * Math.PI / 4;
                    this.span(medallion, [Math.cos(a) * 2.3, Math.sin(a) * 2.3, 1], [Math.cos(a) * 7.3, Math.sin(a) * 7.3, -.7], .19, .21, 0x98a9da, { metalness: .64, emissive: rim, emissiveIntensity: .35 });
                }
                this.torus(medallion, [0, 0, 1.8], 2.9, 2.9, 0xeff4ff, { emissive: rim, emissiveIntensity: .81, transparent: true, opacity: .8 });
            }
            const eye = this.glow(root, spineX, base + 8, spineZ + 3.3, 9, rim, .48);
            this.processSignals.push({ sprite: eye, stage, base, offset: stage * .137 });
            this.qualityGroups.push(eye);
        }
    }
    makePlatforms() {
        // Five small shared batches per act replace ~1,400 independently submitted
        // platform pieces. The physics route remains the sole collision authority.
        for (let act = 0; act < 4; act++) {
            const specs = PLATFORMS.filter(spec => spec.act === act);
            const rim = ACTS[act].color;
            const colors = [0x424650, 0x2c6474, 0x6d554a, 0x4e628c];
            const deck = this.instanced(act, specs.length, colors[act], { roughness: .64, metalness: .51, finish: 'stone' });
            const cap = this.instanced(act, specs.length, act === 0 ? 0x9a9da6 : act === 1 ? 0xa3c4c6 : act === 2 ? 0xb8a38a : 0xbacbf0, { metalness: .65, roughness: .31, finish: 'metal' });
            const edge = this.instanced(act, specs.length, rim, { emissive: rim, emissiveIntensity: 1.4, metalness: .25, roughness: .35 });
            const notch = this.instanced(act, specs.length * 2, 0xdfe9f3, { emissive: rim, emissiveIntensity: .42, metalness: .32 });
            const braces = this.instanced(act, specs.length * 2, act === 0 ? 0x323a48 : act === 1 ? 0x276071 : act === 2 ? 0x716154 : 0x53617e, { metalness: .55, roughness: .42 });
            this.batches.push({ specs, dynamic: specs.flatMap((p, i) => p.kind === 'moving' || p.kind === 'lift' ? [i] : []), deck, cap, edge, notch, braces });
        }
        // Unique interactive ornaments are scene objects because only a small
        // fraction of ledges need them: moving pads, checkpoints, lifts and goal.
        for (const spec of PLATFORMS) {
            const act = spec.act;
            const group = new THREE.Group();
            group.position.set(spec.x, spec.top, 0);
            this.stageRoots[spec.act].add(group);
            this.platformGroups.set(spec.id, group);
            if (spec.kind === 'moving' || spec.kind === 'lift')
                this.dynamicPlatforms.push(spec);
            const rim = ACTS[act].color;
            if (spec.kind === 'moving') {
                for (const side of [-1, 1]) {
                    const x = side * (spec.width / 2 - .6);
                    this.box(group, [x, -.57, 0], [.38, .65, 1.7], 0xafd4e2, { metalness: .68, finish: 'metal' });
                    this.oct(group, [x, -.97, .8], [.18, .24, .18], rim, { emissive: rim, emissiveIntensity: 1.4 });
                }
            }
            if (spec.checkpoint) {
                const beacon = new THREE.Group();
                beacon.position.set(0, .68, -.75);
                group.add(beacon);
                this.oct(beacon, [0, .25, 0], [.28, .62, .28], 0xdaf5f5, { emissive: rim, emissiveIntensity: 1.4, metalness: .25 });
                const halo = this.torus(beacon, [0, .26, 0], .63, .25, rim, { emissive: rim, emissiveIntensity: 1.3, metalness: .38 });
                halo.rotation.y = .25;
                this.animated.push({ object: halo, rate: .12, axis: 'z', phase: spec.index });
                this.floating.push({ object: beacon, base: .68, phase: act * 8 + spec.index, amplitude: .13 });
                const signal = this.glow(beacon, 0, .27, .2, 3.2, rim, .28);
                this.checkpointSignals.push({ sprite: signal, platformId: spec.id });
            }
            if (spec.kind === 'lift') {
                for (const side of [-1, 1]) {
                    const x = side * (spec.width / 2 + .12);
                    this.box(group, [x, 1.25, -1.65], [.31, 2.8, .42], 0xa5b4c6, { metalness: .76, roughness: .36, finish: 'metal' });
                    this.box(group, [x, 1.1, -1.16], [.06, 2.3, .06], rim, { emissive: rim, emissiveIntensity: 2 });
                    this.oct(group, [x, 2.65, -1.65], [.32, .38, .32], 0xfff0d5, { emissive: rim, emissiveIntensity: 1.3 });
                }
                const gantry = this.torus(group, [0, 1.9, -1.4], 1.38, 1.38, rim, { emissive: rim, emissiveIntensity: 1.7, metalness: .54 });
                gantry.rotation.y = .27;
                this.glow(group, 0, 1.9, -1.6, 6, rim, .3);
            }
            if (spec.kind === 'overlook') {
                this.box(group, [0, -1.1, -1.6], [9.5, 2.5, 4.6], 0x38526d, { metalness: .75, roughness: .31, finish: 'metal' });
                const overlook = this.torus(group, [0, 2.7, -2.6], 5.5, 4.6, 0xc8ddff, { emissive: 0x5a83d0, emissiveIntensity: 1.55, metalness: .5 });
                overlook.rotation.y = .25;
                for (let i = 0; i < 11; i++) {
                    const x = -3.9 + i * .78;
                    this.box(group, [x, .38, -.76], [.05, .92, .13], 0xe9f4ff, { emissive: 0x7baef0, emissiveIntensity: 1.55 });
                }
                this.glow(group, 0, 3.6, -2.6, 16, 0x9fbcfa, .29);
            }
        }
        this.updateDecks(0);
        this.tintRouteEdges(false);
    }
    /** Prioritize actual moving, checkpoint and lift ledges without new meshes. */
    tintRouteEdges(contrast) {
        const tint = new THREE.Color();
        for (const batch of this.batches) {
            batch.specs.forEach((spec, i) => {
                const hex = contrast ? 0xffffff : spec.kind === 'lift' || spec.kind === 'overlook' ? 0xffffff :
                    spec.checkpoint ? 0xf9e5c6 : spec.kind === 'moving' ? 0xbbe7f2 : 0x8d99a6;
                batch.edge.setColorAt(i, tint.setHex(hex));
            });
            if (batch.edge.instanceColor)
                batch.edge.instanceColor.needsUpdate = true;
        }
    }
    instanced(act, count, color, opts) {
        const mesh = new THREE.InstancedMesh(this.boxGeo, this.mat(color, opts), count);
        mesh.frustumCulled = false;
        mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.stageRoots[act].add(mesh);
        return mesh;
    }
    updateDecks(time, sim) {
        const liftSignature = sim ? sim.lifts.map(v => Math.round(v * 10000)).join(':') : '';
        const reduced = sim?.reducedMotion ?? false;
        if (this.lastBatchTime === time && this.lastReducedState === reduced && this.lastLiftSignature === liftSignature)
            return;
        const full = this.lastReducedState === null || !sim;
        this.lastBatchTime = time;
        this.lastReducedState = reduced;
        this.lastLiftSignature = liftSignature;
        const instance = this.instanceDummy;
        const up = this.up;
        const a = this.vecA;
        const b = this.vecB;
        const place = (mesh, i, x, y, z, sx, sy, sz) => {
            instance.position.set(x, y, z);
            instance.rotation.set(0, 0, 0);
            instance.scale.set(sx, sy, sz);
            instance.updateMatrix();
            mesh.setMatrixAt(i, instance.matrix);
        };
        for (const batch of this.batches) {
            // Static ledges and overlook matrices are authored once; only real moving/lift
            // platforms are recomputed on subsequent frames. 160 collision surfaces stay intact.
            const indices = full ? batch.specs.map((_, i) => i) : batch.dynamic;
            for (const i of indices) {
                const spec = batch.specs[i];
                const pose = sim ? sim.getPlatformPose(spec, time) : { x: spec.x, top: spec.top, width: spec.width };
                const { x, top, width } = pose;
                place(batch.deck, i, x, top - .25, 0, width, .5, 3.45);
                place(batch.cap, i, x, top + .014, 0, width - .18, .09, 3.22);
                place(batch.edge, i, x, top - .08, 1.72, width - .15, .115, .14);
                for (const side of [-1, 1]) {
                    const n = i * 2 + (side === 1 ? 1 : 0);
                    place(batch.notch, n, x + side * (width / 2 - .15), top + .13, 1.03, .13, .28, .64);
                    a.set(x + side * width / 2, top - .5, -1.25);
                    b.set(x, top - 2.2, -6.1);
                    const direction = this.vecDir.copy(b).sub(a);
                    instance.position.copy(a).add(b).multiplyScalar(.5);
                    instance.scale.set(.22, direction.length(), .26);
                    instance.quaternion.setFromUnitVectors(up, direction.normalize());
                    instance.updateMatrix();
                    batch.braces.setMatrixAt(n, instance.matrix);
                    instance.quaternion.identity();
                }
            }
            if (indices.length)
                for (const key of ['deck', 'cap', 'edge', 'notch', 'braces']) {
                    const matrix = batch[key].instanceMatrix;
                    matrix.clearUpdateRanges();
                    for (const i of indices) {
                        const base = (key === 'notch' || key === 'braces') ? i * 2 : i;
                        matrix.addUpdateRange(base * 16, (key === 'notch' || key === 'braces') ? 32 : 16);
                    }
                    matrix.needsUpdate = true;
                }
        }
    }
    /**
     * Material/geometry-local instancing of static authored scenery, partitioned into
     * short vertical cells. Reduces submissions without treating animations as scenery
     * or forcing the entire four-act world to render at every camera position.
     */
    batchStaticScenery() {
        const fixedGeometry = new Set([
            this.boxGeo, this.cylinderGeo, this.icoGeo, this.octGeo, this.sphereGeo, this.torusGeo, this.diskGeo,
        ]);
        const dynamic = new Set([
            this.portal,
            ...this.animated.map(value => value.object),
            ...this.floating.map(value => value.object),
            ...this.platformGroups.values(),
            ...this.qualityGroups,
        ]);
        for (const root of this.stageRoots) {
            root.updateWorldMatrix(true, true);
            const inverse = new THREE.Matrix4().copy(root.matrixWorld).invert();
            const candidateGroups = new Map();
            const visit = (node, excluded) => {
                const blocked = excluded || dynamic.has(node);
                if (blocked)
                    return;
                if (node instanceof THREE.Mesh && !(node instanceof THREE.InstancedMesh) &&
                    fixedGeometry.has(node.geometry) && node.visible &&
                    !Array.isArray(node.material) && !node.material.transparent &&
                    (node.material instanceof THREE.MeshStandardMaterial || node.material instanceof THREE.MeshBasicMaterial)) {
                    const y = node.getWorldPosition(this.vecA).y;
                    const cell = Math.floor(y / 18);
                    const key = `${node.geometry.uuid}/${node.material.uuid}/${cell}`;
                    let group = candidateGroups.get(key);
                    if (!group) {
                        group = { geometry: node.geometry, material: node.material, members: [] };
                        candidateGroups.set(key, group);
                    }
                    group.members.push(node);
                }
                // Snapshot children: collection is not mutated until traversal completes.
                for (const child of node.children)
                    visit(child, blocked);
            };
            for (const child of root.children)
                visit(child, false);
            for (const group of candidateGroups.values()) {
                if (group.members.length < 3)
                    continue;
                const batch = new THREE.InstancedMesh(group.geometry, group.material, group.members.length);
                batch.name = 'Static set dressing / authored mesh group';
                for (let i = 0; i < group.members.length; i++) {
                    const member = group.members[i];
                    const localMatrix = new THREE.Matrix4().multiplyMatrices(inverse, member.matrixWorld);
                    batch.setMatrixAt(i, localMatrix);
                }
                batch.instanceMatrix.needsUpdate = true;
                batch.computeBoundingSphere();
                // Commit only after the entire instance buffer and bounds are valid.
                root.add(batch);
                for (const member of group.members)
                    member.parent?.remove(member);
                this.staticSceneryBatches.push(batch);
                this.staticMeshesReplaced += group.members.length;
            }
        }
    }
    /** The next actual route ledge, never an invented collision or world objective. */
    makeLandingGuide() {
        const m = new THREE.MeshBasicMaterial({ color: ACTS[0].color, transparent: true, opacity: .77, depthWrite: false, depthTest: true, side: THREE.DoubleSide });
        const core = new THREE.MeshBasicMaterial({ color: 0xf9f6e8, transparent: true, opacity: .95, depthWrite: false });
        this.materials.add(m);
        this.materials.add(core);
        this.landingGuideRing = this.mesh(this.landingGuide, this.torusGeo, m, [0, 0, 0], [.65, .35, .5]);
        this.landingGuideCore = this.mesh(this.landingGuide, this.octGeo, core, [0, .66, 0], [.15, .25, .11]);
        this.landingGuideGlow = this.glow(this.landingGuide, 0, .12, -.09, 2.5, ACTS[0].color, .24);
        this.scene.add(this.landingGuide);
        this.landingGuide.renderOrder = 6;
    }
    /** Reused lightweight motion traces; no gameplay influence and no unbounded spawning. */
    makeRunTraces() {
        const geo = this.geo(new THREE.PlaneGeometry(1, 1));
        for (let i = 0; i < 3; i++) {
            const mat = new THREE.MeshBasicMaterial({ color: ACTS[0].color, transparent: true, opacity: 0, depthWrite: false, depthTest: true, side: THREE.DoubleSide });
            this.materials.add(mat);
            const streak = this.mesh(this.scene, geo, mat, [0, 0, 1.65], [1, .09, 1]);
            streak.visible = false;
            streak.renderOrder = 6;
            this.runTraces.push(streak);
        }
    }
    /** Three stage transitions gain a bounded physical light volume behind their lift. */
    makeLiftBeams() {
        const geo = this.geo(new THREE.PlaneGeometry(1, 1));
        for (const spec of PLATFORMS.filter(spec => spec.kind === 'lift')) {
            const material = new THREE.MeshBasicMaterial({ color: ACTS[spec.act + 1].color, transparent: true, opacity: 0, depthWrite: false, depthTest: true, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
            this.materials.add(material);
            const beam = this.mesh(this.stageRoots[spec.act], geo, material, [spec.x, spec.top + LIFT_RISE * .5, -3.4], [spec.width * .8, LIFT_RISE, 1]);
            beam.visible = false;
            beam.renderOrder = 1;
            this.liftBeams.push({ mesh: beam, material, act: spec.act, x: spec.x, top: spec.top });
        }
    }
    getRenderSavings() {
        return { replaced: this.staticMeshesReplaced, batches: this.staticSceneryBatches.length, estimatedSaved: Math.max(0, this.staticMeshesReplaced - this.staticSceneryBatches.length) };
    }
    /** Each ascent threshold is an authored, non-colliding diagrammatic set-piece.
     * The three distinct portals visually indicate change of process, never a
     * biological feature or a canonical location/event. Each is behind gameplay.
     */
    makeThresholds() {
        const lifts = PLATFORMS.filter(spec => spec.kind === 'lift');
        for (const spec of lifts) {
            const nextAct = spec.act + 1;
            const accent = ACTS[nextAct].color;
            const group = new THREE.Group();
            group.position.set(spec.x, spec.top + LIFT_RISE * .5, -17.5);
            this.stageRoots[spec.act].add(group);
            const metal = this.mat(0x66768c, { metalness: .76, roughness: .35, finish: 'metal' });
            for (const side of [-1, 1]) {
                this.mesh(group, this.boxGeo, metal, [side * 5.0, 0, -1.0], [.38, 13, .6]);
                this.oct(group, [side * 5, 6.5, 0], [.72, 1.0, .56], accent, { emissive: accent, emissiveIntensity: 1.05 });
                this.span(group, [side * 5.0, -5.4, -1], [side * 2.7, -7.2, -2.3], .19, .32, 0x8496b3, { metalness: .6 });
            }
            this.span(group, [-5, 6.4, -1], [5, 6.4, -1], .42, .65, 0xb0bacb, { metalness: .7, roughness: .38 });
            const rim = this.torus(group, [0, 1, -1.8], 4.4, 5.0, accent, { emissive: accent, emissiveIntensity: .68, transparent: true, opacity: .48, metalness: .46 });
            rim.rotation.y = .18;
            const pulse = this.torus(group, [0, 1, -1.6], 3.15, 3.7, 0xe4e9f4, { emissive: accent, emissiveIntensity: .44, transparent: true, opacity: .34 });
            pulse.rotation.y = .17;
            const aura = this.glow(group, 0, 1, -3.4, 17, accent, .22);
            this.qualityGroups.push(aura);
            this.thresholds.push({ ring: pulse, aura, act: spec.act });
        }
    }
    makePortal() {
        const portal = new THREE.Group();
        portal.position.set(-12, 0, -3.2);
        this.stageRoots[0].add(portal);
        this.torus(portal, [0, 3, -.2], 2.25, 3.2, 0xe7d6aa, { metalness: .9, roughness: .2, emissive: 0xaa8055, emissiveIntensity: .3 });
        this.box(portal, [-2.25, 1.4, -.2], [.7, 2.8, .7], 0x655b55, { metalness: .65 });
        this.box(portal, [2.25, 1.4, -.2], [.7, 2.8, .7], 0x655b55, { metalness: .65 });
        const inner = this.mesh(portal, this.sphereGeo, this.basic(0x92a2d6, .1), [0, 3, -.3], [1.8, 2.65, .13]);
        inner.scale.z = .08;
        return portal;
    }
    makeSpectator() {
        // An anonymous ceramic survey silhouette, deliberately not a Drakken or lore character.
        const p = new THREE.Group();
        this.scene.add(p);
        const shell = { metalness: .24, roughness: .54, finish: 'ceramic' };
        this.box(p, [0, 1.03, -.06], [.94, .92, .57], 0xd8d5c8, shell);
        this.box(p, [0, 1.17, .34], [.68, .2, .08], 0x657782, { metalness: .65, roughness: .34 });
        this.box(p, [0, 1.15, .4], [.48, .07, .04], 0x8bdaef, { emissive: 0x54bbdf, emissiveIntensity: 1.5 });
        this.box(p, [0, 1.17, -.47], [.77, .88, .39], 0x445567, { metalness: .55, roughness: .45 });
        this.box(p, [0, 1.14, -.69], [.46, .62, .12], 0xc69369, { metalness: .62, roughness: .28 });
        this.box(p, [0, 1.98, .0], [.61, .11, .65], 0x77909c, { metalness: .64 });
        this.mesh(p, this.sphereGeo, this.mat(0xf1e8d7, { metalness: .26, roughness: .45, finish: 'ceramic' }), [0, 1.79, .08], [.58, .62, .55]);
        this.visor = this.box(p, [0, 1.81, .53], [.93, .31, .14], 0x071b32, { metalness: .84, roughness: .12 });
        this.box(p, [0, 1.8, .615], [.76, .07, .035], 0xbbeefa, { emissive: 0x4da8e0, emissiveIntensity: 2.0 });
        this.box(p, [0, 1.61, .48], [.76, .08, .14], 0x536472, { metalness: .78, roughness: .25 });
        const crest = this.oct(p, [0, 2.4, 0], [.12, .21, .13], 0xf8d2a7, { emissive: 0x94734b, emissiveIntensity: .4 });
        crest.rotation.z = Math.PI / 4;
        const limb = (x, y, arm) => {
            const pivot = new THREE.Group();
            pivot.position.set(x, y, 0);
            p.add(pivot);
            if (arm) {
                this.box(pivot, [x < 0 ? -.07 : .07, -.32, 0], [.27, .63, .31], 0x9eabae, shell);
                this.box(pivot, [x < 0 ? -.07 : .07, -.7, .06], [.31, .27, .35], 0x536679, { metalness: .5, roughness: .48 });
                this.box(pivot, [x < 0 ? -.07 : .07, -.43, .2], [.13, .25, .04], 0x8dc8de, { emissive: 0x34647f, emissiveIntensity: .9 });
            }
            else {
                this.box(pivot, [0, -.39, .01], [.33, .74, .39], 0x75818b, { metalness: .26, roughness: .61, finish: 'ceramic' });
                this.box(pivot, [0, -.8, .21], [.42, .26, .71], 0x222f3d, { metalness: .46, roughness: .48 });
                this.box(pivot, [0, -.86, .54], [.31, .08, .12], 0xeead78, { emissive: 0xb07245, emissiveIntensity: .7 });
            }
            return pivot;
        };
        this.leftArm = limb(-.61, 1.51, true);
        this.rightArm = limb(.61, 1.51, true);
        this.leftLeg = limb(-.25, .87, false);
        this.rightLeg = limb(.25, .87, false);
        this.glow(p, 0, 1.8, .55, 2.55, 0x81dff7, .16);
        // Contact ellipse gives precise visual feedback on grounded / airborne state.
        const shadowMaterial = new THREE.MeshBasicMaterial({ color: 0x05070e, transparent: true, opacity: .38, depthWrite: false });
        this.materials.add(shadowMaterial);
        this.contact = this.mesh(this.scene, this.diskGeo, shadowMaterial, [0, .025, 1.15], [.85, .006, .57]);
        this.contact.renderOrder = 4;
        return p;
    }
    makeSparks() {
        const capacity = 96;
        this.sparkPositions = new Float32Array(capacity * 3);
        this.sparkColors = new Float32Array(capacity * 3);
        this.sparkGeometry = this.geo(new THREE.BufferGeometry());
        const positions = new THREE.BufferAttribute(this.sparkPositions, 3);
        const colors = new THREE.BufferAttribute(this.sparkColors, 3);
        positions.setUsage(THREE.DynamicDrawUsage);
        colors.setUsage(THREE.DynamicDrawUsage);
        this.sparkGeometry.setAttribute('position', positions);
        this.sparkGeometry.setAttribute('color', colors);
        this.sparkGeometry.setDrawRange(0, 0);
        const material = new THREE.PointsMaterial({ size: .14, vertexColors: true, transparent: true, opacity: .9, depthWrite: false, sizeAttenuation: true, blending: THREE.AdditiveBlending });
        this.materials.add(material);
        const mesh = new THREE.Points(this.sparkGeometry, material);
        mesh.frustumCulled = false;
        mesh.renderOrder = 9;
        this.scene.add(mesh);
        this.qualityGroups.push(mesh);
    }
    /** Purely presentational particle response; never affects jump/collision/timing. */
    pulseAt(x, y, act, count = 18) {
        if (this.eco)
            return;
        const amount = Math.min(count, 96 - this.sparks.length);
        for (let i = 0; i < amount; i++) {
            const phase = this.visualClock * 71 + i * 2.39996;
            const speed = 1.1 + this.rand(i + Math.floor(phase * 4)) * 1.9;
            const angle = phase;
            this.sparks.push({ x: x + (this.rand(i + 43) - .5) * 1.2, y: y + .14, z: 1.85,
                vx: Math.cos(angle) * speed, vy: .9 + Math.abs(Math.sin(angle)) * speed,
                life: .58 + this.rand(i + 73) * .46, max: 1, act });
        }
    }
    update(sim, dt, visualX = sim.player.x, visualY = sim.player.y, renderTime = sim.time) {
        this.visualClock += dt;
        this.updateDecks(renderTime, sim);
        // Depth-only parallax: only the far shader planes shift, never colliders.
        const backdropParallax = this.overview || sim.reducedMotion ? 0 : Math.max(-1.8, Math.min(1.8, visualX * .11));
        for (const backdrop of this.backdrops)
            backdrop.position.x = backdropParallax;
        for (let i = 0; i < 4; i++)
            this.stageRoots[i].visible = this.overview || Math.abs(i - sim.player.act) <= 1;
        for (const spec of this.dynamicPlatforms) {
            const p = sim.getPlatformPose(spec, renderTime);
            this.platformGroups.get(spec.id).position.set(p.x, p.top, 0);
        }
        // One small world-space landing sign updates from collision-authoritative poses.
        // During a jump, hold the last grounded route identity so the target does not flicker.
        if (sim.player.groundedId)
            this.lastKnownPlatform = sim.player.groundedId;
        const index = PLATFORMS.findIndex(spec => spec.id === this.lastKnownPlatform);
        const next = PLATFORMS[index + 1];
        this.landingGuide.visible = Boolean(next) && !sim.player.finished && !this.overview;
        if (next) {
            const pose = sim.getPlatformPose(next, renderTime);
            this.landingGuide.position.set(pose.x, pose.top + .56, 2.13);
            const tint = ACTS[next.act].color;
            this.landingGuideRing.material.color.setHex(tint);
            this.landingGuideGlow.material.color.setHex(tint);
            const hover = sim.reducedMotion ? 0 : Math.sin(renderTime * 2.3) * .09;
            this.landingGuideCore.position.y = .66 + hover;
            this.landingGuideRing.rotation.z = sim.reducedMotion ? 0 : Math.sin(renderTime * 1.05) * .06;
            this.landingGuideGlow.visible = !this.eco;
        }
        for (const threshold of this.thresholds) {
            const phase = sim.reducedMotion ? 0 : renderTime * .09 + threshold.act * .33;
            threshold.ring.rotation.z = Math.sin(phase) * .11;
            threshold.aura.material.opacity = this.eco ? 0 : sim.reducedMotion ? .19 : .17 + Math.sin(phase * 1.2) * .035;
        }
        for (const beam of this.liftBeams) {
            const active = sim.liftActive[beam.act];
            const progress = sim.lifts[beam.act];
            beam.mesh.visible = active && !this.eco && !this.overview;
            if (active) {
                beam.material.opacity = sim.reducedMotion ? .19 : .16 + Math.sin(renderTime * 2.2) * .025;
                const length = Math.max(.12, LIFT_RISE * progress);
                beam.mesh.scale.y = length;
                beam.mesh.position.y = beam.top + length * .5;
            }
        }
        const traceSpeed = Math.min(1, Math.abs(sim.player.vx) / 5.65);
        const showTraces = !this.eco && !sim.reducedMotion && !this.overview && dt > 0 && traceSpeed > .34 && Boolean(sim.player.groundedId);
        for (let i = 0; i < this.runTraces.length; i++) {
            const streak = this.runTraces[i];
            streak.visible = showTraces;
            if (!showTraces)
                continue;
            streak.position.set(visualX - sim.player.facing * (.86 + i * .37), visualY + .36 + i * .22, 1.55 - i * .04);
            streak.scale.set(.35 + traceSpeed * (.55 + i * .22), .035 + i * .015, 1);
            streak.rotation.z = sim.player.facing * (-.08 - i * .035);
            streak.material.color.setHex(ACTS[sim.player.act].color);
            streak.material.opacity = (.36 - i * .09) * traceSpeed;
        }
        // Small, bounded visual provenance cues: the existing checkpoint state drives
        // the glow, never vice versa. Unvisited checkpoints remain readable.
        if (sim.checkpoints.length !== this.lastCheckpointLitCount) {
            this.lastCheckpointLitCount = sim.checkpoints.length;
            const visited = new Set(sim.checkpoints.map(c => c.platformId));
            for (const beacon of this.checkpointSignals) {
                beacon.sprite.material.opacity = visited.has(beacon.platformId) ? .17 : .31;
            }
        }
        for (const signal of this.processSignals) {
            const v = sim.reducedMotion ? 0.16 : ((renderTime * .12 + signal.offset) % 1);
            signal.sprite.position.y = signal.base + 6 + (ZONE_RISE - 12) * v;
        }
        const player = sim.player;
        const grounded = Boolean(player.groundedId);
        if (grounded && this.lastGround === null && !sim.reducedMotion) {
            this.landingEnergy = Math.min(1.0, .35 + Math.abs(player.vx) * .09);
            this.pulseAt(player.x, player.y, player.act, 14);
        }
        if (!grounded && this.lastGround !== null && player.vy > 0 && !sim.reducedMotion) {
            this.pulseAt(player.x, player.y, player.act, 9);
        }
        this.lastGround = player.groundedId;
        const moving = grounded && Math.abs(player.vx) > .27 && dt > 0;
        const run = Math.min(1, Math.abs(player.vx) / 5.65);
        const stride = moving && !sim.reducedMotion ? Math.sin(sim.time * 13.4) * .57 * run : 0;
        this.leftLeg.rotation.z = stride;
        this.rightLeg.rotation.z = -stride;
        this.leftArm.rotation.z = -stride * .6;
        this.rightArm.rotation.z = stride * .6;
        const idle = grounded && !moving && !sim.reducedMotion ? Math.sin(sim.time * 1.45) * .015 : 0;
        const bob = (moving && !sim.reducedMotion ? Math.abs(Math.sin(sim.time * 13.4)) * .065 * run : 0) + idle;
        const compression = sim.reducedMotion ? 0 : this.landingEnergy * .075;
        this.spectator.position.set(visualX, visualY + bob - compression, 1.05);
        this.spectator.rotation.y = player.facing < 0 ? -.19 : .19;
        this.spectator.rotation.z = sim.reducedMotion ? 0 : Math.max(-.055, Math.min(.055, -player.vx * .006));
        this.spectator.scale.set(1 + compression * .45, 1 - compression, 1);
        const airborne = !grounded;
        this.leftLeg.rotation.z += airborne && !sim.reducedMotion ? .11 : 0;
        this.rightLeg.rotation.z -= airborne && !sim.reducedMotion ? .1 : 0;
        this.contact.visible = grounded;
        this.contact.position.set(visualX, visualY + .022, 1.11);
        this.contact.scale.set(grounded ? .82 : 1.4, .007, grounded ? .58 : 1);
        this.landingEnergy = Math.max(0, this.landingEnergy - dt * 2.7);
        if (!sim.reducedMotion && dt > 0) {
            for (const item of this.animated)
                item.object.rotation[item.axis] += item.rate * dt;
            for (const item of this.floating)
                item.object.position.y = item.base + Math.sin(sim.time * 1.12 + item.phase) * item.amplitude;
            for (const material of this.falls)
                material.uniforms.uTime.value = renderTime;
        }
        else if (sim.reducedMotion) {
            for (const item of this.floating)
                item.object.position.y = item.base;
            for (const material of this.falls)
                material.uniforms.uTime.value = 0;
        }
        for (const material of this.backShaders)
            material.uniforms.uTime.value = sim.reducedMotion ? 0 : renderTime;
        if (this.planetShader) {
            this.planetShader.uniforms.uTime.value = sim.reducedMotion ? 0 : renderTime;
            this.planetShader.uniforms.uReduced.value = Number(sim.reducedMotion);
        }
        const target = this.stageBackgrounds[player.act];
        const blend = Math.min(1, dt * 1.8);
        this.scene.background.lerp(target, blend);
        if (this.scene.fog instanceof THREE.FogExp2)
            this.scene.fog.color.lerp(target, blend);
        this.lightKey.color.lerp(this.stageKey[player.act], blend);
        this.lightRim.color.lerp(this.stageRims[player.act], blend);
        // Update one capped pooled draw rather than allocating particles per collision.
        if (sim.reducedMotion || this.eco)
            this.sparks.length = 0;
        let count = 0;
        for (let i = this.sparks.length - 1; i >= 0; i--) {
            const a = this.sparks[i];
            a.life -= dt;
            if (a.life <= 0) {
                this.sparks.splice(i, 1);
                continue;
            }
            a.x += a.vx * dt;
            a.y += a.vy * dt;
            a.vy -= 2.7 * dt;
            const color = this.stageRims[a.act];
            const fade = Math.max(.3, Math.min(1, a.life * 1.6));
            this.sparkPositions[count * 3] = a.x;
            this.sparkPositions[count * 3 + 1] = a.y;
            this.sparkPositions[count * 3 + 2] = a.z;
            this.sparkColors[count * 3] = color.r * fade;
            this.sparkColors[count * 3 + 1] = color.g * fade;
            this.sparkColors[count * 3 + 2] = color.b * fade;
            count++;
        }
        this.sparkGeometry.setDrawRange(0, count);
        this.sparkGeometry.getAttribute('position').needsUpdate = true;
        this.sparkGeometry.getAttribute('color').needsUpdate = true;
    }
    setOverview(active) {
        if (active === this.overview)
            return;
        this.overview = active;
        if (this.scene.fog instanceof THREE.FogExp2)
            this.scene.fog.density = active ? .0021 : this.contrast ? .0035 : .006;
        if (active) {
            for (const root of this.stageRoots)
                root.visible = true;
            this.landingGuide.visible = false;
            for (const beam of this.liftBeams)
                beam.mesh.visible = false;
            for (const streak of this.runTraces)
                streak.visible = false;
        }
    }
    setContrast(active) {
        this.contrast = active;
        this.tintRouteEdges(active);
        for (const batch of this.batches) {
            batch.edge.material.emissiveIntensity = active ? 2.6 : 1.4;
            batch.notch.material.emissiveIntensity = active ? 1.15 : .42;
        }
        if (this.scene.fog instanceof THREE.FogExp2)
            this.scene.fog.density = this.overview ? .0021 : active ? .0035 : .006;
    }
    setQuality(eco) {
        this.eco = eco;
        for (const object of this.qualityGroups)
            object.visible = !eco;
        if (eco) {
            this.sparks.length = 0;
            this.sparkGeometry.setDrawRange(0, 0);
        }
    }
    getCounts() {
        return { geometries: this.geometries.size, materials: this.materials.size, textures: this.textures.size, platforms: this.platformGroups.size };
    }
    dispose() {
        for (const batch of this.staticSceneryBatches)
            batch.dispose();
        for (const group of this.batches)
            for (const key of ['deck', 'cap', 'edge', 'notch', 'braces'])
                group[key].dispose();
        this.scene.clear();
        for (const geometry of this.geometries)
            geometry.dispose();
        for (const material of this.materials)
            material.dispose();
        for (const texture of this.textures)
            texture.dispose();
        this.geometries.clear();
        this.materials.clear();
        this.textures.clear();
        this.matCache.clear();
        this.platformGroups.clear();
        this.batches.length = 0;
        this.stageRoots.length = 0;
        this.animated.length = 0;
        this.floating.length = 0;
        this.falls.length = 0;
        this.qualityGroups.length = 0;
        this.sparks.length = 0;
        this.backShaders.length = 0;
        this.glowSprites.length = 0;
        this.dynamicPlatforms.length = 0;
        this.processSignals.length = 0;
        this.checkpointSignals.length = 0;
        this.staticSceneryBatches.length = 0;
        this.runTraces.length = 0;
        this.liftBeams.length = 0;
        this.thresholds.length = 0;
    }
}
