import * as THREE from 'three';
import { GATE_CENTERS, GESTURES } from './domain.js';
/** Gameplay-independent, authored skyline layer. All geometry is local and deterministic. */
const UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
const DISTRICT_GLASS = [
    [0x0d3045, 0x154257, 0x1b5870, 0x102a44],
    [0x211d46, 0x342a64, 0x29294e, 0x413367],
    [0x382b34, 0x513c46, 0x5e4140, 0x35344b],
    [0x103d43, 0x1d5150, 0x254b54, 0x20463f]
];
const rand = (seed) => {
    let s = seed >>> 0;
    return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return (s >>> 0) / 4294967296; };
};
function metal(color, roughness = .29) {
    return new THREE.MeshStandardMaterial({ color, metalness: .69, roughness });
}
function radiance(color, opacity = 1) {
    return new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
}
function block(parent, material, x, y, z, w, h, d) {
    const mesh = new THREE.Mesh(UNIT_BOX, material);
    mesh.position.set(x, y, z);
    mesh.scale.set(w, h, d);
    parent.add(mesh);
    return mesh;
}
function torus(parent, radius, tube, color, x, y, z) {
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(radius, tube, 8, 76), radiance(color, .72));
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
}
function sphere(parent, r, material, x, y, z) {
    const mesh = new THREE.Mesh(new THREE.IcosahedronGeometry(r, 1), material);
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
}
const dummy = new THREE.Object3D();
function staticInstances(parent, records, material) {
    if (!records.length)
        return null;
    const mesh = new THREE.InstancedMesh(UNIT_BOX, material, records.length);
    for (let i = 0; i < records.length; i++) {
        const r = records[i];
        dummy.position.set(r.x, r.y, r.z);
        dummy.scale.set(r.sx, r.sy, r.sz);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
        mesh.setColorAt(i, new THREE.Color(r.color));
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor)
        mesh.instanceColor.needsUpdate = true;
    mesh.frustumCulled = false;
    parent.add(mesh);
    return mesh;
}
export class ArtDirectedSkyline {
    root = new THREE.Group();
    detail = new THREE.Group();
    living = [];
    scratch = new THREE.Color();
    constructor(scene) {
        scene.add(this.root);
        this.root.add(this.detail);
        this.buildSilhouette();
        this.buildDistrictLandmarks();
        this.buildAtmosphere();
        this.living.forEach(item => { item.phase = item.object.rotation[item.axis]; });
    }
    buildSilhouette() {
        const rng = rand(0x75b2391);
        const structures = [];
        const crowns = [];
        const fins = [];
        const windows = [[], [], [], []];
        const antennae = [];
        // Curated shape language: narrow signal spires, stepped memory stacks,
        // broad amplifier blocks and serene glass slabs, without random cube soup.
        for (let n = 0; n < 175; n++) {
            const x = -24 + rng() * 219;
            const zone = Math.max(0, Math.min(3, Math.floor((x - 10) / 40)));
            const z = -20 - rng() * 62;
            const depthBand = (Math.abs(z) + 20) / 85;
            const far = z < -52;
            const w = (zone === 0 ? 2.5 : zone === 2 ? 4.3 : 3.2) + (rng() * (zone === 2 ? 7.6 : 5.8));
            const d = 3.2 + rng() * 7.8;
            const tall = rng() > .81;
            const h = (far ? 19 : 10) + Math.pow(rng(), .85) * (far ? 48 : 32) + (tall ? 24 : 0);
            const y = h / 2 - 12 - (far ? 2 : 0);
            const base = DISTRICT_GLASS[zone][Math.floor(rng() * 4)];
            const b = { x, y, z, w, h, d, zone, color: base };
            structures.push(b);
            if (n % 3 !== 0) {
                crowns.push({ x, y: y + h / 2 + .24, z, sx: w + .24, sy: .28, sz: d + .15, color: GESTURES[zone].color });
            }
            if (n % 5 === 0) {
                fins.push({ x: x - w * .32, y: y + h * .15, z: z + d / 2 + .08, sx: .16, sy: h * .65, sz: .19, color: GESTURES[zone].color });
            }
            if (n % 7 === 0) {
                antennae.push({ x: x + w * .12, y: y + h / 2 + 2.2, z, sx: .13, sy: 4.6, sz: .13, color: 0xa2d1e8 });
            }
            const rows = Math.min(15, Math.floor(h / 3));
            const cols = Math.min(5, Math.floor(w / 1.9));
            for (let row = 1; row <= rows; row++)
                for (let col = 0; col < cols; col++) {
                    if (rng() < .53)
                        continue;
                    const wx = x + (col - (cols - 1) / 2) * Math.min(1.8, w / (cols + 1));
                    const wy = y - h / 2 + row * h / (rows + 1);
                    const baseColor = this.scratch.set(GESTURES[zone].color).clone().lerp(new THREE.Color(rng() > .87 ? 0xffffff : 0x4b6c8b), rng() * .62);
                    const alpha = (.6 + depthBand * .2);
                    windows[zone].push({ x: wx, y: wy, z: z + d / 2 + .12, sx: .39 * alpha, sy: .18 + .12 * rng(), sz: .10, color: baseColor.getHex() });
                }
        }
        const buildings = new THREE.InstancedMesh(UNIT_BOX, new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: .63, roughness: .24 }), structures.length);
        for (let i = 0; i < structures.length; i++) {
            const b = structures[i];
            dummy.rotation.set(0, 0, 0);
            dummy.position.set(b.x, b.y, b.z);
            dummy.scale.set(b.w, b.h, b.d);
            dummy.updateMatrix();
            buildings.setMatrixAt(i, dummy.matrix);
            buildings.setColorAt(i, new THREE.Color(b.color));
        }
        buildings.instanceMatrix.needsUpdate = true;
        if (buildings.instanceColor)
            buildings.instanceColor.needsUpdate = true;
        buildings.frustumCulled = false;
        this.root.add(buildings);
        const bright = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
        staticInstances(this.root, crowns, bright);
        staticInstances(this.detail, fins, bright);
        staticInstances(this.detail, antennae, bright);
        for (let z = 0; z < 4; z++)
            staticInstances(this.root, windows[z], new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }));
        // Recessed architecture beneath the playable spine: genuinely distant scenery,
        // never a competing traversable surface.
        const rhythm = metal(0x1a2b42);
        const edge = radiance(0x579ab3, .46);
        for (let i = 0; i < 22; i++) {
            const x = -15 + i * 9.25;
            block(this.root, rhythm, x, -10, -19, 7.5, 1.0, 9.0);
            block(this.root, edge, x, -9.35, -14.45, 7.5, .12, .1);
        }
    }
    buildDistrictLandmarks() {
        const basalt = metal(0x0a1728, .24);
        const pearl = metal(0xa7d7e9, .18);
        for (let zone = 0; zone < 4; zone++) {
            const x = GATE_CENTERS[zone] + 8;
            const z = -43;
            const color = GESTURES[zone].color;
            const chroma = radiance(color, .86);
            const chapter = new THREE.Group();
            chapter.position.set(x, 0, z);
            this.root.add(chapter);
            // Civic beacon plinth unifies each district while the crown has its own grammar.
            block(chapter, basalt, 0, 4, 0, 14, 9, 13);
            block(chapter, chroma, 0, 8.7, 0, 15, .24, 14);
            for (const dx of [-6.3, 6.3]) {
                block(chapter, pearl, dx, 12, 0, .38, 19, .52);
                block(chapter, chroma, dx, 22, 0, .49, .45, .8);
            }
            if (zone === 0) {
                // NEXT TRACK: the antenna cathedral, five forward-swept signal masts.
                for (let i = -2; i <= 2; i++) {
                    const height = 45 + (2 - Math.abs(i)) * 12;
                    const stalk = block(chapter, basalt, i * 4.1, 10 + height * .5, 0, 2.0, height, 2.3);
                    stalk.rotation.z = -.045;
                    for (let step = 0; step < 7; step++) {
                        const yy = 20 + step * (height - 10) / 7;
                        block(chapter, chroma, i * 4.1 - yy * .045 + .9, yy, 1.18, 2.1, .24, .2);
                    }
                    sphere(chapter, .85, chroma, i * 4.1 - height * .045, height + 11, 0);
                }
                for (let t = 0; t < 3; t++) {
                    const ring = torus(chapter, 8 + t * 2.3, .12, color, -4, 62 + t * 5, -8);
                    ring.rotation.y = .48;
                    this.living.push({ object: ring, axis: 'z', velocity: .05, phase: t });
                }
            }
            else if (zone === 1) {
                // PREVIOUS TRACK: a hall of staggered backward echo apertures.
                for (let i = 0; i < 4; i++) {
                    const yy = 20 + i * 12;
                    block(chapter, basalt, -i * 3.6, yy, 0, 20 - i * 2.5, 7.2, 9);
                    block(chapter, chroma, -i * 3.6, yy + 3.75, 4.6, 20 - i * 2.5, .28, .18);
                }
                for (let i = 0; i < 4; i++) {
                    const ring = torus(chapter, 9 + i * 2.3, .2, color, -6, 52, -2 - i * 2.8);
                    ring.rotation.y = Math.PI * .15;
                    ring.rotation.x = i * .09;
                    this.living.push({ object: ring, axis: 'z', velocity: i % 2 ? .065 : -.065, phase: i });
                }
                sphere(chapter, 3.4, radiance(0xb5baff, .8), -6, 52, -10);
            }
            else if (zone === 2) {
                // VOLUME UP: a monumental audio-gain skyline of ascending resonators.
                for (let i = -5; i <= 5; i++) {
                    const h = 22 + (i + 5) * 4.8 + (i % 2 ? 6 : 0);
                    const x = i * 3.45;
                    block(chapter, basalt, x, 10 + h / 2, -1, 2.6, h, 3.4);
                    block(chapter, chroma, x, 10 + h, -1, 2.8, .7, 3.6);
                    for (let step = 0; step < 5; step++) {
                        const yy = 15 + step * (h - 10) / 5;
                        block(chapter, chroma, x, yy, 1.04, 1.5, .16, .12);
                    }
                }
                const crown = torus(chapter, 15, .26, color, 0, 73, -6);
                crown.rotation.y = .4;
                this.living.push({ object: crown, axis: 'x', velocity: -.025, phase: 0 });
            }
            else {
                // VOLUME DOWN: restrained, horizontal, quieting glass terraces.
                for (let i = 0; i < 4; i++) {
                    const yy = 19 + i * 13;
                    const width = 26 - i * 3.4;
                    block(chapter, basalt, 0, yy, 0, width, 3.2, 10);
                    block(chapter, chroma, 0, yy + 1.8, 5.16, width, .23, .16);
                    const arc = torus(chapter, 8.5 + i * .9, .23, color, 0, yy + 8, -2.8);
                    arc.scale.y = .5;
                    arc.rotation.y = .1;
                    this.living.push({ object: arc, axis: 'y', velocity: i % 2 ? .025 : -.025, phase: i });
                }
                sphere(chapter, 2.3, radiance(0xe5ffe2, .8), 0, 74, -4);
            }
            // Floorless side halos keep the landmark legible behind the traversable line.
            for (let j = 0; j < 3; j++) {
                const ring = torus(chapter, 18 + j * 4, .07, color, 0, 38, -11 - j * 8);
                ring.material.opacity = .12 + j * .025;
            }
        }
    }
    buildAtmosphere() {
        const hazeMats = [0x36728b, 0x7d4ca2, 0xa45a53, 0x438875];
        const rng = rand(0x419ca36);
        for (let z = 0; z < 4; z++) {
            const x = 11 + z * 43.5;
            // Graduated volume-like planes, behind architecture and never over the runner.
            for (let p = 0; p < 3; p++) {
                const mesh = new THREE.Mesh(new THREE.PlaneGeometry(54, 55), new THREE.MeshBasicMaterial({ color: hazeMats[z], transparent: true, opacity: .015 + p * .008, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
                mesh.position.set(x, 27, -66 + p * 8);
                this.detail.add(mesh);
            }
            for (let i = 0; i < 11; i++) {
                const x1 = x - 21 + rng() * 42;
                const y = 23 + rng() * 62;
                const beam = block(this.detail, radiance(GESTURES[z].color, .26), x1, y, -38 - rng() * 17, .08, 7 + rng() * 17, .08);
                beam.rotation.z = (rng() - .5) * .2;
            }
        }
        // A quiet spatial-scale witness: three curved transit trajectories deep in the city.
        for (let route = 0; route < 3; route++) {
            const pts = [];
            for (let j = 0; j <= 60; j++) {
                const x = -18 + j * 3.45;
                pts.push(new THREE.Vector3(x, 38 + route * 9 + Math.sin(j * .15 + route) * 6, -48 - route * 9));
            }
            const curve = new THREE.CatmullRomCurve3(pts);
            const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 180, .07, 5, false), radiance(GESTURES[(route + 1) % 4].color, .49));
            this.root.add(tube);
        }
    }
    update(_time, dt, reduced) {
        if (reduced)
            return;
        for (const item of this.living) {
            item.object.rotation[item.axis] += item.velocity * dt;
        }
    }
    setQuality(mode) { this.detail.visible = mode === 'high'; }
    reset() { this.living.forEach(item => { item.object.rotation[item.axis] = item.phase; }); }
}
