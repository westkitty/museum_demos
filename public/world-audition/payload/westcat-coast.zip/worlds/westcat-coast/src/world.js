/** Original procedural 2.5D art direction. The only imported runtime is a local,
 * MIT-licensed Three.js 0.185.1 build, with no network or external textures.
 */
import * as T from '../vendor/three.module.min.js';
import { PLATFORMS, CHECKPOINTS, CHAPTERS, FINISH_X, surfaceUnder, chapterFor } from './course.js';
import { createFxPool, emitFx, stepFx, fxScale, EFFECT_BUDGET } from './fx.js';

const C={ink:0x183039,forest:0x235e56,pine:0x285a55,pineLight:0x5d9274,leaf:0x77a57c,
  cedar:0x71533a,wood:0x8c6648,woodLight:0xbaa17a,cream:0xf7e5b6,orange:0xe3a06c,
  calico:0x493e3a,white:0xf5e6d2,copper:0xc97f63,moss:0x5c9572,stone:0xb4ad8c,
  gold:0xffdfa0,cloud:0xd4e8d8,shadow:0x182b42};
let seed=17411;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const between=(a,b)=>a+rnd()*(b-a);
const geoBox=new T.BoxGeometry(1,1,1),geoBall=new T.SphereGeometry(1,12,8),geoCone=new T.ConeGeometry(1,1,7),geoCylinder=new T.CylinderGeometry(1,1,1,8),geoDiamond=new T.OctahedronGeometry(1,0),geoPlane=new T.PlaneGeometry(1,1),geoTorus=new T.TorusGeometry(1,.06,4,32);
const materialCache=new Map();
// Paint once, render locally forever: quiet, authored surface language rather than a downloaded texture pack.
// Textures vary by material family, not by frame or individual mesh; InstancedMesh reuse remains intact.
const surfaceTextures=new Map(),surfaceMaterials=new Map();
function paintedSurface(kind){
  if(surfaceTextures.has(kind))return surfaceTextures.get(kind);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=256;
  const g=canvas.getContext('2d');
  const base={stucco:'#f7f0e0',slate:'#ece5dd',bark:'#eee5d2',moss:'#e7f1d9',timber:'#f0e4ca',stone:'#eee8db',water:'#dbf4e9'}[kind]||'#ffffff';
  g.fillStyle=base;g.fillRect(0,0,256,256);
  // A locally seeded illustration keeps the same source pixels on every launch.
  let n=([...'westcat:'+kind].reduce((v,c)=>(Math.imul(v,33)+c.charCodeAt(0))>>>0,9267))||1;
  const random=()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};
  const line=(x,y,xx,yy,width,color)=>{g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(x,y);g.lineTo(xx,yy);g.stroke();};
  if(kind==='slate'){
    for(let row=0;row<9;row++){
      const yy=row*30+4;
      line(0,yy,256,yy,2,'rgba(93,72,68,.27)');
      const shift=row%2?0:15;
      for(let x=shift;x<256;x+=31){line(x,yy,x-3,yy+30,1.3,'rgba(107,80,65,.30)');line(x+4,yy+5,x+20,yy+9,1,'rgba(255,255,255,.50)');}
    }
  }else if(kind==='bark'){
    for(let i=0;i<89;i++){
      const x=random()*256,y=random()*256;
      const drift=(random()-.5)*14;
      line(x,y,x+drift,y+18+random()*80,.7+random()*2.5,i%3?'rgba(77,56,49,.27)':'rgba(255,255,255,.72)');
    }
    for(let k=0;k<5;k++){const x=28+k*52;line(x,0,x-13,256,3,'rgba(102,81,70,.21)');}
  }else if(kind==='timber'){
    for(let i=0;i<70;i++){const y=random()*256,x=random()*256;line(x,y,x+24+random()*160,y+(random()-.5)*10,.55+random()*1.4,i%5?'rgba(91,67,51,.17)':'rgba(255,255,255,.60)');}
    for(let j=0;j<4;j++){const y=34+j*65;line(0,y,256,y,1.4,'rgba(88,59,43,.21)');}
  }else if(kind==='stone'){
    for(let i=0;i<20;i++){const x=random()*256,y=random()*256;line(x,y,x+9+random()*52,y-3+random()*13,.8,'rgba(82,90,74,.17)');}
    for(let i=0;i<7;i++)line(0,i*38,256,i*38,1.2,'rgba(87,77,71,.13)');
  }else if(kind==='moss'){
    for(let i=0;i<88;i++){const x=random()*256,y=random()*256;line(x,y,x+(random()-.5)*19,y-2-random()*12,1.1,i%4?'rgba(71,132,91,.28)':'rgba(255,255,255,.67)');}
  }else if(kind==='water'){
    for(let row=0;row<18;row++){
      const y=row*15+random()*7;
      for(let x=0;x<256;x+=11){
        line(x,y+Math.sin(x*.06+row*.7)*2.5,x+6+random()*18,y+Math.sin((x+18)*.06+row*.7)*2.5,1.1+random()*1.7,row%3?'rgba(37,98,116,.22)':'rgba(255,255,248,.68)');
      }
    }
  }else{
    for(let i=0;i<130;i++){
      const x=random()*256,y=random()*256,z=1+random()*2;
      g.fillStyle=i%4?'rgba(119,100,82,.10)':'rgba(255,255,255,.6)';g.fillRect(x,y,z,z);
    }
    for(let i=0;i<11;i++){const y=12+i*24;line(0,y,256,y+(random()-.5)*4,.7,'rgba(110,89,71,.10)');}
  }
  const tex=new T.CanvasTexture(canvas);tex.colorSpace=T.SRGBColorSpace;
  tex.wrapS=tex.wrapT=T.RepeatWrapping;
  tex.repeat.set(kind==='bark'?2:kind==='slate'?1.5:2,kind==='bark'?3:2);
  tex.anisotropy=2;surfaceTextures.set(kind,tex);return tex;
}
function surfaceMat(kind,color){
  const key=kind+':'+color;
  if(!surfaceMaterials.has(key))surfaceMaterials.set(key,new T.MeshStandardMaterial({
    color,map:paintedSurface(kind),flatShading:true,roughness:kind==='slate'?.76:.96,
    metalness:0,side:T.FrontSide
  }));
  return surfaceMaterials.get(key);
}
function surfaceBox(parent,kind,color,x,y,z,w,h,d=1){return make(geoBox,surfaceMat(kind,color),parent,[x,y,z],[w,h,d]);}
function surfaceCylinder(parent,kind,color,x,y,z,sx,h,sz=sx){return make(geoCylinder,surfaceMat(kind,color),parent,[x,y,z],[sx,h,sz]);}
function mat(color,params={}){
  const key=[color,params.emissive||0,params.transparent||false,params.opacity??1,params.metalness||0].join(':');
  if(!materialCache.has(key))materialCache.set(key,new T.MeshStandardMaterial({color,flatShading:true,roughness:0.87,metalness:params.metalness||0,emissive:params.emissive||0,emissiveIntensity:params.emissive?0.7:0,transparent:params.transparent||false,opacity:params.opacity??1,depthWrite:!(params.transparent||false)}));
  return materialCache.get(key);
}
function make(geo,m,parent,pos,size,rotationZ=0){const o=new T.Mesh(geo,m);o.position.set(...pos);if(size)o.scale.set(...size);if(rotationZ)o.rotation.z=rotationZ;parent.add(o);return o;}
const box=(parent,color,x,y,z,w,h,d=1)=>make(geoBox,mat(color),parent,[x,y,z],[w,h,d]);
const ball=(parent,color,x,y,z,sx,sy=sx,sz=sx)=>make(geoBall,mat(color),parent,[x,y,z],[sx,sy,sz]);
const cylinder=(parent,color,x,y,z,sx,h,sz=sx)=>make(geoCylinder,mat(color),parent,[x,y,z],[sx,h,sz]);
function tapered(parent,color,x,y,z,base,height,depth=1){const obj=make(geoCone,mat(color),parent,[x,y,z],[base,height,base*depth]);return obj;}
function beam(parent,color,from,to,width=.1,depth=.12){const a=new T.Vector3(...from),b=new T.Vector3(...to),mid=a.clone().add(b).multiplyScalar(.5),delta=b.clone().sub(a);const mesh=make(geoBox,mat(color),parent,mid.toArray(),[width,delta.length(),depth]);mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return mesh;}
function lightOrb(parent,x,y,z,scale=1,color=C.gold){return make(geoDiamond,mat(color,{emissive:color}),parent,[x,y,z],[.18*scale,.23*scale,.18*scale]);}
function addBuilding(parent,x,z,w,h,paletteIndex,detail){
  const palettes=[[0xe5c6a1,0x9c4d4f],[0x91b8b5,0x4e6b74],[0xf0cfb7,0xa36561],[0xc4c3a5,0x7f6c65],[0xdba986,0x86576d]];
  const [wall,roof]=palettes[paletteIndex%palettes.length];
  surfaceBox(parent,'stucco',wall,x+w/2,h/2-0.8,z,w,h,2.0);
  // steep folded roofs and cornices
  const peak=make(geoCone,surfaceMat('slate',roof),parent,[x+w/2,h-0.45,z],[w*.74,1.9,w*.74*.55]);peak.rotation.y=Math.PI/4;
  box(parent,0x5f5051,x+w/2,h-1.05,z+1.12,w+0.28,.16,.18);
  const count=Math.max(2,Math.floor(w/1.45));
  for(let i=0;i<count;i++){
    const xx=x+.55+i*(w-1.1)/(count-1);
    for(let j=0;j<Math.min(3,Math.floor((h-1)/1.75));j++){
      const yy=0.15+j*1.65;
      box(parent,0x284658,xx,yy+0.82,z+1.05,.45,.75,.08);
      box(parent,0xe7c691,xx,yy+.43,z+1.105,.51,.09,.09);
      if(detail&&j===0)box(parent,0xf1e2aa,xx,yy+.92,z+1.118,.25,.1,.06);
    }
  }
    if(detail){
      cylinder(parent,0xb47a60,x+w*.76,h+.22,z-.18,.16,1.25,.16);
      ball(parent,0xeddbbf,x+w*.76,h+1.06,z-.18,.24,.10,.2);
      // Hand-built fascia, two layers of roof shingles and brass finials.
      for(let j=0;j<Math.floor(w/.43);j++){
        const tx=x+.2+j*.43;
        box(parent,j%2?0xb97567:0x8b5357,tx,h-.57,z+1.00,.37,.11,.25);
      }
      for(const dx of [-w*.39,w*.39])ball(parent,0xe4bc7f,x+w/2+dx,h-.88,z+1.16,.095,.095,.09);
    }
}
function addTree(parent,x,y,z,scale,kind='pine',detail=true){
  if(kind==='cedar'){
    const r=scale*.44;
    surfaceCylinder(parent,'bark',C.cedar,x,y+5.5*scale,z,r,11*scale,r);
    for(let k=0;k<6;k++){
      const yy=y+(5.8+k*1.75)*scale;
      ball(parent,k%2?0x3d7665:0x4b886c,x+Math.sin(k*1.5)*.28*scale,yy,z,(2.5-k*.15)*scale,1.5*scale,1.45*scale);
    }
    if(detail){for(let k=0;k<5;k++)box(parent,0xb58e65,x+Math.sin(k)*.22*scale,y+(2+k*1.4)*scale,z+r*.85,.06,1.2*scale,.04);}
  }else{
    surfaceCylinder(parent,'bark',0x735641,x,y+1.5*scale,z,.19*scale,3*scale,.19*scale);
    const colors=[C.pine,0x346c5b,0x54836b];
    for(let k=0;k<3;k++)tapered(parent,colors[k],x,y+(2.5+k*1.07)*scale,z,(1.35-k*.18)*scale,3.4*scale,0.85);
    if(detail)ball(parent,0x90bd88,x+.5*scale,y+2.4*scale,z+.24*scale,.24*scale,.11*scale,.12*scale);
  }
}
function addFern(parent,x,y,z,s=1){
  const stem=mat(0x54846b);
  beam(parent,0x69a783,[x,y,z],[x,y+.65*s,z],.05*s,.05*s);
  for(let k=0;k<4;k++)for(const sign of [-1,1]){
    const a=(k+1)/5;
    const leaf=make(geoCone,stem,parent,[x+sign*(.22+.13*k)*s,y+(.6-.1*k)*s,z],[.17*s,.48*s,.15*s]);leaf.rotation.z=sign*.91;
  }
}
function addCloud(parent,x,y,z,scale,color=C.cloud){
  const m=mat(color,{transparent:true,opacity:.87});
  for(let i=0;i<4;i++)make(geoBall,m,parent,[x+(i-1.5)*1.4*scale,y+Math.sin(i*2)*.25*scale,z],[1.55*scale,(.48+i%2*.16)*scale,.85*scale]);
}
/** Light-rendered drawing, never a texture request or remote dependency. */
function softTexture(){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=128;
  const g=canvas.getContext('2d'),grad=g.createRadialGradient(64,64,2,64,64,64);
  grad.addColorStop(0,'rgba(255,255,255,.96)');grad.addColorStop(.2,'rgba(255,255,255,.47)');grad.addColorStop(.53,'rgba(255,255,255,.10)');grad.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=grad;g.fillRect(0,0,128,128);const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;return texture;
}
function glow(group,texture,x,y,z,sx,sy,color=0xffeac4,opacity=.5){
  const material=new T.SpriteMaterial({map:texture,color,opacity,transparent:true,blending:T.AdditiveBlending,depthWrite:false,fog:false});
  const sprite=new T.Sprite(material);sprite.position.set(x,y,z);sprite.scale.set(sx,sy,1);group.add(sprite);return sprite;
}
function distantRidge(group,z,color,phase,height,base=-12){
  const shape=new T.Shape();shape.moveTo(-38,base);
  for(let x=-38;x<=213;x+=3.8){
    const mountain=.58*Math.sin(x*.108+phase)+.3*Math.sin(x*.23+phase*2)+.13*Math.sin(x*.61+phase);
    shape.lineTo(x,base+height*(.52+Math.max(-.1,mountain)));
  }
  shape.lineTo(213,base);shape.closePath();make(new T.ShapeGeometry(shape),new T.MeshBasicMaterial({color,depthWrite:true,fog:true}),group,[0,0,z]);
}

/* Four authored, translucent horizon paintings. These are original local
   illustrations rather than external sprites; they never own collisions.
   Distant planes gain natural 2.5D parallax from the existing perspective camera. */
function chapterPainting(chapter){
  // Painted at three-quarter resolution; distant layers need composition, not 4K texels.
  const canvas=document.createElement('canvas');canvas.width=768;canvas.height=384;
  const g=canvas.getContext('2d');g.scale(.75,.75);const W=1024,H=512;
  const schemes={
    duncan:{sky:['#f5ca9d','#a9c5b2'],ridge:['#96aa9e','#617f83','#3a626b'],ink:'#29485a',glow:'#fff0bd'},
    outskirts:{sky:['#d2d8ab','#72a7a0'],ridge:['#779e81','#426e65','#294e52'],ink:'#1b4b4b',glow:'#ffefb6'},
    cedar:{sky:['#d5cda0','#70989a'],ridge:['#638d76','#38685c','#23444b'],ink:'#284f48',glow:'#f8dc9b'},
    sentinel:{sky:['#e7b08c','#8e9bad'],ridge:['#859fae','#677b9b','#475d80'],ink:'#33405e',glow:'#ffe1ad'},
  };
  const c=schemes[chapter];let n=([...chapter].reduce((v,ch)=>Math.imul(v,33)+ch.charCodeAt(0),9472))>>>0;
  const r=()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};
  const sky=g.createLinearGradient(0,0,0,H);sky.addColorStop(0,c.sky[0]);sky.addColorStop(1,c.sky[1]);
  g.globalAlpha=.74;g.fillStyle=sky;g.fillRect(0,0,W,H);g.globalAlpha=1;
  const halo=g.createRadialGradient(730,125,10,730,125,260);
  halo.addColorStop(0,c.glow+'d8');halo.addColorStop(.25,c.glow+'42');halo.addColorStop(1,c.glow+'00');
  g.fillStyle=halo;g.fillRect(470,0,550,420);
  // Layered, deliberately shaped landscape: consistent horizons, different terrain characters.
  for(let layer=0;layer<3;layer++){
    const baseline=315+layer*47;g.beginPath();g.moveTo(0,H);g.lineTo(0,baseline);
    for(let x=0;x<=W;x+=16){
      const mountain=(Math.sin(x*.011+layer*1.83+1.2)*31+Math.sin(x*.027+layer*2.2)*17+Math.sin(x*.068+layer)*7);
      const v=baseline+mountain*(chapter==='sentinel'?.41:chapter==='cedar'?.9:.64);
      g.lineTo(x,v);
    }
    g.lineTo(W,H);g.closePath();g.fillStyle=c.ridge[layer];g.globalAlpha=layer===0?.35:layer===1?.57:.83;g.fill();
  }
  g.globalAlpha=1;
  if(chapter==='duncan'){
    // Wholly invented coastal streetscape, windows, and pitched roofs. No identifiable landmarks.
    for(let i=0;i<22;i++){
      const x=i*49-12,y=331+(i%5)*13;const h=46+(i%4)*16,w=38+(i%3)*9;
      g.fillStyle=i%3?'#315565':'#486c75';g.fillRect(x,y-h,w,h+55);
      g.fillStyle=i%2?'#a46f70':'#cc9477';g.beginPath();g.moveTo(x-4,y-h);g.lineTo(x+w/2,y-h-18);g.lineTo(x+w+4,y-h);g.closePath();g.fill();
      g.fillStyle=i%3?'#f2d8a3':'#c6e8d1';for(let j=0;j<3;j++)for(let k=0;k<2;k++)g.fillRect(x+7+j*11,y-h+14+k*20,4,7);
    }
    g.lineWidth=2;g.strokeStyle='rgba(255,237,188,.48)';g.beginPath();g.moveTo(0,351);
    for(let x=0;x<W;x+=26)g.lineTo(x,352+Math.sin(x*.037)*3);g.stroke();
  }else if(chapter==='outskirts'){
    for(let i=0;i<58;i++){
      const x=i*20+(r()-.5)*7,top=245+r()*85,stem=H-top;
      g.fillStyle=i%3?'#2e685b':'#3d7966';g.fillRect(x-3,top+20,6,stem);
      for(let j=0;j<3;j++){const y=top+j*24,span=14+(3-j)*10;g.beginPath();g.moveTo(x,y-20);g.lineTo(x-span,y+32);g.lineTo(x+span,y+32);g.closePath();g.fill();}
    }
    g.lineWidth=2;g.strokeStyle='rgba(224,250,210,.38)';
    for(let i=0;i<13;i++){const x=20+i*83,y=415+(i%3)*13;g.beginPath();g.moveTo(x,y);g.lineTo(x+22,y-16);g.lineTo(x+43,y+2);g.stroke();}
  }else if(chapter==='cedar'){
    for(let i=0;i<12;i++){
      const x=i*99-32,h=185+(i%4)*35;
      g.fillStyle=i%2?'#355e57':'#486f63';g.fillRect(x,215-h*.26,17+i%3*6,H);
      g.strokeStyle='rgba(210,204,156,.33)';g.lineWidth=2;
      for(let j=0;j<5;j++){const by=205+j*46;g.beginPath();g.moveTo(x+10,by);g.lineTo(x+(i%2?57:-46),by-34);g.stroke();}
      g.fillStyle='#2b6c5c';for(let j=0;j<4;j++){g.beginPath();g.arc(x+(i%2?37:-22),171+j*36,27+j%2*9,0,Math.PI*2);g.fill();}
    }
    g.lineWidth=1;g.strokeStyle='rgba(255,233,184,.25)';for(let i=0;i<21;i++){const x=i*51+15;g.beginPath();g.moveTo(x,10);g.lineTo(x-19,420);g.stroke();}
  }else{
    // A cloud sea and brass horizon, not a second owl or another obstacle.
    const bank=g.createLinearGradient(0,255,0,H);bank.addColorStop(0,'rgba(255,241,213,0)');bank.addColorStop(.55,'rgba(250,229,216,.55)');bank.addColorStop(1,'rgba(225,234,233,.79)');
    g.fillStyle=bank;g.fillRect(0,250,W,H-250);
    g.fillStyle='rgba(243,229,213,.43)';for(let i=0;i<27;i++){
      g.beginPath();g.arc(i*42-12,380+(i%4)*16,32+(i%5)*9,0,Math.PI*2);g.fill();
    }
    g.strokeStyle='rgba(253,227,173,.52)';g.lineWidth=2;
    for(let i=0;i<11;i++){const x=14+i*102;g.beginPath();g.moveTo(x,410);g.lineTo(x+46,405);g.stroke();}
  }
  // Pinprick luminance, not noisy repeated pixels: sparse, deterministic brushwork.
  g.globalAlpha=.52;for(let i=0;i<90;i++){
    const x=r()*W,y=45+r()*320;
    g.fillStyle=i%4?c.glow:'#f6f3e4';g.fillRect(x,y,i%5===0?2:.8,i%5===0?2:.8);
  }
  g.globalAlpha=1;
  // Feathered edges avoid a hard seam at chapter boundaries.
  g.globalCompositeOperation='destination-in';const mask=g.createLinearGradient(0,0,W,0);
  mask.addColorStop(0,'rgba(255,255,255,0)');mask.addColorStop(.15,'rgba(255,255,255,.88)');
  mask.addColorStop(.85,'rgba(255,255,255,.88)');mask.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=mask;g.fillRect(0,0,W,H);g.globalCompositeOperation='source-over';
  const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
  texture.anisotropy=2;texture.generateMipmaps=true;return texture;
}
function installChapterPaintings(parent){
  const stations=[['duncan',17.8,8.9,-30],['outskirts',53.5,9.7,-30.5],['cedar',86.4,13.2,-31],['sentinel',128.0,14.0,-32]];
  for(const [name,x,y,z] of stations){
    const map=chapterPainting(name);const material=new T.MeshBasicMaterial({map,transparent:true,depthWrite:false,opacity:.74,side:T.DoubleSide,fog:false});
    const plane=make(geoPlane,material,parent,[x,y,z],[72,35,1]);plane.name='CHAPTER_PAINTING_'+name.toUpperCase();
  }
}
function addFineWorldDetails(scenery,details,wind){
  // Suspended fabric flags use wind groups rather than collision or timer systems.
  const flagShape=new T.Shape();flagShape.moveTo(0,0);flagShape.lineTo(.39,-.08);flagShape.lineTo(.12,-.70);flagShape.closePath();
  const flagGeometry=new T.ShapeGeometry(flagShape);
  const flagColors=[0xe4ae75,0x7bad9a,0xc47c73,0xefe0ad];
  for(let i=0;i<10;i++){
    const g=new T.Group();wind.add(g);g.position.set(3.3+i*3.05,5.0-(i%3)*.15,-1.4);g.userData.wind=i*.56;
    const flag=make(flagGeometry,new T.MeshBasicMaterial({color:flagColors[i%4],side:T.DoubleSide}),g,[0,0,0]);flag.name='DUNCAN_WIND_FLAG';
    make(geoBall,mat(0xf6dbad),g,[.04,.03,0],[.055,.06,.05]);
  }
  // Amber lichen grip stitches echo the actual climbable trunks, but stay decorative.
  for(const [x,top] of [[80.75,9.6],[89.95,11.0]]){
    for(let i=0;i<8;i++){
      const y=top-.42-i*.36;
      box(details,i%3?0xe4c783:0x8bc7a6,x+.36,y,1.01,.15,.045,.05);
    }
  }
  // High causeway: non-colliding suspension loops and warm directional markers.
  const beams=[[108,114],[118,124],[127.5,133],[137,143]];
  for(const [x0,x1] of beams){
    const from=new T.Vector3(x0,15.35,-2.55),to=new T.Vector3(x1,15.55,-2.55);
    const curve=new T.CatmullRomCurve3([from,new T.Vector3(x0+1.2,14.25,-2.55),new T.Vector3(x1-1.2,14.1,-2.55),to]);
    make(new T.TubeGeometry(curve,16,.038,4,false),mat(0xb89e7d),scenery,[0,0,0]);
    for(const x of [x0,x1]){
      box(scenery,0xd1aa78,x,15.15,-2.6,.09,.57,.09);
      make(geoDiamond,mat(0xffddab,{emissive:0xe9b97b}),scenery,[x,14.66,-2.35],[.10,.15,.1]);
    }
  }
}

function painterlySign(parent,x,y,z,text,accent='#d9ac75'){
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=160;
  const g=canvas.getContext('2d');g.fillStyle='#28434a';g.fillRect(0,0,512,160);
  g.strokeStyle=accent;g.lineWidth=9;g.strokeRect(11,11,490,138);
  g.strokeStyle='rgba(251,238,200,.25)';g.lineWidth=2;g.strokeRect(25,24,462,112);
  g.textAlign='center';g.textBaseline='middle';g.font='bold 63px Georgia, serif';g.fillStyle='#f8e7bf';g.fillText(text,256,81);
  const tex=new T.CanvasTexture(canvas);tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=2;
  make(geoPlane,new T.MeshBasicMaterial({map:tex,side:T.DoubleSide,fog:false}),parent,[x,y,z],[2.7,.82,1]);
}
function architrave(parent,x,y,z,w=3){
  box(parent,0x6e4c47,x,y,z,w,.16,.18);box(parent,0xdab083,x,y+.125,z,w+.16,.09,.13);
  for(const dx of [-w*.42,w*.42])box(parent,0xf0cda1,x+dx,y-.19,z,.16,.42,.1);
}
function awning(parent,x,y,z,width=2.2){
  box(parent,0x244d54,x,y,z,width,.13,.95);
  for(let j=0;j<7;j++){
    const px=x-width*.43+j*width*.145;
    box(parent,j%2?0xe5b486:0xd97766,px,y+.06,z+.49,width*.145,.07,.12);
  }
  box(parent,0xf2d3a2,x,y-.18,z+.48,width,.24,.1);
}
function foliageFrond(parent,x,y,z,s,color=0x74b99c){
  beam(parent,0x4b7d64,[x,y,z],[x+.1*s,y+.95*s,z],.045*s,.04*s);
  for(let i=0;i<5;i++){const yy=y+(i+.7)*.16*s,span=(.44-i*.055)*s;
    const l=make(geoCone,mat(i%2?color:0x4c967a),parent,[x-span*.55,yy,z],[span*.58,.30*s,.11*s]);l.rotation.z=-1.12;
    const r=make(geoCone,mat(color),parent,[x+span*.55,yy+.03*s,z],[span*.58,.30*s,.11*s]);r.rotation.z=1.12;
  }
}
function extraTownArt(world,details){
  const shopColors=[0xe2ba92,0xe9c8ab,0xb6cfcb,0xb3b8a6];
  for(let i=0;i<8;i++){
    const x=2.2+i*4.25,z=-4.1,w=3.45,h=4.5+(i%3)*.62;
    surfaceBox(world,'stucco',shopColors[i%4],x,h/2-.75,z,w,h,1.55);
    box(world,0x5a4848,x,h-.55,z+1.0,w+.26,.23,.25);
    box(world,0xc47f63,x,h-.35,z,w+.47,.36,1.9);
    for(let j=0;j<3;j++){
      const xx=x-1.05+j*1.05;
      box(world,0x1f3e50,xx,1.0,z+.82,.70,1.18,.10);
      box(world,(i+j)%3?0xf8c995:0x9fced0,xx,1.0,z+.885,.46,.96,.028);
      architrave(world,xx,1.78,z+.94,.78);
      box(world,0x35535a,xx,.33,z+.91,.92,.09,.1);
    }
    awning(world,x,2.52,z+.9,3.18);
    for(let j=0;j<5;j++){
      const tx=x-1.42+j*.71;
      box(details,j%2?0xa46458:0xb87661,tx,h-.1,z+.65,.62,.035,.75);
    }
    if(i%3===0)painterlySign(world,x,3.45,z+1.1,['HARBOR','PASSAGE','COAST'][Math.floor(i/3)]);
  }
  // Amber street lanterns, with physical stands but no expensive per-lamp dynamic lights.
  for(let x=1.8;x<36;x+=5.65){
    cylinder(world,0x394f50,x,2.14,1.82,.052,2.25,.052);
    box(world,0x314950,x,3.32,1.82,.32,.09,.23);
    box(world,0xe9d8a1,x,3.14,1.89,.24,.28,.21);
    box(world,0x3a4748,x,2.98,1.88,.32,.055,.28);
  }
}
function skylineWires(group){
  // WestCat Goes East's overhead town wires return as background illustration, not collision.
  const poles=[2.8,12,20.6,31.9];
  for(let i=0;i<poles.length-1;i++){
    const from=poles[i]+.42,to=poles[i+1]+.42;
    const curve=new T.CatmullRomCurve3([
      new T.Vector3(from,5.25,-1.38),new T.Vector3(from+(to-from)*.28,4.57,-1.39),
      new T.Vector3(from+(to-from)*.70,4.58,-1.39),new T.Vector3(to,5.25,-1.38)]);
    make(new T.TubeGeometry(curve,24,.026,5,false),mat(0x344d55),group,[0,0,0]);
    for(let j=1;j<=3;j++){
      const t=j/4,pos=curve.getPoint(t);
      make(geoDiamond,mat(0xe1be82,{emissive:0xe8bd7e}),group,[pos.x,pos.y-.12,pos.z+.10],[.08,.11,.07]);
    }
  }
}
function woodlandArt(world,details,animated){
  for(let i=0;i<67;i++){
    const x=37.3+i*.99+(rnd()-.5)*.4;
    const p=PLATFORMS.find(p=>p.kind==='moss'&&x>=p.x+.2&&x<=p.x+p.w-.2);
    if(!p)continue;
    if(i%4===0)foliageFrond(details,x,p.top-.03,1.02,between(.4,.85));
    if(i%6===1){
      cylinder(details,0xeed9b1,x,p.top+.15,1.13,.05,.25,.06);
      ball(details,i%2?0xe3b87b:0xd58d74,x,p.top+.3,1.13,.22,.115,.22);
      for(const dx of [-.08,.06])ball(details,0xfde9c4,x+dx,p.top+.34,1.24,.031,.029,.025);
    }
  }
  for(let i=0;i<18;i++){
    const x=70+i*1.74,z=-5.8-(i%4)*.9,low=-3.2;
    surfaceCylinder(world,'bark',0x685141,x,low+8.3,z,.48,17,.48);
    for(let k=0;k<7;k++){
      const y=low+4.0+k*2.16;
      const b=beam(world,k%2?0x5e7c5b:0x51755f,[x,y,z],[x+(k%2?2.1:-2.2),y+.53,z],.28,.3);
      ball(world,k%3?0x447969:0x5a9678,x+(k%2?1.8:-1.8),y+.5,z,(2.0-k*.08),.52,1.25);
    }
    if(i%3===0){for(let k=0;k<6;k++)box(details,0xa78868,x+.44,low+k*2.4+.5,z+.1,.05,1.7,.06);}
  }
  // Foreground arches suggest scale, but remain behind the playable plane.
  for(let i=0;i<10;i++){
    const x=40+i*6.0;const p=PLATFORMS.find(p=>x>=p.x&&x<p.x+p.w&&p.kind!=='trunk');
    if(!p)continue;
    const g=new T.Group();g.position.set(x,p.top,-1.0);animated.add(g);
    foliageFrond(g,-.40,0,0,1.1,0x78a98c);
    foliageFrond(g,.40,0,.07,.76,0x70a78b);
    g.userData.wind=i*.6;
  }
}
function cathedralCedars(world,details){
  for(const [x,s] of [[72.5,1.25],[82.4,1.48],[92.6,1.55],[102.2,1.2]]){
    // A continuous column and large branch plates read like a lofty green cathedral.
    surfaceCylinder(world,'bark',0x5c4737,x,6.7,-6.8,.76*s,23*s,.76*s);
    cylinder(world,0x947253,x+.19*s,6.7,-6.06,.095*s,19*s,.09*s);
    for(let k=0;k<8;k++){
      const y=1+k*2.8*s,span=(4.5-k*.25)*s;
      beam(world,0x71583f,[x,y,-6.8],[x+span*(k%2?1:-1),y+1.05*s,-6.8],.34*s,.33*s);
      ball(world,k%2?0x2b6a5c:0x3d7e68,x+span*(k%2?.7:-.7),y+1.1*s,-6.9,span*.50,.78*s,1.48*s);
    }
    for(let i=0;i<6;i++)box(details,0xb69164,x-.38*s,1.5+i*2.4,-6.1,.055,1.2*s,.045);
  }
}
function trestleDetails(world,details){
  const pcts=PLATFORMS.filter(p=>p.kind==='trestle');
  for(const p of pcts){
    // Exposed staggered timber sleepers, pale caps and repeating structural joints.
    for(let x=p.x+.2;x<p.x+p.w-.08;x+=1.16){
      box(world,0x392f2d,x,p.top-.35,-.6,.2,.65,2.7);
      box(details,0xd9bd8b,x,p.top+.05,1.51,.47,.055,.36);
      for(const s of [-1,1])box(details,0xecd4a0,x+s*.11,p.top+.063,1.72,.045,.022,.05);
    }
    for(let x=p.x+.4;x<p.x+p.w-.2;x+=3.2){
      cylinder(world,0x574639,x,p.top+1.05,-1.56,.12,2.4,.13);
      ball(world,0xc9a477,x,p.top+2.2,-1.56,.14,.16,.14);
      beam(world,0x806049,[x,p.top+1.93,-1.56],[x+2.0,p.top+1.93,-1.56],.085,.08);
    }
  }
  for(let i=0;i<15;i++){
    const x=106+i*3.2,y=5.9+Math.sin(i*.8)*.7;
    ball(details,i%2?0xdbe9df:0xf2e9d4,x,y,-5.0,3.15,.72,2.2);
    ball(details,0x9fc9c6,x+.5,y-.5,-5.1,2.3,.48,1.7);
  }
}
/** Large, sparse, hand-composed landmarks establish chapter identity at gameplay scale. */
function addChapterLandmarks(world,details,glows,softMap){
  // Duncan: a friendly civic clocktower and copper cupola, wholly original architecture.
  const x=25.7,z=-10.3;
  surfaceBox(world,'stucco',0xd8c4ab,x,4.1,z,3.8,11.2,3.15);
  surfaceBox(world,'stone',0xe5d2b0,x,9.65,z+1.65,4.15,.55,3.6);
  const cap=make(geoCone,surfaceMat('slate',0x986765),world,[x,11.1,z],[2.95,3.0,2.95]);cap.rotation.y=Math.PI/4;
  surfaceCylinder(world,'timber',0x8b6a52,x,12.8,z,.16,1.1,.16);
  ball(world,0xf2d3a1,x,13.45,z,.28,.28,.28);
  // A clock face is decorative original geometry; no logo, crest, or local cultural art.
  const face=make(new T.CylinderGeometry(1.15,1.15,.12,32),mat(0xffe6bb),world,[x,7.45,z+1.70],[1,1,1]);face.rotation.x=Math.PI/2;
  const dial=make(geoTorus,mat(0x6a5149),world,[x,7.45,z+1.79],[1.02,1.02,.68]);
  dial.rotation.z=Math.PI/6;
  for(let i=0;i<12;i++){
    const a=i*Math.PI/6;
    box(world,0x684f49,x+Math.sin(a)*.83,7.45+Math.cos(a)*.83,z+1.85,.07,.16,.035);
  }
  beam(world,0x6a5149,[x,7.45,z+1.86],[x+.43,7.98,z+1.86],.06,.04);
  beam(world,0x6a5149,[x,7.45,z+1.88],[x-.24,6.95,z+1.88],.055,.04);
  glow(glows,softMap,x,10.8,z+2.5,6,4,0xffdaaa,.20);

  // Forest: naturally interlaced bridge of boughs, not another obstacle or wall.
  const gx=54.8,gy=4.0,gz=-7.7;
  for(const sx of [-1,1]){
    surfaceCylinder(world,'bark',0x665541,gx+sx*3.5,gy+4.0,gz,.37,9.8,.40);
    beam(world,0x82684a,[gx+sx*3.55,gy+7.7,gz],[gx+sx*.54,gy+10.25,gz],.62,.50);
    for(let k=0;k<4;k++)ball(world,k%2?0x3d8c72:0x529b7f,gx+sx*(2.5-k*.53),gy+8.4+k*.48,gz,1.5,.58,.8);
  }
  glow(glows,softMap,gx,gy+8.3,gz+1.4,8.6,8.5,0xf1e6b4,.22);

  // Cedar climb: a vast layered crown above the optional wall route.
  const cx=89.6,cz=-9.2;
  for(let k=0;k<7;k++){
    const yy=16.3+k*.92,span=8-k*.6;
    beam(world,0x614e3d,[cx,yy-1.8,cz],[cx+span*(k%2?-1:1),yy,cz],.29,.32);
    for(const side of [-1,1])ball(world,k%2?0x427e6b:0x296956,cx+side*span*.64,yy,cz-.3,span*.56,.8,.95);
  }
  glow(glows,softMap,cx,20.4,cz+1,13,7.8,0xffe9b0,.12);

  // Causeway: one ceremonial brass signal beacon above the finish approach.
  const bx=143,bz=-7.5;
  for(const sx of [-1,1]){
    beam(world,0x866749,[bx+sx*2,9.4,bz],[bx+sx*.55,19.3,bz],.32,.33);
    beam(world,0xc69a66,[bx+sx*.55,19.3,bz],[bx+sx*2.7,20.8,bz],.12,.11);
  }
  make(geoDiamond,mat(0xffd798,{emissive:0xffca85}),world,[bx,19.8,bz],[.65,1.2,.63]);
  make(geoTorus,mat(0xecd3a0,{emissive:0x9f8e7c}),world,[bx,19.8,bz],[2.5,2.75,.22]);
  glow(glows,softMap,bx,19.8,bz+1,13,12,0xffdba8,.30);
}
function atmosphericShafts(group){
  const materials=[new T.MeshBasicMaterial({color:0xffe7b4,transparent:true,opacity:.085,side:T.DoubleSide,depthWrite:false,blending:T.AdditiveBlending,fog:false}),
    new T.MeshBasicMaterial({color:0xc2f1df,transparent:true,opacity:.09,side:T.DoubleSide,depthWrite:false,blending:T.AdditiveBlending,fog:false})];
  for(const [chapter,starts,count,h] of [[0,[3,11,23,32],4,8],[1,[40,47,55,63],4,12],[2,[74,83,94,99],4,17],[3,[110,122,135,146],4,13]]){
    for(const [i,x] of starts.entries()){
      const y=chapter===2?22:chapter===3?18:chapter===1?13:10;
      const wedge=new T.Shape();wedge.moveTo(-.27,0);wedge.lineTo(.28,0);wedge.lineTo(3.2+(i%2)*1.4,-h);wedge.lineTo(-1.5,-h);wedge.closePath();
      const mesh=new T.Mesh(new T.ShapeGeometry(wedge),materials[chapter===1||chapter===2?1:0]);mesh.position.set(x,y,chapter===0?-6.4:chapter===3?-5.8:-7.0);
      group.add(mesh);
    }
  }
}
/** Low-contrast feathered echoes give the owl scale without occluding the play plane. */
function buildOwlEchoes(parent){
  const echoes=[];
  for(let i=0;i<3;i++){
    const g=new T.Group();parent.add(g);
    const material=new T.MeshBasicMaterial({color:i===0?0x526075:0x35465c,transparent:true,opacity:.21-i*.045,depthWrite:false,fog:false});
    make(geoBall,material,g,[0,0,0],[1.65,1.70,.5]);
    for(const sign of [-1,1]){
      const wing=make(geoBall,material,g,[sign*2.2,.4,0],[2.1,.42,.22]);wing.rotation.z=sign*.10;
    }
    echoes.push(g);
  }
  return echoes;
}

/** Combine identical static material/geometry calls without touching moving groups. */
function batchStatic(group,allowTransparent=false){
  const buckets=new Map();
  for(const child of group.children){
    if(!child.isMesh||child.isInstancedMesh||(!allowTransparent&&child.material.transparent))continue;
    // Chunk spatially so Three.js can frustum-cull each repeated geometry set.
    const chunk=Math.floor(child.position.x/24);
    const key=`${child.geometry.uuid}:${child.material.uuid}:${chunk}`;
    if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(child);
  }
  let saved=0;
  for(const list of buckets.values()){
    if(list.length<4)continue;
    const first=list[0],im=new T.InstancedMesh(first.geometry,first.material,list.length);
    im.frustumCulled=true;im.name='STATIC_INSTANCE_BATCH';
    for(let i=0;i<list.length;i++){const m=list[i];m.updateMatrix();im.setMatrixAt(i,m.matrix);group.remove(m);}
    im.instanceMatrix.needsUpdate=true;im.computeBoundingSphere();group.add(im);saved+=list.length-1;
  }
  return saved;
}

function townDetails(world,near){
  const pal=[C.cream,0xbac5ad,C.copper,0x9bbeb0];
  for(let i=0;i<10;i++){const x=-3+i*4.65,w=between(2.2,4.0),h=between(5,8.3),z=-8.0-between(0,4);addBuilding(world,x,z,w,h,i,near);}
  for(const x of [2.8,12,20.6,31.9]){
    cylinder(world,C.wood,x,3.25,-1.6,.10,4.5,.10);
    box(world,C.wood,x,5.35,-1.5,.85,.11,.14);
    lightOrb(world,x+.42,5.23,-1.35,.58);
  }
  for(let k=0;k<9;k++){
    const x=1.2+k*4.4;
    if(x<35){const m=mat(k%2?pal[1]:pal[3]);const awning=make(geoBox,m,world,[x,1.6,-2.85],[2.4,.14,1.3],k%2?.08:-.06);awning.rotation.x=.06;}
  }
  // Rooftop weather vanes, fabric flags, and clock-like medallions: no local cultural art.
  for(let i=0;i<6;i++){const x=4.0+i*5.3;beam(world,C.gold,[x,6.5,-3],[x,7.9,-3],.05,.05);box(world,C.copper,x+.32,7.52,-3,.7,.23,.05);}
}
function forests(world,detail){
  for(let i=0;i<102;i++){
    const x=33+i*1.47+(rnd()-.5)*1.7;
    const z=-14-(i%4)*3-between(0,5);const floor=-5.8+Math.sin(i*.16)*1.6;
    addTree(i%3?world:detail,x,floor,z,between(.74,1.45),'pine',false);
  }
  for(let i=0;i<46;i++){
    const x=37+rnd()*63,z=-5-between(0,4),base=-4+rnd()*2.4;
    addTree(world,x,base,z,between(.85,1.9),'pine',i%3===0);
  }
  for(let i=0;i<23;i++){
    const x=37+rnd()*68,z=-.8-between(0,2);
    const platform=PLATFORMS.find(p=>x>=p.x&&x<p.x+p.w&&p.kind!=='trunk');
    if(platform)addFern(detail,x,platform.top,z,between(.45,1));
  }
  for(const [x,s] of [[67,1.2],[73,1.48],[79,1.38],[86,1.7],[94,1.56],[101,1.3]]){
    addTree(world,x,-4.3,-8,1.75*s,'cedar',true);
    ball(world,0x1e605c,x,-1.8,-5,2.5*s,1.1,1.65);
  }
}
function platformVisual(world,details){
  for(const p of PLATFORMS){
    const mid=p.x+p.w/2,base=p.top-p.thickness/2;
    if(p.kind==='trunk'){
      surfaceBox(world,'bark',0x684b33,mid,base,-.1,p.w,p.thickness,1.6);
      for(let j=0;j<8;j++)box(details,0xa27b55,p.x+j*.08,base,-.1,.03,p.thickness,.15);
      for(const side of [-1,1])for(let j=0;j<3;j++){
        const grip=box(details,0xe4c98f,mid+side*(p.w*.5+.046),p.top-.54-j*.72,.92,.07,.32,.06);
        grip.rotation.z=side*.40;
      }
      continue;
    }
    const isWood=['cedar','branch','trestle','roof'].includes(p.kind);
    const color=p.kind==='roof'?0x956362:p.kind==='pavement'?0xbfb39d:
      p.kind==='moss'?0x675a47:p.kind==='trestle'?0x72563b:C.wood;
    surfaceBox(world,p.kind==='roof'?'slate':p.kind==='pavement'?'stone':p.kind==='moss'?'moss':'timber',color,mid,base,0,p.w,p.thickness,2.7);
    const trim=p.kind==='roof'?0xc7836b:p.kind==='pavement'?0xd3c8aa:isWood?0xc2a17a:0x83b17b;
    surfaceBox(world,isWood?'timber':p.kind==='moss'?'moss':'stone',trim,mid,p.top-.085,1.46,p.w,.17,3.08);
    if(p.kind==='moss'||p.kind==='cedar'){
      for(let q=0;q<Math.min(28,Math.floor(p.w*2.6));q++){
        const x=p.x+.19+q*.36;
        if(x<p.x+p.w-.17){box(details,q%4?0x72a27b:0x9bbb81,x,p.top+.07,.95,.09,between(.18,.31),.13);}
      }
    }
    // Two-tone stepped slab gives every playable edge a bright readable rim.
    box(world,p.kind==='trestle'?0x4c3e36:p.kind==='roof'?0x6c4744:0x34473e,mid,p.top-.23,1.55,p.w,.07,.16);
    if(p.kind==='trestle'){
      for(let x=p.x+.18;x<p.x+p.w-.15;x+=.54){box(details,0xb79870,x,p.top-.01,1.57,.15,.19,3.18);}
      box(world,0x4f3e35,mid,p.top-.48,-1.46,p.w,.2,.16);
      box(world,0x4f3e35,mid,p.top-.48,1.43,p.w,.2,.16);
      for(let x=p.x+.42;x<p.x+p.w;x+=2.3){
        beam(world,0x644c38,[x,p.top-.6,-.8],[x+1.5,p.top-6,-.9],.15,.18);
        beam(world,0x644c38,[x+1.5,p.top-.6,-.8],[x,p.top-6,-.9],.15,.18);
        box(world,0x806145,x+.7,p.top-6.3,-.8,1.6,.16,.3);
      }
    }else if(isWood){
      for(let x=p.x+.24;x<p.x+p.w;x+=1.15)box(details,0x513c35,x,base,.96,.08,p.thickness*.58,.08);
    }else if(p.kind==='pavement'){
      for(let x=p.x+.3;x<p.x+p.w;x+=1.3)box(details,0x8e8d7f,x,p.top-.05,1.59,.07,.07,.05);
    }
  }
}
function addCheckpointDecor(group,details){
  for(const p of CHECKPOINTS){
    const x=p.x;
    cylinder(group,0xa17f58,x,p.y+.85,.9,.055,1.7,.055);
    const color=p.id==='last-light'?0xffe0af:0xb5e8bb;
    lightOrb(group,x,p.y+1.78,.93,.85,color);
    make(geoDiamond,mat(color,{transparent:true,opacity:.25,emissive:color}),details,[x,p.y+1.78,.95],[.44,.58,.44]);
  }
}
function addTrestleAtmosphere(group,details){
  for(let i=0;i<15;i++){
    const x=104.7+i*3.25,yy=8.4+Math.sin(i*.7)*.55;
    beam(group,0xc3a477,[x,yy,-1],[x+.15,yy+2.7,-1],.09,.09);
    const lamp=lightOrb(group,x+.12,yy+2.35,-.72,1.1,0xf8bb74);
    if(i%3===0){const p=new T.PointLight(0xffc187,1.4,5.0);p.position.set(x,yy+2.3,.4);details.add(p);}
    ball(details,0xd9e3ce,x,yy-1.8,-2.9,2.1,.8,1.3);
  }
  // The long drop and distant river, included as context from the source game.
  const river=surfaceBox(group,'water',0x417f87,95,-13,-34,170,.24,24);river.name='DISTANT_RIVER';
  for(let i=0;i<24;i++){
    const x=40+i*4.3;
    box(details,0x7badad,x,-12.81,-30.5,between(1,3),.04,.19);
  }
}
function addCollectibles(group){
  const positions=[5.6,12.4,21.2,30.1,41.3,47.2,53.5,59.9,65.2,72.4,77.9,84.6,90.1,98.2,107.1,117.7,127.2,137.2,146.5];
  return positions.map((x,i)=>{
    const top=PLATFORMS.filter(p=>x>=p.x&&x<=p.x+p.w&&p.kind!=='trunk').sort((a,b)=>b.top-a.top)[0]?.top??1;
    const y=top+1.17;
    const node=new T.Group();node.position.set(x,y,.76);group.add(node);
    const gem=make(geoDiamond,mat(0xf9e6b3,{emissive:0xffb55b}),node,[0,0,0],[.18,.28,.16]);
    make(geoDiamond,mat(0xeabf78,{transparent:true,opacity:.24,emissive:0xffc078}),node,[0,0,0],[.42,.57,.38]);
    const lens=make(geoTorus,mat(0xe4d5a1,{metalness:.08}),node,[0,0,-.065],[.31,.44,.18]);lens.rotation.z=.18;

    return {x,y,node,gem,claimed:false,i};
  });
}
function addExit(group){
  const portal=new T.Group();portal.position.set(FINISH_X,12.3,.12);group.add(portal);
  for(let i=0;i<11;i++){
    const a=Math.PI*(i/10),r=2.3;
    const px=Math.cos(a)*r, py=2.45+Math.sin(a)*r;
    ball(portal,i%2?0xefd19e:0xc9a77c,px,py,0,.3,.32,.48);
  }
  lightOrb(portal,0,5.25,.4,2.2,0xffdd96);
  const halo=make(geoTorus,mat(0xffdb9d,{emissive:0xe8b96d}),portal,[0,2.52,-.63],[2.22,2.36,.4]);
  halo.rotation.z=Math.PI;
  make(geoTorus,mat(0xb5e6cc,{transparent:true,opacity:.45,emissive:0x90d6bf}),portal,[0,2.5,-.68],[2.49,2.58,.2]);
  box(portal,0x815b4d,0,0,-.38,4.5,.32,2.3);
  for(let k=0;k<15;k++){
    const x=(rnd()-.5)*5,y=rnd()*5.2;
    lightOrb(portal,x,y,-1,rnd()*.46+.2,k%2?0xc8f5c7:0xffdd93);
  }
  return portal;
}
function buildCat(parent){
  const actor=new T.Group();parent.add(actor);
  const body=new T.Group();actor.add(body);
  // A restrained dark underside is the illustrator's ink key, never a collision change.
  ball(body,0x203340,-.095,.54,-.10,.55,.465,.36);
  ball(body,C.orange,-.08,.54,0,.49,.42,.36);
  ball(body,C.white,.22,.39,.275,.25,.31,.16);
  ball(body,C.calico,-.34,.68,.28,.21,.18,.08);
  // Calico is an illustrative placeholder, not a substitute for approved character art.
  ball(body,0x3b4342,-.17,.77,-.035,.3,.27,.30);
  ball(body,0xf8ebd3,.06,.29,.28,.27,.18,.14);
  ball(body,0xd9956d,.08,.67,.31,.19,.12,.07);
  const head=new T.Group();body.add(head);head.position.set(.35,.88,.04);
  ball(head,0x203340,-.012,.12,-.095,.45,.395,.34);
  ball(head,C.orange,0,.12,0,.4,.35,.32);
  ball(head,C.white,.08,-.03,.25,.29,.2,.11);
  ball(head,C.calico,-.17,.25,.275,.24,.19,.068);
  const ears=[];
  for(const sign of [-1,1]){
    const ear=tapered(head,sign<0?C.calico:C.orange,sign*.25,.5,-.05,.19,.42,.62);ear.rotation.z=sign*.23;ears.push({ear,sign});
    tapered(head,0xd28c88,sign*.25,.48,.09,.095,.21,.61);
  }
  // Rounded cheek tufts preserve a legible silhouette at gameplay size.
  for(const s of [-1,1]){
    const c=ball(head,C.white,.1+s*.18,-.085,.23,.15,.12,.12);c.rotation.z=s*.19;
  }
  const eyes=[],pupils=[];
  for(const x of [-.17,.2]){
    eyes.push(ball(head,0xf4dda8,x,.18,.294,.088,.11,.056));
    const pupil=ball(head,0x162b33,x+.026,.18,.341,.042,.069,.027);pupil.name='CAT_PUPIL';pupils.push(pupil);
    ball(head,0xffffff,x+.043,.212,.367,.019,.025,.013);
  }
  // Painted-calico markings and shaped cheeks turn the generic sphere into a readable sprite silhouette.
  for(const [x,y,z,sx,sy] of [[-.34,.72,.30,.17,.11],[-.16,.83,.29,.15,.09],[.10,.81,-.23,.18,.13]]){
    ball(body,C.calico,x,y,z,sx,sy,.059);
  }
  make(geoCone,mat(0xda8781),head,[.01,-.045,.38],[.09,.085,.06],Math.PI);
  for(const s of [-1,1])for(let i=0;i<3;i++){
    beam(head,0xf5e5c9,[s*.10,-.085+i*.045,.36],[s*(.50+i*.03),-.12+(i-1)*.12,.45],.016,.015);
  }
  for(const s of [-1,1]){
    const brow=ball(head,C.calico,s*.19,.34,.27,.17,.045,.055);brow.rotation.z=s*.14;
  }
  const legs=[];
  for(const x of [-.36,.30])for(const z of [-.21,.20]){
    const leg=ball(body,x>0?C.white:C.orange,x,.19,z,.14,.24,.14);legs.push(leg);
  }
  const curve=new T.CatmullRomCurve3([
    new T.Vector3(-.51,.54,-.01),new T.Vector3(-.76,.67,-.06),
    new T.Vector3(-.93,.96,-.03),new T.Vector3(-.82,1.20,0)
  ]);
  const tail=new T.Mesh(new T.TubeGeometry(curve,12,.105,6,false),mat(C.calico));body.add(tail);
  ball(body,C.white,-.82,1.2,0,.13,.15,.14);
  const scarf=make(geoBox,mat(0x69baab),body,[.16,.61,.22],[.44,.085,.12]);scarf.rotation.z=-.18;
  const ribbon=make(geoCone,mat(0x5aafa3),body,[-.22,.60,.36],[.17,.47,.09]);ribbon.rotation.z=1.7;
  const scarfTip=ball(body,0xe5cf9c,-.45,.59,.36,.065,.065,.07);
  return {actor,body,head,legs,tail,ribbon,scarfTip,eyes,pupils,ears};
}
function buildOwl(parent){
  const root=new T.Group();parent.add(root);root.position.set(92,12,-9);
  const m=mat(C.shadow,{transparent:true,opacity:.94});
  make(geoBall,m,root,[0,0,0],[1.6,2.0,1]);
  make(geoBall,m,root,[0,1.26,.04],[1.43,1.37,.95]);
  for(const s of [-1,1]){
    tapered(root,C.shadow,s*.96,2.35,.0,.67,1.18,.4).rotation.z=s*.25;
    const eye=make(geoBall,mat(0xffbb68,{emissive:0xffaa50}),root,[s*.6,1.45,.96],[.23,.15,.08]);
    make(geoBall,mat(0x241e20),root,[s*.62,1.43,1.04],[.09,.13,.07]);
  }
  const wings=[];
  for(const s of [-1,1]){
    const wing=new T.Group();wing.position.set(s*1.1,.7,0);root.add(wing);
    for(let k=0;k<6;k++){
      const blade=make(geoBall,m,wing,[s*(k*.87+.65),-.18-k*.09,0],[.98,.40-(k*.025),.34]);blade.rotation.z=s*(.05+k*.08);
      tapered(wing,C.shadow,s*(k*.87+.8),-.54-k*.06,-.02,.26,.8,.6).rotation.z=s*.17;
    }
    wings.push({group:wing,s});
  }
  for(const s of [-1,1]){
    beam(root,0x293349,[s*.31,1.65,1.03],[s*1.05,2.02,1.05],.19,.14);
    for(let i=0;i<4;i++){
      const feather=tapered(root,0x17283e,s*(.5+i*.22),-1.35+(i%2)*.1,-.03,.18,.84,.43);
      feather.rotation.z=s*.17;
    }
  }
  const eclipse=make(geoTorus,mat(0xd8af90,{transparent:true,opacity:.18,emissive:0xa66d82}),root,[0,1.0,-.32],[3.8,3.45,.2]);
  eclipse.rotation.z=.16;
  // An original, intentionally non-canonical interpretation of the Sentinel as distant shadow.
  return {root,wings,eclipse};
}
export function createWorld(canvas){
  seed=17411;
  const renderer=new T.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});
  renderer.outputColorSpace=T.SRGBColorSpace;
  renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.16;
  renderer.setSize(canvas.clientWidth||window.innerWidth,canvas.clientHeight||window.innerHeight,false);
  const scene=new T.Scene();scene.background=new T.Color(0x6e9ba5);scene.fog=new T.FogExp2(0x9ec1b9,.010);
  const camera=new T.PerspectiveCamera(28,1,.12,270);camera.position.set(5,5,22);camera.lookAt(5,5,0);
  const sky=new T.Group();scene.add(sky);const premium=new T.Group();scene.add(premium);const wind=new T.Group();scene.add(wind);
  // Warm dusk-dawn canvas gradient, generated locally with no assets.
  const gradient=document.createElement('canvas');gradient.width=1024;gradient.height=512;
  const ctx=gradient.getContext('2d');const lg=ctx.createLinearGradient(0,0,0,512);
  lg.addColorStop(0,'#234d71');lg.addColorStop(.33,'#5086a3');lg.addColorStop(.67,'#9bbbbb');lg.addColorStop(1,'#efcfaa');
  ctx.fillStyle=lg;ctx.fillRect(0,0,1024,512);
  const sunGrad=ctx.createRadialGradient(800,290,15,800,290,150);sunGrad.addColorStop(0,'#ffe7bd');sunGrad.addColorStop(.25,'#ffdeb4');sunGrad.addColorStop(1,'#ffdeb400');ctx.fillStyle=sunGrad;ctx.fillRect(590,75,420,425);
  const skyTexture=new T.CanvasTexture(gradient);skyTexture.colorSpace=T.SRGBColorSpace;
  const backdropMat=new T.MeshBasicMaterial({map:skyTexture,depthWrite:false,fog:false});
  make(new T.PlaneGeometry(480,170),backdropMat,sky,[72,17,-76],[1,1,1]);
  const bloomMap=softTexture();
  const shafts=new T.Group();scene.add(shafts);atmosphericShafts(shafts);
  glow(sky,bloomMap,123,22,-68,42,38,0xffe7ba,.47);
  glow(sky,bloomMap,123,22,-67,16,16,0xffdf9b,.19);
  const paintings=new T.Group();scene.add(paintings);installChapterPaintings(paintings);
  const horizon=new T.Group();scene.add(horizon);
  // Three silhouette planes replace triangular placeholder mountains.
  distantRidge(horizon,-53,0x7d9c9c,1.3,22);
  distantRidge(horizon,-45,0x5d8586,2.6,14);
  distantRidge(horizon,-36,0x416e74,3.8,8);
  box(horizon,0x6390a0,86,-11,-39,225,8,5);
  const clouds=new T.Group();scene.add(clouds);const fineClouds=new T.Group();scene.add(fineClouds);
  for(let i=0;i<74;i++){const x=-30+i*2.8+between(-2,2),y=between(-2,15),z=between(-27,-11);addCloud(i%3?clouds:fineClouds,x,y,z,between(.45,1.4),i%2?0xcce6d9:0xf6e6c8);}
  for(let i=0;i<20;i++){
    const x=102+i*3.0,y=5.5+Math.sin(i*.7)*.9;
    addCloud(i%2?fineClouds:clouds,x,y,-8.5,between(1.25,2.6),i%2?0xdce9e3:0xebdfd4);
  }
  const scenery=new T.Group(),details=new T.Group();scene.add(scenery);scene.add(details);
  townDetails(scenery,true);extraTownArt(scenery,details);skylineWires(scenery);
  forests(scenery,details);woodlandArt(scenery,details,wind);cathedralCedars(scenery,details);
  platformVisual(scenery,details);
  addChapterLandmarks(scenery,details,premium,bloomMap);
  addFineWorldDetails(scenery,details,wind);
  addCheckpointDecor(scenery,details);addTrestleAtmosphere(scenery,details);trestleDetails(scenery,details);
  // A soft, horizontal cloud ocean sits far behind the causeway. It is
  // optional, deliberately translucent, and never covers a platform edge.
  for(let i=0;i<9;i++){
    const x=105+i*5.4,y=5.3+(i%3)*.56;
    glow(premium,bloomMap,x,y,-9.0-(i%2),22+(i%3)*4,4.8,0xebf1eb,.13);
  }
  for(const p of CHECKPOINTS){
    glow(premium,bloomMap,p.x,p.y+1.78,1.0,3.25,3.25,p.id==='last-light'?0xffd48a:0xb3ecd2,.28);
    for(let i=0;i<3;i++)ball(details,0xe9d0a0,p.x+Math.sin(i*1.6)*.2,p.y+.48+i*.28,.96,.055,.11,.07);
  }
  for(let i=0;i<16;i++){
    const x=42+i*3.55,y=3.1+i*.35;
    glow(premium,bloomMap,x,y,-2.7,1.7,1.65,0xc3f7c4,.2);
  }
  // Dew lights suggest a route without imposing a collectible progression system.
  const collectibles=addCollectibles(scenery);
  const exit=addExit(scenery);
  const cat=buildCat(scene),owl=buildOwl(scene);
  const owlEchoes=buildOwlEchoes(scene);
  const contact=make(geoPlane,new T.MeshBasicMaterial({map:bloomMap,color:0x0d2228,transparent:true,opacity:.32,depthWrite:false,fog:false}),scene,[2.1,1.07,1.78],[1.6,.40,1]);
  const sparks=createFxPool();
  const particleMaterial=new T.MeshBasicMaterial({vertexColors:false,color:0xffffff,transparent:true,opacity:.79,blending:T.AdditiveBlending,depthWrite:false,depthTest:false,fog:false});
  const particleMesh=new T.InstancedMesh(geoDiamond,particleMaterial,EFFECT_BUDGET.high);particleMesh.frustumCulled=false;particleMesh.instanceMatrix.setUsage(T.DynamicDrawUsage);scene.add(particleMesh);
  const tempMatrix=new T.Matrix4(),tempQuat=new T.Quaternion(),tempScale=new T.Vector3(),tempPos=new T.Vector3();
  const particleColors={mint:new T.Color(0x97f2c2),gold:new T.Color(0xffdc91),cream:new T.Color(0xf8eee4),rose:new T.Color(0xff9eae)};
  const flies=new T.InstancedMesh(geoDiamond,new T.MeshBasicMaterial({color:0xc8f3b2,transparent:true,opacity:.8,blending:T.AdditiveBlending,depthWrite:false}),36);
  flies.frustumCulled=false;flies.instanceMatrix.setUsage(T.DynamicDrawUsage);premium.add(flies);
  const staticSaved=[horizon,scenery,details].reduce((total,g)=>total+batchStatic(g),0)
    +batchStatic(clouds,true)+batchStatic(fineClouds,true)
    +wind.children.reduce((total,g)=>total+batchStatic(g),0)+batchStatic(exit);
  // Decorative light dots are one dynamic draw call; static scenery is instanced by material.

  const hemi=new T.HemisphereLight(0xe8fbf4,0x435c55,2.4);scene.add(hemi);
  const sunlight=new T.DirectionalLight(0xffd29b,2.15);sunlight.position.set(-8,24,18);scene.add(sunlight);
  const lights=[];
  for(const p of CHECKPOINTS.filter((_,i)=>i%2===0)){
    const pl=new T.PointLight(0xffcb8e,.9,5);pl.position.set(p.x,p.y+2.3,1.3);scene.add(pl);lights.push(pl);
  }
  let low=false,reduced=false,t=0,camX=5,camY=4.1,impact=0,landingSquash=0;
  const palette=[new T.Color(0xffd8ae),new T.Color(0xe5f6d4),new T.Color(0xc4dccd),new T.Color(0xc4badb)];
  const colorWork=new T.Color(),fogWork=new T.Color(),skyTint=new T.Color();
  const setQuality=(tier)=>{
    low=tier==='low';details.visible=!low;fineClouds.visible=!low;premium.visible=!low;shafts.visible=!low;particleMesh.count=low?EFFECT_BUDGET.low:EFFECT_BUDGET.high;
    lights.forEach(l=>l.visible=!low);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,low?1:1.55));
    scene.fog.density=low?.007:.010;
  };
  const resize=()=>{
    const w=Math.max(1,canvas.clientWidth),h=Math.max(1,canvas.clientHeight);
    camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);
  };
  setQuality('high');resize();
  const cameraTarget=(player,active=false,owlX=0)=>{
    // The owl enters the left periphery only as the chase closes. Always retain
    // at least ~10 world units of visible path ahead for responsive platforming.
    const proximity=active?Math.max(0,Math.min(1,(10-(player.x-owlX))/6)):0;
    return {x:Math.max(7,Math.min(145,player.x+3.35-proximity*2.2)),
      y:Math.max(4.0,Math.min(15.3,player.y+3.0))};
  };
  // Reset the presentation on replay / checkpoint recovery, not just the physics.
  const resetView=(player)=>{
    const target=cameraTarget(player);camX=target.x;camY=target.y;t=0;
    camera.position.set(camX,camY,22);camera.lookAt(camX,camY-.05,0);
    impact=0;landingSquash=0;for(const p of sparks.items){p.life=0;p.age=0;}
    cat.pupils.forEach((p,i)=>{p.position.x=i===0?-.144:.226;p.scale.y=.069;});
    cat.eyes.forEach(eye=>eye.scale.y=.11);
    for(const {ear,sign} of cat.ears)ear.rotation.z=sign*.23;
  };
  const emit=(type,x,y)=>{
    if(reduced)return 0;
    emitFx(sparks,type,x,y,low?'low':'high');
    if(type==='land'||type==='doublejump'||type==='walljump')impact=reduced?0:Math.min(.4,impact+(type==='doublejump'?.17:.10));
    if(type==='land')landingSquash=reduced?0:.23;
  };
  const step=(player,owlX,active,dt,reduce,finished=false,alpha=1)=>{
    t+=dt;reduced=!!reduce;
    const interp=Math.min(1,Math.max(0,alpha));
    const drawX=player.prevX+(player.x-player.prevX)*interp,drawY=player.prevY+(player.y-player.prevY)*interp;
    const drawPlayer={x:drawX,y:drawY,vx:player.vx};
    const target=cameraTarget(drawPlayer,active,owlX),targetX=target.x,targetY=target.y;
    const blend=reduce?1:1-Math.exp(-Math.min(dt,.09)*3.65);
    camX+=(targetX-camX)*blend;camY+=(targetY-camY)*blend;
    camera.position.set(camX,camY+(reduce?0:impact*.055),22);camera.lookAt(camX,camY-.05,0);
    impact*=Math.exp(-dt*13);
    cat.actor.position.set(drawX,drawY,.35);
    cat.actor.rotation.y=player.face===1?-.18:Math.PI+.18;
    const stride=Math.min(1,Math.abs(player.vx)/6);
    const bob=reduce?0:Math.sin(t*17)*.045*stride;
    const stretch=player.grounded?1:Math.min(1.12,1+.045*Math.abs(player.vy)/12);
    const squash=reduced?0:Math.max(0,landingSquash);landingSquash=Math.max(0,landingSquash-dt*1.8);
    cat.body.scale.set((player.grounded?1+.035*stride:1/stretch)+squash*.6,stretch-squash*.55,1);
    cat.body.position.y=(player.grounded?bob:.06);
    cat.head.rotation.z=reduce?0:Math.sin(t*2.8)*.028+Math.max(-.085,Math.min(.085,player.vy*.008));
    for(const {ear,sign} of cat.ears)ear.rotation.z=sign*(.23+(reduce?0:Math.sin(t*2.8+sign)*.06)+(active?.06:0));
    const blinkPhase=t%5.7,blink=reduce?1:(blinkPhase>5.25&&blinkPhase<5.38?.14:1);
    cat.eyes.forEach(eye=>{eye.scale.y=.11*blink;});
    cat.pupils.forEach(pupil=>{
      pupil.scale.y=.069*blink;
      const gaze=Math.max(-.033,Math.min(.033,player.vx*.003));
      const base=pupil.position.x>0?.226:-.144;
      pupil.position.x+=(base+gaze-pupil.position.x)*Math.min(1,dt*8);
    });
    cat.legs.forEach((leg,i)=>leg.position.y=.19+(player.grounded?(reduce?0:Math.sin(t*18+(i%2?Math.PI:0))*.085*stride):.065));
    cat.tail.rotation.z=reduce?0:Math.sin(t*3+Math.abs(player.vx)*.2)*.19;
    cat.ribbon.rotation.z=1.7+(reduce?0:Math.sin(t*8)*.16*stride);
    cat.legs.forEach((leg,i)=>leg.rotation.z=reduce?0:(player.grounded?Math.sin(t*18+i*1.9)*.19*stride:(player.vy>0?.28:-.13)));
    cat.body.rotation.z=player.grounded?Math.max(-.12,Math.min(.12,-player.vx*.012)):(player.vy>0?-.12:.11);
    const floor=surfaceUnder(drawX,drawY+.02);
    contact.visible=Boolean(floor&&drawY-floor.top<4.8);
    if(floor){contact.position.set(drawX,floor.top+.11,1.66);contact.scale.set(Math.max(.6,1.55-(drawY-floor.top)*.18),.24,1);}
    owl.root.visible=active;
    for(let i=0;i<owlEchoes.length;i++){
      const echo=owlEchoes[i];echo.visible=active&&!low&&!reduce;
      echo.position.set(owlX-2.0-(i+1)*1.55,player.y+4.8+Math.sin(t*.6-i*.45)*.3,-11.7-i*.21);
      echo.scale.setScalar(1+(i+1)*.12);
    }
    owl.root.position.set(owlX-2.0,player.y+4.8+Math.sin(t*.6)*.35,-10);
    for(const o of owl.wings)o.group.rotation.z=reduce?0:Math.sin(t*3.8)*.21*o.s;
    owl.eclipse.rotation.z=reduce?0:.16+Math.sin(t*.45)*.055;
    for(const c of collectibles)if(!c.claimed){c.node.rotation.y=reduce?0:t*1.25+c.i*.35;c.node.position.y=c.y+(reduce?0:Math.sin(t*2.4+c.i)*.15);}
    exit.rotation.z=reduce?0:Math.sin(t*.8)*.008;
    // Color script follows the four environments without changing collision or gameplay.
    const chap=chapterFor(player.x),next=palette[Math.min(3,chap+1)];
    const edge=CHAPTERS[chap].to;
    const mix=chap<3?Math.max(0,Math.min(1,(player.x-edge+4)/8)):0;
    colorWork.copy(palette[chap]).lerp(next,mix);
    sunlight.color.lerp(colorWork,Math.min(1,dt*2.7));
    const fogHex=[0xb1c5bf,0x9dc9b3,0xa6c9c7,0xaaa9c0][chap];
    fogWork.setHex(fogHex);scene.fog.color.lerp(fogWork,Math.min(1,dt*2.4));
    skyTint.setHex([0xffffff,0xf2fce9,0xe3f4ef,0xbec6e5][chap]);
    backdropMat.color.lerp(skyTint,Math.min(1,dt*2.25));
    renderer.toneMappingExposure=low?1.1:1.13;
    const water=surfaceTextures.get('water');if(water)water.offset.x=reduced?0:(t*.006)%1;
    clouds.position.x=reduced?0:Math.sin(t*.063)*1.8;
    fineClouds.position.x=reduced?0:Math.sin(t*.085+.9)*1.0;
    for(const g of wind.children)g.rotation.z=reduced?0:Math.sin(t*1.02+g.userData.wind)*.042;
    if(!low){
      for(let i=0;i<36;i++){
        const x=41+i*1.61,y=2.4+(i%7)*.82;
        tempPos.set(x+(reduced?0:Math.sin(t*.63+i*2.1)*.27),y+(reduced?0:Math.sin(t*1.1+i*.85)*.23),-.3-(i%3)*.6);
        tempScale.setScalar(.035+(i%3)*.013);tempMatrix.compose(tempPos,tempQuat,tempScale);flies.setMatrixAt(i,tempMatrix);
      }
      flies.instanceMatrix.needsUpdate=true;
    }
    if(reduced){for(const p of sparks.items)p.life=0;impact=0;}
    else stepFx(sparks,dt);
    for(let i=0;i<sparks.items.length;i++){
      const p=sparks.items[i];const size=fxScale(p);
      tempPos.set(p.x,p.y,p.z);tempScale.setScalar(low&&i>=EFFECT_BUDGET.low?0:size);
      tempMatrix.compose(tempPos,tempQuat,tempScale);particleMesh.setMatrixAt(i,tempMatrix);
      particleMesh.setColorAt(i,particleColors[p.hue]||particleColors.gold);
    }
    particleMesh.instanceMatrix.needsUpdate=true;
    if(particleMesh.instanceColor)particleMesh.instanceColor.needsUpdate=true;
    renderer.render(scene,camera);
  };
  const collect=(x,y)=>{let found=0;for(const c of collectibles){if(!c.claimed && Math.abs(x-c.x)<.85 && Math.abs((y+.64)-c.y)<1.15){c.claimed=true;c.node.visible=false;found++;}}return found;};
  const dispose=()=>{
    const geometries=new Set(),materials=new Set(),textures=new Set();
    scene.traverse(obj=>{if(obj.isMesh||obj.isSprite){if(obj.geometry)geometries.add(obj.geometry);for(const m of (Array.isArray(obj.material)?obj.material:[obj.material]))if(m){materials.add(m);if(m.map)textures.add(m.map);}}});
    for(const g of geometries)g.dispose();for(const m of materials)m.dispose();for(const tex of textures)tex.dispose();
    renderer.dispose();materialCache.clear();surfaceMaterials.clear();surfaceTextures.clear();
  };
  const metrics=()=>({drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,
    geometries:renderer.info.memory.geometries,textures:renderer.info.memory.textures,staticDrawCallsSaved:staticSaved,
    activeParticles:sparks.items.filter(p=>p.life>0).length,quality:low?'low':'high',
    paintedSurfaceCount:surfaceTextures.size,chapterPaintingCount:paintings.children.length,lightShafts:shafts.children.length,
    owlEchoesVisible:owlEchoes.filter(o=>o.visible).length});
  return {scene,camera,renderer,setQuality,resize,resetView,step,emit,collect,dispose,collectibles,metrics};
}
