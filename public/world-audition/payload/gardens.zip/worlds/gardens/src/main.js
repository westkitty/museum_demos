import * as THREE from 'three';
import { createHub, createParable, createAcre, createDioramas, makePlayer, disposeWorld } from './worlds.js';
import { returnToMuseum } from './adapter.js';
const el = (id) => { const item = document.getElementById(id); if (!item)
    throw new Error(`Missing interface element: ${id}`); return item; };
const canvas = el('world');
const overlay = el('overlay'), overlayTitle = el('overlay-title'), overlayCopy = el('overlay-copy');
const overlayFoot = el('overlay-foot'), overlayActions = el('overlay-actions');
const chapterText = el('chapter'), chapterDesc = el('chapter-desc'), locator = el('locator');
const objectiveText = el('objective-text');
const prompt = el('prompt'), promptLabel = el('prompt-label'), note = el('note');
const motionBtn = el('motion');
const qualityBtn = el('quality'), qualityValue = el('quality-value');
const errorPanel = el('error');
const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)');
let reducedMotion = prefersReduced.matches;
let graphicsMode = 'AUTO';
let adaptiveLow = false;
let lowGraphics = false;
let frameAverage = 1 / 60;
let frameSampleTime = 0;
let mode = 'hub';
let overlayOpen = true;
let completed = { parable: false, acre: false };
let activated = { parable: false, acre: false };
let busy = false;
let frameId = 0;
let time = 0;
let lastTime = 0;
let accumulator = 0;
let timeline = 0;
let finaleTime = 0;
let toastTimer = 0;
let stepGlintClock = 0;
let viewYaw = 0;
let viewPitch = .21;
let desiredYaw = 0;
let desiredPitch = .21;
let dragging = false;
let dragPointer = null;
let dragPrevX = 0, dragPrevY = 0;
let lookOverride = false;
const keys = { forward: false, back: false, left: false, right: false };
let jumpQueued = .0;
let actQueued = false;
const scene = new THREE.Scene();
let renderer;
try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
}
catch (err) {
    errorPanel.hidden = false;
    errorPanel.textContent = 'This 3D pocket-world requires WebGL2 support. The browser or graphics environment could not create a rendering context. Try a WebGL2-capable browser with hardware acceleration enabled.';
    throw err;
}
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.28;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const camera = new THREE.PerspectiveCamera(58, 1, .1, 900);
const target = new THREE.Vector3(0, 2.4, 0);
const tmp = new THREE.Vector3();
const chase = new THREE.Vector3();
const vLook = new THREE.Vector3();
const hemi = new THREE.HemisphereLight(0xe7c8ff, 0x142735, 2.1);
scene.add(hemi);
const mainLight = new THREE.DirectionalLight(0xffc88a, 3.3);
mainLight.position.set(-31, 64, 28);
mainLight.castShadow = true;
mainLight.shadow.mapSize.set(1024, 1024);
mainLight.shadow.camera.left = -39;
mainLight.shadow.camera.right = 39;
mainLight.shadow.camera.top = 39;
mainLight.shadow.camera.bottom = -39;
mainLight.shadow.camera.near = 1;
mainLight.shadow.camera.far = 170;
mainLight.shadow.bias = -.0002;
mainLight.shadow.normalBias = .035;
scene.add(mainLight);
scene.add(mainLight.target);
const fillLight = new THREE.DirectionalLight(0x73e5e4, 1.45);
fillLight.position.set(42, 22, -72);
scene.add(fillLight);
const glowA = new THREE.PointLight(0xec9bf8, 1100, 140, 1.7);
glowA.position.set(15, 24, -35);
scene.add(glowA);
const glowB = new THREE.PointLight(0x67fbd3, 1100, 140, 1.8);
glowB.position.set(-11, 35, -50);
scene.add(glowB);
// A single gradient sky with an authored distant light source; no post-processing pipeline.
const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false,
    uniforms: {
        high: { value: new THREE.Color(0x24154d) }, low: { value: new THREE.Color(0x714866) },
        horizon: { value: new THREE.Color(0x1c3144) }, accent: { value: new THREE.Color(0xe8b77f) },
        radiance: { value: .55 }
    },
    vertexShader: 'varying vec3 direction;void main(){direction=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
    fragmentShader: `varying vec3 direction;uniform vec3 high,low,horizon,accent;uniform float radiance;
    void main(){
      vec3 d=normalize(direction);float t=d.y;
      vec3 color=mix(horizon,low,smoothstep(-.42,.13,t));
      color=mix(color,high,smoothstep(.13,.93,t));
      float sun=max(0.,dot(d,normalize(vec3(-.18,.32,-1.))));
      float halo=pow(sun,14.)*.42+pow(sun,90.)*.53;
      float litHorizon=exp(-pow((t-.045)*3.4,2.));
      color+=accent*radiance*(halo+litHorizon*.10);
      float curtains=(sin(d.x*23.+sin(d.z*15.)*.8)*.5+.5);
      color+=accent*curtains*.016*smoothstep(.12,.62,t)*(1.-smoothstep(.65,.94,t));
      gl_FragColor=vec4(color,1.);
    }`
});
const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 40, 24), skyMat);
sky.renderOrder = -1000;
sky.frustumCulled = false;
scene.add(sky);
const chapter = { hub: createHub(), parable: createParable(), acre: createAcre() };
for (const w of Object.values(chapter))
    scene.add(w.group);
const dioramas = createDioramas();
scene.add(dioramas);
const actor = makePlayer();
scene.add(actor);
const shadow = new THREE.Mesh(new THREE.CircleGeometry(.65, 24), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: .27, depthWrite: false }));
shadow.rotation.x = -Math.PI / 2;
scene.add(shadow);
// One pooled, fixed-size event effect. No per-contact allocations or additional render loops.
const FX_COUNT = 96;
const fxPositions = new Float32Array(FX_COUNT * 3), fxColors = new Float32Array(FX_COUNT * 3), fxVelocity = new Float32Array(FX_COUNT * 3), fxLife = new Float32Array(FX_COUNT);
const fxGeo = new THREE.BufferGeometry();
for (let i = 0; i < FX_COUNT; i++) {
    fxPositions[i * 3 + 1] = -9999;
    fxColors[i * 3] = fxColors[i * 3 + 1] = fxColors[i * 3 + 2] = 1;
}
fxGeo.setAttribute('position', new THREE.BufferAttribute(fxPositions, 3).setUsage(THREE.DynamicDrawUsage));
fxGeo.setAttribute('color', new THREE.BufferAttribute(fxColors, 3).setUsage(THREE.DynamicDrawUsage));
const fxPixels = new Uint8Array(16 * 16 * 4);
for (let y = 0; y < 16; y++)
    for (let x = 0; x < 16; x++) {
        const a = Math.max(0, 1 - Math.hypot(x - 7.5, y - 7.5) / 7.5), i = (y * 16 + x) * 4;
        fxPixels[i] = fxPixels[i + 1] = fxPixels[i + 2] = 255;
        fxPixels[i + 3] = Math.round(255 * a * a);
    }
const fxTexture = new THREE.DataTexture(fxPixels, 16, 16, THREE.RGBAFormat);
fxTexture.needsUpdate = true;
fxTexture.magFilter = THREE.LinearFilter;
fxTexture.minFilter = THREE.LinearFilter;
const fxMaterial = new THREE.PointsMaterial({ size: .56, vertexColors: true, transparent: true, opacity: .75, map: fxTexture, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
const fx = new THREE.Points(fxGeo, fxMaterial);
fx.frustumCulled = false;
scene.add(fx);
let fxCursor = 0, fxSeed = 917236;
function fxRandom() { fxSeed = (Math.imul(fxSeed, 1664525) + 1013904223) >>> 0; return fxSeed / 4294967296; }
function resetEffects() { fxCursor = 0; fxSeed = 917236; fxLife.fill(0); for (let i = 0; i < FX_COUNT; i++)
    fxPositions[i * 3 + 1] = -9999; fxGeo.attributes.position.needsUpdate = true; }
function burst(position, color, power = 1) {
    if (reducedMotion || lowGraphics)
        return;
    const tint = new THREE.Color(color), total = Math.min(42, Math.round(15 * power));
    for (let k = 0; k < total; k++) {
        const i = fxCursor++ % FX_COUNT, at = i * 3, angle = fxRandom() * Math.PI * 2, spread = .6 + fxRandom() * 2.1;
        fxPositions[at] = position.x + (fxRandom() - .5) * .32;
        fxPositions[at + 1] = position.y + .2 + fxRandom() * .33;
        fxPositions[at + 2] = position.z + (fxRandom() - .5) * .32;
        fxVelocity[at] = Math.cos(angle) * spread;
        fxVelocity[at + 1] = 1 + fxRandom() * power * 2.8;
        fxVelocity[at + 2] = Math.sin(angle) * spread;
        fxLife[i] = .38 + fxRandom() * .38;
        fxColors[at] = tint.r;
        fxColors[at + 1] = tint.g;
        fxColors[at + 2] = tint.b;
    }
    fxGeo.attributes.color.needsUpdate = true;
    fxGeo.attributes.position.needsUpdate = true;
}
function updateEffects(dt) {
    fx.visible = !reducedMotion && !lowGraphics && mode !== 'finale';
    if (!fx.visible)
        return;
    let changed = false;
    for (let i = 0; i < FX_COUNT; i++) {
        if (fxLife[i] <= 0)
            continue;
        fxLife[i] = Math.max(0, fxLife[i] - dt);
        const at = i * 3;
        if (fxLife[i] === 0) {
            fxPositions[at + 1] = -9999;
            changed = true;
            continue;
        }
        fxPositions[at] += fxVelocity[at] * dt;
        fxPositions[at + 1] += fxVelocity[at + 1] * dt;
        fxPositions[at + 2] += fxVelocity[at + 2] * dt;
        fxVelocity[at + 1] -= 4.8 * dt;
        changed = true;
    }
    if (changed)
        fxGeo.attributes.position.needsUpdate = true;
}
const player = { pos: new THREE.Vector3(0, .2, 9), vx: 0, vy: 0, vz: 0, onGround: false, coyote: 0, checkpoint: new THREE.Vector3(0, .2, 9), jumpBuffer: 0, heading: 0 };
let active = chapter.hub;
function resize() {
    const width = Math.max(1, canvas.clientWidth), height = Math.max(1, canvas.clientHeight);
    const cap = lowGraphics ? (width < 700 ? 1 : 1.12) : (width < 700 ? 1.3 : 1.65);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cap));
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.fov = height > width ? 64 : 58;
    camera.updateProjectionMatrix();
}
function setGraphicsMode(next) {
    graphicsMode = next;
    lowGraphics = next === 'LOW' || (next === 'AUTO' && (adaptiveLow || window.innerWidth < 700));
    // Several worlds contain multiple nested high-detail groups; all must respect ECO mode.
    for (const w of Object.values(chapter)) {
        w.group.traverse((object) => { if (object.name === 'detail-high')
            object.visible = !lowGraphics; });
    }
    renderer.shadowMap.enabled = !lowGraphics;
    const size = lowGraphics ? 512 : 1024;
    if (mainLight.shadow.mapSize.width !== size) {
        mainLight.shadow.mapSize.set(size, size);
        mainLight.shadow.map?.dispose();
        mainLight.shadow.map = null;
    }
    qualityValue.textContent = next + (next === 'AUTO' && lowGraphics ? ' · ECO' : '');
    qualityBtn.setAttribute('aria-label', `Rendering quality: ${next.toLowerCase()}${lowGraphics ? ' with reduced detail' : ''}`);
    resize();
}
function setTheme(which) {
    const theme = which === 'parable' ? 'parable' : which === 'acre' ? 'acre' : 'hub';
    let hi, lo, hor, fog, dir, amb, fill;
    if (theme === 'parable') {
        hi = 0x32274f;
        lo = 0xa0729a;
        hor = 0x826486;
        fog = 0x4f3d65;
        dir = 0xffdca4;
        amb = 0xe7caff;
        fill = 0x8b83db;
        renderer.toneMappingExposure = 1.32;
    }
    else if (theme === 'acre') {
        hi = 0x123e4d;
        lo = 0x377d7e;
        hor = 0x267473;
        fog = 0x15464c;
        dir = 0xe2ffd3;
        amb = 0xc8fff1;
        fill = 0x91d4e4;
        renderer.toneMappingExposure = 1.27;
    }
    else {
        hi = 0x1e2346;
        lo = 0x6b6282;
        hor = 0x34495a;
        fog = 0x242a41;
        dir = 0xffd9a5;
        amb = 0xdce5ff;
        fill = 0x96f5d7;
        renderer.toneMappingExposure = 1.20;
    }
    skyMat.uniforms.high.value.set(hi);
    skyMat.uniforms.low.value.set(lo);
    skyMat.uniforms.horizon.value.set(hor);
    skyMat.uniforms.accent.value.set(theme === 'parable' ? 0xffc7ad : theme === 'acre' ? 0x9aeed6 : 0xeed6a9);
    skyMat.uniforms.radiance.value = theme === 'hub' ? .45 : .72;
    scene.fog = new THREE.FogExp2(fog, theme === 'hub' ? .0045 : .0034);
    document.documentElement.dataset.world = theme;
    mainLight.color.set(dir);
    hemi.color.set(amb);
    fillLight.color.set(fill);
    glowA.visible = theme === 'parable' || theme === 'hub';
    glowB.visible = theme === 'acre' || theme === 'hub';
}
function displayFor(which) {
    chapter.hub.group.visible = which === 'hub' || which === 'finale';
    chapter.parable.group.visible = which === 'parable';
    chapter.acre.group.visible = which === 'acre';
    dioramas.visible = which === 'finale';
    actor.visible = which !== 'finale';
    shadow.visible = which !== 'finale';
    setTheme(which);
    const titles = {
        hub: ['THE TWO-FACED PORTAL', 'A museum threshold between independent works.', 'THE THRESHOLD'],
        parable: ['01 / PARABLE', 'Immediate intervention / a ritual changes the course', 'THE VIOLET ASCENT'],
        acre: ['02 / STARLIGHT ACRE', 'Cultivation in orbit / one finite tending act', 'THE JADE GREENHOUSE'],
        finale: ['03 / TWO ANSWERS', 'A cinematic comparison. Not a crossover.', 'THE DISTANCE BETWEEN VERBS']
    };
    chapterText.textContent = titles[which][0];
    chapterDesc.textContent = titles[which][1];
    locator.textContent = titles[which][2];
    updateProgress();
    updateObjective();
}
function updateObjective() {
    const lines = {
        hub: 'Turn to a portal face and press E to enter.',
        parable: activated.parable ? 'The stones have risen. Traverse the gold-edged ascent.' : 'Cross the suspended stones. At the altar, perform the ritual.',
        acre: activated.acre ? 'The leaf path is growing. Follow it to the far terrace.' : 'Reach the seed terrace. Plant with one finite vessel of water.',
        finale: 'Two separate stories. Witness the double-faced exhibition.'
    };
    objectiveText.textContent = lines[mode];
}
function updateProgress() {
    el('markA').className = 'progress-mark' + (completed.parable ? ' complete' : mode === 'parable' ? ' current' : '');
    el('markB').className = 'progress-mark' + (completed.acre ? ' complete' : mode === 'acre' ? ' current' : '');
    el('markEnd').className = 'progress-mark' + (mode === 'finale' ? ' complete' : '');
}
function openOverlay(title, copy, actions, foot = 'INDEPENDENT PROTOTYPE / NOT AN E31 SOURCE CHANGE') {
    overlayTitle.textContent = title;
    overlayCopy.textContent = copy;
    overlayFoot.textContent = foot;
    overlayActions.replaceChildren();
    for (const item of actions) {
        const b = document.createElement('button');
        b.textContent = item.title;
        b.className = item.primary === false ? 'action-secondary' : 'action-primary';
        b.addEventListener('click', item.action);
        overlayActions.append(b);
    }
    overlay.hidden = false;
    overlayOpen = true;
    busy = true;
    overlayActions.querySelector('button')?.focus();
    clearKeys();
}
function closeOverlay() { overlay.hidden = true; overlayOpen = false; busy = false; canvas.focus({ preventScroll: true }); }
function toast(text, duration = 3.4) { note.textContent = text; note.classList.add('show'); toastTimer = duration; }
function clearKeys() { for (const k of Object.keys(keys))
    keys[k] = false; jumpQueued = 0; actQueued = false; }
function spawn(pos) { player.pos.copy(pos); player.checkpoint.copy(pos); player.vx = 0; player.vy = 0; player.vz = 0; player.coyote = .15; player.onGround = true; player.heading = 0; actor.position.copy(player.pos); actor.rotation.y = 0; }
function goHub() {
    mode = 'hub';
    active = chapter.hub;
    displayFor('hub');
    spawn(active.spawn);
    desiredYaw = 0;
    viewYaw = 0;
    viewPitch = .19;
    desiredPitch = .19;
    lookOverride = false;
    resetEffects();
    closeOverlay();
    toast('Approach either face of the ring. Purple is Parable; jade is Starlight Acre.', 4);
}
function enter(side) {
    mode = side;
    active = chapter[side];
    active.reset();
    activated[side] = false;
    displayFor(side);
    spawn(active.spawn);
    desiredYaw = 0;
    viewYaw = 0;
    viewPitch = .20;
    desiredPitch = .20;
    lookOverride = false;
    resetEffects();
    closeOverlay();
    if (side === 'parable')
        toast('Follow the suspended stones. At the altar, perform the exhibit ritual with E.', 4.4);
    else
        toast('A single vessel of water waits at the planting terrace. Tend one seed to grow the route.', 4.4);
}
function hardReset() {
    chapter.parable.reset();
    chapter.acre.reset();
    stepGlintClock = 0;
    completed = { parable: false, acre: false };
    activated = { parable: false, acre: false };
    time = 0;
    timeline = 0;
    finaleTime = 0;
    resetEffects();
    goHub();
    accumulator = 0;
    lastTime = 0;
    camera.position.set(0, 8, 28);
    vLook.set(0, 3, -5);
    camera.lookAt(vLook);
    toast('Every platform and every state has returned to its starting arrangement.', 3.8);
}
function nearPortal() { return Math.hypot(player.pos.x, player.pos.z) < 6.6 && player.pos.y < 2.3; }
function nearInteraction() { const q = active.interaction; return q ? Math.hypot(player.pos.x - q.x, player.pos.z - q.z) < 3.65 && Math.abs(player.pos.y - q.y) < 2.4 : false; }
function interact() {
    if (overlayOpen || mode === 'finale')
        return;
    if (mode === 'hub') {
        if (nearPortal())
            enter(player.pos.z >= 0 ? 'parable' : 'acre');
    }
    else if (mode === 'parable' && !activated.parable && nearInteraction()) {
        activated.parable = true;
        active.activate(reducedMotion);
        updateObjective();
        burst(player.pos, 0xffdd94, 2.2);
        toast('THE RITUAL ANSWERS. The hanging stones rise in one impossible breath.', 5.1);
    }
    else if (mode === 'acre' && !activated.acre && nearInteraction()) {
        activated.acre = true;
        active.activate(reducedMotion);
        updateObjective();
        burst(player.pos, 0xa6ffe0, 2.2);
        toast('ONE VIAL SPENT. The seed takes root; the greenhouse makes a path in its own time.', 5.4);
    }
}
function finishSide(side) {
    if (overlayOpen)
        return;
    completed[side] = true;
    const next = side === 'parable' ? 'acre' : 'parable';
    const all = completed.parable && completed.acre;
    if (all) {
        resetEffects();
        mode = 'finale';
        active = chapter.hub;
        displayFor('finale');
        finaleTime = 0;
        closeOverlay();
        toast('TWO WORLDS. TWO TEMPERAMENTS. THE SAME THRESHOLD.', 5);
        return;
    }
    const title = side === 'parable' ? 'THE WORLD ANSWERS.' : 'THE WORLD REMEMBERS.';
    const copy = side === 'parable' ? 'Parable is represented here by the immediacy of an intervention. The next face belongs to a game about finite resources and growth.' : 'Starlight Acre is represented here by tending a limited resource toward a visible future. On the other face, a ritual changes the path at once.';
    openOverlay(title, copy, [
        { title: `TURN TO ${next === 'acre' ? 'STARLIGHT ACRE' : 'PARABLE'}`, action: () => enter(next) },
        { title: 'RETURN TO THE PORTAL', action: goHub, primary: false }
    ]);
}
function showFinaleOverlay() {
    if (overlayOpen)
        return;
    openOverlay('TWO ANSWERS. NO SHARED HISTORY.', 'One world changes in the instant of a ritual. The other asks for a seed, a finite measure of care, and time. The portal is a museum device; these fictions remain separate.', [
        { title: 'REVISIT THE PORTAL', action: goHub },
        { title: 'WITNESS THE REVEAL AGAIN', action: () => { closeOverlay(); finaleTime = 0; }, primary: false },
        { title: 'RETURN TO MUSEUM (MOCK)', action: mockMuseumReturn, primary: false }
    ], 'E31 STORY WORLDS / P054 PARABLE / P055 STARLIGHT ACRE / ORIGINAL INTERPRETIVE PLATFORMS');
}
function mockMuseumReturn() {
    const result = returnToMuseum({ parable: completed.parable, starlightAcre: completed.acre });
    if (result === 'mock-only') {
        goHub();
        toast('Mock return completed. A host-origin or same-origin return path must be configured before integration.', 5.2);
    }
}
function updatePrompt() {
    let label = '';
    if (!overlayOpen) {
        if (mode === 'hub' && nearPortal())
            label = player.pos.z >= 0 ? 'ENTER PARABLE / PURPLE FACE' : 'ENTER STARLIGHT ACRE / JADE FACE';
        else if (mode === 'parable' && !activated.parable && nearInteraction())
            label = 'PERFORM ONE RITUAL / EXHIBIT INTERPRETATION';
        else if (mode === 'acre' && !activated.acre && nearInteraction())
            label = 'PLANT + WATER / ONE FINITE VIAL';
    }
    prompt.hidden = !label;
    promptLabel.textContent = label;
}
function orientationInput() {
    let x = Number(keys.right) - Number(keys.left), z = Number(keys.forward) - Number(keys.back);
    const mag = Math.hypot(x, z);
    if (mag > 1) {
        x /= mag;
        z /= mag;
    }
    return { x, z };
}
function step(dt) {
    if (overlayOpen || mode === 'finale')
        return;
    const u = orientationInput();
    const vx = (Math.cos(viewYaw) * u.x + Math.sin(viewYaw) * u.z) * 8.35;
    const vz = (Math.sin(viewYaw) * u.x - Math.cos(viewYaw) * u.z) * 8.35;
    const smoothing = 1 - Math.exp(-(player.onGround ? 16 : 6.8) * dt);
    player.vx = THREE.MathUtils.lerp(player.vx, vx, smoothing);
    player.vz = THREE.MathUtils.lerp(player.vz, vz, smoothing);
    const prevY = player.pos.y;
    const wasGrounded = player.onGround;
    const previousVertical = player.vy;
    player.coyote = Math.max(0, player.coyote - dt);
    jumpQueued = Math.max(0, jumpQueued - dt);
    if (jumpQueued > 0 && (player.onGround || player.coyote > 0)) {
        player.vy = 11.8;
        player.onGround = false;
        player.coyote = 0;
        jumpQueued = 0;
        burst(player.pos, mode === 'parable' ? 0xf7c988 : 0x91eec9, .63);
    }
    player.vy = Math.max(-29, player.vy - 22 * dt);
    player.pos.x += player.vx * dt;
    player.pos.z += player.vz * dt;
    player.pos.y += player.vy * dt;
    let landed = null;
    if (player.vy <= 0) {
        for (const p of active.platforms) {
            if (!p.active || p.solid === false)
                continue;
            const withinX = Math.abs(player.pos.x - p.x) < p.w * .5 - .19;
            const withinZ = Math.abs(player.pos.z - p.z) < p.d * .5 - .19;
            if (withinX && withinZ && prevY >= p.y - .1 && player.pos.y <= p.y) {
                if (!landed || p.y > landed.y)
                    landed = p;
            }
        }
    }
    if (landed) {
        if (!wasGrounded && previousVertical < -2.2)
            burst(player.pos, mode === 'parable' ? 0xffdd9c : 0x9cf4db, Math.min(1.5, Math.abs(previousVertical) / 10));
        player.pos.y = landed.y;
        player.vy = 0;
        player.onGround = true;
        player.coyote = .12;
        if (landed.checkpoint && player.checkpoint.distanceToSquared(new THREE.Vector3(landed.x, landed.y, landed.z)) > 12) {
            player.checkpoint.set(landed.x, landed.y, landed.z + Math.min(1, landed.d * .12));
            if (mode !== 'hub') {
                burst(player.pos, mode === 'parable' ? 0xffd4a2 : 0x96ffe0, .85);
                toast('CHECKPOINT / THE JOURNEY WILL RESUME HERE.', 2.25);
            }
        }
    }
    else if (player.onGround) {
        player.onGround = false;
        player.coyote = .13;
    }
    if ((mode === 'hub' && Math.hypot(player.pos.x, player.pos.z) > 15.0) || player.pos.y < -15) {
        player.pos.copy(player.checkpoint);
        player.vx = 0;
        player.vz = 0;
        player.vy = 0;
        player.onGround = true;
        player.coyote = .12;
        toast('RETURNED TO THE LAST SAFE PLATFORM.', 2.2);
    }
    const motion = Math.hypot(player.vx, player.vz);
    if (motion > .2) {
        const desired = Math.atan2(-player.vx, -player.vz);
        let diff = ((desired - player.heading + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
        player.heading += diff * Math.min(1, dt * 11);
    }
    actor.position.copy(player.pos);
    actor.rotation.y = player.heading;
    const limbs = actor.getObjectByName('limbs');
    if (limbs) {
        const gait = reducedMotion ? 0 : Math.sin(time * 12.1) * Math.min(motion / 8, 1);
        for (const part of limbs.children)
            if (part instanceof THREE.Mesh) {
                if (part.name === 'legL' || part.name === 'cuffL' || part.name === 'armR')
                    part.rotation.x = gait * .31;
                else if (part.name === 'legR' || part.name === 'cuffR' || part.name === 'armL')
                    part.rotation.x = -gait * .31;
            }
    }
    // Tiny idle breathing and jump anticipation are presentation-only and never change collision.
    const helmet = actor.getObjectByName('helmet');
    const torso = actor.getObjectByName('torso');
    const idle = (reducedMotion ? 0 : Math.max(0, 1 - motion / 2));
    if (helmet) {
        helmet.position.y = 1.9 + Math.sin(time * 2.1) * .018 * idle;
        helmet.rotation.z = reducedMotion ? 0 : Math.max(-.045, Math.min(.045, -player.vx * .004));
    }
    if (torso) {
        torso.scale.y = 1 + Math.sin(time * 2.1) * .016 * idle;
    }
    const cloak = actor.getObjectByName('cloak');
    if (cloak) {
        cloak.rotation.z = reducedMotion ? 0 : Math.sin(time * 3.9) * .045 + Math.min(.12, motion * .010);
        cloak.rotation.x = reducedMotion ? 0 : -.02 - Math.min(.15, motion * .014);
    }
    for (const sign of [-1, 1]) {
        const ribbon = actor.getObjectByName(sign < 0 ? 'ribbonL' : 'ribbonR');
        if (ribbon) {
            ribbon.rotation.x = reducedMotion ? .16 : .16 + Math.min(.38, motion * .032) + Math.sin(time * 3 + sign) * .044;
            ribbon.rotation.z = reducedMotion ? sign * .15 : sign * .15 + Math.sin(time * 2.5 + sign) * .09;
        }
    }
    const halo = actor.getObjectByName('traveler-halo');
    if (halo)
        halo.rotation.z = reducedMotion ? 0 : Math.sin(time * .55) * .14;
    const stretch = reducedMotion ? 0 : player.onGround ? .008 * Math.sin(time * 2.2) : THREE.MathUtils.clamp(player.vy * .004, -.05, .065);
    actor.scale.set(1.03 - stretch * .27, 1.03 + stretch, 1.03 - stretch * .27);
    stepGlintClock += dt;
    if (player.onGround && motion > 5.2 && stepGlintClock > .34) {
        stepGlintClock = 0;
        burst(player.pos, mode === 'parable' ? 0xffd8ad : 0xa1f6cf, .34);
    }
    if (!reducedMotion) {
        actor.position.y += player.onGround ? Math.sin(time * 12) * Math.min(.04, motion * .006) : 0;
        actor.rotation.z = Math.max(-.06, Math.min(.06, -player.vx * .008));
    }
    else
        actor.rotation.z = 0;
    // Ground-projected landing marker remains on support geometry rather than floating with jumps.
    let support = null;
    for (const p of active.platforms) {
        if (!p.active || !p.solid || p.y > player.pos.y + .15)
            continue;
        if (Math.abs(p.x - player.pos.x) < p.w * .5 - .25 && Math.abs(p.z - player.pos.z) < p.d * .5 - .25) {
            if (!support || p.y > support.y)
                support = p;
        }
    }
    shadow.visible = !!support;
    if (support) {
        shadow.position.set(player.pos.x, support.y + .028, player.pos.z);
        const distance = Math.max(0, player.pos.y - support.y);
        const scale = 1 + Math.min(2.7, distance * .18);
        shadow.scale.set(scale, scale, scale);
        shadow.material instanceof THREE.MeshBasicMaterial && (shadow.material.opacity = .20 / (1 + distance * .24));
    }
    if (mode === 'parable' && activated.parable && player.pos.z < -71 && player.pos.y > 7.6 && Math.abs(player.pos.x) < 7.5)
        finishSide('parable');
    if (mode === 'acre' && activated.acre && player.pos.z < -73 && player.pos.y > 7.3 && Math.abs(player.pos.x + 2) < 8)
        finishSide('acre');
}
function updateCamera(dt) {
    if (mode === 'finale') {
        finaleTime += dt;
        if (reducedMotion) {
            camera.position.set(93, 79, 126);
            camera.lookAt(0, 12, 0);
            if (finaleTime > 3.2 && !overlayOpen)
                showFinaleOverlay();
            return;
        }
        const t = Math.min(1, finaleTime / 10.5);
        const ease = t * t * (3 - 2 * t);
        // Show the violet garden, rotate past the double-faced portal, then reveal the orbital garden.
        const angle = (.22 - ease * .94) * Math.PI;
        const radius = 113;
        const yy = 47 + Math.sin(Math.PI * t) * 33;
        const pos = new THREE.Vector3(Math.sin(angle) * radius, yy, Math.cos(angle) * radius);
        const aim = new THREE.Vector3(0, 12, 0);
        camera.position.lerp(pos, reducedMotion ? 1 : Math.min(1, dt * 4));
        camera.lookAt(aim);
        if (finaleTime > 10.8 && !overlayOpen)
            showFinaleOverlay();
        return;
    }
    const alpha = reducedMotion ? 1 : 1 - Math.exp(-6 * dt);
    viewYaw = THREE.MathUtils.lerp(viewYaw, desiredYaw, alpha);
    viewPitch = THREE.MathUtils.lerp(viewPitch, desiredPitch, alpha);
    const distance = mode === 'hub' ? 17.5 : 15.4;
    const height = mode === 'hub' ? 7.5 : 5.8;
    const cosPitch = Math.cos(viewPitch);
    chase.set(player.pos.x - Math.sin(viewYaw) * distance * cosPitch, player.pos.y + height + Math.sin(viewPitch) * distance * .54, player.pos.z + Math.cos(viewYaw) * distance * cosPitch);
    camera.position.lerp(chase, reducedMotion ? 1 : 1 - Math.exp(-4.1 * dt));
    target.set(player.pos.x + THREE.MathUtils.clamp(player.vx * .14, -.85, .85), player.pos.y + (mode === 'hub' ? 3.1 : 2.4), player.pos.z - 3.0 + THREE.MathUtils.clamp(player.vz * .14, -1.1, 1.1));
    vLook.lerp(target, reducedMotion ? 1 : 1 - Math.exp(-6 * dt));
    camera.lookAt(vLook);
    // Controlled movement staging: camera remains stable in reduced motion and on touch.
    if (!reducedMotion) {
        const pace = Math.hypot(player.vx, player.vz);
        const baseline = canvas.clientHeight > canvas.clientWidth ? 64 : 58;
        const desiredFov = baseline + Math.min(2.5, pace * .24);
        if (Math.abs(camera.fov - desiredFov) > .05) {
            camera.fov = THREE.MathUtils.lerp(camera.fov, desiredFov, Math.min(1, dt * 2.8));
            camera.updateProjectionMatrix();
        }
    }
}
function render(now) {
    if (frameId === -1)
        return;
    if (!lastTime)
        lastTime = now;
    const dt = Math.min(.06, Math.max(0, (now - lastTime) / 1000));
    lastTime = now;
    time += dt;
    frameAverage = frameAverage * .96 + dt * .04;
    frameSampleTime += dt;
    if (graphicsMode === 'AUTO' && !adaptiveLow && frameSampleTime > 6 && frameAverage > .033) {
        adaptiveLow = true;
        setGraphicsMode('AUTO');
    }
    if (toastTimer > 0) {
        toastTimer -= dt;
        if (toastTimer <= 0)
            note.classList.remove('show');
    }
    if (!document.hidden) {
        const simDt = 1 / 60;
        if (!overlayOpen && mode !== 'finale') {
            accumulator = Math.min(.18, accumulator + dt);
            let count = 0;
            while (accumulator >= simDt && count++ < 8) {
                step(simDt);
                accumulator -= simDt;
            }
        }
        else
            accumulator = 0;
        for (const [id, w] of Object.entries(chapter))
            if (w.group.visible)
                w.update(dt, time, reducedMotion);
        updateCamera(dt);
        updateEffects(dt);
        mainLight.target.position.copy(player.pos).add(tmp.set(0, 2, -8));
        mainLight.position.copy(mainLight.target.position).add(tmp.set(-33, 64, 28));
        mainLight.target.updateMatrixWorld();
        sky.position.copy(camera.position);
        updatePrompt();
        renderer.render(scene, camera);
    }
    frameId = requestAnimationFrame(render);
}
function setMotion(next) {
    reducedMotion = next;
    motionBtn.textContent = `REDUCED MOTION: ${next ? 'ON' : 'OFF'}`;
    motionBtn.setAttribute('aria-pressed', String(next));
}
function bindInputs() {
    const bindings = { KeyW: 'forward', ArrowUp: 'forward', KeyS: 'back', ArrowDown: 'back', KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right' };
    window.addEventListener('keydown', (e) => {
        if (e.code in bindings) {
            if (!overlayOpen) {
                keys[bindings[e.code]] = true;
                e.preventDefault();
            }
            return;
        }
        if (e.code === 'Space' && !e.repeat && !overlayOpen) {
            jumpQueued = .16;
            e.preventDefault();
        }
        if ((e.code === 'KeyE' || e.code === 'Enter') && !e.repeat && !overlayOpen) {
            interact();
            e.preventDefault();
        }
        if (e.code === 'KeyR' && !e.repeat) {
            hardReset();
            e.preventDefault();
        }
        if (e.code === 'KeyH' && !e.repeat) {
            goHub();
            e.preventDefault();
        }
        if (e.code === 'Escape' && dragging) {
            dragging = false;
            dragPointer = null;
        }
    });
    window.addEventListener('keyup', (e) => { if (e.code in bindings)
        keys[bindings[e.code]] = false; });
    window.addEventListener('blur', clearKeys);
    document.addEventListener('visibilitychange', () => { if (document.hidden) {
        clearKeys();
        lastTime = 0;
    } });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    canvas.addEventListener('pointerdown', (e) => {
        if (overlayOpen || mode === 'finale')
            return;
        if (e.pointerType === 'mouse' && e.button !== 0 && e.button !== 2)
            return;
        dragging = true;
        dragPointer = e.pointerId;
        dragPrevX = e.clientX;
        dragPrevY = e.clientY;
        try {
            canvas.setPointerCapture(e.pointerId);
        }
        catch { }
    });
    canvas.addEventListener('pointermove', (e) => {
        if (!dragging || e.pointerId !== dragPointer || overlayOpen || mode === 'finale')
            return;
        const dx = e.clientX - dragPrevX, dy = e.clientY - dragPrevY;
        dragPrevX = e.clientX;
        dragPrevY = e.clientY;
        desiredYaw += dx * .004;
        desiredPitch = THREE.MathUtils.clamp(desiredPitch + dy * .003, -.16, .75);
    });
    const release = (e) => { if (e.pointerId === dragPointer) {
        dragging = false;
        dragPointer = null;
    } };
    canvas.addEventListener('pointerup', release);
    canvas.addEventListener('pointercancel', release);
    for (const b of document.querySelectorAll('[data-hold]')) {
        const action = b.dataset.hold;
        const down = (e) => { e.preventDefault(); keys[action] = true; b.classList.add('active'); try {
            b.setPointerCapture(e.pointerId);
        }
        catch { } };
        const up = (e) => { e.preventDefault(); keys[action] = false; b.classList.remove('active'); };
        b.addEventListener('pointerdown', down);
        b.addEventListener('pointerup', up);
        b.addEventListener('pointercancel', up);
        b.addEventListener('lostpointercapture', () => { keys[action] = false; b.classList.remove('active'); });
    }
    el('touch-jump').addEventListener('pointerdown', (e) => { e.preventDefault(); jumpQueued = .17; });
    el('touch-interact').addEventListener('click', interact);
    el('reset').addEventListener('click', hardReset);
    el('museum').addEventListener('click', mockMuseumReturn);
    motionBtn.addEventListener('click', () => setMotion(!reducedMotion));
    qualityBtn.addEventListener('click', () => {
        const modes = ['AUTO', 'HIGH', 'LOW'];
        adaptiveLow = false;
        frameAverage = 1 / 60;
        frameSampleTime = 0;
        setGraphicsMode(modes[(modes.indexOf(graphicsMode) + 1) % modes.length]);
    });
    el('start').addEventListener('click', goHub);
    const mql = (event) => setMotion(event.matches);
    prefersReduced.addEventListener('change', mql);
    window.addEventListener('resize', () => { if (graphicsMode === 'AUTO')
        setGraphicsMode('AUTO');
    else
        resize(); });
}
function cleanup() {
    cancelAnimationFrame(frameId);
    frameId = -1;
    for (const w of Object.values(chapter))
        disposeWorld(w.group);
    disposeWorld(dioramas);
    disposeWorld(actor);
    shadow.geometry.dispose();
    shadow.material.dispose();
    sky.geometry.dispose();
    skyMat.dispose();
    fxGeo.dispose();
    fxTexture.dispose();
    fxMaterial.dispose();
    renderer.dispose();
}
// Offline is a runtime property of the built artifact: the bundle contains Three.js.
// A service worker caches same-origin build assets after the first successful visit.
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => { navigator.serviceWorker.register('./sw.js').catch(() => { }); }, { once: true });
}
window.addEventListener('pagehide', cleanup, { once: true });
if (import.meta.hot)
    import.meta.hot.dispose(cleanup);
try {
    bindInputs();
    setGraphicsMode('AUTO');
    setMotion(reducedMotion);
    displayFor('hub');
    spawn(chapter.hub.spawn);
    viewYaw = .02;
    desiredYaw = 0;
    vLook.copy(new THREE.Vector3(0, 3, -5));
    camera.position.set(0, 8, 28);
    camera.lookAt(0, 3, 0);
    frameId = requestAnimationFrame(render);
}
catch (err) {
    errorPanel.hidden = false;
    errorPanel.textContent = `The pocket-world could not initialize: ${err instanceof Error ? err.message : String(err)}. A WebGL2-capable browser is required.`;
}
