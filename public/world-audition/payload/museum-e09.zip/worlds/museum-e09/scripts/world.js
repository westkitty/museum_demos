import * as THREE from 'three';
import { PLATFORMS, PHASES } from './level.js';
import { ArtDirection } from './art-direction.js';
import { FinishPass } from './finish-pass.js';
const INK = 0x101727;
const PAPER = 0xe8d8b7;
const GOLD = 0xd4ad6a;
const BLUE = 0x64d8ec;
const AMETHYST = 0x9078dd;
function smooth(t) { const v = THREE.MathUtils.clamp(t, 0, 1); return v * v * (3 - 2 * v); }
function standard(color, metalness = 0, roughness = 0.55, emissive = 0, intensity = 0) {
    return new THREE.MeshStandardMaterial({ color, metalness, roughness, emissive, emissiveIntensity: intensity, side: THREE.DoubleSide });
}
function seeded(n) { const x = Math.sin(n * 213.597 + 34.21) * 43758.5453; return x - Math.floor(x); }
export class World {
    scene = new THREE.Scene();
    root = new THREE.Group();
    litArchitectures = [];
    animations = [];
    floaters = [];
    starMaterial = null;
    skyRing = null;
    ownedTextures = new Set();
    platformMaterials = new Map();
    currentPhase = 0;
    currentMix = 0;
    progression = 0;
    fogStops = [0x17141c, 0x130f26, 0x0a1729, 0x081720].map(c => new THREE.Color(c));
    lightStops = [0xffdbab, 0xd3baff, 0xa6d9ff, 0xb7eaf0].map(c => new THREE.Color(c));
    keyLight = null;
    art;
    finish;
    constructor() {
        this.scene.background = new THREE.Color(0x070b15);
        this.scene.fog = new THREE.FogExp2(0x0b1020, 0.0024);
        this.scene.add(this.root);
        this.makeLights();
        this.makeSky();
        this.makePlatforms();
        this.makePaperArchive();
        this.makeSeparateRooms();
        this.makeMonolith();
        this.makeBuildingSite();
        this.makeTransitions();
        this.art = new ArtDirection(this.root);
        this.finish = new FinishPass(this.root, this.root);
    }
    addMesh(parent, geom, mat, x = 0, y = 0, z = 0) {
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set(x, y, z);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        parent.add(mesh);
        return mesh;
    }
    cube(parent, x, y, z, w, h, d, mat) {
        return this.addMesh(parent, new THREE.BoxGeometry(w, h, d), mat, x, y, z);
    }
    /** Batch decorative boxes that must follow one animated parent as a single draw call. */
    instanceBoxes(parent, boxes, material) {
        if (!boxes.length)
            return;
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const batch = new THREE.InstancedMesh(geometry, material, boxes.length);
        const temp = new THREE.Object3D();
        boxes.forEach(([x, y, z, w, h, d], i) => {
            temp.position.set(x, y, z);
            temp.scale.set(w, h, d);
            temp.updateMatrix();
            batch.setMatrixAt(i, temp.matrix);
        });
        batch.instanceMatrix.needsUpdate = true;
        batch.castShadow = false;
        batch.receiveShadow = false;
        batch.frustumCulled = false; // moving scene groups may animate farther than their static bounds
        parent.add(batch);
    }
    tube(parent, points, radius, mat) {
        return this.addMesh(parent, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), Math.max(10, points.length * 7), radius, 5, false), mat);
    }
    line(parent, a, b, r, mat) {
        const delta = new THREE.Vector3().subVectors(b, a);
        const mesh = this.addMesh(parent, new THREE.CylinderGeometry(r, r, delta.length(), 7), mat);
        mesh.position.copy(a).add(b).multiplyScalar(0.5);
        mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
        return mesh;
    }
    ellipsoid(parent, x, y, z, sx, sy, sz, mat) {
        const mesh = this.addMesh(parent, new THREE.SphereGeometry(1, 20, 12), mat, x, y, z);
        mesh.scale.set(sx, sy, sz);
        return mesh;
    }
    label(parent, lines, x, y, z, width = 7, height = 2.2, options = {}) {
        const canvas = document.createElement('canvas');
        canvas.width = 1024;
        canvas.height = Math.max(180, Math.round(1024 * height / width));
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas text unavailable');
        const { ink = '#f3ead6', paper = 'rgba(0,0,0,0)', align = 'center', size = 48 } = options;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (paper !== 'rgba(0,0,0,0)') {
            ctx.fillStyle = paper;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        ctx.textAlign = align;
        ctx.textBaseline = 'middle';
        const yy = canvas.height / (lines.length + 1);
        lines.forEach((str, i) => {
            const fontSize = i === 0 ? size : Math.round(size * 0.54);
            ctx.font = `${i === 0 ? '600' : '400'} ${fontSize}px Georgia, serif`;
            ctx.fillStyle = ink;
            const maxW = canvas.width - 110;
            let safeFont = fontSize;
            while (ctx.measureText(str).width > maxW && safeFont > 19) {
                safeFont -= 2;
                ctx.font = `${i === 0 ? '600' : '400'} ${safeFont}px Georgia, serif`;
            }
            ctx.fillText(str, align === 'left' ? 55 : canvas.width / 2, (i + 1) * yy, maxW);
        });
        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.anisotropy = 4;
        this.ownedTextures.add(tex);
        const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide, depthWrite: false });
        const panel = this.addMesh(parent, new THREE.PlaneGeometry(width, height), mat, x, y, z);
        panel.castShadow = false;
        panel.receiveShadow = false;
        return panel;
    }
    makeLights() {
        this.scene.add(new THREE.HemisphereLight(0xa9d6ff, 0x321c2c, 1.65));
        const moon = new THREE.DirectionalLight(0xbad7ff, 2.55);
        moon.position.set(-48, 110, 35);
        moon.castShadow = true;
        moon.shadow.mapSize.set(2048, 2048);
        moon.shadow.camera.left = -28;
        moon.shadow.camera.right = 28;
        moon.shadow.camera.top = 36;
        moon.shadow.camera.bottom = -36;
        moon.shadow.camera.near = 1;
        moon.shadow.camera.far = 240;
        moon.shadow.bias = -0.0003;
        this.scene.add(moon);
        this.keyLight = moon;
        for (const [color, x, z, intensity] of [[0xecbc78, -7, 0, 38], [0xb495ff, 9, -55, 30], [0x94b6ff, -11, -98, 45], [0x2dcfdf, 16, -150, 46]]) {
            const light = new THREE.PointLight(color, intensity, 49, 2);
            light.position.set(x, 12, z);
            this.scene.add(light);
        }
    }
    makeSky() {
        const pts = [];
        for (let i = 0; i < 950; i++) {
            const angle = seeded(i + 1) * Math.PI * 2, rad = 65 + seeded(i + 205) * 230;
            pts.push(Math.cos(angle) * rad, 35 + seeded(i + 793) * 170, Math.sin(angle) * rad - 85);
        }
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
        this.starMaterial = new THREE.PointsMaterial({ color: 0xcfeeff, size: 0.5, sizeAttenuation: true, transparent: true, opacity: 0.83, depthWrite: false });
        this.root.add(new THREE.Points(geometry, this.starMaterial));
        // Distinct visual artifact above the future building: a ring, not an invented star system.
        const ring = new THREE.Group();
        ring.position.set(34, 65, -265);
        ring.rotation.set(-0.35, -0.4, 0.37);
        ring.add(this.addMesh(new THREE.Group(), new THREE.TorusGeometry(39, 0.52, 7, 110), new THREE.MeshBasicMaterial({ color: 0x9a3658, transparent: true, opacity: 0.88 })));
        const corona = this.addMesh(ring, new THREE.TorusGeometry(40.5, 0.12, 5, 120), new THREE.MeshBasicMaterial({ color: 0xef8294, transparent: true, opacity: 0.7 }));
        corona.rotation.z = 0.14;
        this.skyRing = ring;
        this.root.add(ring);
    }
    matFor(p) {
        const cached = this.platformMaterials.get(p.phase);
        if (cached)
            return cached;
        let materials;
        switch (p.phase) {
            case 'document':
                materials = { floor: standard(0xd7c8aa, 0.07, 0.83), trim: standard(0x8b6748, 0.76, 0.3), glow: standard(0xf4dfb5, 0.1, 0.4, 0xfac884, 0.25) };
                break;
            case 'rooms':
                materials = { floor: standard(0x383451, 0.34, 0.38), trim: standard(0xa18fe1, 0.64, 0.25), glow: standard(0xb4a5ff, 0.1, 0.43, 0xbfa8ff, 0.7) };
                break;
            case 'monolith':
                materials = { floor: standard(0x151b2b, 0.7, 0.21), trim: standard(0x6b89a8, 0.83, 0.2), glow: standard(0x73d9f6, 0.2, 0.28, BLUE, 0.95) };
                break;
            case 'vnext':
                materials = { floor: standard(0x16232d, 0.6, 0.27), trim: standard(0xb99257, 0.8, 0.28), glow: standard(0x72e1e6, 0.3, 0.22, BLUE, 1.2) };
                break;
        }
        this.platformMaterials.set(p.phase, materials);
        return materials;
    }
    makePlatforms() {
        const ornament = new Map();
        PLATFORMS.forEach((p, i) => {
            const { floor, trim, glow } = this.matFor(p);
            const base = this.cube(this.root, p.x, p.top - 0.29, p.z, p.width, 0.58, p.length, floor);
            base.userData.platform = p.id;
            this.cube(this.root, p.x, p.top + 0.02, p.z, p.width - 0.18, 0.037, p.length - 0.18, glow).material = glow;
            // A recessed center walkway remains readable even in deep atmosphere.
            this.cube(this.root, p.x, p.top + 0.05, p.z, Math.min(2.4, p.width - 1.5), 0.025, p.length - 0.2, floor);
            [-1, 1].forEach(side => {
                this.cube(this.root, p.x + side * (p.width / 2 - 0.13), p.top + 0.1, p.z, 0.17, 0.14, p.length, trim);
                for (let j = 0; j < Math.floor(p.length / 2.8); j++) {
                    const z = p.z - p.length / 2 + 1.4 + j * 2.8;
                    const marks = ornament.get(p.phase) ?? [];
                    marks.push([p.x + side * (p.width / 2 - 0.2), p.top + 0.24, z, 0.14, 0.32, 0.14]);
                    ornament.set(p.phase, marks);
                }
            });
            if (p.phase === 'vnext' || p.phase === 'monolith') {
                for (let j = 0; j < Math.floor(p.length / 3.5); j++) {
                    const z = p.z - p.length / 2 + j * 3.5 + 1.8;
                    this.cube(this.root, p.x, p.top + 0.085, z, p.width - 0.65, 0.025, 0.075, trim);
                }
            }
            if (i === 14) {
                this.cube(this.root, p.x, p.top + 0.13, p.z - 4.8, 6.5, 0.17, 0.2, glow);
                this.label(this.root, ['THE VIEW BEYOND THE BUILD'], p.x, p.top + 2.4, p.z - 8.0, 8.4, 1.9, { ink: '#e5ded1', size: 42 });
            }
        });
        for (const [phase, boxes] of ornament)
            this.instanceBoxes(this.root, boxes, this.platformMaterials.get(phase).glow);
    }
    makePaperArchive() {
        const body = standard(PAPER, 0.02, 0.84), edges = standard(0x9f8055, 0.56, 0.43), ink = standard(0x362b38, 0.28, 0.62), light = standard(0xf9ddaa, 0.12, 0.55, 0xfac378, 0.55);
        const bed = this.cube(this.root, 0, -6, -9, 42, 1, 67, standard(0x241d2a, 0.4, 0.8));
        bed.castShadow = false;
        for (let i = 0; i < 20; i++) {
            const side = i % 2 ? -1 : 1, r = seeded(300 + i), z = 12 - i * 2.5;
            const sheet = new THREE.Group();
            sheet.position.set(side * (6.4 + r * 11), 2 + r * 7, z + seeded(i + 61) * 4);
            sheet.rotation.y = side * 0.3;
            this.cube(sheet, 0, 0, 0, 4.7, 0.075, 6.3, body);
            this.cube(sheet, -1.6, 0.055, -1.5, 0.06, 0.015, 2.5, edges);
            this.instanceBoxes(sheet, Array.from({ length: 8 }, (_, l) => [0, 0.07, -2.1 + l * .5, 3.4 - r * .7, .012, .04]), ink);
            const fold = this.addMesh(sheet, new THREE.PlaneGeometry(2.35, 2.7), body, -1.15, 0.3, -1.8);
            fold.rotation.x = -Math.PI / 2.3;
            fold.rotation.z = 0.35;
            this.root.add(sheet);
            this.floaters.push({ obj: sheet, y: sheet.position.y, phase: i * 0.8, amount: 0.16 });
        }
        // Word-columns and binding stitches turn flat page logic into occupied space.
        for (let i = 0; i < 27; i++) {
            const z = 10 - i * 1.6, x = i % 2 ? 4.6 : -4.6;
            const stitch = this.ellipsoid(this.root, x, 0.2, z, 0.055, 0.1, 0.055, edges);
            stitch.castShadow = false;
        }
        for (let i = 0; i < 8; i++) {
            const z = 8 - i * 4.6, side = i % 2 ? 1 : -1;
            const arch = new THREE.Group();
            arch.position.set(side * 8.8, -1, z);
            this.cube(arch, -1.8, 2.4, 0, 0.3, 6, 0.7, body);
            this.cube(arch, 1.8, 2.4, 0, 0.3, 6, 0.7, body);
            this.cube(arch, 0, 5.4, 0, 3.9, 0.22, 0.7, body);
            this.cube(arch, 0, 5.52, 0, 3.9, 0.055, 0.62, light);
            this.root.add(arch);
            this.animations.push({ object: arch, start: new THREE.Vector3(side * 12, -5, z), end: arch.position.clone(), reveal: 0, duration: 9 });
        }
        this.label(this.root, ['MUSEUM OF ME', 'BEFORE THERE WERE WALLS'], 0, 8.5, 10, 9.5, 2.4, { ink: '#ffecd2', size: 53 });
        this.label(this.root, ['A place began as an interactive document.'], 0, 5.9, 2, 8.2, 1.35, { ink: '#ceb79d', size: 38 });
        this.label(this.root, ['Content arranged by page', 'not yet by space'], 0, 7.2, -25, 7.5, 1.9, { ink: '#ffeddb', size: 46 });
        for (let i = 0; i < 7; i++) {
            const fold = new THREE.Group();
            const z = -4 - i * 4.0;
            const leaf = this.cube(fold, 0, 0, 0, 4.6, 0.05, 3.3, body);
            this.cube(fold, 0, 0.047, 0, 3.8, 0.03, 0.045, edges);
            fold.position.set((i % 2 ? -1 : 1) * 5.0, 1.6, z);
            fold.rotation.y = (i % 2 ? -1 : 1) * 0.24;
            this.root.add(fold);
            this.animations.push({ object: fold, start: fold.position.clone().add(new THREE.Vector3(0, -2, 0)), end: fold.position.clone(), rotationStart: new THREE.Euler(0, 0.8, 0), rotationEnd: new THREE.Euler(0, fold.rotation.y, 0), reveal: 0, duration: 12 });
            leaf.castShadow = true;
        }
    }
    makeSeparateRooms() {
        const stone = standard(0x34334b, 0.36, 0.48), trim = standard(0xb6a8db, 0.7, 0.23), glass = new THREE.MeshPhysicalMaterial({ color: 0x9787cf, transparent: true, opacity: 0.24, metalness: 0.3, roughness: 0.19, transmission: 0.28, side: THREE.DoubleSide, depthWrite: false });
        const light = standard(0x997cda, 0.1, 0.42, AMETHYST, 0.82);
        for (let i = 0; i < 8; i++) {
            const z = -39 - i * 5.1, side = i % 2 ? -1 : 1;
            const room = new THREE.Group();
            const w = 5.3, h = 6.1, d = 7;
            this.cube(room, 0, 0, 0, w, 0.42, d, stone);
            this.cube(room, -w / 2, h / 2, 0, 0.3, h, d, stone);
            this.cube(room, w / 2, h / 2, 0, 0.3, h, d, stone);
            this.cube(room, 0, h / 2, -d / 2, w, h, 0.18, glass);
            for (let j = 0; j < 3; j++)
                this.cube(room, -2 + j * 2, 5.95, 0, 0.15, 0.14, d, trim);
            this.cube(room, 0, 6.15, 0, w + 0.3, 0.1, d, light);
            const x = side * (9 + seeded(90 + i) * 4);
            const endX = side * (5.3 + seeded(i + 800) * 1.9);
            room.position.set(endX, 1.0 + seeded(i + 57) * 2, z);
            room.rotation.y = side * 0.15;
            this.root.add(room);
            this.animations.push({ object: room, start: new THREE.Vector3(x, 7 + seeded(i + 12) * 9, z + 2), end: room.position.clone(), reveal: 1, duration: 16 });
        }
        const dust = standard(0xc9b1ff, 0, 0.55, 0x9c91f4, 1.6);
        for (let i = 0; i < 40; i++) {
            const a = seeded(i + 51) * 6.283, x = (seeded(i + 15) - 0.5) * 42, z = -34 - seeded(i + 222) * 44;
            const mesh = this.ellipsoid(this.root, x, 4 + seeded(i + 31) * 15, z, 0.035, 0.035, 0.035, dust);
            this.floaters.push({ obj: mesh, y: mesh.position.y, phase: a, amount: 0.2 });
        }
        this.label(this.root, ['THE FIRST RELIQUARY', 'SCENES WITHOUT A SINGLE PATH'], 0, 9, -36, 10.0, 2.6, { ink: '#d5c3ff', size: 52 });
        this.label(this.root, ['The rooms begin to find one another.'], 0, 8, -61, 9.0, 1.35, { ink: '#ded2ff', size: 36 });
        // Glass threads are a metaphor for emerging continuity, not walkable colliders.
        for (let i = 0; i < 9; i++) {
            const z = -38 - i * 4.4, a = new THREE.Vector3(-7, 5 + seeded(i + 2) * 4, z), b = new THREE.Vector3(7, 6 + seeded(i + 33) * 4, z - 4);
            this.tube(this.root, [a, new THREE.Vector3(0, 9, z - 1.5), b], 0.022, light);
        }
    }
    makeMonolith() {
        const basalt = standard(0x171b29, 0.65, 0.25), face = standard(0x2e354b, 0.6, 0.24), runes = standard(0x80d9ee, 0.11, 0.28, 0x67dafa, 1.4), metal = standard(0x9e91b6, 0.9, 0.19), inner = standard(0x202e45, 0.25, 0.42);
        const tower = new THREE.Group();
        tower.position.set(-12, 1, -100);
        this.cube(tower, 0, 21, 0, 18, 42, 14, basalt);
        this.cube(tower, 0, 21, 7.02, 17.3, 41.2, 0.17, face);
        for (let n = 0; n < 22; n++) {
            this.cube(tower, -7.5 + n * 0.72, 22.1, 7.16, 0.055, 35 + seeded(n + 22) * 6, 0.07, n % 6 === 0 ? runes : metal);
        }
        for (let n = 0; n < 33; n++) {
            const x = -7.5 + seeded(n + 17) * 15, y = 4 + seeded(n + 93) * 36;
            const bar = this.cube(tower, x, y, 7.3, 0.06, 0.35 + seeded(n + 123) * 2, 0.07, runes);
            bar.rotation.z = (seeded(n + 37) - 0.5) * 0.12;
        }
        const opening = this.cube(tower, 0, 9, 7.3, 8, 12, 0.12, inner);
        opening.receiveShadow = false;
        for (let n = 0; n < 9; n++) {
            this.cube(tower, 0, 3.5 + n * 1.4, 7.42, 7.5, 0.038, 0.09, runes);
        }
        this.cube(tower, 0, 43, 0, 20, 0.4, 16, metal);
        for (let i = 0; i < 4; i++) {
            const a = new THREE.Vector3(-8.7 + i * 5.8, 0.5, 7.9), b = new THREE.Vector3(-8.7 + i * 5.8, 46, 7.9);
            this.line(tower, a, b, 0.11, runes);
        }
        this.root.add(tower);
        this.litArchitectures.push(tower);
        this.animations.push({ object: tower, start: new THREE.Vector3(-12, -47, -100), end: tower.position.clone(), reveal: 2, duration: 15 });
        // Archival bridges and monolithic buttresses frame the climb.
        for (let i = 0; i < 8; i++) {
            const z = -79 - i * 5.1, side = i % 2 ? 1 : -1;
            this.cube(this.root, side * 7.1, 4.8 + i * 0.3, z, 1.1, 7.5, 1.2, basalt);
            this.cube(this.root, side * 7.1, 8.6 + i * 0.3, z, 1.3, 0.17, 1.3, runes);
        }
        for (let i = 0; i < 9; i++) {
            const x = i % 2 ? 9.6 : -9.6, z = -79 - i * 4.7;
            const shaft = this.cube(this.root, x, 10, z, 0.35, 15, 0.35, face);
            const halo = this.addMesh(this.root, new THREE.TorusGeometry(0.8, 0.06, 7, 35), runes, x, 17.8, z);
            halo.rotation.x = Math.PI / 2;
            shaft.castShadow = false;
        }
        this.label(this.root, ['THE RESTORED RELIQUARY', 'AN ENTIRE THREE.JS WORLD IN ONE FILE'], 2, 11.5, -80, 10.8, 3.0, { ink: '#ccedff', size: 48 });
        this.label(this.root, ['Its ambition survived.', 'Its architecture had to change.'], 2, 10.5, -113, 9.4, 2.4, { ink: '#b5dceb', size: 44 });
    }
    makeBuildingSite() {
        const dark = standard(0x101c28, 0.68, 0.3), black = standard(0x0b121c, 0.52, 0.37), gold = standard(0xc1a064, 0.86, 0.24), glass = new THREE.MeshPhysicalMaterial({ color: 0x83d9f1, transparent: true, opacity: 0.43, roughness: 0.19, metalness: 0.62, side: THREE.DoubleSide, depthWrite: false }), azure = standard(0x66cddd, 0.15, 0.21, BLUE, 1.2);
        for (let i = 0; i < 12; i++) {
            const z = -122 - i * 5.7, side = i % 2 ? -1 : 1;
            const gantry = new THREE.Group();
            gantry.position.set(side * 7.3, 0, z);
            this.cube(gantry, 0, 6.7, 0, 0.3, 13, 0.3, gold);
            this.cube(gantry, -side * 3.2, 13.4, 0, 6.4, 0.25, 0.3, gold);
            this.cube(gantry, -side * 3.2, 13.51, 0, 6.4, 0.05, 0.36, azure);
            this.root.add(gantry);
            this.animations.push({ object: gantry, start: gantry.position.clone().add(new THREE.Vector3(0, -13, 0)), end: gantry.position.clone(), reveal: 3, duration: 16 });
        }
        // A recognizable but explicitly non-measured conceptual exterior of vNext.
        const site = new THREE.Group();
        site.position.set(0, -9, -253);
        const island = standard(0x19272a, 0, 0.95), moss = standard(0x273b37, 0, 0.99), stone = standard(0x475154, 0.07, 0.92), water = new THREE.MeshPhysicalMaterial({ color: 0x0c526c, roughness: 0.14, metalness: 0.35, transparent: true, opacity: 0.69, clearcoat: 0.75, side: THREE.DoubleSide });
        const waterSurface = this.addMesh(site, new THREE.CylinderGeometry(105, 105, 0.5, 96), water, 0, -2, 0);
        waterSurface.receiveShadow = true;
        this.addMesh(site, new THREE.CylinderGeometry(75, 79, 6.3, 70), island, 0, -1.4, 0);
        this.addMesh(site, new THREE.CylinderGeometry(68, 72, 0.6, 70), moss, 0, 2, 0);
        const foundation = new THREE.Group();
        site.add(foundation);
        // The central rotunda is legible in silhouette, with four large wings and two smaller projections.
        this.addMesh(foundation, new THREE.CylinderGeometry(13, 14, 11, 32), black, 0, 9, 0);
        this.addMesh(foundation, new THREE.CylinderGeometry(13.7, 13.7, 0.45, 32), gold, 0, 15, 0);
        this.addMesh(foundation, new THREE.SphereGeometry(12.8, 40, 18, 0, 2 * Math.PI, 0, Math.PI / 2), glass, 0, 15.2, 0);
        this.addMesh(foundation, new THREE.TorusGeometry(13.9, 0.5, 8, 54), azure, 0, 15.0, 0).rotation.x = Math.PI / 2;
        const wings = [
            { x: 0, z: -26, w: 16, d: 32, h: 13 },
            { x: 0, z: 26, w: 16, d: 31, h: 13 },
            { x: -26, z: 0, w: 30, d: 16, h: 13 },
            { x: 26, z: 0, w: 30, d: 16, h: 13 },
            { x: -22, z: -22, w: 15, d: 13, h: 11 },
            { x: 22, z: 22, w: 15, d: 13, h: 11 }
        ];
        wings.forEach((w, i) => {
            const group = new THREE.Group();
            group.position.set(w.x, 0, w.z);
            this.cube(group, 0, 8, 0, w.w, w.h, w.d, dark);
            this.cube(group, 0, 8 + w.h / 2 + 0.1, 0, w.w + 1.2, 0.25, w.d + 1.2, gold);
            const windows = [];
            for (let j = 0; j < Math.floor(w.d / 4); j++) {
                windows.push([-w.w / 2 + 0.04, 7.5, -w.d / 2 + 2.2 + j * 3.8, .13, 5.0, 1.5]);
                windows.push([w.w / 2 - 0.04, 7.5, -w.d / 2 + 2.2 + j * 3.8, .13, 5.0, 1.5]);
            }
            for (let j = 0; j < Math.floor(w.w / 4); j++) {
                windows.push([-w.w / 2 + 2.2 + j * 3.8, 7.4, -w.d / 2 + .04, 1.5, 4.7, .13]);
                windows.push([-w.w / 2 + 2.2 + j * 3.8, 7.4, w.d / 2 - .04, 1.5, 4.7, .13]);
            }
            this.instanceBoxes(group, windows, azure);
            foundation.add(group);
            this.animations.push({ object: group, start: group.position.clone().add(new THREE.Vector3((i % 2 ? 1 : -1) * 15, -12, i % 2 ? 17 : -17)), end: group.position.clone(), reveal: 3, duration: 25 });
        });
        // Physical landmarks: south arrival axis, pier, east lagoon, northwest gold spire, rear sanctuary.
        this.cube(site, 0, 2.25, 67, 9.0, 0.22, 26, stone);
        for (let i = 0; i < 14; i++)
            this.cube(site, 0, 2.42, 54 + i * 2, 0.16, 0.05, 1.15, azure);
        this.cube(site, 0, 1.6, 82, 5.5, 0.24, 35, standard(0x5d5248, 0.15, 0.8));
        const lagoon = this.ellipsoid(site, 34, 1.98, 30, 23, 0.18, 17, water);
        lagoon.receiveShadow = true;
        const spire = this.addMesh(site, new THREE.CylinderGeometry(0.3, 3.5, 27, 8), gold, -35, 16, -30);
        spire.castShadow = true;
        this.addMesh(site, new THREE.ConeGeometry(2.0, 10, 8), azure, -35, 34, -30);
        this.addMesh(site, new THREE.CylinderGeometry(7, 7.5, 6, 16), dark, -2, 5, -50);
        // Deliberate visible construction: some framework and incompletely clad elements remain.
        for (let i = 0; i < 26; i++) {
            const x = -46 + (i % 9) * 11, z = -33 + Math.floor(i / 9) * 25;
            if (Math.abs(x) < 15 && Math.abs(z) < 22)
                continue;
            const h = 11 + seeded(i + 5) * 17;
            this.cube(site, x, 2 + h / 2, z, 0.28, h, 0.28, gold);
            this.cube(site, x, 2 + h, z, 2.1, 0.18, 2.1, gold);
        }
        const treeTrunk = standard(0x433428, 0, 0.95), treeLeaf = standard(0x182f2b, 0, 0.96);
        const treeSources = [];
        for (let i = 0; i < 100; i++) {
            const theta = seeded(i + 711) * Math.PI * 2, r = 43 + seeded(i + 19) * 26;
            const x = Math.cos(theta) * r, z = Math.sin(theta) * r;
            if (x > 18 && z > 10)
                continue;
            const height = 3.8 + seeded(i + 109) * 7;
            treeSources.push({ x, z, h: height, r: 2.7 + height * .09, angle: seeded(i + 31) * 3 });
        }
        const stemBatch = new THREE.InstancedMesh(new THREE.CylinderGeometry(.38, .55, 1, 5), treeTrunk, treeSources.length);
        const leafBatch = new THREE.InstancedMesh(new THREE.ConeGeometry(1, 1, 6), treeLeaf, treeSources.length);
        const obj = new THREE.Object3D();
        treeSources.forEach((tree, i) => {
            obj.position.set(tree.x, 2 + tree.h / 2, tree.z);
            obj.scale.set(1, tree.h, 1);
            obj.rotation.set(0, 0, 0);
            obj.updateMatrix();
            stemBatch.setMatrixAt(i, obj.matrix);
            obj.position.set(tree.x, 4.8 + tree.h, tree.z);
            obj.scale.set(tree.r, 6 + tree.h * .6, tree.r);
            obj.rotation.y = tree.angle;
            obj.updateMatrix();
            leafBatch.setMatrixAt(i, obj.matrix);
        });
        stemBatch.instanceMatrix.needsUpdate = true;
        leafBatch.instanceMatrix.needsUpdate = true;
        stemBatch.castShadow = false;
        leafBatch.castShadow = false;
        site.add(stemBatch, leafBatch);
        this.root.add(site);
        this.litArchitectures.push(site);
        this.label(this.root, ['MUSEUM OF ME vNEXT', 'AN EVOLVING BUILDING, NOT A FINISHED RELEASE'], 0, 13.4, -139, 12.7, 2.9, { ink: '#daf7f4', size: 46 });
        this.label(this.root, ['ONE CONTINUOUS PLACE', 'THE RELIQUARY ROTUNDA + SIX WINGS'], 0, 12.7, -164, 10.4, 2.6, { ink: '#e7d4b4', size: 50 });
        this.label(this.root, ['INTERPRETIVE MODEL', 'NOT A MEASURED REPLICA'], 0, 8.7, -199, 11.8, 2.6, { ink: '#fff3d4', size: 52 });
        // Wisps of construction beams curl over the route, without affecting collision.
        for (let i = 0; i < 10; i++) {
            const z = -130 - i * 6.0, side = i % 2 ? 1 : -1;
            this.tube(this.root, [new THREE.Vector3(side * 7, 3, z + 4), new THREE.Vector3(side * 10, 13, z), new THREE.Vector3(side * 5, 19, z - 3), new THREE.Vector3(0, 15, z - 4)], 0.065, azure);
        }
    }
    makeTransitions() {
        const rings = [{ z: -34, c: 0xaf97ee, y: 6.0 }, { z: -77, c: 0x84d4ff, y: 7.2 }, { z: -123, c: 0xf0cc91, y: 7.2 }];
        for (let i = 0; i < rings.length; i++) {
            const item = rings[i], mat = new THREE.MeshBasicMaterial({ color: item.c, transparent: true, opacity: 0.74, side: THREE.DoubleSide });
            const glow = new THREE.MeshBasicMaterial({ color: item.c, transparent: true, opacity: 0.09, side: THREE.DoubleSide, depthWrite: false });
            this.addMesh(this.root, new THREE.TorusGeometry(5.0, 0.10, 7, 72), mat, 0, item.y, item.z);
            this.addMesh(this.root, new THREE.TorusGeometry(5.3, 0.48, 7, 72), glow, 0, item.y, item.z);
            for (let a = 0; a < 10; a++) {
                const angle = a * 2 * Math.PI / 10;
                const mesh = this.cube(this.root, Math.sin(angle) * 5, item.y + Math.cos(angle) * 5, item.z, 0.15, 0.48, 0.3, standard(item.c, 0.4, 0.3, item.c, 0.55));
                mesh.rotation.z = -angle;
            }
        }
    }
    pulse(x, y, z, kind) { this.art.pulse(x, y, z, kind); }
    setLowEffects(low) { this.art.setLowEffects(low); this.finish.setLowEffects(low); }
    resetVisuals() { this.art.reset(); this.finish.reset(); }
    setProgress(z) {
        this.progression = z;
        const next = z <= PHASES[3].fromZ ? 3 : z <= PHASES[2].fromZ ? 2 : z <= PHASES[1].fromZ ? 1 : 0;
        this.currentPhase = next;
    }
    update(elapsed, reducedMotion) {
        const z = this.progression;
        this.art.update(elapsed, z, reducedMotion);
        this.finish.update(z, elapsed, reducedMotion);
        for (const a of this.animations) {
            // Phase cues depend on traversal, not time alone: stopping preserves the scene.
            let trigger = a.reveal === 0 ? 9 : a.reveal === 1 ? -31 : a.reveal === 2 ? -75 : -121;
            let progress = a.reveal === 0 ? THREE.MathUtils.clamp((trigger - z) / a.duration, 0, 1) : THREE.MathUtils.clamp((trigger - z) / a.duration, 0, 1);
            // Initial page structures are already largely in the world when entering.
            if (a.reveal === 0)
                progress = THREE.MathUtils.clamp((12 - z) / Math.max(a.duration, 9), 0, 1);
            const t = reducedMotion ? (progress > 0 ? 1 : 0) : smooth(progress);
            a.object.position.copy(a.start).lerp(a.end, t);
            if (a.rotationStart && a.rotationEnd) {
                a.object.rotation.set(THREE.MathUtils.lerp(a.rotationStart.x, a.rotationEnd.x, t), THREE.MathUtils.lerp(a.rotationStart.y, a.rotationEnd.y, t), THREE.MathUtils.lerp(a.rotationStart.z, a.rotationEnd.z, t));
            }
        }
        if (!reducedMotion) {
            for (const f of this.floaters)
                f.obj.position.y = f.y + Math.sin(elapsed * 0.8 + f.phase) * f.amount;
            if (this.skyRing)
                this.skyRing.rotation.z = Math.sin(elapsed * 0.06) * 0.07 + 0.37;
            if (this.starMaterial)
                this.starMaterial.opacity = 0.78 + Math.sin(elapsed * 0.12) * 0.09;
        }
        else {
            for (const f of this.floaters)
                f.obj.position.y = f.y;
        }
        this.currentMix = smooth(this.currentMix + 0.01);
        if (this.keyLight)
            this.keyLight.color.lerp(this.lightStops[this.currentPhase], 0.008);
        if (this.scene.fog && this.scene.fog instanceof THREE.FogExp2) {
            this.scene.fog.color.lerp(this.fogStops[this.currentPhase], 0.022);
        }
    }
    dispose() {
        this.art.dispose();
        this.finish.dispose();
        const geometries = new Set();
        const materials = new Set();
        const shadowMaps = new Set();
        this.scene.traverse(obj => {
            if (obj instanceof THREE.Mesh || obj instanceof THREE.Points || obj instanceof THREE.Line) {
                geometries.add(obj.geometry);
                const ms = Array.isArray(obj.material) ? obj.material : [obj.material];
                for (const m of ms)
                    materials.add(m);
            }
            if ((obj instanceof THREE.DirectionalLight || obj instanceof THREE.SpotLight || obj instanceof THREE.PointLight) && obj.shadow?.map) {
                if (obj.shadow.map.texture)
                    shadowMaps.add(obj.shadow.map.texture);
                obj.shadow.map.dispose();
            }
        });
        geometries.forEach(g => g.dispose());
        materials.forEach(m => m.dispose());
        shadowMaps.forEach(t => t.dispose());
        this.ownedTextures.forEach(t => t.dispose());
        this.ownedTextures.clear();
        this.scene.clear();
        this.animations = [];
        this.floaters = [];
        this.skyRing = null;
        this.starMaterial = null;
    }
}
