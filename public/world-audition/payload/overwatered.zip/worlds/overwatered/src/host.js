/** Optional host-driven bridge, never a direct import of the production museum. */
export const EXHIBIT_ID = 'E31';
export function createMuseumSession(host = (typeof window === 'undefined' ? undefined : window.__MUSEUM_POCKET_HOST__)) {
    const realHost = Boolean(host);
    const visitorSnapshot = host ? host.captureVisitorState() : Object.freeze({ mock: true, exhibitId: 'E31', wing: 'Story Worlds', position: { x: 12, y: 2, z: 31 }, orientation: 1.2, journalOpen: false });
    return { realHost, visitorSnapshot, async returnToMuseum(result) {
            const payload = { ...result, exhibitId: EXHIBIT_ID, pocketWorld: 'breath-of-the-wildly-overwatered', visitorSnapshot };
            if (host)
                await host.returnToMuseum(payload);
            return payload;
        } };
}
