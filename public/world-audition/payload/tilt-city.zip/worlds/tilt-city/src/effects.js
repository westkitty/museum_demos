import * as THREE from 'three';
import { GATE_CENTERS, GESTURES } from './domain.js';
const CAPACITY = 210;
const ABSENT = 9999;
/** One pooled draw call for all spectacle; nothing spawned survives a restart. */
export class CityEffects {
    particles = [];
    positions = new Float32Array(CAPACITY * 3);
    colors = new Float32Array(CAPACITY * 3);
    geometry = new THREE.BufferGeometry();
    material;
    points;
    texture;
    cursor = 0;
    state = 0x1d540ca7;
    reduced = false;
    mode = 'high';
    footstepDelay = 0;
    constructor(scene) {
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const c = canvas.getContext('2d');
        if (c) {
            const g = c.createRadialGradient(32, 32, 1, 32, 32, 32);
            g.addColorStop(0, 'rgba(255,255,255,1)');
            g.addColorStop(.18, 'rgba(255,255,255,.96)');
            g.addColorStop(.52, 'rgba(255,255,255,.34)');
            g.addColorStop(1, 'rgba(255,255,255,0)');
            c.fillStyle = g;
            c.fillRect(0, 0, 64, 64);
        }
        this.texture = new THREE.CanvasTexture(canvas);
        this.texture.colorSpace = THREE.SRGBColorSpace;
        for (let i = 0; i < CAPACITY; i++) {
            this.particles.push({ alive: 0, age: 0, life: 1, x: ABSENT, y: ABSENT, z: ABSENT, vx: 0, vy: 0, vz: 0, color: new THREE.Color() });
            this.positions[i * 3] = ABSENT;
            this.positions[i * 3 + 1] = ABSENT;
            this.positions[i * 3 + 2] = ABSENT;
            this.colors[i * 3] = 1;
            this.colors[i * 3 + 1] = 1;
            this.colors[i * 3 + 2] = 1;
        }
        const pos = new THREE.BufferAttribute(this.positions, 3);
        pos.setUsage(THREE.DynamicDrawUsage);
        const col = new THREE.BufferAttribute(this.colors, 3);
        col.setUsage(THREE.DynamicDrawUsage);
        this.geometry.setAttribute('position', pos);
        this.geometry.setAttribute('color', col);
        this.geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(80, 20, -10), 1e5);
        this.material = new THREE.PointsMaterial({ map: this.texture, size: 1.05, vertexColors: true, transparent: true, opacity: .88, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true, toneMapped: false });
        this.points = new THREE.Points(this.geometry, this.material);
        this.points.frustumCulled = false;
        scene.add(this.points);
    }
    setComfort(reduced) { this.reduced = reduced; if (reduced)
        this.clear(); }
    setQuality(mode) { this.mode = mode; this.material.size = mode === 'eco' ? .82 : 1.05; }
    random() {
        this.state ^= this.state << 13;
        this.state ^= this.state >>> 17;
        this.state ^= this.state << 5;
        return (this.state >>> 0) / 4294967296;
    }
    spawn(x, y, z, base, speed, up, life) {
        const i = this.cursor;
        this.cursor = (this.cursor + 1) % CAPACITY;
        const p = this.particles[i];
        const theta = this.random() * Math.PI * 2;
        const radius = this.random() * speed;
        p.alive = 1;
        p.age = 0;
        p.life = life * (.64 + this.random() * .56);
        p.x = x;
        p.y = y;
        p.z = z;
        p.vx = Math.cos(theta) * radius;
        p.vy = up + (this.random() - .35) * speed;
        p.vz = Math.sin(theta) * radius * .62;
        p.color.copy(base).lerp(new THREE.Color(0xffffff), this.random() * .62);
    }
    burst(x, y, z, color, count, speed, up, life) {
        if (this.reduced)
            return;
        const n = Math.floor(count * (this.mode === 'eco' ? .48 : 1));
        const tint = new THREE.Color(color);
        for (let i = 0; i < n; i++)
            this.spawn(x, y, z, tint, speed, up, life);
    }
    gateStart(index) { this.burst(GATE_CENTERS[index], 3, 0, GESTURES[index].color, 66, 7, 2.2, 1.25); }
    gateLock(index) { this.burst(GATE_CENTERS[index], .25, 0, GESTURES[index].color, 115, 9, 4.2, 1.7); }
    jump(x, z) { this.burst(x, .17, z, 0xb6faff, 19, 2.0, .5, .55); }
    land(x, z) { this.burst(x, .14, z, 0x7adad9, 22, 1.55, .22, .5); }
    checkpoint(index) { this.burst(GATE_CENTERS[index] - 10, .4, 0, GESTURES[index].color, 35, 3.1, 2.0, .9); }
    /** Ground-contact flecks are rate limited and share the existing capped pool. */
    footsteps(x, z, vx, grounded, dt) {
        this.footstepDelay = Math.max(0, this.footstepDelay - dt);
        if (!grounded || Math.abs(vx) < 3 || this.footstepDelay > 0)
            return;
        this.footstepDelay = this.mode === 'eco' ? .24 : .14;
        const chapter = Math.max(0, Math.min(3, Math.floor((x - 10) / 40)));
        this.burst(x, .13, z, GESTURES[chapter].color, 5, 1.1, .13, .26);
    }
    finish() { this.burst(170, 6, -2, 0xacf8cb, 210, 11, 7.8, 2.2); }
    update(dt, paused) {
        if (paused || this.reduced)
            return;
        const drag = Math.pow(.15, dt);
        for (let i = 0; i < CAPACITY; i++) {
            const p = this.particles[i];
            const off = i * 3;
            if (!p.alive) {
                this.positions[off] = ABSENT;
                this.positions[off + 1] = ABSENT;
                this.positions[off + 2] = ABSENT;
                continue;
            }
            p.age += dt;
            if (p.age > p.life) {
                p.alive = 0;
                this.positions[off] = ABSENT;
                this.positions[off + 1] = ABSENT;
                this.positions[off + 2] = ABSENT;
                continue;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.vx *= drag;
            p.vz *= drag;
            p.vy -= 2.9 * dt;
            this.positions[off] = p.x;
            this.positions[off + 1] = p.y;
            this.positions[off + 2] = p.z;
            const brightness = Math.max(.03, 1 - p.age / p.life);
            this.colors[off] = p.color.r * brightness;
            this.colors[off + 1] = p.color.g * brightness;
            this.colors[off + 2] = p.color.b * brightness;
        }
        this.geometry.attributes.position.needsUpdate = true;
        this.geometry.attributes.color.needsUpdate = true;
    }
    clear() {
        this.footstepDelay = 0;
        for (let i = 0; i < CAPACITY; i++) {
            this.particles[i].alive = 0;
            this.positions[i * 3] = ABSENT;
            this.positions[i * 3 + 1] = ABSENT;
            this.positions[i * 3 + 2] = ABSENT;
        }
        this.geometry.attributes.position.needsUpdate = true;
    }
    dispose() { this.points.parent?.remove(this.points); this.geometry.dispose(); this.material.dispose(); this.texture.dispose(); }
}
