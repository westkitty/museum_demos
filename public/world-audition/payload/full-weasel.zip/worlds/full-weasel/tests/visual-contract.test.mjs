import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const read = path => readFileSync(new URL(`../${path}`,import.meta.url),'utf8');
const main=read('src/main.ts'), world=read('src/game/world.ts'), fx=read('src/game/visual-fx.ts'), css=read('src/style.css');

test('existing gameplay, controls, save semantics and museum adapter remain byte-identical',()=>{
  const expected=JSON.parse(read('tests/preservation-locks.json'));
  for(const [path,hash] of Object.entries(expected)){
    assert.equal(createHash('sha256').update(read(path)).digest('hex'),hash,path);
  }
});

test('all four traversable scenes plus cabinet receive authored dressing',()=>{
  for(const routine of ['createCabinetDressing','createHubDressing','createClockworkDressing','createConservatoryDressing','createLeverDressing','createThroneDressing']){
    assert.match(world,new RegExp(`this\\.${routine}\\(\\);`),routine);
    assert.match(world,new RegExp(`private ${routine}\\(\\):void`),routine);
  }
});

test('visual events are pooled and gameplay interactions emit feedback',()=>{
  assert.match(fx,/maxSparks = 104/);
  assert.match(fx,/new THREE\.InstancedMesh\(this\.geo,this\.sparkMat,this\.maxSparks\)/);
  assert.match(fx,/reducedMotion \? 0/);
  for(const token of ["'jump'","'land'","'spring'","'mechanism'","'reward'","'finale'","'respawn'"])
    assert.ok(main.includes(token),`missing visual feedback event ${token}`);
  assert.match(world,/this\.confettiMesh=new THREE\.InstancedMesh/);
  assert.match(world,/const sparkleMesh=new THREE\.InstancedMesh/);
});

test('camera, quality tiers and disposal keep expensive effects bounded',()=>{
  assert.match(main,/private readonly cameraRay = new THREE\.Raycaster\(\)/);
  assert.match(main,/Math\.min\(window\.devicePixelRatio\|\|1,cap\)/);
  assert.match(world,/const shadowSize=tier==='high'\?1536:tier==='medium'\?1024:512/);
  assert.match(world,/this\.effects\.dispose\(\)/);
  assert.match(world,/this\.starInstanced\?\.dispose\(\)/);
  assert.match(world,/this\.confettiMesh\.dispose\(\)/);
  assert.match(main,/for\(const geometry of heroGeometry\)geometry\.dispose\(\)/);
});

test('premium HUD remains responsive, accessible and source-specific',()=>{
  for(const id of ['route-ribbon','checkpoint-readout','interaction-cue','touch-controls','pause-button'])assert.ok(main.includes(`id="${id}"`));
  assert.match(main,/aria-live="polite"/);
  assert.match(css,/@media\(max-width:480px\)/);
  assert.match(css, /@media\(prefers-reduced-motion:reduce\)/);
  assert.match(main,/returnToMuseum:.*this\.returnToMuseum\(\)/);
});

test('no remote assets or runtime CDN references introduced',()=>{
  for(const path of ['src/main.ts','src/style.css','src/game/world.ts','src/game/visual-fx.ts']){
    const content=read(path);
    assert.doesNotMatch(content,/https?:\/\//,path);
  }
});
