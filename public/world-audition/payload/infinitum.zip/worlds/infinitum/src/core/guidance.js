import { constellationPower, treeGrowth } from './state.js';
import { causalStage, finaleReady, heartIrrigation } from './simulation.js';
/** Contextual field note. Never changes state, awards progress, or forces a quest order. */
export function fieldNote(s, world) {
    const stage = causalStage(s);
    if (world === 0) {
        if (finaleReady(s) && !s.endingSeen)
            return 'Three scales are resonating. Inspect the altered raindrop to understand why.';
        if (stage === 2)
            return 'Gravity and the old ruins are the last unanswered instruments. X reveals their connection.';
        if (stage === 3)
            return 'The Observatory remembers the inner stars. Inspect its instruments.';
        return 'A mountain horizon hides inside the suspended water. Cross the drop to explore it.';
    }
    if (world === 1) {
        if (heartIrrigation(s) < .48)
            return 'Water remembers the terrain. Sculpt a basin or trace a river toward the Heart Tree.';
        if (treeGrowth(s) < .25)
            return 'The Heart Tree has water. Plant near its roots and let simulated time pass.';
        if (stage < 2)
            return 'New droplets hang among the leaves. Approach the tree and enter the next scale.';
        return 'The valley answers the stars. Inspect the ruins or return to the outer instrument.';
    }
    if (constellationPower(s) === 0)
        return 'Connect the Garden stars. Their completed paths awaken physical islands.';
    if (stage < 3)
        return 'One scale remains unanswered. Return to the outer drop and alter gravity or restore the ruins.';
    return 'The inner astronomy now echoes the Observatory. Return and inspect the original drop.';
}
