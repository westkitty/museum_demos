/**
 * Three.js first-person convention: zero yaw looks down world -Z.
 * Positive yaw rotates the camera LEFT (forward X becomes negative).
 */
export function viewForward(yaw) {
    return { x: -Math.sin(yaw), z: -Math.cos(yaw) };
}
export function viewRight(yaw) {
    return { x: Math.cos(yaw), z: -Math.sin(yaw) };
}
export function movementVector(yaw, strafe, forward) {
    const m = Math.max(1, Math.hypot(strafe, forward));
    const f = viewForward(yaw), r = viewRight(yaw);
    return { x: (r.x * strafe + f.x * forward) / m, z: (r.z * strafe + f.z * forward) / m };
}
