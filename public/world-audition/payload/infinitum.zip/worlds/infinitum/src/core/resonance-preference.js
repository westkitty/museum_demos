const KEY = 'infinitum.resonance.v1';
export function readResonancePreference() {
    try {
        return localStorage.getItem(KEY) === 'true';
    }
    catch {
        return false;
    }
}
export function writeResonancePreference(on) {
    try {
        localStorage.setItem(KEY, String(on));
    }
    catch { /* The lens remains usable without storage. */ }
}
