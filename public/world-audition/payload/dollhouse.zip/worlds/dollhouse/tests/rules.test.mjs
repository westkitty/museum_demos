import test from 'node:test';import assert from 'node:assert/strict';
// TypeScript rules are compiled on the fly by Node's native type stripping.
import {act,allDone,initialState,pickup} from '../src/rules.ts';
test('moderation cannot mutate synthetic record',()=>{const s=initialState();s.selected='moderation';act(s,'record');assert.equal(s.entries[0].forgotten,true);assert.equal(s.events.length,1)});
test('role permissions, provenance and sequential victory',()=>{const s=initialState();assert.match(act(s,'memory'),/Recover/);assert.match(act(s,'record'),/RECOVERED/);assert.equal(s.entries[0].forgotten,false);s.selected='companion';assert.match(act(s,'memory'),/APPENDED/);assert.equal(s.entries[0].marks.length,1);assert.match(act(s,'door'),/Companion/);s.selected='continuity';assert.match(pickup(s),/picked up/);assert.match(act(s,'door'),/RESTORED/);assert.equal(allDone(s),true);assert.equal(s.entries[0].marks.length,1)});
test('append-only marker cannot duplicate',()=>{const s=initialState();act(s,'record');s.selected='companion';act(s,'memory');act(s,'memory');assert.equal(s.entries[0].marks.length,1)});
