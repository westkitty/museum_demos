import * as THREE from 'three';
import { createScenicHub, createScenicParable, createScenicAcre, mineralTexture, leafBladeGeometry } from './scenic.js';
const C = (n) => new THREE.Color(n);
const m = (color, metalness = 0.12, roughness = 0.6, emissive = 0, emission = 0) => new THREE.MeshStandardMaterial({ color: C(color), metalness, roughness, emissive: C(emissive), emissiveIntensity: emission, flatShading: false });
const basic = (color, opacity = 1) => new THREE.MeshBasicMaterial({ color: C(color), transparent: opacity < 1, opacity, depthWrite: opacity >= 1, side: THREE.DoubleSide });
const AMBER = m(0xe0b979, 0.76, 0.28, 0x9b6424, 0.23);
const INK = m(0x201c35, 0.38, 0.63);
const LILAC = m(0x51436e, 0.18, 0.8);
const GOLD = m(0xf3d48a, 0.68, 0.27, 0xe3a84b, 0.32);
const OBSIDIAN = m(0x1a2031, 0.46, 0.54);
const IVORY = m(0xe9e1cc, 0.15, 0.72);
const JADE = m(0x1d755c, 0.2, 0.47);
const FOLIAGE = [m(0x206b59, .05, .57), m(0x318773, .08, .5), m(0x65ba86, .05, .63), m(0x8ed5a5, .04, .5)];
const CROWN_LEAF_GEOMETRY = leafBladeGeometry();
const CROWN_LEAF_MATERIAL = new THREE.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, side: THREE.DoubleSide, metalness: .05, roughness: .58 });
const CROWN_TRUNK_MATERIAL = m(0x42634b, .08, .89);
const CROWN_FLOWER_GEOMETRY = new THREE.IcosahedronGeometry(.35, 1);
const LAMP = m(0xc2ffcf, .28, .31, 0x68ffba, 1.45);
const PARABLE_PAVING = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: .12, roughness: .77, map: mineralTexture(20262, [95, 78, 130], 'stone') });
const ACRE_PAVING = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: .07, roughness: .69, map: mineralTexture(88732, [36, 103, 84], 'soil') });
function seeded(seed) { let state = seed >>> 0; return () => ((state = (Math.imul(1664525, state) + 1013904223) >>> 0) / 4294967296); }
function mesh(parent, geometry, material, x = 0, y = 0, z = 0) {
    const o = new THREE.Mesh(geometry, material);
    o.position.set(x, y, z);
    o.castShadow = true;
    o.receiveShadow = true;
    parent.add(o);
    return o;
}
function box(parent, w, h, d, material, x = 0, y = 0, z = 0) { return mesh(parent, new THREE.BoxGeometry(w, h, d), material, x, y, z); }
function cyl(parent, rt, rb, h, material, x = 0, y = 0, z = 0, radial = 12) { return mesh(parent, new THREE.CylinderGeometry(rt, rb, h, radial), material, x, y, z); }
function orb(parent, radius, material, x = 0, y = 0, z = 0, detail = 1) { return mesh(parent, new THREE.IcosahedronGeometry(radius, detail), material, x, y, z); }
function ring(parent, radius, tube, material, x = 0, y = 0, z = 0) { return mesh(parent, new THREE.TorusGeometry(radius, tube, 8, 100), material, x, y, z); }
function line(parent, pts, color, radius = .07, opacity = 1) {
    const curve = new THREE.CatmullRomCurve3(pts);
    return mesh(parent, new THREE.TubeGeometry(curve, Math.max(12, pts.length * 6), radius, 5, false), opacity === 1 ? m(color, .45, .4, color, .3) : basic(color, opacity));
}
function edgeLights(parent, w, d, y, color) {
    const light = basic(color, .74);
    box(parent, w, .055, .09, light, 0, y, -d / 2 + .11);
    box(parent, w, .055, .09, light, 0, y, d / 2 - .11);
    box(parent, .09, .055, d, light, -w / 2 + .11, y, 0);
    box(parent, .09, .055, d, light, w / 2 - .11, y, 0);
}
function groundTile(parent, p, style, random) {
    const g = new THREE.Group();
    g.position.set(p.x, p.y, p.z);
    parent.add(g);
    p.mesh = g;
    const matTop = style === 'stone' ? PARABLE_PAVING : style === 'green' ? ACRE_PAVING : m(0x47434a, .2, .7);
    const matBase = style === 'stone' ? INK : style === 'green' ? m(0x183e40, .3, .66) : OBSIDIAN;
    box(g, p.w, 1.12, p.d, matBase, 0, -.57, 0);
    box(g, p.w - .2, .2, p.d - .2, matTop, 0, -.07, 0);
    box(g, p.w + .08, .13, p.d + .08, style === 'stone' ? AMBER : style === 'green' ? JADE : AMBER, 0, -.21, 0);
    edgeLights(g, p.w - .35, p.d - .35, .04, style === 'stone' ? 0xefc377 : style === 'green' ? 0x9cffe1 : 0xf5dd9b);
    if (style !== 'hub') {
        // Outward-facing decorative strata make jump edges obvious at long camera distances.
        const accent = style === 'stone' ? GOLD : LAMP;
        for (const side of [-1, 1]) {
            box(g, p.w * .76, .10, .11, accent, 0, -.37, side * (p.d * .5 + .02));
            box(g, .10, .10, p.d * .70, accent, side * (p.w * .5 + .02), -.37, 0);
            // No scattered strips: the medallion / vines below provide an intentional pattern.
        }
    }
    // The top surfaces are deliberately engraved, not scattered with random debris.
    // All inlays are decorative and remain outside the authoritative landing test.
    if (style === 'stone') {
        const rr = Math.min(p.w, p.d) * .215;
        const dial = ring(g, rr, .036, AMBER, 0, .052, .05);
        dial.rotation.x = -Math.PI / 2;
        dial.castShadow = false;
        const inner = ring(g, rr * .60, .024, GOLD, 0, .055, .05);
        inner.rotation.x = -Math.PI / 2;
        inner.castShadow = false;
        for (let i = 0; i < 8; i++) {
            const a = i * Math.PI / 4;
            const mark = box(g, .13, .021, .33, i % 2 ? GOLD : LILAC, Math.cos(a) * rr * .79, .064, Math.sin(a) * rr * .79 + .05);
            mark.rotation.y = -a;
            mark.castShadow = false;
        }
        for (const sign of [-1, 1]) {
            const jewel = mesh(g, new THREE.IcosahedronGeometry(.23, 0), GOLD, sign * p.w * .37, .15, -p.d * .36);
            jewel.scale.set(.72, .30, 1.08);
            jewel.castShadow = false;
        }
    }
    else if (style === 'green') {
        const tracery = m(0x73dab0, .21, .54, 0x1d7e5b, .22);
        for (const side of [-1, 1]) {
            const branch = line(g, [new THREE.Vector3(side * p.w * .25, .053, p.d * .31), new THREE.Vector3(side * p.w * .16, .064, 0), new THREE.Vector3(side * p.w * .31, .053, -p.d * .30)], 0x58bd9c, .035, .72);
            branch.castShadow = false;
            for (let i = 0; i < 3; i++) {
                const z = p.d * (.20 - i * .20);
                const blade = orb(g, .31, tracery, side * (p.w * .24 + .25), .077, z, 1);
                blade.scale.set(.95, .09, 1.65);
                blade.rotation.y = side * (i % 2 ? .48 : -.55);
                blade.castShadow = false;
            }
        }
    }
    if (style !== 'hub') {
        const bottom = cyl(g, Math.min(p.w, p.d) * .26, Math.min(p.w, p.d) * .5, 4.0, matBase, 0, -2.65, 0, 7);
        bottom.rotation.z = (random() - .5) * .14;
        for (let i = 0; i < 5; i++) {
            const a = i * Math.PI * 2 / 5;
            const rock = orb(g, .65 + random() * .8, matBase, Math.sin(a) * p.w * .35, -2.4 - random() * 1.2, Math.cos(a) * p.d * .35, 0);
            rock.scale.y = 1.0 + random() * .35;
        }
    }
    if (p.checkpoint) {
        cyl(g, .66, .8, .12, style === 'green' ? LAMP : GOLD, 0, .12, 1.2, 16);
        ring(g, .7, .045, style === 'green' ? LAMP : GOLD, 0, .22, 1.2).rotation.x = -Math.PI / 2;
    }
    return g;
}
function lantern(parent, x, y, z, color, h = 2.5) {
    const g = new THREE.Group();
    g.position.set(x, y, z);
    parent.add(g);
    cyl(g, .14, .24, h, color === 'amber' ? AMBER : JADE, 0, h / 2, 0, 8);
    const light = color === 'amber' ? GOLD : LAMP;
    orb(g, .33, light, 0, h + .2, 0, 1);
    const halo = orb(g, .6, basic(color === 'amber' ? 0xffc66d : 0x8cffe1, .12), 0, h + .2, 0, 1);
    halo.castShadow = false;
    return g;
}
function rockSpire(parent, x, z, height, random, color = OBSIDIAN) {
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    parent.add(g);
    cyl(g, 1.3, 2.9, height, color, 0, height / 2, 0, 5).rotation.y = random() * 6;
    cyl(g, .15, 1.3, height * .5, LILAC, 0, height * 1.23, 0, 5).rotation.z = (random() - .5) * .35;
    for (let i = 0; i < 4; i++) {
        const y = height * (.22 + i * .16);
        box(g, 3.5, .11, 3.5, AMBER, 0, y, 0).rotation.y = i * .35;
    }
    return g;
}
function stoneGate(parent, z, span, height, material = OBSIDIAN) {
    const g = new THREE.Group();
    g.position.z = z;
    parent.add(g);
    for (const s of [-1, 1]) {
        const x = s * span / 2;
        cyl(g, 1.4, 2, height, material, x, height / 2, 0, 8);
        cyl(g, 2.2, 2.2, .5, AMBER, x, height - .4, 0, 10);
        cyl(g, 1.9, 1.9, .24, LILAC, x, height * .37, 0, 10);
        lantern(g, x + (-s * 2), .1, .5, 'amber', 1.8);
    }
    box(g, span + 4, 1.8, 2.8, material, 0, height + 1, 0);
    box(g, span + 4, .18, 3.2, AMBER, 0, height + 1.92, 0);
    box(g, span - 1, .15, 3.2, GOLD, 0, height + .15, 0);
    return g;
}
function floatingShard(parent, x, y, z, scale, material, random) {
    const o = orb(parent, scale, material, x, y, z, 0);
    o.scale.set(.45 + random(), 1.4 + random(), .45 + random());
    o.rotation.set(random(), random() * 6, random());
    return o;
}
function petals(parent, x, y, z, color, random, size = 1) {
    const root = new THREE.Group();
    root.position.set(x, y, z);
    parent.add(root);
    cyl(root, .11, .22, size * .95, JADE, 0, size * .47, 0, 7);
    const blades = new THREE.InstancedMesh(new THREE.SphereGeometry(size * .35, 8, 6), color, 7);
    const scratch = new THREE.Object3D();
    for (let i = 0; i < 7; i++) {
        const a = i * Math.PI * 2 / 7;
        scratch.position.set(Math.cos(a) * size * .34, size, Math.sin(a) * size * .34);
        scratch.scale.set(.9, .22, 1.5);
        scratch.rotation.set(0, -a, 0);
        scratch.updateMatrix();
        blades.setMatrixAt(i, scratch.matrix);
    }
    blades.instanceMatrix.needsUpdate = true;
    blades.castShadow = true;
    root.add(blades);
    orb(root, size * .24, LAMP, 0, size + .09, 0, 1);
    return root;
}
function foliageCrown(parent, x, y, z, s, random) {
    // One instanced crown instead of four independent InstancedMesh render calls per shrub.
    // Each leaf retains a separate stem direction and color without multiplying draw calls.
    const g = new THREE.Group();
    g.position.set(x, y, z);
    parent.add(g);
    cyl(g, s * .16, s * .30, s * 3.0, CROWN_TRUNK_MATERIAL, 0, s * 1.45, 0, 7);
    const crown = new THREE.InstancedMesh(CROWN_LEAF_GEOMETRY, CROWN_LEAF_MATERIAL, 13);
    const scratch = new THREE.Object3D();
    for (let i = 0; i < 13; i++) {
        const a = i * Math.PI * 2 / 13;
        const radius = s * (.5 + random() * .3);
        scratch.position.set(Math.cos(a) * s * .8, s * (2.8 + random() * .85), Math.sin(a) * s * .8);
        scratch.scale.set(radius * .85, radius * 1.25, radius * .62);
        scratch.rotation.set(0, a, (random() - .5) * .4);
        scratch.updateMatrix();
        crown.setMatrixAt(i, scratch.matrix);
        crown.setColorAt(i, FOLIAGE[i % 4].color);
    }
    crown.instanceMatrix.needsUpdate = true;
    if (crown.instanceColor)
        crown.instanceColor.needsUpdate = true;
    crown.castShadow = false;
    crown.receiveShadow = false;
    g.add(crown);
    const blossoms = new THREE.InstancedMesh(CROWN_FLOWER_GEOMETRY, LAMP, 2);
    for (let i = 0; i < 2; i++) {
        scratch.position.set((random() - .5) * s * 2, s * (3.1 + random()), (random() - .5) * s * 2);
        scratch.scale.setScalar(s * (.55 + random() * .45));
        scratch.rotation.set(0, i * Math.PI, 0);
        scratch.updateMatrix();
        blossoms.setMatrixAt(i, scratch.matrix);
    }
    blossoms.instanceMatrix.needsUpdate = true;
    blossoms.castShadow = false;
    g.add(blossoms);
    return g;
}
function leafGeometry(w, d) {
    const segX = 10, segZ = 16;
    const verts = [], indices = [], colors = [];
    const lime = new THREE.Color(0x95fbc1), dark = new THREE.Color(0x116951);
    for (let j = 0; j <= segZ; j++) {
        const t = j / segZ;
        const extent = Math.pow(Math.max(0.04, Math.sin(Math.PI * t)), .63);
        for (let i = 0; i <= segX; i++) {
            const u = i / segX * 2 - 1;
            const x = u * w * .5 * extent;
            const z = (t - .5) * d;
            const y = .06 + .34 * (1 - Math.abs(u)) + .18 * Math.sin(Math.PI * t);
            verts.push(x, y, z);
            const col = dark.clone().lerp(lime, Math.max(0, Math.min(1, .2 + .55 * (1 - Math.abs(u)) + .15 * Math.sin(t * Math.PI))));
            colors.push(col.r, col.g, col.b);
        }
    }
    for (let j = 0; j < segZ; j++)
        for (let i = 0; i < segX; i++) {
            const a = j * (segX + 1) + i, b = a + 1, c = a + segX + 1, e = c + 1;
            indices.push(a, c, b, b, c, e);
        }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return geo;
}
function buildLeaf(parent, p, random) {
    const root = new THREE.Group();
    root.position.set(p.x, p.y - .14, p.z);
    parent.add(root);
    p.mesh = root;
    const geo = leafGeometry(p.w * 1.14, p.d * 1.26);
    const surface = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ side: THREE.DoubleSide, vertexColors: true, metalness: .05, roughness: .4, emissive: 0x104c40, emissiveIntensity: .32 }));
    surface.receiveShadow = true;
    root.add(surface);
    // Midrib and branching veins; still a leaf, not a lattice.
    line(root, [new THREE.Vector3(0, .23, -p.d * .57), new THREE.Vector3(0, .48, 0), new THREE.Vector3(0, .23, p.d * .57)], 0xb3ffe0, .055, .9);
    for (const s of [-1, 1])
        for (let i = 0; i < 4; i++) {
            const z = -p.d * .36 + i * p.d * .22;
            line(root, [new THREE.Vector3(0, .42, z), new THREE.Vector3(s * p.w * .19, .3, z + .9), new THREE.Vector3(s * p.w * .35, .18, z + 1.2)], 0x71dcb3, .024, .7);
        }
    const stalk = line(root, [new THREE.Vector3(0, -.5, p.d * .55), new THREE.Vector3(0, -1, p.d * .8), new THREE.Vector3(0, -2.8, p.d)], 0x3eac7b, .2);
    stalk.castShadow = true;
    for (let i = 0; i < 9; i++) {
        const c = orb(root, .09 + random() * .1, LAMP, (random() - .5) * p.w * .65, .35 + random() * .2, (random() - .5) * p.d * .6, 0);
        c.castShadow = false;
    }
    return root;
}
function makeStars(parent, seed, count, color, min = 70, max = 330) {
    const r = seeded(seed);
    const positions = [];
    for (let i = 0; i < count; i++) {
        const t = r() * Math.PI * 2, p = (r() - .23) * Math.PI * .92, d = min + r() * (max - min);
        positions.push(Math.sin(t) * Math.cos(p) * d, Math.sin(p) * d + 18, Math.cos(t) * Math.cos(p) * d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const points = new THREE.Points(geo, new THREE.PointsMaterial({ color, size: .35, sizeAttenuation: true, transparent: true, opacity: .87, depthWrite: false }));
    parent.add(points);
    return points;
}
export function createHub() {
    const random = seeded(101);
    const group = new THREE.Group();
    const scenery = createScenicHub();
    group.add(scenery.group);
    // The common architecture is explicitly an interpretive museum threshold.
    const deck = cyl(group, 15.3, 16.4, 2.5, OBSIDIAN, 0, -1.3, 0, 52);
    deck.receiveShadow = true;
    cyl(group, 15.4, 15.4, .15, AMBER, 0, -.03, 0, 52);
    cyl(group, 14.9, 14.9, .15, INK, 0, .045, 0, 52);
    ring(group, 14.2, .045, GOLD, 0, .18, 0).rotation.x = -Math.PI / 2;
    for (let i = 0; i < 24; i++) {
        const t = i * Math.PI * 2 / 24;
        const x = Math.cos(t) * 13.35, z = Math.sin(t) * 13.35;
        const o = cyl(group, .3, .43, 1.1, AMBER, x, .5, z, 8);
        o.rotation.z = .04;
        orb(group, .15, GOLD, x, 1.18, z, 0);
    }
    for (let i = 0; i < 9; i++) {
        const t = (i + .5) * Math.PI * 2 / 9;
        const x = Math.sin(t) * 11.9, z = Math.cos(t) * 11.9;
        cyl(group, .8, 1.15, 5.3, OBSIDIAN, x, 2.65, z, 7);
        orb(group, .33, GOLD, x, 5.75, z, 0);
    }
    // A single portal with two literal faces. +Z = Parable; -Z = Starlight Acre.
    const gate = new THREE.Group();
    gate.position.y = 4.6;
    group.add(gate);
    ring(gate, 4.3, .47, OBSIDIAN);
    ring(gate, 4.04, .16, GOLD, 0, 0, .25);
    ring(gate, 4.04, .16, LAMP, 0, 0, -.25);
    ring(gate, 3.6, .05, AMBER, 0, 0, .28);
    ring(gate, 3.6, .05, JADE, 0, 0, -.28);
    for (let i = 0; i < 10; i++) {
        const t = i * Math.PI * 2 / 10;
        const x = Math.cos(t) * 4.31, y = Math.sin(t) * 4.31;
        const gem = orb(gate, .38, i % 2 ? GOLD : LAMP, x, y, 0, 0);
        gem.rotation.y = t;
    }
    // The two opaque living panes preserve each source identity from either viewing face.
    // No opposite-side geometry can show through or imply a shared fictional landscape.
    function portalPane(primary, secondary, accent) {
        return new THREE.ShaderMaterial({
            side: THREE.FrontSide, depthWrite: true,
            uniforms: { time: { value: 0 }, a: { value: new THREE.Color(primary) }, b: { value: new THREE.Color(secondary) }, c: { value: new THREE.Color(accent) } },
            vertexShader: 'varying vec2 uvFace;void main(){uvFace=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
            fragmentShader: `varying vec2 uvFace;uniform float time;uniform vec3 a,b,c;
        void main(){
          vec2 p=(uvFace-.5)*2.;float d=length(p);float angle=atan(p.y,p.x);
          float ripple=sin(d*25.-angle*5.-time*.32)*.5+.5;
          float veil=sin(p.x*10.+sin(p.y*6.+time*.2)*1.5)*.5+.5;
          float o=clamp(.10+.45*ripple+.25*veil,0.,1.);
          vec3 color=mix(a,b,o);
          float glyph=pow(max(0.,sin(18.*d+angle*8.+time*.16)),12.);
          color+=c*(glyph*.19+pow(max(0.,1.-d),8.)*.17);
          color*=.82+.18*smoothstep(1.,.16,d);
          gl_FragColor=vec4(color,1.);
        }`
        });
    }
    const violetMat = portalPane(0x24143e, 0x82488b, 0xcfa477);
    const jadeMat = portalPane(0x073735, 0x16846d, 0x9deac2);
    const violet = mesh(gate, new THREE.CircleGeometry(3.53, 88), violetMat, 0, 0, .09);
    violet.castShadow = false;
    const green = mesh(gate, new THREE.CircleGeometry(3.53, 88), jadeMat, 0, 0, -.09);
    green.rotation.y = Math.PI;
    green.castShadow = false;
    for (const side of [-1, 1]) {
        box(group, 2.6, 1.1, 3.1, OBSIDIAN, -5.3, .53, side * 2);
        box(group, 2.6, .13, 3.4, AMBER, -5.3, 1.16, side * 2);
        box(group, 2.6, 1.1, 3.1, OBSIDIAN, 5.3, .53, side * 2);
        box(group, 2.6, .13, 3.4, AMBER, 5.3, 1.16, side * 2);
        for (let i = 0; i < 6; i++) {
            const angle = i * Math.PI / 3;
            lantern(group, Math.cos(angle) * 10, .13, Math.sin(angle) * 10, side > 0 ? 'amber' : 'green', 1.4);
        }
    }
    makeStars(group, 110, 950, 0xe5f1ec, 45, 210);
    const platforms = [{ id: 'hub', x: 0, z: 0, y: .2, w: 29, d: 29, active: true, solid: true, checkpoint: true }];
    return { id: 'hub', group, platforms, spawn: new THREE.Vector3(0, .2, 9.0), interaction: new THREE.Vector3(0, .2, 0), goal: null, activate: () => { }, reset: () => { }, update: (_dt, elapsed, reduced) => { scenery.update(elapsed, reduced); if (!reduced) {
            gate.rotation.z = Math.sin(elapsed * .34) * .01;
            violetMat.uniforms.time.value = elapsed;
            jadeMat.uniforms.time.value = elapsed;
        } } };
}
export function createParable() {
    const random = seeded(2453), group = new THREE.Group(), platforms = [];
    const scenery = createScenicParable();
    group.add(scenery.group);
    const nodes = [
        ['A0', 0, 18, .2, 16, 16, true, true], ['A1', 0, 3, 1.0, 10, 8, true, false],
        ['A2', -2, -9, 2.0, 9, 8, true, true], ['A3', -2, -22, 3.3, 15, 12, true, true],
        ['A4', 0, -37, 4.5, 9, 9, false, false], ['A5', 2, -50, 5.6, 9, 9, false, true],
        ['A6', 0, -63, 7.0, 11, 10, false, false], ['A7', 0, -76, 8.2, 16, 12, false, true]
    ];
    for (const [id, x, z, y, w, d, active, checkpoint] of nodes) {
        const p = { id, x, z, y, w, d, active, checkpoint };
        platforms.push(p);
        groundTile(group, p, 'stone', random);
        p.mesh.visible = active;
        p.solid = active;
    }
    for (const p of platforms) {
        if (p.id === 'A3' || p.id === 'A7')
            stoneGate(group, p.z, p.w + 7, p.id === 'A3' ? 16 : 22);
        for (const sign of [-1, 1])
            lantern(group, p.x + sign * (p.w * .41), p.y + .05, p.z - p.d * .24, 'amber', 2 + random());
    }
    // Mythic scale: temple corridors, hanging obelisks, gold strata and immense rings.
    for (let i = 0; i < 28; i++) {
        const z = 22 - i * 4.3 - random() * 9;
        const x = (i % 2 ? 1 : -1) * (29 + random() * 54);
        const spire = rockSpire(group, x, z, 13 + random() * 57, random, i % 5 === 0 ? LILAC : OBSIDIAN);
        spire.rotation.z = (random() - .5) * .07;
    }
    for (let i = 0; i < 15; i++) {
        const x = (i % 2 ? 1 : -1) * (17 + random() * 13), z = 18 - i * 7 + random() * 3;
        const h = 12 + random() * 26;
        const stone = box(group, 2.8, h, 2.3, random() > .5 ? LILAC : INK, x, h * .6, z);
        stone.rotation.set((random() - .5) * .3, random() * 1.5, (random() - .5) * .3);
        box(group, 3.1, .12, 2.7, AMBER, x, h * .6 + h / 2 + .2, z).rotation.y = stone.rotation.y;
    }
    for (let i = 0; i < 35; i++)
        floatingShard(group, (i % 2 ? 1 : -1) * (15 + random() * 37), 10 + random() * 34, -random() * 115, 1.3 + random() * 3, random() > .63 ? GOLD : LILAC, random);
    const gateRing = ring(group, 24, 1.2, INK, 32, 36, -126);
    gateRing.rotation.y = .38;
    const gateFiligree = ring(group, 23.4, .18, GOLD, 32, 36, -125);
    gateFiligree.rotation.y = .38;
    orb(group, 18, basic(0xb178db, .12), 32, 36, -130, 2).castShadow = false;
    for (let i = 0; i < 11; i++) {
        const z = -14 - i * 12;
        const rock = orb(group, 5 + random() * 4, OBSIDIAN, (i % 2 ? 1 : -1) * (28 + random() * 13), 3 + random() * 6, z, 1);
        rock.scale.set(1.9, .3 + random() * .2, 1.5);
    }
    const ritual = new THREE.Group();
    ritual.position.set(-2, 3.3, -22);
    group.add(ritual);
    cyl(ritual, 2.25, 2.5, .6, AMBER, 0, .18, 0, 16);
    cyl(ritual, 1.94, 1.94, .11, INK, 0, .56, 0, 24);
    const ritualRing = ring(ritual, 1.7, .055, GOLD, 0, .69, 0);
    ritualRing.rotation.x = -Math.PI / 2;
    for (let i = 0; i < 12; i++) {
        const a = i * 2 * Math.PI / 12;
        const stone = box(ritual, .2, .06, .8, GOLD, Math.cos(a) * 1.27, .64, Math.sin(a) * 1.27);
        stone.rotation.y = -a;
    }
    const ritualLight = orb(ritual, .66, GOLD, 0, 2.3, 0, 1);
    const cascade = new THREE.Group();
    group.add(cascade);
    cascade.visible = false;
    for (let i = 0; i < 9; i++) {
        const t = i / 8;
        const z = -32 - i * 5.6;
        const height = 10 + t * 28;
        const a = ring(cascade, 4 + t * 6, .13, GOLD, Math.sin(i * .8) * 8, height, z);
        a.rotation.y = (i % 2 ? .6 : -.6);
        a.rotation.x = .25;
        for (let j = 0; j < 3; j++)
            floatingShard(cascade, Math.cos(j * 2.1) * 7, height + Math.sin(j * 2) * 3, z, 1.1 + random(), GOLD, random);
    }
    let awakened = false, awakeT = 0;
    makeStars(group, 999, 1600, 0xe9c7ff, 55, 285);
    return {
        id: 'parable', group, platforms, spawn: new THREE.Vector3(0, .2, 20), interaction: new THREE.Vector3(-2, 3.5, -22), goal: new THREE.Vector3(0, 8.2, -76),
        activate: (reduced) => { if (awakened)
            return; awakened = true; awakeT = reduced ? 1 : 0; cascade.visible = true; for (const p of platforms) {
            if (!p.active) {
                p.active = true;
                p.solid = reduced;
                p.mesh.visible = true;
                if (!reduced)
                    p.mesh.position.y = p.y - 8;
            }
        } },
        reset: () => { awakened = false; awakeT = 0; cascade.visible = false; for (const p of platforms) {
            p.active = ['A0', 'A1', 'A2', 'A3'].includes(p.id);
            p.solid = p.active;
            p.mesh.visible = p.active;
            p.mesh.position.y = p.y;
        } },
        update: (dt, elapsed, reduced) => {
            scenery.update(elapsed, reduced, awakened ? 1 : 0);
            if (reduced && awakened && awakeT < 1) {
                awakeT = 1;
                for (const p of platforms)
                    if (['A4', 'A5', 'A6', 'A7'].includes(p.id)) {
                        p.mesh.position.y = p.y;
                        p.solid = true;
                    }
            }
            if (awakened && awakeT < 1) {
                awakeT = Math.min(1, awakeT + dt / 1.4);
                for (const p of platforms)
                    if (['A4', 'A5', 'A6', 'A7'].includes(p.id)) {
                        p.mesh.position.y = p.y - 8 * (1 - (1 - Math.pow(1 - awakeT, 3)));
                        if (awakeT === 1)
                            p.solid = true;
                    }
            }
            if (!reduced) {
                ritualLight.position.y = 2.3 + Math.sin(elapsed * 1.6) * .22;
                ritualRing.rotation.z = elapsed * .15;
                gateRing.rotation.z = elapsed * .008;
                gateFiligree.rotation.z = elapsed * .009;
                cascade.rotation.z = Math.sin(elapsed * .15) * .04;
            }
        }
    };
}
export function createAcre() {
    const random = seeded(801), group = new THREE.Group(), platforms = [];
    const scenery = createScenicAcre();
    group.add(scenery.group);
    const nodes = [
        ['B0', 0, 18, .2, 17, 16, true, true], ['B1', 0, 2, 1.1, 11, 9, true, false],
        ['B2', 2, -11, 2.15, 10, 9, true, true], ['B3', 2, -24, 3.4, 15, 13, true, true],
        ['B4', 1, -40, 4.6, 9, 10, false, false], ['B5', -1, -52, 5.5, 10, 10, false, true],
        ['B6', -2, -65, 6.7, 10, 10, false, false], ['B7', -2, -78, 8.0, 17, 14, false, true]
    ];
    for (const [id, x, z, y, w, d, active, checkpoint] of nodes) {
        const p = { id, x, z, y, w, d, active, checkpoint };
        platforms.push(p);
        if (active)
            groundTile(group, p, 'green', random);
        else {
            buildLeaf(group, p, random);
            p.mesh.visible = false;
        }
        p.solid = active;
    }
    for (const p of platforms) {
        if (p.id !== 'B0' && p.id !== 'B3' && p.id !== 'B7')
            continue;
        for (let j = 0; j < 8; j++) {
            const x = p.x + (random() - .5) * (p.w - 1), z = p.z + (random() - .5) * (p.d - 1);
            if (Math.abs(x - p.x) < p.w * .33 || Math.hypot(x - p.x, z - p.z) < 2.7)
                continue;
            foliageCrown(group, x, p.y, z, .4 + random() * .52, random);
        }
        for (const sign of [-1, 1])
            lantern(group, p.x + sign * p.w * .43, p.y + .05, p.z, 'green', 2.0);
    }
    // Orbital greenhouse: transparent pressure shell, orbital rings and a living canopy.
    const dome = new THREE.Group();
    dome.position.set(0, -10, -30);
    group.add(dome);
    const glowDome = mesh(dome, new THREE.SphereGeometry(100, 36, 20), new THREE.MeshPhysicalMaterial({ color: 0x75f0d9, transparent: true, opacity: .042, metalness: .08, roughness: .12, depthWrite: false, side: THREE.BackSide }), 0, 0, 0);
    glowDome.castShadow = false;
    for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 8;
        const pts = [];
        for (let j = 0; j <= 24; j++) {
            const t = j * Math.PI / 24;
            pts.push(new THREE.Vector3(Math.cos(a) * 98 * Math.cos(t), 98 * Math.sin(t), Math.sin(a) * 98 * Math.cos(t)));
        }
        line(dome, pts, 0x67cebd, .16, .38).castShadow = false;
    }
    for (let y of [5, 32, 61]) {
        const radius = Math.sqrt(Math.max(0, 100 * 100 - y * y));
        const r = ring(dome, radius, .07, basic(0x6bd1c2, .2), 0, y, 0);
        r.rotation.x = -Math.PI / 2;
        r.castShadow = false;
    }
    const orbPlanet = orb(group, 28, m(0x315e8b, .15, .93, 0x21445e, .1), -78, 54, -215, 3);
    orbPlanet.castShadow = false;
    const planetAtmo = orb(group, 31, basic(0x80bbf6, .10), -78, 54, -215, 3);
    planetAtmo.castShadow = false;
    const orbitalRing = ring(group, 42, 1.35, m(0x83c6ce, .56, .38), -78, 54, -215);
    orbitalRing.rotation.x = 1.14;
    orbitalRing.rotation.y = .28;
    // Vertical garden towers: organic silhouette contrasted against clean station ribs.
    const towers = [];
    for (let i = 0; i < 22; i++) {
        const z = 26 - i * 5.75 - random() * 6;
        const x = (i % 2 ? 1 : -1) * (19 + random() * 28);
        const h = 9 + random() * 29;
        const g = new THREE.Group();
        g.position.set(x, 0, z);
        group.add(g);
        towers.push(g);
        cyl(g, 1.4, 2.4, h, m(0x376d5b, .1, .75), 0, h * .44, 0, 9);
        const foliage = new THREE.InstancedMesh(CROWN_LEAF_GEOMETRY, CROWN_LEAF_MATERIAL, 20);
        const scratch = new THREE.Object3D();
        for (let j = 0; j < 4; j++) {
            const yy = 3 + j * h * .19;
            const radius = 3 + random() * 3.5;
            for (let k = 0; k < 5; k++) {
                const a = k * Math.PI * 2 / 5 + j * .3;
                scratch.position.set(Math.cos(a) * radius * .68, yy + .9, Math.sin(a) * radius * .68);
                scratch.scale.set(radius * .60, 1 + random() * .65, radius * .72);
                scratch.rotation.set(0, a, 0);
                scratch.updateMatrix();
                const index = j * 5 + k;
                foliage.setMatrixAt(index, scratch.matrix);
                foliage.setColorAt(index, FOLIAGE[(i + k + j) % 4].color);
            }
        }
        foliage.instanceMatrix.needsUpdate = true;
        if (foliage.instanceColor)
            foliage.instanceColor.needsUpdate = true;
        foliage.castShadow = false;
        g.add(foliage);
        const tip = orb(g, 1.25, LAMP, 0, h + 2, 0, 1);
        tip.castShadow = false;
        if (i % 4 === 0) {
            for (let j = 0; j < 4; j++) {
                const a = j * Math.PI * .5;
                petals(g, Math.cos(a) * 2.2, h * .8, Math.sin(a) * 2.2, LAMP, random, .9);
            }
        }
    }
    // Rows of raised planters visibly terrace the walkable route.
    for (let i = 0; i < 18; i++) {
        const z = 19 - i * 5.65;
        for (const s of [-1, 1]) {
            const x = s * (9.4 + i % 3 * 1.7);
            const height = .6 + (i % 5) * .33;
            box(group, 3.5, height, 3.5, OBSIDIAN, x, height / 2, z);
            box(group, 3.7, .22, 3.7, JADE, x, height + .05, z);
            foliageCrown(group, x, height, z, .36 + random() * .44, random);
        }
    }
    // The single action is a stylized planting + watering gesture, not the Godot game's complete crop lifecycle.
    const planter = new THREE.Group();
    planter.position.set(2, 3.4, -24);
    group.add(planter);
    cyl(planter, 2.5, 2.7, .55, OBSIDIAN, 0, .21, 0, 16);
    cyl(planter, 2.24, 2.24, .13, JADE, 0, .56, 0, 24);
    cyl(planter, 1.75, 1.75, .08, m(0x193f35, .04, .9), 0, .67, 0, 24);
    for (let i = 0; i < 16; i++) {
        const a = i * Math.PI * 2 / 16;
        orb(planter, .15, LAMP, Math.cos(a) * 2.1, .72, Math.sin(a) * 2.1, 0).castShadow = false;
    }
    const seed = orb(planter, .36, GOLD, 0, .94, 0, 1);
    seed.castShadow = false;
    const watering = mesh(planter, new THREE.ConeGeometry(.52, 1.2, 8), basic(0x8cffe0, .3), .72, 1.54, 0);
    watering.rotation.z = -.3;
    watering.castShadow = false;
    const growthBeams = new THREE.Group();
    growthBeams.visible = false;
    group.add(growthBeams);
    for (let i = 0; i < 8; i++) {
        const t = i / 7;
        const x = (random() - .5) * 7, z = -32 - i * 6;
        line(growthBeams, [new THREE.Vector3(x, -5, z), new THREE.Vector3(x + Math.sin(i) * 2, 7 + t * 8, z), new THREE.Vector3(x, 14 + t * 13, z)], 0x7dffcb, .05, .62);
        for (let j = 0; j < 4; j++)
            petals(growthBeams, x + (random() - .5) * 6, 2 + random() * 13, z + (random() - .5) * 6, j % 2 ? LAMP : GOLD, random, .3 + random() * .6);
    }
    makeStars(group, 405, 1500, 0xcdeee7, 45, 300);
    let planted = false, growth = 0;
    return {
        id: 'acre', group, platforms, spawn: new THREE.Vector3(0, .2, 20), interaction: new THREE.Vector3(2, 3.65, -24), goal: new THREE.Vector3(-2, 8, -78),
        activate: (reduced) => {
            if (planted)
                return;
            planted = true;
            growth = reduced ? 1 : 0;
            growthBeams.visible = true;
            seed.visible = false;
            watering.visible = false;
            for (const p of platforms) {
                if (p.id.startsWith('B') && Number(p.id.slice(1)) >= 4) {
                    p.active = true;
                    p.solid = reduced;
                    p.mesh.visible = true;
                    p.mesh.scale.set(Math.max(.02, growth), Math.max(.02, growth), Math.max(.02, growth));
                }
            }
        },
        reset: () => {
            planted = false;
            growth = 0;
            growthBeams.visible = false;
            seed.visible = true;
            watering.visible = true;
            for (const p of platforms)
                if (Number(p.id.slice(1)) >= 4) {
                    p.active = false;
                    p.solid = false;
                    p.mesh.visible = false;
                    p.mesh.scale.set(1, 1, 1);
                }
        },
        update: (dt, elapsed, reduced) => {
            scenery.update(elapsed, reduced, planted ? 1 : 0);
            if (reduced && planted && growth < 1) {
                growth = 1;
                for (const p of platforms)
                    if (Number(p.id.slice(1)) >= 4) {
                        p.mesh.scale.set(1, 1, 1);
                        p.solid = true;
                    }
            }
            if (planted && growth < 1) {
                growth = Math.min(1, growth + dt / 2.7);
                const rise = 1 - Math.pow(1 - growth, 3);
                for (const p of platforms)
                    if (Number(p.id.slice(1)) >= 4) {
                        p.mesh.scale.set(Math.max(.02, rise), Math.max(.02, rise), Math.max(.02, rise));
                        if (growth === 1)
                            p.solid = true;
                    }
            }
            if (!reduced) {
                orbitalRing.rotation.z = elapsed * .007;
                for (let i = 0; i < towers.length; i++)
                    towers[i].rotation.z = Math.sin(elapsed * .42 + i * .9) * .012;
                if (!planted) {
                    seed.position.y = .94 + Math.sin(elapsed * 2) * .12;
                    watering.rotation.z = -.3 + Math.sin(elapsed) * .13;
                }
            }
        }
    };
}
export function createDioramas() {
    const g = new THREE.Group(), r = seeded(89);
    // Visual-only exhibit vistas, NOT a passage or event linking the two source fictions.
    const a = new THREE.Group();
    a.position.z = 56;
    g.add(a);
    const aPlinth = cyl(a, 19, 24, 6, INK, 0, -8, 0, 11);
    aPlinth.scale.z = 1.4;
    cyl(a, 19, 19, .3, LILAC, 0, -4.8, 0, 11);
    for (let i = 0; i < 11; i++) {
        const ang = i * Math.PI * 2 / 11;
        const x = Math.cos(ang) * 13, z = Math.sin(ang) * 18;
        rockSpire(a, x, z, 9 + r() * 25, r);
    }
    const aRing = ring(a, 19, 1.3, GOLD, 0, 28, -4);
    aRing.rotation.y = .55;
    orb(a, 10, basic(0x8f63ce, .15), 0, 28, -7, 2).castShadow = false;
    for (let i = 0; i < 30; i++)
        floatingShard(a, (r() - .5) * 45, 3 + r() * 30, (r() - .5) * 45, 1 + r() * 2, GOLD, r);
    const b = new THREE.Group();
    b.position.z = -56;
    g.add(b);
    const bBase = cyl(b, 20, 23, 6, OBSIDIAN, 0, -8, 0, 12);
    bBase.scale.z = 1.4;
    cyl(b, 20, 20, .3, JADE, 0, -4.8, 0, 12);
    for (let i = 0; i < 23; i++) {
        const ang = i * Math.PI * 2 / 23, dist = 8 + r() * 15;
        foliageCrown(b, Math.cos(ang) * dist, -4.5, Math.sin(ang) * dist, 1.2 + r() * 2.3, r);
    }
    const bRing = ring(b, 25, .8, LAMP, 0, 27, 0);
    bRing.rotation.y = -.6;
    const glass = orb(b, 15, basic(0x46ffd3, .09), 0, 20, 0, 3);
    glass.castShadow = false;
    for (let i = 0; i < 16; i++)
        petals(b, (r() - .5) * 22, 6 + r() * 20, (r() - .5) * 30, LAMP, r, .8 + r());
    return g;
}
export function makePlayer() {
    const p = new THREE.Group();
    const cloak = m(0x273944, .35, .46), seam = m(0xe5bd6c, .78, .25), skin = m(0xf0e5d8, .07, .65), shoe = m(0x252c35, .45, .5);
    const body = mesh(p, new THREE.CylinderGeometry(.3, .45, 1.06, 9), cloak, 0, 1.15, 0);
    body.castShadow = true;
    body.name = 'torso';
    const breast = box(p, .55, .45, .10, m(0x4a6470, .5, .33, 0x254a52, .16), 0, 1.27, -.36);
    breast.rotation.x = -.12;
    const insignia = orb(p, .11, GOLD, 0, 1.36, -.44, 1);
    insignia.castShadow = false;
    for (const sign of [-1, 1]) {
        const shoulder = orb(p, .23, m(0x628292, .5, .38), sign * .42, 1.49, 0, 1);
        shoulder.scale.set(1, .7, .9);
    }
    const head = orb(p, .35, skin, 0, 1.9, 0, 2);
    head.name = 'helmet';
    const visor = box(p, .50, .105, .14, seam, 0, 1.92, -.29);
    visor.castShadow = false;
    cyl(p, .42, .45, .11, seam, 0, 1.46, 0, 12);
    const limbs = new THREE.Group();
    limbs.name = 'limbs';
    p.add(limbs);
    for (const s of [-1, 1]) {
        const leg = cyl(limbs, .14, .16, .65, shoe, s * .19, .39, 0, 8);
        leg.name = s < 0 ? 'legL' : 'legR';
        const arm = cyl(limbs, .10, .13, .72, cloak, s * .49, 1.25, 0, 8);
        arm.name = s < 0 ? 'armL' : 'armR';
        arm.rotation.z = s * .22;
        const cuff = cyl(limbs, .13, .13, .13, seam, s * .50, .94, -.02, 8);
        cuff.name = s < 0 ? 'cuffL' : 'cuffR';
        orb(p, .12, GOLD, s * .49, .84, 0, 0);
    }
    // Segmented travel mantle: secondary motion never changes the character collider.
    const cape = mesh(p, new THREE.ConeGeometry(.67, 1.32, 4, 1, true), new THREE.MeshStandardMaterial({ color: 0x496471, side: THREE.DoubleSide, roughness: .87, transparent: true, opacity: .84 }), 0, 1.14, .25);
    cape.rotation.y = Math.PI / 4;
    cape.name = 'cloak';
    const ringHalo = ring(p, .22, .045, GOLD, 0, 2.3, 0);
    ringHalo.rotation.x = -Math.PI / 2;
    ringHalo.name = 'traveler-halo';
    // Two self-contained movement accents: cloth follows the traveler, never the collider.
    const ribbonMaterial = new THREE.MeshStandardMaterial({ color: 0x8bbdb0, side: THREE.DoubleSide, roughness: .68, metalness: .12, emissive: 0x193f43, emissiveIntensity: .12 });
    for (const sign of [-1, 1]) {
        const ribbon = mesh(p, new THREE.PlaneGeometry(.17, 1.0, 1, 4), ribbonMaterial, sign * .25, 1.04, .45);
        ribbon.name = sign < 0 ? 'ribbonL' : 'ribbonR';
        ribbon.rotation.x = .20;
        ribbon.rotation.z = sign * .15;
        ribbon.castShadow = false;
    }
    const crest = orb(p, .125, LAMP, 0, 1.26, -.51, 1);
    crest.castShadow = false;
    crest.name = 'travel-crest';
    const headband = ring(p, .29, .045, AMBER, 0, 2.045, 0);
    headband.rotation.x = -Math.PI / 2;
    for (const sign of [-1, 1]) {
        const boot = box(p, .27, .17, .42, shoe, sign * .19, .14, -.1);
        boot.rotation.y = sign * .09;
        const sideLamp = orb(p, .10, LAMP, sign * .32, 1.08, -.18, 0);
        sideLamp.castShadow = false;
    }
    return p;
}
export function disposeWorld(group) {
    const geometries = new Set(), materials = new Set();
    group.traverse((o) => { if (o instanceof THREE.Mesh || o instanceof THREE.Points || o instanceof THREE.Line) {
        if (o.geometry)
            geometries.add(o.geometry);
        const mat = o.material;
        if (Array.isArray(mat))
            mat.forEach(m => materials.add(m));
        else if (mat)
            materials.add(mat);
    } });
    const textures = new Set();
    for (const mat of materials) {
        for (const value of Object.values(mat))
            if (value instanceof THREE.Texture)
                textures.add(value);
    }
    for (const geo of geometries)
        geo.dispose();
    for (const texture of textures)
        texture.dispose();
    for (const mat of materials)
        mat.dispose();
    group.clear();
}
