import { loadExplorer, saveExplorer, clearExplorer, landmarkById } from './core/expedition.js';
import { createPortableExpedition, inspectPortableExpedition } from './core/portable.js';
import { readResonancePreference, writeResonancePreference } from './core/resonance-preference.js';
import { ResonanceLens } from './worlds/resonance-lens.js';
import { AdaptiveResolution } from './core/adaptive.js';
import { resolveWalk } from './core/locomotion.js';
import { ExpeditionBeacons } from './worlds/expedition-beacons.js';
import { completedExperiments } from './core/experiments.js';
import { causalStage, finaleReady, echoDifferences, heartIrrigation, gravityAligned } from './core/simulation.js';
import { observationById, narrativeStatus } from './core/mystery.js';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

import { StateStore, WORLD_NAMES, ruinsComplete, TERRAIN_ZONES, sunAmount } from './core/state.js';
import { heightAt, clamp, lerp } from './core/math.js';
import { PreviewManager } from './core/preview.js';
import { visibleMiniatureTargets } from './core/preview-policy.js';
import { WeatherAudio } from './core/audio.js';
import { InteractionFeedback } from './core/feedback.js';
import { TransitionComposer } from './core/transition.js';
import { Observatory } from './worlds/observatory.js';
import { LivingWorld } from './worlds/living.js';
import { CelestialGarden, edgeKey, constellationCompletion } from './worlds/garden.js';
import { STAR_POINTS } from './core/constellations.js';
import { UI, nextConstellationEdge, TOOL_HINTS } from './ui.js';
// A very small scale-specific field-of-view change reinforces the nesting,
// without altering controls, positions or the player's selected navigation mode.
const SCALE_FOV = [59, 64, 67];
const pathXY = (e, canvas) => {
    const rect = canvas.getBoundingClientRect();
    return { x: ((e.clientX - rect.left) / rect.width) * 2 - 1, y: 1 - ((e.clientY - rect.top) / rect.height) * 2 };
};
class FlightNavigator {
    camera;
    mode = 'orbit';
    orbit;
    yaw = 0;
    pitch = 0;
    keys = new Set();
    destination = null;
    constructor(camera, canvas) {
        this.camera = camera;
        this.orbit = new OrbitControls(camera, canvas);
        this.orbit.enableDamping = true;
        this.orbit.dampingFactor = .065;
        this.orbit.minDistance = 3.1;
        this.orbit.maxDistance = 150;
        this.orbit.maxPolarAngle = Math.PI * .9;
        this.orbit.enablePan = true;
    }
    get target() {
        if (this.mode === 'orbit')
            return this.orbit.target.clone();
        const d = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
        return this.camera.position.clone().addScaledVector(d, 20);
    }
    setMode(mode, pose) {
        const oldTarget = this.target;
        this.mode = mode;
        this.orbit.enabled = mode === 'orbit';
        if (pose)
            this.setPose(pose);
        else if (mode === 'orbit') {
            this.orbit.target.copy(oldTarget);
            this.orbit.update();
        }
        this.syncAngles();
    }
    setPose(pose) {
        this.camera.position.copy(pose.position);
        this.camera.lookAt(pose.target);
        this.orbit.target.copy(pose.target);
        this.orbit.update();
        this.syncAngles();
    }
    syncAngles() {
        const d = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
        this.yaw = Math.atan2(-d.x, -d.z);
        this.pitch = Math.asin(clamp(d.y, -.998, .998));
    }
    key(code, pressed) { if (pressed)
        this.keys.add(code);
    else
        this.keys.delete(code); }
    releaseKeys() { this.keys.clear(); }
    look(dx, dy) {
        if (this.mode === 'orbit' || this.destination)
            return;
        this.yaw += dx * .0032;
        this.pitch = clamp(this.pitch - dy * .0032, -Math.PI * .48, Math.PI * .48);
        this.camera.quaternion.setFromEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'));
    }
    wheel(dy) {
        if (this.mode === 'orbit')
            return;
        const direction = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
        this.camera.position.addScaledVector(direction, clamp(dy, -100, 100) * -.067);
    }
    animateTo(target, dist = 9, duration = 2.3) {
        const dir = this.camera.position.clone().sub(target).normalize();
        if (dir.lengthSq() < .1)
            dir.set(0, .2, 1);
        const to = target.clone().addScaledVector(dir, dist);
        to.y = Math.max(to.y, target.y + 1.5);
        this.destination = { from: this.camera.position.clone(), to, look: target.clone(), elapsed: 0, duration };
    }
    stopMotion() { this.destination = null; }
    get isAnimating() { return this.destination !== null; }
    update(dt, world, store) {
        if (this.destination) {
            const d = this.destination;
            d.elapsed = Math.min(d.duration, d.elapsed + dt);
            const t = d.elapsed / d.duration, e = t * t * (3 - 2 * t);
            this.camera.position.copy(d.from).lerp(d.to, e);
            this.camera.lookAt(d.look);
            this.orbit.target.copy(d.look);
            this.syncAngles();
            if (t >= 1)
                this.destination = null;
            return;
        }
        if (this.mode === 'orbit') {
            this.orbit.update();
            return;
        }
        const f = Number(this.keys.has('KeyW') || this.keys.has('ArrowUp')) - Number(this.keys.has('KeyS') || this.keys.has('ArrowDown'));
        const strafe = Number(this.keys.has('KeyD') || this.keys.has('ArrowRight')) - Number(this.keys.has('KeyA') || this.keys.has('ArrowLeft'));
        const up = Number(this.keys.has('Space')) - Number(this.keys.has('ShiftLeft') || this.keys.has('ShiftRight'));
        const fast = this.keys.has('ControlLeft') || this.keys.has('ControlRight');
        const speed = (this.mode === 'walk' ? 8 : 24) * (fast ? 2.8 : 1);
        const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
        if (this.mode === 'walk')
            forward.y = 0;
        forward.normalize();
        const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
        if (this.mode === 'walk')
            right.y = 0;
        right.normalize();
        const beforeMove = this.camera.position.clone();
        const move = new THREE.Vector3().addScaledVector(forward, f).addScaledVector(right, strafe);
        if (move.lengthSq() > 1)
            move.normalize();
        move.multiplyScalar(speed * dt);
        move.y += up * speed * dt * (this.mode === 'walk' ? .0 : .68);
        this.camera.position.add(move);
        if (this.mode === 'walk' && world.id !== 2) {
            const safe = resolveWalk(world.id, beforeMove, this.camera.position);
            this.camera.position.x = safe.x;
            this.camera.position.z = safe.z;
        }
        if (world.id === 0) {
            const r = Math.hypot(this.camera.position.x, this.camera.position.z);
            if (r > 75)
                this.camera.position.multiplyScalar(75 / r);
            this.camera.position.y = clamp(this.camera.position.y, 2.8, 106);
        }
        else if (world.id === 1) {
            const s = store.data;
            this.camera.position.x = clamp(this.camera.position.x, -117, 117);
            this.camera.position.z = clamp(this.camera.position.z, -116, 117);
            const ground = heightAt(this.camera.position.x, this.camera.position.z, s) + 1.65;
            this.camera.position.y = this.mode === 'walk' ? ground : clamp(this.camera.position.y, ground, 155);
        }
        else {
            this.camera.position.x = clamp(this.camera.position.x, -260, 260);
            this.camera.position.z = clamp(this.camera.position.z, -270, 150);
            if (this.mode === 'walk' && world.walkHeightAt) {
                const y = world.walkHeightAt(this.camera.position.x, this.camera.position.z);
                if (y === null) {
                    this.camera.position.x = beforeMove.x;
                    this.camera.position.z = beforeMove.z;
                }
                else
                    this.camera.position.y = y + 1.65;
            }
            else
                this.camera.position.y = clamp(this.camera.position.y, -8, 200);
        }
    }
    dispose() { this.orbit.dispose(); }
}
class Infinitum {
    canvas;
    renderer;
    camera;
    store = new StateStore();
    sound = new WeatherAudio();
    navigator;
    adaptive = new AdaptiveResolution();
    beacons;
    resonance;
    resonanceOn = readResonancePreference();
    unsubscribeState = null;
    savePositionClock = 0;
    photoActive = false;
    photoRequested = false;
    editingField = null;
    preview;
    composer;
    ui;
    feedback;
    world = 0;
    tool = 'inspect';
    current;
    transition = null;
    ray = new THREE.Raycaster();
    pointer = new THREE.Vector2();
    gesture = 'none';
    pointerId = null;
    startX = 0;
    startY = 0;
    prevX = 0;
    prevY = 0;
    activeZone = 0;
    selectedRuin = 0;
    selectedStarGroup = 0;
    selectedPrism = 0;
    starStart = null;
    riverPoints = [];
    riverGuide = null;
    storedPoses = new Map();
    accumulator = 0;
    lastFrame = 0;
    elapsed = 0;
    previewClock = 0;
    lastPreviewRevision = -1;
    lastUiClock = 0;
    resizeObserver;
    lastTerrainRevision = 0;
    previousReveal = 0;
    queuedTravel = null;
    lastCausalStage = -1;
    probeClock = 0;
    frameTimes = [];
    downHandler = (e) => this.pointerDown(e);
    moveHandler = (e) => this.pointerMove(e);
    upHandler = (e) => this.pointerUp(e);
    cancelHandler = (e) => this.cancelGesture(e.pointerId);
    wheelHandler = (e) => { if (this.navigator.mode !== 'orbit') {
        e.preventDefault();
        this.navigator.wheel(e.deltaY);
    } };
    keyDown = (e) => this.keyboard(e, true);
    keyUp = (e) => this.keyboard(e, false);
    focusLost = () => { this.navigator.releaseKeys(); this.cancelGesture(); };
    constructor() {
        this.canvas = document.querySelector('#universe');
        const resumed = loadExplorer();
        if (resumed)
            this.world = resumed.world;
        this.adaptive.enabled = this.store.data.adaptiveQuality;
        this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.07;
        this.renderer.shadowMap.enabled = this.store.data.quality !== 'low';
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.renderer.setClearColor(0x071019);
        this.renderer.setPixelRatio(this.pixelRatio());
        this.renderer.setSize(window.innerWidth, window.innerHeight, false);
        this.renderer.transmissionResolutionScale = this.store.data.quality === 'low' ? .32 : .55;
        this.camera = new THREE.PerspectiveCamera(SCALE_FOV[this.world], window.innerWidth / window.innerHeight, .05, 1550);
        this.navigator = new FlightNavigator(this.camera, this.canvas);
        this.preview = new PreviewManager(this.renderer, this.store.data);
        this.current = this.makeWorld(this.world);
        this.beacons = new ExpeditionBeacons(this.current.scene, this.world);
        this.resonance = new ResonanceLens(this.current.scene, this.world);
        this.resonance.setEnabled(this.resonanceOn);
        this.feedback = new InteractionFeedback(this.current.scene, this.store.data.quality === 'low' ? 7 : 13);
        this.navigator.setMode(resumed?.mode ?? 'orbit', resumed ? this.poseFromMemory(resumed) : this.current.spawn);
        this.composer = new TransitionComposer(this.renderer);
        this.composer.resize();
        this.ui = new UI(this.store, this);
        this.ui.showToast(resumed ? 'Your expedition resumes exactly where it was held.' : 'A single raindrop. Approach it. The impossible is inside.');
        this.canvas.addEventListener('pointerdown', this.downHandler);
        this.canvas.addEventListener('pointermove', this.moveHandler);
        this.canvas.addEventListener('pointerup', this.upHandler);
        this.canvas.addEventListener('pointercancel', this.cancelHandler);
        this.canvas.addEventListener('wheel', this.wheelHandler, { passive: false });
        window.addEventListener('keydown', this.keyDown);
        window.addEventListener('keyup', this.keyUp);
        window.addEventListener('blur', this.focusLost);
        this.unsubscribeState = this.store.onChange(() => this.onStateChange());
        this.resizeObserver = new ResizeObserver(() => this.resize());
        this.resizeObserver.observe(document.body);
        document.addEventListener('visibilitychange', this.onVisibility);
        window.addEventListener('pagehide', this.onPageHide);
        this.preview.update(this.store.data, 0, true, visibleMiniatureTargets(this.world));
        this.renderer.setAnimationLoop((ms) => this.frame(ms));
    }
    get navigationMode() { return this.navigator.mode; }
    get photoMode() { return this.photoActive; }
    get resolutionScale() { return this.adaptive.percent; }
    poseFromMemory(memory) {
        return { position: new THREE.Vector3(...memory.position), target: new THREE.Vector3(...memory.target) };
    }
    saveExplorerPose() {
        if (this.transition)
            return;
        const p = this.camera.position, target = this.navigator.target;
        saveExplorer({ schema: 1, world: this.world, mode: this.navigator.mode,
            position: [p.x, p.y, p.z], target: [target.x, target.y, target.z] });
    }
    get soundEnabled() { return this.sound.enabled; }
    get resonanceActive() { return this.resonanceOn; }
    get saveStatus() { return this.store.saveStatus; }
    get isTransitioning() { return Boolean(this.transition); }
    get riverPointCount() { return this.riverPoints.length; }
    pixelRatio() { const cap = this.store.data.quality === 'high' ? 1.75 : this.store.data.quality === 'medium' ? 1.35 : 1.0; return Math.min(window.devicePixelRatio || 1, cap) * this.adaptive.scale; }
    makeWorld(id) {
        if (id === 0)
            return new Observatory(this.store.data, this.preview.living);
        if (id === 1)
            return new LivingWorld(this.store.data, this.preview.garden);
        return new CelestialGarden(this.store.data);
    }
    onVisibility = () => {
        if (document.hidden) {
            this.cancelGesture();
            this.store.save();
            this.saveExplorerPose();
            this.navigator.releaseKeys();
            this.lastFrame = 0;
        }
    };
    onPageHide = () => { this.store.save(); this.saveExplorerPose(); };
    resize() {
        const w = window.innerWidth, h = window.innerHeight;
        if (!w || !h)
            return;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        if (this.transition) {
            for (const c of [this.transition.fromCamera, this.transition.toCamera]) {
                c.aspect = w / h;
                c.updateProjectionMatrix();
            }
        }
        this.renderer.setPixelRatio(this.pixelRatio());
        this.renderer.setSize(w, h, false);
        this.composer.resize();
    }
    onStateChange() {
        this.current.sync(this.store.data);
        this.transition?.to.sync(this.store.data);
        this.ui.refresh();
        if (this.lastTerrainRevision !== this.store.revision) {
            this.lastTerrainRevision = this.store.revision;
            this.previewClock = 1;
        }
    }
    frame(nowMs) {
        if (document.hidden) {
            this.lastFrame = 0;
            return;
        }
        const now = nowMs / 1000;
        if (!this.lastFrame)
            this.lastFrame = now;
        const delta = clamp(now - this.lastFrame, 0, .05);
        this.lastFrame = now;
        if (delta > .001) {
            this.frameTimes.push(delta * 1000);
            if (this.frameTimes.length > 180)
                this.frameTimes.shift();
            if (!this.transition && this.adaptive.sample(delta * 1000)) {
                this.resize();
            }
        }
        this.savePositionClock += delta;
        if (this.savePositionClock >= 4) {
            this.savePositionClock = 0;
            this.saveExplorerPose();
        }
        this.accumulator += delta;
        let step = 0;
        const dt = 1 / 60;
        while (this.accumulator >= dt && step++ < 4) {
            this.elapsed += dt;
            this.store.tick(dt);
            this.sound.tick(this.elapsed, this.store.data.weather, this.world, this.store.data.time, this.camera.position);
            if (!this.transition) {
                this.navigator.update(dt, this.current, this.store);
                if (this.queuedTravel !== null && !this.navigator.isAnimating) {
                    const next = this.queuedTravel;
                    this.queuedTravel = null;
                    this.beginTransition(next);
                }
            }
            this.current.update(dt, this.elapsed, this.store.data, this.transition ? this.transition.fromCamera : this.camera);
            this.beacons.update(this.elapsed, this.store.data);
            this.resonance.update(this.store.data, this.elapsed);
            this.feedback.update(dt, this.store.data.reducedMotion);
            if (this.previousReveal !== this.store.data.reveal) {
                this.previousReveal = this.store.data.reveal;
                this.store.touch();
            }
            if (this.transition)
                this.transition.to.update(dt, this.elapsed, this.store.data, this.transition.toCamera);
            this.accumulator -= dt;
        }
        if (step >= 4)
            this.accumulator = 0;
        this.previewClock += delta;
        if (this.previewClock > .9 || this.lastPreviewRevision !== this.store.revision) {
            const force = this.lastPreviewRevision !== this.store.revision;
            this.lastPreviewRevision = this.store.revision;
            this.previewClock = 0;
            this.preview.update(this.store.data, this.elapsed, force, visibleMiniatureTargets(this.world, this.transition?.to.id ?? null));
        }
        const daylight = sunAmount(this.store.data.time);
        const targetExposure = (this.world === 2 ? .94 : this.world === 0 ? 1.04 : .97) + daylight * .19;
        this.renderer.toneMappingExposure = lerp(this.renderer.toneMappingExposure, targetExposure, .04);
        if (this.transition)
            this.renderTransition(delta);
        else {
            this.renderer.setRenderTarget(null);
            this.renderer.render(this.current.scene, this.camera);
        }
        if (this.photoRequested && !this.transition)
            this.captureImage();
        this.probeClock += delta;
        if (this.probeClock > .6) {
            this.probeClock = 0;
            this.updateProbe();
        }
        this.lastUiClock += delta;
        if (this.lastUiClock > .14) {
            this.ui.refresh();
            this.lastUiClock = 0;
        }
    }
    downloadText(value, name) {
        const blob = new Blob([value], { type: 'application/json' });
        const url = URL.createObjectURL(blob), anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = name;
        document.body.append(anchor);
        anchor.click();
        anchor.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 12000);
        this.ui.showToast('File saved locally. Keep a copy outside this browser.');
    }
    captureImage() {
        this.photoRequested = false;
        try {
            // Read the canvas immediately after WebGLRenderer.render(), in the same animation frame.
            // This avoids a permanent preserveDrawingBuffer GPU-memory penalty.
            const png = this.canvas.toDataURL('image/png');
            if (!png.startsWith('data:image/png'))
                throw new Error('PNG capture unavailable');
            const anchor = document.createElement('a');
            anchor.href = png;
            anchor.download = `INFINITUM-${['OBSERVATORY', 'LIVING-WORLD', 'CELESTIAL-GARDEN'][this.world]}-${Date.now()}.png`;
            document.body.append(anchor);
            anchor.click();
            anchor.remove();
            this.ui.showToast('A frame of the universe has been preserved.');
        }
        catch (error) {
            this.ui.showToast('Could not capture WebGL frame: ' + String(error));
        }
    }
    updateProbe() {
        const stage = causalStage(this.store.data);
        if (stage !== this.lastCausalStage) {
            this.lastCausalStage = stage;
            if (stage > 0)
                this.ui.showToast(narrativeStatus(this.store.data).title);
        }
        const hud = document.getElementById('diagnostic-hud');
        if (hud && !hud.hidden) {
            const r = this.renderer.info;
            const p = this.framePercentiles();
            hud.textContent = `World ${this.world + 1} | ${this.store.data.quality.toUpperCase()} | frame p95 ${p.p95.toFixed(1)}ms | draw ${r.render.calls} | tris ${r.render.triangles.toLocaleString()} | geo ${r.memory.geometries} | tex ${r.memory.textures} | causal ${stage}/3 | experiments ${completedExperiments(this.store.data).length}/9 | resolution ${this.adaptive.percent}% | mini renders ${this.preview.renderPasses}`;
        }
    }
    framePercentiles() { const sorted = [...this.frameTimes].sort((a, b) => a - b); return { p95: sorted[Math.max(0, Math.ceil(sorted.length * .95) - 1)] ?? 0, p99: sorted[Math.max(0, Math.ceil(sorted.length * .99) - 1)] ?? 0, samples: sorted.length }; }
    renderTransition(dt) {
        const t = this.transition;
        if (!t)
            return;
        t.elapsed = Math.min(t.duration, t.elapsed + dt);
        const u = t.elapsed / t.duration, e = u * u * (3 - 2 * u);
        // Move the parent eye all the way into the glass, while the child eye expands outward.
        const near = t.sourcePortal.clone();
        const approach = t.source.position.clone().sub(t.sourcePortal).normalize();
        near.addScaledVector(approach, lerp(2.4, .01, e));
        t.fromCamera.position.copy(t.source.position).lerp(near, e);
        t.fromCamera.lookAt(t.sourcePortal);
        const childFar = t.destination.position.clone().multiplyScalar(1.38);
        t.toCamera.position.copy(childFar).lerp(t.destination.position, e);
        // The parent view remains stable while the new scale opens its wider lens.
        t.toCamera.fov = this.store.data.reducedMotion ? this.camera.fov : lerp(this.camera.fov, SCALE_FOV[t.to.id], e);
        t.toCamera.updateProjectionMatrix();
        const firstLook = t.destination.target.clone().add(new THREE.Vector3(0, -9, -19));
        t.toCamera.lookAt(firstLook.lerp(t.destination.target, e));
        const forward = e;
        this.composer.render(t.from.scene, t.fromCamera, t.to.scene, t.toCamera, forward, this.elapsed);
        if (u >= 1) {
            this.clearEchoGhost();
            this.feedback.dispose();
            this.beacons.dispose();
            this.resonance.dispose();
            t.from.dispose();
            this.current = t.to;
            this.world = t.to.id;
            this.beacons = new ExpeditionBeacons(this.current.scene, this.world);
            this.resonance = new ResonanceLens(this.current.scene, this.world);
            this.resonance.setEnabled(this.resonanceOn);
            this.feedback = new InteractionFeedback(this.current.scene, this.store.data.quality === 'low' ? 7 : 13);
            this.transition = null;
            this.camera.fov = t.toCamera.fov;
            this.camera.updateProjectionMatrix();
            this.navigator.stopMotion();
            this.navigator.setMode(this.world === 0 ? 'orbit' : 'fly', t.destination);
            this.tool = 'inspect';
            this.ui.refresh(true);
            if (this.store.selectedEcho)
                this.renderEchoGhost();
            if (this.world === 1)
                this.store.recordObservation('outer-drop');
            if (this.world === 2)
                this.store.recordObservation('heart-tree');
            if (this.world === 0 && finaleReady(this.store.data))
                this.ui.showToast('THE CONCORDANCE · The first instrument has changed. Inspect the threshold.');
            if (this.world === 2 && !this.store.data.gardenVisited) {
                this.store.change(s => { s.gardenVisited = true; });
                this.ui.showToast('THE THIRD SCALE. Look upward. Geometry remembers.');
            }
            else
                this.ui.showToast(WORLD_NAMES[this.world] + ' · the world remembers every change.');
        }
    }
    beginTransition(next) {
        if (this.transition || Math.abs(next - this.world) !== 1)
            return;
        const source = { position: this.camera.position.clone(), target: this.navigator.target };
        if (this.current.portal)
            this.feedback.pulse(this.current.portal, 0xb6ebe2, this.world === 0 ? 5 : 2);
        this.storedPoses.set(this.world, { position: source.position.clone(), target: source.target.clone() });
        const destination = this.storedPoses.get(next) ?? this.makeDefaultPose(next);
        this.preview.update(this.store.data, this.elapsed, true, visibleMiniatureTargets(this.world, next));
        const to = this.makeWorld(next);
        to.sync(this.store.data);
        const fromCamera = this.camera.clone(), toCamera = this.camera.clone();
        const sourcePortal = (next > this.world ? this.current.portal : this.current.exitPortal)?.clone() ?? source.position.clone().add(new THREE.Vector3(0, 0, -12));
        this.transition = { from: this.current, to, fromCamera, toCamera, elapsed: 0, duration: this.store.data.reducedMotion ? .95 : 2.7, source, destination, sourcePortal };
        this.riverPoints = [];
        this.cleanupRiverGuide();
        this.gesture = 'none';
        this.ui.showToast('Crossing the membrane · ' + WORLD_NAMES[next]);
    }
    makeDefaultPose(next) {
        if (next === 0)
            return { position: new THREE.Vector3(0, 12.5, 31), target: new THREE.Vector3(0, 11, 0) };
        if (next === 1)
            return { position: new THREE.Vector3(57, 51, 85), target: new THREE.Vector3(-5, 15, -20) };
        return { position: new THREE.Vector3(20, 22, 72), target: new THREE.Vector3(0, 17, 0) };
    }
    currentPortal(next) { return next !== undefined && next < this.world ? this.current.exitPortal ?? null : this.current.portal; }
    requestTravel(next) {
        if (this.transition || Math.abs(next - this.world) !== 1)
            return;
        const portal = this.currentPortal(next);
        if (!portal) {
            this.beginTransition(next);
            return;
        }
        const approach = this.world === 0 ? 12 : this.world === 1 && next === 2 ? 5.5 : 7.5;
        if (this.camera.position.distanceTo(portal) > approach + 2) {
            this.queuedTravel = next;
            this.navigator.animateTo(portal, approach, this.store.data.reducedMotion ? .65 : 2);
            this.ui.showToast('Approaching the physical membrane. The crossing begins at its surface.');
            return;
        }
        this.beginTransition(next);
    }
    focusPortal() {
        const portal = this.currentPortal(this.world === 2 ? 1 : (this.world + 1));
        if (!portal) {
            this.ui.showToast('No deeper drop. Look upward, or return to the leaf.');
            return;
        }
        const distance = this.world === 0 ? 12 : this.world === 1 ? 5.5 : 7.5;
        this.navigator.animateTo(portal, distance, this.store.data.reducedMotion ? .7 : 2.3);
        this.ui.showToast('Following the light to the next membrane.');
    }
    setTool(tool) {
        this.tool = tool;
        this.gesture = 'none';
        this.starStart = null;
        this.navigator.orbit.enabled = this.navigator.mode === 'orbit' && tool === 'inspect';
        this.ui.setTool(tool);
        this.ui.showToast(TOOL_HINTS[tool]);
    }
    setMode(mode) {
        this.navigator.setMode(mode);
        this.navigator.orbit.enabled = mode === 'orbit' && this.tool === 'inspect';
        this.ui.refresh(true);
        this.ui.showToast({ orbit: 'Orbit inspection · drag to rotate, wheel to zoom.', fly: 'Free flight · WASD, drag to look, Space and Shift to rise and descend.', walk: 'Ground navigation · WASD, drag to look.' }[mode]);
    }
    aimRay(ndc) {
        this.pointer.copy(ndc ?? new THREE.Vector2(0, 0));
        this.ray.setFromCamera(this.pointer, this.camera);
        return this.ray;
    }
    aimedTerrainPoint(ndc) {
        if (this.world !== 1)
            return null;
        const ray = this.aimRay(ndc);
        const ground = this.current.getTerrainPoint(ray);
        if (ground)
            return ground;
        const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
        const x = clamp(this.camera.position.x + forward.x * 12, -115, 115), z = clamp(this.camera.position.z + forward.z * 12, -115, 115);
        return new THREE.Vector3(x, heightAt(x, z, this.store.data), z);
    }
    objectHit(ndc) {
        this.aimRay(ndc);
        const list = this.current.inspectionObjects;
        return this.ray.intersectObjects(list, true)[0] ?? null;
    }
    findLabeled(o) { let obj = o; while (obj) {
        if (obj.userData.label)
            return obj;
        obj = obj.parent;
    } return o; }
    pointerDown(e) {
        if (this.transition || e.button > 0 || this.pointerId !== null)
            return;
        this.canvas.setPointerCapture(e.pointerId);
        this.pointerId = e.pointerId;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.prevX = e.clientX;
        this.prevY = e.clientY;
        const ndc = pathXY(e, this.canvas), pos = new THREE.Vector2(ndc.x, ndc.y);
        const hit = this.objectHit(pos);
        this.gesture = 'none';
        if (this.tool === 'gravity' && this.world === 0) {
            this.store.beginTransient(['gravity']);
            this.gesture = 'gravity';
            return;
        }
        if (this.tool === 'sculpt' && this.world === 1) {
            const p = this.aimedTerrainPoint(pos);
            if (p) {
                const zone = TERRAIN_ZONES.findIndex(z => Math.hypot(z.x - p.x, z.z - p.z) < z.radius * 1.5);
                if (zone >= 0) {
                    this.store.beginTransient(['terrain']);
                    this.activeZone = zone;
                    this.gesture = 'sculpt';
                    return;
                }
            }
        }
        if (this.tool === 'river' && this.world === 1) {
            const p = this.aimedTerrainPoint(pos);
            if (p) {
                this.riverPoints = [[p.x, p.z]];
                this.gesture = 'river';
                this.updateRiverGuide();
                return;
            }
        }
        if (this.tool === 'seed' && this.world === 1) {
            const p = this.aimedTerrainPoint(pos);
            if (p) {
                this.plantAt(p.x, p.z);
                this.gesture = 'none';
                return;
            }
        }
        if (this.tool === 'wildlife' && this.world === 1) {
            const target = hit ? this.findLabeled(hit.object) : null;
            if (target?.userData.action === 'marker') {
                const x = target.position.x, z = target.position.z;
                this.store.change(s => { s.wildlifeMarkers = s.wildlifeMarkers.filter(p => Math.hypot(p[0] - x, p[1] - z) > 2.5); });
                this.ui.showToast('The attraction marker dissipates.');
                return;
            }
            const p = this.aimedTerrainPoint(pos);
            if (p)
                this.addMarker(p.x, p.z);
            return;
        }
        if (this.tool === 'constellation' && this.world === 2) {
            const star = hit ? this.current.getStarId(hit.object) : null;
            if (star !== null) {
                if (this.starStart !== null && this.starStart !== star) {
                    this.connectStar(this.starStart, star);
                    this.starStart = null;
                }
                else
                    this.starStart = star;
                this.gesture = 'star';
                return;
            }
        }
        if (this.tool === 'moon' && this.world === 1) {
            this.store.beginTransient(['moonAngle']);
            this.gesture = 'moon';
            return;
        }
        if (this.tool === 'light' && this.world === 1) {
            const obj = hit ? this.findLabeled(hit.object) : null;
            const idx = this.current.prisms.indexOf(obj);
            this.selectedPrism = idx >= 0 ? idx : 0;
            this.store.beginTransient([this.selectedPrism === 0 ? 'prismAngle' : 'mirrorAngle']);
            this.gesture = 'prism';
            return;
        }
        if (this.tool === 'ruins' && this.world === 1) {
            const idx = hit ? this.current.getRuinId(hit.object) : -1;
            if (idx >= 0) {
                this.store.beginTransient(['ruins']);
                this.selectedRuin = idx;
                this.gesture = 'ruin';
                return;
            }
        }
        if (this.tool === 'inspect') {
            this.gesture = this.navigator.mode === 'orbit' ? 'none' : 'look';
        }
    }
    pointerMove(e) {
        if (this.pointerId !== e.pointerId || this.transition)
            return;
        const dx = e.clientX - this.prevX, dy = e.clientY - this.prevY;
        this.prevX = e.clientX;
        this.prevY = e.clientY;
        if (this.gesture === 'look') {
            this.navigator.look(dx, dy);
            return;
        }
        if (this.gesture === 'gravity') {
            this.store.change(s => { s.gravity[0] = clamp(s.gravity[0] + dx * .008, -1, 1); s.gravity[1] = clamp(s.gravity[1] - dy * .008, -1, 1); });
            return;
        }
        if (this.gesture === 'sculpt' && Math.abs(dy) > .1) {
            this.store.change(s => { s.terrain[this.activeZone] = clamp(s.terrain[this.activeZone] - dy * .054, -13, 18); });
            return;
        }
        if (this.gesture === 'river') {
            const { x, y } = pathXY(e, this.canvas), p = this.aimedTerrainPoint(new THREE.Vector2(x, y));
            if (p && this.riverPoints.length < 96) {
                const last = this.riverPoints[this.riverPoints.length - 1];
                if (!last || Math.hypot(p.x - last[0], p.z - last[1]) > 1.5) {
                    this.riverPoints.push([p.x, p.z]);
                    this.updateRiverGuide();
                }
            }
            return;
        }
        if (this.gesture === 'star' && this.starStart !== null) {
            const { x, y } = pathXY(e, this.canvas), hit = this.objectHit(new THREE.Vector2(x, y));
            const index = hit ? this.current.getStarId(hit.object) : null;
            if (index !== null && index !== this.starStart)
                this.ui.setCaption(`Release to connect star ${this.starStart + 1} to star ${index + 1}.`);
            return;
        }
        if (this.gesture === 'moon') {
            this.store.change(s => { s.moonAngle = (s.moonAngle + dx * .009 + Math.PI * 2) % (Math.PI * 2); });
            return;
        }
        if (this.gesture === 'prism') {
            this.store.change(s => {
                const key = this.selectedPrism === 0 ? 'prismAngle' : 'mirrorAngle';
                s[key] = clamp(s[key] + dx * .008, -Math.PI, Math.PI);
            });
            return;
        }
        if (this.gesture === 'ruin') {
            const { x, y } = pathXY(e, this.canvas), p = this.aimedTerrainPoint(new THREE.Vector2(x, y));
            if (p) {
                this.store.change(s => { const r = s.ruins[this.selectedRuin]; r.x = p.x; r.z = p.z; r.snapped = false; });
            }
            return;
        }
    }
    pointerUp(e) {
        if (this.pointerId !== e.pointerId)
            return;
        this.pointerId = null;
        const moved = Math.hypot(e.clientX - this.startX, e.clientY - this.startY);
        const { x, y } = pathXY(e, this.canvas), point = new THREE.Vector2(x, y);
        if (this.gesture === 'river') {
            if (this.riverPoints.length >= 3)
                this.commitRiver();
            else {
                this.ui.showToast('Trace a longer route to carve a channel.');
                this.riverPoints = [];
                this.cleanupRiverGuide();
            }
        }
        else if (this.gesture === 'star' && this.starStart !== null) {
            const hit = this.objectHit(point);
            const star = hit ? this.current.getStarId(hit.object) : null;
            if (star !== null && star !== this.starStart) {
                this.connectStar(this.starStart, star);
                this.starStart = null;
            }
            else
                this.ui.showToast(`Star ${this.starStart + 1} selected · choose another star.`);
        }
        else if (this.gesture === 'ruin') {
            const r = this.store.data.ruins[this.selectedRuin], goals = [[28, 43], [32, 43], [30, 47]];
            const goal = goals[this.selectedRuin];
            if (Math.hypot(r.x - goal[0], r.z - goal[1]) < 5.2)
                this.snapRuin(this.selectedRuin, false);
            else
                this.ui.showToast('The stone remains where you left it. Align it with the socket.');
        }
        else if (this.gesture === 'sculpt') {
            const z = TERRAIN_ZONES[this.activeZone];
            this.pulseTerrain(z.x, z.z, 0xa3c6a9, 3);
        }
        else if ((this.gesture === 'none' || this.gesture === 'look') && this.tool === 'inspect' && moved < 10) {
            this.inspectAt(point);
        }
        this.store.commitTransient();
        this.gesture = 'none';
        try {
            this.canvas.releasePointerCapture(e.pointerId);
        }
        catch { /* pointer may already have been cancelled */ }
    }
    cancelGesture(pointer) {
        if (this.pointerId === null || (pointer !== undefined && this.pointerId !== pointer))
            return;
        const id = this.pointerId;
        this.pointerId = null;
        this.starStart = null;
        if (this.gesture === 'river') {
            this.riverPoints = [];
            this.cleanupRiverGuide();
        }
        // Browser interruption and touch cancellation must not commit half-dragged state.
        this.store.cancelTransient();
        this.gesture = 'none';
        try {
            this.canvas.releasePointerCapture(id);
        }
        catch { /* capture may already have ended */ }
    }
    cleanupRiverGuide() {
        if (!this.riverGuide)
            return;
        this.current.scene.remove(this.riverGuide);
        this.riverGuide.geometry.dispose();
        this.riverGuide.material.dispose();
        this.riverGuide = null;
    }
    updateRiverGuide() {
        this.cleanupRiverGuide();
        if (this.world !== 1 || !this.riverPoints.length)
            return;
        const vertices = this.riverPoints.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z, this.store.data) + 1.0, z));
        const geom = new THREE.BufferGeometry().setFromPoints(vertices);
        this.riverGuide = new THREE.Line(geom, new THREE.LineBasicMaterial({ color: 0xacece4, transparent: true, opacity: .91 }));
        this.current.scene.add(this.riverGuide);
    }
    pulse(x, y, z, color = 0x8bded5, size = 1) {
        this.feedback.pulse(new THREE.Vector3(x, y, z), color, size);
        this.sound.cue(this.world, size);
    }
    pulseTerrain(x, z, color = 0x8bded5, size = 1) {
        this.pulse(x, heightAt(x, z, this.store.data) + .55, z, color, size);
    }
    commitRiver() {
        if (this.riverPoints.length < 2)
            return;
        const points = this.riverPoints.slice();
        this.store.checkpoint();
        this.store.change(s => {
            if (s.rivers.length >= 8)
                s.rivers.shift();
            // Snap a near-water source to the primary river without teleports.
            const first = points[0];
            const bank = -17 + Math.sin(first[1] * .043 + .4) * 10 + Math.cos(first[1] * .087) * 4;
            if (Math.abs(first[0] - bank) < 7)
                first[0] = bank;
            s.rivers.push(points);
        });
        this.cleanupRiverGuide();
        this.riverPoints = [];
        this.pulseTerrain(points[points.length - 1][0], points[points.length - 1][1], 0x8dcbd3, 3);
        if (heartIrrigation(this.store.data) > .48)
            this.store.recordObservation('water-law');
        this.ui.showToast('A new river now runs through actual terrain geometry.');
    }
    plantAt(x, z) {
        if (this.store.data.seeds.length >= 80) {
            this.ui.showToast('The seed garden is full (80 plants).');
            return;
        }
        this.store.checkpoint();
        this.store.change(s => { const id = Math.max(0, ...s.seeds.map(p => p.id)) + 1; s.seeds.push({ id, x: clamp(x, -115, 115), z: clamp(z, -115, 115), age: 0 }); });
        this.pulseTerrain(x, z, 0x97d2a7, 1.5);
        this.ui.showToast('A living seed takes root. Time now grows it.');
    }
    addMarker(x, z) {
        this.store.checkpoint();
        this.store.change(s => { s.wildlifeMarkers.push([x, z]); if (s.wildlifeMarkers.length > 6)
            s.wildlifeMarkers.shift(); });
        this.pulseTerrain(x, z, 0xdbc58d, 2);
        this.ui.showToast('A quiet signal travels into the wildlife.');
    }
    snapRuin(id, withCheckpoint = true) {
        if (withCheckpoint)
            this.store.checkpoint();
        const targets = [[28, 43], [32, 43], [30, 47]];
        this.store.change(s => { const p = s.ruins[id]; p.x = targets[id][0]; p.z = targets[id][1]; p.angle = 0; p.snapped = true; });
        this.pulseTerrain(targets[id][0], targets[id][1], 0x8ef5d5, 3);
        this.ui.showToast(ruinsComplete(this.store.data) ? 'All stones restored. The ancient beacon awakens.' : 'The fragment locks into its original foundation.');
    }
    connectStar(a, b) {
        if (a === b)
            return;
        const edge = edgeKey(a, b);
        if (this.store.data.constellations.includes(edge)) {
            this.ui.showToast('That celestial connection already exists.');
            return;
        }
        this.store.checkpoint();
        this.store.change(s => {
            s.constellations.push(edge);
            for (const key of constellationCompletion(s.constellations))
                if (!s.constellations.includes(key))
                    s.constellations.push(key);
        });
        const star = STAR_POINTS[b];
        if (star)
            this.pulse(star[0], star[1], star[2], 0xb2d0f6, 3);
        const completed = constellationCompletion(this.store.data.constellations);
        this.ui.showToast(completed.length ? `${completed.length} constellation structures awakened. Their geometry echoes in the Observatory.` : 'Stars linked. The luminous path holds.');
    }
    keyboard(e, down) {
        const target = e.target;
        if (target?.closest('input, select, textarea, button') && e.code !== 'Escape')
            return;
        if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code))
            e.preventDefault();
        this.navigator.key(e.code, down);
        if (!down || e.repeat)
            return;
        if (e.code === 'KeyH')
            this.ui.toggleHidden();
        if (e.code === 'KeyO')
            this.action('mode');
        if (e.code === 'KeyG') {
            this.setMode('walk');
        }
        if (e.code === 'KeyC')
            this.action('reset-camera');
        if (e.code === 'KeyF')
            this.action('focus');
        if (e.code === 'KeyR' && this.world > 0)
            this.requestTravel((this.world - 1));
        if (e.code === 'KeyE' && this.world < 2)
            this.requestTravel((this.world + 1));
        if (e.code === 'KeyI')
            this.inspectAt(new THREE.Vector2(0, 0));
        if (e.code === 'KeyJ')
            this.ui.toggleJournal();
        if (e.code === 'KeyV')
            this.toggleDiagnostics();
        if (e.code === 'KeyX')
            this.action('resonance-toggle');
        if (e.code === 'KeyM')
            this.ui.toggleAtlas();
        if (e.code === 'KeyP')
            this.action('photo-toggle');
        if (e.code === 'KeyK' && this.photoActive)
            this.action('photo-capture');
        if (e.code === 'KeyZ' && !e.altKey)
            this.action('undo');
        if (e.code === 'KeyY' && !e.altKey)
            this.action('redo');
        if (e.code === 'Escape') {
            this.cancelGesture();
            if (this.photoActive) {
                this.action('photo-toggle');
                return;
            }
            this.queuedTravel = null;
            this.navigator.stopMotion();
            this.tool = 'inspect';
            this.navigator.orbit.enabled = this.navigator.mode === 'orbit';
            this.ui.refresh(true);
        }
    }
    toggleDiagnostics() {
        const hud = document.getElementById('diagnostic-hud');
        if (!hud)
            return;
        hud.hidden = !hud.hidden;
        if (!hud.hidden)
            this.updateProbe();
    }
    inspectAt(point) {
        const hit = this.objectHit(point);
        if (!hit) {
            this.ui.showToast('No inspectable object in view.');
            return;
        }
        const target = this.findLabeled(hit.object);
        let ancestor = hit.object;
        while (ancestor && !ancestor.userData.clueId)
            ancestor = ancestor.parent;
        const id = String(ancestor?.userData.clueId ?? target.userData.clueId ?? '');
        this.ui.showToast(String(target.userData.label || 'An unfamiliar structure.'));
        this.ui.setCaption(String(target.userData.label || 'An unfamiliar structure.'));
        if (id === 'gravity-reliquary' && !gravityAligned(this.store.data)) {
            this.ui.showToast('The stone lens is displaced. Its bridge moves with the outer droplet.');
            return;
        }
        if (id) {
            const discovery = observationById(id);
            if (discovery && this.store.recordObservation(id)) {
                this.ui.showToast('OBSERVATION · ' + discovery.title);
                this.ui.refresh(true);
            }
        }
        if (this.world === 0 && finaleReady(this.store.data) && !this.store.data.endingSeen &&
            (id === 'outer-drop' || id === 'outer-instrument')) {
            this.store.change(s => { s.endingSeen = true; s.knowledge.push('concordance'); });
            this.ui.showToast('THE CONCORDANCE · Three scales have answered one another. The first drop was never alone.');
            this.ui.toggleJournal(true);
        }
    }
    action(action, value) {
        if (action === 'hold-on' || action === 'hold-off') {
            if (value)
                this.navigator.key(value, action === 'hold-on');
            return;
        }
        if (this.transition && action !== 'hide')
            return;
        const s = this.store.data;
        const n = Number(value);
        if (action === 'edit-end') {
            this.editingField = null;
            return;
        }
        if (action.startsWith('input:') || action.startsWith('change:')) {
            const field = action.split(':')[1];
            if (action.startsWith('input:') && !['sculptZone', 'starGroup', 'ruinPiece', 'sound'].includes(field) && this.editingField !== field) {
                this.store.checkpoint();
                this.editingField = field;
            }
            switch (field) {
                case 'time':
                    this.store.change(s => { s.time = clamp(n, 0, 24); });
                    break;
                case 'weather':
                    this.store.change(s => { s.weather = value; });
                    break;
                case 'season':
                    if (value === 'Spring' || value === 'Summer' || value === 'Autumn' || value === 'Winter')
                        this.store.change(s => { s.season = value; });
                    break;
                case 'quality': {
                    if (value !== 'low' && value !== 'medium' && value !== 'high')
                        break;
                    this.store.change(s => { s.quality = value; });
                    this.applyQuality();
                    break;
                }
                case 'reducedMotion':
                    this.store.change(s => { s.reducedMotion = value === 'true'; });
                    break;
                case 'adaptiveQuality':
                    this.store.change(s => { s.adaptiveQuality = value === 'true'; });
                    this.adaptive.enabled = this.store.data.adaptiveQuality;
                    if (!this.adaptive.enabled) {
                        this.adaptive.reset();
                        this.resize();
                    }
                    break;
                case 'sound':
                    void this.sound.setEnabled(value === 'true');
                    break;
                case 'gravityX':
                    this.store.change(s => { s.gravity[0] = n / 100; });
                    break;
                case 'gravityZ':
                    this.store.change(s => { s.gravity[1] = n / 100; });
                    break;
                case 'sculptZone':
                    this.activeZone = clamp(n, 0, 2);
                    break;
                case 'starGroup':
                    this.selectedStarGroup = clamp(n, 0, 2);
                    break;
                case 'ruinPiece':
                    this.selectedRuin = clamp(n, 0, 2);
                    break;
                case 'moonAngle':
                    this.store.change(s => { s.moonAngle = n * Math.PI / 180; });
                    break;
                case 'prismAngle':
                    this.store.change(s => { s.prismAngle = n * Math.PI / 180; });
                    break;
                case 'mirrorAngle':
                    this.store.change(s => { s.mirrorAngle = n * Math.PI / 180; });
                    break;
            }
            return;
        }
        if (['sculpt-up', 'sculpt-down', 'river-delete', 'markers-clear', 'gravity-zero'].includes(action))
            this.store.checkpoint();
        switch (action) {
            case 'resonance-toggle': {
                this.resonanceOn = !this.resonanceOn;
                writeResonancePreference(this.resonanceOn);
                this.resonance.setEnabled(this.resonanceOn);
                this.ui.refresh(true);
                this.ui.showToast(this.resonanceOn ? 'RESONANCE SIGHT · Actual cross-scale causes are illuminated.' : 'Resonance sight released.');
                break;
            }
            case 'save-recovery': {
                const raw = this.store.recoverableRawSave;
                if (raw)
                    this.downloadText(raw, `INFINITUM-RECOVERY-${Date.now()}.json`);
                else
                    this.ui.showToast('No damaged save is held in this browser.');
                break;
            }
            case 'photo-toggle':
                this.photoActive = !this.photoActive;
                this.ui.setPhotoMode(this.photoActive);
                this.ui.showToast(this.photoActive ? 'Photo mode active. Press K to capture, P to exit.' : 'Free exploration restored.');
                break;
            case 'photo-capture':
                this.photoRequested = true;
                break;
            case 'atlas':
                this.ui.toggleAtlas();
                break;
            case 'focus-landmark': {
                const mark = value ? landmarkById(value) : undefined;
                if (mark && mark.world === this.world) {
                    this.navigator.animateTo(new THREE.Vector3(...mark.position), mark.approach, this.store.data.reducedMotion ? .75 : 2.9);
                    this.ui.showToast('Following the route to ' + mark.name + '.');
                }
                break;
            }
            case 'undo': {
                const beforeQuality = this.store.data.quality;
                if (this.store.undo()) {
                    if (this.store.data.quality !== beforeQuality)
                        this.applyQuality();
                    else
                        this.recreateCurrent();
                    this.adaptive.enabled = this.store.data.adaptiveQuality;
                    if (!this.adaptive.enabled) {
                        this.adaptive.reset();
                        this.resize();
                    }
                    this.ui.refresh(true);
                    this.ui.showToast('The last world edit has been reversed.');
                }
                else
                    this.ui.showToast('Nothing to undo.');
                break;
            }
            case 'redo': {
                const beforeQuality = this.store.data.quality;
                if (this.store.redo()) {
                    if (this.store.data.quality !== beforeQuality)
                        this.applyQuality();
                    else
                        this.recreateCurrent();
                    this.adaptive.enabled = this.store.data.adaptiveQuality;
                    if (!this.adaptive.enabled) {
                        this.adaptive.reset();
                        this.resize();
                    }
                    this.ui.refresh(true);
                    this.ui.showToast('The last world edit has returned.');
                }
                else
                    this.ui.showToast('Nothing to redo.');
                break;
            }
            case 'save-export': {
                try {
                    const pos = this.camera.position, target = this.navigator.target;
                    const explorer = { schema: 1, world: this.world, mode: this.navigator.mode,
                        position: [pos.x, pos.y, pos.z], target: [target.x, target.y, target.z] };
                    const bundle = createPortableExpedition(this.store.exportSave(), explorer);
                    this.downloadText(JSON.stringify(bundle, null, 2), `INFINITUM-EXPEDITION-${Date.now()}.json`);
                }
                catch (error) {
                    this.ui.showToast('Save export failed: ' + String(error));
                }
                break;
            }
            case 'save-browse':
                this.ui.root.querySelector('#import-save')?.click();
                break;
            case 'save-import': {
                if (!value)
                    return;
                try {
                    const parsed = JSON.parse(value);
                    const packageInfo = inspectPortableExpedition(parsed);
                    if (!packageInfo)
                        throw new Error('Invalid or unsupported save format');
                    if (!window.confirm('Replace this expedition with the imported simulation and camera (when included)?'))
                        break;
                    if (!this.store.importSave(packageInfo.simulation))
                        throw new Error('Invalid simulation data');
                    this.storedPoses.clear();
                    this.queuedTravel = null;
                    if (packageInfo.explorer)
                        this.world = packageInfo.explorer.world;
                    this.adaptive.reset();
                    this.adaptive.enabled = this.store.data.adaptiveQuality;
                    this.resize();
                    this.recreateCurrent();
                    if (packageInfo.explorer)
                        this.navigator.setMode(packageInfo.explorer.mode, this.poseFromMemory(packageInfo.explorer));
                    else
                        this.navigator.setMode('orbit', this.current.spawn);
                    this.saveExplorerPose();
                    this.preview.update(this.store.data, this.elapsed, true, visibleMiniatureTargets(this.world));
                    this.ui.refresh(true);
                    this.ui.showToast('Simulation and exploration position restored.');
                }
                catch (error) {
                    this.ui.showToast('Import refused: ' + String(error));
                }
                break;
            }
            case 'enter':
                if (this.world < 2)
                    this.requestTravel((this.world + 1));
                break;
            case 'back':
                if (this.world > 0)
                    this.requestTravel((this.world - 1));
                break;
            case 'focus':
                this.focusPortal();
                break;
            case 'inspect-aim':
                this.inspectAt(new THREE.Vector2(0, 0));
                break;
            case 'journal':
                this.ui.toggleJournal();
                break;
            case 'diagnostics':
                this.toggleDiagnostics();
                break;
            case 'echo-display': {
                if (value && this.store.selectEcho(Number(value))) {
                    this.renderEchoGhost();
                    const past = this.store.selectedEcho;
                    if (this.world === 1 && past && echoDifferences(s, past.data).length > 0)
                        this.store.recordObservation('temporal-history');
                    this.ui.refresh(true);
                }
                break;
            }
            case 'reset-camera':
                this.navigator.setPose(this.current.spawn);
                this.ui.showToast('Camera reset to the authored vantage.');
                break;
            case 'mode': {
                const next = this.navigator.mode === 'orbit' ? 'fly' : this.navigator.mode === 'fly' ? 'walk' : 'orbit';
                this.setMode(next);
                break;
            }
            case 'pause-time':
                this.store.change(s => { s.paused = !s.paused; });
                this.ui.showToast(this.store.data.paused ? 'Time held.' : 'The shared clock resumes.');
                break;
            case 'rate-half':
                this.store.change(s => { s.timeRate = clamp(s.timeRate * .5, .003, 12); });
                break;
            case 'rate-double':
                this.store.change(s => { s.timeRate = clamp(s.timeRate * 2, .003, 12); });
                break;
            case 'gravity-zero':
                this.store.change(s => { s.gravity = [0, 0]; });
                break;
            case 'sculpt-up':
                this.store.change(s => { s.terrain[this.activeZone] = clamp(s.terrain[this.activeZone] + 2, -13, 18); });
                this.pulseTerrain(TERRAIN_ZONES[this.activeZone].x, TERRAIN_ZONES[this.activeZone].z, 0xa3c6a9, 5);
                this.ui.showToast('Earth lifted. Instanced trees follow the contour.');
                break;
            case 'sculpt-down':
                this.store.change(s => { s.terrain[this.activeZone] = clamp(s.terrain[this.activeZone] - 2, -13, 18); });
                this.pulseTerrain(TERRAIN_ZONES[this.activeZone].x, TERRAIN_ZONES[this.activeZone].z, 0xa3c6a9, 5);
                this.ui.showToast('Earth lowered. The horizon changes outside the drop.');
                break;
            case 'river-waypoint': {
                const p = this.aimedTerrainPoint();
                if (p) {
                    this.riverPoints.push([p.x, p.z]);
                    this.updateRiverGuide();
                    this.ui.showToast(`${this.riverPoints.length} river waypoint(s) placed.`);
                }
                break;
            }
            case 'river-finish':
                if (this.riverPoints.length >= 2)
                    this.commitRiver();
                else
                    this.ui.showToast('Add at least two aimed waypoints.');
                break;
            case 'river-undo':
                this.riverPoints.pop();
                this.updateRiverGuide();
                break;
            case 'river-delete':
                this.store.change(s => { s.rivers.pop(); });
                this.ui.showToast('The most recent user-made channel is removed.');
                break;
            case 'plant-ahead': {
                const p = this.aimedTerrainPoint();
                if (p)
                    this.plantAt(p.x, p.z);
                break;
            }
            case 'star-next': {
                const edge = nextConstellationEdge(s, this.selectedStarGroup);
                if (!edge) {
                    this.ui.showToast('This constellation is already complete. Choose another.');
                    return;
                }
                const m = /^edge:(\d+)-(\d+)$/.exec(edge);
                if (m)
                    this.connectStar(Number(m[1]), Number(m[2]));
                break;
            }
            case 'marker-ahead': {
                const p = this.aimedTerrainPoint();
                if (p)
                    this.addMarker(p.x, p.z);
                break;
            }
            case 'markers-clear':
                this.store.change(s => { s.wildlifeMarkers = []; });
                this.ui.showToast('Wildlife returns to its original routes.');
                break;
            case 'ruin-snap':
                this.snapRuin(this.selectedRuin);
                break;
            case 'echo-capture': {
                const e = this.store.capture();
                this.ui.showToast(`TEMPORAL ECHO ${e.id} CAPTURED. Your past now exists in parallel.`);
                this.renderEchoGhost();
                break;
            }
            case 'echo-restore': {
                if (value && this.store.restore(Number(value))) {
                    this.recreateCurrent();
                    this.renderEchoGhost();
                    this.ui.showToast('The former world returns: land, light, weather, wildlife and geometry.');
                }
                break;
            }
            case 'reset-state': {
                if (window.confirm('Reset all simulation changes and snapshots in this browser?')) {
                    this.store.reset();
                    clearExplorer();
                    this.recreateCurrent();
                    this.ui.showToast('The original impossibility has been restored.');
                }
                break;
            }
        }
        // Refresh low-frequency panel data without rebuilding controls during a slider drag.
        if (['echo-capture', 'echo-restore', 'ruin-snap', 'star-next', 'plant-ahead', 'echo-display'].includes(action))
            this.ui.refresh(true);
    }
    applyQuality() {
        this.adaptive.reset();
        this.adaptive.enabled = this.store.data.adaptiveQuality;
        this.renderer.shadowMap.enabled = this.store.data.quality !== 'low';
        this.renderer.transmissionResolutionScale = this.store.data.quality === 'high' ? .75 : this.store.data.quality === 'medium' ? .55 : .3;
        this.resize();
        this.preview.update(this.store.data, this.elapsed, true, visibleMiniatureTargets(this.world));
        this.recreateCurrent();
        this.ui.showToast('Quality budget applied: ' + this.store.data.quality.toUpperCase());
    }
    recreateCurrent() {
        const pose = { position: this.camera.position.clone(), target: this.navigator.target };
        this.cleanupRiverGuide();
        this.clearEchoGhost();
        this.feedback.dispose();
        this.beacons.dispose();
        this.resonance.dispose();
        this.current.dispose();
        this.current = this.makeWorld(this.world);
        this.beacons = new ExpeditionBeacons(this.current.scene, this.world);
        this.resonance = new ResonanceLens(this.current.scene, this.world);
        this.resonance.setEnabled(this.resonanceOn);
        this.feedback = new InteractionFeedback(this.current.scene, this.store.data.quality === 'low' ? 7 : 13);
        this.current.sync(this.store.data);
        this.navigator.setPose(pose);
        if (this.store.selectedEcho)
            this.renderEchoGhost();
    }
    // Echo geometry is a visible rendition of the previously captured world, not merely a save label.
    echoGhost = null;
    clearEchoGhost() {
        if (!this.echoGhost)
            return;
        this.current.scene.remove(this.echoGhost);
        this.echoGhost.traverse(o => {
            const m = o;
            m.geometry?.dispose();
            if (m.material)
                for (const mat of Array.isArray(m.material) ? m.material : [m.material])
                    mat.dispose();
        });
        this.echoGhost = null;
    }
    renderEchoGhost() {
        this.clearEchoGhost();
        if (!this.store.echoes.length)
            return;
        const past = this.store.selectedEcho;
        if (!past)
            return;
        const ghost = new THREE.Group();
        if (this.world === 1) {
            const mesh = new THREE.Mesh(new THREE.PlaneGeometry(240, 240, 64, 64), new THREE.MeshBasicMaterial({ color: 0x89d5df, wireframe: true, transparent: true, opacity: .17, depthWrite: false }));
            mesh.rotation.x = -Math.PI / 2;
            const positions = mesh.geometry.getAttribute('position');
            // Geometry is in XY before rotation; its Y maps to negative world Z after rotation.
            for (let i = 0; i < positions.count; i++) {
                const x = positions.getX(i), z = -positions.getY(i);
                positions.setZ(i, heightAt(x, z, past.data) + 1.3);
            }
            positions.needsUpdate = true;
            mesh.geometry.computeVertexNormals();
            ghost.add(mesh);
            const lineMat = new THREE.LineBasicMaterial({ color: 0x7de0e7, transparent: true, opacity: .58, depthWrite: false });
            for (const path of past.data.rivers) {
                const points = path.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z, past.data) + .56, z));
                if (points.length > 1)
                    ghost.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), lineMat.clone()));
            }
            lineMat.dispose();
            for (const seed of past.data.seeds.slice(0, 50)) {
                const crystal = new THREE.Mesh(new THREE.ConeGeometry(.38 + seed.age * .3, 1.4 + seed.age * 3.3, 5), new THREE.MeshBasicMaterial({ color: 0x8fefd1, transparent: true, opacity: .24, wireframe: true, depthWrite: false }));
                crystal.position.set(seed.x, heightAt(seed.x, seed.z, past.data) + 1, seed.z);
                ghost.add(crystal);
            }
        }
        else if (this.world === 0) {
            const oldDrop = new THREE.Mesh(new THREE.SphereGeometry(4, 30, 20), new THREE.MeshBasicMaterial({ color: 0x9de6e9, wireframe: true, transparent: true, opacity: .20, depthWrite: false }));
            oldDrop.position.set(0, 12.6, 0);
            oldDrop.rotation.set(past.data.gravity[1] * .21, 0, past.data.gravity[0] * .26);
            oldDrop.scale.set(1, 1.32, 1);
            ghost.add(oldDrop);
        }
        else {
            const color = new THREE.LineBasicMaterial({ color: 0xa7f5e5, transparent: true, opacity: .32, depthWrite: false });
            for (const e of past.data.constellations) {
                const match = /^edge:(\d+)-(\d+)$/.exec(e);
                if (!match)
                    continue;
                const a = STAR_POINTS[Number(match[1])], b = STAR_POINTS[Number(match[2])];
                if (!a || !b)
                    continue;
                const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...a), new THREE.Vector3(...b)]), color.clone());
                ghost.add(line);
            }
            if (!ghost.children.length) {
                const orbit = new THREE.Mesh(new THREE.TorusGeometry(17, .18, 6, 90), new THREE.MeshBasicMaterial({ color: 0x8bd5dd, wireframe: true, transparent: true, opacity: .22, depthWrite: false }));
                orbit.rotation.x = .36 + past.data.moonAngle * .2;
                orbit.position.set(0, 49, -70);
                ghost.add(orbit);
            }
            color.dispose();
        }
        this.echoGhost = ghost;
        this.current.scene.add(ghost);
    }
    performanceStats() { return this.framePercentiles(); }
    dispose() {
        this.renderer.setAnimationLoop(null);
        this.store.save();
        this.saveExplorerPose();
        this.unsubscribeState?.();
        this.beacons.dispose();
        this.resonance.dispose();
        this.cleanupRiverGuide();
        this.clearEchoGhost();
        this.feedback.dispose();
        this.canvas.removeEventListener('pointerdown', this.downHandler);
        this.canvas.removeEventListener('pointermove', this.moveHandler);
        this.canvas.removeEventListener('pointerup', this.upHandler);
        this.canvas.removeEventListener('pointercancel', this.cancelHandler);
        this.canvas.removeEventListener('wheel', this.wheelHandler);
        window.removeEventListener('keydown', this.keyDown);
        window.removeEventListener('keyup', this.keyUp);
        window.removeEventListener('blur', this.focusLost);
        document.removeEventListener('visibilitychange', this.onVisibility);
        window.removeEventListener('pagehide', this.onPageHide);
        this.resizeObserver.disconnect();
        this.navigator.dispose();
        this.current.dispose();
        this.transition?.to.dispose();
        this.composer.dispose();
        this.preview.dispose();
        this.ui.dispose();
        this.renderer.dispose();
        this.sound.dispose();
    }
}
let experience = null;
try {
    experience = new Infinitum();
    window.__INFINITUM_TEST__ = {
        get state() { return experience?.store.data; },
        get scene() { return experience?.world; },
        get objects() { return experience?.current.scene.children.length; },
        echoIds: () => experience?.store.echoes.map(e => e.id) ?? [],
        sceneFeatures: () => {
            const counts = {};
            experience?.current.scene.traverse(o => {
                const feature = o.userData.feature;
                if (feature && o.visible)
                    counts[feature] = (counts[feature] ?? 0) + 1;
            });
            return counts;
        },
        get transition() { return experience?.transition?.elapsed ?? null; },
        get navigation() { return experience?.navigationMode; },
        get resumeWorld() { return experience?.world; },
        get photoMode() { return experience?.photoMode; },
        get resonance() { return experience?.resonanceActive; },
        get saveStatus() { return experience?.saveStatus; },
        get resolutionScale() { return experience?.resolutionScale; },
        get previewPasses() { return experience?.preview.renderPasses ?? 0; },
        get narrative() { return experience ? { status: narrativeStatus(experience.store.data), observations: experience.store.data.knowledge } : null; },
        action: (name, v) => experience?.action(name, v),
        tool: (name) => experience?.setTool(name),
        stats: () => ({ calls: experience?.renderer.info.render.calls, triangles: experience?.renderer.info.render.triangles, geometries: experience?.renderer.info.memory.geometries, textures: experience?.renderer.info.memory.textures, frames: experience?.performanceStats() })
    };
}
catch (error) {
    const fatal = document.querySelector('#fatal');
    if (fatal) {
        fatal.hidden = false;
        fatal.textContent = 'INFINITUM needs a WebGL-capable browser. ' + String(error);
    }
    console.error('INFINITUM initialization failure', error);
}
