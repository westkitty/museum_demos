/** Scene-graph integration with actual Three.js geometry/material classes; WebGL backend is stubbed.
 * This does not demonstrate that shaders render in a physical browser. */
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import * as T from '../vendor/three.module.min.js';

class RendererStub{
  constructor(){this.info={render:{calls:0,triangles:0},memory:{geometries:0,textures:0}};this.disposed=false;}
  setSize(w,h){this.size=[w,h];}
  setPixelRatio(v){this.ratio=v;}
  render(scene,camera){
    let calls=0,triangles=0,geometries=new Set(),textures=new Set();
    scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);
    const projection=new T.Matrix4().multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);
    const frustum=new T.Frustum().setFromProjectionMatrix(projection);
    scene.traverseVisible(obj=>{
      if(obj.isMesh||obj.isSprite){
        if(obj.frustumCulled!==false && !(obj.isSprite?frustum.intersectsSprite(obj):frustum.intersectsObject(obj)))return;
        calls++;
        if(obj.geometry){geometries.add(obj.geometry);const count=obj.geometry.index?.count??obj.geometry.attributes.position?.count??0;triangles+=count/3*(obj.isInstancedMesh?obj.count:1);}
        if(obj.material?.map)textures.add(obj.material.map);
      }
    });
    this.info.render={calls,triangles};this.info.memory={geometries:geometries.size,textures:textures.size};
  }
  dispose(){this.disposed=true;}
}
function fakeDocument(){
  const gradient=()=>({addColorStop(){}});
  const ctx={createLinearGradient:gradient,createRadialGradient:gradient,fillRect(){},strokeRect(){},fillText(){},beginPath(){},closePath(){},moveTo(){},lineTo(){},stroke(){},fill(){},arc(){},scale(){}};
  return {createElement(tag){assert.equal(tag,'canvas');return {width:1024,height:512,getContext(){return ctx;}};}};
}
async function constructWorld(){
  const context=vm.createContext({document:fakeDocument(),window:{devicePixelRatio:2,innerWidth:1280,innerHeight:720},console});
  const source=file=>readFileSync(new URL('../src/'+file,import.meta.url),'utf8');
  const all={
    'course':new vm.SourceTextModule(source('course.js'),{context,identifier:'course'}),
    'fx':new vm.SourceTextModule(source('fx.js'),{context,identifier:'fx'}),
    'world':new vm.SourceTextModule(source('world.js'),{context,identifier:'world'}),
  };
  const names=Object.keys(T);
  const vendor=new vm.SyntheticModule(names,function(){for(const name of names)this.setExport(name,name==='WebGLRenderer'?RendererStub:T[name]);},{context});
  const lookup=(specifier)=>{
    if(specifier.endsWith('three.module.min.js'))return vendor;
    if(specifier.endsWith('course.js'))return all.course;
    if(specifier.endsWith('fx.js'))return all.fx;
    throw Error('Unknown import '+specifier);
  };
  await all.world.link(lookup);await all.world.evaluate();
  const canvas={clientWidth:1280,clientHeight:720};
  return all.world.namespace.createWorld(canvas);
}

test('actual Three.js world geometry and animations construct, draw and dispose in isolated scene graph',async()=>{
  const world=await constructWorld();
  assert.ok(world.scene.children.length>8);
  assert.ok(world.collectibles.length===19);
  assert.ok(world.metrics().staticDrawCallsSaved>250,'Static material instancing should meaningfully reduce calls');
  assert.ok(world.metrics().paintedSurfaceCount>=5,'At least five local illustration materials should be present');
  assert.equal(world.metrics().chapterPaintingCount,4,'Four painted landscape layers should be installed');
  const painted=[];world.scene.traverse(node=>{if(node.name?.startsWith('CHAPTER_PAINTING_'))painted.push(node);});
  assert.deepEqual(painted.map(p=>p.name).sort(),['CHAPTER_PAINTING_CEDAR','CHAPTER_PAINTING_DUNCAN','CHAPTER_PAINTING_OUTSKIRTS','CHAPTER_PAINTING_SENTINEL']);
  assert.ok(painted.every(p=>p.material.map?.isCanvasTexture && p.material.transparent),'Chapter paintings must be local alpha textures in the actual scene');
  assert.ok(painted.every(p=>p.material.map.image.width===768 && p.material.map.image.height===384),'Painted horizons have the declared memory-bounded resolution');
  const flags=[];world.scene.traverse(node=>{if(node.name==='DUNCAN_WIND_FLAG')flags.push(node);});
  assert.equal(flags.length,10,'Existing downtown chapter gains ten animated banner surfaces');
  const river=[];world.scene.traverse(node=>{if(node.name==='DISTANT_RIVER')river.push(node);});
  assert.equal(river.length,1,'Forest and sky route share a single distant animated river material');
  const pixels=river[0].material.map;
  const pupils=[];world.scene.traverse(node=>{if(node.name==='CAT_PUPIL')pupils.push(node);});
  assert.equal(pupils.length,2,'Original placeholder cat should have two independently posed pupils');
  assert.equal(world.metrics().lightShafts,16,'Every chapter gets authored shafts; never a per-frame allocation');
  const player={x:2.1,y:1,prevX:2.1,prevY:1,vx:0,vy:0,face:1,grounded:true};
  world.step(player,0,false,1/60,false,false,1);
  const high=world.metrics().drawCalls;
  assert.ok(high>0);
  world.emit('doublejump',player.x,player.y+1);
  world.step(player,0,false,1/60,false,false,.5);
  assert.ok(world.metrics().activeParticles>0);
  assert.ok(pixels.offset.x>0,'The distant river should drift subtly when movement effects are enabled');
  player.x=113;player.y=10.7;player.prevX=112.9;player.prevY=10.7;player.vx=7;
  world.resetView(player);
  world.step(player,97,true,1/60,false,false,.6);
  assert.ok(Number.isFinite(world.camera.position.y));
  assert.equal(world.metrics().owlEchoesVisible,3,'Pursuit must have a restrained silhouette echo at high quality');
  const farCamera=world.camera.position.x;
  world.step(player,110,true,.5,false,false,1);
  assert.ok(world.camera.position.x<farCamera,'Near owl should shift the camera toward the threat, with preserved path ahead');
  world.setQuality('low');world.step(player,97,true,1/60,false,false,1);
  const low=world.metrics().drawCalls;
  console.log('SCENE_METRICS',JSON.stringify({highCalls:high,lowCalls:low,staticSaved:world.metrics().staticDrawCallsSaved,triangles:world.metrics().triangles}));
  assert.ok(low<high,`LOW must reduce visible draw calls: low ${low}, high ${high}`);
  assert.equal(world.metrics().quality,'low');
  assert.equal(world.metrics().owlEchoesVisible,0,'LOW tier must not render shadow echoes');
  world.setQuality('high');world.step(player,97,true,1/60,true,false,1);
  assert.equal(world.metrics().activeParticles,0,'Reduced motion must extinguish moving particles');
  assert.equal(world.metrics().owlEchoesVisible,0,'Reduced motion must suppress owl motion echoes');
  assert.equal(pixels.offset.x,0,'Reduced motion must freeze procedural river texture flow');
  const chapterSamples=[];
  for(const [chapter,x,y] of [['town',9,1],['forest',51,2.9],['cedars',93,10.15],['trestle',136,11.85]]){
    player.prevX=player.x=x;player.prevY=player.y=y;player.vx=0;
    world.resetView(player);
    world.setQuality('high');world.step(player,x-15,chapter==='trestle',1/60,true,false,1);
    const highCalls=world.metrics().drawCalls,highTriangles=world.metrics().triangles;
    world.setQuality('low');world.step(player,x-15,chapter==='trestle',1/60,true,false,1);
    const lowCalls=world.metrics().drawCalls,lowTriangles=world.metrics().triangles;
    chapterSamples.push({chapter,highCalls,lowCalls,highTriangles,lowTriangles});
    assert.ok(highCalls>0&&lowCalls>0&&lowCalls<=highCalls);
    assert.ok(highCalls<260,`${chapter} drawcall estimation exceeded declared visual ceiling`);
  }
  console.log('CHAPTER_FRUSTUM_ESTIMATES',JSON.stringify(chapterSamples));
  player.x=9;player.prevX=9;player.y=1;player.prevY=1;player.vx=6;player.grounded=true;player.vy=0;
  for(let i=0;i<60;i++)world.step(player,0,false,1/60,false,false,1);
  assert.ok(pupils[0].position.x<-.08 && pupils[1].position.x>.16,'Eye gaze must remain anchored to each eye after sustained motion');
  let before=0;world.scene.traverse(()=>before++);
  for(let i=0;i<90;i++)world.step(player,121,true,1/60,false,false,i%2?.7:1);
  let after=0;world.scene.traverse(()=>after++);
  assert.equal(after,before,'Animation must not accumulate scene objects during play');
  const saved=world.metrics().staticDrawCallsSaved;
  world.resetView(player);
  assert.ok(world.metrics().staticDrawCallsSaved===saved);
  const disposableTextures=painted.map(o=>o.material.map);
  let disposals=0;for(const map of disposableTextures)map.addEventListener('dispose',()=>disposals++);
  world.dispose();assert.equal(world.renderer.disposed,true);
  assert.equal(disposals,4,'All four generated art textures must release GPU resources');
});
