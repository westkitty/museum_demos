/** Art-only enrichment layer. No collision, quest state, or input lives here. */
import * as THREE from 'three';
import { CAN, DEW, STATIONS, SUMMIT, SURFACES, VINES } from './course.js';
const GOLD = 0xf4cb7c;
const MINT = 0xa6edc0;
const rng = (seed) => { let s = seed >>> 0; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; };
const noShadow = (mesh) => { mesh.castShadow = false; mesh.receiveShadow = false; return mesh; };
const glow = (hex, opacity = .65) => new THREE.MeshBasicMaterial({ color: hex, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
const matte = (hex, roughness = .86) => new THREE.MeshStandardMaterial({ color: hex, roughness, metalness: .03, side: THREE.DoubleSide });
const attach = (parent, geometry, material, x = 0, y = 0, z = 0) => {
    const m = noShadow(new THREE.Mesh(geometry, material));
    m.position.set(x, y, z);
    parent.add(m);
    return m;
};
const curve = (parent, pts, radius, material) => {
    return attach(parent, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), Math.max(16, pts.length * 8), radius, 5, false), material);
};
const ring = (parent, r, tube, material, x, y, z) => {
    const m = attach(parent, new THREE.TorusGeometry(r, tube, 6, 56), material, x, y, z);
    m.rotation.x = -Math.PI / 2;
    return m;
};
function sunbeamTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 256;
    const context = canvas.getContext('2d');
    const gradient = context.createRadialGradient(64, 94, 4, 64, 122, 133);
    gradient.addColorStop(0, 'rgba(255,248,218,.68)');
    gradient.addColorStop(.25, 'rgba(255,228,176,.23)');
    gradient.addColorStop(1, 'rgba(255,218,161,0)');
    context.fillStyle = gradient;
    context.fillRect(0, 0, 128, 256);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
}
function moteTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const c = canvas.getContext('2d');
    const g = c.createRadialGradient(32, 32, 1, 32, 32, 30);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(.2, 'rgba(255,255,255,.95)');
    g.addColorStop(.55, 'rgba(255,255,255,.3)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g;
    c.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(canvas);
}
/** One pooled draw call for brief bursts and glider motes; no per-frame mesh allocations. */
class MotePool {
    points;
    position;
    tint;
    life;
    velocity;
    capacity;
    cursor = 0;
    random = rng(1472);
    constructor(parent, quality) {
        this.capacity = quality === 'lite' ? 72 : 192;
        this.position = new Float32Array(this.capacity * 3);
        this.tint = new Float32Array(this.capacity * 3);
        this.velocity = new Float32Array(this.capacity * 3);
        this.life = new Float32Array(this.capacity);
        for (let i = 0; i < this.capacity; i++)
            this.position[i * 3 + 1] = -1000;
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(this.position, 3).setUsage(THREE.DynamicDrawUsage));
        geometry.setAttribute('color', new THREE.BufferAttribute(this.tint, 3).setUsage(THREE.DynamicDrawUsage));
        const material = new THREE.PointsMaterial({ map: moteTexture(), color: 0xffffff, size: quality === 'lite' ? .65 : .86, sizeAttenuation: true,
            vertexColors: true, transparent: true, opacity: .93, depthWrite: false, blending: THREE.AdditiveBlending });
        this.points = new THREE.Points(geometry, material);
        this.points.frustumCulled = false;
        parent.add(this.points);
    }
    burst(x, y, z, color, count, radius = 2.2) {
        const shade = new THREE.Color(color);
        for (let j = 0; j < count; j++) {
            const i = this.cursor++ % this.capacity, k = i * 3, a = this.random() * Math.PI * 2;
            const r = Math.sqrt(this.random()) * radius;
            this.position[k] = x + Math.cos(a) * r;
            this.position[k + 1] = y + this.random() * 1.2;
            this.position[k + 2] = z + Math.sin(a) * r;
            this.velocity[k] = (this.random() - .5) * 3.2;
            this.velocity[k + 1] = 1.5 + this.random() * 3.8;
            this.velocity[k + 2] = (this.random() - .5) * 3.2;
            this.tint[k] = shade.r;
            this.tint[k + 1] = shade.g;
            this.tint[k + 2] = shade.b;
            this.life[i] = .65 + this.random() * 1.2;
        }
        this.points.geometry.getAttribute('color').needsUpdate = true;
        this.points.geometry.getAttribute('position').needsUpdate = true;
    }
    update(dt) {
        if (dt <= 0)
            return;
        let changed = false;
        for (let i = 0; i < this.capacity; i++) {
            if (this.life[i] <= 0)
                continue;
            const k = i * 3;
            this.life[i] -= dt;
            changed = true;
            if (this.life[i] <= 0) {
                this.position[k + 1] = -1000;
                continue;
            }
            this.position[k] += this.velocity[k] * dt;
            this.position[k + 1] += this.velocity[k + 1] * dt;
            this.position[k + 2] += this.velocity[k + 2] * dt;
            this.velocity[k + 1] -= 1.9 * dt;
        }
        if (changed)
            this.points.geometry.getAttribute('position').needsUpdate = true;
    }
}
export class PremiumGardenDetails {
    root = new THREE.Group();
    motes;
    elapsed = 0;
    trailClock = 0;
    prevGrounded = true;
    prevGliding = false;
    quality;
    animated = [];
    constructor(parent, growth, quality) {
        this.quality = quality;
        parent.add(this.root);
        this.horizon();
        this.terrazzo();
        this.conservatory();
        this.signatureLandmarks();
        this.flightRoute();
        this.surfaceJewelry(parent, growth);
        this.motes = new MotePool(this.root, quality);
    }
    horizon() {
        // Three intentional painterly silhouettes rather than anonymous low-poly fog clutter.
        const center = new THREE.Vector3(0, 0, 42);
        const bands = [{ r: 155, h: 23, c: 0x7faea7 }, { r: 213, h: 37, c: 0x89aaa1 }, { r: 285, h: 55, c: 0xa1bbb0 }];
        bands.forEach((band, layer) => {
            const v = [];
            const segments = 128;
            for (let i = 0; i < segments; i++) {
                const a = i / segments * Math.PI * 2, b = (i + 1) / segments * Math.PI * 2;
                const height = (angle) => -3 + band.h * (.48 + .19 * Math.sin(angle * 3 + layer * 2) + .13 * Math.sin(angle * 9 + layer) + .08 * Math.cos(angle * 17));
                const p = (angle, y) => [center.x + band.r * Math.cos(angle), y, center.z + band.r * Math.sin(angle)];
                const loA = p(a, -31), hiA = p(a, height(a)), loB = p(b, -31), hiB = p(b, height(b));
                v.push(...loA, ...hiA, ...hiB, ...loA, ...hiB, ...loB);
            }
            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
            geometry.computeVertexNormals();
            attach(this.root, geometry, new THREE.MeshBasicMaterial({ color: band.c, side: THREE.DoubleSide, fog: true }));
        });
        // Hand-placed distant tree silhouettes frame the greenhouse without hiding the route.
        const random = rng(6002), bark = new THREE.MeshStandardMaterial({ color: 0x4b7964, roughness: 1 });
        const leaves = [matte(0x5a9676), matte(0x6ca786), matte(0x86b18e)];
        const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(.65, .98, 6, 6), bark, 64);
        const crowns = leaves.map(m => new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), m, 64));
        let count = 0;
        const crownCounts = [0, 0, 0];
        const dummy = new THREE.Object3D();
        for (let i = 0; i < 64; i++) {
            const side = i % 2 === 0 ? -1 : 1;
            const x = side * (30 + random() * 18), z = -27 + random() * 114;
            // No visual trunk may occupy the designed central platform route.
            if (Math.abs(x) < 27)
                continue;
            const size = .75 + random() * .9, h = 5.4 * size;
            dummy.position.set(x, h * .48, z);
            dummy.rotation.set(0, random() * 6.28, 0);
            dummy.scale.set(size, size, size);
            dummy.updateMatrix();
            trunks.setMatrixAt(count, dummy.matrix);
            dummy.position.set(x, h + 1.7, z);
            dummy.scale.set(2.7 * size, 3.1 * size, 2.6 * size);
            dummy.updateMatrix();
            const group = i % 3;
            crowns[group].setMatrixAt(crownCounts[group]++, dummy.matrix);
            count++;
        }
        trunks.count = count;
        trunks.instanceMatrix.needsUpdate = true;
        trunks.castShadow = false;
        this.root.add(trunks);
        crowns.forEach((c, i) => { c.count = crownCounts[i]; c.instanceMatrix.needsUpdate = true; c.castShadow = false; this.root.add(c); });
    }
    terrazzo() {
        // A sculpted, beveled garden diorama replaces the visual impression of a raw box.
        // Everything stays below the authoritative y=0 ground collision surface.
        const roundedPlate = (width, height, radius) => {
            const w = width / 2, h = height / 2, r = radius;
            const shape = new THREE.Shape();
            shape.moveTo(-w + r, -h);
            shape.lineTo(w - r, -h);
            shape.quadraticCurveTo(w, -h, w, -h + r);
            shape.lineTo(w, h - r);
            shape.quadraticCurveTo(w, h, w - r, h);
            shape.lineTo(-w + r, h);
            shape.quadraticCurveTo(-w, h, -w, h - r);
            shape.lineTo(-w, -h + r);
            shape.quadraticCurveTo(-w, -h, -w + r, -h);
            return shape;
        };
        const foundation = [{ w: 92, h: 127, y: -3.35, d: 1.4, c: 0xb48c61 }, { w: 95, h: 130, y: -4.7, d: 1.7, c: 0x496f60 }, { w: 98, h: 133, y: -6.28, d: 1, c: 0x9c8057 }];
        for (const plinth of foundation) {
            const base = attach(this.root, new THREE.ExtrudeGeometry(roundedPlate(plinth.w, plinth.h, 4), {
                depth: plinth.d, bevelEnabled: true, bevelThickness: .25, bevelSize: .23, bevelSegments: 2, curveSegments: 5, steps: 1
            }), matte(plinth.c, .67), 0, plinth.y, 25.5);
            base.rotation.x = Math.PI / 2;
            base.receiveShadow = true;
        }
        // Painterly ground wash: procedural, bundled canvas pigment, not a remote texture.
        const pigment = document.createElement('canvas');
        pigment.width = 256;
        pigment.height = 256;
        const painter = pigment.getContext('2d');
        const washRandom = rng(274);
        for (let i = 0; i < 185; i++) {
            painter.beginPath();
            const x = washRandom() * 256, y = washRandom() * 256;
            painter.ellipse(x, y, 4 + washRandom() * 19, 1 + washRandom() * 8, washRandom() * 6.283, 0, 6.283);
            painter.fillStyle = ["rgba(247,217,157,.14)", "rgba(25,96,74,.12)", "rgba(202,237,164,.1)"][i % 3];
            painter.fill();
        }
        const pigmentMap = new THREE.CanvasTexture(pigment);
        pigmentMap.colorSpace = THREE.SRGBColorSpace;
        pigmentMap.wrapS = THREE.RepeatWrapping;
        pigmentMap.wrapT = THREE.RepeatWrapping;
        pigmentMap.repeat.set(6, 9);
        pigmentMap.anisotropy = 4;
        const wash = attach(this.root, new THREE.PlaneGeometry(87, 121), new THREE.MeshBasicMaterial({ map: pigmentMap, transparent: true, opacity: .65, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }), 0, .025, 25.5);
        wash.rotation.x = -Math.PI / 2;
        // Non-colliding carved pathways and garden ornaments, kept outside the player's route.
        const random = rng(9183), stone = matte(0xdbd5b1), trim = matte(0xb48f5b, .35);
        const chips = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(.48, 0), stone, 190);
        const dummy = new THREE.Object3D();
        for (let i = 0; i < 190; i++) {
            const z = -29 + random() * 104, side = i % 2 ? -1 : 1, x = side * (11 + random() * 29);
            dummy.position.set(x, .1, z);
            dummy.scale.set(.7 + random() * 2, .25 + random() * .7, .7 + random() * 2);
            dummy.rotation.y = random() * 6.28;
            dummy.updateMatrix();
            chips.setMatrixAt(i, dummy.matrix);
        }
        chips.instanceMatrix.needsUpdate = true;
        chips.castShadow = false;
        this.root.add(chips);
        const smallSeal = new THREE.InstancedMesh(new THREE.OctahedronGeometry(.29, 0), trim, 46);
        for (let i = 0; i < 46; i++) {
            const z = -26 + i * .59;
            dummy.position.set(Math.sin(z * .28) * 1.4, .23, z);
            dummy.scale.set(1, .24, 1);
            dummy.rotation.y = i * .8;
            dummy.updateMatrix();
            smallSeal.setMatrixAt(i, dummy.matrix);
        }
        smallSeal.instanceMatrix.needsUpdate = true;
        smallSeal.castShadow = false;
        this.root.add(smallSeal);
        // Carved flower plinths at the edges provide deliberate decorative rhythm.
        for (let i = 0; i < 12; i++) {
            const x = (i % 2 ? 1 : -1) * 18.4, z = -24 + Math.floor(i / 2) * 17;
            const pedestal = attach(this.root, new THREE.CylinderGeometry(1.4, 1.62, .72, 10), stone, x, .34, z);
            pedestal.receiveShadow = true;
            ring(this.root, 1.14, .08, trim, x, .75, z);
            const flower = attach(this.root, new THREE.IcosahedronGeometry(1.15, 1), leavesMat(i), x, 1.7, z);
            flower.scale.set(1.3, .6, 1.3);
        }
    }
    conservatory() {
        const brass = matte(0xb79062, .32), ivory = matte(0xf3e1ad, .4);
        // Radial window tracery and key-stone crests maintain the established arch architecture.
        for (const z of [-5.75, 53.9]) {
            const rose = attach(this.root, new THREE.TorusGeometry(5.5, .17, 10, 80), brass, 0, 25.9, z);
            rose.castShadow = false;
            ring(this.root, 1.13, .12, ivory, 0, 25.9, z).rotation.x = 0;
            for (let i = 0; i < 12; i++) {
                const a = Math.PI * 2 * i / 12;
                const start = new THREE.Vector3(1.3 * Math.cos(a), 25.9 + 1.3 * Math.sin(a), z);
                const end = new THREE.Vector3(5.3 * Math.cos(a), 25.9 + 5.3 * Math.sin(a), z);
                const delta = end.clone().sub(start);
                const rod = attach(this.root, new THREE.CylinderGeometry(.07, .07, delta.length(), 5), brass, (start.x + end.x) / 2, (start.y + end.y) / 2, z);
                rod.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
            }
        }
        // Exterior vertical-garden fins; all above/beside the authored collision route.
        const vine = matte(0x5a9477), leaf = matte(0x8bd2a0);
        for (const x of [-21.6, 21.6])
            for (let i = 0; i < 13; i++) {
                const z = -4 + i * 4.2;
                curve(this.root, [new THREE.Vector3(x, 1, z), new THREE.Vector3(x + Math.sin(i) * .5, 4.5, z + .6), new THREE.Vector3(x, 7.7, z + 1)], .085, vine);
                for (let j = 0; j < 3; j++) {
                    const l = attach(this.root, new THREE.SphereGeometry(1, 10, 8), leaf, x + (j - 1) * .6, 3 + j * 1.6, z + .35);
                    l.scale.set(.5, .11, 1.05);
                    l.rotation.y = (j - 1) * .6;
                }
            }
        if (this.quality === 'rich') {
            const beams = new THREE.MeshBasicMaterial({ map: sunbeamTexture(), depthWrite: false, transparent: true, opacity: .34, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
            for (let i = 0; i < 7; i++) {
                const z = -1 + i * 7.9, x = (i % 2 ? -1 : 1) * (6 + i % 3 * 2.5);
                const shaft = attach(this.root, new THREE.PlaneGeometry(1, 1), beams, x, 16, z);
                shaft.scale.set(10, 33, 1);
                shaft.rotation.y = .17 * (i % 3 - 1);
                shaft.rotation.z = (i % 2 ? -1 : 1) * .15;
            }
        }
        // Relief ornament on the front facade; no expensive real-time spotlights.
        const medallion = attach(this.root, new THREE.TorusKnotGeometry(1.04, .11, 56, 5, 2, 3), ivory, 0, 5.4, -7);
        medallion.rotation.x = Math.PI / 2;
    }
    signatureLandmarks() {
        const bronze = matte(0xb48d5b, .42), teal = glow(0x91f7d0, .6), rose = glow(0xffcaac, .58);
        // Moonbell's hanging drops and a quiet halo.
        for (let i = 0; i < 12; i++) {
            const a = i * Math.PI / 6, r = 2.2 + (.4 * (i % 3)), x = -17 + Math.sin(a) * r, z = 11 + Math.cos(a) * r;
            const m = attach(this.root, new THREE.OctahedronGeometry(.24, 0), i % 2 ? teal : rose, x, 13 + (i % 4) * .7, z);
            m.rotation.z = .3;
            this.animated.push({ object: m, origin: m.position.y, speed: .7 + i * .06, amplitude: .2 });
        }
        ring(this.root, 4.9, .09, bronze, -17, 19.6, 11);
        // Orchid's central prism gives it an architectural identity distinct from the moonbell.
        const orchid = attach(this.root, new THREE.OctahedronGeometry(2.4, 0), new THREE.MeshPhysicalMaterial({ color: 0xe7aff3, roughness: .11, metalness: .17, clearcoat: 1, clearcoatRoughness: .13, transparent: true, opacity: .77 }), 17, 19.2, 38);
        orchid.scale.set(.78, 1.5, .78);
        this.animated.push({ object: orchid, origin: orchid.position.y, speed: .42, amplitude: .16 });
        const oRing = ring(this.root, 6.3, .11, rose, 17, 20, 38);
        this.animated.push({ object: oRing, origin: oRing.position.y, speed: .55, amplitude: .16 });
        // Sunflower crown frame, visible from the ground and during the entire ascent.
        for (let i = 0; i < 3; i++) {
            const halo = ring(this.root, 11 + i * 1.5, .115, glow(i % 2 ? 0xffefaa : 0xf9bd69, .32), SUMMIT.x, SUMMIT.y - .5 - i * 2, SUMMIT.z);
            this.animated.push({ object: halo, origin: halo.position.y, speed: .24 + i * .2, amplitude: .28 });
        }
        // The destination feels like a designed shrine, not a marker floating in empty space.
        ring(this.root, 9.7, .24, bronze, CAN.x, CAN.y + .05, CAN.z);
        const plinth = attach(this.root, new THREE.CylinderGeometry(2.6, 3.2, 1.6, 12), bronze, CAN.x, CAN.y + .68, CAN.z);
        plinth.castShadow = true;
        plinth.receiveShadow = true;
        for (let i = 0; i < 8; i++) {
            const a = i * Math.PI / 4;
            attach(this.root, new THREE.OctahedronGeometry(.55, 0), i % 2 ? teal : rose, CAN.x + Math.cos(a) * 9.2, CAN.y + .4, CAN.z + Math.sin(a) * 9.2);
        }
        // Scalloped rock roots visually suspend the island, without changing its broad safe collider.
        const stone = matte(0x6d8175), random = rng(221);
        for (let i = 0; i < 18; i++) {
            const a = i / 18 * Math.PI * 2, r = 6 + random() * 6, h = 3 + random() * 8;
            const st = attach(this.root, new THREE.ConeGeometry(1.1 + random() * 1.4, h, 6), stone, CAN.x + Math.cos(a) * r, CAN.y - 3.5 - h * .45, CAN.z + Math.sin(a) * r);
            st.rotation.x = Math.PI;
        }
    }
    flightRoute() {
        // Soft stationary slipstream sculptures communicate glide direction without blocking it.
        const airflow = glow(0xccf8dc, .22);
        for (let j = 0; j < (this.quality === 'lite' ? 5 : 10); j++) {
            const z = 84 + j * 6.6, side = j % 2 === 0 ? -1 : 1;
            const x = side * (8 + j % 3 * 2), y = 33 - j * .5;
            const stroke = curve(this.root, [
                new THREE.Vector3(x - 2, y - 2, z - 5), new THREE.Vector3(x + 1, y, z - 2),
                new THREE.Vector3(x + 2, y + 1.3, z + 2), new THREE.Vector3(x + .5, y + 1.7, z + 4)
            ], .045, airflow);
            stroke.renderOrder = 1;
        }
        // Translucent ribbons under the intended launch direction; no actual lift force.
        const ribbon = glow(MINT, .2);
        for (const x of [-14, 14])
            curve(this.root, [new THREE.Vector3(SUMMIT.x + x, 40, 80), new THREE.Vector3(CAN.x + x * .7, 34, 105), new THREE.Vector3(CAN.x + x * .38, 27, 133)], .07, ribbon);
    }
    surfaceJewelry(parent, growth) {
        const warm = glow(0xffe6aa, .8), cool = glow(0xb6f5d0, .67), rose = glow(0xffc6dd, .62), amber = matte(0xe6bd78, .4);
        const gemGeometry = new THREE.OctahedronGeometry(.15, 0), dummy = new THREE.Object3D();
        for (const s of SURFACES) {
            const group = (s.stage ? growth[s.stage - 1] : parent)?.getObjectByName(`surface-${s.id}`);
            if (!group)
                continue;
            const material = s.look === 'leaf' ? cool : s.look === 'blossom' ? rose : warm;
            const n = s.look === 'island' ? 40 : 24;
            const freckles = new THREE.InstancedMesh(gemGeometry, material, n);
            freckles.castShadow = false;
            freckles.frustumCulled = false;
            for (let i = 0; i < n; i++) {
                const a = i / n * Math.PI * 2;
                dummy.position.set(Math.cos(a) * s.rx * .85, .1, Math.sin(a) * s.rz * .84);
                dummy.scale.set(.58, .32, .58);
                dummy.rotation.y = a;
                dummy.updateMatrix();
                freckles.setMatrixAt(i, dummy.matrix);
            }
            freckles.instanceMatrix.needsUpdate = true;
            group.add(freckles);
            if (s.look === 'leaf') {
                // Radiating engraved veins follow the readable walking ellipse.
                for (const side of [-1, 1])
                    for (let i = 0; i < 5; i++) {
                        const z = (i - 2) * s.rz * .25;
                        curve(group, [new THREE.Vector3(0, .105, z * .6), new THREE.Vector3(side * s.rx * .28, .115, z * .9), new THREE.Vector3(side * s.rx * .57, .1, z * 1.2)], .025, amber);
                    }
            }
            if (s.look === 'sunflower') {
                for (let i = 0; i < 12; i++) {
                    const a = i * Math.PI / 6;
                    const p = attach(group, new THREE.ConeGeometry(.27, .85, 5), amber, Math.cos(a) * 5.9, .03, Math.sin(a) * 5.9);
                    p.rotation.x = Math.PI / 2;
                    p.rotation.z = a;
                }
            }
        }
        // Vines are marked with slender leaf stitches, unmistakable climb affordances.
        const vineMat = matte(0x88bb84), vein = glow(0xc5eab5, .37);
        for (const v of VINES) {
            const stage = v.stage;
            const base = STATIONS[stage - 1];
            const group = growth[stage - 1];
            for (let k = 0; k < 14; k++) {
                const t = (k + .5) / 14, y = v.base + (v.top - v.base) * t;
                const a = k * 2.399;
                const xx = v.x - base.x + Math.cos(a) * .55, zz = v.z - base.z + Math.sin(a) * .55;
                const leaf = attach(group, new THREE.SphereGeometry(1, 8, 6), vineMat, xx, y - base.y, zz);
                leaf.scale.set(.65, .09, 1.2);
                leaf.rotation.y = a;
                if (k % 3 === 0)
                    ring(group, .6, .035, vein, xx, y - base.y + .05, zz);
            }
        }
        DEW.forEach((d, i) => {
            const stage = i === 0 ? 0 : i, parentGroup = stage === 0 ? parent : growth[stage - 1];
            const base = stage === 0 ? { x: 0, y: 0, z: 0 } : STATIONS[stage - 1];
            const g = new THREE.Group();
            g.position.set(d.x - base.x, d.y - base.y + .9, d.z - base.z);
            parentGroup.add(g);
            for (let j = 0; j < 4; j++) {
                const jewel = attach(g, new THREE.OctahedronGeometry(.2, 0), cool, Math.cos(j * Math.PI / 2) * 1.1, .6 + j * .2, Math.sin(j * Math.PI / 2) * 1.1);
                this.animated.push({ object: jewel, origin: jewel.position.y, speed: 1 + j * .1, amplitude: .2 });
            }
        });
    }
    onGrowth(stage) { const p = STATIONS[stage - 1]; if (p)
        this.motes.burst(p.x, p.y + 2.2, p.z, stage === 2 ? 0xffb9cd : stage === 3 ? GOLD : MINT, this.quality === 'lite' ? 30 : 85, 4.5); }
    onDew(index) { const p = DEW[index]; if (p)
        this.motes.burst(p.x, p.y + 1.3, p.z, 0x8fffea, 18, 1.2); }
    onCheckpoint(position) { this.motes.burst(position.x, position.y + .8, position.z, GOLD, 12, 1.4); }
    onVictory() { this.motes.burst(CAN.x, CAN.y + 5, CAN.z, 0xffd88c, this.quality === 'lite' ? 50 : 105, 6); }
    update(dt, state, reducedMotion) {
        this.elapsed += dt;
        const p = state.player.position, v = state.player.velocity;
        const speed = Math.hypot(v.x, v.z);
        if (state.phase === 'playing' && !reducedMotion) {
            if (this.prevGrounded && !state.player.grounded && v.y > 1) {
                this.motes.burst(p.x, p.y + .3, p.z, 0xffe3a4, 9, .55);
            }
            if (!this.prevGrounded && state.player.grounded && speed > 1) {
                this.motes.burst(p.x, p.y + .2, p.z, 0xd6e8b2, 11, .6);
            }
            if (!this.prevGliding && state.player.gliding)
                this.motes.burst(p.x, p.y + 1.6, p.z, 0xffe1b0, 18, 1.2);
            if (state.player.gliding) {
                this.trailClock += dt;
                while (this.trailClock > .095) {
                    this.trailClock -= .095;
                    this.motes.burst(p.x, p.y + 1.2, p.z - 1, 0xc8f8d7, this.quality === 'lite' ? 1 : 2, .38);
                }
            }
            else
                this.trailClock = 0;
        }
        this.prevGrounded = state.player.grounded;
        this.prevGliding = state.player.gliding;
        if (!reducedMotion) {
            for (let i = 0; i < this.animated.length; i++) {
                const it = this.animated[i];
                it.object.position.y = it.origin + Math.sin(this.elapsed * it.speed + i * .7) * it.amplitude;
                if (i % 3 === 0)
                    it.object.rotation.y = Math.sin(this.elapsed * .4 + i) * .12;
            }
        }
        this.motes.points.visible = !reducedMotion;
        if (!reducedMotion)
            this.motes.update(dt);
    }
}
function leavesMat(i) { return matte([0x92ca91, 0xf3c89e, 0xc6b5d2, 0x84b9a1][i % 4]); }
