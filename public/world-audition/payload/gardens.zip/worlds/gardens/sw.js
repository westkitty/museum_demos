/* Optional same-origin offline cache for the self-contained Vite build. */
const CACHE = 'e31-gardens-0.1.0';
self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const page = new URL('./index.html', self.registration.scope);
    try {
      const response = await fetch(page);
      if (!response.ok) return;
      await cache.put(page, response.clone());
      const html = await response.text();
      const paths = [...html.matchAll(/(?:src|href)="(\.\/assets\/[^\"]+)"/g)].map((m) => new URL(m[1], page));
      paths.push(...['./src/main.js','./src/worlds.js','./src/adapter.js','./src/style.css','./vendor/three.module.min.js','./vendor/three.core.min.js'].map((s) => new URL(s, page)));
      await Promise.all(paths.map(async (url) => { try { await cache.add(url); } catch {} }));
      await self.skipWaiting();
    } catch { /* Network may be absent during reinstallation. */ }
  })());
});
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key.startsWith('e31-gardens-') && key !== CACHE) await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cached = await caches.match(req);
    if (cached) return cached;
    try {
      const fresh = await fetch(req);
      if (fresh.ok) { const c = await caches.open(CACHE); await c.put(req, fresh.clone()); }
      return fresh;
    } catch { return req.mode === 'navigate' ? (await caches.match(new URL('./index.html', self.registration.scope)) || Response.error()) : Response.error(); }
  })());
});
