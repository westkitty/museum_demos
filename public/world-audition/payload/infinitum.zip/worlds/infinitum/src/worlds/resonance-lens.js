import * as THREE from 'three';
import { resonanceChannels } from '../core/resonance.js';
/** Three finite, world-space causal threads. These are original geometry, never a 2D overlay. */
const ENDPOINTS = [
    [
        [[0, 12.6, 0], [27, 14, 24]],
        [[0, 12.6, 0], [0, 73, -18]],
        [[0, 12.6, 0], [-27, 15, -24]]
    ],
    [
        [[-18, 17, -37], [17, 29, -2]],
        [[17, 29, -2], [17, 40, -2]],
        [[17, 29, -2], [30, 15, 44]]
    ],
    [
        [[0, 9, 6], [0, 57, -133]],
        [[0, 57, -133], [39, 28, -113]],
        [[0, 57, -133], [-64, 19, -48]]
    ]
];
const COLOR = [0x75d3bb, 0xa8bce7, 0xd5b979];
export class ResonanceLens {
    scene;
    world;
    group = new THREE.Group();
    parts = [];
    enabled = false;
    constructor(scene, world) {
        this.scene = scene;
        this.world = world;
        this.group.name = 'Resonance Lens';
        const scale = world === 0 ? 1 : world === 1 ? 1.3 : 2.1;
        ENDPOINTS[world].forEach(([start, end], i) => {
            const a = new THREE.Vector3(start[0], start[1], start[2]);
            const b = new THREE.Vector3(end[0], end[1], end[2]);
            const middle = a.clone().lerp(b, .5).add(new THREE.Vector3(0, scale * (2.8 + i * 1.6), 0));
            const curve = new THREE.QuadraticBezierCurve3(a, middle, b);
            const geometry = new THREE.TubeGeometry(curve, 42, .065 * scale, 5, false);
            const material = new THREE.MeshBasicMaterial({ color: COLOR[i], transparent: true, opacity: .13, depthWrite: false, side: THREE.DoubleSide });
            const path = new THREE.Mesh(geometry, material);
            path.userData.feature = 'resonance-thread';
            this.group.add(path);
            const terminal = new THREE.Mesh(new THREE.IcosahedronGeometry(.45 * scale, 1), new THREE.MeshBasicMaterial({ color: COLOR[i], transparent: true, opacity: .5, depthWrite: false }));
            terminal.position.copy(b);
            terminal.userData.feature = 'resonance-terminal';
            this.group.add(terminal);
            this.parts.push({ material, terminal, channel: i });
        });
        this.group.visible = false;
        scene.add(this.group);
    }
    get isEnabled() { return this.enabled; }
    setEnabled(enabled) { this.enabled = enabled; this.group.visible = enabled; }
    update(s, elapsed) {
        if (!this.enabled)
            return;
        const channels = resonanceChannels(s);
        for (const { material, terminal, channel } of this.parts) {
            const state = channels[channel];
            const pulse = s.reducedMotion ? 0 : Math.sin(elapsed * 1.35 + channel * 1.8) * .12;
            material.opacity = Math.min(.87, .13 + state.strength * .55 + (state.complete ? .09 : 0) + pulse * .6);
            terminal.material.opacity = Math.min(.94, .25 + state.strength * .58 + pulse);
            terminal.scale.setScalar(s.reducedMotion ? 1 : 1 + Math.max(0, pulse) * .75);
        }
    }
    dispose() {
        this.scene.remove(this.group);
        this.group.traverse(object => {
            const mesh = object;
            mesh.geometry?.dispose();
            if (mesh.material)
                for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material])
                    mat.dispose();
        });
        this.group.clear();
        this.parts = [];
    }
}
