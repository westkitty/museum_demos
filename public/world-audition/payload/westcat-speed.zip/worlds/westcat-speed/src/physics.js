import { COURSE_LENGTH, PLAYER_RADIUS, CHECKPOINTS, LOOPS, RAILS, SPRINGS, BOOST_PADS, HURDLES, heightAt, slopeAt, isGap, railY, zoneProgress } from './track.js';
export const FIXED_DT = 1 / 120;
export const GRAVITY = 32;
export const RUN_ACCEL = 16;
export const BRAKE_ACCEL = 36;
export const BASE_TOP_SPEED = 14;
export const BOOST_TOP_SPEED = 26;
export const JUMP_VELOCITY = 13.8;
export function createState() {
    return {
        x: 5, y: heightAt(5) + PLAYER_RADIUS, vx: 0, vy: 0, mode: 'ground',
        loopIndex: -1, loopAngle: -Math.PI / 2, railIndex: -1,
        elapsed: 0, boostEnergy: 100, checkpointIndex: -1, recoveries: 0,
        coyote: .15, jumpBuffer: 0, springCooldown: 0, hurdleCooldown: 0,
        loopDone: LOOPS.map(() => false), railDone: RAILS.map(() => false),
        padDone: BOOST_PADS.map(() => false), finished: false, paused: false, distance: 0
    };
}
function recover(s, emit) {
    const safeX = s.checkpointIndex < 0 ? 5 : CHECKPOINTS[s.checkpointIndex].x + 3;
    s.x = safeX;
    s.y = heightAt(safeX) + PLAYER_RADIUS;
    s.vx = 3;
    s.vy = 0;
    s.mode = 'ground';
    s.loopIndex = -1;
    s.railIndex = -1;
    s.coyote = .15;
    s.springCooldown = .7;
    s.hurdleCooldown = 1;
    s.boostEnergy = Math.max(s.boostEnergy, 50);
    s.recoveries++;
    s.elapsed += 3;
    emit({ type: 'recovery' });
}
export function step(s, a, dt = FIXED_DT, emit = () => { }) {
    if (s.finished || s.paused)
        return;
    // Keep integration stable even if caller gives a bad delta.
    if (!Number.isFinite(dt) || dt <= 0 || dt > 1 / 30)
        throw new Error('Use fixed, bounded simulation steps.');
    s.elapsed += dt;
    s.springCooldown = Math.max(0, s.springCooldown - dt);
    s.hurdleCooldown = Math.max(0, s.hurdleCooldown - dt);
    s.jumpBuffer = Math.max(0, s.jumpBuffer - dt);
    if (a.jumpPressed)
        s.jumpBuffer = .13;
    const wantsBoost = a.boost && s.boostEnergy > .01;
    s.boostEnergy = Math.max(0, Math.min(100, s.boostEnergy + (wantsBoost ? -19 : 8) * dt));
    if (s.mode === 'loop') {
        const loop = LOOPS[s.loopIndex];
        s.vx = Math.max(s.vx, 13);
        if (wantsBoost)
            s.vx = Math.min(BOOST_TOP_SPEED, s.vx + 12 * dt);
        const angleAdvance = (s.vx / loop.radius) * dt;
        s.loopAngle += angleAdvance;
        s.x = loop.x + Math.cos(s.loopAngle) * loop.radius;
        s.y = heightAt(loop.x) + loop.radius + Math.sin(s.loopAngle) * loop.radius + PLAYER_RADIUS;
        s.vy = Math.cos(s.loopAngle) * s.vx;
        if (s.loopAngle >= Math.PI * 1.5) {
            s.x = loop.x + 3.3;
            s.y = heightAt(s.x) + PLAYER_RADIUS;
            s.vx = Math.max(s.vx, 18);
            s.vy = 0;
            s.mode = 'ground';
            s.loopIndex = -1;
            s.coyote = .15;
        }
    }
    else if (s.mode === 'rail') {
        const rail = RAILS[s.railIndex];
        s.vx = Math.max(17, s.vx + (wantsBoost ? 16 : 5) * dt);
        s.vx = Math.min(BOOST_TOP_SPEED, s.vx);
        s.x += s.vx * dt;
        s.y = railY(s.railIndex, s.x) + PLAYER_RADIUS;
        s.vy = 0;
        if (s.x >= rail.end) {
            s.x = rail.end;
            s.y = railY(s.railIndex, s.x) + PLAYER_RADIUS;
            s.vy = 9;
            s.mode = 'air';
            s.railIndex = -1;
            s.coyote = 0;
        }
    }
    else {
        const direction = (a.right ? 1 : 0) - (a.left ? 1 : 0);
        const onGround = s.mode === 'ground';
        const accel = onGround ? RUN_ACCEL : RUN_ACCEL * .6;
        if (direction !== 0) {
            const reversing = Math.abs(s.vx) > .2 && Math.sign(s.vx) !== direction;
            s.vx += direction * (reversing ? BRAKE_ACCEL : accel + (wantsBoost ? 18 : 0)) * dt;
        }
        else if (onGround) {
            const drag = Math.min(Math.abs(s.vx), (5 + Math.abs(s.vx) * .115) * dt);
            s.vx -= Math.sign(s.vx) * drag;
        }
        else {
            s.vx *= Math.max(0, 1 - dt * .025);
        }
        if (onGround) {
            // Gravity projects along the tangent, giving downslopes genuine momentum.
            const slope = slopeAt(s.x);
            s.vx += (-GRAVITY * slope / (1 + slope * slope)) * .41 * dt;
            s.coyote = .13;
        }
        else {
            s.coyote = Math.max(0, s.coyote - dt);
        }
        const top = wantsBoost ? BOOST_TOP_SPEED : BASE_TOP_SPEED;
        // Momentum does not disappear instantly when the boost button is released.
        if (Math.abs(s.vx) > top && !wantsBoost)
            s.vx -= Math.sign(s.vx) * Math.min(Math.abs(s.vx) - top, 4 * dt);
        s.vx = Math.max(-BASE_TOP_SPEED, Math.min(BOOST_TOP_SPEED, s.vx));
        if (s.jumpBuffer > 0 && s.coyote > 0) {
            s.mode = 'air';
            s.vy = JUMP_VELOCITY + Math.min(3, Math.max(0, s.vx) * .09);
            s.jumpBuffer = 0;
            s.coyote = 0;
        }
        const beforeX = s.x;
        s.x = Math.max(2, Math.min(COURSE_LENGTH + 18, s.x + s.vx * dt));
        if (s.mode === 'air') {
            s.vy -= GRAVITY * dt;
            s.y += s.vy * dt;
            if (!isGap(s.x) && s.vy <= 0 && s.y <= heightAt(s.x) + PLAYER_RADIUS) {
                s.y = heightAt(s.x) + PLAYER_RADIUS;
                s.vy = 0;
                s.mode = 'ground';
                s.coyote = .13;
            }
        }
        else if (!isGap(s.x)) {
            s.y = heightAt(s.x) + PLAYER_RADIUS;
            s.vy = 0;
        }
        else {
            s.mode = 'air';
            s.coyote = 0;
            s.vy = Math.min(0, s.vy);
        }
        if (s.mode === 'ground' && s.vx > 7) {
            for (let i = 0; i < LOOPS.length; i++) {
                const loop = LOOPS[i];
                if (!s.loopDone[i] && beforeX <= loop.x + .3 && s.x >= loop.x - 1.5) {
                    s.loopDone[i] = true;
                    s.loopIndex = i;
                    s.loopAngle = -Math.PI / 2;
                    s.x = loop.x;
                    s.y = heightAt(loop.x) + PLAYER_RADIUS;
                    s.mode = 'loop';
                    emit({ type: 'loop', index: i });
                    break;
                }
            }
            if (s.mode === 'ground')
                for (let i = 0; i < RAILS.length; i++) {
                    if (!s.railDone[i] && beforeX <= RAILS[i].start + .2 && s.x >= RAILS[i].start - 1.5) {
                        s.railDone[i] = true;
                        s.railIndex = i;
                        s.mode = 'rail';
                        s.x = RAILS[i].start;
                        s.y = railY(i, s.x) + PLAYER_RADIUS;
                        emit({ type: 'rail', index: i });
                        break;
                    }
                }
        }
        if (s.mode === 'ground') {
            for (let i = 0; i < SPRINGS.length; i++) {
                const spring = SPRINGS[i];
                if (s.springCooldown <= 0 && Math.abs(s.x - spring.x) < 1.4 && s.vx > 1) {
                    s.springCooldown = .8;
                    s.mode = 'air';
                    s.vy = spring.impulse;
                    s.vx = Math.max(s.vx, 24);
                    emit({ type: 'spring', index: i });
                    break;
                }
            }
            if (s.hurdleCooldown <= 0)
                for (let i = 0; i < HURDLES.length; i++) {
                    if (beforeX <= HURDLES[i] && s.x >= HURDLES[i] && s.vx > 0) {
                        s.hurdleCooldown = .85;
                        s.vx = Math.max(5, s.vx * .63);
                        s.vy = 6;
                        s.mode = 'air';
                        emit({ type: 'hurdle', index: i });
                        break;
                    }
                }
        }
    }
    // Pads can trigger while airborne close to the track; crossing rather than overlap avoids repeat boosting.
    for (let i = 0; i < BOOST_PADS.length; i++) {
        const x = BOOST_PADS[i];
        if (!s.padDone[i] && s.x >= x && s.x < x + 4 && Math.abs(s.y - heightAt(x)) < 12) {
            s.padDone[i] = true;
            s.vx = Math.max(21, s.vx + 8);
            s.boostEnergy = Math.min(100, s.boostEnergy + 19);
            emit({ type: 'pad', index: i });
        }
    }
    for (let i = 0; i < CHECKPOINTS.length; i++) {
        if (s.checkpointIndex < i && s.x >= CHECKPOINTS[i].x) {
            s.checkpointIndex = i;
            emit({ type: 'checkpoint', index: i });
        }
    }
    s.distance = Math.max(s.distance, s.x);
    if (s.x >= COURSE_LENGTH - 4 && s.y <= heightAt(COURSE_LENGTH) + PLAYER_RADIUS + 24) {
        s.finished = true;
        s.vx = 0;
        s.vy = 0;
        emit({ type: 'finish', time: s.elapsed });
    }
    if (s.y < heightAt(Math.max(0, Math.min(COURSE_LENGTH, s.x))) - 25 || s.x > COURSE_LENGTH + 15) {
        recover(s, emit);
    }
    if (!Number.isFinite(s.x) || !Number.isFinite(s.y) || !Number.isFinite(s.vx)) {
        throw new Error('Non-finite physics state');
    }
}
export function progress(s) { return zoneProgress(s.distance); }
export const NO_INPUT = { left: false, right: false, boost: false, jumpPressed: false };
