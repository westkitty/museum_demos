export const START = { x: 0, y: 0, z: -26 };
export const SUMMIT = { x: 8, y: 42, z: 72 };
export const CAN = { x: 5, y: 19.5, z: 149 };
export const SURFACES = [
    { id: 'first-step', x: 0, z: 2, top: 2.1, rx: 4.9, rz: 3.9, stage: 1, look: 'leaf' },
    { id: 'leaf-2', x: -3, z: 7, top: 4.35, rx: 4.4, rz: 4, stage: 1, look: 'leaf' },
    { id: 'leaf-3', x: -1, z: 12, top: 6.65, rx: 4.4, rz: 4, stage: 1, look: 'leaf' },
    { id: 'leaf-4', x: 2, z: 17, top: 9.15, rx: 6, rz: 5.1, stage: 1, look: 'leaf' },
    { id: 'bloom-1', x: 6, z: 21, top: 11.6, rx: 4.6, rz: 4.1, stage: 2, look: 'blossom' },
    { id: 'bloom-2', x: 9, z: 26, top: 14, rx: 4.4, rz: 4.1, stage: 2, look: 'blossom' },
    { id: 'bloom-3', x: 7, z: 31, top: 16.45, rx: 4.7, rz: 4.2, stage: 2, look: 'blossom' },
    { id: 'bloom-4', x: 4, z: 36, top: 18.9, rx: 4.6, rz: 4.3, stage: 2, look: 'blossom' },
    { id: 'bloom-5', x: 4, z: 40, top: 21.25, rx: 6, rz: 4.8, stage: 2, look: 'blossom' },
    { id: 'petal-1', x: 0, z: 44, top: 23.85, rx: 4.6, rz: 4.3, stage: 3, look: 'petal' },
    { id: 'petal-2', x: -4, z: 49, top: 26.5, rx: 4.7, rz: 4.2, stage: 3, look: 'petal' },
    { id: 'petal-3', x: -2, z: 54, top: 29.2, rx: 4.6, rz: 4.1, stage: 3, look: 'petal' },
    { id: 'petal-4', x: 3, z: 59, top: 31.8, rx: 4.7, rz: 4.2, stage: 3, look: 'petal' },
    { id: 'petal-5', x: 6, z: 63, top: 34.4, rx: 4.6, rz: 4.1, stage: 3, look: 'petal' },
    { id: 'petal-6', x: 8, z: 67, top: 37, rx: 4.7, rz: 4.1, stage: 3, look: 'petal' },
    { id: 'petal-7', x: 8, z: 69.5, top: 39.6, rx: 4.9, rz: 4.1, stage: 3, look: 'petal' },
    { id: 'sunflower-head', x: 8, z: 72, top: 42, rx: 8, rz: 7.8, stage: 3, look: 'sunflower' },
    { id: 'landing-island', x: 5, z: 147, top: 19.5, rx: 14, rz: 12.5, stage: 0, look: 'island' }
];
export const VINES = [
    { id: 'bean-vine', x: -0.3, z: 8, base: 0, top: 9.5, radius: 2.5, stage: 1 },
    { id: 'orchid-vine', x: 7, z: 28, base: 9.1, top: 21.6, radius: 2.4, stage: 2 },
    { id: 'sun-vine', x: 1, z: 54, base: 21, top: 38, radius: 2.8, stage: 3 },
    { id: 'sunflower-stalk', x: 8, z: 72, base: 36, top: 42, radius: 3.8, stage: 3 }
];
export const STATIONS = [
    { id: 1, name: 'THE GREAT GERMINATION', x: 1, y: 0, z: -2.5, costWater: 1, costPower: 18, quip: 'You have watered a staircase. History will call this agriculture.' },
    { id: 2, name: 'THE BLOOM BUREAUCRACY', x: 2, y: 9.15, z: 17, costWater: 1, costPower: 18, quip: 'The flower has approved your vertical planning application.' },
    { id: 3, name: 'THE SUNFLOWER SUMMONS', x: 4, y: 21.25, z: 40, costWater: 1, costPower: 18, quip: 'Behold. A plant with an extremely inflated sense of duty.' }
];
export const DEW = [
    { x: 4.8, y: 0, z: -4 },
    { x: 5.8, y: 9.15, z: 16 },
    { x: 6.8, y: 21.25, z: 39 }
];
export const CHECKPOINTS = [
    START, { x: 0, y: 0, z: -1 }, { x: 2, y: 9.15, z: 17 },
    { x: 4, y: 21.25, z: 40 }, { x: 8, y: 42, z: 72 }
];
export function groundExists(x, z) {
    return x >= -42 && x <= 42 && z >= -35 && z <= 86;
}
export function surfaceUnlocked(surface, grown) {
    return surface.stage === 0 || surface.stage <= grown;
}
export function sqDistXZ(ax, az, bx, bz) {
    return (ax - bx) ** 2 + (az - bz) ** 2;
}
export function safeCourseGeometry() {
    if (SURFACES.length !== 18 || STATIONS.length !== 3)
        return false;
    if (new Set(SURFACES.map(s => s.id)).size !== SURFACES.length)
        return false;
    if (SURFACES.some(s => s.rx <= 0 || s.rz <= 0 || s.top <= 0))
        return false;
    if (!SURFACES.slice(0, -1).every((s, i) => i === 0 || s.stage >= SURFACES[i - 1].stage))
        return false;
    for (let i = 1; i < SURFACES.length - 1; i++) {
        const a = SURFACES[i - 1], b = SURFACES[i];
        if (b.top - a.top > 4.5)
            return false;
        const gap = Math.sqrt(sqDistXZ(a.x, a.z, b.x, b.z)) - Math.min(a.rx, a.rz) - Math.min(b.rx, b.rz);
        if (gap > 4.5)
            return false;
    }
    return true;
}
