export const STAR_POINTS = [
    [-32, 68, -35], [-12, 82, -45], [13, 73, -48], [-3, 55, -60],
    [49, 62, -61], [72, 89, -81], [90, 67, -66], [64, 49, -90],
    [-73, 83, -115], [-48, 97, -135], [-21, 76, -137], [-54, 56, -127]
];
export const CONSTELLATION_SHAPES = [
    [[0, 1], [1, 2], [2, 3]], [[4, 5], [5, 6], [6, 7]], [[8, 9], [9, 10], [10, 11]]
];
export function edgeKey(a, b) { return `edge:${Math.min(a, b)}-${Math.max(a, b)}`; }
export function constellationCompletion(edges) {
    return CONSTELLATION_SHAPES.map((shape, i) => shape.every(([a, b]) => edges.includes(edgeKey(a, b))) ? `complete:${i}` : '').filter(Boolean);
}
