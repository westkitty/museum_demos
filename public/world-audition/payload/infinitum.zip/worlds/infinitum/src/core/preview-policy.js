export function visibleMiniatureTargets(world, destination = null) {
    const result = [];
    for (const visibleWorld of [world, destination]) {
        if (visibleWorld === 0 && !result.includes(0))
            result.push(0);
        if (visibleWorld === 1 && !result.includes(1))
            result.push(1);
    }
    return result;
}
