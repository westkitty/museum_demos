/** Narrow E02 museum-return contract. Never accept cross-origin redirect URLs. */
export const BRIDGE_VERSION = 1;
export const BRIDGE_SOURCE = 'the-machine-that-eats-worlds';
export const BRIDGE_EXHIBIT = 'E02';
export const RETURN_REQUEST = 'museum:pocket-world:return-request';
export const RETURN_ACK = 'museum:pocket-world:return-ack';
export const RETURN_READY = 'museum:pocket-world:return-ready';
export function resolveMuseumReturn(href) {
    try {
        const url = new URL(href);
        const raw = url.searchParams.get('museumReturn');
        if (!raw)
            return null;
        const target = new URL(raw, url.href);
        if (!['http:', 'https:'].includes(url.protocol) || !['http:', 'https:'].includes(target.protocol))
            return null;
        if (target.origin !== url.origin)
            return null;
        if (target.href === url.href || target.pathname === url.pathname)
            return null;
        if (target.username || target.password)
            return null;
        return target.href;
    }
    catch {
        return null;
    }
}
export function bridgeMessage(type, nonce) {
    return { type, version: BRIDGE_VERSION, source: BRIDGE_SOURCE, exhibitId: BRIDGE_EXHIBIT, nonce };
}
export function isValidAck(data, nonce) {
    if (!data || typeof data !== 'object')
        return false;
    const obj = data;
    return obj.type === RETURN_ACK && obj.version === BRIDGE_VERSION && obj.source === BRIDGE_SOURCE && obj.exhibitId === BRIDGE_EXHIBIT && obj.nonce === nonce;
}
export async function requestMuseumReturn(onAccepted) {
    const origin = window.location.origin;
    const embedded = window.parent !== window;
    if (embedded && /^https?:/.test(origin)) {
        const nonce = crypto.randomUUID();
        const accepted = await new Promise(resolve => {
            let settled = false;
            const end = (pass) => { if (settled)
                return; settled = true; window.removeEventListener('message', onMessage); window.clearTimeout(timeout); resolve(pass); };
            const onMessage = (event) => {
                if (event.origin !== origin || event.source !== window.parent)
                    return;
                if (isValidAck(event.data, nonce))
                    end(true);
            };
            window.addEventListener('message', onMessage);
            const timeout = window.setTimeout(() => end(false), 1250);
            window.parent.postMessage(bridgeMessage(RETURN_REQUEST, nonce), origin);
        });
        if (accepted) {
            onAccepted();
            window.parent.postMessage(bridgeMessage(RETURN_READY, nonce), origin);
            return 'embedded';
        }
    }
    // Never navigate the museum INSIDE an unacknowledged iframe.
    if (embedded)
        return 'mock';
    const destination = resolveMuseumReturn(window.location.href);
    if (destination) {
        onAccepted();
        window.location.assign(destination);
        return 'navigated';
    }
    return 'mock';
}
