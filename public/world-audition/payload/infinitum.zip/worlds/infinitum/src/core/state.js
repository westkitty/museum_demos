export const WORLD_NAMES = ['THE OBSERVATORY', 'THE LIVING WORLD', 'THE CELESTIAL GARDEN'];
export const WEATHER = ['Clear', 'Cloudy', 'Rain', 'Thunderstorm', 'Snow', 'Fog'];
export const TERRAIN_ZONES = [
    { x: -67, z: 15, radius: 17, name: 'The western meadow' },
    { x: 34, z: 45, radius: 19, name: 'The sunken ruins' },
    { x: 5, z: -21, radius: 16, name: 'The forest saddle' }
];
export const DEFAULT_DATA = {
    time: 17.6, timeRate: 0.06, paused: false, weather: 'Clear', gravity: [0, 0],
    terrain: [0, 0, 0], rivers: [], seeds: [], constellations: [], moonAngle: 0.9,
    prismAngle: 0.0, mirrorAngle: 0.0, wildlifeMarkers: [],
    ruins: [
        { id: 0, x: 41, z: 42, angle: 0.1, snapped: false },
        { id: 1, x: 27, z: 42, angle: -0.2, snapped: false },
        { id: 2, x: 39, z: 52, angle: 0.4, snapped: false }
    ],
    gardenVisited: false, reveal: 0, reducedMotion: false, quality: 'medium',
    soilWater: .12, knowledge: [], endingSeen: false,
    season: 'Summer', adaptiveQuality: true
};
const KEY = 'infinitum.session.v1';
const copy = (v) => JSON.parse(JSON.stringify(v));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export const clamp01 = (v) => clamp(v, 0, 1);
const validWeather = (v) => WEATHER.includes(v);
const finite = (v, fallback, lo, hi) => typeof v === 'number' && Number.isFinite(v) ? clamp(v, lo, hi) : fallback;
const vec2 = (v) => Array.isArray(v) ? [finite(v[0], 0, -120, 120), finite(v[1], 0, -120, 120)] : [0, 0];
export function normalize(raw) {
    const r = raw && typeof raw === 'object' ? raw : {};
    const safeRivers = Array.isArray(r.rivers) ? r.rivers.slice(0, 8).filter((p) => Array.isArray(p))
        .map(p => p.slice(0, 96).map(vec2)).filter(p => p.length >= 2) : [];
    const safeSeeds = Array.isArray(r.seeds) ? r.seeds.slice(0, 80).map((p, i) => ({
        id: finite(p?.id, i, 0, 999999), x: finite(p?.x, 0, -115, 115),
        z: finite(p?.z, 0, -110, 110), age: finite(p?.age, 0, 0, 1)
    })) : [];
    return {
        ...copy(DEFAULT_DATA),
        time: finite(r.time, DEFAULT_DATA.time, 0, 24),
        timeRate: finite(r.timeRate, DEFAULT_DATA.timeRate, 0, 12),
        paused: Boolean(r.paused), weather: validWeather(r.weather) ? r.weather : 'Clear',
        gravity: vec2(r.gravity).map(v => clamp(v, -1, 1)),
        terrain: [0, 1, 2].map(i => finite(r.terrain?.[i], 0, -13, 18)),
        rivers: safeRivers, seeds: safeSeeds,
        constellations: Array.isArray(r.constellations) ? [...new Set(r.constellations.filter((s) => typeof s === 'string'))].slice(0, 80) : [],
        moonAngle: finite(r.moonAngle, 0.9, 0, Math.PI * 2),
        prismAngle: finite(r.prismAngle, 0, -Math.PI, Math.PI),
        mirrorAngle: finite(r.mirrorAngle, 0, -Math.PI, Math.PI),
        wildlifeMarkers: Array.isArray(r.wildlifeMarkers) ? r.wildlifeMarkers.slice(0, 6).map(vec2) : [],
        ruins: Array.isArray(r.ruins) && r.ruins.length === 3 ? r.ruins.map((p, i) => ({
            id: i, x: finite(p?.x, DEFAULT_DATA.ruins[i].x, -115, 115),
            z: finite(p?.z, DEFAULT_DATA.ruins[i].z, -115, 115),
            angle: finite(p?.angle, 0, -Math.PI * 2, Math.PI * 2), snapped: Boolean(p?.snapped)
        })) : copy(DEFAULT_DATA.ruins),
        gardenVisited: Boolean(r.gardenVisited), reveal: finite(r.reveal, 0, 0, 1),
        reducedMotion: Boolean(r.reducedMotion),
        quality: r.quality === 'low' || r.quality === 'medium' || r.quality === 'high' ? r.quality : 'medium',
        soilWater: finite(r.soilWater, .12, 0, 1),
        knowledge: Array.isArray(r.knowledge) ? [...new Set(r.knowledge.filter((x) => typeof x === 'string' && /^[a-z-]{2,40}$/.test(x)))].slice(0, 40) : [],
        endingSeen: Boolean(r.endingSeen),
        season: SEASONS.includes(r.season) ? r.season : 'Summer',
        adaptiveQuality: r.adaptiveQuality !== false
    };
}
export const sunAmount = (time) => clamp01((Math.sin((time - 6) * Math.PI / 12) + 0.19) * 2.2);
export const isNight = (time) => sunAmount(time) < 0.13;
export const tideAt = (angle) => Math.sin(angle * 2.0) * 1.75;
export const stormIntensity = (weather) => weather === 'Thunderstorm' ? 1 : weather === 'Rain' ? 0.5 : 0;
export const treeGrowth = (s) => Math.min(1, s.seeds.filter(p => Math.hypot(p.x - 17, p.z + 2) < 27 && p.age > 0.3).length / 4);
export const extraDroplets = (s) => Math.floor(treeGrowth(s) * 5);
export const constellationPower = (s) => s.constellations.filter(c => c.startsWith('complete:')).length;
export const lightAligned = (s) => Math.abs(s.prismAngle - 0.72) < 0.17 && Math.abs(s.mirrorAngle + 0.48) < 0.19;
export const ruinsComplete = (s) => s.ruins.every(p => p.snapped);
import { growthRate, stormWaterTarget } from './simulation.js';
import { SEASONS, seasonalGrowthFactor } from './seasons.js';
export class StateStore {
    data;
    echoes;
    revision = 0;
    listeners = new Set();
    dirty = false;
    storageFailed = false;
    corruptedRaw = null;
    transient = null;
    get saveStatus() {
        if (this.corruptedRaw !== null)
            return 'blocked';
        if (this.storageFailed)
            return 'unavailable';
        return this.dirty ? 'pending' : 'saved';
    }
    get recoverableRawSave() { return this.corruptedRaw; }
    persistenceClock = 0;
    selectedEchoId = null;
    past = [];
    future = [];
    get canUndo() { return this.past.length > 0; }
    get canRedo() { return this.future.length > 0; }
    checkpoint() { this.past.push(copy(this.data)); if (this.past.length > 30)
        this.past.shift(); this.future = []; }
    beginTransient(fields = []) {
        if (this.transient)
            return;
        this.transient = { before: copy(this.data), fields, future: this.future.map(copy), history: this.past.map(copy) };
        this.checkpoint();
    }
    commitTransient() { this.transient = null; }
    cancelTransient() {
        if (!this.transient)
            return false;
        const snapshot = this.transient;
        this.transient = null;
        this.past = snapshot.history;
        this.future = snapshot.future;
        // Cancel ONLY the tool's fields, not concurrent clock/weather/growth simulation.
        const reverted = copy(this.data);
        for (const field of snapshot.fields)
            Object.assign(reverted, { [field]: copy(snapshot.before[field]) });
        this.data = normalize(snapshot.fields.length ? reverted : snapshot.before);
        this.revision++;
        this.dirty = true;
        this.listeners.forEach(f => f());
        this.save();
        return true;
    }
    undo() { const previous = this.past.pop(); if (!previous)
        return false; this.future.push(copy(this.data)); this.data = normalize(previous); this.revision++; this.dirty = true; this.listeners.forEach(f => f()); this.save(); return true; }
    redo() { const next = this.future.pop(); if (!next)
        return false; this.past.push(copy(this.data)); this.data = normalize(next); this.revision++; this.dirty = true; this.listeners.forEach(f => f()); this.save(); return true; }
    constructor() {
        let saved;
        let raw = null;
        try {
            raw = localStorage.getItem(KEY);
            if (raw) {
                try {
                    const value = JSON.parse(raw);
                    if (!value || typeof value !== 'object' || Array.isArray(value))
                        throw new Error('Invalid save');
                    const candidate = value;
                    if (candidate.schema !== 1 || !candidate.data || typeof candidate.data !== 'object' ||
                        Array.isArray(candidate.data) || !Array.isArray(candidate.echoes) || candidate.echoes.length > 5 ||
                        candidate.echoes.some(e => !e || typeof e !== 'object' || typeof e.id !== 'number' ||
                            !Number.isFinite(e.id) || !e.data || typeof e.data !== 'object' || Array.isArray(e.data)))
                        throw new Error('Invalid save');
                    saved = candidate;
                }
                catch {
                    this.corruptedRaw = raw;
                }
            }
        }
        catch {
            this.storageFailed = true;
        }
        this.data = normalize(saved?.data);
        if (!saved && this.corruptedRaw === null && typeof window !== 'undefined' &&
            typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
            this.data.reducedMotion = true;
        this.echoes = saved ? saved.echoes.map(e => ({
            id: finite(e.id, 0, 0, Number.MAX_SAFE_INTEGER), at: String(e.at).slice(0, 36), data: normalize(e.data)
        })) : [];
    }
    onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
    change(fn) { fn(this.data); this.revision++; this.dirty = true; this.listeners.forEach(f => f()); }
    recordObservation(id) {
        if (this.data.knowledge.includes(id))
            return false;
        this.change(s => { s.knowledge.push(id); });
        return true;
    }
    get selectedEcho() { return this.echoes.find(e => e.id === this.selectedEchoId) ?? this.echoes[this.echoes.length - 1] ?? null; }
    selectEcho(id) { if (!this.echoes.some(e => e.id === id))
        return false; this.selectedEchoId = id; this.revision++; this.listeners.forEach(f => f()); return true; }
    tick(dt) {
        if (!this.data.paused && this.data.timeRate > 0) {
            this.data.time = (this.data.time + dt * this.data.timeRate) % 24;
            this.dirty = true;
        }
        // Environmental growth and drainage follow accelerated simulation time,
        // while geometry animation remains real-time to preserve camera comfort.
        const simulationSpeed = Math.max(.1, Math.min(16, this.data.timeRate / .06));
        // Slow bounded hydrology; renderer scenes only read this shared scalar.
        if (!this.data.paused) {
            const target = stormWaterTarget(this.data);
            const next = this.data.soilWater + (target - this.data.soilWater) * Math.min(.018 * dt * simulationSpeed, 1);
            if (Math.abs(next - this.data.soilWater) > 1e-6) {
                this.data.soilWater = next;
                this.dirty = true;
            }
        }
        // Growth is driven by simulation time, independent of the current scene.
        if (!this.data.paused) {
            const previousDroplets = extraDroplets(this.data);
            for (const seed of this.data.seeds)
                seed.age = Math.min(1, seed.age + Math.min(dt, .1) * simulationSpeed * growthRate(this.data, seed.x, seed.z) * seasonalGrowthFactor(this.data));
            if (this.data.seeds.some(seed => seed.age < 1))
                this.dirty = true;
            if (previousDroplets !== extraDroplets(this.data)) {
                this.revision++;
                this.listeners.forEach(f => f());
            }
        }
        this.persistenceClock += dt;
        if (this.persistenceClock > 4) {
            this.persistenceClock = 0;
            this.save();
        }
    }
    save() {
        // Never silently overwrite a damaged original. Export it before an explicit reset/import.
        if (this.corruptedRaw !== null)
            return false;
        if (!this.dirty)
            return !this.storageFailed;
        try {
            localStorage.setItem(KEY, JSON.stringify({ schema: 1, data: this.data, echoes: this.echoes }));
            this.dirty = false;
            this.storageFailed = false;
            return true;
        }
        catch {
            this.storageFailed = true;
            return false;
        }
    }
    touch() { this.dirty = true; }
    exportSave() { return { schema: 1, data: copy(this.data), echoes: copy(this.echoes) }; }
    importSave(raw) {
        if (!raw || typeof raw !== 'object')
            return false;
        const file = raw;
        if (file.schema !== 1 || !file.data || typeof file.data !== 'object' || Array.isArray(file.data) ||
            !Array.isArray(file.echoes) || file.echoes.length > 5)
            return false;
        const restored = normalize(file.data);
        const echoes = [];
        for (const value of file.echoes) {
            if (!value || typeof value !== 'object' || typeof value.id !== 'number' || !Number.isFinite(value.id) ||
                !value.data || typeof value.data !== 'object')
                return false;
            echoes.push({ id: finite(value.id, 0, 0, Number.MAX_SAFE_INTEGER), at: String(value.at ?? '').slice(0, 36), data: normalize(value.data) });
        }
        this.data = restored;
        this.echoes = echoes;
        this.selectedEchoId = null;
        this.past = [];
        this.future = [];
        this.transient = null;
        this.corruptedRaw = null;
        this.revision++;
        this.dirty = true;
        this.listeners.forEach(f => f());
        this.save();
        return true;
    }
    capture() {
        const echo = { id: Math.max(Date.now(), (this.echoes[this.echoes.length - 1]?.id ?? 0) + 1), at: new Date().toLocaleString(), data: copy(this.data) };
        this.echoes.push(echo);
        this.echoes = this.echoes.slice(-5);
        this.selectedEchoId = echo.id;
        this.change(() => { });
        this.save();
        return echo;
    }
    restore(id) {
        const echo = this.echoes.find(e => e.id === id);
        if (!echo)
            return false;
        this.checkpoint();
        this.selectedEchoId = id;
        this.change(() => { this.data = normalize(copy(echo.data)); });
        this.save();
        return true;
    }
    reset() {
        this.past = [];
        this.future = [];
        this.transient = null;
        this.corruptedRaw = null;
        this.change(() => { this.data = copy(DEFAULT_DATA); this.echoes = []; this.selectedEchoId = null; });
        this.save();
    }
}
