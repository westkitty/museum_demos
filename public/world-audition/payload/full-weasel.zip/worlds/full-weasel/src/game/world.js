import * as THREE from 'three';
import { VisualFX } from './visual-fx.js';
import { GATE_Z, PLATFORMS, REWARDS } from './layout.js';
import { MECHANISMS, throneUnlocked } from './rules.js';
const PALETTE = {
    blush: 0xfca5d5, egg: 0xfff4c4, gold: 0xf8c86d,
    plum: 0x5a2f81, indigo: 0x261750, mint: 0x93f4d1,
    turquoise: 0x38d5de, navy: 0x1c245d, green: 0x39a99f
};
export class ToyWorld {
    scene = new THREE.Scene();
    surfaces = [];
    solids = [];
    cameraObstacles = [];
    coins = new Map();
    devices = new Map();
    gate = new THREE.Group();
    lights = [];
    detailRoot = new THREE.Group();
    glowRoot = new THREE.Group();
    effects;
    dustRoot = new THREE.Group();
    staticRoot = new THREE.Group();
    finaleRoot = new THREE.Group();
    silhouette = new THREE.Group();
    puppet = new THREE.Group();
    buttonCap = new THREE.Group();
    allGeometry = new Set();
    allMaterials = new Set();
    allTextures = new Set();
    geometryCache = new Map();
    materialCache = new Map();
    tileTextures = new Map();
    blinkStars = [];
    spinners = [];
    confetti = [];
    confettiMesh;
    starInstanced = null;
    twinkleData = [];
    conveyorTextures = [];
    beacons = new Map();
    glowTexture = null;
    keyLight;
    shadowAnchor = new THREE.Vector3(999, 0, 999);
    staticTwinkleMatrix = new THREE.Matrix4();
    confettiMatrix = new THREE.Matrix4();
    confettiSpin = new THREE.Euler();
    confettiScale = new THREE.Vector3();
    moodTarget = new THREE.Color(0x211445);
    stagePieces = new Map();
    catchCage = new THREE.Group();
    leverArm = new THREE.Group();
    crankWheel = new THREE.Group();
    sharkJaw = new THREE.Group();
    gateStars = new THREE.Group();
    worldTime = 0;
    seeded = 92331;
    pitColor = new THREE.Color(0x1d123d);
    constructor() {
        this.scene.background = new THREE.Color(0x140b37);
        this.scene.fog = new THREE.FogExp2(0x211445, 0.0068);
        this.scene.add(this.staticRoot, this.detailRoot, this.dustRoot, this.finaleRoot, this.silhouette, this.glowRoot);
        this.effects = new VisualFX(this.scene);
        this.createLighting();
        this.createCabinet();
        this.createPlatforms();
        this.createHub();
        this.createCrankRoom();
        this.createCatchRoom();
        this.createLeverRoom();
        this.createThroneRoom();
        this.createBorders();
        this.createRewards();
        this.createAtmosphere();
        this.createConfetti();
        this.createCabinetDressing();
        this.createHubDressing();
        this.createClockworkDressing();
        this.createConservatoryDressing();
        this.createLeverDressing();
        this.createThroneDressing();
        this.createBeacons();
    }
    random() {
        this.seeded = (1664525 * this.seeded + 1013904223) >>> 0;
        return this.seeded / 4294967296;
    }
    geo(kind) {
        let cached = this.geometryCache.get(kind);
        if (cached)
            return cached;
        if (kind === 'box')
            cached = new THREE.BoxGeometry(1, 1, 1);
        else if (kind === 'sphere')
            cached = new THREE.SphereGeometry(1, 20, 14);
        else if (kind === 'sphere-low')
            cached = new THREE.SphereGeometry(1, 10, 7);
        else if (kind === 'cylinder')
            cached = new THREE.CylinderGeometry(1, 1, 1, 24);
        else if (kind === 'cone')
            cached = new THREE.ConeGeometry(1, 1, 8);
        else if (kind === 'octa')
            cached = new THREE.OctahedronGeometry(1, 0);
        else if (kind === 'torus')
            cached = new THREE.TorusGeometry(1, .12, 8, 32);
        else if (kind === 'plane')
            cached = new THREE.PlaneGeometry(1, 1);
        else
            cached = new THREE.BoxGeometry(1, 1, 1);
        this.geometryCache.set(kind, cached);
        this.allGeometry.add(cached);
        return cached;
    }
    material(color, opts = {}) {
        const key = [color, opts.metal ?? .1, opts.rough ?? .56, opts.emissive ?? 0, opts.emit ?? 0, Number(Boolean(opts.flat)), Number(Boolean(opts.transparent)), opts.opacity ?? 1].join('/');
        const old = this.materialCache.get(key);
        if (old)
            return old;
        const mat = new THREE.MeshStandardMaterial({
            color, metalness: opts.metal ?? .1, roughness: opts.rough ?? .56,
            emissive: opts.emissive ?? 0, emissiveIntensity: opts.emit ?? 0,
            flatShading: opts.flat ?? false, transparent: opts.transparent ?? false,
            opacity: opts.opacity ?? 1
        });
        this.materialCache.set(key, mat);
        this.allMaterials.add(mat);
        return mat;
    }
    mesh(parent, kind, xyz, scale, material) {
        const item = new THREE.Mesh(this.geo(kind), material);
        item.position.set(...xyz);
        item.scale.set(...scale);
        // Dominant silhouettes cast; small props never multiply shadow-map draw calls.
        item.castShadow = kind !== 'plane' && parent === this.staticRoot;
        item.receiveShadow = true;
        parent.add(item);
        return item;
    }
    box(parent, xyz, scale, color, opts) {
        return this.mesh(parent, 'box', xyz, scale, this.material(color, opts));
    }
    globe(parent, xyz, scale, color, opts) {
        return this.mesh(parent, 'sphere', xyz, scale, this.material(color, opts));
    }
    cylinder(parent, xyz, scale, color, opts) {
        return this.mesh(parent, 'cylinder', xyz, scale, this.material(color, opts));
    }
    ring(parent, xyz, size, color, opts) {
        return this.mesh(parent, 'torus', xyz, [size, size, size], this.material(color, opts));
    }
    solid(x, y, z, sx, sy, sz, color, trim = true) {
        const mesh = this.box(this.staticRoot, [x, y, z], [sx, sy, sz], color, { rough: .5 });
        this.cameraObstacles.push(mesh);
        this.solids.push({ x0: x - sx / 2, x1: x + sx / 2, z0: z - sz / 2, z1: z + sz / 2, bottom: y - sy / 2, top: y + sy / 2 });
        if (trim && sy > 1.4)
            this.box(this.detailRoot, [x, y + sy / 2 - .15, z], [sx + .14, .24, sz + .14], PALETTE.gold, { metal: .55 });
    }
    createLighting() {
        this.scene.add(new THREE.HemisphereLight(0xc5dbff, 0x594064, 2.05));
        const sun = new THREE.DirectionalLight(0xffefd8, 2.45);
        sun.position.set(-25, 60, 22);
        sun.castShadow = true;
        sun.shadow.mapSize.set(1024, 1024);
        sun.shadow.camera.left = -29;
        sun.shadow.camera.right = 29;
        sun.shadow.camera.top = 29;
        sun.shadow.camera.bottom = -29;
        sun.shadow.camera.near = 1;
        sun.shadow.camera.far = 130;
        sun.shadow.normalBias = .045;
        sun.shadow.bias = -.0001;
        sun.shadow.radius = 2.5;
        this.keyLight = sun;
        this.scene.add(sun, sun.target);
        const lights = [
            [0, 14, 0, 0xff9ed9, 70], [2, 12, -49, 0xffb859, 45],
            [55, 13, 0, 0x6df9d6, 45], [-55, 13, 0, 0x65c7ff, 45],
            [0, 16, 46, 0xfaa4d8, 60]
        ];
        for (const [x, y, z, color, distance] of lights) {
            const p = new THREE.PointLight(color, 33, distance, 2);
            p.position.set(x, y, z);
            this.scene.add(p);
            this.lights.push(p);
        }
    }
    canvasTexture(draw, size = 256) {
        const c = document.createElement('canvas');
        c.width = c.height = size;
        const ctx = c.getContext('2d');
        if (!ctx)
            throw new Error('2D canvas not available');
        draw(ctx);
        const texture = new THREE.CanvasTexture(c);
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.anisotropy = 4;
        this.allTextures.add(texture);
        return texture;
    }
    tiledTexture(tone) {
        const old = this.tileTextures.get(tone);
        if (old)
            return old;
        const colors = {
            hub: ['#f0c8c9', '#efafc8', '#fff0db'],
            hall: ['#e1b9d6', '#c78cbf', '#f5dfe1'],
            crank: ['#e7a35e', '#edc077', '#ffe9a4'],
            catch: ['#a7dcb2', '#73c5b1', '#dff6bd'],
            lever: ['#78b8ce', '#5b8fbc', '#c5e2ed'],
            throne: ['#ffcd9a', '#ed91b2', '#ffe6c9']
        };
        const [base, second, dots] = colors[tone] ?? colors.hub;
        const texture = this.canvasTexture((ctx) => {
            // Draw at half resolution: the repeats remain intricate while clones cost 4x less GPU memory.
            ctx.scale(.5, .5);
            const W = 512, cell = 64;
            ctx.fillStyle = base;
            ctx.fillRect(0, 0, W, W);
            for (let row = 0; row < 8; row++)
                for (let col = 0; col < 8; col++) {
                    const x = col * cell, y = row * cell;
                    const even = (row + col) % 2 === 0;
                    ctx.fillStyle = even ? base : second;
                    ctx.fillRect(x + 2, y + 2, cell - 3, cell - 3);
                    const glaze = ctx.createLinearGradient(x, y, x + 64, y + 64);
                    glaze.addColorStop(0, '#ffffff35');
                    glaze.addColorStop(.34, '#ffffff04');
                    glaze.addColorStop(1, '#210b3c29');
                    ctx.fillStyle = glaze;
                    ctx.fillRect(x + 2, y + 2, cell - 4, cell - 4);
                    ctx.strokeStyle = '#fff8e15c';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(x + 4, y + 4, 56, 56);
                    ctx.strokeStyle = '#27144242';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(x + 8, y + 8, 48, 48);
                    ctx.fillStyle = dots;
                    for (const [ax, ay] of [[12, 12], [52, 12], [12, 52], [52, 52]]) {
                        ctx.beginPath();
                        ctx.arc(x + ax, y + ay, 2, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    if ((row * 7 + col * 11) % 5 === 0) {
                        ctx.beginPath();
                        ctx.moveTo(x + 27, y + 24);
                        ctx.lineTo(x + 32, y + 18);
                        ctx.lineTo(x + 37, y + 24);
                        ctx.lineTo(x + 32, y + 31);
                        ctx.closePath();
                        ctx.fillStyle = '#fff8dd88';
                        ctx.fill();
                    }
                }
            // Subtle printed flecks suggest lacquered paper instead of stock checkerboard tiles.
            for (let i = 0; i < 2200; i++) {
                const x = (i * 107.37) % 512, y = (i * 73.19 + i * i * .014) % 512;
                ctx.fillStyle = i % 3 ? '#26114212' : '#fff9e229';
                ctx.fillRect(x, y, i % 5 ? 1 : 2, 1);
            }
        }, 256);
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.RepeatWrapping;
        this.tileTextures.set(tone, texture);
        return texture;
    }
    createPlatforms() {
        for (const def of PLATFORMS) {
            const group = new THREE.Group();
            group.name = 'walkable:' + def.id;
            group.position.set(def.x, def.top, def.z);
            this.staticRoot.add(group);
            const tone = def.kind === 'hub' ? 'hub' : def.kind === 'hall' ? 'hall' : def.kind === 'throne' ? 'throne' :
                def.id.startsWith('crank') ? 'crank' : def.id.startsWith('catch') ? 'catch' : 'lever';
            const trim = def.kind === 'spring' ? 0x5dcebe : def.kind === 'conveyor' ? 0x5d86cb : def.kind === 'bridge' ? 0xfada89 : 0x714e97;
            this.box(group, [0, -.45, 0], [def.sx, .84, def.sz], trim, { metal: .18, rough: .42 });
            this.box(group, [0, -.12, 0], [def.sx + .35, .15, def.sz + .35], PALETTE.gold, { metal: .5, rough: .28 });
            const tx = this.tiledTexture(tone).clone();
            this.allTextures.add(tx);
            tx.wrapS = THREE.RepeatWrapping;
            tx.wrapT = THREE.RepeatWrapping;
            tx.repeat.set(def.sx / 9, def.sz / 9);
            tx.needsUpdate = true;
            if (def.kind === 'conveyor')
                this.conveyorTextures.push({ texture: tx, x: def.beltX ? -.09 : 0, y: def.beltZ ? .1 : 0 });
            const mat = new THREE.MeshStandardMaterial({ map: tx, roughness: .66, metalness: .05, side: THREE.DoubleSide });
            this.allMaterials.add(mat);
            const surface = this.mesh(group, 'plane', [0, .015, 0], [def.sx - .10, def.sz - .10, 1], mat);
            surface.rotation.x = -Math.PI / 2;
            surface.castShadow = false;
            if (def.kind === 'spring') {
                const pad = this.cylinder(group, [0, .14, 0], [2.1, .2, 2.1], 0x6ddfc7, { metal: .3, rough: .27 });
                this.ring(group, [0, .26, 0], 1.57, 0xfaffd3, { emissive: 0x74cbb9, emit: .45 });
                pad.material = this.material(0x72d4bc, { metal: .3 });
                for (let i = 0; i < 8; i++) {
                    const a = i * Math.PI / 4;
                    const petal = this.globe(group, [Math.cos(a) * 1.58, .17, Math.sin(a) * 1.58], [.65, .1, .35], i % 2 ? 0xffd8ad : 0xf7a4cb, { metal: .12 });
                    petal.rotation.y = -a;
                }
            }
            if (def.kind === 'conveyor') {
                this.box(group, [0, .095, 0], [def.sx - .35, .09, def.sz - .35], 0x283d6d, { metal: .5 });
                for (let i = -2; i <= 2; i++) {
                    const arrow = this.box(group, [i * .84, .17, 0], [.25, .045, 3.3], 0x9df8f3, { emissive: 0x44aeb2, emit: .5 });
                    arrow.rotation.y = def.beltZ ? Math.PI / 2 : 0;
                }
            }
            if (def.kind === 'throne') {
                for (let z = -13; z < 15; z += 6) {
                    for (let x = -11; x < 15; x += 6) {
                        const crystal = this.mesh(group, 'octa', [x, .13, z], [.17, .3, .17], this.material(0xffeaaa, { metal: .6, emissive: 0xffc072, emit: .12 }));
                        crystal.castShadow = false;
                    }
                }
            }
            group.visible = !def.required;
            // Raised levels are visibly supported: painted toy masonry, not floating placeholders.
            if (def.top > .5 && def.kind !== 'bridge') {
                const legs = def.top > 2.1 ? 4 : 2;
                for (let i = 0; i < legs; i++) {
                    const x = (i % 2 ? 1 : -1) * (def.sx / 2 - .7);
                    const z = (i < 2 ? -1 : 1) * (def.sz / 2 - .7);
                    const height = def.top + 6.4;
                    this.box(group, [x, -height / 2 - .15, z], [.56, height, .56], 0x563d77, { rough: .64 });
                    this.box(group, [x, -.2, z], [.84, .5, .84], 0xf1cd87, { metal: .3 });
                }
            }
            this.surfaces.push({ def, group });
        }
        this.solid(-14.7, 2.5, -9.5, 1.0, 5, 8, 0x6d4a91);
        this.solid(-14.7, 2.5, 9.5, 1.0, 5, 8, 0x6d4a91);
        this.solid(14.7, 2.5, -9.5, 1.0, 5, 8, 0x6d4a91);
        this.solid(14.7, 2.5, 9.5, 1.0, 5, 8, 0x6d4a91);
        this.solid(-9.8, 2.5, -13.6, 9.1, 5, 1.1, 0x6d4a91);
        this.solid(9.8, 2.5, -13.6, 9.1, 5, 1.1, 0x6d4a91);
        this.solid(-9.8, 2.5, 13.6, 9.1, 5, 1.1, 0x6d4a91);
        this.solid(9.8, 2.5, 13.6, 9.1, 5, 1.1, 0x6d4a91);
    }
    label(parent, name, at, width, glow = false, rotationY = 0) {
        const group = new THREE.Group();
        parent.add(group);
        group.position.set(...at);
        group.rotation.y = rotationY;
        const height = width * .21;
        const bg = this.mesh(group, 'plane', [0, 0, -.04], [width, height, 1], this.material(glow ? 0x58356f : 0x332457, { metal: .22, rough: .44 }));
        bg.material = this.material(glow ? 0x58356f : 0x332457, { metal: .22, rough: .44, emissive: glow ? 0x4d1e65 : 0, emit: glow ? .35 : 0 });
        this.box(group, [0, height * .51, 0], [width + .35, .09, .22], 0xf4ca7e, { metal: .65 });
        this.box(group, [0, -height * .51, 0], [width + .35, .09, .22], 0xf4ca7e, { metal: .65 });
        const texture = this.canvasTexture(ctx => {
            ctx.clearRect(0, 0, 256, 256);
            ctx.fillStyle = '#fff4ce';
            ctx.font = '900 31px Trebuchet MS, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const parts = name.split('|');
            for (let i = 0; i < parts.length; i++)
                ctx.fillText(parts[i], 128, 128 + (i - (parts.length - 1) / 2) * 37, 247);
        });
        const mat = new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, side: THREE.DoubleSide });
        this.allMaterials.add(mat);
        this.mesh(group, 'plane', [0, 0, .085], [width, height, 1], mat);
        return group;
    }
    createCabinet() {
        const root = this.silhouette;
        // The toy world sits inside a monumental open-faced arcade cabinet.
        this.box(root, [0, -12, -4], [176, 3, 165], 0x291447, { metal: .08 });
        this.box(root, [0, -11.1, 77], [178, 2.5, 7], 0xf5aeae, { metal: .1, emissive: 0x66264e, emit: .22 });
        this.box(root, [0, -11.1, -84], [178, 2.5, 7], 0xf5aeae, { metal: .1, emissive: 0x66264e, emit: .22 });
        this.box(root, [-90, 8, -3], [8, 49, 174], 0x542777, { metal: .25 });
        this.box(root, [90, 8, -3], [8, 49, 174], 0x542777, { metal: .25 });
        this.box(root, [0, 31, -84], [188, 9, 6], 0x341f6a, { metal: .25 });
        this.box(root, [0, 34, -80], [177, 3, 5], 0xe985b8, { emissive: 0x9a386d, emit: .45 });
        for (let i = -6; i <= 6; i++) {
            const x = i * 12;
            this.box(root, [x, 30.5, -80], [5, 1, .7], i % 2 ? 0xffc781 : 0x64d5d4, { emissive: i % 2 ? 0xc07541 : 0x248f9d, emit: .65 });
        }
        this.label(root, 'FULL WEASEL 64|THE PARTY IS ELSEWHERE', [0, 34.8, -76.1], 24, true, 0);
        // Large joystick and arcade buttons are visible outside the mini-castle level.
        this.cylinder(root, [58, -7, 57], [7, 1.8, 7], 0x251335, { metal: .4 });
        this.cylinder(root, [58, -2, 57], [1, 11, 1], 0xdcb4e3, { metal: .45 });
        this.globe(root, [58, 4, 57], [3.8, 3.8, 3.8], 0xf377af, { rough: .18 });
        for (const [x, z, color] of [[-55, 53, 0x76d5fa], [-43, 60, 0xf5bf62], [-64, 65, 0xf68fae]]) {
            this.cylinder(root, [x, -6.9, z], [5, 2, 5], color, { metal: .22, rough: .22 });
            this.ring(root, [x, -5.8, z], 4.5, 0xffedd5, { metal: .55 });
        }
        for (let i = 0; i < 16; i++) {
            const x = -81 + i * 11;
            this.globe(root, [x, 24, -81.4], [.75, .75, .75], i % 3 === 0 ? 0xf8c768 : i % 3 === 1 ? 0xfc9ace : 0x75e0d4, { emissive: 0xffffff, emit: .65 });
        }
    }
    tower(x, z, radius, height, roof, color) {
        const g = this.staticRoot;
        this.cylinder(g, [x, height / 2, z], [radius, height, radius], color, { rough: .72 });
        this.solids.push({ x0: x - radius * .7, x1: x + radius * .7, z0: z - radius * .7, z1: z + radius * .7, bottom: 0, top: height + 1 });
        this.cylinder(g, [x, height + .5, z], [radius * 1.15, 1, radius * 1.15], PALETTE.gold, { metal: .4 });
        const cone = this.mesh(g, 'cone', [x, height + 3.05, z], [radius * 1.5, 5.5, radius * 1.5], this.material(roof, { metal: .2, rough: .38 }));
        cone.castShadow = true;
        this.cylinder(g, [x, height + 6.8, z], [.11, 3, .11], 0xffe5ad, { metal: .72 });
        const flag = this.box(g, [x + .75, height + 7.6, z], [1.65, .8, .09], 0xff91bd, { emissive: 0x852b52, emit: .2 });
        flag.rotation.z = .24;
        for (let i = 0; i < 5; i++) {
            const a = i * Math.PI * 2 / 5;
            this.box(g, [x + Math.cos(a) * radius * .89, height * .65, z + Math.sin(a) * radius * .89], [.35, 1.25, .22], 0xffefbd, { emissive: 0xffb870, emit: .1 });
        }
    }
    arch(x, y, z, orientation, wide, color, sign) {
        const g = this.detailRoot;
        if (orientation === 'z') {
            this.box(g, [x - wide / 2, y + 2.65, z], [1.3, 5.3, 1.55], color);
            this.box(g, [x + wide / 2, y + 2.65, z], [1.3, 5.3, 1.55], color);
            this.box(g, [x, y + 5.25, z], [wide + 1.4, 1.25, 1.75], color);
            this.ring(g, [x, y + 5.0, z + .84], wide * .33, PALETTE.gold, { metal: .66 });
            this.label(g, sign, [x, y + 7, z + 1.1], Math.max(wide + 1, 11), true, 0);
        }
        else {
            this.box(g, [x, y + 2.65, z - wide / 2], [1.55, 5.3, 1.3], color);
            this.box(g, [x, y + 2.65, z + wide / 2], [1.55, 5.3, 1.3], color);
            this.box(g, [x, y + 5.25, z], [1.75, 1.25, wide + 1.4], color);
            this.label(g, sign, [x + (x < 0 ? -.95 : .95), y + 7, z], Math.max(wide + 1, 11), true, x < 0 ? -Math.PI / 2 : Math.PI / 2);
        }
    }
    createHub() {
        this.arch(0, 0, -13.4, 'z', 11, 0x7a468b, 'CLOCKWORK|CRANK');
        this.arch(0, 0, 13.5, 'z', 11, 0x7a468b, 'THRONE|ROOM');
        this.arch(14.8, 0, 0, 'x', 11, 0x7a468b, 'CATCH|CONSERVATORY');
        this.arch(-14.8, 0, 0, 'x', 11, 0x7a468b, 'LEVER|LANES');
        for (const [x, z] of [[-11, -10], [11, -10], [-11, 10], [11, 10]]) {
            this.tower(x, z, 2.25, 8.4, 0xf29fcb, 0xdfbcea);
        }
        const central = this.staticRoot;
        this.cylinder(central, [0, .43, 0], [4.3, .85, 4.3], 0xd07caa, { metal: .35 });
        this.solids.push({ x0: -3.55, x1: 3.55, z0: -3.55, z1: 3.55, bottom: 0, top: 1.7 });
        this.cylinder(central, [0, .92, 0], [3.55, .18, 3.55], 0xffdf9d, { metal: .5, rough: .23 });
        this.cylinder(central, [0, 1.28, 0], [2.8, .54, 2.8], 0x773a8c, { metal: .35 });
        this.ring(central, [0, 1.6, 0], 1.8, 0xffca74, { emissive: 0xffab67, emit: .7 });
        // Central diorama is decorative; the surrounding hub floor is traversable.
        const trophy = this.mesh(central, 'octa', [0, 4.0, 0], [1.25, 2.35, 1.25], this.material(0xf7d37d, { metal: .62, rough: .2, emissive: 0xef9f62, emit: .22 }));
        this.spinners.push({ object: trophy, speed: .3, axis: 'y' });
        for (let i = 0; i < 12; i++) {
            const a = (i / 12) * Math.PI * 2;
            const r = 8;
            const head = this.globe(this.detailRoot, [Math.cos(a) * r, .24, Math.sin(a) * r], [.24, .24, .24], i % 2 ? 0xfac4d8 : 0x69e3dd, { emissive: 0xffffff, emit: .6 });
            this.blinkStars.push({ mesh: head, offset: i * .65 });
        }
        for (const [x, z, rot] of [[-7, 4, 0], [7, 4, Math.PI], [0, -7, -Math.PI / 2]]) {
            const g = new THREE.Group();
            g.position.set(x, 0, z);
            g.rotation.y = rot;
            this.detailRoot.add(g);
            this.box(g, [0, .6, 0], [2.8, 1.1, 1.15], 0xc56e8d);
            this.solids.push({ x0: x - 1.35, x1: x + 1.35, z0: z - .55, z1: z + .55, bottom: 0, top: 1.5 });
            this.box(g, [0, 1.23, 0], [3.1, .21, 1.4], 0xffd68e, { metal: .4 });
            this.cylinder(g, [1.0, 1.53, 0], [.13, .6, .13], 0xffdd9f, { metal: .65 });
            this.globe(g, [1, 1.95, 0], [.3, .3, .3], 0xfcc3e1, { emissive: 0xfc9dcc, emit: .3 });
        }
        this.label(this.detailRoot, 'THE TREAT|IS THE HERO', [0, 10.6, -4], 12, true, 0);
    }
    gear(parent, pos, radius, color, axis = 'z', speed = 0) {
        const g = new THREE.Group();
        g.position.set(...pos);
        parent.add(g);
        const disc = this.cylinder(g, [0, 0, 0], [radius * .85, .3, radius * .85], color, { metal: .65, rough: .29 });
        disc.rotation.x = Math.PI / 2;
        this.ring(g, [0, 0, .18], radius * .56, 0xffedb7, { metal: .68 });
        this.cylinder(g, [0, 0, .37], [.25, .4, .25], 0x673a65, { metal: .7 }).rotation.x = Math.PI / 2;
        for (let i = 0; i < 12; i++) {
            const a = (i / 12) * Math.PI * 2;
            const tooth = this.box(g, [Math.sin(a) * radius, Math.cos(a) * radius, 0], [radius * .3, .48, .53], color, { metal: .65 });
            tooth.rotation.z = -a;
        }
        if (speed)
            this.spinners.push({ object: g, speed, axis });
        return g;
    }
    roomBackdrop(x, z, sizeX, sizeZ, base, accent) {
        // A low-level upholstered foam pit gives missed jumps a readable consequence.
        this.box(this.staticRoot, [x, -9.35, z], [sizeX, 1.1, sizeZ], base, { rough: .9 });
        for (let i = 0; i < 24; i++) {
            const xx = x + (this.random() - .5) * (sizeX - 4);
            const zz = z + (this.random() - .5) * (sizeZ - 4);
            const bubble = this.globe(this.dustRoot, [xx, -8.35 + this.random() * .35, zz], [.6 + this.random(), .26, .6 + this.random()], i % 3 === 0 ? accent : base, { rough: .75 });
            bubble.castShadow = false;
        }
    }
    createCrankRoom() {
        this.roomBackdrop(0, -47, 37, 44, 0x503078, 0xe3a46f);
        this.arch(0, 0, -29, 'z', 10.4, 0xf2a665, 'WIND IT|UP');
        this.tower(-15, -48, 3.6, 12.5, 0xf5a867, 0xf1c982);
        this.tower(15, -61, 3.2, 10.5, 0xea8e68, 0xa8dbea);
        for (let i = 0; i < 7; i++) {
            const z = -38 - i * 3.7;
            this.gear(this.detailRoot, [-15.6, 8.2 + (i % 3) * 2.25, z], 1.35 + i * .13, i % 2 ? 0xe0a861 : 0xf7d798, 'z', i % 2 ? .33 : -.4);
        }
        for (let i = 0; i < 5; i++) {
            const x = -9 + i * 5.2;
            const chain = this.box(this.detailRoot, [x, 10, -61], [.13, 12, .13], 0xffddaa, { metal: .8 });
            chain.castShadow = false;
            const orb = this.globe(this.detailRoot, [x, 3.5, -61], [.78, .78, .78], i % 2 ? 0xffb69b : 0x8ce8de, { metal: .28, emissive: i % 2 ? 0xb8434e : 0x1b8c95, emit: .3 });
            this.spinners.push({ object: orb, speed: .3, axis: 'y' });
        }
        const wheel = new THREE.Group();
        wheel.position.set(9, 6.45, -49);
        this.detailRoot.add(wheel);
        this.crankWheel = wheel;
        this.ring(wheel, [0, 0, 0], 1.6, 0xffd47e, { metal: .8, rough: .23 });
        for (let i = 0; i < 8; i++) {
            const a = i * Math.PI / 4;
            const spoke = this.box(wheel, [Math.cos(a) * .81, Math.sin(a) * .81, 0], [1.6, .16, .2], 0xffe7a0, { metal: .65 });
            spoke.rotation.z = a;
        }
        this.cylinder(wheel, [0, 0, .23], [.28, .52, .28], 0x78426c, { metal: .65 }).rotation.x = Math.PI / 2;
        this.globe(wheel, [1.7, 0, .3], [.38, .38, .38], 0xff9ba9, { metal: .4 });
        const switchPed = this.cylinder(this.detailRoot, [9, 4.8, -49], [1.12, .56, 1.12], 0x9a5975, { metal: .45 });
        switchPed.castShadow = false;
        this.ring(this.detailRoot, [9, 4.95, -49], .95, 0xffde97, { metal: .65 });
        this.label(this.detailRoot, 'A BRIDGE|OF WIND-UP', [3, 10, -58], 10, true, 0);
        const goldenBridge = this.stagePieces.get('crank') ?? new THREE.Group();
        this.stagePieces.set('crank', goldenBridge);
        this.detailRoot.add(goldenBridge);
        for (let i = 0; i < 14; i++) {
            const a = i / 14 * Math.PI * 2;
            const light = this.globe(goldenBridge, [Math.sin(a) * 5.2, 5, Math.cos(a) * 3.8 - 59], [.18, .18, .18], 0xffefac, { emissive: 0xffaa66, emit: 1 });
            light.castShadow = false;
        }
        goldenBridge.visible = false;
    }
    createCatchRoom() {
        this.roomBackdrop(52, 0, 48, 37, 0x316776, 0xc3e9b0);
        this.arch(31, 0, 0, 'x', 10, 0x53aa94, 'RELEASE|THE CATCH');
        for (let i = 0; i < 13; i++) {
            const x = 36 + i * 2.7;
            const z = i % 2 === 0 ? 11 : -12;
            this.cylinder(this.detailRoot, [x, -3, z], [.22, 12, .22], 0x4bbf9b);
            this.globe(this.detailRoot, [x, 3 + this.random() * 3, z], [1.4, 2.9, 1.4], i % 2 ? 0x8decb8 : 0xb1eab2, { rough: .8 });
            this.globe(this.detailRoot, [x + (i % 2 ? 1 : -1), 6.5 + this.random() * 2, z], [1.1, .72, 1.5], 0xffb1c1, { rough: .55 });
        }
        for (let i = 0; i < 9; i++) {
            const x = 36 + i * 4.15;
            const z = (i % 3 - 1) * 8;
            const flower = this.globe(this.detailRoot, [x, 7 + this.random() * 2.4, z], [.6, .6, .6], 0xffd3b2, { emissive: 0xeb9a63, emit: .4 });
            for (let k = 0; k < 6; k++) {
                const a = k * Math.PI / 3;
                this.globe(this.detailRoot, [x + Math.sin(a) * 1.15, 7 + Math.cos(a) * 1.15, z], [.69, .88, .38], i % 2 ? 0xff9bbb : 0xb9d7f1, { rough: .52 });
            }
        }
        const cage = new THREE.Group();
        cage.position.set(65.2, 3.6, 4.2);
        this.catchCage = cage;
        this.detailRoot.add(cage);
        for (let i = -2; i <= 2; i++) {
            this.box(cage, [i * .66, 1.55, 1.45], [.13, 3.1, .14], 0xffce8e, { metal: .7 });
            this.box(cage, [i * .66, 1.55, -1.45], [.13, 3.1, .14], 0xffce8e, { metal: .7 });
            this.box(cage, [1.45, 1.55, i * .66], [.14, 3.1, .13], 0xffce8e, { metal: .7 });
            this.box(cage, [-1.45, 1.55, i * .66], [.14, 3.1, .13], 0xffce8e, { metal: .7 });
        }
        this.box(cage, [0, 3.25, 0], [3.7, .5, 3.7], 0x52a7a0, { metal: .5 });
        for (const [x, z] of [[60.8, -3.2], [65.2, -3.2]]) {
            this.cylinder(this.detailRoot, [x, 3.95, z], [.75, .7, .75], 0x8bc9c3, { metal: .5 });
        }
        const handle = new THREE.Group();
        handle.position.set(63, 4.6, -3.5);
        this.detailRoot.add(handle);
        this.box(handle, [0, .43, 0], [.28, .95, .25], 0xffdc8f, { metal: .68 });
        this.globe(handle, [0, 1, 0], [.5, .5, .5], 0xffa6b9, { emissive: 0xac4062, emit: .25 });
        this.label(this.detailRoot, 'A VERY|IMPORTANT CATCH', [64, 10, -8], 12, true, 0);
    }
    createLeverRoom() {
        this.roomBackdrop(-52, 0, 47, 39, 0x263d6c, 0x7da2c1);
        this.arch(-31, 0, 0, 'x', 10, 0x628cb5, 'PULL THE|LEVER');
        for (let i = 0; i < 7; i++) {
            const z = -13 + i * 4.4;
            this.gear(this.detailRoot, [-68, 6.5 + (i % 3) * 2, z], 1.2 + i * .18, i % 2 ? 0x64d5e1 : 0xffbb74, 'z', i % 2 ? .33 : -.25);
        }
        for (let i = 0; i < 7; i++) {
            const z = -14 + i * 4.5;
            this.box(this.detailRoot, [-35, 3.4, z], [.5, 6.8, .6], 0x9ae7e2, { metal: .4, emissive: 0x2b8b90, emit: .3 });
        }
        for (let i = 0; i < 6; i++) {
            const lamp = this.globe(this.detailRoot, [-37 - i * 5.6, 8, 12], [1.2, 1.2, 1.2], i % 2 ? 0xfbd3b2 : 0xa3e1f1, { emissive: i % 2 ? 0x8d4934 : 0x2389b0, emit: .36 });
            lamp.castShadow = false;
        }
        const lever = new THREE.Group();
        lever.position.set(-63, 3.95, -2.5);
        this.leverArm = lever;
        this.detailRoot.add(lever);
        this.cylinder(lever, [0, .15, 0], [1.05, .55, 1.05], 0x4b7192, { metal: .55 });
        const rod = this.box(lever, [0, 1.1, 0], [.25, 2.4, .27], 0xffd38f, { metal: .7 });
        rod.rotation.z = .24;
        this.globe(lever, [.3, 2.4, 0], [.68, .68, .68], 0xf49ab5, { rough: .25, emissive: 0xb54e68, emit: .24 });
        const bridgeGroup = new THREE.Group();
        this.detailRoot.add(bridgeGroup);
        this.stagePieces.set('lever', bridgeGroup);
        for (let i = 0; i < 7; i++) {
            const lamp = this.globe(bridgeGroup, [-66 + i * .94, 3.8, 7.2], [.19, .19, .19], 0xe8d88c, { emissive: 0xe6ad4a, emit: .8 });
            lamp.castShadow = false;
        }
        bridgeGroup.visible = false;
        this.label(this.detailRoot, 'CONVEYORS|OF QUESTIONABLE WISDOM', [-62, 9, -8], 16, true, 0);
    }
    createThroneRoom() {
        this.arch(0, 0, 30, 'z', 10.8, 0xe48d9d, 'ONE BUTTON|TO PARTY');
        for (const [x, z] of [[-13, 33], [13, 33], [-13, 57], [13, 57]]) {
            this.tower(x, z, 2.2, 9.2, x < 0 ? 0xfa93bc : 0xf6d08d, 0x9c6baa);
        }
        this.box(this.detailRoot, [0, 3.2, 59.5], [19, 6.3, 1.5], 0x8a407b);
        this.box(this.detailRoot, [0, 6.65, 59.5], [21, 1.1, 1.6], 0xffcb93, { metal: .4 });
        for (let x = -8; x <= 8; x += 4) {
            this.cylinder(this.detailRoot, [x, 8.5, 59], [.26, 3.4, .26], 0xffeac1, { metal: .58 });
            this.globe(this.detailRoot, [x, 10.8, 59], [.8, .8, .8], 0xf99cc3, { emissive: 0xe87daf, emit: .5 });
        }
        this.label(this.detailRoot, 'THE PARTY|IS IN HERE', [0, 10, 58.5], 17, true, Math.PI);
        const pedestal = this.staticRoot;
        this.cylinder(pedestal, [0, .6, 46.8], [3.0, 1.1, 3.0], 0x8350a0, { metal: .35 });
        this.cylinder(pedestal, [0, 1.15, 46.8], [2.6, .25, 2.6], 0xffd78d, { metal: .6 });
        this.cylinder(this.buttonCap, [0, 0, 0], [1.6, .65, 1.6], 0xfa738d, { metal: .38, rough: .16, emissive: 0xab2a63, emit: .28 });
        this.ring(this.buttonCap, [0, .36, 0], 1.55, 0xffefba, { emissive: 0xe39b55, emit: .4 });
        this.buttonCap.position.set(0, 1.65, 46.8);
        this.detailRoot.add(this.buttonCap);
        // Mechanical throne at far wall, not an inaccessible level-select door.
        const throne = new THREE.Group();
        throne.position.set(0, 0, 56.3);
        this.staticRoot.add(throne);
        this.box(throne, [0, 1, 0], [4.9, 2.0, 3.3], 0xe8bb74, { metal: .54 });
        this.box(throne, [0, 3, -1.3], [5.1, 4.1, 1.1], 0x783c89, { rough: .35 });
        this.box(throne, [0, 3.3, -.68], [4.2, 2.8, .3], 0xd7609b, { rough: .49 });
        for (const x of [-2.2, 2.2]) {
            this.cylinder(throne, [x, 5.45, -1.3], [.6, 1.3, .6], 0xffd68e, { metal: .54 });
            this.globe(throne, [x, 6.3, -1.3], [.65, .65, .65], 0xffe2a5, { metal: .55 });
        }
        this.ring(throne, [0, 4.7, -.35], 1.0, 0xffe7a6, { metal: .6 });
        this.gate.position.set(0, 0, GATE_Z);
        this.staticRoot.add(this.gate);
        for (let x = -4; x <= 4; x += .9) {
            this.box(this.gate, [x, 2.8, 0], [.22, 5.5, .5], 0xf6c885, { metal: .76, rough: .25, emissive: 0x925d28, emit: .13 });
        }
        this.box(this.gate, [0, .5, 0], [9.4, .65, .75], 0x7d548e, { metal: .38 });
        this.box(this.gate, [0, 5.5, 0], [9.4, .65, .75], 0x7d548e, { metal: .38 });
        this.gateStars.position.set(0, 3, GATE_Z + .6);
        this.detailRoot.add(this.gateStars);
        this.ring(this.gateStars, [0, 0, 0], 1.4, 0xffd779, { metal: .6 });
        const lockStar = this.mesh(this.gateStars, 'octa', [0, 0, .4], [1, 1.2, .3], this.material(0xffe69d, { metal: .75, emissive: 0xf29d45, emit: .28 }));
        this.spinners.push({ object: lockStar, speed: .5, axis: 'y' });
        for (let i = -1; i <= 1; i++) {
            this.box(this.detailRoot, [i * 2.7, 11.6, 54], [.17, 18, .17], 0xffdcae, { metal: .6 });
        }
        this.box(this.detailRoot, [0, 20.3, 54], [9, .85, 1.2], 0x6d467f, { metal: .5 });
        this.createSharkPuppet();
        for (let i = 0; i < 13; i++) {
            const z = 34 + i * 1.8;
            const x = (i % 2 ? 1 : -1) * 12.8;
            this.globe(this.detailRoot, [x, 5.7, z], [.6, .6, .6], i % 3 === 0 ? 0xffadce : i % 3 === 1 ? 0xffdfa1 : 0x88e4e5, { emissive: 0x985a7e, emit: .5 });
        }
    }
    createSharkPuppet() {
        this.puppet.position.set(0, 16, 52.5);
        this.finaleRoot.add(this.puppet);
        const shark = this.puppet;
        const blue = 0x5dcfe0;
        const fin = 0x3e9db9;
        this.globe(shark, [0, .3, 0], [2.05, 1.52, 3.6], blue, { rough: .34, metal: .15 });
        this.globe(shark, [0, -.38, -.8], [1.65, 1.02, 2.7], 0xf9eedc, { rough: .72 });
        this.globe(shark, [0, .05, -2.8], [1.35, .92, 1.5], blue, { rough: .3 });
        for (const x of [-1.15, 1.15]) {
            this.globe(shark, [x, .71, -2.65], [.31, .31, .24], 0xfff9e6);
            this.globe(shark, [x, .75, -2.86], [.16, .2, .15], 0x1d315a, { rough: .12 });
            this.globe(shark, [x * 1.1, .85, -2.96], [.09, .1, .06], 0xffffff);
        }
        this.globe(shark, [0, .05, -4.05], [1, .43, 1], blue, { rough: .35 });
        for (const x of [-1.75, 1.75]) {
            const wing = this.mesh(shark, 'cone', [x, -.24, .4], [1.2, .25, 1.7], this.material(fin, { rough: .4 }));
            wing.rotation.z = x < 0 ? Math.PI / 2 : -Math.PI / 2;
            wing.rotation.y = x < 0 ? -.15 : .15;
        }
        const dorsal = this.mesh(shark, 'cone', [0, 1.91, .6], [1.15, 1.75, .75], this.material(fin, { rough: .46 }));
        dorsal.rotation.x = .28;
        this.globe(shark, [0, .14, 3.1], [.35, .55, 1.1], blue);
        const tail = this.mesh(shark, 'cone', [0, .55, 3.85], [1.7, 2.1, .34], this.material(fin, { rough: .4 }));
        tail.rotation.z = Math.PI;
        const jaw = new THREE.Group();
        jaw.position.set(0, -.75, -2.94);
        this.sharkJaw = jaw;
        shark.add(jaw);
        this.globe(jaw, [0, -.17, -.38], [1.25, .33, 1.27], 0xffffff, { rough: .63 });
        this.box(jaw, [0, .12, -.9], [1.75, .1, .47], 0x6c3357, { rough: .8 });
        for (let i = -3; i <= 3; i++) {
            const tooth = this.mesh(jaw, 'cone', [i * .24, -.05, -1.04], [.12, .36, .12], this.material(0xfff9e6, { rough: .47 }));
            tooth.rotation.z = Math.PI;
        }
        // Clear it is an articulated theatrical puppet, not a real shark.
        for (const x of [-1.7, 1.7]) {
            const string = this.box(shark, [x, 4.35, 0], [.07, 7.5, .07], 0xffe3a9, { metal: .7 });
            string.castShadow = false;
        }
        this.label(shark, 'SPECIAL GUEST|NOT A REAL SHARK', [0, 6.5, .2], 11, true, 0);
        shark.visible = false;
    }
    createBorders() {
        // True collision perimeter with deliberate gaps aligning to the four open hallways.
        for (const x of [-5.7, 5.7]) {
            this.solid(x, 1.55, -21, .65, 3.1, 14.5, 0x8b5b98);
            this.solid(x, 1.55, 21, .65, 3.1, 14.5, 0x8b5b98);
        }
        for (const z of [-5.7, 5.7]) {
            this.solid(22, 1.55, z, 15, .65 + 2.45, .65, 0x8b5b98);
            this.solid(-22, 1.55, z, 15, 3.1, .65, 0x8b5b98);
        }
        // Crank room; south edge has an open ten-unit entrance.
        this.solid(-17.5, 3, -48, .9, 6, 42, 0xb97a8d);
        this.solid(17.5, 3, -48, .9, 6, 42, 0xb97a8d);
        this.solid(0, 3, -69, 36, 6, .9, 0xb97a8d);
        for (const x of [-11.4, 11.4])
            this.solid(x, 3, -27.7, 13.4, 6, .9, 0xb97a8d);
        // Catch room; west gap is the actual east hallway entrance.
        for (const z of [-19, 19])
            this.solid(54, 3, z, 46, 6, .9, 0x4d999e);
        this.solid(76.8, 3, 0, .9, 6, 38, 0x4d999e);
        for (const z of [-12.3, 12.3])
            this.solid(31, 3, z, .9, 6, 13.6, 0x4d999e);
        // Lever room; east gap is the actual west hallway entrance.
        for (const z of [-19, 19])
            this.solid(-54, 3, z, 44, 6, .9, 0x607eae);
        this.solid(-76, 3, 0, .9, 6, 38, 0x607eae);
        for (const z of [-12.3, 12.3])
            this.solid(-31.3, 3, z, .9, 6, 13.6, 0x607eae);
        // The throne's north wall is open behind the functional locked gate.
        this.solid(-16.2, 3.5, 45, .9, 7, 34, 0xb86c99);
        this.solid(16.2, 3.5, 45, .9, 7, 34, 0xb86c99);
        this.solid(0, 3.5, 62, 32, 7, .9, 0xb86c99);
        for (const x of [-11.0, 11.0])
            this.solid(x, 3.5, 28, 10, 7, .9, 0xb86c99);
        // Rendered crenellations reinforce the toy-castle silhouette.
        for (const [axis, start, end, fixed, y, color] of [
            ['x', -15, 15, -13.6, 0, 0xf9b5d1], ['x', -15, 15, 13.6, 0, 0xf9b5d1],
            ['x', -17, 17, -69, 0, 0xf4be8f], ['x', -17, 17, -27.7, 0, 0xf4be8f],
            ['z', -19, 19, 76.8, 0, 0x9ceec9], ['z', -19, 19, -76, 0, 0x93d7f0]
        ]) {
            for (let n = start + 1; n < end; n += 2.6) {
                if (axis === 'x')
                    this.box(this.detailRoot, [n, y + 6.4, fixed], [1.55, 1.3, .95], color, { rough: .52 });
                else
                    this.box(this.detailRoot, [fixed, y + 6.4, n], [.95, 1.3, 1.55], color, { rough: .52 });
            }
        }
    }
    starShape(points = 5) {
        const shape = new THREE.Shape();
        const outer = 1, inner = .46;
        for (let i = 0; i < points * 2; i++) {
            const a = (Math.PI * i / points) - Math.PI / 2;
            const r = i % 2 ? inner : outer;
            const x = Math.cos(a) * r, y = Math.sin(a) * r;
            if (i === 0)
                shape.moveTo(x, y);
            else
                shape.lineTo(x, y);
        }
        shape.closePath();
        return shape;
    }
    tokenMesh() {
        const group = new THREE.Group();
        const geo = new THREE.ExtrudeGeometry(this.starShape(), { depth: .36, bevelEnabled: true, bevelThickness: .11, bevelSize: .11, bevelSegments: 2, steps: 1 });
        this.allGeometry.add(geo);
        const token = new THREE.Mesh(geo, this.material(0xffd56f, { metal: .72, rough: .2, emissive: 0x8a4b08, emit: .22 }));
        token.castShadow = true;
        group.add(token);
        const halo = this.ring(group, [0, 0, -.3], 1.65, 0xffe9a9, { emissive: 0xffd068, emit: 1, metal: .25 });
        halo.material = this.material(0xffe9a9, { emissive: 0xffd068, emit: .75, metal: .25 });
        const backGlow = this.mesh(group, 'octa', [0, 0, -.6], [.6, .6, .17], this.material(0xfffed8, { emissive: 0xffeaa0, emit: .6 }));
        backGlow.castShadow = false;
        for (let i = 0; i < 5; i++) {
            const a = i * Math.PI * 2 / 5;
            const spark = this.mesh(group, 'octa', [Math.sin(a) * 1.8, Math.cos(a) * 1.8, 0], [.18, .18, .18], this.material(0xfff8cc, { emissive: 0xffe68d, emit: 1 }));
            spark.castShadow = false;
        }
        return group;
    }
    createRewards() {
        for (const name of MECHANISMS) {
            const spot = REWARDS[name];
            const group = this.tokenMesh();
            group.position.set(spot.x, spot.y, spot.z);
            group.name = 'reward:' + name;
            group.visible = false;
            this.coins.set(name, group);
            this.detailRoot.add(group);
            const baseColor = name === 'crank' ? 0xf5b76e : name === 'catch' ? 0x8fd8c1 : 0x97b5ed;
            this.cylinder(this.detailRoot, [spot.x, spot.y - 1.08, spot.z], [1.6, .2, 1.6], baseColor, { metal: .45 });
            this.ring(this.detailRoot, [spot.x, spot.y - .95, spot.z], 1.2, 0xffe6a4, { emissive: 0xffc36f, emit: .3 });
        }
    }
    createAtmosphere() {
        // Fixed-seed sparkle constellations give the cabinet a luminous staged depth.
        const sparkleMat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
        this.allMaterials.add(sparkleMat);
        const sparkleMesh = new THREE.InstancedMesh(this.geo('octa'), sparkleMat, 135);
        sparkleMesh.frustumCulled = false;
        sparkleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.starInstanced = sparkleMesh;
        this.dustRoot.add(sparkleMesh);
        const tints = [0xffbdce, 0xfde7a8, 0x96ece8, 0xe9c4ff];
        for (let i = 0; i < 135; i++) {
            const at = new THREE.Vector3((this.random() - .5) * 156, 6 + this.random() * 28, (this.random() - .5) * 145);
            const size = new THREE.Vector3(.09 + this.random() * .23, .17 + this.random() * .32, .09 + this.random() * .23);
            const phase = this.random() * Math.PI * 2;
            this.twinkleData.push({ position: at, size, phase });
            this.staticTwinkleMatrix.makeScale(size.x, size.y, size.z);
            this.staticTwinkleMatrix.setPosition(at);
            sparkleMesh.setMatrixAt(i, this.staticTwinkleMatrix);
            sparkleMesh.setColorAt(i, new THREE.Color(tints[i % 4]));
        }
        sparkleMesh.instanceMatrix.needsUpdate = true;
        if (sparkleMesh.instanceColor)
            sparkleMesh.instanceColor.needsUpdate = true;
        for (let i = 0; i < 13; i++) {
            const x = (this.random() - .5) * 135;
            const z = (this.random() - .5) * 130;
            const y = 15 + this.random() * 16;
            const cloud = new THREE.Group();
            cloud.position.set(x, y, z);
            this.dustRoot.add(cloud);
            const tint = i % 3 === 0 ? 0xebc4f5 : i % 3 === 1 ? 0xb4d6ee : 0xf1b4c9;
            for (let j = 0; j < 4; j++) {
                const puff = this.globe(cloud, [(j - 1.6) * 1.5, (j % 2) * .35, .2 * j], [1.7 + (j % 2) * .6, .6 + .15 * j, .87], tint, { transparent: true, opacity: .43, rough: .95 });
                puff.castShadow = false;
            }
        }
        for (const [x, z] of [[-10, -13], [10, -13], [-13, 10], [13, 10], [31, -5], [-31, 5]]) {
            const beam = this.mesh(this.detailRoot, 'cone', [x, 8, z], [.8, 12, .8], this.material(0xffdda9, { transparent: true, opacity: .12, emissive: 0xffae80, emit: .34 }));
            beam.castShadow = false;
        }
    }
    createConfetti() {
        // One draw call for the entire celebration, regardless of confetti count.
        const colors = [0xf6b5d6, 0xffd47e, 0x92e2d7, 0x7da6ed, 0xfdf4ca, 0xdb8bda];
        const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, toneMapped: false });
        this.allMaterials.add(mat);
        this.confettiMesh = new THREE.InstancedMesh(this.geo('box'), mat, 140);
        this.confettiMesh.frustumCulled = false;
        this.confettiMesh.castShadow = false;
        this.confettiMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.confettiMesh.count = 0;
        this.finaleRoot.add(this.confettiMesh);
        for (let i = 0; i < 140; i++) {
            const x = (this.random() - .5) * 28;
            const z = 34 + this.random() * 27;
            const phase = this.random();
            this.confetti.push({ originX: x, originZ: z, speed: 1.8 + this.random() * 2.6, phase: phase * 18, phaseX: this.random() * Math.PI * 2, scaleX: .14 + this.random() * .24, scaleY: .11 + this.random() * .15 });
            this.confettiMesh.setColorAt(i, new THREE.Color(colors[i % colors.length]));
        }
        if (this.confettiMesh.instanceColor)
            this.confettiMesh.instanceColor.needsUpdate = true;
    }
    /** Lacquer, velvet, brass and light-punched paper are the shared scenic vocabulary. */
    addGlow(at, color, size) {
        if (!this.glowTexture) {
            this.glowTexture = this.canvasTexture((ctx) => {
                const g = ctx.createRadialGradient(128, 128, 6, 128, 128, 126);
                g.addColorStop(0, '#ffffffff');
                g.addColorStop(.15, '#fffffff2');
                g.addColorStop(.35, '#ffffff8c');
                g.addColorStop(.75, '#ffffff16');
                g.addColorStop(1, '#ffffff00');
                ctx.fillStyle = g;
                ctx.fillRect(0, 0, 256, 256);
            });
        }
        const mat = new THREE.SpriteMaterial({ map: this.glowTexture, color, transparent: true, opacity: .53, depthWrite: false, blending: THREE.AdditiveBlending, depthTest: true, toneMapped: false });
        this.allMaterials.add(mat);
        const sprite = new THREE.Sprite(mat);
        sprite.position.set(...at);
        sprite.scale.set(size, size, 1);
        this.glowRoot.add(sprite);
    }
    banner(at, width, height, primary, accent, angle = 0) {
        const root = new THREE.Group();
        root.position.set(...at);
        root.rotation.y = angle;
        this.detailRoot.add(root);
        this.box(root, [0, .3, 0], [width + .24, .18, .23], 0xf6d998, { metal: .72, rough: .29 });
        for (const x of [-width / 2, width / 2])
            this.globe(root, [x, .3, 0], [.17, .17, .17], 0xfff0be, { metal: .75 });
        const cloth = this.box(root, [0, -height / 2, 0], [width, height, .10], primary, { rough: .93 });
        cloth.castShadow = false;
        this.box(root, [0, -.16, .09], [width * .9, .12, .07], accent, { metal: .39 });
        this.box(root, [0, -height + .29, .1], [width * .88, .11, .07], accent, { metal: .39 });
        const medallion = this.mesh(root, 'octa', [0, -height * .43, .15], [.48, .68, .12], this.material(accent, { metal: .66, rough: .24 }));
        medallion.castShadow = false;
        this.ring(root, [0, -height * .43, .22], .32, 0xfff3d4, { metal: .56 });
        for (let i = 0; i < 3; i++)
            this.box(root, [-width * .29 + i * width * .29, -height * .79, .15], [.11, height * .18, .04], accent, { metal: .4 });
    }
    lantern(at, color, scale = 1) {
        const g = this.detailRoot;
        this.cylinder(g, [at[0], at[1] - .42 * scale, at[2]], [.43 * scale, .18 * scale, .43 * scale], 0x7b547a, { metal: .5 });
        this.cylinder(g, [at[0], at[1] + .4 * scale, at[2]], [.51 * scale, .15 * scale, .51 * scale], 0xf0d292, { metal: .64 });
        const glass = this.globe(g, at, [.44 * scale, .59 * scale, .44 * scale], color, { emissive: color, emit: .95, metal: .08, rough: .23 });
        glass.castShadow = false;
        for (const side of [-1, 1])
            this.box(g, [at[0] + side * .32 * scale, at[1], at[2]], [.07 * scale, .83 * scale, .08 * scale], 0xeac38e, { metal: .6 });
        this.addGlow(at, color, 5.6 * scale);
    }
    floorSeal(x, z, radius, color) {
        // Keep actual line weight fixed instead of scaling torus tube thickness by radius.
        for (const [r, tint, width] of [[radius, color, .075], [radius * .79, 0xffefcd, .045]]) {
            const geometry = new THREE.TorusGeometry(r, width, 6, 96);
            this.allGeometry.add(geometry);
            const line = new THREE.Mesh(geometry, this.material(tint, { metal: .52, rough: .32, emissive: tint, emit: .1 }));
            line.position.set(x, .065, z);
            line.rotation.x = Math.PI / 2;
            line.castShadow = false;
            line.receiveShadow = false;
            this.detailRoot.add(line);
        }
        for (let j = 0; j < 8; j++) {
            const a = j * Math.PI / 4;
            const dot = this.mesh(this.detailRoot, 'octa', [x + Math.sin(a) * radius * .9, .08, z + Math.cos(a) * radius * .9], [.15, .07, .15], this.material(color, { metal: .58 }));
            dot.castShadow = false;
        }
    }
    createCabinetDressing() {
        // Recessed external pin-striping and stage-bulb marquee are readable from every region.
        for (const x of [-86, 86]) {
            this.box(this.silhouette, [x, 8, -2], [.6, 38, 147], 0xeab47f, { metal: .73, rough: .24 });
            this.box(this.silhouette, [x + (x < 0 ? 2 : -2), 8, -2], [.2, 33, 143], 0xf3a2c3, { emissive: 0x95456a, emit: .42 });
        }
        for (let i = 0; i < 13; i++) {
            const x = -70 + i * 11.7;
            this.lantern([x, 27.8, -77.2], i % 3 === 0 ? 0xffc475 : i % 3 === 1 ? 0xff99c2 : 0x8ae8db, .76);
        }
        for (let i = 0; i < 6; i++) {
            const x = -52 + i * 21;
            this.box(this.silhouette, [x, -9.4, 73], [12, .18, 3.6], i % 2 ? 0x7b3a91 : 0x5b3579, { metal: .4 });
        }
        this.banner([-76, 24, -73], 4.4, 11, 0x7e356d, 0xffd18c, .14);
        this.banner([76, 24, -73], 4.4, 11, 0x276c84, 0xf5cc85, -.14);
    }
    createHubDressing() {
        this.floorSeal(0, 0, 9.4, 0xffd690);
        for (const [x, z, rotation, accent] of [
            [0, -9, 0, 0xf5bb80], [0, 9, 0, 0xff99c5], [9, 0, Math.PI / 2, 0x80e3c7], [-9, 0, Math.PI / 2, 0x9ab9ec]
        ]) {
            const arrow = this.mesh(this.detailRoot, 'cone', [x, .085, z], [.38, .15, .62], this.material(accent, { metal: .39, emissive: accent, emit: .12 }));
            arrow.rotation.x = Math.PI / 2;
            arrow.rotation.z = rotation;
            arrow.castShadow = false;
        }
        for (const [x, z, col] of [[-12, -13, 0xffb980], [12, -13, 0xffb980], [-12, 13, 0x7cdddf], [12, 13, 0x7cdddf]]) {
            this.lantern([x, 6.6, z], col, .8);
        }
        for (const [x, z, ang, c] of [[-8, -14, 0, 0xb75a8f], [8, -14, 0, 0x754c9b], [-14, -8, Math.PI / 2, 0x4b839e], [14, 8, -Math.PI / 2, 0x478d85]]) {
            this.banner([x, 10.3, z], 2.3, 4.3, c, 0xffd991, ang);
        }
        for (const [x, z] of [[-15, -3], [15, 3], [-6, 14], [6, -14]]) {
            const pole = this.cylinder(this.detailRoot, [x, 2.15, z], [.16, 4.3, .16], 0xd6b88a, { metal: .43 });
            pole.castShadow = false;
            this.globe(this.detailRoot, [x, 4.45, z], [.39, .39, .39], 0xffeeb6, { emissive: 0xffd687, emit: .55 });
        }
        this.addGlow([0, 5.5, 0], 0xffc879, 9);
    }
    createClockworkDressing() {
        // Overscale dial on an exterior wall makes the entire challenge feel clock-driven.
        const face = new THREE.Group();
        face.position.set(-15.8, 13.5, -56);
        this.detailRoot.add(face);
        const dial = this.cylinder(face, [0, 0, 0], [4.2, .27, 4.2], 0xffe7b2, { metal: .45, rough: .42 });
        dial.rotation.x = Math.PI / 2;
        this.ring(face, [0, 0, .23], 4.0, 0x926080, { metal: .74, rough: .28 });
        this.ring(face, [0, 0, .26], 3.58, 0xb5814d, { metal: .63 });
        for (let i = 0; i < 12; i++) {
            const angle = i * Math.PI / 6;
            const tick = this.box(face, [Math.sin(angle) * 3.22, Math.cos(angle) * 3.22, .34], [i % 3 ? .13 : .19, i % 3 ? .31 : .56, .10], 0x835370, { metal: .5 });
            tick.rotation.z = -angle;
        }
        const hand1 = this.box(face, [0, 1.15, .4], [.16, 2.65, .17], 0x7e416c, { metal: .61 });
        hand1.rotation.z = -.55;
        const hand2 = this.box(face, [.4, .66, .43], [.2, 1.6, .17], 0xa86b53, { metal: .61 });
        hand2.rotation.z = .68;
        this.globe(face, [0, 0, .55], [.33, .33, .22], 0xe8a66c, { metal: .52 });
        for (const [x, z] of [[-13, -38], [-13, -62], [13, -57]]) {
            this.lantern([x, 11, z], 0xffd287, .88);
        }
        for (const z of [-37, -47, -57]) {
            const wheel = this.gear(this.detailRoot, [-15.3, 11.7, z], .92, 0xf8c78f, 'z', .16);
            wheel.rotation.y = .15;
        }
        for (const [x, z] of [[15, -38], [-15, -53], [15, -64]]) {
            this.box(this.detailRoot, [x, 3, z], [.3, 6, .3], 0x87607c, { metal: .32 });
            this.globe(this.detailRoot, [x, 6.25, z], [.48, .48, .48], 0xffbb85, { metal: .4, emissive: 0xa44b4e, emit: .4 });
        }
        this.banner([13, 13.1, -63], 2.6, 7, 0x99576c, 0xffd796, -Math.PI / 2);
        this.addGlow([0, 7, -61], 0xffb879, 10);
    }
    createConservatoryDressing() {
        // The translucent glasshouse canopy is intentionally above all navigable jump arcs.
        for (const x of [39, 52, 68]) {
            for (const z of [-15, 15]) {
                const pole = this.cylinder(this.detailRoot, [x, 6.6, z], [.27, 12.3, .27], 0x3f8990, { metal: .37 });
                pole.castShadow = false;
                this.globe(this.detailRoot, [x, 13, z], [.59, .59, .59], 0xffdc9f, { emissive: 0x7a9c71, emit: .3 });
            }
            const span = this.box(this.detailRoot, [x, 12.75, 0], [.28, .37, 30.2], 0xd0c69b, { metal: .5 });
            span.castShadow = false;
            const finial = this.mesh(this.detailRoot, 'octa', [x, 14.25, 0], [.65, 1.42, .65], this.material(0xd2f4bd, { transparent: true, opacity: .7, metal: .21 }));
            finial.castShadow = false;
        }
        for (let i = 0; i < 13; i++) {
            const x = 37 + i * 2.7;
            const z = i % 2 ? 15.8 : -15.8;
            const sprig = new THREE.Group();
            sprig.position.set(x, 1.1, z);
            this.detailRoot.add(sprig);
            this.cylinder(sprig, [0, 1.35, 0], [.12, 2.7, .12], 0x4b997f);
            for (let j = 0; j < 4; j++) {
                const h = .65 + j * .72, side = j % 2 ? -1 : 1;
                const leaf = this.globe(sprig, [side * .67, h, 0], [.9, .24, .48], j % 2 ? 0x9cddb2 : 0x68c1a5, { rough: .64 });
                leaf.rotation.z = side * .38;
            }
            this.globe(sprig, [0, 3.1, 0], [.48, .48, .48], i % 3 ? 0xffa9c1 : 0xffe3a5, { emissive: 0xb76b75, emit: .3 });
        }
        for (const [x, z] of [[42, -5], [49, 3], [55, -4]]) {
            this.addGlow([x, 2.4, z], 0x8df7d7, 8.6);
        }
        this.banner([71, 11, 13.6], 3.1, 5.5, 0x468b86, 0xf2d89f, Math.PI);
        this.banner([43, 11, -14.7], 2.7, 4.8, 0x397c83, 0xffd5ad, Math.PI);
        this.lantern([65, 9, 7], 0x9ff7d0, 1.15);
    }
    createLeverDressing() {
        // Blue steel, brass seam-lines, and circuit conduits unify the conveyor chapter.
        for (const z of [-14, 14]) {
            this.box(this.detailRoot, [-55, 4, z], [37, .22, .21], 0xf2c581, { metal: .58 });
            this.box(this.detailRoot, [-54, 4.3, z], [37, .12, .14], 0x8de1e4, { emissive: 0x5acbd1, emit: .55 });
        }
        for (let i = 0; i < 9; i++) {
            const x = -37 - i * 4;
            const z = i % 2 ? 15 : -15;
            this.cylinder(this.detailRoot, [x, 4.9, z], [.24, 9.6, .24], 0x366683, { metal: .52 });
            const cap = this.globe(this.detailRoot, [x, 9.6, z], [.7, .7, .7], i % 2 ? 0x88e0ef : 0xffd09a, { emissive: i % 2 ? 0x5caad8 : 0x915544, emit: .55 });
            cap.castShadow = false;
            this.addGlow([x, 9.6, z], i % 2 ? 0x8de9f0 : 0xffc38b, 5.5);
        }
        for (const [x, z] of [[-47, 11], [-58, -11], [-69, 9]]) {
            this.gear(this.detailRoot, [x, 11.5, z], 2, 0xb5d3cb, 'z', .31);
        }
        for (const [x, y, z] of [[-37, .06, 0], [-49, 1.66, -4], [-63, 3.26, 0]]) {
            const stripe = this.box(this.detailRoot, [x, y, z], [1.4, .06, 1.4], 0xffc886, { metal: .32, emissive: 0xc27d39, emit: .25 });
            stripe.rotation.y = Math.PI / 4;
        }
        this.banner([-71, 12, -10], 2.8, 5.8, 0x456f9b, 0xffe2ad, Math.PI / 2);
    }
    createThroneDressing() {
        // A proper puppet theatre lives *within* the toy castle: proscenium, curtains, footlights.
        for (const x of [-13.5, 13.5]) {
            this.box(this.detailRoot, [x, 8, 53], [1.4, 16, 2], 0xc2769a, { metal: .22 });
            this.box(this.detailRoot, [x, 15.7, 53], [2, 1.2, 2.5], 0xffe0a3, { metal: .55 });
            const velvet = x < 0 ? 0x913d74 : 0x5f397d;
            for (let i = 0; i < 4; i++) {
                this.box(this.detailRoot, [x + (x < 0 ? 1.2 : -1.2) + (i - 1.5) * .3, 7.5, 55], [.55, 13.9, .18], velvet, { rough: .93 });
            }
            this.lantern([x, 14.3, 52], 0xffd59d, 1.12);
        }
        const arch = this.box(this.detailRoot, [0, 16, 53], [27, 1.4, 2.2], 0x6b387e, { metal: .27 });
        arch.castShadow = false;
        this.box(this.detailRoot, [0, 16.45, 54.2], [24.3, .27, .27], 0xffce89, { metal: .61 });
        for (let x = -11; x <= 11; x += 2.2) {
            this.globe(this.detailRoot, [x, 16.8, 54], [.25, .25, .25], Math.round(x) % 2 ? 0xf7d789 : 0xffa1cc, { emissive: 0xe59d64, emit: .8 });
            this.addGlow([x, 16.8, 54], 0xffc3a3, 3.0);
        }
        for (let x = -10; x <= 10; x += 5) {
            const bulb = this.globe(this.detailRoot, [x, .5, 34], [.54, .54, .54], 0xffefc3, { emissive: 0xf9ba64, emit: .86 });
            bulb.castShadow = false;
            this.addGlow([x, .7, 34], 0xffdc97, 4.8);
        }
        for (const [x, z] of [[-10, 40], [10, 40], [-11, 52], [11, 52]]) {
            this.banner([x, 12.5, z], 2.7, 6.2, x < 0 ? 0x874280 : 0xb85e83, 0xffdc9c, x < 0 ? Math.PI / 2 : -Math.PI / 2);
        }
        this.floorSeal(0, 46.8, 4.9, 0xffcf8c);
        this.addGlow([0, 8.2, 56], 0xffbcb8, 11);
    }
    createBeacons() {
        for (const key of MECHANISMS) {
            const where = key === 'crank' ? [9, 4.6, -49] : key === 'catch' ? [63, 3.7, -3.5] : [-63, 3.4, -2.5];
            const col = key === 'crank' ? 0xffd080 : key === 'catch' ? 0x82e9cc : 0xa3c9fd;
            const g = new THREE.Group();
            g.position.set(where[0], where[1], where[2]);
            this.detailRoot.add(g);
            const orbit = this.ring(g, [0, .08, 0], 1.9, col, { metal: .47, emissive: col, emit: .45 });
            orbit.rotation.x = Math.PI / 2;
            const points = 6;
            for (let i = 0; i < points; i++) {
                const a = i * Math.PI * 2 / points;
                const point = this.mesh(g, 'octa', [Math.cos(a) * 1.92, .13, Math.sin(a) * 1.92], [.24, .24, .24], this.material(0xfff7cb, { emissive: col, emit: .38 }));
                point.castShadow = false;
            }
            this.beacons.set(key, g);
            this.addGlow([where[0], where[1] + 1, where[2]], col, 4.7);
        }
    }
    burst(at, kind, tier, reducedMotion) {
        this.effects.burst(at, kind, tier, reducedMotion);
    }
    /** Called when authoritative gameplay progress changes. */
    synchronize(progress) {
        for (const v of this.surfaces) {
            if (v.def.required)
                v.group.visible = progress.engaged[v.def.required];
        }
        for (const key of MECHANISMS) {
            this.coins.get(key).visible = progress.engaged[key] && !progress.rewards[key];
        }
        for (const [key, group] of this.stagePieces) {
            group.visible = progress.engaged[key];
        }
        this.gate.visible = !throneUnlocked(progress);
        this.gateStars.visible = !throneUnlocked(progress);
        this.puppet.visible = progress.won;
        if (!progress.won) {
            this.puppet.position.set(0, 16, 52.5);
            this.lights[4].color.set(0xfaa4d8);
        }
        this.confettiMesh.visible = progress.won;
        for (const [key, beacon] of this.beacons)
            beacon.visible = !progress.engaged[key];
    }
    visibleSurfaces(progress) {
        return PLATFORMS.filter(p => !p.required || progress.engaged[p.required]);
    }
    /** All collision solids are physical scenery; locked throne gate is the only dynamic solid. */
    solidBounds(progress) {
        if (throneUnlocked(progress))
            return this.solids;
        return [...this.solids, { x0: -4.7, x1: 4.7, z0: GATE_Z - .43, z1: GATE_Z + .43, bottom: 0, top: 5.7 }];
    }
    update(dt, progress, reducedMotion, quality, focus) {
        this.worldTime += dt;
        const t = this.worldTime;
        const motion = reducedMotion ? .2 : 1;
        if (focus) {
            if (this.shadowAnchor.distanceToSquared(focus) > 12) {
                this.shadowAnchor.set(focus.x, 0, focus.z);
                this.keyLight.position.set(focus.x - 25, 60, focus.z + 22);
                this.keyLight.target.position.set(focus.x, 0, focus.z);
                this.keyLight.target.updateMatrixWorld();
            }
            const zone = focus.x > 29 ? 0x173c48 : focus.x < -29 ? 0x192a51 : focus.z < -29 ? 0x36223c : focus.z > 28 ? 0x3c1c41 : 0x211445;
            this.moodTarget.setHex(zone);
            const fog = this.scene.fog;
            fog.color.lerp(this.moodTarget, 1 - Math.exp(-1.35 * dt));
            this.scene.background.lerp(this.moodTarget, 1 - Math.exp(-1.35 * dt));
        }
        for (const [key, beacon] of this.beacons) {
            beacon.visible = !progress.engaged[key];
            if (beacon.visible) {
                const pulse = reducedMotion ? 1 : 1 + .047 * Math.sin(t * 3.6);
                beacon.scale.set(pulse, 1, pulse);
            }
        }
        if (this.starInstanced && quality !== 'low' && !reducedMotion) {
            for (let i = 0; i < this.twinkleData.length; i++) {
                const part = this.twinkleData[i], pulse = .83 + .17 * Math.sin(t * 1.25 + part.phase);
                this.staticTwinkleMatrix.makeScale(part.size.x * pulse, part.size.y * pulse, part.size.z * pulse);
                this.staticTwinkleMatrix.setPosition(part.position);
                this.starInstanced.setMatrixAt(i, this.staticTwinkleMatrix);
            }
            this.starInstanced.instanceMatrix.needsUpdate = true;
        }
        for (const belt of this.conveyorTextures) {
            if (!reducedMotion) {
                belt.texture.offset.x = (belt.texture.offset.x + belt.x * dt) % 1;
                belt.texture.offset.y = (belt.texture.offset.y + belt.y * dt) % 1;
            }
        }
        this.effects.update(dt, quality, reducedMotion);
        for (const spinner of this.spinners) {
            spinner.object.rotation[spinner.axis] += dt * spinner.speed * motion;
        }
        for (const spark of this.blinkStars) {
            if (reducedMotion) {
                spark.mesh.scale.setScalar(.17);
                continue;
            }
            const pulse = .79 + .22 * Math.sin(t * 1.8 + spark.offset);
            spark.mesh.scale.multiplyScalar(Math.min(1.03, Math.max(.97, pulse / (.79 + .22 * Math.sin((t - dt) * 1.8 + spark.offset)))));
        }
        for (const name of MECHANISMS) {
            const coin = this.coins.get(name);
            if (coin.visible) {
                coin.rotation.y = reducedMotion ? 0 : t * 1.05;
                coin.rotation.z = Math.sin(t * 1.6) * .1 * motion;
                coin.position.y = REWARDS[name].y + (reducedMotion ? 0 : Math.sin(t * 2.7) * .26);
            }
        }
        this.crankWheel.rotation.z = progress.engaged.crank ? t * (reducedMotion ? .2 : 1.5) : Math.sin(t * .65) * .11;
        this.catchCage.position.y = THREE.MathUtils.damp(this.catchCage.position.y, progress.engaged.catch ? 9.1 : 3.6, 4.5, dt);
        this.catchCage.visible = !progress.engaged.catch || this.catchCage.position.y < 8.95;
        this.leverArm.rotation.z = THREE.MathUtils.damp(this.leverArm.rotation.z, progress.engaged.lever ? -.88 : 0, 4, dt);
        this.buttonCap.position.y = THREE.MathUtils.damp(this.buttonCap.position.y, progress.won ? 1.27 : 1.65, 5, dt);
        if (progress.won) {
            this.puppet.position.y = THREE.MathUtils.damp(this.puppet.position.y, 7.8, reducedMotion ? 22 : 1.15, dt);
            this.puppet.rotation.y = Math.sin(t * (reducedMotion ? .4 : 1.2)) * (reducedMotion ? .01 : .14);
            this.sharkJaw.rotation.x = reducedMotion ? -.19 : -.18 - .16 * Math.sin(t * 4.5);
            const count = quality === 'low' || reducedMotion ? 0 : quality === 'medium' ? 82 : this.confetti.length;
            this.confettiMesh.count = count;
            this.confettiMesh.visible = count > 0;
            for (let i = 0; i < count; i++) {
                const p = this.confetti[i];
                const y = 18 - (((t * p.speed + p.phase) % 18));
                this.confettiSpin.set(t * 1.3 + p.phaseX, t * 1.9, Math.sin(t * .5 + p.phaseX));
                this.confettiMatrix.makeRotationFromEuler(this.confettiSpin);
                this.confettiScale.set(p.scaleX, p.scaleY, .045);
                this.confettiMatrix.scale(this.confettiScale);
                this.confettiMatrix.setPosition(p.originX + Math.sin(t * 1.1 + p.phaseX) * 1.6, Math.max(.35, y), p.originZ + Math.sin(t * .71 + p.phaseX));
                this.confettiMesh.setMatrixAt(i, this.confettiMatrix);
            }
            if (count)
                this.confettiMesh.instanceMatrix.needsUpdate = true;
            const phase = Math.sin(t * 4);
            this.lights[4].color.setHSL(.86 + phase * .03, .72, .65);
            this.lights[4].intensity = quality === 'low' ? 9 : quality === 'medium' ? 22 : 28 + Math.sin(t * 2) * 5;
        }
        if (reducedMotion) {
            this.puppet.position.y = progress.won ? 7.8 : 16;
            this.catchCage.position.y = progress.engaged.catch ? 9.1 : 3.6;
        }
        if (!progress.won)
            this.confettiMesh.count = 0;
        this.dustRoot.visible = quality !== 'low';
        this.glowRoot.visible = quality !== 'low';
    }
    setGraphicsQuality(tier) {
        this.dustRoot.visible = tier !== 'low';
        this.glowRoot.visible = tier !== 'low';
        if (this.starInstanced)
            this.starInstanced.count = tier === 'high' ? 135 : tier === 'medium' ? 84 : 0;
        const shadowSize = tier === 'high' ? 1536 : tier === 'medium' ? 1024 : 512;
        if (this.keyLight.shadow.mapSize.x !== shadowSize) {
            this.keyLight.shadow.map?.dispose();
            this.keyLight.shadow.map = null;
            this.keyLight.shadow.mapSize.set(shadowSize, shadowSize);
        }
        for (let i = 0; i < this.lights.length; i++) {
            this.lights[i].intensity = tier === 'low' ? 9 : tier === 'medium' ? 20 : 31;
        }
    }
    clearFeedback() { this.effects.reset(); }
    dispose() {
        this.effects.dispose();
        this.starInstanced?.dispose();
        this.confettiMesh.dispose();
        this.keyLight.shadow.map?.dispose();
        for (const item of this.allGeometry)
            item.dispose();
        for (const item of this.allTextures)
            item.dispose();
        for (const item of this.allMaterials)
            item.dispose();
        this.geometryCache.clear();
        this.materialCache.clear();
        this.tileTextures.clear();
        this.surfaces.length = 0;
        this.solids.length = 0;
        this.confetti.length = 0;
        this.scene.clear();
    }
}
