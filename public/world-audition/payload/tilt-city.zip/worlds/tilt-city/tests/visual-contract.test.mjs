import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';

const source=(path)=>readFileSync(path,'utf8');
const getHash=(path)=>createHash('sha256').update(readFileSync(path)).digest('hex');

test('gameplay state and physics exactly match the playable source baseline',()=>{
  const ledger=source('BASELINE_SHA256.txt');
  for(const path of ['src/domain.ts','src/physics.ts']){
    const expected=ledger.split('\n').find(line=>line.trim().endsWith('  '+path))?.split(/\s+/)[0];
    assert.ok(expected,`missing baseline: ${path}`);
    assert.equal(getHash(path),expected);
  }
});
test('the four source-command labels remain visible in HUD and never become dispatched commands',()=>{
  const ui=source('src/main.ts');
  const domain=source('src/domain.ts');
  assert.match(ui,/g\.command\.toUpperCase\(\)/);
  assert.match(domain,/Tip forward.*Next track/);
  assert.match(domain,/Tip back.*Previous track/);
  assert.match(domain,/Roll right.*Volume up/);
  assert.match(domain,/Roll left.*Volume down/);
  for(const path of ['src/main.ts','src/scene.ts','src/art-direction.ts','src/effects.ts','index.html']){
    assert.doesNotMatch(source(path),/(?:fetch\s*\(|new\s+WebSocket\s*\(|XMLHttpRequest\s*\(|postMessage\s*\(|mediaSession|sendBeacon\s*\(|shell\.exec|child_process)/i,`forbidden runtime I/O in ${path}`);
  }
});
test('visuals are deterministic, owned by render modules and do not add new collision surfaces',()=>{
  assert.match(source('src/art-direction.ts'),/const rand = \(seed:number\)/);
  assert.match(source('src/art-direction.ts'),/new THREE\.InstancedMesh/);
  assert.match(source('src/scene.ts'),/new ArtDirectedSkyline\(this\.scene\)/);
  assert.match(source('src/scene.ts'),/resetPresentation\(\)/);
  assert.match(source('src/main.ts'),/world\.resetPresentation\(\)/);
  assert.doesNotMatch(source('src/art-direction.ts'),/\.surfaces\s*\(|\.request\s*\(/);
});
test('particle work is explicitly bounded with lifecycle cleanup and reduced-motion suppression',()=>{
  const fx=source('src/effects.ts');
  const cap=Number(fx.match(/const CAPACITY=(\d+);/)?.[1]);
  assert.ok(cap>50&&cap<=256);
  assert.match(fx,/setComfort\(reduced:boolean\)/);
  assert.match(fx,/if\(this\.reduced\)return/);
  assert.match(fx,/this\.points\.parent\?\.remove\(this\.points\)/);
  assert.match(fx,/this\.geometry\.dispose\(\)/);
  assert.match(fx,/this\.texture\.dispose\(\)/);
});
test('quality can reduce GPU costs while preserving gesture input, HUD and fixed-step loop',()=>{
  const main=source('src/main.ts');
  assert.match(main,/setGraphics\(value:GraphicsDetail,manual:boolean\)/);
  assert.match(main,/setPixelRatio/);
  assert.match(main,/qualitySlowFrames>124/);
  assert.match(main,/lookPoint\.lerp\(aimTarget,damp\(7\)\)/);
  assert.match(main,/while\(accumulator>=1\/60/);
  assert.match(source('src/scene.ts'),/skyline\.setQuality\(mode\)/);
});
test('browser package is self-contained and mock museum return remains non-navigating',()=>{
  const html=source('index.html');
  assert.match(html,/id="graphics-btn"/);
  assert.match(html,/id="return-btn"/);
  assert.doesNotMatch(html,/<script[^>]+src\s*=\s*["']https?:/i);
  assert.doesNotMatch(source('src/style.css'),/url\(\s*["']?https?:/i);
  assert.ok(existsSync('integration/README.md'));
  assert.match(source('src/main.ts'),/Intentionally mock only/);
});
