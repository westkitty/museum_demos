export const STANDALONE_ADAPTER = {};
export const FUTURE_INTEGRATION_DESCRIPTOR = Object.freeze({
    id: 'E09', slug: 'museum-evolution', host: 'museum-of-me-vnext',
    candidate: 'the-museum-still-building-itself', status: 'independent prototype',
    installRequired: false, writesMuseumState: false, modifiesMapping: false,
    entry: 'Enter E09', exit: 'Return to Museum',
    eventContract: ['onEnter', 'onPhase', 'onComplete', 'onExit'],
    notes: 'The museum must explicitly pass callbacks and own its exhibit lifecycle. The pocket-world never navigates to a guessed museum URL.'
});
