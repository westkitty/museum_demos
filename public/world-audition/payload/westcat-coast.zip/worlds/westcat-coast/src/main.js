/** Standalone game: one renderer, one frame loop, one authoritative simulation. */
import { CHAPTERS, CHECKPOINTS, PLATFORMS, FINISH_X, SPAWN, chapterFor } from './course.js';
import { createPlayer, simulate, resetPlayer } from './physics.js';
import { InputController } from './input.js';
import { createWorld } from './world.js';

const $=id=>document.getElementById(id);
const dom={
  canvas:$('game'),chapterKicker:$('chapterKicker'),chapterTitle:$('chapterTitle'),chapterSubtitle:$('chapterSubtitle'),chapterBox:document.querySelector('.chapter-title'),
  progress:$('progressFill'),message:$('message'),checkpoint:$('checkpoint'),sparks:$('sparks'),pause:$('pauseBtn'),
  chaseCue:$('chaseCue'),chaseFill:$('chaseFill'),chaseMeter:$('chaseMeter'),
  museum:$('museumBtn'),museumOverlay:$('museumOverlay'),endOverlay:$('endOverlay'),enter:$('enterBtn'),replay:$('replayBtn'),endMuseum:$('endMuseumBtn'),
  settingsBtn:$('settingsBtn'),settings:$('settings'),quality:$('quality'),reduce:$('reducedMotion'),sound:$('sound'),error:$('errorPanel'),errorText:$('errorText'),hint:$('controlsHint'),
};
const params=new URLSearchParams(location.search);
const game={player:createPlayer(SPAWN.x,SPAWN.y),checkpoint:CHECKPOINTS[0],checkpointIndex:0,chapter:-1,
  paused:false,finished:false,portal:false,score:0,chaseActive:false,owlX:92,deaths:0,elapsed:0,
  noticeUntil:0,chapterUntil:0,settingsOpen:false,pausedBeforeSettings:false,accumulator:0,prevTime:0,frame:0};
let world=null,input=null,disposed=false,audioCtx=null;
const clock=()=>performance.now()/1000;
const safeOrigin=()=>{try{return document.referrer?new URL(document.referrer).origin:location.origin;}catch{return location.origin;}};
function sound(freq=500,decay=.12,shape='sine'){
  if(!dom.sound.checked)return;
  try{const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;
    audioCtx=audioCtx||new Ctx();if(audioCtx.state==='suspended')audioCtx.resume();
    const osc=audioCtx.createOscillator(),gain=audioCtx.createGain(),t=audioCtx.currentTime;
    osc.type=shape;osc.frequency.setValueAtTime(freq,t);osc.frequency.exponentialRampToValueAtTime(Math.max(80,freq*.65),t+decay);
    gain.gain.setValueAtTime(.055,t);gain.gain.exponentialRampToValueAtTime(.001,t+decay);
    osc.connect(gain).connect(audioCtx.destination);osc.start(t);osc.stop(t+decay+.01);
  }catch{/* Audio is optional; simulation never depends on it. */}
}
function announce(text,seconds=2.2){dom.message.textContent=text;dom.message.classList.add('visible');game.noticeUntil=clock()+seconds;}
function showChapter(index){
  const c=CHAPTERS[index];game.chapter=index;
  document.documentElement.dataset.chapter=c.id;
  dom.chapterKicker.innerHTML=`CHAPTER ${String(index+1).padStart(2,'0')} <span> / </span> 04`;
  dom.chapterTitle.textContent=c.name;dom.chapterSubtitle.textContent=c.subtitle;
  dom.chapterBox.classList.remove('out');game.chapterUntil=clock()+(index===0?6.5:5.2);
}
function updateHud(){
  dom.progress.style.width=`${Math.max(0,Math.min(100,game.player.x/FINISH_X*100))}%`;
  dom.sparks.textContent=String(game.score).padStart(2,'0');
  const labels={'duncan':'FIRST LIGHT','forest':'FOREST GATE','cedar-approach':'THE UPPER PATH','canopy':'CLOUDLINE','sentinel-bridge':'THE HIGH TRESTLE','last-light':'LAST LIGHT'};
  dom.checkpoint.textContent=`✦ ${labels[game.checkpoint.id]||'CHECKPOINT'}`;
  // The meter is purely observational. Owl physics and catch distance remain unchanged.
  const visible=game.chaseActive&&!game.finished;
  dom.chaseCue.hidden=!visible;
  if(visible){
    const distance=Math.max(0,Math.min(16,game.player.x-game.owlX));
    dom.chaseFill.style.width=`${(distance/16*100).toFixed(1)}%`;
    dom.chaseMeter.setAttribute('aria-valuenow',String(Math.round(distance)));
    dom.chaseCue.classList.toggle('urgent',distance<6);
  }
}
function pause(value){
  if(game.finished||game.portal||game.settingsOpen)game.paused=true;
  else game.paused=Boolean(value);
  dom.pause.textContent=game.paused?'RESUME  P':'PAUSE  P';dom.pause.setAttribute('aria-pressed',String(game.paused));
  if(game.paused)input?.clear();
  else if(!game.portal && !game.settingsOpen)dom.canvas.focus({preventScroll:true});
}
function museum(visible){
  // A portal transition must not strand an open settings panel behind a modal.
  if(visible && game.settingsOpen){game.settingsOpen=false;dom.settings.hidden=true;dom.settingsBtn.setAttribute('aria-expanded','false');}
  game.portal=visible;dom.museumOverlay.hidden=!visible;
  if(visible){game.paused=true;input?.clear();dom.enter.focus();
    if(window.parent!==window){window.parent.postMessage({protocol:'westcat-e26-v1',type:'westcat:return-request',exhibit:'E26'},safeOrigin());}}
  else {game.paused=false;dom.canvas.focus({preventScroll:true});}
  pause(game.paused);
}
function finish(){
  world.emit?.('finish',game.player.x,game.player.y+1.4);
  game.finished=true;game.paused=true;game.chaseActive=false;
  dom.endOverlay.hidden=false;dom.replay.focus();sound(780,.35,'triangle');
  updateHud();
}
function respawn(reason){
  world.emit?.(reason==='owl'?'owl':'fall',game.player.x,game.player.y+.7);
  game.deaths++;
  resetPlayer(game.player,game.checkpoint.x+.18,game.checkpoint.y);
  game.chaseActive=game.checkpoint.x>=103;
  game.owlX=game.player.x-16;
  world.resetView(game.player);
  announce(reason==='owl'?'THE SHADOW FOUND YOU · TRY AGAIN':'A SOFT LANDING, A SECOND CHANCE',2.9);
  sound(185,.22,'triangle');
  updateHud();
}
function newGame(){
  game.checkpoint=CHECKPOINTS[0];game.checkpointIndex=0;game.score=0;game.deaths=0;game.elapsed=0;
  game.chaseActive=false;game.owlX=92;game.finished=false;game.paused=false;game.portal=false;game.chapter=-1;
  game.accumulator=0;game.prevTime=0;game.noticeUntil=0;game.settingsOpen=false;game.pausedBeforeSettings=false;
  dom.settings.hidden=true;dom.settingsBtn.setAttribute('aria-expanded','false');dom.message.classList.remove('visible');
  resetPlayer(game.player,SPAWN.x,SPAWN.y);world.resetView(game.player);
  for(const c of world.collectibles){c.claimed=false;c.node.visible=true;}
  dom.endOverlay.hidden=true;dom.museumOverlay.hidden=true;showChapter(0);updateHud();input.clear();dom.canvas.focus({preventScroll:true});
}
function step(dt){
  const frame=input.consume();
  if(frame.pause){pause(!game.paused);return;}
  if(game.paused||game.portal||game.finished)return;
  game.elapsed+=dt;
  const events=simulate(game.player,frame,PLATFORMS,dt);
  for(const effect of events){
    if(effect==='jump'||effect==='doublejump'||effect==='walljump'||effect==='land')
      world.emit?.(effect,game.player.x,game.player.y+(effect==='land'?.15:.5));
  }
  if(events.includes('jump'))sound(610,.10,'triangle');
  if(events.includes('doublejump'))sound(820,.12,'sine');
  if(events.includes('walljump'))sound(710,.11,'triangle');
  if(events.includes('fall')){respawn('fall');return;}
  const current=chapterFor(game.player.x);
  if(current!==game.chapter){showChapter(current);sound(670,.18);}
  for(let j=game.checkpointIndex+1;j<CHECKPOINTS.length;j++){
    const cp=CHECKPOINTS[j];
    if(game.player.x<cp.x)break;
    if(game.player.y >= cp.y-.45 && game.player.y <= cp.y+3.0){
      game.checkpoint=cp;game.checkpointIndex=j;announce('✦ CHECKPOINT REACHED');world.emit?.('checkpoint',cp.x,cp.y+1.8);sound(880,.28,'sine');
    }
  }
  const found=world.collect(game.player.x,game.player.y);
  if(found){game.score+=found;world.emit?.('collect',game.player.x,game.player.y+1.2);sound(1050,.13,'sine');}
  if(!game.chaseActive && game.player.x>=103){
    game.chaseActive=true;game.owlX=game.player.x-15;
    announce('THE SENTINEL IS AWAKE · RUN!',4.5);world.emit?.('chase',game.player.x,game.player.y+2.5);sound(200,.5,'sawtooth');
  }
  if(game.chaseActive){
    const speed=5.35+Math.min(.9,(game.player.x-103)/55);
    game.owlX+=speed*dt;
    if(game.owlX>game.player.x-.9){respawn('owl');return;}
  }
  if(game.player.x>=FINISH_X && game.player.y>10.8){finish();return;}
  updateHud();
}
function render(now){
  if(disposed)return;
  requestAnimationFrame(render);
  let dt=game.prevTime?Math.min((now-game.prevTime)/1000,.09):0;
  game.prevTime=now;game.frame++;
  if(!game.paused&&!game.portal&&!game.finished){
    game.accumulator+=dt;
    let n=0;
    while(game.accumulator>=1/60 && n<6){step(1/60);game.accumulator-=1/60;n++;if(game.paused||game.finished||game.portal)break;}
  }else{
    const f=input.consume();if(f.pause && !game.portal && !game.finished)pause(!game.paused);
    game.accumulator=0;
  }
  world.step(game.player,game.owlX,game.chaseActive&&!game.finished,game.paused?0:dt,
    dom.reduce.checked,game.finished,game.paused?1:Math.min(1,game.accumulator*60));
  if(clock()>game.noticeUntil)dom.message.classList.remove('visible');
  if(clock()>game.chapterUntil)dom.chapterBox.classList.add('out');
}
function applyQuality(){
  const v=dom.quality.value;
  const autoLow=(navigator.deviceMemory&&navigator.deviceMemory<4)||window.innerWidth<580;
  world.setQuality(v==='auto'?(autoLow?'low':'high'):v);
  world.resize();
}
function showError(error){dom.errorText.textContent=String(error?.message||error||'Unknown WebGL error');dom.error.hidden=false;game.paused=true;}
function boot(){
  try{
    world=createWorld(dom.canvas);input=new InputController(document);
    dom.reduce.checked=matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.documentElement.dataset.motion=dom.reduce.checked?'reduced':'full';
    applyQuality();showChapter(0);updateHud();
    window.__westcatBooted=true;
    dom.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();showError('WebGL context was lost. A page reload may be required.');});
    dom.canvas.addEventListener('webglcontextrestored',()=>{dom.error.hidden=true;game.paused=false;});
    dom.settingsBtn.addEventListener('click',()=>{
      const next=!game.settingsOpen;
      if(next)game.pausedBeforeSettings=game.paused;
      game.settingsOpen=next;dom.settings.hidden=!next;
      dom.settingsBtn.setAttribute('aria-expanded',String(next));
      pause(next?true:game.pausedBeforeSettings);
    });
    dom.quality.addEventListener('change',applyQuality);
    dom.reduce.addEventListener('change',()=>{document.documentElement.dataset.motion=dom.reduce.checked?'reduced':'full';});
    dom.pause.addEventListener('click',()=>pause(!game.paused));
    dom.museum.addEventListener('click',()=>museum(true));
    dom.enter.addEventListener('click',()=>museum(false));
    dom.replay.addEventListener('click',newGame);
    dom.endMuseum.addEventListener('click',()=>{newGame();museum(true);});
    const resizeObserver=new ResizeObserver(()=>{world?.resize();applyQuality();});resizeObserver.observe(dom.canvas);
    if(params.get('museum')==='1')museum(true);
    requestAnimationFrame(render);
    // An inspectable integration/state harness for browser smoke tests.
    window.__WESTCAT_TEST__={
      read:()=>({x:game.player.x,y:game.player.y,chapter:game.chapter,score:game.score,deaths:game.deaths,
        checkpoint:game.checkpoint.id,chaseActive:game.chaseActive,finished:game.finished,portal:game.portal,paused:game.paused,
        visual:params.get('test')==='1'&&typeof world.metrics==='function'?world.metrics():null,revision:'e26-pocket-0.4.0-art-finish'}),
      restart:newGame,
      // Test-only; intentionally gated behind an explicit query flag and never persisted.
      teleport:(x,y)=>{if(params.get('test')==='1'){resetPlayer(game.player,x,y);game.chaseActive=false;game.owlX=x-15;world.resetView(game.player);}}
    };
    window.addEventListener('pagehide',()=>{disposed=true;input.dispose();resizeObserver.disconnect();world.dispose();audioCtx?.close?.();},{once:true});
  }catch(e){showError(e);console.error('WESTCAT BOOT FAILURE',e);}
}
boot();
