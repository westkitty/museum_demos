export function rotateXZ(x, z, angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    return { x: x * c + z * s, z: -x * s + z * c };
}
export function normal(p) {
    return { x: Math.sin(p.yaw), z: Math.cos(p.yaw) };
}
export function right(p) {
    return { x: Math.cos(p.yaw), z: -Math.sin(p.yaw) };
}
export function signedDepth(x, z, portal) {
    const n = normal(portal);
    return (x - portal.x) * n.x + (z - portal.z) * n.z;
}
export function lateralOffset(x, z, portal) {
    const r = right(portal);
    return (x - portal.x) * r.x + (z - portal.z) * r.z;
}
export function teleport(pose, from, to, clearance = 1.02, preview = false) {
    const deltaYaw = to.yaw + Math.PI - from.yaw;
    const lateral = -lateralOffset(pose.x, pose.z, from);
    const exitRight = right(to), exitNormal = normal(to);
    const depth = preview ? Math.max(0.6, signedDepth(pose.x, pose.z, from)) : clearance;
    const v = rotateXZ(pose.vx, pose.vz, deltaYaw);
    return {
        x: to.x + exitRight.x * lateral + exitNormal.x * depth,
        z: to.z + exitRight.z * lateral + exitNormal.z * depth,
        yaw: wrapYaw(pose.yaw + deltaYaw),
        vx: v.x, vz: v.z, deltaYaw
    };
}
export function wrapYaw(radians) {
    const circle = Math.PI * 2;
    return ((radians + Math.PI) % circle + circle) % circle - Math.PI;
}
export function approachingPortal(before, after, portal, halfWidth = 1.65, trigger = 0.84) {
    const d0 = signedDepth(before.x, before.z, portal);
    const d1 = signedDepth(after.x, after.z, portal);
    return d0 > trigger && d1 <= trigger &&
        Math.abs(lateralOffset(after.x, after.z, portal)) <= halfWidth;
}
