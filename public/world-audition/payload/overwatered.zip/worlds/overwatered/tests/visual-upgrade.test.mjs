import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read=(name)=>readFileSync(new URL(`../${name}`,import.meta.url),'utf8');

// Static contract checks only. These never claim to execute or benchmark Three.js/WebGL.
test('the visual system attaches to the original authored game rather than replacing the simulation',()=>{
  const main=read('src/main.ts'),art=read('src/art.ts'),visual=read('src/premium.ts');
  assert.match(main,/new GardenSimulation\(\)/);
  assert.match(main,/new GardenArt\(scene,visualQuality\)/);
  assert.match(main,/art\?\.onEvent\(event,game\.state\)/);
  assert.match(art,/new PremiumGardenDetails\(this\.root,this\.growth,quality\)/);
  assert.match(art,/group\.name=`surface-\$\{s\.id\}`/);
  assert.doesNotMatch(visual,/\bstate\.(?:grown|water|power|checkpoint|won|phase|summitVisited|summitLaunch)\s*=(?!=)/);
});

test('effects are pooled, low-detail graphics are available, and GPU resources are released',()=>{
  const main=read('src/main.ts'),art=read('src/art.ts'),visual=read('src/premium.ts');
  assert.match(main,/visualQuality==='lite'\?1\.1:1\.6/);
  assert.match(main,/renderer\.shadowMap\.enabled=visualQuality==='rich'/);
  assert.match(visual,/new THREE\.InstancedMesh/);
  assert.match(visual,/DynamicDrawUsage/);
  assert.match(visual,/this\.capacity=quality==='lite'\?72:192/);
  assert.match(visual,/this\.motes\.points\.visible=!reducedMotion/);
  assert.match(art,/const geometries=new Set<THREE\.BufferGeometry>/);
  assert.match(art,/textures\.forEach\(x=>x\.dispose\(\)\)/);
  assert.match(art,/cloudMesh\.instanceMatrix\.needsUpdate=true/);
  assert.match(art,/darkSeeds\.instanceMatrix\.needsUpdate=true/);
});

test('quest navigation, mobile controls, focus handling, and reduced-motion controls remain visible and operable',()=>{
  const html=read('index.html'),main=read('src/main.ts'),input=read('src/input.ts'),css=read('src/style.css');
  assert.match(html,/id="progress-rail"/);
  assert.match(html,/id="chapter-name"/);
  assert.equal([...html.matchAll(/data-chapter="\d"/g)].length,4);
  assert.match(main,/getVisualQuality:.*visualQuality/);
  assert.match(input,/target\.closest\('button,input,select,textarea,a,\[role="button"\]'\)/);
  assert.match(html,/id="reduced-motion-title"/);
  assert.match(html,/id="reduced-motion-pause"/);
  assert.match(css,/\.reduced-motion \*/);
  assert.match(css,/#touch-controls/);
});

test('the restored environment has authored botanical landmarks and an identifiable finale',()=>{
  const art=read('src/art.ts'),visual=read('src/premium.ts');
  for(const phrase of ['MOONBELL ARBOR','PRISM ORCHID','THE SUNFLOWER OF UNREASONABLE IMPORTANCE','THE HOLY WATERING CAN','THE SPARE CAN']){
    assert.ok(art.includes(phrase),`missing authored landmark or ending: ${phrase}`);
  }
  for(const component of ['horizon()','terrazzo()','conservatory()','signatureLandmarks()','flightRoute()','surfaceJewelry(parent,growth)']){
    assert.ok(visual.includes(component),`missing scenery phase ${component}`);
  }
  assert.match(visual,/this\.motes\.burst\(CAN\.x/);
});
