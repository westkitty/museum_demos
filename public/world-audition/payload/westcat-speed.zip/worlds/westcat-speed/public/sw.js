// Runtime-offline cache for same-origin distribution. No remote requests or telemetry.
const CACHE='westcat-e26-speed-limit-v1';
const ROOT=new URL('./',self.location.href);
self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    const html=await fetch(ROOT.href,{cache:'no-store'});
    if(!html.ok)throw new Error('Cannot cache E26 entry');
    const body=await html.clone().text();
    const resources=[ROOT.href];
    // Vite dist references its hashed local scripts and stylesheet in built index.html.
    for(const match of body.matchAll(/(?:src|href)=["']([^"']+\.(?:js|css))["']/g)){
      const url=new URL(match[1],ROOT.href);
      if(url.origin===self.location.origin)resources.push(url.href);
    }
    await cache.addAll([...new Set(resources)]);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const names=await caches.keys();
    await Promise.all(names.filter(n=>n!==CACHE&&n.startsWith('westcat-e26-')).map(n=>caches.delete(n)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin||!url.href.startsWith(ROOT.href))return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const hit=await cache.match(event.request);
    if(hit)return hit;
    if(event.request.mode==='navigate'&&url.pathname.endsWith('/index.html')){
      const appShell=await cache.match(ROOT.href);
      if(appShell)return appShell;
    }
    try{const response=await fetch(event.request);
      if(response.ok)cache.put(event.request,response.clone());return response;
    }catch{return hit||Response.error();}
  })());
});
