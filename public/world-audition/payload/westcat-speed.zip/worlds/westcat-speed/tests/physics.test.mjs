import test from 'node:test';
import assert from 'node:assert/strict';
import {heightAt,isGap,PROFILE,LOOPS,RAILS,CHECKPOINTS,COURSE_LENGTH,GAPS,SPRINGS} from '../.test-build/track.js';
import {createState,step,NO_INPUT,FIXED_DT,BASE_TOP_SPEED,BOOST_TOP_SPEED} from '../.test-build/physics.js';
const move={...NO_INPUT,right:true};
function run(s,input,seconds,events=[]){for(let i=0;i<Math.round(seconds/FIXED_DT);i++)step(s,input,FIXED_DT,e=>events.push(e));}
test('level profile is ordered, bounded and finite',()=>{
 assert.equal(PROFILE[0].x,0);assert.equal(PROFILE.at(-1).x,COURSE_LENGTH);
 for(let i=1;i<PROFILE.length;i++)assert.ok(PROFILE[i].x>PROFILE[i-1].x);
 for(let x=0;x<=COURSE_LENGTH;x+=1.5)assert.ok(Number.isFinite(heightAt(x)));
 assert.equal(isGap(GAPS[0].start+4),true);assert.equal(isGap(GAPS[0].end+8),false);
});
test('acceleration, braking, slopes and capped boost work',()=>{
 const s=createState();run(s,move,3);assert.ok(s.vx>5);const v=s.vx;
 run(s,{...NO_INPUT,left:true},.4);assert.ok(s.vx<v);
});
test('jump has upward impulse, gravity and landing',()=>{
 const s=createState();run(s,{...NO_INPUT,jumpPressed:true},FIXED_DT);
 assert.equal(s.mode,'air');assert.ok(s.vy>0);
 run(s,NO_INPUT,2);assert.equal(s.mode,'ground');
});
test('boost is finite, faster and depletes/recharges',()=>{
 const s=createState();run(s,{...move,boost:true},2);
 assert.ok(s.vx>BASE_TOP_SPEED);assert.ok(s.vx<=BOOST_TOP_SPEED);
 assert.ok(s.boostEnergy<100);let e=s.boostEnergy;run(s,move,2);assert.ok(s.boostEnergy>e);
});
test('both authored loops complete with safe exit position',()=>{
 for(let i=0;i<LOOPS.length;i++){
  const s=createState(),l=LOOPS[i];s.x=l.x-1;s.y=heightAt(s.x)+1.45;
  s.vx=19;let events=[];run(s,move,.06,events);
  assert.equal(s.mode,'loop');run(s,move,12,events);
  assert.notEqual(s.mode,'loop');assert.ok(s.x>l.x+2);
  assert.ok(events.some(e=>e.type==='loop'&&e.index===i));
 }
});
test('magnetic rails capture, traverse and launch with exit speed',()=>{
 for(let i=0;i<RAILS.length;i++){
  const s=createState();s.x=RAILS[i].start-1;s.y=heightAt(s.x)+1.45;s.vx=18;
  const events=[];run(s,move,.06,events);assert.equal(s.mode,'rail');
  run(s,move,26,events);assert.notEqual(s.mode,'rail');
  assert.ok(s.x>RAILS[i].end);assert.ok(events.some(e=>e.type==='rail'&&e.index===i));
 }
});
test('missed leap into a gap recovers at latest checkpoint with time penalty',()=>{
 const s=createState();s.checkpointIndex=1;s.x=GAPS[0].start+10;s.y=heightAt(s.x)-26;s.vx=1;s.mode='air';
 const events=[];step(s,NO_INPUT,FIXED_DT,e=>events.push(e));
 assert.equal(s.recoveries,1);assert.equal(s.mode,'ground');
 assert.ok(s.x>=CHECKPOINTS[1].x);assert.ok(s.elapsed>=3);
 assert.ok(events.some(e=>e.type==='recovery'));
});
test('checkpoint progression, finish detection and replay reset',()=>{
 const s=createState(),events=[];s.x=COURSE_LENGTH-4.1;s.y=heightAt(s.x)+1.45;s.vx=22;
 run(s,move,.03,events);assert.ok(s.finished);assert.ok(events.some(e=>e.type==='finish'));
 const next=createState();assert.equal(next.finished,false);assert.equal(next.checkpointIndex,-1);
});
test('springs supply enough movement to land across all authored gaps at baseline speed',()=>{
 for(let i=0;i<GAPS.length;i++){
  const spring=SPRINGS[i],s=createState(),events=[];
  s.x=spring.x-1;s.y=heightAt(s.x)+1.45;s.vx=13;
  run(s,move,5,events);
  assert.ok(s.x>GAPS[i].end+5,`spring ${i} did not cross`);
  assert.equal(s.recoveries,0,`spring ${i} caused a recovery`);
  assert.ok(events.some(e=>e.type==='spring'&&e.index===i));
 }
});
