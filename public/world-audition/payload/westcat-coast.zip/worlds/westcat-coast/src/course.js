/** Authoritative gameplay course. All gameplay coordinates are in world units.
 * The 2.5D renderer derives its objects from this data; rendering never owns collision.
 */
export const CHAPTERS = Object.freeze([
  { id: 'duncan', name: 'DOWNTOWN DUNCAN', subtitle: 'Chimneys & copper roofs', from: 0, to: 36.8, mood: 'morning' },
  { id: 'outskirts', name: 'FOREST OUTSKIRTS', subtitle: 'Where the lanterns begin', from: 36.8, to: 69, mood: 'canopy' },
  { id: 'cedar', name: 'CEDAR CLIMB', subtitle: 'The old trees touch the clouds', from: 69, to: 103, mood: 'highforest' },
  { id: 'sentinel', name: 'THE GREAT HORNED SENTINEL', subtitle: 'Run above the weather', from: 103, to: 152, mood: 'twilight' },
]);
const P = (x,w,top,kind='stone',thickness=0.8)=>({x,w,top,kind,thickness});
export const PLATFORMS = Object.freeze([
  // Downtown: forgiving gaps and optional roof shortcuts.
  P(0,8.2,1,'pavement',2), P(9.2,7.1,1,'pavement',2), P(17.35,8.8,1,'pavement',2),
  P(27.25,9.55,1.2,'pavement',2),
  P(5.6,3.0,3.0,'roof',0.55), P(13.2,4.5,3.45,'roof',0.55), P(21.7,3.1,3.5,'roof',0.55),
  P(30.1,3.8,3.35,'roof',0.55),
  // Forest: a broad staircase of living shelves.
  P(36.8,6.1,1.2,'moss',1.7), P(43.9,5.1,2.0,'moss',1.1), P(50.15,5.05,2.9,'moss',1.0),
  P(56.3,4.6,3.5,'moss',1.05), P(61.95,7.0,4.0,'moss',1.0),
  P(46.0,2.9,4.25,'branch',0.45), P(54.2,2.2,5.25,'branch',0.45),
  // Cedar: vertical rhythm, optional walls, broad landings.
  P(68.95,3.35,4.0,'cedar',1.25), P(73.1,3.35,5.3,'cedar',1.0),
  P(77.3,3.45,6.8,'cedar',1.0), P(81.45,4.2,8.0,'cedar',1.05),
  P(86.8,4.65,9.25,'cedar',1.05), P(92.55,6.2,10.15,'cedar',1.05),
  P(99.15,5.2,10.15,'cedar',1.0),
  // A wall-jump optional route; side collisions are real, but never mandatory.
  P(80.75,0.62,9.6,'trunk',3.8), P(89.95,0.62,11.0,'trunk',2.7),
  P(83.1,2.5,10.8,'branch',0.45),
  // Above the clouds: a spectacular broken but forgiving timber viaduct.
  P(104.35,11.0,10.15,'trestle',0.7), P(116.7,7.2,10.7,'trestle',0.7),
  P(125.05,6.7,11.25,'trestle',0.7), P(133.2,6.9,11.85,'trestle',0.7),
  P(141.1,11.25,12.3,'trestle',0.75),
]);
export const CHECKPOINTS = Object.freeze([
  { x: 2.0, y: 1.0, id: 'duncan' },
  { x: 38.1, y: 1.2, id: 'forest' },
  { x: 63.0, y: 4.0, id: 'cedar-approach' },
  { x: 94.0, y: 10.15, id: 'canopy' },
  { x: 107.4, y: 10.15, id: 'sentinel-bridge' },
  { x: 126.7, y: 11.25, id: 'last-light' },
]);
export const FINISH_X = 148.65;
export const WORLD_END = 152.3;
export const SPAWN = Object.freeze({ x: 2.1, y: 1.0 });
export function chapterFor(x) { return CHAPTERS.findIndex(c=>x < c.to) === -1 ? 3 : CHAPTERS.findIndex(c=>x < c.to); }
export function surfaceUnder(x, y=100) {
  return PLATFORMS.filter(p=>x>=p.x && x<=p.x+p.w && p.top <= y).sort((a,b)=>b.top-a.top)[0] || null;
}
export function checkpointFor(x) { return CHECKPOINTS.reduce((best,p)=>x>=p.x? p:best,CHECKPOINTS[0]); }
export function validateCourse() {
  const errors=[];
  if(CHAPTERS.length!==4)errors.push('Expected four chapters');
  for(let i=1;i<CHAPTERS.length;i++) if(CHAPTERS[i].from!==CHAPTERS[i-1].to) errors.push('Broken chapter boundary');
  for(const p of PLATFORMS)if(!(p.w>0&&p.thickness>0&&Number.isFinite(p.x)&&Number.isFinite(p.top)))errors.push('Invalid platform');
  for(const cp of CHECKPOINTS){const p=surfaceUnder(cp.x, cp.y+0.02);if(!p || Math.abs(p.top-cp.y)>0.02)errors.push(`Checkpoint ${cp.id} lacks supporting platform`);}
  if(!surfaceUnder(FINISH_X,13))errors.push('Finish point has no platform');
  return errors;
}
