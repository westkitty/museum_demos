import * as THREE from 'three';
import { TERRAIN_ZONES } from './state.js';
export const TAU = Math.PI * 2;
export const clamp = THREE.MathUtils.clamp;
export const lerp = THREE.MathUtils.lerp;
export const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
export function mulberry32(seed) { return () => { let t = seed += 0x6d2b79f5; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
export function noise2(x, z) {
    return Math.sin(x * 0.137 + Math.cos(z * 0.05) * 2.5) * Math.cos(z * 0.169 - x * 0.013) * 0.5 +
        Math.sin(x * 0.31 + z * 0.19) * 0.22 + Math.cos(x * 0.58 - z * 0.44) * 0.09;
}
export const riverX = (z) => -17 + Math.sin(z * 0.043 + 0.4) * 10 + Math.cos(z * 0.087) * 4;
export function heightAt(x, z, state) {
    const north = smooth(2, 85, -z);
    const mountains = north * (14 + (Math.sin(x * 0.072 + 0.8) ** 2) * 32 + (Math.sin(x * 0.21 + z * 0.042) ** 2) * 17);
    const hills = 5 + noise2(x, z) * 7.5 + Math.sin(x * 0.024 + z * 0.018) * 2.5;
    const coast = smooth(45, 100, z);
    let h = (hills + mountains) * (1 - coast) + (-1.5 + noise2(x, z) * 0.6) * coast;
    const dx = x - riverX(z);
    h -= Math.exp(-dx * dx / (z < -20 ? 110 : 75)) * (7 + north * 5);
    for (let i = 0; i < 3; i++) {
        const zone = TERRAIN_ZONES[i];
        const d2 = ((x - zone.x) ** 2 + (z - zone.z) ** 2) / (zone.radius ** 2);
        h += state.terrain[i] * Math.exp(-d2 * 2.3);
    }
    return h;
}
export function terrainNormal(x, z, s) {
    const d = 0.4;
    const n = new THREE.Vector3(heightAt(x - d, z, s) - heightAt(x + d, z, s), 2 * d, heightAt(x, z - d, s) - heightAt(x, z + d, s));
    return n.normalize();
}
export function makeTerrain(state, width = 240, segments = 112) {
    const g = new THREE.PlaneGeometry(width, width, segments, segments);
    g.rotateX(-Math.PI / 2);
    updateTerrain(g, state);
    return g;
}
export function updateTerrain(g, s) {
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++)
        p.setY(i, heightAt(p.getX(i), p.getZ(i), s));
    p.needsUpdate = true;
    g.computeVertexNormals();
    g.computeBoundingSphere();
}
export function material(color, rough = 0.75, metal = 0) { return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal }); }
export function sphere(r, col, segments = 16) { return new THREE.Mesh(new THREE.SphereGeometry(r, segments, Math.max(8, segments / 2)), material(col)); }
export function cylinder(r1, r2, h, col, n = 12) { return new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, n), material(col)); }
export function tube(points, r, color, seg = 28) {
    return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), seg, r, 6, false), material(color, 0.55, 0.4));
}
export function instanced(geo, mat, places) {
    const m = new THREE.InstancedMesh(geo, mat, places.length);
    const obj = new THREE.Object3D();
    places.forEach((p, i) => { obj.position.set(p.x, p.y, p.z); obj.scale.setScalar(p.scale ?? 1); obj.rotation.y = p.ry ?? 0; obj.updateMatrix(); m.setMatrixAt(i, obj.matrix); });
    m.instanceMatrix.needsUpdate = true;
    m.computeBoundingSphere();
    return m;
}
export function disposeScene(scene) {
    const geometries = new Set();
    const materials = new Set();
    const textures = new Set();
    scene.traverse(o => {
        const m = o;
        if (m.geometry)
            geometries.add(m.geometry);
        if (m.material)
            for (const mat of (Array.isArray(m.material) ? m.material : [m.material]))
                materials.add(mat);
    });
    materials.forEach(m => {
        for (const v of Object.values(m))
            if (v instanceof THREE.Texture && !v.userData.shared)
                textures.add(v);
    });
    geometries.forEach(g => g.dispose());
    materials.forEach(m => m.dispose());
    textures.forEach(t => t.dispose());
    scene.clear();
}
