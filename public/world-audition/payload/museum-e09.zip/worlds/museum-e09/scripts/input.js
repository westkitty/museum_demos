/** Input ownership: a single instance, an AbortController and no global handlers left after disposal. */
export class Input {
    keys = new Set();
    pointerButtons = new Set();
    jumpQueued = false;
    abort = new AbortController();
    targets = [];
    touchMode;
    constructor(root) {
        this.touchMode = window.matchMedia('(pointer: coarse)').matches;
        const signal = this.abort.signal;
        const cancelMovement = () => { this.keys.clear(); this.pointerButtons.clear(); this.jumpQueued = false; };
        window.addEventListener('keydown', e => {
            if (e.repeat && e.code === 'Space')
                return;
            if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target?.tagName ?? ''))
                return;
            if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code))
                e.preventDefault();
            this.keys.add(e.code);
            if (e.code === 'Space')
                this.jumpQueued = true;
        }, { signal });
        window.addEventListener('keyup', e => this.keys.delete(e.code), { signal });
        window.addEventListener('blur', cancelMovement, { signal });
        document.addEventListener('visibilitychange', () => { if (document.hidden)
            cancelMovement(); }, { signal });
        for (const el of Array.from(root.querySelectorAll('[data-action]'))) {
            const action = el.dataset.action ?? '';
            this.targets.push(el);
            el.addEventListener('pointerdown', e => {
                e.preventDefault();
                el.setPointerCapture(e.pointerId);
                this.pointerButtons.add(action);
                if (action === 'jump')
                    this.jumpQueued = true;
                el.classList.add('held');
            }, { signal });
            const release = (e) => {
                this.pointerButtons.delete(action);
                el.classList.remove('held');
                if (el.hasPointerCapture(e.pointerId))
                    el.releasePointerCapture(e.pointerId);
            };
            el.addEventListener('pointerup', release, { signal });
            el.addEventListener('pointercancel', release, { signal });
            el.addEventListener('lostpointercapture', () => { this.pointerButtons.delete(action); el.classList.remove('held'); }, { signal });
        }
    }
    get movement() {
        const has = (name, ...codes) => this.pointerButtons.has(name) || codes.some(code => this.keys.has(code));
        const x = Number(has('right', 'KeyD', 'ArrowRight')) - Number(has('left', 'KeyA', 'ArrowLeft'));
        const z = Number(has('back', 'KeyS', 'ArrowDown')) - Number(has('forward', 'KeyW', 'ArrowUp'));
        const magnitude = Math.hypot(x, z) || 1;
        return { x: x / magnitude, z: z / magnitude, run: has('run', 'ShiftLeft', 'ShiftRight') };
    }
    takeJump() { const value = this.jumpQueued; this.jumpQueued = false; return value; }
    clear() { this.keys.clear(); this.pointerButtons.clear(); this.jumpQueued = false; this.targets.forEach(el => el.classList.remove('held')); }
    dispose() { this.clear(); this.abort.abort(); this.targets.length = 0; }
}
