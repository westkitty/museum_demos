/** Authored, conservative walking solids. Flight and orbit remain unrestricted. */
export function walkSolids(world) {
    if (world === 0) {
        const disks = [{ x: 0, z: 0, r: 9.5 }];
        for (let i = 0; i < 22; i++) {
            const a = i / 22 * Math.PI * 2;
            disks.push({ x: Math.cos(a) * 64, z: Math.sin(a) * 64, r: 3.6 });
        }
        return disks;
    }
    if (world === 1) {
        const disks = [];
        for (let j = 0; j < 14; j++) {
            const a = j / 14 * Math.PI * 2 * .9, dist = 5 + Math.floor(j / 5) * 5.6;
            disks.push({ x: -29 + Math.sin(a + j * .12) * dist, z: 28 + Math.cos(a + j * .12) * dist, r: 3.7 });
        }
        return disks;
    }
    return [];
}
export function resolveWalk(world, from, to, margin = .8) {
    let x = to.x, z = to.z;
    for (const c of walkSolids(world)) {
        const dx = x - c.x, dz = z - c.z, dist = Math.hypot(dx, dz), limit = c.r + margin;
        if (dist >= limit)
            continue;
        // Reject only the movement toward the solid; slide along a tangent when possible.
        const fx = from.x - c.x, fz = from.z - c.z, fr = Math.hypot(fx, fz);
        const nx = fr > .001 ? fx / fr : dist > .001 ? dx / dist : 1;
        const nz = fr > .001 ? fz / fr : dist > .001 ? dz / dist : 0;
        if (fr >= limit) {
            const tangentX = -nz, tangentZ = nx;
            const projected = (to.x - from.x) * tangentX + (to.z - from.z) * tangentZ;
            x = from.x + tangentX * projected;
            z = from.z + tangentZ * projected;
        }
        const rx = x - c.x, rz = z - c.z, r = Math.hypot(rx, rz);
        if (r < limit) {
            const ux = r > .001 ? rx / r : nx, uz = r > .001 ? rz / r : nz;
            x = c.x + ux * limit;
            z = c.z + uz * limit;
        }
    }
    return { x, z };
}
