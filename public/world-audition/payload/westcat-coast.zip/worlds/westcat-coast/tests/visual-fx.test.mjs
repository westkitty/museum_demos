import test from 'node:test';
import assert from 'node:assert/strict';
import {createFxPool,emitFx,stepFx,activeFxCount,EFFECT_BUDGET,fxScale} from '../src/fx.js';

test('visual FX has strict high and battery-tier capacity limits',()=>{
  const high=createFxPool();const low=createFxPool();
  for(let i=0;i<40;i++){emitFx(high,'finish',i,1,'high');emitFx(low,'finish',i,1,'low');}
  assert.equal(activeFxCount(high),EFFECT_BUDGET.high);
  assert.ok(activeFxCount(low)<=EFFECT_BUDGET.low);
  for(const p of low.items.slice(EFFECT_BUDGET.low))assert.equal(p.life,0);
});
test('visual FX cannot change gameplay state and drains without allocation',()=>{
  const pool=createFxPool();const ref=pool.items;const player={x:3,y:1,vx:5,vy:10};
  assert.equal(emitFx(pool,'doublejump',player.x,player.y),15);
  assert.ok(activeFxCount(pool)>0);
  stepFx(pool,1.5);
  assert.equal(activeFxCount(pool),0);
  assert.strictEqual(pool.items,ref);
  assert.deepEqual(player,{x:3,y:1,vx:5,vy:10});
  assert.ok(pool.items.every(p=>fxScale(p)===0));
});
test('unknown FX type is safely ignored',()=>{
  const pool=createFxPool();assert.equal(emitFx(pool,'weather-system',4,8),0);
  assert.equal(activeFxCount(pool),0);
});
test('FX emission is deterministic for an identical event sequence',()=>{
  const a=createFxPool(),b=createFxPool();
  for(const name of ['jump','land','checkpoint','collect','chase']){emitFx(a,name,7,4);emitFx(b,name,7,4);}
  stepFx(a,1/60);stepFx(b,1/60);
  assert.deepEqual(a,b);
});
