/** Standalone entrypoint only. The opt-in museum adapter imports game.ts instead. */
import { mountGodGame } from './game.js';
const root = document.getElementById('game-root');
if (root)
    mountGodGame(root);
