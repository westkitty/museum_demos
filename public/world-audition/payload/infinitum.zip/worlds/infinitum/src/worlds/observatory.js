import { causalStage, finaleReady, heartIrrigation, gravityAligned } from '../core/simulation.js';
import * as THREE from 'three';
import { constellationPower, stormIntensity } from '../core/state.js';
import { TAU, mulberry32, sphere, tube, disposeScene } from '../core/math.js';
import { PortalDrop, EnvironmentRig, makeDust, addArch, labelObject, waterMaterial } from './shared.js';
import { contactShadows, grainTexture, reliefTexture, softGlow, stoneSurface } from './art.js';
import { CinematicVistas } from './cinematic-vistas.js';
import { authoredSurface, authoredDecal } from './asset-materials.js';
export class Observatory {
    id = 0;
    scene = new THREE.Scene();
    spawn = { position: new THREE.Vector3(0, 12.5, 31), target: new THREE.Vector3(0, 10.8, 0) };
    portal = new THREE.Vector3(0, 12.6, 0);
    inspectionObjects = [];
    rig;
    vistas;
    mainDrop;
    astrolabes = [];
    echoLines = new THREE.Group();
    lastEchoPower = -1;
    dust;
    condensation;
    glassSupport;
    lanterns = [];
    basinWater;
    waterRings = new THREE.Group();
    travelingGlow;
    concordance = new THREE.Group();
    causalLenses = [];
    causalRays = [];
    dialMaterial;
    concordanceLight = new THREE.PointLight(0xa8e7d3, 0, 48);
    constructor(s, texture) {
        this.rig = new EnvironmentRig(this.scene, 0, s.quality);
        this.vistas = new CinematicVistas(this.scene, 0, s);
        this.rig.haze.color.set(0x101b27);
        this.rig.haze.density = .008; // Keep the shared interpolating weather fog authoritative.
        const floorMat = new THREE.MeshPhysicalMaterial({ color: 0x293c46, metalness: .28, roughness: .49, clearcoat: .62, clearcoatRoughness: .24 });
        const floorGrain = grainTexture(742);
        floorGrain.repeat.set(12, 12);
        floorMat.map = floorGrain;
        floorMat.normalMap = reliefTexture(floorGrain);
        floorMat.normalScale.set(.25, .25);
        // Texture stays local to the Observatory and is not shared with miniature worlds.
        const finishFloor = authoredSurface('slate', { tint: 0x8b9b9c, repeat: 12, roughness: .63, metalness: .18, quality: s.quality });
        const floor = new THREE.Mesh(new THREE.CylinderGeometry(75, 75, 1, 120), finishFloor);
        floor.position.y = -.65;
        floor.receiveShadow = true;
        floor.userData.feature = 'observatory-slate-art';
        this.scene.add(floor);
        const innerDisk = new THREE.Mesh(new THREE.CylinderGeometry(16, 16, .16, 72), floorMat);
        innerDisk.position.y = -.08;
        this.scene.add(innerDisk);
        // Counter-rotating radial stone courses: restrained texture in the low camera angles.
        const pavingGeometry = new THREE.BoxGeometry(1.3, .075, 2.15);
        const paving = authoredSurface('slate', { tint: 0xd9e5e6, repeat: 5, roughness: .85, quality: s.quality });
        const steps = [];
        const stoneRng = mulberry32(999);
        for (let tier = 0; tier < 12; tier++) {
            const r = 13 + tier * 4.25, count = 24 + tier * 4;
            for (let i = 0; i < count; i++) {
                const angle = (i + (tier % 2) * .5) / count * TAU;
                steps.push({ x: Math.cos(angle) * r, y: -.087, z: Math.sin(angle) * r, a: angle, s: .75 + tier * .035, shade: stoneRng() });
            }
        }
        const pavers = new THREE.InstancedMesh(pavingGeometry, paving, steps.length);
        const paverDummy = new THREE.Object3D(), paverColor = new THREE.Color();
        steps.forEach((p, i) => {
            paverDummy.position.set(p.x, p.y, p.z);
            paverDummy.rotation.set(0, -p.a, 0);
            paverDummy.scale.set(.8, p.s, 1.15 + p.s * .4);
            paverDummy.updateMatrix();
            pavers.setMatrixAt(i, paverDummy.matrix);
            paverColor.setHSL(.54, .055, .40 + p.shade * .08);
            pavers.setColorAt(i, paverColor);
        });
        pavers.instanceMatrix.needsUpdate = true;
        pavers.instanceColor.needsUpdate = true;
        pavers.receiveShadow = true;
        this.scene.add(pavers);
        // Original engraved brass dial, physically laid over the plaza paving.
        this.dialMaterial = authoredDecal('observatory', .52);
        const dial = new THREE.Mesh(new THREE.PlaneGeometry(113, 113), this.dialMaterial);
        dial.rotation.x = -Math.PI / 2;
        dial.position.y = -.015;
        dial.renderOrder = 2;
        dial.userData.feature = 'observatory-dial-art';
        this.scene.add(dial);
        for (let j = 0; j < 9; j++) {
            const r = 8 + j * 6.7;
            const ring = new THREE.Mesh(new THREE.TorusGeometry(r, .06, 5, 144), new THREE.MeshStandardMaterial({ color: j % 2 ? 0x5c675d : 0x887756, roughness: .35, metalness: .85 }));
            ring.rotation.x = Math.PI / 2;
            ring.position.y = -.045;
            this.scene.add(ring);
        }
        const engravingMat = new THREE.MeshBasicMaterial({ color: 0x72766c, transparent: true, opacity: .32 });
        for (let j = 0; j < 40; j++) {
            const a = j / 40 * TAU;
            const line = new THREE.Mesh(new THREE.BoxGeometry(.04, .013, 56), engravingMat);
            line.position.set(Math.sin(a) * 31, -.025, Math.cos(a) * 31);
            line.rotation.y = a;
            this.scene.add(line);
        }
        const columns = 22;
        const columnMaterial = authoredSurface('slate', { tint: 0xdfebea, repeat: 2.4, roughness: .79, quality: s.quality }), darkStone = stoneSurface(0x293940, 101, 3.1, .91), trim = authoredSurface('bronze', { tint: 0xf7ede1, repeat: 3, roughness: .38, metalness: .72, quality: s.quality });
        const flute = new THREE.CylinderGeometry(1.6, 1.9, 37, 72, 8);
        const fPos = flute.getAttribute('position');
        for (let i = 0; i < fPos.count; i++) {
            const x = fPos.getX(i), z = fPos.getZ(i), angle = Math.atan2(z, x), m = 1 + .042 * Math.cos(angle * 18);
            fPos.setXYZ(i, x * m, fPos.getY(i), z * m);
        }
        flute.computeVertexNormals();
        for (let j = 0; j < columns; j++) {
            const a = j / columns * TAU, r = 64;
            const x = Math.cos(a) * r, z = Math.sin(a) * r;
            const group = new THREE.Group();
            group.position.set(x, 0, z);
            const base = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 3.35, 3.5, 12), darkStone);
            base.position.y = 1.6;
            const shaft = new THREE.Mesh(flute, columnMaterial);
            shaft.position.y = 20.5;
            shaft.castShadow = true;
            const cap = new THREE.Mesh(new THREE.CylinderGeometry(3.45, 2.35, 3.1, 12), columnMaterial);
            cap.position.y = 40.5;
            group.add(base, shaft, cap);
            for (let h = 0; h < 4; h++) {
                const ring = new THREE.Mesh(new THREE.TorusGeometry(2.08, .14, 6, 24), trim);
                ring.rotation.x = Math.PI / 2;
                ring.position.y = 3.6 + h * 11;
                group.add(ring);
            }
            this.scene.add(group);
            const next = (j + 1) / columns * TAU;
            const center = new THREE.Vector3((x + Math.cos(next) * r) / 2, 36, (z + Math.sin(next) * r) / 2);
            const chord = new THREE.Mesh(new THREE.BoxGeometry(2.2, 7.6, 19.1), darkStone);
            chord.position.copy(center);
            chord.lookAt(0, center.y, 0);
            this.scene.add(chord);
        }
        this.scene.add(contactShadows(Array.from({ length: columns }, (_, j) => {
            const a = j / columns * TAU;
            return { x: Math.cos(a) * 64, y: -.015, z: Math.sin(a) * 64, r: 4.4 };
        })));
        const dome = new THREE.Mesh(new THREE.SphereGeometry(79, 72, 36, 0, TAU, 0, Math.PI * .5), new THREE.MeshStandardMaterial({ color: 0x15262f, metalness: .37, roughness: .82, side: THREE.BackSide }));
        dome.position.y = 37;
        this.scene.add(dome);
        for (let i = 0; i < 9; i++) {
            const band = new THREE.Mesh(new THREE.TorusGeometry(78 * Math.sin(.23 + i * .13), .22, 6, 180), trim);
            band.rotation.x = Math.PI / 2;
            band.position.y = 37 + 78 * Math.cos(.23 + i * .13);
            this.scene.add(band);
        }
        for (let j = 0; j < 16; j++) {
            const a = j / 16 * TAU;
            const y = 45 + Math.sin(j * 3.1) * 18;
            const points = [new THREE.Vector3(Math.cos(a) * 62, 47, Math.sin(a) * 62), new THREE.Vector3(Math.cos(a + .24) * 47, y + 12, Math.sin(a + .24) * 47), new THREE.Vector3(Math.cos(a + .35) * 27, 87, Math.sin(a + .35) * 27)];
            this.scene.add(tube(points, .09, 0x998864, 24));
        }
        // Monumental basin, gravity-mounted droplet and counterweighted suspension.
        const basin = new THREE.Mesh(new THREE.CylinderGeometry(7.9, 9.1, 2.7, 48), darkStone);
        basin.position.y = 1.25;
        basin.receiveShadow = true;
        this.scene.add(basin);
        const pool = new THREE.Mesh(new THREE.CylinderGeometry(6.6, 6.6, .08, 64), new THREE.MeshPhysicalMaterial({ color: 0x113847, metalness: .64, roughness: .11, clearcoat: 1 }));
        pool.position.y = 2.64;
        this.scene.add(pool);
        this.basinWater = new THREE.Mesh(new THREE.CircleGeometry(6.48, 96), waterMaterial(0x4e8990, .76));
        this.basinWater.rotation.x = -Math.PI / 2;
        this.basinWater.position.y = 2.696;
        this.basinWater.renderOrder = 1;
        this.scene.add(this.basinWater);
        for (let i = 0; i < 5; i++) {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(1.3 + i * .95, .021, 4, 90), new THREE.MeshBasicMaterial({ color: 0xb2e5d9, transparent: true, opacity: .08, depthWrite: false }));
            ring.rotation.x = Math.PI / 2;
            ring.position.y = 2.724;
            this.waterRings.add(ring);
        }
        this.scene.add(this.waterRings);
        for (const r of [7.6, 8.8, 10.4]) {
            const t = new THREE.Mesh(new THREE.TorusGeometry(r, .24, 9, 86), trim);
            t.rotation.x = Math.PI / 2;
            t.position.y = r === 10.4 ? .1 : 2.62;
            this.scene.add(t);
        }
        this.mainDrop = new PortalDrop(texture, 4.2, 'THE FIRST THRESHOLD · Enter the living world');
        this.mainDrop.group.position.copy(this.portal);
        this.scene.add(this.mainDrop.group);
        this.mainDrop.group.userData.clueId = 'outer-drop';
        this.inspectionObjects.push(this.mainDrop.group, this.mainDrop.shell, this.mainDrop.glass);
        this.glassSupport = new THREE.Group();
        this.scene.add(this.glassSupport);
        // A single moving caustic beneath the glass anchors its scale without bloom.
        this.travelingGlow = softGlow(0x66beb6, 16, .38);
        this.travelingGlow.rotation.x = -Math.PI / 2;
        this.travelingGlow.position.set(0, 2.755, 0);
        this.scene.add(this.travelingGlow);
        for (let i = 0; i < 4; i++) {
            const a = i * Math.PI * .5;
            const anchor = new THREE.Vector3(Math.cos(a) * 7.6, 37, Math.sin(a) * 7.6);
            const start = new THREE.Vector3(Math.cos(a) * 4.3, 18, Math.sin(a) * 4.3);
            this.glassSupport.add(tube([anchor, new THREE.Vector3(Math.cos(a) * 5.9, 26, Math.sin(a) * 5.9), start], .13, 0x988365, 22));
        }
        for (let i = 0; i < 7; i++) {
            const instrument = new THREE.Group();
            const a = (i / 7) * TAU + .31, r = 37 + (i % 2) * 8;
            instrument.position.set(Math.sin(a) * r, 5, Math.cos(a) * r);
            const orb = sphere(.65, 0xc9ad7e, 16);
            orb.material = trim;
            instrument.add(orb);
            for (let j = 0; j < 4; j++) {
                const t = new THREE.Mesh(new THREE.TorusGeometry(3.8 + j * .51, .08 + j * .016, 6, 86), trim);
                t.rotation.set(j * .71, j * .35, j * .47);
                instrument.add(t);
            }
            const stand = new THREE.Mesh(new THREE.CylinderGeometry(.45, .68, 7.7, 8), darkStone);
            stand.position.y = -4.2;
            instrument.add(stand);
            this.scene.add(instrument);
            this.astrolabes.push(instrument);
            // Instrument lenses, graduation marks and a bright but bounded focal dot.
            const disk = new THREE.Mesh(new THREE.CircleGeometry(2.1, 40), new THREE.MeshPhysicalMaterial({ color: 0x8db8b6, metalness: .25, roughness: .12, transmission: .34, transparent: true, opacity: .35, side: THREE.DoubleSide, depthWrite: false }));
            disk.rotation.x = Math.PI * .5;
            instrument.add(disk);
            for (let k = 0; k < 12; k++) {
                const alpha = k / 12 * TAU;
                const tick = new THREE.Mesh(new THREE.BoxGeometry(.045, .06, k % 3 === 0 ? .65 : .32), trim);
                tick.position.set(Math.cos(alpha) * 4.6, 0, Math.sin(alpha) * 4.6);
                tick.rotation.y = -alpha;
                instrument.add(tick);
            }
            labelObject(instrument, 'An ancient astronomical instrument');
            instrument.userData.clueId = 'outer-instrument';
            this.inspectionObjects.push(instrument);
        }
        const portalArches = 8;
        for (let j = 0; j < portalArches; j++) {
            const a = (j + .5) / portalArches * TAU;
            const origin = new THREE.Vector3(Math.sin(a) * 71, .5, Math.cos(a) * 71);
            const arch = new THREE.Group();
            arch.position.copy(origin);
            arch.rotation.y = a;
            addArch(arch, new THREE.Vector3(0, 0, 0), 6, 26, 0x39454b, 18);
            this.scene.add(arch);
        }
        // Long light funnels have nearly imperceptible luminance; no bloom dependency.
        for (let j = 0; j < 8; j++) {
            const a = j / 8 * TAU + .2;
            const cone = new THREE.Mesh(new THREE.ConeGeometry(12, 69, 32, 1, true), new THREE.MeshBasicMaterial({ color: 0x98afaf, transparent: true, opacity: .016, depthWrite: false, side: THREE.DoubleSide }));
            cone.position.set(Math.sin(a) * 42, 52, Math.cos(a) * 42);
            cone.rotation.z = Math.sin(a) * .33;
            cone.rotation.x = Math.cos(a) * .33;
            this.scene.add(cone);
        }
        // Architectural lanterns are volumetric cues, not a blanket light boost.
        const lanternGeo = new THREE.OctahedronGeometry(.84, 0), lanternGlass = new THREE.MeshStandardMaterial({ color: 0xe2ddaa, emissive: 0xa48552, emissiveIntensity: 1.2, roughness: .24 });
        const lanterns = new THREE.InstancedMesh(lanternGeo, lanternGlass, 12), dummy = new THREE.Object3D();
        for (let i = 0; i < 12; i++) {
            const a = (i + .5) / 12 * TAU;
            dummy.position.set(Math.cos(a) * 56, 19.5, Math.sin(a) * 56);
            dummy.scale.set(1, 1.6, 1);
            dummy.updateMatrix();
            lanterns.setMatrixAt(i, dummy.matrix);
            if (i % 3 === 0) {
                const l = new THREE.PointLight(0xd8a778, 2.9, 44, 2);
                l.position.copy(dummy.position);
                this.scene.add(l);
                this.lanterns.push(l);
            }
        }
        lanterns.instanceMatrix.needsUpdate = true;
        this.scene.add(lanterns);
        this.dust = makeDust(this.scene, s.quality === 'low' ? 450 : 850, new THREE.Vector3(125, 52, 125), 223, 0xb4cabf);
        this.scene.add(this.echoLines);
        this.rebuildEcho(s);
        this.concordance.position.set(0, 12.6, 0);
        for (let j = 0; j < 3; j++) {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(5.5 + j * 1.5, .05 + j * .015, 6, 96), new THREE.MeshBasicMaterial({ color: j === 0 ? 0xc5d6c6 : j === 1 ? 0x75c4bb : 0xada6ca, transparent: true, opacity: .08, depthWrite: false }));
            ring.rotation.set(j * .6, .18 * j, .37 + j * .6);
            this.concordance.add(ring);
        }
        this.scene.add(this.concordance);
        this.concordanceLight.position.set(0, 12.6, 0);
        this.scene.add(this.concordanceLight);
        // A world-space, inspectable causal orrery; each illuminated station is backed
        // by an actual condition in the shared simulation, never a decorative timer.
        const stationNames = ['THE WATERSHED', 'THE CONSTELLATIONS', 'THE GRAVITY CIRCUIT'];
        for (let i = 0; i < 3; i++) {
            const angle = i * TAU / 3 + .48, rad = 15.5;
            const p = new THREE.Vector3(Math.cos(angle) * rad, 5.3, Math.sin(angle) * rad);
            const lens = new THREE.Mesh(new THREE.TorusGeometry(2.0, .18, 8, 50), new THREE.MeshStandardMaterial({ color: 0x4c7778, metalness: .68, roughness: .3, emissive: 0x72b9b4, emissiveIntensity: .12 }));
            lens.position.copy(p);
            lens.rotation.y = angle + .5;
            lens.rotation.x = .33;
            labelObject(lens, stationNames[i]);
            lens.userData.feature = 'causal-lens';
            this.scene.add(lens);
            this.inspectionObjects.push(lens);
            this.causalLenses.push(lens);
            const ray = new THREE.Line(new THREE.BufferGeometry().setFromPoints([p, new THREE.Vector3(0, 12.6, 0)]), new THREE.LineBasicMaterial({ color: 0xa9e1c8, transparent: true, opacity: 0, depthWrite: false }));
            this.scene.add(ray);
            this.causalRays.push(ray);
        }
        const beadGeo = new THREE.SphereGeometry(.08, 6, 4), beadMat = new THREE.MeshPhysicalMaterial({ color: 0xd0f4fa, transparent: true, opacity: .38, roughness: .12, transmission: .25 });
        const rng = mulberry32(711), matrix = new THREE.Matrix4(), obj = new THREE.Object3D();
        this.condensation = new THREE.InstancedMesh(beadGeo, beadMat, 70);
        for (let j = 0; j < 70; j++) {
            const a = rng() * TAU, theta = rng() * Math.PI;
            obj.position.set(this.portal.x + Math.cos(a) * Math.sin(theta) * 4.2, this.portal.y + Math.cos(theta) * 5.2, this.portal.z + Math.sin(a) * Math.sin(theta) * 4.2);
            obj.scale.setScalar(.25 + rng() * .9);
            obj.updateMatrix();
            matrix.copy(obj.matrix);
            this.condensation.setMatrixAt(j, matrix);
        }
        this.condensation.instanceMatrix.needsUpdate = true;
        this.condensation.count = 0;
        this.scene.add(this.condensation);
    }
    rebuildEcho(s) {
        const power = constellationPower(s);
        if (power === this.lastEchoPower)
            return;
        this.lastEchoPower = power;
        while (this.echoLines.children.length) {
            const o = this.echoLines.children[0];
            this.echoLines.remove(o);
            const m = o;
            m.geometry?.dispose();
            if (m.material)
                for (const mat of Array.isArray(m.material) ? m.material : [m.material])
                    mat.dispose();
        }
        for (let j = 0; j < power; j++) {
            const a = j * 1.36 + 1.3;
            const p = [new THREE.Vector3(Math.cos(a) * 21, 104, Math.sin(a) * 21), new THREE.Vector3(Math.cos(a + .6) * 37, 93, Math.sin(a + .6) * 37), new THREE.Vector3(Math.cos(a + 1.2) * 52, 76, Math.sin(a + 1.2) * 52)];
            const g = new THREE.BufferGeometry().setFromPoints(p);
            this.echoLines.add(new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0xb8ddec, transparent: true, opacity: .48 })));
            for (const v of p) {
                const star = sphere(.41, 0x87f2e3, 8);
                star.material.emissive = new THREE.Color(0x539db3);
                star.position.copy(v);
                this.echoLines.add(star);
            }
        }
    }
    sync(s) {
        this.dialMaterial.opacity = .50 + causalStage(s) * .07;
        this.rebuildEcho(s);
        this.condensation.count = Math.floor(stormIntensity(s.weather) * 70);
        const stage = causalStage(s);
        this.concordance.children.forEach((m, i) => { m.visible = stage > i; });
        const conditions = [heartIrrigation(s) > .48, constellationPower(s) > 0, gravityAligned(s) || s.ruins.every(r => r.snapped)];
        this.causalLenses.forEach((lens, i) => { const m = lens.material; m.emissiveIntensity = conditions[i] ? 2.7 : .14; });
        this.causalRays.forEach((line, i) => { line.material.opacity = conditions[i] ? .63 : .03; });
    }
    update(dt, elapsed, s, camera) {
        this.rig.update(dt, elapsed, s, camera);
        this.vistas.update(elapsed, s, camera);
        this.mainDrop.update(elapsed, s);
        this.glassSupport.rotation.y = Math.sin(elapsed * .085) * .004;
        this.astrolabes.forEach((a, i) => { a.rotation.y += dt * (.09 + i * .01) * (s.reducedMotion ? .15 : 1); a.rotation.z = Math.sin(elapsed * .15 + i) * .03; });
        this.dust.update(elapsed, s.gravity[0]);
        this.condensation.count = Math.floor(stormIntensity(s.weather) * 70);
        this.condensation.material.opacity = .15 + stormIntensity(s.weather) * .45;
        this.echoLines.rotation.y = Math.sin(elapsed * .014) * .005;
        this.sync(s);
        const stage = causalStage(s), ready = finaleReady(s);
        this.concordance.rotation.y += dt * (s.reducedMotion ? .014 : .047) * (1 + stage * .4);
        this.concordance.children.forEach((m, i) => {
            const ring = m;
            ring.rotation.x += dt * .011 * (i % 2 ? 1 : -1);
            ring.material.opacity = stage > i ? .16 + stage * .075 + (ready ? .2 : 0) : 0;
        });
        this.concordanceLight.intensity = ready ? 5.3 : stage * .8;
        const water = this.basinWater.material;
        water.uniforms.uTime.value = elapsed;
        water.uniforms.uRain.value = stormIntensity(s.weather);
        water.uniforms.uDay.value = .5 + .33 * Math.sin((s.time - 6) * Math.PI / 12);
        this.waterRings.children.forEach((o, i) => {
            const ring = o, phase = (elapsed * .15 + i * .19) % 1;
            ring.scale.setScalar(.55 + phase * .57);
            ring.material.opacity = (1 - phase) * (.055 + stormIntensity(s.weather) * .06);
        });
        const glow = this.travelingGlow.material;
        glow.uniforms.uOpacity.value = .21 + Math.sin(elapsed * .77) * .06 + stormIntensity(s.weather) * .15;
        this.travelingGlow.rotation.z = elapsed * .085;
        this.lanterns.forEach(l => { l.intensity = (.75 + 1.8 * (1 - ((Math.sin((s.time - 6) * Math.PI / 12) + 1) * .5))) * (s.reducedMotion ? .96 : 1); });
    }
    dispose() { disposeScene(this.scene); }
}
