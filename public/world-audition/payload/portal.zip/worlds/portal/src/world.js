import * as THREE from 'three';
import { VISUAL_CHAPTERS } from './visual.js';
import { isPortalActive } from './puzzle.js';
import { teleport, signedDepth } from './portalMath.js';
import { collisionsFor } from './levelGeometry.js';
const PAL = {
    ivory: 0xf1efe8, milk: 0xfffaf0, stone: 0xdedbcf, gold: 0xdab76d,
    dark: 0x233541, black: 0x142631, teal: 0x46e5d4, blue: 0x71bbf7,
    rose: 0xff677f, cream: 0xffe5b8
};
const VERTEX = `
  varying vec2 vUv;
  void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}
`;
const PORTAL_FRAGMENT = `
  precision highp float;
  uniform sampler2D uScene;
  uniform float uTime;
  uniform float uEnabled;
  uniform float uForbidden;
  uniform vec3 uTint;
  varying vec2 vUv;
  void main(){
    vec2 p = vUv * 2.0 - 1.0;
    float r = length(p * vec2(0.85, 1.05));
    float wave = sin(p.y * 22.0 - uTime * 0.94 + sin(p.x * 8.0)) * 0.003;
    vec2 sampledUv = clamp(vUv + vec2(wave, sin(p.x * 12.0 + uTime) * 0.0025), 0.005, 0.995);
    vec3 viewColor = texture2D(uScene, sampledUv).rgb;
    float concentric = 0.5 + 0.5 * sin(r * 37.0 - uTime * 0.7);
    float filaments = pow(max(0.0, sin(atan(p.y, p.x) * 13.0 + r * 8.0 + uTime * 0.15)), 14.0);
    float nebula = 0.5 + 0.5 * sin(p.x * 13.0 + sin(p.y * 18.0 + uTime * 0.26));
    vec3 dormant = vec3(0.015, 0.037, 0.055) + uTint * (0.10 + concentric * 0.07 + nebula * 0.075);
    dormant += uTint * pow(max(0.0, 1.0 - r), 3.0) * 0.26;
    vec3 openView = mix(viewColor * 0.89, viewColor * 0.75 + uTint * 0.25, 0.27);
    openView += uTint * (filaments * 0.07 + concentric * 0.035);
    vec3 color = mix(dormant, openView, uEnabled);
    if (uForbidden > 0.5) {
      float fracture = 0.5 + 0.5 * sin(24.0 * r - uTime * 0.5 + 3.0 * sin(p.x * 3.0));
      float cross1 = 1.0 - smoothstep(0.02, 0.095, abs(p.x - p.y));
      float cross2 = 1.0 - smoothstep(0.02, 0.095, abs(p.x + p.y));
      vec3 denied = mix(vec3(0.052, 0.010, 0.029), uTint * 0.30, fracture * 0.35);
      denied += uTint * clamp(cross1 + cross2, 0.0, 1.0) * 0.27;
      denied += uTint * pow(max(0.0, 1.0 - r), 3.0) * 0.10;
      color = denied;
    }
    float rim = 1.0 - smoothstep(0.0, 0.095, min(min(vUv.x, 1.0 - vUv.x), min(vUv.y, 1.0 - vUv.y)));
    color += uTint * rim * 0.36;
    color += uTint * (0.018 + filaments * 0.018);
    gl_FragColor = vec4(color, 1.0);
  }
`;
export class FacilityWorld {
    scene = new THREE.Scene();
    obstacles = [];
    interactions = [];
    doors = [];
    chamber;
    ambientParticles = new THREE.Group();
    base = new THREE.Group();
    boxGeo = new THREE.BoxGeometry(1, 1, 1);
    cylinderGeo = new THREE.CylinderGeometry(1, 1, 1, 32);
    ballGeo = new THREE.SphereGeometry(1, 18, 12);
    lineGeo = new THREE.TorusGeometry(1, 0.05, 10, 80);
    ownedGeometries = [this.boxGeo, this.cylinderGeo, this.ballGeo, this.lineGeo];
    ownedMaterials = [];
    ownedTextures = [];
    rotor = new THREE.Group();
    rotorSocket = new THREE.Group();
    token = new THREE.Group();
    proofBulb = null;
    socketOrb = null;
    proofBeam = null;
    folding = [];
    haloRings = [];
    tokenDropAt = new THREE.Vector3(-8, 0.8, 10);
    rotorAngle = 0;
    foldProgress = 0;
    budget;
    chapter;
    previewCamera = new THREE.PerspectiveCamera(77, 0.75, 0.08, 120);
    oculus = new THREE.Group();
    crownLight = null;
    fxMesh = null;
    fxDummy = new THREE.Object3D();
    decorativeTmp = new THREE.Object3D();
    decorativeBatches = new Map();
    cylinderBatches = new Map();
    fxParticles = [];
    fxIndex = 0;
    fxSeed = 0;
    pulseRings = [];
    pulseIndex = 0;
    mat;
    constructor(chamber, budget) {
        this.chamber = chamber;
        this.budget = budget;
        this.chapter = VISUAL_CHAPTERS[chamber];
        this.obstacles.push(...collisionsFor(chamber));
        this.mat = {
            marble: this.material(PAL.ivory, 0.26, 0.34),
            porcelain: this.material(PAL.milk, 0.18, 0.26),
            pale: this.material(PAL.stone, 0.22, 0.45),
            gold: this.material(PAL.gold, 0.85, 0.27),
            brass: this.material(0x937044, 0.82, 0.34),
            shadow: this.material(PAL.dark, 0.38, 0.45),
            dark: this.material(PAL.black, 0.48, 0.23),
            teal: this.material(PAL.teal, 0.2, 0.3, PAL.teal, 1.6),
            rose: this.material(PAL.rose, 0.24, 0.25, PAL.rose, 1.8),
            whiteGlow: this.material(PAL.milk, 0.1, 0.24, 0xfff4d4, 2.0),
            inkInset: this.material(0x304651, 0.46, 0.42),
            floorLine: this.material(0x998458, 0.68, 0.27),
            accent: this.material(this.chapter.accent, 0.22, 0.3, this.chapter.accent, 0.85),
            accentDim: this.material(this.chapter.accent, 0.34, 0.38, this.chapter.accent, 0.26)
        };
        this.makeProceduralMaterials();
        this.scene.background = new THREE.Color(this.chapter.backplate);
        this.scene.fog = new THREE.FogExp2(this.chapter.atmospheric, 0.009);
        this.scene.add(this.base);
        this.ambientParticles.name = 'ambient particles';
        this.base.add(this.ambientParticles);
        this.buildLighting();
        this.buildRoom();
        this.buildDoors();
        this.buildChamberDetails();
        this.flushDecorations();
        this.buildEffects();
    }
    material(color, metalness, roughness, emissive = 0, intensity = 0) {
        const m = new THREE.MeshStandardMaterial({ color, metalness, roughness, emissive, emissiveIntensity: intensity });
        this.ownedMaterials.push(m);
        return m;
    }
    block(parent, x, y, z, w, h, d, material, cast = true) {
        const mesh = new THREE.Mesh(this.boxGeo, material);
        mesh.position.set(x, y, z);
        mesh.scale.set(w, h, d);
        mesh.castShadow = cast;
        mesh.receiveShadow = true;
        parent.add(mesh);
        return mesh;
    }
    /** Static surface-level details are collected by material into a handful of draw calls. */
    decoBlock(x, y, z, w, h, d, material, rotationY = 0, rotationZ = 0) {
        const temp = this.decorativeTmp;
        temp.position.set(x, y, z);
        temp.rotation.set(0, rotationY, rotationZ);
        temp.scale.set(w, h, d);
        temp.updateMatrix();
        const batch = this.decorativeBatches.get(material) ?? [];
        batch.push(temp.matrix.clone());
        this.decorativeBatches.set(material, batch);
    }
    decoDisk(x, y, z, rx, height, rz, material) {
        const temp = this.decorativeTmp;
        temp.position.set(x, y, z);
        temp.rotation.set(0, 0, 0);
        temp.scale.set(rx, height, rz);
        temp.updateMatrix();
        const batch = this.cylinderBatches.get(material) ?? [];
        batch.push(temp.matrix.clone());
        this.cylinderBatches.set(material, batch);
    }
    flushDecorations() {
        for (const [material, matrices] of this.decorativeBatches) {
            if (matrices.length === 0)
                continue;
            const instanced = new THREE.InstancedMesh(this.boxGeo, material, matrices.length);
            matrices.forEach((matrix, i) => instanced.setMatrixAt(i, matrix));
            instanced.instanceMatrix.needsUpdate = true;
            instanced.receiveShadow = true;
            instanced.castShadow = false;
            instanced.frustumCulled = false;
            this.base.add(instanced);
        }
        this.decorativeBatches.clear();
        for (const [material, matrices] of this.cylinderBatches) {
            if (matrices.length === 0)
                continue;
            const instanced = new THREE.InstancedMesh(this.cylinderGeo, material, matrices.length);
            matrices.forEach((matrix, i) => instanced.setMatrixAt(i, matrix));
            instanced.instanceMatrix.needsUpdate = true;
            instanced.receiveShadow = true;
            instanced.castShadow = false;
            instanced.frustumCulled = false;
            this.base.add(instanced);
        }
        this.cylinderBatches.clear();
    }
    disk(parent, x, y, z, rx, height, rz, material) {
        const m = new THREE.Mesh(this.cylinderGeo, material);
        m.position.set(x, y, z);
        m.scale.set(rx, height, rz);
        m.receiveShadow = true;
        m.castShadow = true;
        parent.add(m);
        return m;
    }
    sphere(parent, x, y, z, r, material) {
        const mesh = new THREE.Mesh(this.ballGeo, material);
        mesh.position.set(x, y, z);
        mesh.scale.setScalar(r);
        mesh.castShadow = true;
        parent.add(mesh);
        return mesh;
    }
    ring(parent, x, y, z, r, material) {
        const mesh = new THREE.Mesh(this.lineGeo, material);
        mesh.position.set(x, y, z);
        mesh.scale.setScalar(r);
        parent.add(mesh);
        return mesh;
    }
    /** Hand-authored mineral/metal microstructure without external textures or network I/O. */
    makeProceduralMaterials() {
        const makeTexture = (kind, seed) => {
            const canvas = document.createElement('canvas');
            canvas.width = canvas.height = 256;
            const ctx = canvas.getContext('2d');
            if (!ctx)
                return null;
            const image = ctx.createImageData(256, 256);
            let v = seed >>> 0;
            const random = () => { v = (Math.imul(1664525, v) + 1013904223) >>> 0; return v / 4294967296; };
            for (let y = 0; y < 256; y++)
                for (let x = 0; x < 256; x++) {
                    const i = (y * 256 + x) * 4;
                    const grain = random();
                    const streak = kind === 'metal'
                        ? Math.sin(x * 0.15 + y * 0.028) * 3.2
                        : Math.sin((x * 0.032 + y * 0.023) + Math.sin(y * 0.055) * 1.6) * 2.8;
                    const n = Math.round((kind === 'metal' ? 235 : 245) + (grain - 0.5) * (kind === 'metal' ? 16 : 11) + streak);
                    image.data[i] = n;
                    image.data[i + 1] = Math.min(255, n + (kind === 'stone' ? 2 : -1));
                    image.data[i + 2] = Math.min(255, n + (kind === 'stone' ? 4 : -5));
                    image.data[i + 3] = 255;
                }
            ctx.putImageData(image, 0, 0);
            if (kind === 'stone') {
                ctx.lineWidth = 0.7;
                ctx.strokeStyle = 'rgba(79,100,107,0.19)';
                for (let k = 0; k < 5; k++) {
                    const off = k * 61 + seed * 3;
                    ctx.beginPath();
                    ctx.moveTo(-30, 50 + off % 210);
                    ctx.bezierCurveTo(90, 12 + off % 160, 128, 220 - off % 140, 290, 56 + off % 140);
                    ctx.stroke();
                }
            }
            const texture = new THREE.CanvasTexture(canvas);
            texture.colorSpace = THREE.SRGBColorSpace;
            texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
            texture.anisotropy = 2;
            this.ownedTextures.push(texture);
            return texture;
        };
        const stone = makeTexture('stone', 31);
        const metal = makeTexture('metal', 79);
        if (stone) {
            for (const m of [this.mat.marble, this.mat.porcelain, this.mat.pale]) {
                m.map = stone;
                m.needsUpdate = true;
            }
        }
        if (metal) {
            for (const m of [this.mat.gold, this.mat.brass, this.mat.floorLine]) {
                m.map = metal;
                m.needsUpdate = true;
            }
        }
    }
    buildLighting() {
        this.scene.add(new THREE.HemisphereLight(0xcde5ef, 0x716454, 1.95));
        const sun = new THREE.DirectionalLight(0xffe5bd, 3.15);
        sun.position.set(-14, 28, 11);
        sun.castShadow = true;
        sun.shadow.mapSize.set(this.budget.shadowSize, this.budget.shadowSize);
        sun.shadow.camera.left = -28;
        sun.shadow.camera.right = 28;
        sun.shadow.camera.top = 34;
        sun.shadow.camera.bottom = -34;
        sun.shadow.camera.near = 1;
        sun.shadow.camera.far = 90;
        sun.shadow.bias = -0.00035;
        this.scene.add(sun);
        this.crownLight = new THREE.PointLight(this.chapter.crown, 75, 40, 1.65);
        this.crownLight.position.set(0, 13.4, -2);
        this.scene.add(this.crownLight);
        const bronzeLight = new THREE.PointLight(this.chapter.warm, 46, 34, 1.6);
        bronzeLight.position.set(8, 6, -12);
        this.scene.add(bronzeLight);
        // Shadow-map and light count are intentionally bounded for modest laptops.
    }
    buildRoom() {
        const g = this.base;
        this.block(g, 0, -0.36, 0, 34, 0.7, 39, this.mat.shadow, false);
        this.block(g, 0, -0.26, 0, 33.3, 0.52, 38.2, this.mat.marble, false);
        // Two tinted families of instanced marble floor tiles, no external textures.
        const ivory = new THREE.InstancedMesh(this.boxGeo, this.mat.porcelain, 320);
        const pale = new THREE.InstancedMesh(this.boxGeo, this.mat.pale, 320);
        let ci = 0, cp = 0;
        const temp = new THREE.Object3D();
        for (let ix = 0; ix < 16; ix++)
            for (let iz = 0; iz < 18; iz++) {
                temp.position.set(-15 + ix * 2, -0.007, -17 + iz * 2);
                temp.scale.set(1.93, 0.045, 1.93);
                temp.updateMatrix();
                if ((ix + iz) % 2 === 0)
                    ivory.setMatrixAt(ci++, temp.matrix);
                else
                    pale.setMatrixAt(cp++, temp.matrix);
            }
        ivory.count = ci;
        pale.count = cp;
        ivory.instanceMatrix.needsUpdate = pale.instanceMatrix.needsUpdate = true;
        ivory.receiveShadow = pale.receiveShadow = true;
        g.add(ivory, pale);
        this.buildFloorInlays();
        for (const x of [-16.35, 16.35]) {
            this.block(g, x, 7, 0, 0.9, 14, 40, this.mat.marble);
            this.block(g, x - Math.sign(x) * 0.23, 8.8, 0, 0.11, 0.18, 38, this.mat.gold);
        }
        for (const z of [-19, 19]) {
            this.block(g, 0, 7, z, 34.5, 14, 0.85, this.mat.marble);
            this.block(g, 0, 12.4, z - Math.sign(z) * 0.25, 33.8, 0.14, 0.2, this.mat.gold);
        }
        // The cross-wall is physically segmented around fixed doors; every hole is
        // protected by a separate, always-present collidable portal plane.
        const holes = this.chamber === 3
            ? [[-9.85, -6.15], [-2.15, 2.15], [6.15, 9.85]]
            : [[-9.85, -6.15], [6.15, 9.85]];
        let left = -16.0;
        for (const [a, b] of holes) {
            if (a > left) {
                const w = a - left;
                this.block(g, left + w / 2, 5.2, 0, w, 10.4, 0.85, this.mat.marble);
            }
            left = b;
        }
        if (left < 16) {
            this.block(g, (left + 16) / 2, 5.2, 0, 16 - left, 10.4, 0.85, this.mat.marble);
        }
        this.block(g, 0, 9.8, 0, 32.4, 2.4, 1.05, this.mat.gold);
        this.block(g, 0, 11.5, 0, 32.4, 2.8, 1.0, this.mat.marble);
        // Pilasters, fluted column shafts, crown beams and repeating shadow rhythm.
        for (const x of [-14, -11.8, -4, 4, 11.8, 14]) {
            for (const z of [-17, 17])
                this.column(g, x, z, 0.7);
        }
        for (const z of [-15.5, -10.5, -5.5, 5.5, 10.5, 15.5]) {
            for (const x of [-15.2, 15.2])
                this.column(g, x, z, 0.52);
        }
        for (const z of [-16, -11, -6, 5.5, 11, 16]) {
            this.block(g, 0, 12.85, z, 33, 0.44, 0.52, this.mat.gold);
            this.block(g, 0, 13.5, z, 34, 0.8, 0.84, this.mat.porcelain);
            this.block(g, 0, 14.2, z, 33, 0.12, 0.14, this.mat.teal, false);
        }
        for (const x of [-13.3, -7, 0, 7, 13.3]) {
            this.block(g, x, 13.9, 0, 0.5, 0.9, 39, this.mat.gold);
        }
        // Floating ornamental lantern array, each smaller than the architectural span.
        for (const z of [-14, -7.2, 7, 14]) {
            const pendulum = new THREE.Group();
            pendulum.position.set(0, 11.7, z);
            this.disk(pendulum, 0, -0.08, 0, 2.2, 0.17, 2.2, this.mat.gold);
            this.disk(pendulum, 0, -0.35, 0, 1.55, 0.25, 1.55, this.mat.whiteGlow);
            const circ = this.ring(pendulum, 0, -0.47, 0, 1.7, this.mat.gold);
            circ.rotation.x = Math.PI / 2;
            g.add(pendulum);
            this.haloRings.push(pendulum);
        }
        // Accessible paths stay physically level; decorative stripes reveal intent.
        for (const x of [-8, 8]) {
            for (const z of [-17, -13, -9, -5, 5, 9, 13, 17]) {
                this.decoBlock(x, 0.03, z, 3.8, 0.038, 0.085, this.mat.gold);
            }
        }
        this.buildPlaza(-11, 10);
        this.buildPlaza(8, -15.8);
        // Majestic distant forms: explicitly outside the playable boundaries.
        for (let i = 0; i < 12; i++) {
            const x = -40 + i * 7.4;
            this.block(g, x, 20, -32, 3.8, 40, 3.8, this.mat.pale);
            this.block(g, x, 40, -32, 5.5, 0.9, 5.5, this.mat.gold);
            this.block(g, x, 44, -32, 0.8, 7, 0.8, this.mat.gold);
        }
        this.buildWallReliefs();
        this.buildCeilingOculus();
        this.addAtmosphere();
    }
    /** Decorative geometry occupies the existing solid wall or lies flush to the floor. */
    buildFloorInlays() {
        for (const [x, z] of [[-8, 10], [8, -11], [-8, -8], [8, 9]]) {
            const medallion = this.ring(this.base, x, 0.042, z, 1.72, this.mat.floorLine);
            medallion.rotation.x = Math.PI / 2;
            medallion.scale.y = 0.79;
            const inner = this.ring(this.base, x, 0.044, z, 0.98, this.mat.brass);
            inner.rotation.x = Math.PI / 2;
            for (let i = 0; i < 8; i++) {
                const angle = i * Math.PI / 4;
                this.decoBlock(x + Math.sin(angle) * 2.08, 0.047, z + Math.cos(angle) * 2.08, 0.055, 0.022, 0.33, this.mat.floorLine, angle);
            }
        }
        for (const side of [-1, 1]) {
            this.decoBlock(side * 14.3, 0.035, 0, 0.065, 0.018, 35.0, this.mat.floorLine);
            this.decoBlock(side * 13.9, 0.035, 0, 0.025, 0.018, 35.0, this.mat.brass);
        }
        for (let z = -16; z <= 16; z += 4) {
            this.decoBlock(0, 0.039, z, 24, 0.018, 0.024, this.mat.brass);
        }
    }
    buildWallReliefs() {
        for (const side of [-1, 1]) {
            for (let z = -15.5; z <= 15.5; z += 5.2) {
                // Their depth remains inside the existing x wall's collision volume.
                const x = side * 15.92;
                this.decoBlock(x, 6.6, z, 0.09, 8.1, 3.12, this.mat.inkInset);
                this.decoBlock(x - side * 0.065, 6.6, z, 0.055, 7.6, 2.64, this.mat.pale);
                this.decoBlock(x - side * 0.10, 6.6, z, 0.045, 7.15, 2.08, this.mat.marble);
                for (const dz of [-1.25, 1.25]) {
                    this.decoBlock(x - side * 0.145, 6.6, z + dz, 0.055, 7.8, 0.065, this.mat.gold);
                }
                this.decoBlock(x - side * 0.16, 10.25, z, 0.065, 0.07, 2.5, this.mat.gold);
                this.decoBlock(x - side * 0.16, 2.94, z, 0.065, 0.07, 2.5, this.mat.gold);
                this.sphere(this.base, x - side * 0.175, 6.65, z, 0.13, this.mat.accentDim).castShadow = false;
            }
        }
        for (const z of [-18.52, 18.52]) {
            for (const x of [-12.2, -5.9, 0, 5.9, 12.2]) {
                this.decoBlock(x, 8, z, 3.9, 7.3, 0.1, this.mat.inkInset);
                this.decoBlock(x, 8, z - Math.sign(z) * 0.063, 3.48, 6.94, 0.05, this.mat.pale);
                this.decoBlock(x, 11.1, z - Math.sign(z) * 0.12, 3.55, 0.065, 0.05, this.mat.gold);
            }
        }
    }
    buildCeilingOculus() {
        this.oculus.position.set(0, 16.3, 0);
        const rings = [{ r: 8.9, t: 0.19, mat: this.mat.brass }, { r: 7.7, t: 0.12, mat: this.mat.gold }, { r: 5.2, t: 0.12, mat: this.mat.gold }, { r: 2.1, t: 0.21, mat: this.mat.accentDim }];
        for (const ring of rings) {
            const geo = new THREE.TorusGeometry(ring.r, ring.t, 8, 96);
            this.ownedGeometries.push(geo);
            const mesh = new THREE.Mesh(geo, ring.mat);
            mesh.rotation.x = Math.PI / 2;
            mesh.castShadow = false;
            this.oculus.add(mesh);
        }
        for (let i = 0; i < 20; i++) {
            const a = i * Math.PI / 10;
            const strut = this.block(this.oculus, Math.sin(a) * 6.45, 0, Math.cos(a) * 6.45, 0.14, 0.12, 2.45, this.mat.brass, false);
            strut.rotation.y = a;
            const pin = this.sphere(this.oculus, Math.sin(a) * 8.0, 0.1, Math.cos(a) * 8.0, 0.13, this.mat.accentDim);
            pin.castShadow = false;
        }
        const center = this.disk(this.oculus, 0, -0.18, 0, 1.52, 0.3, 1.52, this.mat.gold);
        center.castShadow = false;
        this.disk(this.oculus, 0, -0.33, 0, 1.05, 0.13, 1.05, this.mat.dark).castShadow = false;
        this.base.add(this.oculus);
    }
    buildPlaza(x, z) {
        const g = this.base;
        this.disk(g, x, 0.04, z, 2.1, 0.12, 2.1, this.mat.gold);
        this.disk(g, x, 0.13, z, 1.86, 0.12, 1.86, this.mat.porcelain);
    }
    column(g, x, z, r) {
        this.disk(g, x, 0.46, z, r * 1.56, 0.9, r * 1.56, this.mat.gold);
        this.disk(g, x, 1.0, z, r * 1.25, 0.35, r * 1.25, this.mat.porcelain);
        this.disk(g, x, 6.45, z, r, 10.7, r, this.mat.porcelain);
        for (let k = 0; k < 8; k++) {
            const a = k * Math.PI / 4;
            const px = x + Math.cos(a) * r * 0.85;
            const pz = z + Math.sin(a) * r * 0.85;
            this.decoDisk(px, 6.5, pz, r * 0.17, 10.3, r * 0.17, this.mat.pale);
        }
        this.disk(g, x, 11.8, z, r * 1.3, 0.7, r * 1.3, this.mat.gold);
        this.block(g, x, 12.2, z, r * 2.9, 0.42, r * 2.9, this.mat.porcelain);
    }
    addAtmosphere() {
        const mat = new THREE.MeshBasicMaterial({ color: 0xe6e6ca, transparent: true, opacity: 0.48, depthWrite: false });
        this.ownedMaterials.push(mat);
        const geom = new THREE.OctahedronGeometry(0.06, 0);
        this.ownedGeometries.push(geom);
        const mesh = new THREE.InstancedMesh(geom, mat, this.budget.dustCount);
        const tmp = new THREE.Object3D();
        for (let i = 0; i < this.budget.dustCount; i++) {
            const n = i * 91.3181;
            const rand = (v) => { const t = Math.sin(v) * 43758.5453; return t - Math.floor(t); };
            tmp.position.set(-15.1 + rand(n) * 30.2, 1.6 + rand(n + 7) * 12, -18 + rand(n + 17) * 36);
            tmp.rotation.set(rand(n + 13), rand(n + 30) * 6.28, rand(n + 3));
            tmp.scale.setScalar(0.6 + rand(n + 23) * 1.8);
            tmp.updateMatrix();
            mesh.setMatrixAt(i, tmp.matrix);
        }
        mesh.instanceMatrix.needsUpdate = true;
        mesh.frustumCulled = false;
        this.ambientParticles.add(mesh);
    }
    makePortal(x, z, yaw, id) {
        const forbidden = id === 'PUBLISH';
        const tint = forbidden ? PAL.rose : (this.chamber === 2 ? PAL.gold : PAL.teal);
        const darkGold = forbidden ? this.mat.rose : this.mat.gold;
        const group = new THREE.Group();
        group.position.set(x, 0, z);
        group.rotation.y = yaw;
        const frameW = forbidden ? 4.7 : 4.2;
        const frameH = forbidden ? 6.1 : 5.35;
        const doorW = forbidden ? 3.85 : 3.32;
        const doorH = forbidden ? 5.08 : 4.35;
        const target = new THREE.WebGLRenderTarget(this.budget.previewWidth, this.budget.previewHeight, {
            depthBuffer: true, stencilBuffer: false,
            minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
            format: THREE.RGBAFormat
        });
        target.texture.colorSpace = THREE.SRGBColorSpace;
        const material = new THREE.ShaderMaterial({
            vertexShader: VERTEX,
            fragmentShader: PORTAL_FRAGMENT,
            uniforms: {
                uScene: { value: target.texture }, uTime: { value: 0 },
                uEnabled: { value: 0 }, uForbidden: { value: forbidden ? 1 : 0 },
                uTint: { value: new THREE.Color(tint) }
            },
            side: THREE.DoubleSide
        });
        this.ownedMaterials.push(material);
        const geo = new THREE.PlaneGeometry(doorW, doorH);
        this.ownedGeometries.push(geo);
        const surface = new THREE.Mesh(geo, material);
        surface.position.set(0, doorH / 2 + 0.20, 0.095);
        group.add(surface);
        this.block(group, 0, doorH / 2 + 0.21, -0.37, frameW, frameH, 0.45, this.mat.dark);
        // Reparent the visible surface after the opaque backdrop to avoid depth ambiguity.
        group.remove(surface);
        group.add(surface);
        this.block(group, -frameW / 2 + 0.12, frameH / 2, 0.22, 0.42, frameH, 0.55, darkGold);
        this.block(group, frameW / 2 - 0.12, frameH / 2, 0.22, 0.42, frameH, 0.55, darkGold);
        this.block(group, 0, frameH - 0.1, 0.22, frameW, 0.48, 0.55, darkGold);
        this.block(group, 0, 0.25, 0.21, frameW, 0.5, 0.65, this.mat.gold);
        // Precision-machined depth, recessed illuminated teeth and radial signal array.
        for (let level = 0; level < 7; level++) {
            const h = 0.8 + level * 0.65;
            for (const side of [-1, 1]) {
                this.block(group, side * (frameW / 2 + 0.035), h, 0.55, 0.1, 0.13, 0.3, this.mat.porcelain, false);
                this.block(group, side * (frameW / 2 - 0.30), h, 0.55, 0.055, 0.34, 0.15, forbidden ? this.mat.rose : this.mat.accentDim, false);
            }
        }
        for (const scale of [1.02, 1.22, 1.43]) {
            const halo = this.ring(group, 0, frameH / 2 + 0.15, 0.52, 1.4 * scale, forbidden ? this.mat.rose : this.mat.brass);
            halo.scale.y = 1.6;
            halo.castShadow = false;
        }
        for (const side of [-1, 1]) {
            this.block(group, side * (frameW / 2 + 0.37), 3.05, 0.17, 0.13, 4.8, 0.3, this.mat.porcelain);
            this.sphere(group, side * (frameW / 2 - 0.05), frameH + 0.08, 0.13, 0.17, forbidden ? this.mat.rose : this.mat.teal);
        }
        const crown = this.ring(group, 0, frameH + 0.22, 0.06, 0.7, darkGold);
        crown.scale.y = 0.31;
        const cap = this.disk(group, 0, frameH + 0.12, 0, 0.18, 0.42, 0.18, this.mat.whiteGlow);
        cap.rotation.z = Math.PI / 2;
        const signal = new THREE.Group();
        const stripMat = new THREE.MeshBasicMaterial({ color: tint, toneMapped: false, depthWrite: false });
        this.ownedMaterials.push(stripMat);
        for (const side of [-1, 1]) {
            this.block(signal, side * (frameW / 2 - 0.44), frameH / 2, 0.68, 0.055, frameH - 0.7, 0.07, stripMat, false);
        }
        const activeCrown = this.sphere(signal, 0, frameH + 0.21, 0.63, 0.13, stripMat);
        activeCrown.castShadow = false;
        group.add(signal);
        signal.visible = false;
        this.base.add(group);
        this.doors.push({ id, pose: { x, z, yaw }, group, surface, material, target, signal });
        if (forbidden) {
            signal.visible = true; // Never use linked-state authority to change a forbidden portal's collision or preview.
            const outside = new THREE.Group();
            outside.position.set(x, 0, z + 0.44);
            for (let i = 0; i < 4; i++) {
                const halo = this.ring(outside, 0, 3.0, 0.24 + i * 0.15, 1.45 + i * 0.24, this.mat.rose);
                halo.scale.y = 1.40;
                this.haloRings.push(halo);
            }
            this.base.add(outside);
            this.plaque('PUBLISH / NO AUTHORITY', x, 7.85, z + 0.66, 0, 5.4, 0.65, true);
        }
        else {
            const name = this.chamber === 3 ? (id === 'A' ? 'VALIDATE / ENTRY' : 'VERIFIED EXIT') : `LINKED GATE ${id}`;
            const frontYaw = id === 'B' ? Math.PI : 0;
            this.plaque(name, x, 6.78, z + Math.cos(frontYaw) * 0.7, frontYaw, 4.8, 0.68, false);
        }
    }
    buildDoors() {
        this.makePortal(-8, 0, 0, 'A');
        this.makePortal(8, 0, Math.PI, 'B');
        if (this.chamber === 3)
            this.makePortal(0, 0, 0, 'PUBLISH');
    }
    plaque(label, x, y, z, yaw = 0, w = 4.4, h = 0.72, warning = false) {
        const canvas = document.createElement('canvas');
        canvas.width = 1024;
        canvas.height = 180;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.fillStyle = warning ? '#351a2a' : '#1d3542';
        ctx.fillRect(0, 0, 1024, 180);
        ctx.strokeStyle = warning ? '#ff6d84' : '#ddbd7e';
        ctx.lineWidth = 9;
        ctx.strokeRect(10, 10, 1004, 160);
        ctx.fillStyle = warning ? '#ffc0ba' : '#f7e9c7';
        ctx.font = 'bold 53px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(label, 512, 93, 970);
        const texture = new THREE.CanvasTexture(canvas);
        texture.colorSpace = THREE.SRGBColorSpace;
        this.ownedTextures.push(texture);
        const material = new THREE.MeshBasicMaterial({ map: texture, transparent: false, side: THREE.DoubleSide });
        this.ownedMaterials.push(material);
        const geo = new THREE.PlaneGeometry(w, h);
        this.ownedGeometries.push(geo);
        const mesh = new THREE.Mesh(geo, material);
        mesh.position.set(x, y, z);
        mesh.rotation.y = yaw;
        this.base.add(mesh);
    }
    pedestal(x, z, color, label) {
        const g = this.base;
        this.disk(g, x, 0.3, z, 0.85, 0.6, 0.85, this.mat.shadow);
        this.disk(g, x, 0.75, z, 0.53, 0.46, 0.53, this.mat.porcelain);
        this.disk(g, x, 1.02, z, 0.65, 0.2, 0.65, this.mat.gold);
        this.sphere(g, x, 1.24, z, 0.23, this.mat[color]);
        this.plaque(label, x, 1.76, z + 0.05, 0, 2.4, 0.45, color === 'rose');
    }
    archGate(x, z) {
        const g = this.base;
        this.block(g, x - 2.25, 2.4, z, 0.55, 4.8, 1.2, this.mat.gold);
        this.block(g, x + 2.25, 2.4, z, 0.55, 4.8, 1.2, this.mat.gold);
        this.block(g, x, 4.75, z, 4.9, 0.5, 1.2, this.mat.gold);
        this.block(g, x, 2.4, z - 0.15, 3.85, 4.15, 0.17, this.mat.dark);
        const plate = this.block(g, x, 2.35, z + 0.07, 3.6, 3.85, 0.05, this.mat.porcelain);
        plate.material = this.mat.pale;
        this.plaque('NEXT / E15', x, 5.35, z + 0.7, 0, 3.7, 0.54);
    }
    buildChamberDetails() {
        if (this.chamber === 1) {
            this.pedestal(-11, 10, 'teal', 'AUTHORIZE PAIR');
            this.interactions.push({ id: 'link', title: 'Authorize reversible link', action: 'LINK', x: -11, z: 10, radius: 2.8 });
            this.archGate(8, -17.4);
            this.pedestal(8, -15.6, 'gold', 'ARCHIVE GATE');
            this.interactions.push({ id: 'exit', title: 'Continue to chamber 02', action: 'EXIT', x: 8, z: -15.6, radius: 2.7 });
            this.plaque('01 / CONNECTION', 0, 8.0, 1.0, 0, 5.8, 0.72);
            this.createSculpture(-2, 11, 1);
            this.createSculpture(12, -10, 1.4);
            this.buildChamberConstellation();
        }
        if (this.chamber === 2) {
            this.pedestal(-11, 10, 'gold', 'TOKEN INTAKE');
            this.interactions.push({ id: 'token', title: 'Pick up synthetic token', action: 'PICK_TOKEN', x: -8, z: 10, radius: 2.3,
                enabled: s => !s.carrying && !s.inserted });
            this.createToken();
            this.createRotor();
            this.pedestal(8, -15.6, 'gold', 'ARCHIVE GATE');
            this.archGate(8, -17.4);
            this.interactions.push({ id: 'exit', title: 'Continue to chamber 03', action: 'EXIT', x: 8, z: -15.6, radius: 2.6 });
            this.plaque('02 / CAPABILITY', 0, 8.0, 1.0, 0, 5.8, 0.72);
            this.createSculpture(-2, 12, 1.1);
            this.buildChamberConstellation();
        }
        if (this.chamber === 3) {
            this.pedestal(-11, 10, 'teal', 'BOUNDED VALIDATION');
            this.interactions.push({ id: 'validate', title: 'Authorize bounded validation only', action: 'VALIDATE', x: -11, z: 10, radius: 2.8 });
            this.pedestal(0, 5, 'rose', 'PUBLISH?');
            this.interactions.push({ id: 'publish', title: 'Attempt unauthorized publish (safe refusal)', action: 'PUBLISH', x: 0, z: 5, radius: 3.1 });
            this.interactions.push({ id: 'publish-door', title: 'Ask publishing portal for access (safe refusal)', action: 'PUBLISH', x: 0, z: 1.4, radius: 2.5 });
            this.pedestal(8, -10, 'teal', 'VERIFY PROOF');
            this.interactions.push({ id: 'verify', title: 'Reconcile validation evidence', action: 'VERIFY', x: 8, z: -10, radius: 2.8 });
            this.createProofLamp();
            this.createFoldingArchitecture();
            this.plaque('03 / AUTHORITY', 0, 8.0, 1.0, 0, 5.8, 0.72);
            this.createSculpture(-3, 13, 1.1);
            this.createSculpture(12, -11, 1.3);
            this.buildChamberConstellation();
        }
    }
    /** Chamber-specific silhouettes are scenic only; no puzzle route or collider changes. */
    buildChamberConstellation() {
        if (this.chamber === 1) {
            for (let side of [-1, 1]) {
                const x = side * 8;
                for (let i = 0; i < 3; i++) {
                    const arch = this.ring(this.base, x, 9.5 + i * 1.25, -2.6, 2.3 + i * 0.58, this.mat.accentDim);
                    arch.scale.y = 1.2;
                    arch.castShadow = false;
                }
            }
            this.plaque('LINK / REVERSIBLE', -8, 11.9, -2.7, 0, 4.7, 0.54);
        }
        else if (this.chamber === 2) {
            for (let i = 0; i < 12; i++) {
                const a = i * Math.PI / 6;
                const x = 8 + Math.sin(a) * 7.1, z = -9 + Math.cos(a) * 7.1;
                this.decoBlock(x, 9.8, z, 0.11, 4.2, 0.11, this.mat.brass, a);
                this.sphere(this.base, x, 7.7, z, 0.23, this.mat.accentDim).castShadow = false;
            }
            for (let r of [5.4, 6.6]) {
                const rim = this.ring(this.base, 8, 11.6, -9, r, this.mat.gold);
                rim.rotation.x = Math.PI / 2;
                rim.castShadow = false;
            }
        }
        else {
            // A ludicrous publication apparatus, conspicuously decorative and permanently inert.
            const warning = this.ring(this.base, 0, 11.9, 0.7, 5.25, this.mat.rose);
            warning.scale.y = 0.63;
            for (let i = 0; i < 13; i++) {
                const a = (-0.95 + i * 0.158) * Math.PI;
                this.decoBlock(Math.cos(a) * 5.8, 11.8 + Math.sin(a) * 3.0, 0.4, 0.1, 2.5, 0.13, this.mat.brass, 0, a);
            }
            this.plaque('REJECTED / NON-EXECUTABLE', 0, 12.4, 1.0, 0, 7, 0.75, true);
        }
    }
    createSculpture(x, z, scale) {
        const g = new THREE.Group();
        g.position.set(x, 0, z);
        g.scale.setScalar(scale);
        this.disk(g, 0, 0.36, 0, 1.8, 0.72, 1.8, this.mat.dark);
        this.disk(g, 0, 0.8, 0, 1.44, 0.24, 1.44, this.mat.gold);
        for (let i = 0; i < 5; i++) {
            const a = i * Math.PI * 2 / 5;
            const b = this.block(g, Math.cos(a) * 0.65, 2.3, Math.sin(a) * 0.65, 0.22, 2.7, 0.6, this.mat.porcelain);
            b.rotation.y = a;
            b.rotation.z = Math.sin(a) * 0.2;
        }
        const crown = this.ring(g, 0, 4.1, 0, 1.2, this.mat.gold);
        crown.rotation.x = Math.PI / 2;
        this.sphere(g, 0, 3.9, 0, 0.36, this.mat.teal);
        this.base.add(g);
        this.haloRings.push(g);
    }
    createToken() {
        const token = this.token;
        const body = this.block(token, 0, 0, 0, 0.82, 0.54, 0.22, this.mat.gold);
        body.rotation.y = 0.13;
        this.block(token, 0, 0, 0.15, 0.56, 0.3, 0.04, this.mat.dark);
        this.block(token, -0.12, 0, 0.2, 0.11, 0.15, 0.03, this.mat.teal);
        this.block(token, 0.14, 0.05, 0.2, 0.15, 0.05, 0.03, this.mat.porcelain);
        const rim = this.ring(token, 0, 0, 0, 0.48, this.mat.teal);
        rim.castShadow = false;
        for (let i = 0; i < 5; i++) {
            this.block(token, -0.26 + i * 0.13, -0.16, 0.235, 0.038, 0.105, 0.026, this.mat.porcelain, false);
        }
        this.sphere(token, 0.31, 0.10, 0.235, 0.05, this.mat.whiteGlow).castShadow = false;
        token.position.copy(this.tokenDropAt);
        this.base.add(token);
    }
    createRotor() {
        const cx = 8, cz = -9;
        this.disk(this.base, cx, 0.10, cz, 6, 0.18, 6, this.mat.gold);
        this.disk(this.base, cx, 0.18, cz, 5.74, 0.15, 5.74, this.mat.shadow);
        this.disk(this.base, cx, 0.24, cz, 5.2, 0.11, 5.2, this.mat.porcelain);
        for (let i = 0; i < 8; i++) {
            const a = i * Math.PI / 4;
            const bar = this.block(this.base, cx + Math.sin(a) * 4.1, 0.31, cz + Math.cos(a) * 4.1, 0.1, 0.06, 1.2, this.mat.gold, false);
            bar.rotation.y = a;
        }
        this.rotor.position.set(cx, 0, cz);
        this.disk(this.rotor, 0, 0.48, 0, 0.8, 0.65, 0.8, this.mat.gold);
        for (let i = 0; i < 4; i++) {
            const a = i * Math.PI / 2;
            const arm = this.block(this.rotor, Math.cos(a) * 2.7, 7.1, Math.sin(a) * 2.7, 4.6, 0.28, 0.30, this.mat.gold);
            arm.rotation.y = -a;
            this.sphere(this.rotor, Math.cos(a) * 4.8, 7.1, Math.sin(a) * 4.8, 0.31, this.mat.teal);
        }
        this.disk(this.rotor, 0, 7.1, 0, 0.9, 0.65, 0.9, this.mat.porcelain);
        for (const radius of [3.1, 4.7]) {
            const bearing = this.ring(this.rotor, 0, 7.1, 0, radius, this.mat.brass);
            bearing.rotation.x = Math.PI / 2;
            bearing.castShadow = false;
        }
        this.rotorSocket.position.set(5, 0, 0);
        this.disk(this.rotorSocket, 0, 0.55, 0, 1.1, 0.45, 1.1, this.mat.shadow);
        this.disk(this.rotorSocket, 0, 0.81, 0, 0.83, 0.16, 0.83, this.mat.gold);
        this.block(this.rotorSocket, 0, 1.02, 0, 0.96, 0.3, 0.45, this.mat.dark);
        this.socketOrb = this.sphere(this.rotorSocket, 0, 1.25, 0, 0.22, this.mat.dark);
        this.block(this.rotorSocket, 0, 4.2, 0, 0.28, 5.7, 0.28, this.mat.gold);
        this.rotor.add(this.rotorSocket);
        this.base.add(this.rotor);
        this.pedestal(8, -9, 'gold', 'INDEX ROTOR');
        this.interactions.push({ id: 'rotate', title: 'Index rotor 90 degrees', action: 'ROTATE', x: 8, z: -9, radius: 2.4 });
        this.interactions.push({ id: 'socket', title: 'Insert token at 180-degree receiver', action: 'INSERT', x: 3, z: -9, radius: 2.1,
            enabled: s => s.rotorIndex === 2 && !s.inserted });
        const hoop = this.ring(this.base, 8, 11, -9, 5.6, this.mat.gold);
        hoop.rotation.x = Math.PI / 2;
        this.haloRings.push(hoop);
        this.plaque('ROTATE TO 180 DEGREES', 8, 7, -17.9, 0, 7.0, 0.75);
    }
    createProofLamp() {
        this.pedestal(8, -15.8, 'gold', 'VALIDATION PASSED');
        this.disk(this.base, 8, 1.53, -15.8, 0.26, 0.2, 0.26, this.mat.gold);
        this.proofBulb = this.sphere(this.base, 8, 1.77, -15.8, 0.17, this.mat.dark);
        const beamMat = new THREE.MeshBasicMaterial({ color: 0xfff3c3, transparent: true, opacity: 0.13, depthWrite: false, side: THREE.DoubleSide });
        this.ownedMaterials.push(beamMat);
        const beamGeo = new THREE.ConeGeometry(1.8, 7.0, 20, 1, true);
        this.ownedGeometries.push(beamGeo);
        this.proofBeam = new THREE.Mesh(beamGeo, beamMat);
        this.proofBeam.position.set(8, 5.3, -15.8);
        this.proofBeam.visible = false;
        this.base.add(this.proofBeam);
        this.interactions.push({ id: 'proof', title: 'Claim the small validation proof', action: 'CLAIM_PROOF', x: 8, z: -15.8, radius: 2.3 });
    }
    createFoldingArchitecture() {
        // Giant articulated wings are scenic only: never change playable collision.
        for (let i = 0; i < 12; i++) {
            const leftSide = i % 2 === 0;
            const wing = new THREE.Group();
            wing.position.set(leftSide ? -16 : 16, 7.8 + Math.floor(i / 2) * 0.45, -17.1 + Math.floor(i / 2) * 0.22);
            const span = 7.5 + Math.floor(i / 2) * 1.2;
            const panel = this.block(wing, (leftSide ? 1 : -1) * span / 2, 0, 0, span, 0.25, 2.15, this.mat.porcelain);
            panel.rotation.z = leftSide ? -0.12 : 0.12;
            this.block(wing, (leftSide ? 1 : -1) * span / 2, 0.19, 0, span, 0.10, 0.14, this.mat.gold);
            const angle = (leftSide ? 1 : -1) * (0.55 + i * 0.033);
            this.folding.push({ group: wing, openAngle: angle });
            this.base.add(wing);
        }
        for (let i = 0; i < 7; i++) {
            const arch = this.ring(this.base, 8, 7 + i * 1.08, -14, 2.8 + i * 0.46, this.mat.gold);
            arch.scale.y = 0.7;
            this.haloRings.push(arch);
        }
    }
    /** One batched, finite VFX pool for all scenes. No particle creates a mesh in gameplay. */
    buildEffects() {
        const geometry = new THREE.OctahedronGeometry(0.085, 0);
        const material = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, transparent: true, opacity: 0.75, depthWrite: false, blending: THREE.AdditiveBlending });
        this.ownedGeometries.push(geometry);
        this.ownedMaterials.push(material);
        const mesh = new THREE.InstancedMesh(geometry, material, this.budget.burstCount);
        mesh.frustumCulled = false;
        mesh.castShadow = false;
        this.fxMesh = mesh;
        this.fxParticles = Array.from({ length: this.budget.burstCount }, () => ({ x: 0, y: -100, z: 0, vx: 0, vy: 0, vz: 0, age: 1, ttl: 0.001 }));
        for (let i = 0; i < this.budget.burstCount; i++) {
            this.fxDummy.position.set(0, -100, 0);
            this.fxDummy.scale.setScalar(0);
            this.fxDummy.updateMatrix();
            mesh.setMatrixAt(i, this.fxDummy.matrix);
            mesh.setColorAt(i, new THREE.Color(0xffffff));
        }
        mesh.instanceMatrix.needsUpdate = true;
        if (mesh.instanceColor)
            mesh.instanceColor.needsUpdate = true;
        this.base.add(mesh);
        const ringGeometry = new THREE.TorusGeometry(1, 0.035, 6, 64);
        this.ownedGeometries.push(ringGeometry);
        for (let i = 0; i < 3; i++) {
            const ringMaterial = new THREE.MeshBasicMaterial({ color: this.chapter.accent, toneMapped: false, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending });
            this.ownedMaterials.push(ringMaterial);
            const ring = new THREE.Mesh(ringGeometry, ringMaterial);
            ring.rotation.x = Math.PI / 2;
            ring.visible = false;
            ring.castShadow = false;
            this.base.add(ring);
            this.pulseRings.push({ mesh: ring, material: ringMaterial, age: 1, ttl: 0.001 });
        }
    }
    /** Stateless presentation response. Authority never flows from an effect back to the puzzle. */
    react(event, action, position, reducedMotion) {
        if (reducedMotion || event === 'none' || event === 'advance' || event === 'reset')
            return;
        let x = position.x, y = 1.2, z = position.z;
        if (action === 'LINK' || action === 'VALIDATE') {
            x = -11;
            z = 10;
        }
        else if (action === 'ROTATE') {
            x = 8;
            z = -9;
            y = 2.2;
        }
        else if (action === 'INSERT') {
            x = 3;
            z = -9;
            y = 1.3;
        }
        else if (action === 'PUBLISH') {
            x = 0;
            z = 1.6;
            y = 2.6;
        }
        else if (action === 'VERIFY') {
            x = 8;
            z = -10;
        }
        else if (action === 'CLAIM_PROOF') {
            x = 8;
            z = -15.8;
        }
        const color = action === 'PUBLISH' ? 0xff607d : action === 'ROTATE' || action === 'INSERT' ? 0xffd28b : this.chapter.accent;
        const quantity = event === 'teleport' ? 22 : event === 'denied' ? 18 : 12;
        const rand = (n) => {
            const k = Math.sin(n * 91.28 + this.fxSeed * 17.37) * 43758.5453;
            return k - Math.floor(k);
        };
        this.fxSeed++;
        for (let n = 0; n < Math.min(quantity, this.fxParticles.length); n++) {
            const i = (this.fxIndex++) % this.fxParticles.length;
            const phi = rand(n + 4) * Math.PI * 2;
            const spread = 0.6 + rand(n + 16) * 1.45;
            const speed = 0.5 + rand(n + 39) * 1.2;
            this.fxParticles[i] = { x: x + Math.cos(phi) * 0.13, y: y + rand(n + 70) * 0.25, z: z + Math.sin(phi) * 0.13,
                vx: Math.cos(phi) * spread * speed, vy: (rand(n + 23) - 0.18) * 2.0, vz: Math.sin(phi) * spread * speed,
                age: 0, ttl: 0.75 + rand(n + 99) * 0.45 };
            this.fxMesh?.setColorAt(i, new THREE.Color(color));
        }
        if (this.fxMesh?.instanceColor)
            this.fxMesh.instanceColor.needsUpdate = true;
        const ring = this.pulseRings[this.pulseIndex++ % this.pulseRings.length];
        ring.mesh.position.set(x, action === 'PUBLISH' ? 1.0 : 0.13, z);
        ring.mesh.scale.setScalar(0.2);
        ring.material.color.setHex(color);
        ring.age = 0;
        ring.ttl = action === 'PUBLISH' ? 0.67 : 0.85;
        ring.mesh.visible = true;
    }
    updateEffects(dt, reducedMotion) {
        if (!this.fxMesh)
            return;
        let changed = false;
        for (let i = 0; i < this.fxParticles.length; i++) {
            const fx = this.fxParticles[i];
            if (fx.age >= fx.ttl)
                continue;
            fx.age += reducedMotion ? fx.ttl : dt;
            if (fx.age >= fx.ttl) {
                this.fxDummy.scale.setScalar(0);
            }
            else {
                const damp = Math.exp(-dt * 1.9);
                fx.vx *= damp;
                fx.vz *= damp;
                fx.x += fx.vx * dt;
                fx.z += fx.vz * dt;
                fx.y += fx.vy * dt;
                fx.vy -= dt * 1.05;
                this.fxDummy.scale.setScalar(Math.max(0.001, 1 - fx.age / fx.ttl) * (0.55 + (i % 5) * 0.17));
            }
            this.fxDummy.position.set(fx.x, fx.y, fx.z);
            this.fxDummy.rotation.set(fx.age * 1.7, fx.age * 2.1, 0);
            this.fxDummy.updateMatrix();
            this.fxMesh.setMatrixAt(i, this.fxDummy.matrix);
            changed = true;
        }
        if (changed)
            this.fxMesh.instanceMatrix.needsUpdate = true;
        for (const r of this.pulseRings) {
            if (r.age >= r.ttl)
                continue;
            r.age += reducedMotion ? r.ttl : dt;
            if (r.age >= r.ttl) {
                r.mesh.visible = false;
                continue;
            }
            const progress = r.age / r.ttl;
            r.mesh.scale.setScalar(0.2 + 3.6 * progress);
            r.material.opacity = 0.43 * (1 - progress) * (1 - progress);
        }
    }
    setTokenDrop(x, z) {
        this.tokenDropAt.set(THREE.MathUtils.clamp(x, -14.8, 14.8), 0.9, THREE.MathUtils.clamp(z, -17.5, 17.5));
    }
    getTokenDrop() { return this.tokenDropAt.clone(); }
    getNearestInteraction(x, z, state) {
        const options = [];
        for (const i of this.interactions) {
            if (i.enabled && !i.enabled(state))
                continue;
            if (i.id === 'socket' && Math.abs(this.rotorAngle - state.rotorIndex * Math.PI / 2) > 0.07)
                continue;
            if (i.id === 'socket')
                this.rotor.updateWorldMatrix(true, true);
            const point = i.id === 'token' ? this.tokenDropAt : i.id === 'socket' ? this.rotorSocket.getWorldPosition(new THREE.Vector3()) : i;
            const dist = Math.hypot(x - point.x, z - point.z);
            if (dist <= i.radius)
                options.push({ interaction: i, distance: dist });
        }
        options.sort((a, b) => a.distance - b.distance);
        return options[0]?.interaction ?? null;
    }
    update(state, dt, elapsed, reducedMotion, playerPosition, yaw) {
        for (const p of this.doors) {
            p.material.uniforms.uEnabled.value = p.id !== 'PUBLISH' && isPortalActive(state) ? 1 : 0;
            p.material.uniforms.uTime.value = reducedMotion ? 0 : elapsed;
            p.signal.visible = p.id === 'PUBLISH' || isPortalActive(state);
        }
        if (this.crownLight) {
            const requested = state.linked ? 91 : 67;
            this.crownLight.intensity += (requested - this.crownLight.intensity) * Math.min(1, dt * 1.8);
        }
        this.updateEffects(dt, reducedMotion);
        if (!reducedMotion) {
            for (let i = 0; i < this.haloRings.length; i++) {
                const halo = this.haloRings[i];
                if (this.chamber === 2 && i === this.haloRings.length - 1)
                    continue;
                if (halo.type === 'Mesh')
                    halo.rotation.z += dt * 0.02 * (i % 2 ? 1 : -1);
                else
                    halo.rotation.y += dt * 0.023 * (i % 2 ? 1 : -1);
            }
            this.ambientParticles.rotation.y = Math.sin(elapsed * 0.06) * 0.018;
            this.oculus.rotation.y = Math.sin(elapsed * 0.047) * 0.025;
        }
        if (this.chamber === 2) {
            if (this.socketOrb)
                this.socketOrb.material = state.inserted ? this.mat.whiteGlow : this.mat.dark;
            const target = state.rotorIndex * Math.PI / 2;
            const speed = reducedMotion ? 1 : Math.min(1, dt * 3.4);
            this.rotorAngle += (target - this.rotorAngle) * speed;
            this.rotor.rotation.y = this.rotorAngle;
            if (state.carrying) {
                const hand = new THREE.Vector3(0.47, 1.32, -0.8).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
                this.token.position.copy(playerPosition).add(hand);
                this.token.rotation.y = -yaw + Math.sin(elapsed * 1.7) * 0.08;
                this.token.visible = true;
            }
            else if (state.inserted) {
                this.token.visible = false;
            }
            else {
                this.token.visible = true;
                this.token.position.copy(this.tokenDropAt);
                this.token.position.y += reducedMotion ? 0 : Math.sin(elapsed * 2.2) * 0.09;
                this.token.rotation.y = reducedMotion ? 0 : elapsed * 0.32;
            }
        }
        if (this.chamber === 3 && this.proofBulb) {
            const active = state.verified;
            this.proofBulb.material = active ? this.mat.whiteGlow : this.mat.dark;
            this.proofBeam.visible = active;
            const target = active ? 1 : 0;
            this.foldProgress += (target - this.foldProgress) * (reducedMotion ? 1 : Math.min(1, dt * 0.44));
            const eased = this.foldProgress * this.foldProgress * (3 - 2 * this.foldProgress);
            for (const [i, f] of this.folding.entries()) {
                f.group.rotation.z = f.openAngle * eased;
                f.group.rotation.y = (i % 2 ? 1 : -1) * eased * 0.09;
            }
        }
    }
    /** Render spatial previews from linked portals; disable surfaces to avoid recursion. */
    renderPreviews(renderer, playerCamera, state, frame) {
        if (!isPortalActive(state) || frame % this.budget.previewStride !== 0)
            return;
        const pair = this.doors.filter(d => d.id !== 'PUBLISH');
        if (pair.length !== 2)
            return;
        const visible = this.doors.map(p => p.surface.visible);
        const previousTarget = renderer.getRenderTarget();
        const previousXR = renderer.xr.enabled;
        const previousClear = renderer.getClearColor(new THREE.Color()).clone();
        const previousAlpha = renderer.getClearAlpha();
        try {
            for (const p of this.doors)
                p.surface.visible = false;
            renderer.xr.enabled = false;
            this.previewCamera.fov = playerCamera.fov;
            this.previewCamera.aspect = pair[0].target.width / pair[0].target.height;
            this.previewCamera.updateProjectionMatrix();
            for (let i = 0; i < 2; i++) {
                const from = pair[i], to = pair[1 - i];
                if (signedDepth(playerCamera.position.x, playerCamera.position.z, from.pose) < -0.35)
                    continue;
                // A portal behind the player cannot consume a second scene render.
                const toward = new THREE.Vector3(from.pose.x, 2.4, from.pose.z).sub(playerCamera.position);
                const distance = toward.length();
                const forward = playerCamera.getWorldDirection(new THREE.Vector3());
                if (distance > 30 || forward.dot(toward) < distance * 0.09)
                    continue;
                const euler = new THREE.Euler().setFromQuaternion(playerCamera.quaternion, 'YXZ');
                const pose = teleport({ x: playerCamera.position.x, z: playerCamera.position.z, yaw: euler.y, vx: 0, vz: 0 }, from.pose, to.pose, 0, true);
                this.previewCamera.position.set(pose.x, playerCamera.position.y, pose.z);
                this.previewCamera.rotation.order = 'YXZ';
                this.previewCamera.rotation.set(euler.x, pose.yaw, euler.z);
                this.previewCamera.updateMatrixWorld();
                renderer.setRenderTarget(from.target);
                renderer.setClearColor(this.chapter.backplate, 1);
                renderer.clear(true, true, true);
                renderer.render(this.scene, this.previewCamera);
            }
        }
        finally {
            renderer.setRenderTarget(previousTarget);
            renderer.setClearColor(previousClear, previousAlpha);
            renderer.xr.enabled = previousXR;
            this.doors.forEach((p, i) => { p.surface.visible = visible[i]; });
        }
    }
    dispose() {
        this.doors.forEach(door => door.target.dispose());
        this.ownedTextures.forEach(texture => texture.dispose());
        this.ownedGeometries.forEach(geo => geo.dispose());
        this.ownedMaterials.forEach(material => material.dispose());
        this.scene.clear();
    }
}
