/** Pure view state: cannot change gameplay success or its deterministic timing. */
export function victoryStage(state) {
    if (!state.victory)
        return 'hidden';
    if (state.signHasFallenAgain)
        return 'postscript';
    return state.victoryTime >= 6.1 ? 'epilogue' : 'proclamation';
}
