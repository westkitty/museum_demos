import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const dir='dist';
assert.ok(fs.existsSync(dir),'Run npm run build first');
const entries=[];
function walk(root){for(const e of fs.readdirSync(root,{withFileTypes:true})){const p=path.join(root,e.name);if(e.isDirectory())walk(p);else entries.push(p);}}
walk(dir);
assert.ok(entries.some(p=>p.endsWith('.js')),'No JS bundle was produced');
const html=fs.readFileSync('dist/index.html','utf8');
assert.ok(/assets\//.test(html),'Expected bundler-owned same-origin assets');
for(const p of entries.filter(p=>/\.(?:html|css|js)$/i.test(p))) {
  const data=fs.readFileSync(p,'utf8');
  assert.ok(!/https?:\/\/(?:fonts\.googleapis|fonts\.gstatic|cdn\.|unpkg|jsdelivr)/.test(data),`Remote runtime asset found: ${p}`);
  assert.ok(!/type=["']module["']\s+src=["']https?:/.test(data),`Remote runtime script in ${p}`);
}
console.log(`Offline runtime asset check passed: ${entries.length} packaged files; no remote asset URLs.`);
