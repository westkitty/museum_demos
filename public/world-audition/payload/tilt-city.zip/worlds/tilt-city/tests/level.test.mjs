import {test} from 'node:test';
import assert from 'node:assert/strict';
import {GESTURES,GATE_CENTERS,CHECKPOINT_X,LevelMachine,ROTATION_DURATION} from '../.test-compiled/domain.js';
import {PlayerPhysics,JUMP_SPEED} from '../.test-compiled/physics.js';

test('E19 has precisely the supplied four gesture to source-command pairs',()=>{
  assert.deepEqual(GESTURES.map(g=>[g.gesture,g.command]),[
    ['Tip forward','Next track'],['Tip back','Previous track'],
    ['Roll right','Volume up'],['Roll left','Volume down']]);
  assert.equal(GESTURES.length,4);
});
test('gates are sequential, proximity gated, grounded and correct gesture only',()=>{
  const l=new LevelMachine();
  assert.equal(l.request('forward',20,false),'not-grounded');
  assert.equal(l.request('forward',-8,true),'too-far');
  assert.equal(l.request('right',20,true),'wrong-gesture');
  assert.equal(l.request('forward',20,true),'started');
  assert.equal(l.request('forward',20,true),'in-motion');
  assert.equal(l.surfaces().length,8);
});
test('each animated gate resolves to an exact signed quarter-turn and solid bridge',()=>{
  const l=new LevelMachine();
  for(let i=0;i<4;i++){
    l.approach(CHECKPOINT_X[i]);
    assert.equal(l.request(GESTURES[i].id,CHECKPOINT_X[i],true),'started');
    let complete=null;
    for(let step=0;step<160;step++){
      const hit=l.tick(1/60);if(hit!==null)complete=hit;
    }
    assert.equal(complete,i);
    assert.equal(l.states[i].angle,GESTURES[i].rotationSign*Math.PI/2);
    const bridge=l.surfaces().find(f=>f.id===`bridge-${i}`);
    assert.ok(bridge);
    assert.ok(bridge.minX<GATE_CENTERS[i]&&bridge.maxX>GATE_CENTERS[i]);
  }
  assert.equal(l.activeGate,-1);
  assert.equal(l.request('left',140,true),'already-done');
  assert.ok(ROTATION_DURATION>0);
});
test('deterministic restart revokes all rotations, surfaces and checkpoint progress',()=>{
  const l=new LevelMachine();
  l.approach(20);l.request('forward',20,true);
  for(let i=0;i<100;i++)l.tick(1/60);
  assert.equal(l.unlockedCount,1);
  l.reset();
  assert.equal(l.unlockedCount,0);assert.equal(l.checkpointIndex,0);
  assert.equal(l.movingIndex,-1);assert.equal(l.complete,false);
  assert.equal(l.surfaces().length,8);assert.deepEqual(l.states.map(s=>s.angle),[0,0,0,0]);
});
test('player lands only on existing surfaces; disabled bridge is not fictional collision',()=>{
  const l=new LevelMachine(),p=new PlayerPhysics();
  p.reset(28);p.state.y=1;p.state.vy=-2;p.state.grounded=false;
  for(let i=0;i<45;i++)p.step(1/60,0,0,false,l.surfaces());
  assert.ok(p.state.y<-2);
  l.approach(20);l.request('forward',20,true);
  for(let i=0;i<100;i++)l.tick(1/60);
  p.reset(28);p.state.y=1;p.state.vy=-2;p.state.grounded=false;
  for(let i=0;i<40;i++)p.step(1/60,0,0,false,l.surfaces());
  assert.equal(p.state.y,0);assert.equal(p.state.grounded,true);
});
test('jump arc is bounded and returns safely to a stable static platform',()=>{
  const p=new PlayerPhysics(),l=new LevelMachine();
  const start=p.state.x;
  p.step(1/60,0,0,true,l.surfaces());
  assert.ok(p.state.vy<JUMP_SPEED&&p.state.vy>0);
  for(let i=0;i<100;i++)p.step(1/60,0,0,false,l.surfaces());
  assert.equal(p.state.y,0);assert.equal(p.state.x,start);assert.equal(p.state.grounded,true);
});
test('finish cannot fire before all four bridges are completed',()=>{
  const l=new LevelMachine();
  assert.equal(l.reachFinish(171,true),false);
  for(let i=0;i<4;i++){
    assert.equal(l.request(GESTURES[i].id,CHECKPOINT_X[i],true),'started');
    for(let n=0;n<100;n++)l.tick(1/60);
  }
  assert.equal(l.reachFinish(171,false),false);
  assert.equal(l.reachFinish(171,true),true);
  assert.equal(l.reachFinish(171,true),false);
});
