import * as THREE from 'three';
import { Input } from './input.js';
import { Visitor } from './visitor.js';
import { World } from './world.js';
import { START, GOAL_Z, PHASES, floorBelow, phaseIndexAt, checkpointFor } from './level.js';
import { advancePlayer } from './physics.js';
import { STANDALONE_ADAPTER } from './adapter.js';
export class MuseumPocketWorld {
    host;
    adapter;
    abort = new AbortController();
    input = null;
    world = null;
    visitor = null;
    renderer = null;
    camera = null;
    rafId = 0;
    lastFrame = 0;
    accumulator = 0;
    elapsed = 0;
    shownPhase = -1;
    revealTime = 0;
    playing = false;
    paused = false;
    completed = false;
    finishPanelShown = false;
    disposed = false;
    reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    highContrast = window.matchMedia('(forced-colors: active)').matches;
    qualityHigh = !window.matchMedia('(pointer: coarse)').matches && (window.devicePixelRatio || 1) <= 2;
    cameraLook = new THREE.Vector3(0, 2, 0);
    cameraDesired = new THREE.Vector3();
    cameraAim = new THREE.Vector3();
    footstepDistance = 0;
    player = { x: START.x, y: START.y, z: START.z, vx: 0, vz: 0, vy: 0, grounded: true };
    checkpoint = { x: START.x, y: START.y, z: START.z, phase: PHASES[0].id };
    F = 1 / 60;
    MAX_FRAME = 0.05;
    constructor(host, adapter = STANDALONE_ADAPTER) {
        this.host = host;
        this.adapter = adapter;
        const signal = this.abort.signal;
        const click = (selector, cb) => {
            const el = host.querySelector(selector);
            if (el)
                el.addEventListener('click', cb, { signal });
        };
        click('#enter-e09', () => this.enter());
        click('#restart-world', () => this.reset());
        click('#retry-world', () => this.reset());
        click('#view-overlook', () => this.viewOverlook());
        click('#resume-world', () => this.resume());
        click('#pause-world', () => this.togglePause());
        click('#exit-world', () => this.exit());
        click('#exit-from-pause', () => this.exit());
        click('#exit-from-finish', () => this.exit());
        click('#mock-return', () => this.mockReturn());
        click('#resume-from-portal', () => this.resume());
        click('#start-again', () => this.reset());
        click('#motion-toggle', () => this.toggleMotion());
        click('#contrast-toggle', () => this.toggleContrast());
        click('#quality-toggle', () => this.toggleQuality());
        click('#help-toggle', () => this.toggleHelp());
        click('#close-help', () => this.toggleHelp(false));
        window.addEventListener('keydown', e => {
            if (e.code !== 'Escape' || !this.playing || this.completed)
                return;
            e.preventDefault();
            if (this.isPortalOpen())
                return;
            if (this.element('help-sheet').classList.contains('is-visible')) {
                this.toggleHelp(false);
                return;
            }
            if (this.paused)
                this.resume();
            else
                this.pause();
        }, { signal });
        window.addEventListener('resize', () => this.resize(), { signal });
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.lastFrame = 0;
                this.input?.clear();
            }
        }, { signal });
        const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
        motion.addEventListener('change', e => { this.reducedMotion = e.matches; this.updateOptions(); }, { signal });
        host.classList.toggle('high-contrast', this.highContrast);
        this.updateOptions();
    }
    element(id) {
        const el = this.host.querySelector(`#${id}`);
        if (!el)
            throw new Error(`Missing required interface element: ${id}`);
        return el;
    }
    show(id, show) {
        const el = this.element(id);
        el.classList.toggle('is-visible', show);
        if (show) {
            el.removeAttribute('inert');
            el.setAttribute('aria-hidden', 'false');
        }
        else {
            el.setAttribute('inert', '');
            el.setAttribute('aria-hidden', 'true');
        }
    }
    announce(text) {
        const aria = this.element('announcer');
        aria.textContent = '';
        aria.textContent = text;
    }
    toast(message) {
        const el = this.element('toast');
        el.textContent = message;
        el.classList.add('show');
        el.dataset.until = String(this.elapsed + 4);
        this.announce(message);
    }
    isOverlayOpen() {
        return ['pause-sheet', 'finish-sheet', 'mock-portal', 'help-sheet'].some(x => this.element(x).classList.contains('is-visible'));
    }
    isPortalOpen() { return this.element('mock-portal').classList.contains('is-visible'); }
    enter() {
        if (this.disposed)
            return;
        if (!this.renderer) {
            try {
                this.initializeRenderer();
            }
            catch (err) {
                this.show('error-sheet', true);
                this.element('error-details').textContent = String(err instanceof Error ? err.message : err);
                this.element('enter-e09').setAttribute('disabled', '');
                return;
            }
        }
        this.show('entry-sheet', false);
        this.show('mock-portal', false);
        this.show('finish-sheet', false);
        this.show('pause-sheet', false);
        this.show('error-sheet', false);
        this.host.classList.add('active');
        this.resetState();
        this.playing = true;
        this.paused = false;
        this.adapter.onEnter?.();
        this.input?.clear();
        this.focusCanvas();
        this.rafId = requestAnimationFrame(this.frame);
    }
    initializeRenderer() {
        const slot = this.element('viewport');
        const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', alpha: false });
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.07;
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.qualityHigh ? 1.5 : 1.0));
        renderer.shadowMap.enabled = this.qualityHigh;
        renderer.domElement.setAttribute('role', 'img');
        renderer.domElement.setAttribute('aria-label', 'Third-person three-dimensional museum chronology platform course');
        renderer.domElement.tabIndex = 0;
        renderer.domElement.className = 'world-canvas';
        slot.append(renderer.domElement);
        this.renderer = renderer;
        this.camera = new THREE.PerspectiveCamera(63, 1, 0.1, 650);
        this.world = new World();
        this.world.setLowEffects(!this.qualityHigh);
        this.visitor = new Visitor();
        this.world.scene.add(this.visitor.group);
        this.input = new Input(this.host);
        renderer.domElement.addEventListener('webglcontextlost', e => {
            e.preventDefault();
            this.paused = true;
            this.toast('Graphics context lost. Waiting for the browser to restore it.');
        }, { signal: this.abort.signal });
        renderer.domElement.addEventListener('webglcontextrestored', () => {
            this.paused = false;
            this.lastFrame = 0;
            this.resize();
            this.toast('Graphics context restored.');
        }, { signal: this.abort.signal });
        this.resize();
    }
    resize() {
        if (!this.renderer || !this.camera)
            return;
        const rect = this.element('viewport').getBoundingClientRect();
        const width = Math.max(1, Math.round(rect.width)), height = Math.max(1, Math.round(rect.height));
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height, false);
    }
    resetState() {
        this.player = { x: START.x, y: START.y, z: START.z, vx: 0, vz: 0, vy: 0, grounded: true };
        this.checkpoint = { x: START.x, y: START.y, z: START.z, phase: PHASES[0].id };
        this.shownPhase = -1;
        this.elapsed = 0;
        this.accumulator = 0;
        this.revealTime = 0;
        this.lastFrame = 0;
        this.completed = false;
        this.finishPanelShown = false;
        this.footstepDistance = 0;
        if (this.camera) {
            this.camera.position.set(7, 8, 26);
            this.camera.fov = 63;
            this.camera.updateProjectionMatrix();
            this.cameraLook.set(0, 2, 0);
            this.camera.lookAt(this.cameraLook);
        }
        this.world?.resetVisuals();
        this.world?.setProgress(START.z);
        this.world?.update(0, this.reducedMotion);
        if (this.visitor)
            this.visitor.group.position.set(START.x, START.y, START.z);
        this.enterPhase(0);
    }
    reset() {
        if (this.disposed)
            return;
        if (!this.renderer) {
            this.enter();
            return;
        }
        this.show('finish-sheet', false);
        this.show('pause-sheet', false);
        this.show('mock-portal', false);
        this.host.classList.add('active');
        this.playing = true;
        this.paused = false;
        this.resetState();
        this.input?.clear();
        this.focusCanvas();
        if (!this.rafId)
            this.rafId = requestAnimationFrame(this.frame);
    }
    frame = (now) => {
        if (this.disposed || !this.playing) {
            this.rafId = 0;
            return;
        }
        if (!this.lastFrame)
            this.lastFrame = now;
        const dt = Math.min(this.MAX_FRAME, Math.max(0, (now - this.lastFrame) / 1000));
        this.lastFrame = now;
        const hidden = document.hidden;
        if (!this.paused && !hidden) {
            if (!this.completed) {
                this.accumulator = Math.min(this.accumulator + dt, 0.15);
                let steps = 0;
                while (this.accumulator >= this.F && steps < 5) {
                    this.step(this.F);
                    this.accumulator -= this.F;
                    steps++;
                }
            }
            this.elapsed += dt;
            if (this.completed && !this.finishPanelShown && this.elapsed >= this.revealTime)
                this.showFinishPanel();
        }
        this.world?.setProgress(this.player.z);
        this.world?.update(this.elapsed, this.reducedMotion);
        this.updateCamera(dt);
        if (this.visitor) {
            this.visitor.group.position.set(this.player.x, this.player.y, this.player.z);
            this.visitor.animate(dt, Math.hypot(this.player.vx, this.player.vz), !this.player.grounded, this.reducedMotion);
        }
        if (this.renderer && this.camera && this.world && !hidden && !this.paused) {
            this.renderer.render(this.world.scene, this.camera);
        }
        const t = this.element('toast');
        if (t.classList.contains('show') && this.elapsed > Number(t.dataset.until ?? Infinity))
            t.classList.remove('show');
        this.rafId = requestAnimationFrame(this.frame);
    };
    step(dt) {
        if (!this.input)
            return;
        const move = this.input.movement;
        const jump = this.input.takeJump();
        const result = advancePlayer(this.player, { ...move, jump }, dt);
        this.player = result.state;
        let player = this.player;
        if (result.jumped)
            this.world?.pulse(player.x, player.y, player.z, 'jump');
        if (result.landed)
            this.world?.pulse(player.x, player.y, player.z, 'land');
        if (result.fell) {
            this.player = { x: this.checkpoint.x, y: this.checkpoint.y, z: this.checkpoint.z, vx: 0, vz: 0, vy: 0, grounded: true };
            this.world?.pulse(this.player.x, this.player.y, this.player.z, 'recover');
            this.toast('The archive caught you. Returned to the last checkpoint.');
            player = this.player;
        }
        const phase = phaseIndexAt(player.z);
        if (phase !== this.shownPhase)
            this.enterPhase(phase);
        if (player.z <= GOAL_Z && Math.abs(player.x) <= 4.6 && player.y >= 4.0)
            this.complete();
        const moved = Math.hypot(player.vx, player.vz);
        if (player.grounded && moved > 2.4) {
            this.footstepDistance += moved * dt;
            if (this.footstepDistance >= 1.8) {
                this.footstepDistance = 0;
                this.world?.pulse(player.x, player.y, player.z, 'step');
            }
        }
        else if (!player.grounded)
            this.footstepDistance = 0;
        if (this.visitor && moved > 0.15) {
            const aim = Math.atan2(player.vx, -player.vz);
            const from = this.visitor.group.rotation.y;
            const delta = Math.atan2(Math.sin(aim - from), Math.cos(aim - from));
            this.visitor.group.rotation.y = from + delta * (1 - Math.exp(-dt * 12));
        }
        this.updateHud();
    }
    enterPhase(i) {
        this.shownPhase = i;
        const phase = PHASES[i];
        this.revealTime = this.elapsed + 3.6;
        if (i > 0) {
            this.world?.pulse(this.player.x, this.player.y, this.player.z, 'land');
            const cp = checkpointFor(phase.checkpointZ);
            // A checkpoint is only activated after crossing its source-grounded phase boundary.
            const supporting = floorBelow(this.player.x, phase.checkpointZ, 10, 0);
            this.checkpoint = { x: supporting?.x ?? cp.x, y: supporting?.top ?? cp.y, z: phase.checkpointZ, phase: phase.id };
            this.toast(`Checkpoint ${i + 1}/4 - ${phase.title}`);
            this.announce(`${phase.title}. ${phase.historicalNote}`);
        }
        else
            this.announce(`${phase.title}. ${phase.historicalNote}`);
        this.element('chapter-number').textContent = `0${i + 1} / 04`;
        this.element('chapter-title').textContent = phase.title;
        this.element('chapter-subtitle').textContent = phase.subtitle;
        this.element('historical-note').textContent = phase.historicalNote;
        this.host.style.setProperty('--phase-accent', phase.accent);
        Array.from(this.host.querySelectorAll('.phase-segment')).forEach((el, j) => el.classList.toggle('passed', j <= i));
        this.adapter.onPhase?.(phase.id);
    }
    updateHud() {
        const done = Math.round(THREE.MathUtils.clamp((START.z - this.player.z) / (START.z - GOAL_Z), 0, 1) * 100);
        this.element('distance-readout').textContent = `${done}% of course`;
        this.element('checkpoint-readout').textContent = `CHECKPOINT 0${Math.max(1, this.shownPhase + 1)}`;
    }
    updateCamera(dt) {
        if (!this.camera)
            return;
        const p = this.player;
        if (this.completed) {
            // The visual climax does not take input control or obscure the overlook.
            const desired = this.cameraDesired.set(p.x + 1.3, p.y + 11.5, p.z + 18.5);
            const alpha = this.reducedMotion ? 1 : 1 - Math.exp(-Math.min(.05, dt) * 1.18);
            this.camera.position.lerp(desired, alpha);
            this.cameraLook.lerp(this.cameraAim.set(0, p.y + 9, p.z - 70), alpha);
            this.camera.lookAt(this.cameraLook);
            const fov = 57;
            if (Math.abs(this.camera.fov - fov) > .05) {
                this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, fov, alpha);
                this.camera.updateProjectionMatrix();
            }
            return;
        }
        const cinematic = !this.reducedMotion && this.elapsed < this.revealTime;
        const ahead = cinematic ? 12.5 : 8.3;
        const desired = this.cameraDesired.set(p.x + (cinematic ? 9.5 : 5.2), p.y + (cinematic ? 10.4 : 6.5), p.z + (cinematic ? 15.5 : 13.2));
        const alpha = this.reducedMotion ? 1 : 1 - Math.exp(-Math.min(.05, dt) * 4.6);
        this.camera.position.lerp(desired, alpha);
        const aim = this.cameraAim.set(p.x, p.y + 2.45, p.z - ahead);
        this.cameraLook.lerp(aim, Math.min(1, alpha * 1.35));
        this.camera.lookAt(this.cameraLook);
        const fov = cinematic ? 67 : 62;
        if (Math.abs(this.camera.fov - fov) > .04) {
            this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, fov, alpha * .65);
            this.camera.updateProjectionMatrix();
        }
    }
    complete() {
        if (this.completed)
            return;
        this.completed = true;
        this.input?.clear();
        this.revealTime = this.elapsed + (this.reducedMotion ? 1.5 : 5.8);
        this.announce('You reached the overlook. Look ahead at the still-unfinished museum. The return menu will appear after the view.');
        this.adapter.onComplete?.();
    }
    showFinishPanel() {
        if (this.finishPanelShown)
            return;
        this.finishPanelShown = true;
        this.show('finish-sheet', true);
        this.element('finish-sheet').querySelector('button')?.focus();
        this.announce('The museum is still under construction. You may return, restart, or keep viewing the overlook.');
    }
    viewOverlook() {
        this.show('finish-sheet', false);
        this.focusCanvas();
        this.announce('Overlook view restored. Use Return to Museum in the header when ready.');
    }
    focusCanvas() { this.renderer?.domElement.focus({ preventScroll: true }); }
    togglePause() { if (!this.playing || this.completed)
        return; this.paused ? this.resume() : this.pause(); }
    pause() {
        this.paused = true;
        this.input?.clear();
        this.show('pause-sheet', true);
        this.element('resume-world').focus();
        this.announce('Course paused.');
    }
    resume() {
        this.show('pause-sheet', false);
        this.show('mock-portal', false);
        this.show('help-sheet', false);
        this.paused = false;
        this.lastFrame = 0;
        this.focusCanvas();
        this.announce('Course resumed.');
    }
    exit() {
        this.input?.clear();
        this.paused = true;
        const phase = PHASES[Math.max(0, this.shownPhase)].id;
        if (this.adapter.onExit) {
            this.adapter.onExit({ completed: this.completed, lastPhase: phase });
            return;
        }
        this.show('pause-sheet', false);
        this.show('finish-sheet', false);
        this.show('mock-portal', true);
        this.element('resume-from-portal').focus();
        this.announce('Mock museum return. This separate prototype has no actual museum URL.');
    }
    mockReturn() {
        this.show('mock-portal', false);
        this.show('entry-sheet', true);
        this.show('finish-sheet', false);
        this.show('pause-sheet', false);
        this.host.classList.remove('active');
        this.playing = false;
        this.paused = false;
        this.input?.clear();
        this.element('enter-e09').focus();
        if (this.rafId) {
            cancelAnimationFrame(this.rafId);
            this.rafId = 0;
        }
    }
    toggleMotion() { this.reducedMotion = !this.reducedMotion; this.updateOptions(); this.announce(`Reduced motion ${this.reducedMotion ? 'on' : 'off'}.`); }
    toggleContrast() { this.highContrast = !this.highContrast; this.host.classList.toggle('high-contrast', this.highContrast); this.updateOptions(); }
    toggleQuality() {
        this.qualityHigh = !this.qualityHigh;
        this.renderer?.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.qualityHigh ? 1.5 : 1.0));
        if (this.renderer)
            this.renderer.shadowMap.enabled = this.qualityHigh;
        this.world?.setLowEffects(!this.qualityHigh);
        this.resize();
        this.updateOptions();
        this.announce(`Scenic detail ${this.qualityHigh ? 'high' : 'economy'}. Movement and collision are unchanged.`);
    }
    updateOptions() {
        const btn = this.host.querySelector('#motion-toggle');
        if (btn)
            btn.setAttribute('aria-pressed', String(this.reducedMotion));
        const contrast = this.host.querySelector('#contrast-toggle');
        if (contrast)
            contrast.setAttribute('aria-pressed', String(this.highContrast));
        const detail = this.host.querySelector('#quality-toggle');
        if (detail) {
            detail.setAttribute('aria-pressed', String(this.qualityHigh));
            detail.textContent = this.qualityHigh ? 'DETAIL: HIGH' : 'DETAIL: ECO';
        }
    }
    toggleHelp(force) {
        const isOpen = this.element('help-sheet').classList.contains('is-visible');
        const show = typeof force === 'boolean' ? force : !isOpen;
        this.show('help-sheet', show);
        if (show) {
            this.paused = true;
            this.input?.clear();
            this.element('close-help').focus();
        }
        else {
            this.paused = false;
            this.focusCanvas();
        }
    }
    snapshot() {
        return { phase: PHASES[Math.max(this.shownPhase, 0)].id, position: { x: this.player.x, y: this.player.y, z: this.player.z }, completed: this.completed, playing: this.playing, rendererReady: !!this.renderer };
    }
    /** Explicit QA-only spatial hook, guarded by the query flag in main.ts. */
    debugTeleport(z) {
        if (!Number.isFinite(z))
            return;
        const x = 0, platform = floorBelow(x, z, 20, 0);
        if (!platform)
            return;
        this.player = { x, y: platform.top, z, vx: 0, vz: 0, vy: 0, grounded: true };
        const phase = phaseIndexAt(z);
        if (phase !== this.shownPhase)
            this.enterPhase(phase);
        this.world?.setProgress(z);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        this.playing = false;
        if (this.rafId)
            cancelAnimationFrame(this.rafId);
        this.abort.abort();
        this.input?.dispose();
        this.input = null;
        this.visitor?.group.removeFromParent();
        this.visitor?.dispose();
        this.visitor = null;
        this.world?.dispose();
        this.world = null;
        if (this.renderer) {
            this.renderer.dispose();
            this.renderer.forceContextLoss();
            this.renderer.domElement.remove();
            this.renderer = null;
        }
        this.camera = null;
        this.host.classList.remove('active');
    }
}
export function mountMuseumE09(host, adapter = STANDALONE_ADAPTER) {
    return new MuseumPocketWorld(host, adapter);
}
