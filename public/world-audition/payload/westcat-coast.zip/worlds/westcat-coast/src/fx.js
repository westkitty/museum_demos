/** Bounded, deterministic visual-only particles. No effect can alter physics. */
export const EFFECT_BUDGET = Object.freeze({high: 84, low: 18});
export const EFFECT_PRESETS = Object.freeze({
  jump: {count: 7, speed: 1.9, life: .42, hue: 'mint'},
  doublejump: {count: 15, speed: 3.0, life: .62, hue: 'gold'},
  walljump: {count: 11, speed: 2.4, life: .47, hue: 'mint'},
  land: {count: 8, speed: 1.4, life: .37, hue: 'cream'},
  checkpoint: {count: 22, speed: 3.2, life: .85, hue: 'mint'},
  collect: {count: 13, speed: 2.5, life: .58, hue: 'gold'},
  chase: {count: 26, speed: 3.5, life: .92, hue: 'rose'},
  finish: {count: 46, speed: 3.8, life: 1.25, hue: 'gold'},
  fall: {count: 10, speed: 2.0, life: .6, hue: 'cream'},
  owl: {count: 20, speed: 2.7, life: .72, hue: 'rose'},
});
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
export function createFxPool(capacity=EFFECT_BUDGET.high){
  return {items:Array.from({length:capacity},()=>({life:0,age:0,x:0,y:0,z:0,vx:0,vy:0,vz:0,scale:0,hue:'gold'})), cursor:0, emission:0};
}
/** Select a fixed number of particles with a low-tier cap. No allocation occurs per event. */
export function emitFx(pool,type,x,y,tier='high'){
  const preset=EFFECT_PRESETS[type];if(!preset)return 0;
  const budget=Math.min(pool.items.length,EFFECT_BUDGET[tier]??EFFECT_BUDGET.high);
  const count=Math.min(preset.count,tier==='low'?Math.ceil(preset.count*.33):preset.count,budget);
  for(let i=0;i<count;i++){
    const slot=pool.items[(pool.cursor+i)%budget];
    const seed=pool.emission*17.43+i*2.399;
    const angle=(i/count)*Math.PI*2 + (pool.emission%7)*.15;
    const power=.48+.52*(.5+.5*Math.sin(seed*4.1));
    slot.age=0;slot.life=preset.life*(.77+.23*Math.cos(seed)**2);
    slot.x=x;slot.y=y;slot.z=.75+(i%3)*.08;
    slot.vx=Math.cos(angle)*preset.speed*power;
    slot.vy=Math.sin(angle)*preset.speed*power+(type==='jump'||type==='doublejump'?.8:0);
    slot.vz=0;slot.scale=.065+.047*(i%3);slot.hue=preset.hue;
  }
  pool.cursor=(pool.cursor+count)%budget;pool.emission++;
  return count;
}
export function stepFx(pool,dt){
  if(!(dt>0))return;
  for(const p of pool.items){if(p.life<=0)continue;
    p.age+=dt;p.life=Math.max(0,p.life-dt);
    p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy-=2.8*dt;p.z+=p.vz*dt;
    p.vx*=Math.exp(-1.2*dt);
  }
}
export function activeFxCount(pool){return pool.items.reduce((sum,p)=>sum+(p.life>0?1:0),0);}
export function fxScale(p){return p.life>0?clamp(p.scale*Math.min(1,p.life*5),.001,.3):0;}
