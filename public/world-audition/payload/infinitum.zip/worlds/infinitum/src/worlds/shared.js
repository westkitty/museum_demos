import { seasonalLight } from '../core/seasons.js';
import * as THREE from 'three';
import { sunAmount, stormIntensity, isNight } from '../core/state.js';
import { TAU, clamp, lerp, mulberry32, material, disposeScene } from '../core/math.js';
import { ArtSky, softGlow } from './art.js';
export function labelObject(o, label, action) {
    o.userData.label = label;
    o.userData.action = action ?? '';
    return o;
}
export function decorStars(scene, count = 900, seed = 617) {
    const rng = mulberry32(seed);
    const a = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
        const az = rng() * TAU, y = rng() * 0.88 + 0.12, radius = 400 + rng() * 150;
        a[i * 3] = Math.cos(az) * radius * Math.sqrt(1 - y * y);
        a[i * 3 + 1] = y * radius;
        a[i * 3 + 2] = Math.sin(az) * radius * Math.sqrt(1 - y * y);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(a, 3));
    const m = new THREE.PointsMaterial({ color: 0xc3dbfa, size: 1.5, sizeAttenuation: false, transparent: true, opacity: 0.7, depthWrite: false, fog: false });
    const p = new THREE.Points(g, m);
    p.frustumCulled = false;
    scene.add(p);
    return m;
}
export function makeDust(scene, count, bounds, seed, color = 0xabc9ca) {
    const rng = mulberry32(seed), p = new Float32Array(count * 3), phase = new Float32Array(count);
    for (let i = 0; i < count; i++) {
        p[i * 3] = (rng() - 0.5) * bounds.x;
        p[i * 3 + 1] = rng() * bounds.y;
        p[i * 3 + 2] = (rng() - 0.5) * bounds.z;
        phase[i] = rng() * TAU;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(p, 3));
    const m = new THREE.PointsMaterial({ color, size: 0.12, transparent: true, opacity: 0.5, depthWrite: false });
    const o = new THREE.Points(g, m);
    o.frustumCulled = false;
    scene.add(o);
    return { o, update: (time, tiltX = 0) => {
            o.position.x = Math.sin(time * 0.12) * 0.45 + tiltX * 3;
            o.rotation.y = Math.sin(time * 0.06) * 0.03;
            m.opacity = 0.36 + Math.sin(time * 0.25 + phase[0]) * 0.1;
        } };
}
const shellVS = `
 varying vec3 vNormal; varying vec3 vEye; varying vec3 vPos;
 void main() {
   vec4 view = modelViewMatrix * vec4(position,1.);
   vNormal = normalize(normalMatrix * normal);
   vEye = normalize(-view.xyz); vPos = position;
   gl_Position = projectionMatrix * view;
 }
`;
const shellFS = `
 uniform float uTime; uniform float uCondense; uniform float uGravity;
 varying vec3 vNormal; varying vec3 vEye; varying vec3 vPos;
 float sdFilament(float x){return 1.-smoothstep(.003,.075,abs(x));}
 void main(){
   float ndotv=clamp(dot(normalize(vNormal),normalize(vEye)),0.,1.);
   float fres=pow(1.-ndotv,3.1);
   float rim=smoothstep(.11,.80,fres);
   float arc=sin(vPos.y*11.+sin(vPos.x*8.+uTime*.15)*1.7+uTime*.46);
   float filament=sdFilament(arc)*smoothstep(-.9,.25,vPos.y);
   float bead=pow(max(0.,sin(vPos.x*59.+vPos.y*34.)*sin(vPos.z*53.-vPos.y*28.)),9.);
   float caustic=pow(.5+.5*sin(vPos.x*17.-vPos.z*23.+uTime*.33),15.);
   vec3 col=mix(vec3(.08,.20,.25),vec3(.63,.89,.92),rim);
   col+=vec3(.24,.29,.27)*filament*.12;
   col+=vec3(.22,.34,.33)*(bead*uCondense*.76+caustic*.11);
   float alpha=.065+rim*.54+uCondense*bead*.21+abs(uGravity)*.02;
   gl_FragColor=vec4(col,clamp(alpha,0.,.86));
 }
`;
export class PortalDrop {
    group = new THREE.Group();
    shell;
    glass;
    preview;
    rim;
    uniforms = { uTime: { value: 0 }, uCondense: { value: 0 }, uGravity: { value: 0 } };
    constructor(texture, size, name) {
        // Pear silhouette rather than a perfect spherical crystal.
        const profile = [
            [0, -1.1], [.44, -1.07], [.77, -.86], [.91, -.42], [.90, .04], [.75, .43],
            [.56, .74], [.40, 1.02], [.19, 1.34], [.06, 1.54], [0, 1.59]
        ].map(([r, y]) => new THREE.Vector2(r, y));
        const g = new THREE.LatheGeometry(profile, 64, 0, TAU);
        g.computeVertexNormals();
        this.glass = new THREE.Mesh(g, new THREE.MeshPhysicalMaterial({
            color: 0xcdeefa, metalness: 0, roughness: 0.06, transmission: 0.9, thickness: 1.7,
            ior: 1.33, clearcoat: 1, clearcoatRoughness: 0.04, transparent: true,
            opacity: 0.44, depthWrite: false, side: THREE.DoubleSide
        }));
        this.glass.renderOrder = 2;
        this.shell = new THREE.Mesh(g.clone(), new THREE.ShaderMaterial({
            uniforms: this.uniforms, vertexShader: shellVS, fragmentShader: shellFS,
            transparent: true, depthWrite: false, side: THREE.FrontSide, blending: THREE.NormalBlending
        }));
        this.shell.renderOrder = 4;
        this.preview = new THREE.Mesh(new THREE.SphereGeometry(.77, 40, 24), new THREE.MeshBasicMaterial({
            map: texture, transparent: true, opacity: .92, depthWrite: false, side: THREE.FrontSide
        }));
        this.preview.scale.set(1, 1.15, .65);
        this.preview.position.y = -.03;
        this.preview.renderOrder = 1;
        this.rim = new THREE.Mesh(new THREE.TorusGeometry(.94, .012, 6, 72), new THREE.MeshBasicMaterial({ color: 0x9de1ef, transparent: true, opacity: .22, depthWrite: false }));
        this.rim.rotation.x = Math.PI / 2;
        this.rim.position.y = -.32;
        this.rim.renderOrder = 3;
        this.group.add(this.preview, this.glass, this.shell, this.rim);
        this.group.scale.setScalar(size);
        labelObject(this.group, name, 'portal');
        labelObject(this.shell, name, 'portal');
        labelObject(this.glass, name, 'portal');
    }
    update(time, state) {
        this.uniforms.uTime.value = time;
        this.uniforms.uCondense.value = stormIntensity(state.weather);
        this.uniforms.uGravity.value = Math.hypot(...state.gravity);
        this.group.rotation.z = state.gravity[0] * .26;
        this.group.rotation.x = state.gravity[1] * .21;
        this.preview.rotation.y = time * .025;
        const m = this.glass.material;
        m.roughness = lerp(m.roughness, .045 + stormIntensity(state.weather) * .19, .025);
    }
}
export function waterMaterial(color, alpha = .87) {
    // Procedural thin-film water: phase coherent ripples, grazing-angle reflection, rain rings.
    return new THREE.ShaderMaterial({
        uniforms: {
            uTime: { value: 0 }, uColor: { value: new THREE.Color(color) }, uAlpha: { value: alpha },
            uTide: { value: 0 }, uGravity: { value: new THREE.Vector2() }, uRain: { value: 0 }, uDay: { value: .7 }
        },
        vertexShader: `uniform float uTime;uniform vec2 uGravity;uniform float uRain;
      varying vec2 vUv;varying vec3 vPos;varying vec3 vEye;varying vec3 vNormal;
      void main(){vUv=uv;vPos=position;vec3 p=position;
        float wave=sin(position.x*.27+uTime*.95)*cos(position.z*.19+uTime*.72);
        float micro=sin(position.x*.81-position.z*.57+uTime*1.2)*.023;
        p.y+=wave*(.065+uRain*.09)+micro+dot(position.xz,uGravity)*.006;
        vec4 w=modelMatrix*vec4(p,1.);vEye=normalize(cameraPosition-w.xyz);
        vNormal=normalize(mat3(modelMatrix)*normal);
        gl_Position=projectionMatrix*viewMatrix*w;
      }`,
        fragmentShader: `uniform float uTime,uRain,uAlpha,uDay;uniform vec3 uColor;
      varying vec2 vUv;varying vec3 vPos;varying vec3 vEye;varying vec3 vNormal;
      void main(){
        float w1=sin(vPos.x*.81+uTime*1.46+sin(vPos.z*.41));
        float w2=cos(vPos.z*.69-uTime*.91+vPos.x*.29);
        float ripple=w1*w2;
        float disturbs=pow(max(0.,sin(vPos.x*3.2+uTime*10.3)*cos(vPos.z*3.7-uTime*9.5)),15.);
        vec3 n=normalize(vNormal+vec3(w1*.06,0.,w2*.065));
        float fres=pow(1.-abs(dot(normalize(vEye),n)),2.5);
        float sheen=pow(max(0.,.5+.5*cos(vPos.x*1.2+vPos.z*.7+uTime*1.2)),23.);
        float filament=pow(.5+.5*sin(vPos.z*1.1+vPos.x*.33+uTime*.8+ripple*.32),17.);
        vec3 ambient=mix(vec3(.055,.12,.17),vec3(.4,.55,.59),uDay*.85);
        vec3 base=uColor*(.78+.16*ripple);
        vec3 c=mix(base,ambient,fres*.62);
        c+=vec3(.21,.31,.31)*(sheen*.16+filament*.34);
        c+=vec3(.16,.23,.24)*disturbs*uRain*.7;
        gl_FragColor=vec4(c,clamp(uAlpha+fres*.08,0.,1.));
      }`,
        transparent: true, depthWrite: false, side: THREE.DoubleSide
    });
}
export class EnvironmentRig {
    scene;
    kind;
    sun = new THREE.DirectionalLight(0xffdfbd, 3.1);
    moon = new THREE.DirectionalLight(0x7eafff, .4);
    hemi = new THREE.HemisphereLight(0x8ca9c3, 0x132019, 1.0);
    stars;
    haze;
    sunMesh;
    moonMesh;
    sunHalo = null;
    moonHalo = null;
    clouds;
    precipitation;
    precipitationFall = 0;
    precipitationDrift = 0;
    sky;
    cloudMaterial;
    stormBolt = null;
    smoothWeather = { Clear: 1, Cloudy: 0, Rain: 0, Thunderstorm: 0, Snow: 0, Fog: 0 };
    constructor(scene, kind, quality) {
        this.scene = scene;
        this.kind = kind;
        scene.add(this.sun, this.moon, this.hemi);
        this.sky = new ArtSky(scene, kind === 2, quality === 'low');
        this.sun.position.set(-80, 120, -80);
        this.sun.castShadow = kind === 1;
        if (kind === 1) {
            this.sun.shadow.mapSize.set(quality === 'high' ? 2048 : quality === 'medium' ? 1024 : 512, quality === 'high' ? 2048 : quality === 'medium' ? 1024 : 512);
            this.sun.shadow.camera.left = -110;
            this.sun.shadow.camera.right = 110;
            this.sun.shadow.camera.top = 110;
            this.sun.shadow.camera.bottom = -110;
            this.sun.shadow.camera.near = .1;
            this.sun.shadow.camera.far = 400;
            this.sun.shadow.bias = -.0003;
        }
        this.haze = new THREE.FogExp2(0x172734, kind === 1 ? .004 : kind === 0 ? .007 : .003);
        scene.fog = this.haze;
        this.stars = decorStars(scene, quality === 'low' ? 550 : 1300, 2281);
        this.sunMesh = new THREE.Mesh(new THREE.SphereGeometry(kind === 1 ? 7 : 4, 20, 12), new THREE.MeshBasicMaterial({ color: 0xffd39a }));
        this.moonMesh = new THREE.Mesh(new THREE.SphereGeometry(kind === 1 ? 4.3 : 3, 20, 12), new THREE.MeshBasicMaterial({ color: 0xbbd4ea }));
        scene.add(this.sunMesh, this.moonMesh);
        if (quality !== 'low') {
            this.sunHalo = softGlow(0xe3b788, kind === 1 ? 85 : 58, .08);
            this.moonHalo = softGlow(0x9abddc, kind === 1 ? 59 : 46, .06);
            scene.add(this.sunHalo, this.moonHalo);
        }
        this.clouds = new THREE.Group();
        scene.add(this.clouds);
        this.cloudMaterial = new THREE.MeshBasicMaterial({ color: 0xb8c9ca, transparent: true, opacity: .42, depthWrite: false, fog: true });
        if (kind !== 0) {
            // Three independent lobes per cloud formation, batched into a single draw call.
            const rng = mulberry32(183);
            const g = new THREE.SphereGeometry(1, 9, 6);
            const formations = quality === 'low' ? 19 : quality === 'medium' ? 36 : 54;
            const clouds = new THREE.InstancedMesh(g, this.cloudMaterial, formations * 3), obj = new THREE.Object3D();
            for (let j = 0; j < formations; j++) {
                const x = (rng() - .5) * 220, z = (rng() - .5) * 230, y = kind === 1 ? 58 + rng() * 18 : 53 + rng() * 45;
                const w = 10 + rng() * 15;
                for (let k = 0; k < 3; k++) {
                    obj.position.set(x + (k - 1) * w * .58, y + (k === 1 ? 2 : 0), z + (k === 1 ? 2 : k === 2 ? 5 : -4));
                    obj.scale.set(w * (k === 1 ? 1 : .73), 3 + rng() * 2.7, 5 + rng() * 5);
                    obj.rotation.set(0, rng() * TAU, 0);
                    obj.updateMatrix();
                    clouds.setMatrixAt(j * 3 + k, obj.matrix);
                }
            }
            clouds.instanceMatrix.needsUpdate = true;
            clouds.computeBoundingSphere();
            this.clouds.add(clouds);
        }
        const n = quality === 'low' ? 400 : quality === 'medium' ? 900 : 1600;
        const drops = new Float32Array(n * 3), rng = mulberry32(1587);
        for (let i = 0; i < n; i++) {
            drops[i * 3] = (rng() - .5) * 90;
            drops[i * 3 + 1] = rng() * 50;
            drops[i * 3 + 2] = (rng() - .5) * 90;
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(drops, 3));
        this.precipitation = new THREE.Points(geo, new THREE.ShaderMaterial({
            uniforms: { uOpacity: { value: 0 }, uSnow: { value: 0 }, uColor: { value: new THREE.Color(0xbad5ed) },
                uFall: { value: 0 }, uDrift: { value: 0 } },
            transparent: true, depthWrite: false, fog: false,
            vertexShader: `uniform float uFall,uDrift;
        void main(){
          vec3 p=position;
          p.y=mod(mod(position.y-uFall,50.)+50.,50.);
          p.x=mod(mod(position.x+uDrift+45.,90.)+90.,90.)-45.;
          vec4 mv=modelViewMatrix*vec4(p,1.);
          gl_Position=projectionMatrix*mv;
          gl_PointSize=clamp(165./max(1.,-mv.z),2.5,10.);
        }`,
            fragmentShader: `uniform float uOpacity,uSnow;uniform vec3 uColor;void main(){vec2 p=gl_PointCoord-.5;
        float rain=1.-smoothstep(.14,.36,length(vec2(p.x*3.8,p.y*.8)));
        float flake=1.-smoothstep(.24,.48,length(p));
        float shape=mix(rain,flake,uSnow);gl_FragColor=vec4(uColor,shape*uOpacity);}`
        }));
        this.precipitation.frustumCulled = false;
        scene.add(this.precipitation);
        if (kind === 1) {
            const boltPoints = [[-9, 49, -5], [-5, 42, -7], [-8, 34, -5], [-1, 29, -9], [-5, 23, -4], [3, 14, -6], [0, 5, -7]]
                .map(([x, y, z]) => new THREE.Vector3(x, y, z));
            this.stormBolt = new THREE.Line(new THREE.BufferGeometry().setFromPoints(boltPoints), new THREE.LineBasicMaterial({ color: 0xd8eefd, transparent: true, opacity: 0, depthWrite: false, fog: false }));
            this.stormBolt.frustumCulled = false;
            scene.add(this.stormBolt);
        }
    }
    update(dt, elapsed, s, camera) {
        for (const w of Object.keys(this.smoothWeather))
            this.smoothWeather[w] = lerp(this.smoothWeather[w], s.weather === w ? 1 : 0, Math.min(1, dt * .65));
        const rain = this.smoothWeather.Rain * .7 + this.smoothWeather.Thunderstorm;
        const snow = this.smoothWeather.Snow;
        const fog = this.smoothWeather.Fog;
        const overcast = this.smoothWeather.Cloudy * .6 + rain * .8 + snow * .55 + fog * .4;
        const seasonal = seasonalLight(s);
        const daylight = sunAmount(s.time);
        const angle = (s.time - 6) / 24 * TAU;
        this.sun.position.set(Math.cos(angle) * 120, Math.sin(angle) * 140, -65);
        this.moon.position.set(-this.sun.position.x, -this.sun.position.y, -this.sun.position.z);
        this.sky.update(daylight, elapsed, overcast, this.sun.position);
        const sunPower = daylight * (1 - overcast * .63) * seasonal.intensity;
        this.sun.intensity = lerp(this.sun.intensity, (this.kind === 2 ? 1.35 : 3.0) * sunPower, .05);
        this.sun.color.setHSL(.075 + daylight * .04 + seasonal.warmth * .15, .50 + overcast * .12, .62);
        this.moon.intensity = .17 + (1 - daylight) * (this.kind === 2 ? 1.1 : .62);
        this.hemi.intensity = ((this.kind === 2 ? .82 : .45) + daylight * .65) * seasonal.intensity;
        this.hemi.color.setHSL(.59, .36, .3 + daylight * .40);
        this.sunMesh.position.copy(this.sun.position).multiplyScalar(1.8);
        this.moonMesh.position.copy(this.moon.position).multiplyScalar(1.8);
        this.sunMesh.visible = daylight > .03;
        this.moonMesh.visible = daylight < .98;
        if (this.sunHalo && this.moonHalo) {
            this.sunHalo.position.copy(this.sunMesh.position);
            this.moonHalo.position.copy(this.moonMesh.position);
            this.sunHalo.quaternion.copy(camera.quaternion);
            this.moonHalo.quaternion.copy(camera.quaternion);
            this.sunHalo.material.uniforms.uOpacity.value = daylight * (1 - overcast * .6) * .14;
            this.moonHalo.material.uniforms.uOpacity.value = (1 - daylight) * .10;
            this.sunHalo.visible = daylight > .03;
            this.moonHalo.visible = daylight < .98;
        }
        this.stars.opacity = clamp((1 - daylight) * .94 + (this.kind === 2 ? .3 : 0), 0, 1);
        const bg = new THREE.Color(0x071018).lerp(new THREE.Color(this.kind === 2 ? 0x29455b : 0x7ba5b9), daylight * .83);
        bg.lerp(new THREE.Color(0x26323d), overcast * .4);
        if (s.season === 'Winter')
            bg.lerp(new THREE.Color(0x718ca5), daylight * .12);
        if (s.season === 'Autumn')
            bg.lerp(new THREE.Color(0x92745b), daylight * .09);
        this.scene.background = bg;
        this.haze.color.copy(bg);
        this.haze.density = (this.kind === 1 ? .004 : this.kind === 2 ? .003 : .007) + fog * .029 + overcast * .0016;
        this.cloudMaterial.opacity = (this.kind === 2 ? .17 : .11) + overcast * .38;
        this.clouds.position.x = Math.sin(elapsed * .025) * 5 + (elapsed * (s.reducedMotion ? .04 : .17)) % 20;
        this.clouds.position.z = s.gravity[1] * 3;
        const precipitation = this.precipitation.material;
        precipitation.uniforms.uOpacity.value = clamp(rain + snow, 0, 1) * .65;
        precipitation.uniforms.uSnow.value = clamp(snow, 0, 1);
        precipitation.uniforms.uColor.value.set(snow > .4 ? 0xdcebf8 : 0x95bdd9);
        if (rain + snow > .005) {
            // GPU translation replaces thousands of per-frame BufferAttribute writes.
            // Counters advance incrementally so changes to weather/gravity are continuous.
            const motion = s.reducedMotion ? .22 : 1;
            this.precipitationFall += dt * (rain > snow ? 19 : 3.6) * motion;
            this.precipitationDrift += dt * (s.gravity[0] * 1.4 + .4) * motion;
            precipitation.uniforms.uFall.value = this.precipitationFall;
            precipitation.uniforms.uDrift.value = this.precipitationDrift;
            this.precipitation.position.copy(camera.position);
            this.precipitation.position.y = camera.position.y - 16;
        }
        // Localized sky lightning with a slow envelope; no full-screen strobe or mandatory flashing cues.
        if (this.stormBolt) {
            const phase = elapsed % 18;
            const glow = Math.max(0, 1 - Math.abs(phase - 2.55) / .58) * this.smoothWeather.Thunderstorm;
            this.stormBolt.material.opacity = glow * .75;
            this.stormBolt.position.copy(camera.position).add(new THREE.Vector3(28, 14, -83));
        }
        // No sudden full-screen lightning; gently illuminated storm clouds instead.
        if (this.smoothWeather.Thunderstorm > .5)
            this.sun.intensity += Math.max(0, Math.sin(elapsed * 1.1) * .12) * this.smoothWeather.Thunderstorm;
    }
    isNight(s) { return isNight(s.time); }
    dispose() { disposeScene(this.scene); }
}
export function addArch(parent, at, radius, height, color = 0xb4a887, segments = 10) {
    const mat = material(color, .83, .08);
    const left = new THREE.Mesh(new THREE.CylinderGeometry(.55, .8, height, 8), mat);
    const right = left.clone();
    left.position.set(at.x - radius, at.y + height / 2, at.z);
    right.position.set(at.x + radius, at.y + height / 2, at.z);
    const arcPoints = [];
    for (let i = 0; i <= segments; i++) {
        const a = Math.PI - i / segments * Math.PI;
        arcPoints.push(new THREE.Vector3(at.x + Math.cos(a) * radius, at.y + height + Math.sin(a) * radius * .61, at.z));
    }
    const cap = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(arcPoints), segments * 3, .56, 7), mat);
    parent.add(left, right, cap);
    return [left, right, cap];
}
