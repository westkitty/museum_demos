/** Local opt-in WebAudio score. Three worlds share one quiet tonal family. */
export class WeatherAudio {
    enabled = false;
    ctx = null;
    worldGains = [];
    windGain = null;
    waterGain = null;
    windFilter = null;
    waterFilter = null;
    lastStormCycle = -1;
    count = 0;
    voices = 0;
    async setEnabled(enabled) {
        this.enabled = enabled;
        if (!enabled) {
            try {
                await this.ctx?.suspend();
            }
            catch { /* no sound */ }
            return;
        }
        if (typeof AudioContext === 'undefined') {
            this.enabled = false;
            return;
        }
        if (!this.ctx) {
            this.ctx = new AudioContext();
            this.build(this.ctx);
        }
        try {
            await this.ctx.resume();
        }
        catch {
            this.enabled = false;
        }
    }
    build(ctx) {
        const master = ctx.createGain();
        master.gain.value = .6;
        master.connect(ctx.destination);
        const frequencies = [[83, 124.5], [131, 196], [98, 147]];
        frequencies.forEach((frequencies, i) => {
            const gain = ctx.createGain();
            gain.gain.value = 0;
            gain.connect(master);
            this.worldGains.push(gain);
            frequencies.forEach((frequency, j) => {
                const osc = ctx.createOscillator();
                osc.type = i === 2 ? 'sine' : i === 1 ? 'triangle' : 'sine';
                osc.frequency.value = frequency;
                const low = ctx.createGain();
                low.gain.value = j === 0 ? .11 : .05;
                osc.connect(low).connect(gain);
                osc.start();
            });
        });
        const duration = 2, buffer = ctx.createBuffer(1, ctx.sampleRate * duration, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        let seed = 8573, lo = 0;
        for (let i = 0; i < data.length; i++) {
            seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
            const white = (seed / 4294967296) * 2 - 1;
            lo = lo * .82 + white * .18;
            data[i] = lo * .75 + white * .25;
        }
        const wind = ctx.createBufferSource();
        wind.buffer = buffer;
        wind.loop = true;
        this.windFilter = ctx.createBiquadFilter();
        this.windFilter.type = 'lowpass';
        this.windFilter.frequency.value = 500;
        this.windGain = ctx.createGain();
        this.windGain.gain.value = 0;
        wind.connect(this.windFilter).connect(this.windGain).connect(master);
        wind.start();
        const water = ctx.createBufferSource();
        water.buffer = buffer;
        water.loop = true;
        this.waterFilter = ctx.createBiquadFilter();
        this.waterFilter.type = 'bandpass';
        this.waterFilter.frequency.value = 1000;
        this.waterFilter.Q.value = .42;
        this.waterGain = ctx.createGain();
        this.waterGain.gain.value = 0;
        water.connect(this.waterFilter).connect(this.waterGain).connect(master);
        water.start();
    }
    tick(elapsed, weather, world, time, position) {
        const ctx = this.ctx;
        if (!this.enabled || !ctx || ctx.state !== 'running')
            return;
        const now = ctx.currentTime;
        this.worldGains.forEach((gain, i) => {
            const night = (time < 6 || time > 20) ? 1.18 : 1;
            const vol = i === world ? (world === 0 ? .35 : world === 1 ? .32 : .48) * night : 0;
            gain.gain.setTargetAtTime(vol, now, .85);
        });
        const storm = weather === 'Thunderstorm' ? 1 : weather === 'Rain' ? .65 : weather === 'Snow' ? .21 : 0;
        const windTarget = world === 0 ? .006 : world === 1 ? .035 : .013;
        const waterDist = Math.hypot(position.x + 12, position.y - 16, position.z + 37);
        const waterfallProximity = world === 1 ? Math.max(0, 1 - waterDist / 105) : 0;
        this.windGain?.gain.setTargetAtTime(windTarget + storm * .12, now, .75);
        this.waterGain?.gain.setTargetAtTime(world === 1 ? .035 + waterfallProximity * .20 + storm * .06 : world === 2 ? .037 : .009, now, .95);
        this.windFilter?.frequency.setTargetAtTime(weather === 'Fog' ? 210 : weather === 'Snow' ? 340 : world === 2 ? 460 : storm > 0 ? 940 : 560, now, 1.0);
        this.waterFilter?.frequency.setTargetAtTime(world === 1 ? 1100 : world === 2 ? 510 : 370, now, .8);
        if (weather === 'Thunderstorm') {
            const cycle = Math.floor(elapsed / 18), phase = elapsed % 18;
            if (cycle !== this.lastStormCycle && phase > 2.9 && phase < 3.13) {
                this.lastStormCycle = cycle;
                this.count++;
                this.playThunder();
            }
        }
    }
    cue(world, magnitude = 1) {
        const ctx = this.ctx;
        if (!this.enabled || !ctx || ctx.state !== 'running' || this.voices >= 7)
            return;
        const note = [174.6, 196, 261.6][world], t = ctx.currentTime;
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(note * (magnitude > 3 ? 2 : 1), t);
        osc.frequency.exponentialRampToValueAtTime(note * .79 * (magnitude > 3 ? 2 : 1), t + .42);
        const env = ctx.createGain();
        env.gain.setValueAtTime(.0001, t);
        env.gain.exponentialRampToValueAtTime(Math.min(.1, .02 + magnitude * .013), t + .02);
        env.gain.exponentialRampToValueAtTime(.0001, t + .65);
        osc.connect(env).connect(ctx.destination);
        this.voices++;
        osc.start(t);
        osc.stop(t + .68);
        osc.onended = () => { this.voices--; osc.disconnect(); env.disconnect(); };
    }
    playThunder() {
        const ctx = this.ctx;
        if (!ctx || ctx.state !== 'running')
            return;
        const duration = 3.1, n = Math.floor(ctx.sampleRate * duration), buffer = ctx.createBuffer(1, n, ctx.sampleRate), data = buffer.getChannelData(0);
        let seed = 1237 + this.count * 7919, low = 0;
        for (let i = 0; i < n; i++) {
            seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
            const white = (seed / 4294967296) * 2 - 1;
            low = low * .97 + white * .03;
            const t = i / ctx.sampleRate, env = (1 - Math.exp(-t * 9)) * Math.pow(Math.max(0, 1 - t / duration), 1.75);
            data[i] = low * env;
        }
        const src = ctx.createBufferSource();
        src.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 240;
        const gain = ctx.createGain();
        gain.gain.value = .23;
        src.connect(filter).connect(gain).connect(ctx.destination);
        src.start();
        src.onended = () => { src.disconnect(); filter.disconnect(); gain.disconnect(); };
    }
    dispose() { void this.ctx?.close(); this.ctx = null; this.worldGains = []; this.windGain = null; this.waterGain = null; }
}
