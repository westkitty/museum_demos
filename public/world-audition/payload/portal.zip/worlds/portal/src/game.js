import * as THREE from 'three';
import { initialState, transition, objective, phaseLabels } from './puzzle.js';
import { selectVisualBudget } from './visual.js';
import { FacilityWorld } from './world.js';
import { overlapsCircle } from './levelGeometry.js';
import { movementVector, viewForward } from './cameraMath.js';
import { approachingPortal, teleport, signedDepth } from './portalMath.js';
const PLAYER_RADIUS = 0.33;
const PLAYER_HEIGHT = 1.82;
const EYE_HEIGHT = 1.64;
const MAX_FALL = -22;
const WALK_SPEED = 6.4;
const GRAVITY = 22;
const JUMP_VELOCITY = 8.1;
const FIXED_STEP = 1 / 60;
export class Game {
    state = { current: initialState(1) };
    renderer;
    visualBudget;
    camera = new THREE.PerspectiveCamera(77, 1, 0.08, 180);
    world;
    hooks;
    canvasHost;
    movement = { forward: false, back: false, left: false, right: false };
    horizontal = new THREE.Vector3(0, 0, 0);
    position = new THREE.Vector3(-8, 0, 12);
    previous = this.position.clone();
    yaw = 0;
    pitch = -0.035;
    verticalSpeed = 0;
    grounded = true;
    jumpQueued = false;
    interactQueued = false;
    isActive = false;
    reducedMotion = false;
    accumulator = 0;
    lastTime = 0;
    elapsed = 0;
    frameCount = 0;
    cooldown = 0;
    deniedCooldown = 0;
    lastContext = '';
    raf = null;
    resizeObserver;
    constructor(host, hooks) {
        this.hooks = hooks;
        this.canvasHost = host;
        this.visualBudget = selectVisualBudget(Math.max(host.clientWidth, window.innerWidth), Math.max(host.clientHeight, window.innerHeight), window.devicePixelRatio || 1, window.matchMedia('(pointer:coarse)').matches);
        try {
            this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
        }
        catch (error) {
            hooks.onError(`WebGL could not initialize: ${String(error)}`);
            throw error;
        }
        this.renderer.setPixelRatio(this.visualBudget.pixelRatio);
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.09;
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.renderer.info.autoReset = true;
        this.renderer.domElement.className = 'game-canvas';
        this.renderer.domElement.setAttribute('aria-label', 'First-person portal puzzle chamber viewport');
        host.append(this.renderer.domElement);
        this.camera.rotation.order = 'YXZ';
        this.world = new FacilityWorld(1, this.visualBudget);
        this.resizeObserver = new ResizeObserver(() => this.resize());
        this.resizeObserver.observe(host);
        this.resize();
        this.updateCamera(1);
        this.publishState();
    }
    get canvas() { return this.renderer.domElement; }
    get playing() { return this.isActive; }
    get currentPosition() { return this.position.clone(); }
    get currentYaw() { return this.yaw; }
    setReducedMotion(reduced) { this.reducedMotion = reduced; }
    start() {
        if (!this.isActive) {
            this.isActive = true;
            this.lastTime = performance.now();
            this.accumulator = 0;
            if (this.raf === null)
                this.raf = requestAnimationFrame(this.tick);
        }
        this.publishState();
    }
    pause() {
        this.isActive = false;
        for (const key of Object.keys(this.movement))
            this.movement[key] = false;
        this.jumpQueued = false;
        this.interactQueued = false;
        this.lastContext = '';
        this.hooks.onContext(null);
    }
    setMove(dir, active) { this.movement[dir] = active; }
    jump() { this.jumpQueued = true; }
    interact() { this.interactQueued = true; }
    turn(dx, dy) {
        if (!this.isActive)
            return;
        this.yaw -= dx * 0.0023;
        this.pitch = THREE.MathUtils.clamp(this.pitch - dy * 0.0023, -1.32, 1.32);
    }
    keyboardTurn(dx, dy) {
        if (!this.isActive)
            return;
        this.yaw += dx;
        this.pitch = THREE.MathUtils.clamp(this.pitch + dy, -1.32, 1.32);
    }
    restoreCheckpoint() {
        const result = transition(this.state.current, 'RESET');
        this.state.current = result.state;
        this.enterChamber(this.state.current.chamber);
        this.say(result.message);
    }
    restart() {
        this.state.current = initialState(1);
        this.enterChamber(1);
        this.say('New inspection. New evidence. Same suspicious doors.');
    }
    enterChamber(chamber) {
        const prior = this.world;
        this.world = new FacilityWorld(chamber, this.visualBudget);
        prior.dispose();
        this.position.set(-8, 0, 12);
        this.previous.copy(this.position);
        this.horizontal.set(0, 0, 0);
        this.yaw = 0;
        this.pitch = -0.045;
        this.verticalSpeed = 0;
        this.grounded = true;
        this.cooldown = 0.75;
        this.deniedCooldown = 0;
        this.lastContext = '';
        this.updateCamera(1);
        this.publishState();
        this.hooks.onStage(chamber);
    }
    publishState() {
        const s = this.state.current;
        this.hooks.onState(s, objective(s), phaseLabels(s));
    }
    say(message) { this.hooks.onHint(message); }
    doAction(action) {
        const old = this.state.current;
        const r = transition(old, action);
        if (!r.accepted) {
            this.say(r.message);
            return;
        }
        this.state.current = r.state;
        this.say(r.message);
        if (r.event !== 'advance' && r.event !== 'victory') {
            this.world.react(r.event, action, this.position, this.reducedMotion);
            this.hooks.onVisualCue?.(r.event);
        }
        if (r.event === 'advance') {
            this.enterChamber(r.state.chamber);
        }
        else if (r.event === 'victory') {
            this.hooks.onVictory();
            this.pause();
        }
        else {
            this.publishState();
        }
    }
    handleInteract() {
        const s = this.state.current;
        const nearest = this.world.getNearestInteraction(this.position.x, this.position.z, s);
        if (nearest) {
            this.doAction(nearest.action);
            return;
        }
        // The single Interact key drops a carried token when no station is nearby.
        if (s.chamber === 2 && s.carrying) {
            const { x: fx, z: fz } = viewForward(this.yaw);
            const x = this.position.x + fx * 1.2, z = this.position.z + fz * 1.2;
            if (!this.isColliding(x, z, this.position.y)) {
                this.world.setTokenDrop(x, z);
                this.doAction('DROP_TOKEN');
            }
            else
                this.say('Place the token in clear floor space first.');
            return;
        }
        this.say('No operative control within reach. The architecture seems disappointed.');
    }
    isColliding(x, z, y) {
        for (const o of this.world.obstacles) {
            if (y < o.maxY && y + PLAYER_HEIGHT > 0 && overlapsCircle(o, x, z, PLAYER_RADIUS))
                return true;
        }
        return false;
    }
    slideAxis(axis, delta) {
        if (Math.abs(delta) < 1e-8)
            return;
        const candidate = this.position.clone();
        candidate[axis] += delta;
        for (const o of this.world.obstacles) {
            if (candidate.y >= o.maxY || candidate.y + PLAYER_HEIGHT <= 0)
                continue;
            if (candidate.x + PLAYER_RADIUS <= o.minX || candidate.x - PLAYER_RADIUS >= o.maxX ||
                candidate.z + PLAYER_RADIUS <= o.minZ || candidate.z - PLAYER_RADIUS >= o.maxZ)
                continue;
            if (axis === 'x') {
                if (delta > 0)
                    candidate.x = Math.min(candidate.x, o.minX - PLAYER_RADIUS);
                else
                    candidate.x = Math.max(candidate.x, o.maxX + PLAYER_RADIUS);
                this.horizontal.x = 0;
            }
            else {
                if (delta > 0)
                    candidate.z = Math.min(candidate.z, o.minZ - PLAYER_RADIUS);
                else
                    candidate.z = Math.max(candidate.z, o.maxZ + PLAYER_RADIUS);
                this.horizontal.z = 0;
            }
        }
        this.position[axis] = candidate[axis];
    }
    handlePortalCrossing(nextX, nextZ) {
        if (this.cooldown > 0)
            return false;
        const linked = this.world.doors.filter(d => d.id !== 'PUBLISH');
        if (linked.length !== 2)
            return false;
        const s = this.state.current;
        if (!s.linked)
            return false;
        for (let i = 0; i < linked.length; i++) {
            const from = linked[i], to = linked[1 - i];
            if (!approachingPortal(this.position, { x: nextX, z: nextZ }, from.pose))
                continue;
            if (this.position.y > 2.9)
                continue;
            const out = teleport({ x: nextX, z: nextZ, yaw: this.yaw, vx: this.horizontal.x, vz: this.horizontal.z }, from.pose, to.pose);
            if (this.isColliding(out.x, out.z, this.position.y)) {
                this.say('Destination clearance failed. Portal transport withheld.');
                return false;
            }
            this.position.set(out.x, this.position.y, out.z);
            this.previous.copy(this.position);
            this.horizontal.set(out.vx, 0, out.vz);
            this.yaw = out.yaw;
            this.cooldown = 0.44;
            this.doAction('TRAVERSE');
            return true;
        }
        return false;
    }
    checkForbiddenApproach() {
        if (this.world.chamber !== 3 || this.deniedCooldown > 0)
            return;
        const p = this.world.doors.find(d => d.id === 'PUBLISH');
        if (!p)
            return;
        if (Math.abs(this.position.x - p.pose.x) < 1.85 &&
            signedDepth(this.position.x, this.position.z, p.pose) > 0.48 &&
            signedDepth(this.position.x, this.position.z, p.pose) < 1.13) {
            this.deniedCooldown = 4.0;
            this.doAction('PUBLISH');
        }
    }
    simulate(dt) {
        if (this.cooldown > 0)
            this.cooldown -= dt;
        if (this.deniedCooldown > 0)
            this.deniedCooldown -= dt;
        this.previous.copy(this.position);
        const strafe = (this.movement.right ? 1 : 0) - (this.movement.left ? 1 : 0);
        const forward = (this.movement.forward ? 1 : 0) - (this.movement.back ? 1 : 0);
        const { x, z } = movementVector(this.yaw, strafe, forward);
        const follow = 1 - Math.exp(-dt * (this.grounded ? 15.5 : 8.1));
        this.horizontal.x += (x * WALK_SPEED - this.horizontal.x) * follow;
        this.horizontal.z += (z * WALK_SPEED - this.horizontal.z) * follow;
        if (this.jumpQueued) {
            if (this.grounded) {
                this.verticalSpeed = JUMP_VELOCITY;
                this.grounded = false;
            }
            this.jumpQueued = false;
        }
        this.verticalSpeed = Math.max(MAX_FALL, this.verticalSpeed - GRAVITY * dt);
        this.position.y += this.verticalSpeed * dt;
        if (this.position.y <= 0) {
            this.position.y = 0;
            this.verticalSpeed = 0;
            this.grounded = true;
        }
        const nextX = this.position.x + this.horizontal.x * dt;
        const nextZ = this.position.z + this.horizontal.z * dt;
        if (!this.handlePortalCrossing(nextX, nextZ)) {
            this.slideAxis('x', this.horizontal.x * dt);
            this.slideAxis('z', this.horizontal.z * dt);
        }
        this.checkForbiddenApproach();
        if (this.interactQueued) {
            this.interactQueued = false;
            this.handleInteract();
        }
    }
    updateCamera(alpha) {
        const q = Math.max(0, Math.min(1, alpha));
        const x = THREE.MathUtils.lerp(this.previous.x, this.position.x, q);
        const y = THREE.MathUtils.lerp(this.previous.y, this.position.y, q);
        const z = THREE.MathUtils.lerp(this.previous.z, this.position.z, q);
        // Tiny, presentation-only gait motion. No physics transform or input latency.
        const locomotion = this.grounded && this.isActive ? Math.min(1, this.horizontal.length() / WALK_SPEED) : 0;
        const bob = this.reducedMotion ? 0 : Math.sin(this.elapsed * 10.2) * 0.014 * locomotion;
        this.camera.position.set(x, y + EYE_HEIGHT + bob, z);
        this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
        this.camera.updateMatrixWorld();
    }
    tick = (now) => {
        this.raf = null;
        if (!this.isActive)
            return;
        const frameDt = Math.min(0.06, Math.max(0, (now - this.lastTime) / 1000));
        this.lastTime = now;
        this.accumulator += frameDt;
        let steps = 0;
        while (this.accumulator >= FIXED_STEP && steps < 5 && this.isActive) {
            this.simulate(FIXED_STEP);
            this.accumulator -= FIXED_STEP;
            steps++;
            this.elapsed += FIXED_STEP;
        }
        if (steps === 5)
            this.accumulator = 0;
        const alpha = this.accumulator / FIXED_STEP;
        this.updateCamera(alpha);
        this.world.update(this.state.current, frameDt, this.elapsed, this.reducedMotion, this.position, this.yaw);
        this.world.renderPreviews(this.renderer, this.camera, this.state.current, this.frameCount);
        this.renderer.render(this.world.scene, this.camera);
        if (this.frameCount % 11 === 0) {
            const near = this.world.getNearestInteraction(this.position.x, this.position.z, this.state.current);
            let title = near?.title ?? null;
            if (this.state.current.chamber === 2 && this.state.current.carrying && !near)
                title = 'Place synthetic token';
            const id = title ?? '';
            if (id !== this.lastContext) {
                this.lastContext = id;
                this.hooks.onContext(title);
            }
        }
        this.frameCount++;
        if (this.isActive)
            this.raf = requestAnimationFrame(this.tick);
    };
    resize() {
        const w = Math.max(1, this.canvasHost.clientWidth), h = Math.max(1, this.canvasHost.clientHeight);
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        const adaptive = selectVisualBudget(w, h, window.devicePixelRatio || 1, window.matchMedia('(pointer:coarse)').matches);
        this.renderer.setPixelRatio(adaptive.pixelRatio);
        this.renderer.setSize(w, h, false);
    }
    destroy() {
        this.pause();
        if (this.raf !== null) {
            cancelAnimationFrame(this.raf);
            this.raf = null;
        }
        this.resizeObserver.disconnect();
        this.world.dispose();
        this.renderer.dispose();
        this.renderer.forceContextLoss();
        this.renderer.domElement.remove();
    }
}
