import * as THREE from 'three';
function rng(seed) {
    let value = seed >>> 0;
    return () => ((value = (Math.imul(value, 1664525) + 1013904223) >>> 0) / 4294967296);
}
const standard = (color, metalness = .1, roughness = .7, emissive = 0, strength = 0) => new THREE.MeshStandardMaterial({ color, metalness, roughness, emissive, emissiveIntensity: strength });
const glow = (color, opacity = .7) => new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity, depthWrite: opacity >= 1, side: THREE.DoubleSide });
const mesh = (parent, geo, mat, x = 0, y = 0, z = 0) => {
    const o = new THREE.Mesh(geo, mat);
    o.position.set(x, y, z);
    o.castShadow = false;
    o.receiveShadow = false;
    parent.add(o);
    return o;
};
const tube = (parent, positions, radius, color, alpha = 1) => mesh(parent, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(positions), Math.max(28, positions.length * 6), radius, 6, false), glow(color, alpha));
const sphere = (parent, r, color, x, y, z, detail = 1) => mesh(parent, new THREE.IcosahedronGeometry(r, detail), standard(color, .12, .58), x, y, z);
const orbit = (parent, radius, tubeSize, color, x = 0, y = 0, z = 0, opacity = 1) => mesh(parent, new THREE.TorusGeometry(radius, tubeSize, 6, 96), glow(color, opacity), x, y, z);
function instance(parent, geo, mat, data) {
    const out = new THREE.InstancedMesh(geo, mat, data.length);
    const scratch = new THREE.Object3D();
    data.forEach((item, i) => { scratch.position.set(...item.p); scratch.scale.set(...item.s); scratch.rotation.set(...(item.r ?? [0, 0, 0])); scratch.updateMatrix(); out.setMatrixAt(i, scratch.matrix); });
    out.instanceMatrix.needsUpdate = true;
    out.castShadow = false;
    out.receiveShadow = false;
    out.frustumCulled = true;
    parent.add(out);
    return out;
}
function softSprite() {
    const size = 32, pixels = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y++)
        for (let x = 0; x < size; x++) {
            const d = Math.hypot((x + .5 - size / 2) / (size / 2), (y + .5 - size / 2) / (size / 2));
            const a = Math.pow(Math.max(0, 1 - d), 1.65);
            const i = (y * size + x) * 4;
            pixels[i] = pixels[i + 1] = pixels[i + 2] = 255;
            pixels[i + 3] = Math.round(a * 255);
        }
    const tex = new THREE.DataTexture(pixels, size, size, THREE.RGBAFormat);
    tex.needsUpdate = true;
    tex.magFilter = THREE.LinearFilter;
    tex.minFilter = THREE.LinearFilter;
    return tex;
}
function floatingMotes(parent, seed, count, color, extents, size) {
    const r = rng(seed);
    const [x0, x1, y0, y1, z0, z1] = extents;
    const data = Array.from({ length: count }, () => ({ x: x0 + (x1 - x0) * r(), y: y0 + (y1 - y0) * r(), z: z0 + (z1 - z0) * r(), rate: .32 + r() * .7, phase: r() * 6.3 }));
    const positions = new Float32Array(count * 3), geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
    const mat = new THREE.PointsMaterial({ color, size, map: softSprite(), transparent: true, opacity: .7, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
    const particles = new THREE.Points(geo, mat);
    particles.frustumCulled = false;
    parent.add(particles);
    const update = (time, reduced, intensity = 1) => {
        particles.visible = intensity > 0 && !reduced;
        if (reduced)
            return;
        const attr = geo.getAttribute('position');
        for (let i = 0; i < count; i++) {
            const d = data[i];
            const drift = (time * d.rate + d.phase);
            attr.setXYZ(i, d.x + Math.sin(drift * .6) * .55, d.y + Math.sin(drift) * .7, d.z + Math.cos(drift * .55) * .55);
        }
        attr.needsUpdate = true;
        mat.opacity = .62 * intensity;
    };
    update(0, false);
    return update;
}
function etching(parent, x, y, z, r, c) {
    const a = orbit(parent, r, .026, c, x, y, z, .67);
    a.rotation.x = Math.PI / 2;
    for (let i = 0; i < 4; i++) {
        const theta = i * Math.PI / 2;
        const mark = mesh(parent, new THREE.BoxGeometry(.13, .018, .45), glow(c, .72), x + Math.cos(theta) * r, y + .015, z + Math.sin(theta) * r);
        mark.rotation.y = -theta;
    }
}
/** Curved, pointed botanical blades: real leaf geometry rather than flattened spheres.
 * Local space intentionally has no collision or gameplay contract. */
function botanicalBlade() {
    const vertices = [], colors = [], indices = [];
    const root = new THREE.Color(0x1e8069), tip = new THREE.Color(0xa1efd1);
    const along = 14, across = 6;
    for (let i = 0; i <= along; i++) {
        const t = i / along;
        const spread = Math.pow(Math.max(0.002, Math.sin(Math.PI * t)), .72);
        for (let j = 0; j <= across; j++) {
            const u = j / across * 2 - 1;
            vertices.push(u * .52 * spread, Math.sin(t * Math.PI) * .085 + (1 - Math.abs(u)) * .115 - Math.pow(t, 3) * .045, t);
            const shade = .16 + .68 * (1 - Math.abs(u)) + .18 * (1 - t);
            const c = root.clone().lerp(tip, Math.min(1, shade));
            colors.push(c.r, c.g, c.b);
        }
    }
    for (let i = 0; i < along; i++)
        for (let j = 0; j < across; j++) {
            const a = i * (across + 1) + j, b = a + 1, c = a + across + 1, d = c + 1;
            indices.push(a, b, c, b, d, c);
        }
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    out.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    out.setIndex(indices);
    out.computeVertexNormals();
    return out;
}
/** Shared, pointed and ribbed foliage replaces primitive ovoid crowns and towers. */
export function leafBladeGeometry() { return botanicalBlade(); }
/** An atmospheric layer well below traversal geometry. Never a landing collider. */
function atmospherePlane(parent, kind) {
    const violet = kind === 'violet';
    const mat = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, side: THREE.DoubleSide,
        uniforms: { time: { value: 0 }, a: { value: new THREE.Color(violet ? 0x6b4b8d : 0x174f54) }, b: { value: new THREE.Color(violet ? 0xd5a3bb : 0x53a999) } },
        vertexShader: 'varying vec2 surfaceUv;void main(){surfaceUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
        fragmentShader: `varying vec2 surfaceUv;uniform float time;uniform vec3 a,b;
      void main(){
        vec2 p=surfaceUv*vec2(10.,13.);
        float v=sin(p.x*1.2+sin(p.y*.7+time*.013))*sin(p.y*1.5-p.x*.56);
        float w=sin(p.x*2.6-p.y*.72+time*.018)*.5+sin(p.y*3.7+p.x*.24)*.16;
        float bands=smoothstep(-.5,.94,v*.73+w*.27);
        float veil=smoothstep(.05,.38,surfaceUv.y)*(1.-smoothstep(.78,1.,surfaceUv.y));
        vec3 hue=mix(a,b,bands*.77+.17);
        gl_FragColor=vec4(hue,.30*veil+.25*bands*veil);
      }`
    });
    const o = mesh(parent, new THREE.PlaneGeometry(460, 440), mat, 0, -23, -75);
    o.rotation.x = -Math.PI / 2;
    o.renderOrder = -2;
    return { setTime: (t) => { mat.uniforms.time.value = t; } };
}
function wovenPennant() {
    const vertices = [], colors = [], indices = [];
    const atTop = new THREE.Color(0x9d78bc), atBottom = new THREE.Color(0x3b2c66);
    for (let i = 0; i <= 14; i++) {
        const t = i / 14;
        const tip = t > .79 ? Math.max(.025, 1 - (t - .79) * 4.4) : 1;
        const width = .52 * (1 - .25 * t) * tip;
        for (let j = 0; j <= 2; j++) {
            const u = j - 1;
            vertices.push(u * width, .5 - t, Math.sin(t * Math.PI * 2) * .025 + Math.cos(t * 8) * .024 * (1 - Math.abs(u)));
            const c = atTop.clone().lerp(atBottom, t * .9);
            c.multiplyScalar(j === 1 ? 1.3 : .84);
            colors.push(c.r, c.g, c.b);
        }
    }
    for (let i = 0; i < 14; i++)
        for (let j = 0; j < 2; j++) {
            const a = i * 3 + j, b = a + 1, c = a + 3, d = c + 1;
            indices.push(a, c, b, b, c, d);
        }
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    out.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    out.setIndex(indices);
    out.computeVertexNormals();
    return out;
}
/** Violet chapter's ceremonial skyline: banners, votive lanterns, and finely tapered crown shards. */
function addParableFinerArt(parent) {
    const r = rng(271041), root = new THREE.Group();
    root.name = 'parable-sculpture';
    parent.add(root);
    const bannerMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, roughness: .73, metalness: .12, emissive: 0x25142b, emissiveIntensity: .16 });
    const filigree = standard(0xe9bd81, .63, .36, 0x8b4a35, .25);
    const banners = new THREE.Group();
    root.add(banners);
    const fabric = wovenPennant();
    for (let i = 0; i < 12; i++) {
        const side = i % 2 ? 1 : -1, z = 13 - Math.floor(i / 2) * 23;
        const x = side * (16.4 + r() * 2.8), h = 15 + r() * 9;
        const banner = mesh(banners, fabric, bannerMaterial, x, h, z);
        banner.scale.set(6.4, 13 + r() * 4, 1);
        banner.rotation.y = side * (.10 + r() * .24);
        const top = mesh(banners, new THREE.BoxGeometry(8, .18, .21), filigree, x, h + banner.scale.y * .51, z);
        top.rotation.y = banner.rotation.y;
        const gem = mesh(banners, new THREE.IcosahedronGeometry(.85, 0), filigree, x, h + .45, z + .14);
        gem.scale.set(.66, 1.1, .21);
        gem.castShadow = false;
        for (const dir of [-1, 1]) {
            const tassel = mesh(banners, new THREE.CylinderGeometry(.07, .07, 7, 6), filigree, x + dir * 3.5, h + banner.scale.y * .16, z);
            tassel.rotation.z = dir * .025;
            tassel.castShadow = false;
        }
    }
    const shardsData = [];
    for (let i = 0; i < 92; i++) {
        const side = i % 2 ? 1 : -1, z = 20 - r() * 151, x = side * (26 + r() * 49);
        shardsData.push({ p: [x, 9 + r() * 44, z], s: [.28 + r() * .70, 2.5 + r() * 5.8, .28 + r() * .70], r: [(r() - .5) * .25, r() * 6.28, (r() - .5) * .45] });
    }
    instance(root, new THREE.IcosahedronGeometry(1, 0), filigree, shardsData);
    const constellations = new THREE.Group();
    constellations.name = 'detail-high';
    root.add(constellations);
    const ink = glow(0xdfbdf4, .34), metal = glow(0xfce1ad, .76);
    for (let i = 0; i < 4; i++) {
        const z = 0 - i * 33;
        const xx = i % 2 ? 30 : -31, yy = 38 + i * 2;
        const curve = [];
        for (let j = 0; j < 10; j++) {
            const t = j / 9 * Math.PI * 1.7;
            curve.push(new THREE.Vector3(xx + Math.cos(t) * 9, yy + Math.sin(t) * 6, z - Math.sin(t) * 3));
        }
        const o = tube(constellations, curve, .08, 0xe5b37e, .72);
        o.castShadow = false;
        const star = mesh(constellations, new THREE.IcosahedronGeometry(1.8, 0), metal, xx + 6, yy + 2, z);
        star.rotation.z = .4;
        star.scale.y = 2;
        star.castShadow = false;
        const ringMesh = orbit(constellations, 5.7, .08, 0xd6a4eb, xx + 6, yy + 2, z, .50);
        ringMesh.rotation.x = .25;
        ringMesh.rotation.y = .3;
    }
    return { update: (time, reduced) => { if (!reduced) {
            banners.rotation.y = Math.sin(time * .08) * .007;
            constellations.rotation.z = Math.sin(time * .08) * .008;
        }
        else {
            banners.rotation.y = 0;
            constellations.rotation.z = 0;
        } } };
}
/** Cultivated detail that reads botanically at play distance; each species is instanced. */
function addAcreFinerArt(parent) {
    const random = rng(900100), root = new THREE.Group();
    root.name = 'acre-botanical-atelier';
    parent.add(root);
    const plant = new THREE.Group();
    root.add(plant);
    const blade = botanicalBlade();
    const leafMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, metalness: .07, roughness: .51, emissive: 0x103b36, emissiveIntensity: .2 });
    const leafData = [];
    const vines = [];
    const seedBuds = [];
    const scratch = new THREE.Object3D();
    for (let i = 0; i < 32; i++) {
        const side = i % 2 ? 1 : -1;
        const x = side * (21 + random() * 17), z = 21 - Math.floor(i / 2) * 9.5 + (random() - .5) * 5, h = 13 + random() * 18;
        vines.push({ p: [x, h * .44, z], s: [.75, h, .75] });
        for (let j = 0; j < 7; j++) {
            const a = j * 2.399 + random() * .3;
            const offset = 1.2 + random() * 2.7;
            leafData.push({ p: [x + Math.cos(a) * offset, h * (.28 + .08 * j), z + Math.sin(a) * offset],
                s: [3.8 + random() * 4, 1.4 + random() * 1.7, 6.8 + random() * 6], r: [-.18 - random() * .42, a, Math.sin(a) * .18] });
        }
        if (i % 2 === 0) {
            seedBuds.push({ p: [x, h + 1.6, z], s: [1.2 + random(), 2.0 + random(), 1.2 + random()] });
        }
    }
    instance(plant, new THREE.CylinderGeometry(.34, .75, 1, 8), standard(0x1b5249, .15, .8), vines);
    const leafArray = instance(plant, blade, leafMaterial, leafData);
    const tinted = new THREE.Color();
    for (let i = 0; i < leafData.length; i++) {
        tinted.set(i % 9 === 0 ? 0xc3db7b : i % 5 === 0 ? 0x86e6bf : i % 3 === 0 ? 0x38a98d : 0x6cbf9c);
        leafArray.setColorAt(i, tinted);
    }
    if (leafArray.instanceColor)
        leafArray.instanceColor.needsUpdate = true;
    const buds = instance(plant, new THREE.IcosahedronGeometry(1, 2), standard(0xc3f3bd, .05, .43, 0x399e78, .30), seedBuds);
    const nectar = standard(0xefdfa2, .33, .33, 0x9aba6b, .4);
    const bloom = new THREE.Group();
    root.add(bloom);
    const petalsData = [];
    const coronaData = [];
    for (let j = 0; j < 10; j++) {
        const side = j % 2 ? 1 : -1, x = side * (15 + random() * 5), z = 10 - Math.floor(j / 2) * 23, h = 17 + random() * 9;
        coronaData.push({ p: [x, h, z], s: [.65, .65, .65] });
        for (let k = 0; k < 8; k++) {
            const a = k * Math.PI / 4;
            petalsData.push({ p: [x + Math.sin(a) * 1.6, h + Math.cos(a) * 1.6, z], s: [2.2, 3.0, .30], r: [0, 0, -a] });
        }
    }
    instance(bloom, new THREE.IcosahedronGeometry(1, 1), nectar, coronaData);
    const petals = instance(bloom, new THREE.IcosahedronGeometry(1, 1), new THREE.MeshStandardMaterial({ color: 0xa2f9c9, roughness: .5, metalness: .05, emissive: 0x317658, emissiveIntensity: .28 }), petalsData);
    const trellises = new THREE.Group();
    trellises.name = 'detail-high';
    root.add(trellises);
    for (const [n, z] of [-9, -47, -83].entries()) {
        const y = 23 + n * 2;
        const curve = [];
        for (let i = 0; i <= 12; i++) {
            const t = i / 12 * Math.PI;
            curve.push(new THREE.Vector3(Math.cos(t) * 18, 2 + Math.sin(t) * y, z));
        }
        tube(trellises, curve, .18, 0x9be1cd, .82);
        tube(trellises, curve.map(v => v.clone().add(new THREE.Vector3(0, .55, -.28))), .04, 0xe3daa8, .57);
    }
    // Never swap a plant-growth animation for a static illustration: this is only scenic.
    const flowerMaterial = petals.material;
    return { update: (time, reduced, intensity) => {
            if (!reduced) {
                plant.rotation.y = Math.sin(time * .09) * .004;
                bloom.rotation.y = Math.sin(time * .12) * .009;
            }
            else {
                plant.rotation.y = 0;
                bloom.rotation.y = 0;
            }
            flowerMaterial.emissiveIntensity = .28 + .18 * intensity;
        } };
}
/** Hub: an architectural presentation device, never a fictional passage between the two source games. */
export function createScenicHub() {
    const group = new THREE.Group();
    group.name = 'scenic-hub';
    const r = rng(116);
    const dark = standard(0x181c30, .54, .35), bronze = standard(0xcda96c, .74, .24);
    const floor = instance(group, new THREE.BoxGeometry(1, 1, 1), dark, Array.from({ length: 28 }, (_, i) => {
        const a = i * Math.PI * 2 / 28;
        return { p: [Math.sin(a) * 17, -5.2, Math.cos(a) * 17], s: [2.3, 7.0, 1.55], r: [0, -a, 0] };
    }));
    floor.receiveShadow = true;
    // The signature object reads as a pair of opposite-faced, independently illuminated plates.
    for (const s of [-1, 1]) {
        const tint = s > 0 ? 0xe7bd79 : 0x7af0c9;
        for (let i = 0; i < 3; i++) {
            const o = orbit(group, 6.1 + i * .46, .025 + i * .01, tint, 0, 4.6, s * .33, .30);
            o.rotation.z = i * .16;
            o.rotation.y = s * .13;
        }
        for (let i = 0; i < 12; i++) {
            const a = i * 2 * Math.PI / 12;
            const g = sphere(group, .20, tint, Math.sin(a) * 5.8, 4.6 + Math.cos(a) * 5.8, s * .55, 0);
            g.scale.set(1.1, .5, .7);
        }
    }
    const inlay = new THREE.Group();
    group.add(inlay);
    for (let i = 0; i < 3; i++) {
        const circle = orbit(inlay, 8.4 + i * 2.6, .033, i === 0 ? 0xecc991 : i === 1 ? 0xc3a8da : 0x8addc6, 0, .16, 0, .51);
        circle.rotation.x = -Math.PI / 2;
    }
    const distance = new THREE.Group();
    distance.name = 'detail-high';
    group.add(distance);
    const flight = instance(distance, new THREE.IcosahedronGeometry(.8, 0), bronze, Array.from({ length: 80 }, () => {
        const theta = r() * 6.28, rad = 20 + r() * 47;
        return { p: [Math.cos(theta) * rad, -7 + r() * 27, Math.sin(theta) * rad], s: [.28 + r() * .65, .35 + r() * 1.8, .28 + r() * .65], r: [r() * 3, r() * 3, r() * 3] };
    }));
    flight.castShadow = false;
    const ambience = floatingMotes(distance, 667, 86, 0xf2dab0, [-16, 16, 1, 19, -16, 16], 1.0);
    return { group, update: (t, reduced) => { if (!reduced)
            inlay.rotation.y = Math.sin(t * .07) * .05; ambience(t, reduced); } };
}
/** Parable: impossible, immediate vertical architecture, edged in ancient gold. */
export function createScenicParable() {
    const group = new THREE.Group();
    group.name = 'scenic-parable';
    const random = rng(1906);
    const authored = addParableFinerArt(group);
    const stone = standard(0x403454, .25, .82), pale = standard(0x8a789d, .16, .78), gold = standard(0xe0b472, .66, .30, 0x8c5924, .16);
    const obsidian = standard(0x242139, .32, .68);
    const cloudSea = atmospherePlane(group, 'violet');
    const silhouette = instance(group, new THREE.CylinderGeometry(.44, 1.18, 1, 7), stone, Array.from({ length: 64 }, (_, i) => {
        const z = 32 - random() * 160, sgn = i % 2 ? 1 : -1;
        return { p: [sgn * (33 + random() * 66), -11 + random() * 3, z], s: [4 + random() * 10, 19 + random() * 47, 4 + random() * 12], r: [0, random() * 6.28, 0] };
    }));
    silhouette.receiveShadow = true;
    const spines = instance(group, new THREE.ConeGeometry(.6, 1, 6), pale, Array.from({ length: 100 }, (_, i) => {
        const z = 25 - random() * 146, sgn = i % 2 ? 1 : -1;
        return { p: [sgn * (35 + random() * 67), 15 + random() * 44, z], s: [1 + random() * 3, 8 + random() * 25, 1 + random() * 3], r: [0, random() * 6.28, 0] };
    }));
    spines.receiveShadow = true;
    // Elevated sculptural arches sit clear of the walkable route; no collision changes.
    const vaults = new THREE.Group();
    group.add(vaults);
    [-15, -48, -82].forEach((z, index) => {
        const size = 14.8 + index * 1.5;
        for (const s of [-1, 1]) {
            mesh(vaults, new THREE.CylinderGeometry(1.6, 2.5, 27 + index * 3, 10), obsidian, s * size, 13 + index * 1.5, z);
            for (let k = 0; k < 5; k++) {
                const yy = 4 + k * 5;
                mesh(vaults, new THREE.BoxGeometry(3.8, .18, 3.8), gold, s * size, yy, z);
            }
        }
        tube(vaults, [new THREE.Vector3(-size, 26 + index * 3, z), new THREE.Vector3(-size * .65, 31 + index * 3, z), new THREE.Vector3(0, 34 + index * 3, z), new THREE.Vector3(size * .65, 31 + index * 3, z), new THREE.Vector3(size, 26 + index * 3, z)], .75, 0x352944, 1);
        tube(vaults, [new THREE.Vector3(-size, 27 + index * 3, z + .11), new THREE.Vector3(-size * .65, 32 + index * 3, z + .11), new THREE.Vector3(0, 35 + index * 3, z + .11), new THREE.Vector3(size * .65, 32 + index * 3, z + .11), new THREE.Vector3(size, 27 + index * 3, z + .11)], .05, 0xf5ca83, .78);
    });
    // Radial sanctuary at the far distance: it is a sculptural horizon, not a new source event.
    const coronation = new THREE.Group();
    coronation.position.set(0, 53, -133);
    group.add(coronation);
    const core = mesh(coronation, new THREE.SphereGeometry(17, 32, 22), glow(0x7e4a9e, .16));
    core.scale.z = .27;
    for (let i = 0; i < 4; i++) {
        const orbitMesh = orbit(coronation, 23 + i * 2.5, .2, i % 2 ? 0xd8a35e : 0x9475bc, 0, 0, -i * 1.5, .6 - i * .1);
        orbitMesh.rotation.y = i * .17;
    }
    const rays = instance(coronation, new THREE.BoxGeometry(1, 1, 1), gold, Array.from({ length: 24 }, (_, i) => {
        const a = i * Math.PI * 2 / 24;
        return { p: [Math.sin(a) * 31, Math.cos(a) * 31, -4], s: [.18, 5, 1], r: [0, 0, -a] };
    }));
    rays.castShadow = false;
    // Sky-high currents give the ascent its specific silhouette, independent of time-of-day controls.
    const stream = new THREE.Group();
    group.add(stream);
    for (let b = 0; b < 4; b++) {
        const pts = [];
        for (let i = 0; i < 13; i++) {
            const z = 31 - i * 12;
            pts.push(new THREE.Vector3(Math.sin(i * .39 + b) * 17 + (b - 1.5) * 11, 39 + b * 6 + Math.sin(i * .4 + b * 2) * 6, z));
        }
        tube(stream, pts, b % 2 ? .12 : .23, b % 2 ? 0xf7c983 : 0x8e66b7, b % 2 ? .35 : .20);
    }
    const gilded = instance(group, new THREE.BoxGeometry(1, 1, 1), gold, Array.from({ length: 130 }, (_, i) => {
        const z = 26 - random() * 132, side = i % 2 ? 1 : -1;
        return { p: [side * (12 + random() * 50), 1 + random() * 39, z], s: [.07, .12 + random() * .4, 2 + random() * 7], r: [0, random() * 6.28, 0] };
    }));
    gilded.castShadow = false;
    const small = new THREE.Group();
    small.name = 'detail-high';
    group.add(small);
    const chips = instance(small, new THREE.IcosahedronGeometry(.6, 0), gold, Array.from({ length: 160 }, () => {
        const z = 20 - random() * 115, x = (random() - .5) * 95;
        return { p: [x, 9 + random() * 45, z], s: [.15 + random() * .5, .4 + random() * 2, .15 + random() * .5], r: [random() * 6.28, random() * 6.28, random() * 6.28] };
    }));
    chips.castShadow = false;
    const motes = floatingMotes(small, 710, 155, 0xffdc96, [-22, 22, 2, 26, -96, 20], .91);
    const intervention = orbit(group, 2, .13, 0xffdba0, -2, 4.02, -22, .9);
    intervention.rotation.x = Math.PI / 2;
    intervention.visible = false;
    const echo = orbit(group, 2.2, .045, 0xfbe9ae, -2, 4.03, -22, .7);
    echo.rotation.x = Math.PI / 2;
    echo.visible = false;
    let trigger = -1;
    return { group, update: (time, reduced, intensity = 0) => {
            if (small.visible)
                motes(time, reduced);
            cloudSea.setTime(reduced ? 0 : time);
            authored.update(time, reduced);
            if (intensity > 0 && trigger < 0)
                trigger = time;
            if (intensity === 0)
                trigger = -1;
            if (trigger >= 0 && !reduced) {
                const phase = Math.min(1, (time - trigger) / 1.35);
                intervention.visible = echo.visible = phase < 1;
                intervention.scale.setScalar(.1 + phase * 7);
                echo.scale.setScalar(.1 + phase * 10);
                intervention.material.opacity = .75 * (1 - phase);
                echo.material.opacity = .42 * (1 - phase);
            }
            else {
                intervention.visible = false;
                echo.visible = false;
            }
            if (!reduced) {
                stream.rotation.y = Math.sin(time * .10) * .018;
                coronation.rotation.z = Math.sin(time * .06) * .03;
            }
        } };
}
/** Starlight Acre: orbital conservatory; finite tending interpreted as a single dramatic growth. */
export function createScenicAcre() {
    const group = new THREE.Group();
    group.name = 'scenic-acre';
    const r = rng(27182);
    const authored = addAcreFinerArt(group);
    const stem = standard(0x174f49, .1, .79), deep = standard(0x0c323a, .34, .52), fern = standard(0x369879, .06, .61), mint = standard(0x76d7a5, .04, .52), leafMat = new THREE.MeshStandardMaterial({ color: 0x76cda1, side: THREE.DoubleSide, metalness: .05, roughness: .53, emissive: 0x145d45, emissiveIntensity: .12 }), citrus = standard(0xd8f3ad, .08, .44, 0x7aba69, .23), filigree = standard(0x8adbcf, .56, .28);
    const waterFloor = atmospherePlane(group, 'jade');
    // A recessed habitat deck supports the illusion of a cultivated station below the jumps.
    // All geometry is visual-only and is positioned at least ten units below the route.
    const lower = new THREE.Group();
    group.add(lower);
    const deck = standard(0x0c2d31, .24, .6), copper = standard(0x83c6ad, .6, .32), water = glow(0x267d77, .83);
    const baseData = [];
    const railData = [];
    const waterData = [];
    for (let n = 0; n < 10; n++) {
        const z = 24 - n * 14.0;
        baseData.push({ p: [0, -11, z], s: [25, .65, 8.4] });
        for (const sign of [-1, 1]) {
            railData.push({ p: [sign * 12.7, -10.5, z], s: [.13, .16, 8.4] });
            waterData.push({ p: [sign * 10.5, -10.62, z], s: [1.85, .05, 6.6] });
        }
    }
    instance(lower, new THREE.BoxGeometry(1, 1, 1), deck, baseData);
    instance(lower, new THREE.BoxGeometry(1, 1, 1), copper, railData);
    instance(lower, new THREE.BoxGeometry(1, 1, 1), water, waterData);
    fern.side = THREE.DoubleSide;
    mint.side = THREE.DoubleSide;
    fern.vertexColors = true;
    mint.vertexColors = true;
    // Three nested glass-roof support arcs make the habitat read as an engineered conservatory.
    for (const z of [12, -25, -65, -96]) {
        const path = [];
        for (let j = 0; j <= 20; j++) {
            const a = j * Math.PI / 20;
            path.push(new THREE.Vector3(47 * Math.cos(a), 3 + 49 * Math.sin(a), z));
        }
        tube(group, path, .21, 0x8ad2c1, .58);
    }
    // Terraced hydroponic waterways are outside the generous central jump corridor.
    const channels = new THREE.Group();
    group.add(channels);
    const trays = [];
    const waters = [];
    const edges = [];
    for (const side of [-1, 1])
        for (let k = 0; k < 16; k++) {
            const x = side * 15, z = 23 - k * 7.7;
            trays.push({ p: [x, -.45, z], s: [2.7, .55, 7.5] });
            waters.push({ p: [x, -.1, z], s: [2.45, .06, 7.0] });
            edges.push({ p: [x, -.18, z], s: [2.75, .07, 7.6] });
        }
    instance(channels, new THREE.BoxGeometry(1, 1, 1), deep, trays).receiveShadow = true;
    instance(channels, new THREE.BoxGeometry(1, 1, 1), glow(0x59c9ba, .48), waters);
    instance(channels, new THREE.BoxGeometry(1, 1, 1), filigree, edges);
    // Fronds are four shared instanced draws, rather than hundreds of individual plant meshes.
    const large = new THREE.Group();
    group.add(large);
    const stalks = [], lightLeaves = [], darkLeaves = [], buds = [];
    for (let i = 0; i < 48; i++) {
        const side = i % 2 ? 1 : -1, x = side * (18 + r() * 34), z = 30 - r() * 151;
        const height = 8 + r() * 29, spread = 5 + r() * 12;
        stalks.push({ p: [x, -2 + height * .5, z], s: [1, height, 1] });
        for (let j = 0; j < 5; j++) {
            const angle = (j / 5) * Math.PI * 2 + r() * .3;
            const item = { p: [x + Math.cos(angle) * spread * .48, -2 + height * (.52 + j * .095), z + Math.sin(angle) * spread * .48],
                s: [spread * .34, .95, spread * .84], r: [0, -angle, Math.sin(angle) * .29] };
            (j % 2 ? darkLeaves : lightLeaves).push(item);
        }
        if (i % 5 === 0)
            buds.push({ p: [x, -2 + height + 1.1, z], s: [1, .7, 1] });
    }
    instance(large, new THREE.CylinderGeometry(.35, .8, 1, 7), stem, stalks);
    const leafGeo = botanicalBlade();
    instance(large, leafGeo, fern, darkLeaves);
    instance(large, leafGeo, mint, lightLeaves);
    instance(large, new THREE.IcosahedronGeometry(1.4, 2), glow(0xb9fbd1, .95), buds);
    const graced = new THREE.Group();
    graced.name = 'detail-high';
    group.add(graced);
    // A field of structural leaf-scales and coral-shaped luminous crop clusters uses six draw calls.
    const perches = instance(graced, new THREE.IcosahedronGeometry(.8, 1), mint, Array.from({ length: 210 }, (_, i) => {
        const s = i % 2 ? 1 : -1;
        return { p: [s * (11 + r() * 41), 1 + r() * 19, 30 - r() * 147], s: [.6 + r() * 1.5, .20 + r() * .22, 1.5 + r() * 3], r: [r() * .3, r() * 6.28, (r() - .5) * .4] };
    }));
    perches.castShadow = false;
    const pods = instance(graced, new THREE.IcosahedronGeometry(.6, 1), citrus, Array.from({ length: 150 }, (_, i) => {
        const s = i % 2 ? 1 : -1;
        return { p: [s * (17 + r() * 26), 3 + r() * 25, 20 - r() * 134], s: [.25 + r() * .55, .4 + r() * .7, .25 + r() * .55], r: [r() * 3, r() * 3, 0] };
    }));
    pods.castShadow = false;
    const glassPebbles = instance(graced, new THREE.IcosahedronGeometry(.6, 0), filigree, Array.from({ length: 75 }, () => {
        const x = (r() - .5) * 95;
        return { p: [x, 12 + r() * 36, 20 - r() * 142], s: [.12 + r() * .25, .4 + r() * .8, .12 + r() * .25], r: [0, r() * 6.28, 0] };
    }));
    glassPebbles.castShadow = false;
    const pollen = floatingMotes(graced, 932, 170, 0x9dffe1, [-22, 22, 3, 27, -91, 22], 1.05);
    const seedWave = orbit(group, 1.8, .13, 0xafffda, 2, 4.08, -24, .9);
    seedWave.rotation.x = Math.PI / 2;
    seedWave.visible = false;
    const secondWave = orbit(group, 2.1, .04, 0xe6ffc4, 2, 4.1, -24, .7);
    secondWave.rotation.x = Math.PI / 2;
    secondWave.visible = false;
    let plantedAt = -1;
    return { group, update: (time, reduced, intensity = 0) => {
            if (graced.visible)
                pollen(time, reduced, intensity > 0 ? 1.15 : .65);
            waterFloor.setTime(reduced ? 0 : time);
            authored.update(time, reduced, intensity);
            if (intensity > 0 && plantedAt < 0)
                plantedAt = time;
            if (intensity === 0)
                plantedAt = -1;
            if (plantedAt >= 0 && !reduced) {
                const phase = Math.min(1, (time - plantedAt) / 2.6);
                seedWave.visible = secondWave.visible = phase < 1;
                seedWave.scale.setScalar(.1 + phase * 7);
                secondWave.scale.setScalar(.1 + phase * 10);
                seedWave.material.opacity = .76 * (1 - phase);
                secondWave.material.opacity = .45 * (1 - phase);
            }
            else {
                seedWave.visible = false;
                secondWave.visible = false;
            }
            if (!reduced) {
                large.rotation.y = Math.sin(time * .19) * .005;
            }
        } };
}
/** Creates deterministic polychrome mineral surfaces without network textures or DOM canvas. */
export function mineralTexture(seed, tint, kind) {
    const size = 128, r = rng(seed), data = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y++)
        for (let x = 0; x < size; x++) {
            const warp = 3.2 * Math.sin(y * .026) + 2.1 * Math.sin(x * .05 + y * .031);
            const lamination = Math.sin(x * .086 + y * .046 + warp) * 7.7 + Math.sin(y * .11 - x * .032) * 4.9;
            const veinCore = Math.abs(Math.sin(x * .047 + y * .094 + warp * .18));
            const vein = veinCore > .972 ? 13 : 0;
            const grain = (r() - .5) * (kind === 'stone' ? 8 : 11);
            const factor = kind === 'stone' ? lamination + vein + grain : (lamination * .67 + vein * .18 + grain);
            const i = (y * size + x) * 4;
            data[i] = Math.max(0, Math.min(255, tint[0] + factor));
            data[i + 1] = Math.max(0, Math.min(255, tint[1] + factor * .86));
            data[i + 2] = Math.max(0, Math.min(255, tint[2] + factor * .78));
            data[i + 3] = 255;
        }
    const out = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
    out.needsUpdate = true;
    out.wrapS = out.wrapT = THREE.RepeatWrapping;
    out.colorSpace = THREE.SRGBColorSpace;
    out.minFilter = THREE.LinearMipmapLinearFilter;
    out.magFilter = THREE.LinearFilter;
    out.generateMipmaps = true;
    out.anisotropy = 2;
    return out;
}
