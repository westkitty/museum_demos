import * as THREE from 'three';
/** Reusable, procedural visual grammar. All materials and patterns are local. */
export const STAGE_ART = [
    { ink: 0x080c15, top: 0x172437, low: 0x25151a, halo: 0xc86c41, rim: 0xffa56b, stone: 0x151c26 },
    { ink: 0x061625, top: 0x173e51, low: 0x0b273c, halo: 0x51bfe3, rim: 0x95ebf7, stone: 0x133744 },
    { ink: 0x1a1015, top: 0x46302b, low: 0x1b1d26, halo: 0xeb9c55, rim: 0xffcb80, stone: 0x333139 },
    { ink: 0x070d26, top: 0x243a68, low: 0x101731, halo: 0x809af5, rim: 0xc8d7ff, stone: 0x222d4d },
];
export function proceduralSurface(kind) {
    const size = 128;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx)
        throw new Error('Canvas 2D context unavailable for procedural surface.');
    const data = ctx.createImageData(size, size);
    const hash = (x, y) => {
        let v = Math.imul(x + 169, 374761393) + Math.imul(y + 43, 668265263);
        v = Math.imul(v ^ (v >>> 13), 1274126177);
        return ((v ^ (v >>> 16)) >>> 0) / 4294967295;
    };
    for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
            const coarse = hash(x >> 3, y >> 3);
            const micro = hash(x, y);
            const streak = Math.sin((kind === 'metal' ? y : x) * (kind === 'metal' ? 1.44 : 0.22) + coarse * 7);
            const chip = kind === 'stone' && hash(x >> 2, y >> 2) > .87 ? -38 : 0;
            const value = Math.max(84, Math.min(246, (kind === 'ceramic' ? 218 : kind === 'metal' ? 192 : 170) +
                (coarse - .5) * (kind === 'ceramic' ? 12 : 38) +
                (micro - .5) * (kind === 'metal' ? 18 : 29) + streak * 5 + chip));
            const i = (y * size + x) * 4;
            data.data[i] = value;
            data.data[i + 1] = value * (kind === 'stone' ? .96 : 1);
            data.data[i + 2] = value * (kind === 'metal' ? 1.03 : 1);
            data.data[i + 3] = 255;
        }
    }
    ctx.putImageData(data, 0, 0);
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 2;
    tex.needsUpdate = true;
    return tex;
}
export function glowTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 96;
    const ctx = canvas.getContext('2d');
    if (!ctx)
        throw new Error('Canvas 2D context unavailable for glow sprite.');
    const gradient = ctx.createRadialGradient(48, 48, 1, 48, 48, 48);
    gradient.addColorStop(0, 'rgba(255,255,255,1)');
    gradient.addColorStop(.14, 'rgba(255,255,255,.88)');
    gradient.addColorStop(.37, 'rgba(255,255,255,.27)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 96, 96);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
}
export function atmosphericBackdrop(act) {
    const stage = STAGE_ART[act];
    return new THREE.ShaderMaterial({
        uniforms: {
            uDeep: { value: new THREE.Color(stage.low) },
            uZenith: { value: new THREE.Color(stage.top) },
            uHalo: { value: new THREE.Color(stage.halo) },
            uTime: { value: 0 },
            uAct: { value: act },
        },
        vertexShader: `varying vec2 vUv;
      void main() { vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
        fragmentShader: `precision highp float;
      varying vec2 vUv; uniform vec3 uDeep; uniform vec3 uZenith; uniform vec3 uHalo;
      uniform float uTime, uAct;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
      void main() {
        vec2 uv=vUv;
        float bend = .035*sin(uv.y*12.+uAct*2.1);
        float horizon = smoothstep(.02,1.,uv.y);
        vec3 col=mix(uDeep,uZenith,horizon*.78);
        float shaft=pow(max(0.,1.-abs(uv.x-.48+bend)*2.9),3.0);
        col += uHalo*shaft*(.085+.16*pow(1.-uv.y,2.));
        float rays=pow(max(0.,sin(uv.x*89.+sin(uv.y*9.)*2.)),29.);
        col += uHalo*rays*.045;
        float rough=(hash(floor(uv*vec2(540.,240.)))-.5)*.035;
        col += rough;
        float vignette=smoothstep(.0,.6,uv.x)*(1.-smoothstep(.43,1.,uv.x));
        col*=.58+.42*vignette;
        gl_FragColor=vec4(col,1.);
      }`,
        depthWrite: false,
    });
}
export function planetSurface() {
    return new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 }, uReduced: { value: 0 } },
        vertexShader: `varying vec3 vNormal; varying vec3 vPosition; varying vec2 vUv;
      void main(){vNormal=normalize(normalMatrix*normal);vPosition=position;vUv=uv;
        gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
        fragmentShader: `precision highp float;
      varying vec3 vNormal; varying vec3 vPosition; varying vec2 vUv;
      uniform float uTime, uReduced;
      float hash(float n){return fract(sin(n)*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p), f=fract(p);f=f*f*(3.-2.*f);
        float a=hash(dot(i,vec2(1.,57.)));float b=hash(dot(i+vec2(1.,0.),vec2(1.,57.)));
        float c=hash(dot(i+vec2(0.,1.),vec2(1.,57.)));float d=hash(dot(i+vec2(1.,1.),vec2(1.,57.)));
        return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);}
      void main() {
        vec2 p=vUv*vec2(14.,30.); p.x += (1.-uReduced)*uTime*.011;
        float cloud=noise(vec2(p.x,p.y*1.4));
        float band=sin(vUv.y*95.+cloud*11.+sin(p.x*1.7)*2.);
        float fine=sin(vUv.y*176.-cloud*5.);
        float t=smoothstep(-.9,.94,band*.7+fine*.14+cloud*.42);
        vec3 deep=vec3(.032,.082,.17);
        vec3 mist=vec3(.28,.43,.62);
        vec3 amber=vec3(.65,.48,.38);
        vec3 color=mix(deep,mist,t*.72);
        color=mix(color,amber,pow(max(t-.5,0.)*2.,3.)*.18);
        vec3 light=normalize(vec3(.78,.44,.46));
        float diffuse=max(dot(normalize(vNormal),light),0.);
        float rim=pow(1.-max(dot(normalize(vNormal),vec3(0.,0.,1.)),0.),4.);
        gl_FragColor=vec4(color*(.25+.83*diffuse)+vec3(.2,.42,.75)*rim*.38,1.);
      }`,
    });
}
