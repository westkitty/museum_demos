import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';
mkdirSync('.test-compiled',{recursive:true});
const tsc = process.platform==='win32' ? 'tsc.cmd' : 'tsc';
try{
  execFileSync(tsc,['--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext','--outDir','.test-compiled','--strict','--skipLibCheck','src/domain.ts','src/physics.ts','src/presentation.ts'],{stdio:'inherit'});
}catch{
  console.error('The pure-system tests require TypeScript. Install dependencies with npm install, then npm test.');
  process.exitCode=1;
}
if(!process.exitCode){
  await import('../tests/level.test.mjs');
  await import('../tests/visual-contract.test.mjs');
  await import('../tests/premium-pass.test.mjs');
}
