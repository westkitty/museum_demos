import test from 'node:test';
import assert from 'node:assert/strict';
import {CHAPTERS,PLATFORMS,CHECKPOINTS,FINISH_X,chapterFor,validateCourse,checkpointFor,surfaceUnder} from '../src/course.js';
import {createPlayer,simulate} from '../src/physics.js';
test('the course is exactly four ordered contiguous chapters',()=>{
 assert.equal(validateCourse().length,0,validateCourse().join(', '));
 assert.equal(CHAPTERS.length,4);
 assert.deepEqual(CHAPTERS.map(x=>x.id),['duncan','outskirts','cedar','sentinel']);
});
test('chapter transitions are monotonic and final escape is in chapter 4',()=>{
 for(let x=0,last=0;x<FINISH_X;x+=.2){const i=chapterFor(x);assert.ok(i>=last);last=i;}
 assert.equal(chapterFor(FINISH_X),3);
});
test('every checkpoint rests on actual solid geometry',()=>{
 for(const p of CHECKPOINTS){const floor=surfaceUnder(p.x,p.y+.01);assert.ok(floor,`${p.id} has no platform`);assert.ok(Math.abs(floor.top-p.y)<.02);}
});
test('checkpoints do not regress when moving backwards',()=>{
 assert.equal(checkpointFor(128).id,'last-light');assert.equal(checkpointFor(80).id,'cedar-approach');
});
test('all required horizontal gaps can be crossed with conservative double jump budget',()=>{
 const base=PLATFORMS.filter(p=>p.kind!=='trunk').sort((a,b)=>a.x-b.x);
 // Mechanical guard: no main route gap between successive floor steps exceeds 2 units.
 const route=base.filter(p=>['pavement','moss','cedar','trestle'].includes(p.kind));
 for(let i=0;i<route.length-1;i++){
   const a=route[i],b=route[i+1];const gap=b.x-(a.x+a.w);
   assert.ok(gap<2.3,`Gap ${gap.toFixed(2)} at x ${a.x} → ${b.x} is too large`);
   assert.ok(b.top-a.top<2.1,`Climb at x ${b.x} exceeds assisted single-jump rise`);
 }
});
test('deterministic fixed 60Hz simulation matches repeated runs',()=>{
 const run=()=>{const p=createPlayer(2,1);for(let i=0;i<90;i++)simulate(p,{axis:1,jumpPressed:i===12,jumpHeld:i>=12&&i<34},PLATFORMS,1/60);return [p.x,p.y,p.vx,p.vy,p.grounded];};
 assert.deepEqual(run(),run());
});
