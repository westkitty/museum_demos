import * as THREE from 'three';
import { GardenArt } from './art.js';
import { CAN, DEW, STATIONS, SUMMIT, VINES, sqDistXZ } from './course.js';
import { createMuseumSession } from './host.js';
import { GameInput } from './input.js';
import { GardenSimulation } from './simulation.js';

const $ = (id) => {
    const element = document.getElementById(id);
    if (!element)
        throw new Error(`Missing required DOM element #${id}`);
    return element;
};
const canvas = $('world');
const hud = $('hud'), title = $('title-screen'), pause = $('pause-screen'), win = $('victory-screen'), returned = $('returned-screen');
const touchControls = $('touch-controls');
const game = new GardenSimulation();
const host = createMuseumSession();
const input = new GameInput(canvas, touchControls);
let art;
let renderer;
let scene;
let camera;
let running = true, reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const params = new URLSearchParams(location.search);
const coarse = window.matchMedia('(pointer:coarse)').matches;
const visualQuality = params.get('quality') === 'lite' || (params.get('quality') !== 'rich' && (coarse || (navigator.hardwareConcurrency || 8) < 6)) ? 'lite' : 'rich';
let snapCamera = true;
const cameraAim = new THREE.Vector3();
const focusTarget = new THREE.Vector3();
const desiredCamera = new THREE.Vector3();
const velocityLead = new THREE.Vector3();
document.documentElement.classList.toggle('reduced-motion', reducedMotion);
document.documentElement.dataset.visualQuality = visualQuality;
let toastEnd = 0, victoryAnim = -1, victoryCameraFrom;
let currentAnimation = 0, lastFrame = 0, accumulator = 0, frames = 0;
const STEP = 1 / 60;
const SAVE_KEY = 'overwatered.progress.v1';
const show = (el, visible) => el.classList.toggle('hidden', !visible);
const timer = (n) => `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(Math.floor(n % 60)).padStart(2, '0')}`;
const reducedInputs = [$('reduced-motion-title'), $('reduced-motion-pause')];
for (const field of reducedInputs) {
    field.checked = reducedMotion;
    field.addEventListener('change', () => {
        reducedMotion = field.checked;
        reducedInputs.forEach(item => item.checked = reducedMotion);
        document.documentElement.classList.toggle('reduced-motion', reducedMotion);
    });
}
function stored() {
    try {
        const data = localStorage.getItem(SAVE_KEY);
        return data ? JSON.parse(data) : null;
    }
    catch {
        return null;
    }
}
function save() { try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(game.serialize()));
}
catch { /* Private browsing may deny persistent storage. */ } }
function erase() { try {
    localStorage.removeItem(SAVE_KEY);
}
catch { /* Optional storage only. */ } }
function announce(text, seconds = 4) {
    const toast = $('toast');
    toast.textContent = text;
    show(toast, true);
    toastEnd = performance.now() + seconds * 1000;
}
function toastEvents(events) {
    for (const event of events) {
        art?.onEvent(event, game.state);
        switch (event.type) {
            case 'toast':
                announce(event.message);
                break;
            case 'grow':
            case 'checkpoint':
                save();
                break;
            case 'summit':
                save();
                break;
            case 'respawn':
                save();
                snapCamera = true;
                break;
            case 'victory':
                save();
                victoryAnim = 0;
                victoryCameraFrom = camera?.position.clone();
                art?.revealSpare();
                input.reset();
                $('victory-stat').textContent = `${timer(game.state.elapsed)} OF AGRICULTURAL HEROISM · ${game.state.deaths} BOTANICAL INSURANCE CLAIM${game.state.deaths === 1 ? '' : 'S'}`;
                break;
            case 'dew': break;
        }
    }
}
function updateHud() {
    const s = game.state, p = s.player.position;
    $('timer').textContent = timer(s.elapsed);
    $('water-label').textContent = `${s.water} / 3`;
    $('water-meter').style.width = `${s.water / 3 * 100}%`;
    $('power-label').textContent = `${Math.round(s.power)}%`;
    $('power-meter').style.width = `${s.power}%`;
    $('seed-dots').querySelectorAll('span').forEach((e, i) => e.classList.toggle('done', i < s.grown));
    const headings = [
        ['Find the first glowing seed altar', 'Water the seed. Yes, this requires an entire quest.'],
        ['Ascend the enormous leaves', 'Follow the new leaf staircase to the second altar. Near vines, hold forward + jump to climb.'],
        ['Cross the flowering rafters', 'The next seed altar waits above the giant blossoms.'],
        ['Reach the royal sunflower', 'Ascend the last petal path to the sunflower summit.'],
        ['The flight of excessive importance', 'Unfold the glider in midair. Release forward to slow down, and fold it to land on the can island.']
    ];
    const index = s.summitVisited ? 4 : Math.min(3, s.grown);
    $('quest-title').textContent = headings[index][0];
    $('quest-detail').textContent = headings[index][1];
    const sections = ['01 · GERMINATION', '02 · BLOOM', '03 · SUMMONS', '04 · THE GREAT GLIDE'];
    $('chapter-name').textContent = sections[index] ?? sections[3];
    $('progress-rail').querySelectorAll('[data-chapter]').forEach((node, i) => {
        node.classList.toggle('active', i === index);
        node.classList.toggle('complete', i < index);
        node.setAttribute('aria-current', i === index ? 'step' : 'false');
    });
    const prompt = $('context-prompt');
    let text = '';
    if (s.phase === 'playing') {
        const station = STATIONS[s.grown];
        if (station && Math.abs(p.y - station.y) < 2.3 && sqDistXZ(p.x, p.z, station.x, station.z) < 17) {
            text = s.water >= station.costWater && s.power >= station.costPower ? `[ E / WATER ] GROW ${station.name}` : 'LOW SUPPLIES · Stand near the BLUE DEW COLLECTOR';
        }
        else if (DEW.some((d, i) => i <= s.grown && Math.abs(p.y - d.y) < 2.1 && sqDistXZ(p.x, p.z, d.x, d.z) < 12)) {
            text = 'BLUE DEW COLLECTOR · AUTO-REFILLS WATER AND POWER';
        }
        else if (VINES.some(v => v.stage <= s.grown && Math.abs(p.y - (v.base + v.top) / 2) < (v.top - v.base) / 2 + 1 && sqDistXZ(p.x, p.z, v.x, v.z) < 18)) {
            text = 'HOLD W + SPACE TO CLIMB · NO STAMINA LIMIT';
        }
        else if (s.summitVisited && sqDistXZ(p.x, p.z, SUMMIT.x, SUMMIT.z) < 180) {
            text = 'RUN · JUMP · PRESS G OR SPACE IN AIR TO UNFOLD THE GLIDER';
        }
        else if (s.grown === 0) {
            text = 'FOLLOW THE STONE PATH TO THE FIRST SEED STATION';
        }
    }
    prompt.textContent = text;
    show(prompt, Boolean(text));
    show($('glide-meter'), s.summitLaunch && s.phase === 'playing');
    $('glide-progress-fill').style.width = `${Math.min(100, s.longGlideDistance / 70 * 100)}%`;
    $('glide-distance').textContent = `${Math.round(s.longGlideDistance)} m`;
    $('resources-hint').textContent = s.water === 0 ? 'Seek a glowing blue dew collector. It renews.' : 'Dew regenerates in 10 seconds. No unwinnable heroics.';
}
function setInterface(phase) {
    show(title, phase === 'title');
    show(hud, phase === 'playing' || phase === 'paused' || phase === 'victory');
    show(pause, phase === 'paused');
    show(win, phase === 'victory' && victoryAnim >= 3.25);
    show(returned, phase === 'returned');
    show(touchControls, phase === 'playing' && (window.matchMedia('(pointer:coarse)').matches || new URLSearchParams(location.search).get('touch') === '1'));
    document.documentElement.classList.toggle('touch-active', !touchControls.classList.contains('hidden'));
}
function begin(continueRun = false) {
    if (!continueRun) {
        game.restart();
        erase();
        art?.hideSpare();
    }
    else {
        const data = stored();
        if (data && !game.restore(data))
            game.restart();
    }
    game.start();
    input.reset();
    snapCamera = true;
    victoryAnim = -1;
    victoryCameraFrom = undefined;
    setInterface('playing');
    updateHud();
    announce('GARDEN DIVISION: The watering can has been declared a matter of national importance.', 5);
}
function pauseGame() { game.pause(); input.reset(); setInterface('paused'); $('resume-btn').focus(); }
function resumeGame() { game.resume(); setInterface('playing'); $('pause-btn').focus(); }
async function returnToMuseum() {
    const s = game.state;
    const result = { outcome: s.won ? 'complete' : 'abandoned', elapsedSeconds: s.elapsed, stagesGrown: s.grown };
    try {
        const payload = await host.returnToMuseum(result);
        if (!host.realHost) {
            $('return-state').textContent = JSON.stringify({ restoredVisitorSnapshot: payload.visitorSnapshot, outcome: payload.outcome }, null, 2);
            game.returnToMuseum();
            setInterface('returned');
            $('reenter-btn').focus();
        }
    }
    catch (err) {
        announce(`Museum handoff could not complete: ${err instanceof Error ? err.message : 'Unknown error'}`, 7);
    }
}
$('enter-btn').addEventListener('click', () => begin(false));
$('continue-btn').addEventListener('click', () => begin(true));
$('pause-btn').addEventListener('click', pauseGame);
$('resume-btn').addEventListener('click', resumeGame);
$('restart-btn').addEventListener('click', () => begin(false));
$('replay-btn').addEventListener('click', () => begin(false));
$('return-btn').addEventListener('click', () => { void returnToMuseum(); });
$('victory-return-btn').addEventListener('click', () => { void returnToMuseum(); });
$('reenter-btn').addEventListener('click', () => begin(false));
window.addEventListener('keydown', (event) => {
    if (event.code === 'Escape') {
        if (game.state.phase === 'playing')
            pauseGame();
        else if (game.state.phase === 'paused')
            resumeGame();
    }
});
document.addEventListener('visibilitychange', () => { if (document.hidden && game.state.phase === 'playing')
    pauseGame(); });
function cameraUpdate(dt) {
    if (!camera)
        return;
    const s = game.state;
    if (s.phase === 'title' || s.phase === 'returned') {
        const t = reducedMotion ? 0 : currentAnimation * .06;
        const from = new THREE.Vector3(39 + Math.sin(t) * 5, 29 + Math.sin(t * .7) * 2, -53 + Math.cos(t * .6) * 5);
        camera.position.lerp(from, reducedMotion ? 1 : Math.min(1, dt * 2));
        camera.lookAt(new THREE.Vector3(2, 18, 34));
        return;
    }
    if (s.phase === 'victory') {
        victoryAnim += dt;
        const start = victoryCameraFrom ?? camera.position;
        const finish = new THREE.Vector3(26, 13, -42);
        const t = THREE.MathUtils.smoothstep(victoryAnim, 0, 3.1);
        camera.position.lerpVectors(start, finish, reducedMotion ? 1 : t);
        const aim = new THREE.Vector3().lerpVectors(new THREE.Vector3(CAN.x, CAN.y + 3, CAN.z), new THREE.Vector3(9, 1.5, -25), reducedMotion ? 1 : t);
        camera.lookAt(aim);
        if (victoryAnim >= 3.25 && !win.classList.contains('hidden'))
            return;
        if (victoryAnim >= 3.25) {
            setInterface('victory');
            $('replay-btn').focus();
        }
        return;
    }
    const p = s.player.position;
    const v = s.player.velocity;
    const gliding = s.player.gliding;
    const horizontalSpeed = Math.hypot(v.x, v.z);
    const yaw = input.cameraYaw;
    const followDist = gliding ? 18.6 : 12.6;
    const followHeight = gliding ? 9.4 : 7.2;
    velocityLead.set(v.x * .17, 0, Math.max(0, v.z) * .3);
    focusTarget.set(p.x, p.y + (gliding ? 2.4 : 1.9), p.z + 2.7).add(velocityLead);
    desiredCamera.set(p.x - Math.sin(yaw) * followDist, p.y + followHeight, p.z - Math.cos(yaw) * followDist);
    const snap = snapCamera || reducedMotion;
    if (snap) {
        camera.position.copy(desiredCamera);
        cameraAim.copy(focusTarget);
        snapCamera = false;
    }
    else {
        camera.position.lerp(desiredCamera, 1 - Math.exp(-dt * (gliding ? 4.2 : 6.2)));
        cameraAim.lerp(focusTarget, 1 - Math.exp(-dt * 10));
    }
    camera.lookAt(cameraAim);
    const targetFov = 66 + (gliding ? 6.5 : Math.min(1.8, horizontalSpeed * .17));
    const nextFov = snap ? targetFov : THREE.MathUtils.lerp(camera.fov, targetFov, 1 - Math.exp(-dt * 2.8));
    if (Math.abs(camera.fov - nextFov) > .02) {
        camera.fov = nextFov;
        camera.updateProjectionMatrix();
    }
}
function frame(timestamp) {
    if (!running)
        return;
    const dt = lastFrame ? Math.min(.1, (timestamp - lastFrame) / 1000) : STEP;
    lastFrame = timestamp;
    currentAnimation += dt;
    if (game.state.phase === 'playing') {
        accumulator = Math.min(.18, accumulator + dt);
        let count = 0;
        while (accumulator >= STEP && count < 5) {
            const controls = input.sample(STEP);
            toastEvents(game.step(STEP, controls));
            accumulator -= STEP;
            count++;
            if (game.state.phase !== 'playing')
                break;
        }
    }
    else {
        accumulator = 0;
    }
    if (art && renderer && scene && camera) {
        art.update(dt, game.state, reducedMotion);
        cameraUpdate(dt);
        renderer.render(scene, camera);
    }
    if (performance.now() > toastEnd)
        show($('toast'), false);
    if (++frames % 6 === 0)
        updateHud();
    requestAnimationFrame(frame);
}
function setupRenderer() {
    try {
        const context = canvas.getContext('webgl2', { alpha: false, antialias: true, powerPreference: 'high-performance' });
        if (!context)
            throw new Error('A functioning WebGL 2 context is required.');
        renderer = new THREE.WebGLRenderer({ canvas, context, antialias: true, powerPreference: 'high-performance' });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, visualQuality === 'lite' ? 1.1 : 1.6));
        renderer.setSize(window.innerWidth, window.innerHeight, false);
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.14;
        renderer.shadowMap.enabled = visualQuality === 'rich';
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        scene = new THREE.Scene();
        camera = new THREE.PerspectiveCamera(66, window.innerWidth / window.innerHeight, .2, 460);
        camera.position.set(39, 29, -53);
        art = new GardenArt(scene, visualQuality);
        art.update(0, game.state, reducedMotion);
        const resize = () => {
            if (!renderer || !camera)
                return;
            camera.aspect = window.innerWidth / Math.max(1, window.innerHeight);
            camera.updateProjectionMatrix();
            renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, visualQuality === 'lite' ? 1.1 : 1.6));
            renderer.setSize(window.innerWidth, window.innerHeight, false);
        };
        window.addEventListener('resize', resize);
        const existing = stored();
        if (existing && game.restore(existing) && !game.state.won) {
            show($('continue-btn'), true);
        }
        else
            game.state.phase = 'title';
        setInterface('title');
        requestAnimationFrame(frame);
    }
    catch (e) {
        const message = e instanceof Error ? e.message : String(e);
        $('error-message').textContent = message;
        show($('error-screen'), true);
        show(title, false);
        show(hud, false);
        console.error('Garden renderer initialization failed:', e);
    }
}
// Explicitly dev-only instrumentation for deterministic browser smoke tests.
if (({DEV:false,PROD:true,MODE:"production",BASE_URL:"./"}).DEV && new URLSearchParams(location.search).has('debug')) {
    Object.assign(window, {
        __GARDEN_DEBUG__: {
            getState: () => JSON.parse(JSON.stringify(game.state)),
            getRenderer: () => renderer?.info.render,
            getVisualQuality: () => visualQuality,
            getVisualStats: () => renderer ? { ...renderer.info.render, geometries: renderer.info.memory.geometries, textures: renderer.info.memory.textures } : null,
            begin: () => begin(false),
            warp: (x, y, z) => { game.state.player.position = { x, y, z }; game.state.player.velocity = { x: 0, y: 0, z: 0 }; game.state.player.grounded = true; },
            water: () => { const result = game.water(); toastEvents(game.drainEvents()); return result; },
            run: (steps, controls = {}) => {
                let events = [];
                for (let i = 0; i < Math.min(steps, 20000); i++)
                    events = events.concat(game.step(STEP, controls));
                toastEvents(events);
                return events;
            }
        }
    });
}
window.addEventListener('pagehide', () => {
    running = false;
    input.dispose();
    art?.dispose();
    renderer?.dispose();
    renderer?.forceContextLoss();
}, { once: true });
setupRenderer();
