import { MAX_SIM_DT } from './domain.js';
export const MOVE_SPEED = 8.9;
export const DEPTH_SPEED = 5.8;
export const GRAVITY = 27;
export const JUMP_SPEED = 11.8;
export const PLAYER_RADIUS = 0.39;
export class PlayerPhysics {
    state;
    constructor() { this.state = { x: -8, y: 0, z: 0, vx: 0, vy: 0, vz: 0, grounded: true }; }
    reset(x = -8) { this.state = { x, y: 0, z: 0, vx: 0, vy: 0, vz: 0, grounded: true }; }
    step(dt, xAxis, zAxis, jump, floors) {
        dt = Math.min(Math.max(dt, 0), MAX_SIM_DT);
        const s = this.state;
        const ax = Math.max(-1, Math.min(1, xAxis));
        const az = Math.max(-1, Math.min(1, zAxis));
        s.vx = ax * MOVE_SPEED;
        s.vz = az * DEPTH_SPEED;
        if (jump && s.grounded) {
            s.vy = JUMP_SPEED;
            s.grounded = false;
        }
        s.x = Math.max(-14.4, Math.min(179.2, s.x + s.vx * dt));
        s.z = Math.max(-3.5, Math.min(3.5, s.z + s.vz * dt));
        const prevY = s.y;
        s.vy -= GRAVITY * dt;
        s.y += s.vy * dt;
        let landed = -Infinity;
        if (s.vy <= 0) {
            for (const f of floors) {
                const overlapsX = s.x + PLAYER_RADIUS >= f.minX && s.x - PLAYER_RADIUS <= f.maxX;
                const overlapsZ = s.z + PLAYER_RADIUS >= f.minZ && s.z - PLAYER_RADIUS <= f.maxZ;
                if (overlapsX && overlapsZ && prevY >= f.top - 0.11 && s.y <= f.top + 0.02 && f.top > landed) {
                    landed = f.top;
                }
            }
        }
        if (Number.isFinite(landed)) {
            s.y = landed;
            s.vy = 0;
            s.grounded = true;
        }
        else {
            s.grounded = false;
        }
    }
}
