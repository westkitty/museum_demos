export function safeReturnPath(raw) {
    if (!raw || !raw.startsWith('/') || raw.startsWith('//') || raw.includes('\\'))
        return null;
    try {
        const url = new URL(raw, window.location.origin);
        if (url.origin !== window.location.origin)
            return null;
        return url.pathname + url.search + url.hash;
    }
    catch {
        return null;
    }
}
export function returnToMuseum(completed) {
    const q = new URLSearchParams(window.location.search);
    const receipt = {
        type: 'museum:pocket-world:return', protocol: 1, exhibitId: 'E31',
        prototypeId: 'gardens-opposite-time', completed
    };
    // Explicit parent origin is required. Never send a museum message to '*'.
    const candidate = q.get('museumOrigin');
    if (candidate && window.parent !== window) {
        try {
            const origin = new URL(candidate);
            if ((origin.protocol === 'https:' || origin.hostname === 'localhost' || origin.hostname === '127.0.0.1') && origin.origin === candidate) {
                window.parent.postMessage(receipt, origin.origin);
                return 'messaged-host';
            }
        }
        catch { /* no authorized host */ }
    }
    const path = safeReturnPath(q.get('returnPath'));
    if (path) {
        window.location.assign(path);
        return 'same-origin-navigation';
    }
    return 'mock-only';
}
