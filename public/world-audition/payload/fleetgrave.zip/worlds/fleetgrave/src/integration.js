export const MUSEUM_RETURN_EVENT = 'museum:pocket-world:return';
export function makeMuseumReturnRequest(state) {
    return {
        contract: 'fleetgrave-return-v1',
        exhibitId: 'E28',
        pocketWorld: 'the-fleetgrave-causeway',
        result: state.completed ? 'completed' : 'exited',
        elapsedSeconds: Number(state.elapsed.toFixed(3)),
        checkpoint: state.checkpoint,
    };
}
/** Emits a local event, plus a same-origin message if this page is framed. Never navigates production. */
export function publishMuseumReturn(request, host = window) {
    host.dispatchEvent(new CustomEvent(MUSEUM_RETURN_EVENT, { detail: request }));
    if (host.parent !== host) {
        host.parent.postMessage({ type: MUSEUM_RETURN_EVENT, payload: request }, host.location.origin);
    }
}
