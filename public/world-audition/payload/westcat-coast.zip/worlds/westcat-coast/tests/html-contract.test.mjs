import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=file=>readFileSync(new URL('../'+file,import.meta.url),'utf8');

test('live chase HUD and reduced-motion controls are represented in the actual HTML/CSS, not only test doubles',()=>{
  const html=read('index.html'),css=read('style.css'),main=read('src/main.js');
  for(const id of ['game','museumOverlay','endOverlay','reducedMotion','chaseCue','chaseMeter','chaseFill','touchControls']){
    assert.equal((html.match(new RegExp('id="'+id+'"','g'))||[]).length,1,`Exactly one #${id} in the real page`);
  }
  assert.match(html,/id="chaseMeter"\s+role="meter"\s+aria-label="Safe distance from the Sentinel"/);
  assert.match(html,/id="chaseCue"[^>]*hidden/);
  assert.match(css,/\.chase-cue\.urgent/);
  assert.match(css,/:root\[data-motion="reduced"\]/);
  assert.match(main,/document\.documentElement\.dataset\.motion=/);
  assert.match(main,/game\.player\.x-game\.owlX/,'Threat meter must reflect the real existing owl separation');
});
