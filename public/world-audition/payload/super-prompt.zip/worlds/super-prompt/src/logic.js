export const PLAYER_WIDTH = 1.04;
export const PLAYER_HEIGHT = 1.56;
export const MOVE_SPEED = 9.0;
export const GRAVITY = 28;
export const JUMP_SPEED = 13.7;
export const MAX_DT = 1 / 45;
export const WORLD_END = 256;
export const PLATFORMS = [
    { id: 'prologue', x: 8.5, y: -0.92, w: 35, h: 1.84, stage: 0 },
    { id: 'level-1', x: 31, y: 0.75, w: 13, h: 1.5, stage: 0 },
    { id: 'level-2', x: 44, y: 2.6, w: 13, h: 1.6, stage: 0 },
    { id: 'dusk-balcony', x: 58.5, y: 4.55, w: 17, h: 1.7, stage: 0 },
    { id: 'dusk-stair-a', x: 73.5, y: 6.15, w: 13, h: 1.7, stage: 1 },
    { id: 'dusk-stair-b', x: 88, y: 8.05, w: 15, h: 1.7, stage: 1 },
    { id: 'wide-balcony', x: 104, y: 9.85, w: 17, h: 1.7, stage: 1 },
    { id: 'wide-bridge-a', x: 121, y: 8.9, w: 18, h: 1.35, stage: 2, kind: 'bridge' },
    { id: 'wide-bridge-b', x: 140.5, y: 10.65, w: 19, h: 1.4, stage: 2, kind: 'bridge' },
    { id: 'wide-bridge-c', x: 159.5, y: 12.65, w: 17, h: 1.5, stage: 2, kind: 'bridge' },
    { id: 'edit-balcony', x: 178.8, y: 14.15, w: 23, h: 1.65, stage: 2 },
    { id: 'final-step-a', x: 198.5, y: 15.9, w: 16, h: 1.6, stage: 3 },
    { id: 'final-step-b', x: 216.3, y: 17.65, w: 18, h: 1.7, stage: 3 },
    { id: 'parade-roof', x: 238.2, y: 18.85, w: 27, h: 1.75, stage: 3 }
];
export const SWITCHES = [
    { x: 60.8, footY: 5.4, stage: 1, key: 'dusk', label: 'At dusk' },
    { x: 105.6, footY: 10.7, stage: 2, key: 'wide', label: 'Wide framing' },
    { x: 183.6, footY: 14.975, stage: 3, key: 'constraints', label: 'No people · No text' }
];
export const CHECKPOINTS = [
    { x: 5.5, y: 0, stage: 0 },
    { x: 59.2, y: 5.4, stage: 1 },
    { x: 104.5, y: 10.7, stage: 2 },
    { x: 182.5, y: 14.975, stage: 3 }
];
export const EXIT = { x: 247.7, footY: 19.725 };
export const GATES = [
    { id: 'gate-style', x: 67.6, y: 9.5, w: .65, h: 11, stage: 0, unlock: 1 },
    { id: 'gate-composition', x: 112.3, y: 15.6, w: .65, h: 11, stage: 0, unlock: 2 },
    { id: 'gate-constraints', x: 190.55, y: 20.1, w: .65, h: 11, stage: 0, unlock: 3 }
];
export function activeColliders(stage) { return [...activePlatforms(stage), ...GATES.filter(g => stage < g.unlock)]; }
const NONE = { axis: 0, jump: false, jumpPressed: false, activate: false };
export function activePlatforms(stage) { return PLATFORMS.filter(p => p.stage <= stage); }
export function top(p) { return p.y + p.h / 2; }
export function bottom(p) { return p.y - p.h / 2; }
export function freshState() {
    return { stage: 0, player: { x: 5.5, y: 0, vx: 0, vy: 0, grounded: true, facing: 1, coyote: .1, jumpBuffer: 0 }, checkpoint: { ...CHECKPOINTS[0] }, deaths: 0, won: false, started: false, paused: false, steps: 0, message: '', messageTime: 0, parade: false, transition: 0 };
}
export function safeRespawn(state) {
    const { x, y } = state.checkpoint;
    state.player = { x, y, vx: 0, vy: 0, grounded: true, facing: 1, coyote: .11, jumpBuffer: 0 };
    state.deaths += 1;
    state.message = 'A minor editorial setback. Checkpoint restored.';
    state.messageTime = 3.1;
    state.transition = 0;
}
export function restoreCheckpoint(stage, deaths = 0) {
    const g = freshState();
    g.stage = stage;
    g.deaths = deaths;
    g.checkpoint = { ...CHECKPOINTS[stage] };
    g.started = true;
    const { x, y } = g.checkpoint;
    g.player.x = x;
    g.player.y = y;
    return g;
}
export function canActivate(state) {
    const s = SWITCHES[state.stage];
    if (!s)
        return null;
    if (Math.abs(state.player.x - s.x) < 3.55 && Math.abs(state.player.y - s.footY) < 3.1)
        return s;
    return null;
}
export function activate(state) {
    if (!state.started || state.paused || state.won)
        return 'none';
    const near = canActivate(state);
    if (near) {
        state.stage = near.stage;
        state.checkpoint = { ...CHECKPOINTS[near.stage] };
        state.transition = 2.8;
        state.message = near.stage === 1 ? 'The tower remembers the evening.' : near.stage === 2 ? 'Composition widened. The missing route is now solid.' : 'Prohibitions respected. Your clay existence is unaffected.';
        state.messageTime = 4.1;
        return near.key;
    }
    if (state.stage === 3 && Math.abs(state.player.x - EXIT.x) < 4.25 && Math.abs(state.player.y - EXIT.footY) < 3.4) {
        state.won = true;
        state.parade = true;
        state.message = 'Approved, somehow.';
        state.messageTime = 1000;
        return 'exit';
    }
    state.message = 'Nothing here is ready to be instructed.';
    state.messageTime = 2.1;
    return 'none';
}
// Pure geometry solver: deterministic broad-phase + swept axis collision at a fixed step.
export function step(state, input = NONE, dt = 1 / 120) {
    if (!state.started || state.paused || state.won)
        return state;
    const t = Math.min(MAX_DT, Math.max(0, dt));
    state.steps++;
    state.messageTime = Math.max(0, state.messageTime - t);
    state.transition = Math.max(0, state.transition - t);
    if (input.activate)
        activate(state);
    const p = state.player;
    const accel = p.grounded ? 47 : 29;
    const requested = input.axis * MOVE_SPEED;
    if (p.vx < requested)
        p.vx = Math.min(requested, p.vx + accel * t);
    else if (p.vx > requested)
        p.vx = Math.max(requested, p.vx - accel * t);
    if (input.axis !== 0)
        p.facing = input.axis;
    p.coyote = p.grounded ? .11 : Math.max(0, p.coyote - t);
    p.jumpBuffer = input.jumpPressed ? .13 : Math.max(0, p.jumpBuffer - t);
    if (p.jumpBuffer > 0 && p.coyote > 0) {
        p.vy = JUMP_SPEED;
        p.grounded = false;
        p.coyote = 0;
        p.jumpBuffer = 0;
    }
    const world = activeColliders(state.stage);
    const half = PLAYER_WIDTH / 2;
    const oldX = p.x;
    p.x += p.vx * t;
    for (const a of world) {
        if (p.y + PLAYER_HEIGHT <= bottom(a) + .06 || p.y >= top(a) - .06)
            continue;
        if (p.x + half > a.x - a.w / 2 && p.x - half < a.x + a.w / 2) {
            if (oldX + half <= a.x - a.w / 2 + .02 && p.vx > 0) {
                p.x = a.x - a.w / 2 - half;
                p.vx = 0;
            }
            else if (oldX - half >= a.x + a.w / 2 - .02 && p.vx < 0) {
                p.x = a.x + a.w / 2 + half;
                p.vx = 0;
            }
        }
    }
    p.x = Math.max(-7, Math.min(WORLD_END, p.x));
    const oldY = p.y;
    p.vy = Math.max(-27, p.vy - GRAVITY * t);
    p.y += p.vy * t;
    p.grounded = false;
    for (const a of world) {
        if (p.x + half < a.x - a.w / 2 + .02 || p.x - half > a.x + a.w / 2 - .02)
            continue;
        const surface = top(a);
        if (p.vy <= 0 && oldY >= surface - .065 && p.y <= surface) {
            p.y = surface;
            p.vy = 0;
            p.grounded = true;
        }
        else if (p.vy > 0 && oldY + PLAYER_HEIGHT <= bottom(a) + .05 && p.y + PLAYER_HEIGHT >= bottom(a)) {
            p.y = bottom(a) - PLAYER_HEIGHT;
            p.vy = 0;
        }
    }
    if (p.grounded)
        p.coyote = .11;
    if (p.y < -20)
        safeRespawn(state);
    if (state.stage === 3 && p.x > 228)
        state.parade = true;
    return state;
}
/** Explicit state validation: removal is world-only and cannot affect game-domain entities. */
export function contentAllowed(stage) { return { people: stage < 3, worldText: stage < 3, clayPlayer: true, domInstructions: true }; }
/** Path graph, conservative jump physics and platform collision coverage. */
export function routeGraph(stage) {
    const ps = activePlatforms(stage);
    const out = {};
    const airtime = 2 * JUMP_SPEED / GRAVITY;
    const maxJumpX = MOVE_SPEED * airtime * .91;
    const maxRise = JUMP_SPEED * JUMP_SPEED / (2 * GRAVITY) - .25;
    for (const a of ps) {
        out[a.id] = [];
        for (const b of ps) {
            if (a === b)
                continue;
            const gap = Math.max(0, Math.abs(a.x - b.x) - (a.w + b.w) / 2);
            const rise = top(b) - top(a);
            if (gap <= maxJumpX && rise <= maxRise && rise > -8)
                out[a.id].push(b.id);
        }
    }
    return out;
}
export function canReach(stage, fromId, toId) {
    const graph = routeGraph(stage), seen = new Set([fromId]), todo = [fromId];
    while (todo.length) {
        const id = todo.shift();
        if (id === toId)
            return true;
        for (const n of graph[id] ?? [])
            if (!seen.has(n)) {
                seen.add(n);
                todo.push(n);
            }
    }
    return false;
}
