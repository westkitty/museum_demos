import * as THREE from 'three';
import { POINTS, easeInOut } from './rules.js';
import { IslandArtDirection } from './artDirection.js';
import { LittleGloriesFinishing } from './finishing.js';
const C = {
    ivory: 0xffefc9, gold: 0xf4bf65, honey: 0xe59f55, teal: 0x5af5d9,
    violet: 0xcaa4ff, deep: 0x273c49, ink: 0x1a3341, river: 0x3fbdd5,
};
const seeded = (seed) => {
    let s = seed >>> 0;
    return () => ((s = (Math.imul(1664525, s) + 1013904223) >>> 0) / 4294967296);
};
function material(hex, roughness = 0.85, metalness = 0) {
    return new THREE.MeshStandardMaterial({ color: hex, roughness, metalness });
}
function mesh(geo, mat, shadow = true) {
    const m = new THREE.Mesh(geo, mat);
    m.castShadow = shadow;
    m.receiveShadow = true;
    return m;
}
function addBall(parent, color, radius, x, y, z, segments = 12) {
    const b = mesh(new THREE.SphereGeometry(radius, segments, Math.max(8, segments >> 1)), material(color));
    b.position.set(x, y, z);
    parent.add(b);
    return b;
}
function addBox(parent, color, size, x, y, z) {
    const b = mesh(new THREE.BoxGeometry(...size), material(color));
    b.position.set(x, y, z);
    parent.add(b);
    return b;
}
function groundY(x, z) {
    const rad = Math.hypot(x, z);
    const mound = 0.38 * Math.exp(-Math.pow((x + 3.4) / 2.6, 2) - Math.pow((z + 3.2) / 2.1, 2));
    const slope = 0.13 * Math.sin(x * 0.57 + 0.6) * Math.cos(z * 0.72);
    return 0.24 + mound + slope + 0.05 * Math.sin(rad * 1.2);
}
function ring(parent, x, z, radius, hex, opacity = 0.76) {
    const m = mesh(new THREE.TorusGeometry(radius, 0.048, 7, 90), new THREE.MeshBasicMaterial({
        color: hex, transparent: true, opacity, depthWrite: false,
    }), false);
    m.rotation.x = Math.PI / 2;
    m.position.set(x, groundY(x, z) + 0.11, z);
    parent.add(m);
    return m;
}
function lineRibbon(points, width, color, parent) {
    const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(p.x, groundY(p.x, p.z) + 0.07, p.z)));
    const n = 80;
    const vertices = [];
    const indices = [];
    for (let i = 0; i <= n; i++) {
        const t = i / n;
        const p = curve.getPoint(t);
        const tangent = curve.getTangent(t).normalize();
        const ortho = new THREE.Vector3(tangent.z, 0, -tangent.x).normalize();
        for (const sign of [-1, 1]) {
            const x = p.x + ortho.x * sign * width / 2;
            const z = p.z + ortho.z * sign * width / 2;
            vertices.push(x, groundY(x, z) + 0.085, z);
        }
        if (i < n) {
            const j = 2 * i;
            indices.push(j, j + 1, j + 2, j + 1, j + 3, j + 2);
        }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    g.setIndex(indices);
    g.computeVertexNormals();
    const m = mesh(g, new THREE.MeshStandardMaterial({ color, side: THREE.DoubleSide, roughness: 1 }), false);
    m.receiveShadow = true;
    parent.add(m);
    return m;
}
export class IslandWorld {
    scene;
    camera;
    renderer;
    residents = [];
    safeResidents = [];
    hand = new THREE.Group();
    wind = new THREE.Group();
    sign = new THREE.Group();
    markers;
    cameraTarget = new THREE.Vector3(0, 0, 0);
    ocean;
    art;
    finishing;
    sun;
    moon;
    rock;
    wardRing;
    pulse = [];
    confettiMesh;
    confettiSeeds = [];
    lastConfettiUpdate = -1;
    effectSeeds = [];
    effectPoints;
    effectPalette = '';
    instanceTransform = new THREE.Object3D();
    sparkles = [];
    sparkleBaseY = [];
    flyingLights = [];
    flyingLightBaseY = [];
    windStrands = [];
    halo;
    inputPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.25);
    raycaster = new THREE.Raycaster();
    rand = seeded(30117);
    cameraBase = new THREE.Vector3(16, 18, 22);
    cameraFinal = new THREE.Vector3(19.7, 24.2, 27.5);
    pointerNdc = new THREE.Vector2();
    pulseTime = 0;
    eventName = '';
    eventDuration = 0;
    handFingers = [];
    disposed = false;
    lastWidth = 0;
    lastHeight = 0;
    constructor(canvas) {
        const scene = this.scene = new THREE.Scene();
        scene.background = new THREE.Color(0x718f99);
        scene.fog = new THREE.FogExp2(0xa3b7ad, 0.010);
        this.camera = new THREE.OrthographicCamera(-13, 13, 8, -8, 0.1, 180);
        this.camera.position.copy(this.cameraBase);
        this.camera.lookAt(this.cameraTarget);
        this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
        const r = this.renderer;
        r.setClearAlpha(0);
        r.outputColorSpace = THREE.SRGBColorSpace;
        r.toneMapping = THREE.ACESFilmicToneMapping;
        r.toneMappingExposure = 1.24;
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.PCFSoftShadowMap;
        scene.add(new THREE.HemisphereLight(0xf3faff, 0x6b7858, 1.56));
        const sun = this.sun = new THREE.DirectionalLight(0xffe1a8, 3.25);
        sun.position.set(-9, 23, 13);
        sun.castShadow = true;
        sun.shadow.mapSize.set(2048, 2048);
        sun.shadow.camera.left = -13;
        sun.shadow.camera.right = 13;
        sun.shadow.camera.top = 13;
        sun.shadow.camera.bottom = -13;
        sun.shadow.camera.near = 0.1;
        sun.shadow.camera.far = 54;
        sun.shadow.bias = -0.0002;
        sun.shadow.normalBias = 0.025;
        scene.add(sun);
        const fill = new THREE.DirectionalLight(0x89c5dc, .92);
        fill.position.set(12, 7, -9);
        scene.add(fill);
        const warm = new THREE.PointLight(0xffd1a0, 7.5, 11, 2);
        warm.position.set(0.3, 4.8, 0);
        scene.add(warm);
        this.createAtmosphere();
        this.ocean = this.createOcean();
        this.makeIsland();
        this.createPaths();
        this.createVillage();
        this.createFlora();
        this.createBridge();
        this.createResidents();
        this.rock = this.createRock();
        this.createSquare();
        this.wind = this.createWind();
        this.scene.add(this.wind);
        this.sign = this.createSign();
        this.scene.add(this.sign);
        this.wardRing = this.createWardRing();
        this.scene.add(this.wardRing);
        this.art = new IslandArtDirection(scene, groundY);
        this.finishing = new LittleGloriesFinishing(scene, groundY);
        this.markers = {
            strike: ring(scene, POINTS.strike.x, POINTS.strike.z, 0.64, C.gold),
            sweep: ring(scene, POINTS.windStart.x, POINTS.windStart.z, 0.65, C.teal),
            ward: ring(scene, POINTS.sign.x, POINTS.sign.z, 1.15, C.violet),
        };
        this.createEffects();
        this.createDivineHand();
        this.scene.add(this.hand);
        const halo = this.halo = ring(this.hand, 0, 0, 0.76, 0xffeab9, 0.5);
        halo.position.set(0, -0.42, 0);
    }
    createAtmosphere() {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 256;
        const ctx = canvas.getContext('2d');
        const gr = ctx.createRadialGradient(128, 128, 2, 128, 128, 128);
        gr.addColorStop(0, 'rgba(255,246,191,1)');
        gr.addColorStop(.23, 'rgba(255,218,142,.82)');
        gr.addColorStop(.55, 'rgba(255,223,165,.24)');
        gr.addColorStop(1, 'rgba(255,223,165,0)');
        ctx.fillStyle = gr;
        ctx.fillRect(0, 0, 256, 256);
        const tex = new THREE.CanvasTexture(canvas);
        const sprite = this.moon = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false, color: 0xffe5a6 }));
        sprite.position.set(-23, 24, -19);
        sprite.scale.set(28, 28, 1);
        this.scene.add(sprite);
        // Clouds are color-varied but share one draw call and one geometric budget.
        const cloudGeo = new THREE.SphereGeometry(1, 10, 7);
        const clouds = new THREE.InstancedMesh(cloudGeo, new THREE.MeshBasicMaterial({
            color: 0xffffff, transparent: true, opacity: .31, depthWrite: false,
        }), 70);
        const cloudTransform = new THREE.Object3D();
        clouds.frustumCulled = false;
        clouds.castShadow = false;
        for (let i = 0; i < 14; i++) {
            const x = (this.rand() - .5) * 55;
            const z = -22 - this.rand() * 32;
            const y = 9 + this.rand() * 14;
            const color = new THREE.Color(i % 3 === 0 ? 0xfff5e7 : 0xe7fff4);
            for (let j = 0; j < 5; j++) {
                const index = i * 5 + j;
                const radius = .8 + this.rand() * 1.1;
                cloudTransform.position.set(x + (j - 2) * 1.25, y + this.rand() * .26, z + this.rand() * .6);
                cloudTransform.scale.set(radius * 2.4, radius * .38, radius * 1.3);
                cloudTransform.rotation.set(0, 0, 0);
                cloudTransform.updateMatrix();
                clouds.setMatrixAt(index, cloudTransform.matrix);
                clouds.setColorAt(index, color);
            }
        }
        clouds.instanceMatrix.needsUpdate = true;
        this.scene.add(clouds);
        for (let i = 0; i < 12; i++) {
            const b = addBall(this.scene, i % 3 ? 0xffecc4 : 0xccffea, .035 + this.rand() * .045, (this.rand() - .5) * 24, 3.5 + this.rand() * 12, (this.rand() - .5) * 25, 7);
            b.material.emissive = new THREE.Color(0xffd3aa);
            b.material.emissiveIntensity = 1;
            b.castShadow = false;
            this.sparkles.push(b);
            this.sparkleBaseY.push(b.position.y);
        }
    }
    createOcean() {
        const disc = mesh(new THREE.CircleGeometry(12.1, 128), new THREE.MeshPhysicalMaterial({
            color: 0x58b3b4, roughness: 0.22, metalness: .06, transparent: true, opacity: 0.72,
            side: THREE.DoubleSide, clearcoat: 0.65, clearcoatRoughness: .1,
        }), false);
        disc.rotation.x = -Math.PI / 2;
        disc.position.y = -0.08;
        disc.receiveShadow = true;
        this.scene.add(disc);
        for (let i = 0; i < 5; i++) {
            const m = ring(this.scene, 0, 0, 8.5 + i * .55, i % 2 ? 0x9bf0e8 : 0xd2ffed, .21);
            m.position.y = -0.035 + i * .001;
            this.pulse.push(m);
        }
        return disc;
    }
    makeIsland() {
        const rings = 31, segments = 112, rad = 7.64;
        const positions = [], colors = [], indices = [];
        const vColor = new THREE.Color();
        for (let i = 0; i <= rings; i++) {
            for (let j = 0; j <= segments; j++) {
                const a = j / segments * Math.PI * 2;
                const rimNoise = 1 + .026 * Math.sin(a * 11) + .014 * Math.sin(a * 31 + .8);
                const rr = i / rings * rad * rimNoise;
                const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
                const y = groundY(x, z) + (i === rings ? -.08 : 0);
                positions.push(x, y, z);
                const e = .03 * Math.sin(x * 2.5) * Math.cos(z * 3.2);
                vColor.setHSL(.285 + e, .30 + .09 * Math.cos(z * .5), .36 + .08 * (1 - rr / rad) + .06 * Math.exp(-Math.pow(z / 3, 2)));
                colors.push(vColor.r, vColor.g, vColor.b);
            }
        }
        for (let i = 0; i < rings; i++)
            for (let j = 0; j < segments; j++) {
                const a = i * (segments + 1) + j, b = a + segments + 1;
                indices.push(a, b + 1, b, a, a + 1, b + 1);
            }
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        g.setIndex(indices);
        g.computeVertexNormals();
        this.scene.add(mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, side: THREE.DoubleSide }), false));
        const rocky = [0x8b7b60, 0x746d63, 0x8d7d70, 0x5e6561, 0xa58c69].map(c => material(c, 1));
        const cliffPositions = [], cliffIndices = [];
        const levels = [0, -.65, -1.18, -1.82, -2.55, -3.25];
        const radius = [7.64, 7.20, 6.12, 4.73, 2.78, 0.27];
        for (let k = 0; k < levels.length; k++) {
            for (let j = 0; j <= segments; j++) {
                const a = j / segments * Math.PI * 2;
                const rr = radius[k] * (1 + .03 * Math.sin(a * 11) + .012 * Math.sin(a * 31 + .8));
                cliffPositions.push(Math.cos(a) * rr, (k === 0 ? groundY(Math.cos(a) * rr, Math.sin(a) * rr) : levels[k]) + Math.sin(a * 19 + k) * .055, Math.sin(a) * rr);
            }
        }
        for (let k = 0; k < levels.length - 1; k++)
            for (let j = 0; j < segments; j++) {
                const a = k * (segments + 1) + j, b = a + segments + 1;
                cliffIndices.push(a, b, a + 1, a + 1, b, b + 1);
            }
        const cg = new THREE.BufferGeometry();
        cg.setAttribute('position', new THREE.Float32BufferAttribute(cliffPositions, 3));
        cg.setIndex(cliffIndices);
        cg.computeVertexNormals();
        const cliffMat = rocky[1];
        cliffMat.side = THREE.DoubleSide;
        const cliff = mesh(cg, cliffMat, true);
        this.scene.add(cliff);
        // Exposed strata and suspended-reef crystals make the island read as a precious model.
        for (let i = 0; i < 52; i++) {
            const a = this.rand() * Math.PI * 2;
            const rr = 6.6 + this.rand() * .8;
            const crystal = mesh(new THREE.ConeGeometry(.1 + this.rand() * .18, .28 + this.rand() * .45, 5), rocky[i % rocky.length]);
            crystal.position.set(Math.cos(a) * rr, -.7 - this.rand() * 1.55, Math.sin(a) * rr);
            crystal.rotation.z = this.rand() * .8 - .4;
            this.scene.add(crystal);
        }
        const under = addBall(this.scene, 0x436a61, 2.3, 0, -2.5, 0, 20);
        under.scale.set(1.5, .18, 1.5);
        under.castShadow = false;
    }
    createPaths() {
        lineRibbon([{ x: -6.8, z: .6 }, { x: -4.2, z: .52 }, { x: -2.5, z: .65 }, { x: -1, z: .42 }, { x: .75, z: .30 }, { x: 3.1, z: 2.4 }], .67, 0xd9c7a6, this.scene);
        lineRibbon([{ x: .7, z: .3 }, { x: 1.6, z: -1.6 }, { x: 3, z: -3.3 }, { x: 4.7, z: -4.6 }], .43, 0xc9baa3, this.scene);
        lineRibbon([{ x: .7, z: .3 }, { x: -.3, z: 2.6 }, { x: -1.9, z: 4.4 }], .42, 0xd9c2a8, this.scene);
        lineRibbon([{ x: -6, z: -2 }, { x: -3.8, z: -2 }, { x: -2.3, z: -1.3 }, { x: -1.05, z: -3.34 }], .35, 0xb8c6a0, this.scene);
        // Individual cobbles reinforce the delicate tabletop scale.
        // Static stones are instanced rather than consuming a draw call per pebble.
        const stoneGeo = new THREE.DodecahedronGeometry(.085, 0);
        const stoneMeshes = [0xd4ccae, 0xe1d4b9, 0xbac4ae, 0xf2dcc4].map((color, i) => {
            const inst = new THREE.InstancedMesh(stoneGeo, material(color), Math.ceil((130 - i) / 4));
            inst.castShadow = false;
            inst.receiveShadow = true;
            this.scene.add(inst);
            return inst;
        });
        const transform = new THREE.Object3D();
        for (let i = 0; i < 130; i++) {
            const r = 1.5 + this.rand() * 4.3, a = this.rand() * Math.PI * 2;
            const x = Math.cos(a) * r, z = Math.sin(a) * r;
            transform.position.set(x, groundY(x, z) + .10, z);
            transform.scale.set(.58 + this.rand() * .85, .20, .8 + this.rand() * .65);
            transform.rotation.y = a;
            transform.updateMatrix();
            stoneMeshes[i % 4].setMatrixAt(Math.floor(i / 4), transform.matrix);
        }
        stoneMeshes.forEach(m => m.instanceMatrix.needsUpdate = true);
    }
    createVillage() {
        const layouts = [
            [-.75, -1.65, 0xead8bf, 0xd2896e], [1.65, -2.13, 0xf2dab7, 0x9d879c],
            [3.22, -1.24, 0xf8ead3, 0xc78475], [4.5, .5, 0xe6d8c6, 0x769c9e],
            [-.4, 3.04, 0xffe3c9, 0xa8a4b9], [1.72, 3.32, 0xf1e2c1, 0xc79b64],
            [-2.3, 3.08, 0xe2d9bc, 0x7e9b86], [-3.4, -2.5, 0xf5dabe, 0xbf8b71],
        ];
        layouts.forEach(([x, z, wall, roof], index) => {
            const house = new THREE.Group();
            house.position.set(x, groundY(x, z), z);
            house.rotation.y = (index % 3 - 1) * .35;
            addBox(house, 0x8e7157, [1.23, .13, 1.17], 0, .07, 0);
            addBox(house, wall, [1.04, .92, .99], 0, .56, 0);
            // Broad eaves, stacked roof tiers, copper flashing, and individual façades.
            const eaves = mesh(new THREE.ConeGeometry(1.02, .27, 4), material(0x6b756e, .72));
            eaves.rotation.y = Math.PI / 4;
            eaves.position.y = 1.10;
            house.add(eaves);
            const roofMesh = mesh(new THREE.ConeGeometry(.94, .72, 4), material(roof, .78));
            roofMesh.rotation.y = Math.PI / 4;
            roofMesh.position.y = 1.36;
            house.add(roofMesh);
            const cap = mesh(new THREE.ConeGeometry(.17, .28, 7), material(0xf4d9a6, .45, .18));
            cap.position.y = 1.83;
            house.add(cap);
            const chimney = addBox(house, 0xd2b79c, [.19, .54, .18], .38, 1.52, -.22);
            chimney.rotation.z = .04;
            addBox(house, 0x84675a, [.29, .09, .28], .38, 1.81, -.22);
            for (const side of [-1, 1]) {
                addBox(house, 0xe9d9bc, [.08, .94, .09], side * .49, .56, .49);
                addBox(house, 0x6d7366, [.13, .60, .08], side * .49, .5, -.48);
                const shutter = addBox(house, index % 2 ? 0x88a69b : 0xba9379, [.11, .34, .065], side * .46, .75, .56);
                shutter.rotation.y = side * .28;
            }
            const porch = addBox(house, 0x8e8472, [.71, .08, .42], 0, .61, .70);
            porch.castShadow = false;
            for (const side of [-1, 1]) {
                addBox(house, 0xead9bb, [.055, .45, .055], side * .31, .37, .82);
                addBox(house, 0xb88c6b, [.19, .12, .16], side * .34, .24, .69);
                addBall(house, index % 2 ? 0xf2d1a1 : 0xb8ddb3, .12, side * .34, .31, .72, 8);
            }
            const crest = addBox(house, 0xe5bb79, [.57, .055, .06], 0, 1.27, .73);
            crest.rotation.x = -.13;
            const dome = mesh(new THREE.ConeGeometry(.22, .36, 6), material(0xf5d3aa));
            dome.position.set(-.3, 1.65, -.16);
            house.add(dome);
            addBox(house, 0x6e6d67, [.27, .43, .055], 0, .29, .53);
            addBall(house, 0xf8cb70, .035, .075, .29, .56, 8);
            for (const side of [-1, 1]) {
                addBox(house, 0x75665f, [.25, .28, .06], side * .32, .76, .533);
                const light = addBox(house, 0xffe0a0, [.20, .22, .063], side * .32, .76, .568);
                light.material.emissive = new THREE.Color(0xffad3e);
                light.material.emissiveIntensity = .72;
                addBox(house, 0xe9ddc5, [.03, .27, .077], side * .32, .76, .59);
                addBox(house, 0xe9ddc5, [.23, .025, .077], side * .32, .76, .59);
            }
            addBox(house, 0x789b79, [.22, .18, .32], .43, .21, -.44);
            this.scene.add(house);
            // Emissive window lanterns are already visible; avoid eight extra dynamic lights.
            const hanging = addBall(house, 0xffd89b, .075, .53, 1.03, .57, 8);
            hanging.material.emissive = new THREE.Color(0xffb456);
            hanging.material.emissiveIntensity = 1.3;
        });
        // Chapel-like bell canopy, a harmlessly monumental ritual object.
        const shrine = new THREE.Group();
        shrine.position.set(-1.75, groundY(-1.75, -4.5), -4.5);
        for (const dx of [-.55, .55])
            for (const dz of [-.52, .52]) {
                addBox(shrine, 0xf2e6ca, [.14, 1.8, .14], dx, .96, dz);
                addBall(shrine, 0xffd59d, .12, dx, 1.88, dz);
            }
        const crown = mesh(new THREE.ConeGeometry(.95, .9, 4), material(0x7bada1), false);
        crown.rotation.y = Math.PI / 4;
        crown.position.y = 2.15;
        shrine.add(crown);
        addBall(shrine, 0xffd35f, .19, 0, 1.37, 0);
        this.scene.add(shrine);
    }
    createFlora() {
        const treeLocations = [];
        for (let i = 0; i < 25; i++) {
            const a = (i / 25) * Math.PI * 2 + (this.rand() - .5) * .18;
            const rr = 5.2 + this.rand() * 1.35;
            const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
            // Keep named playable target areas uncluttered.
            if (Math.hypot(x - POINTS.strike.x, z - POINTS.strike.z) < 1.75 ||
                Math.hypot(x - POINTS.rockEnd.x, z - POINTS.rockEnd.z) < 1.5 ||
                Math.hypot(x - POINTS.sign.x, z - POINTS.sign.z) < 1.6 ||
                Math.hypot(x - POINTS.windStart.x, z - POINTS.windStart.z) < 1.35)
                continue;
            treeLocations.push({ x, z });
        }
        // Canopies and blossom tips are batched. Trunks remain individually sculpted.
        const treeColors = [0x628d67, 0x7caa78, 0x9fbc7f, 0x9ec5a5, 0xd99fa0, 0x75ad89];
        const treeGeo = new THREE.SphereGeometry(1, 11, 8);
        const canopy = new THREE.InstancedMesh(treeGeo, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .95 }), treeLocations.length * 6);
        const tips = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 0), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 }), treeLocations.length * 3);
        canopy.castShadow = false;
        canopy.receiveShadow = true;
        tips.castShadow = false;
        const tf = new THREE.Object3D();
        treeLocations.forEach(({ x, z }, i) => {
            const h = 1.05 + this.rand() * .75;
            const trunk = mesh(new THREE.CylinderGeometry(.08, .14, h, 7), material(0x77654a));
            trunk.position.set(x, groundY(x, z) + h / 2, z);
            this.scene.add(trunk);
            for (let j = 0; j < 5; j++) {
                const radius = .48 + this.rand() * .23;
                tf.position.set(x + Math.sin(j * 3) * .34, groundY(x, z) + h + Math.sin(j) * .18, z + Math.cos(j * 3) * .32);
                tf.rotation.set(0, 0, 0);
                tf.scale.set(radius * 1.05, radius * .9, radius * 1.08);
                tf.updateMatrix();
                canopy.setMatrixAt(i * 6 + j, tf.matrix);
                canopy.setColorAt(i * 6 + j, new THREE.Color(treeColors[i % treeColors.length]));
            }
            tf.position.set(x, groundY(x, z) + h + .63, z);
            tf.scale.set(.23 * .91, .23 * .56, .23 * .92);
            tf.updateMatrix();
            canopy.setMatrixAt(i * 6 + 5, tf.matrix);
            canopy.setColorAt(i * 6 + 5, new THREE.Color(i % 4 === 0 ? 0xd8b3a8 : 0xb4cb8d));
            for (let k = 0; k < 3; k++) {
                tf.position.set(x + Math.cos(k * 2.09 + i) * .49, groundY(x, z) + h + .08 + Math.sin(k + i) * .35, z + Math.sin(k * 2.09 + i) * .49);
                tf.scale.setScalar(.07);
                tf.updateMatrix();
                tips.setMatrixAt(i * 3 + k, tf.matrix);
                tips.setColorAt(i * 3 + k, new THREE.Color(i % 5 === 0 ? 0xffe2c0 : 0xcfe5bd));
            }
        });
        canopy.instanceMatrix.needsUpdate = true;
        tips.instanceMatrix.needsUpdate = true;
        this.scene.add(canopy, tips);
        const flowerPalette = [0xffd7ab, 0xfff3b6, 0xe3b7e8, 0xc7e9bb, 0xffffff, 0xffbc8c];
        const flowerGeo = new THREE.IcosahedronGeometry(.055, 0);
        const flowers = flowerPalette.map((color, i) => {
            const inst = new THREE.InstancedMesh(flowerGeo, material(color), Math.ceil((255 - i) / 6));
            inst.castShadow = false;
            this.scene.add(inst);
            return inst;
        });
        const petal = new THREE.Object3D();
        for (let i = 0; i < 255; i++) {
            const a = this.rand() * Math.PI * 2;
            const r = Math.sqrt(this.rand()) * 7.0;
            const x = Math.cos(a) * r, z = Math.sin(a) * r;
            const occupied = Math.hypot(x - POINTS.strike.x, z - POINTS.strike.z) < 1.5 ||
                Math.hypot(x - POINTS.rockEnd.x, z - POINTS.rockEnd.z) < 1.35 ||
                Math.hypot(x - POINTS.sign.x, z - POINTS.sign.z) < 1.35;
            petal.position.set(x, groundY(x, z) + .13 + this.rand() * .06, z);
            const size = occupied ? 0 : .65 + this.rand() * .5;
            petal.scale.setScalar(size);
            petal.updateMatrix();
            flowers[i % 6].setMatrixAt(Math.floor(i / 6), petal.matrix);
        }
        flowers.forEach(m => m.instanceMatrix.needsUpdate = true);
        // Pairs of silent standing stones serve as fantasy scale markers.
        for (const [x, z] of [[-5.2, -3.3], [5.38, -2.4], [2.1, 5.68]]) {
            const st = mesh(new THREE.DodecahedronGeometry(.3, 0), material(0x98a993));
            st.scale.set(.9, 2, .85);
            st.position.set(x, groundY(x, z) + .46, z);
            st.rotation.y = .4;
            this.scene.add(st);
            addBall(this.scene, 0xffd594, .055, x, groundY(x, z) + 1.18, z, 8);
        }
    }
    createBridge() {
        // The little causeway visibly stops where the oversized boulder sits.
        for (let i = 0; i < 9; i++) {
            const x = -6.7 + i * .33, z = .49 + Math.sin(i * .6) * .11;
            const p = addBox(this.scene, i % 2 ? 0xb59c77 : 0xbfa884, [.28, .09, .89], x, groundY(x, z) + .15, z);
            p.rotation.y = Math.sin(i * .6) * .18;
            if (i % 2 === 0) {
                for (const side of [-1, 1]) {
                    const post = mesh(new THREE.CylinderGeometry(.035, .049, .45, 7), material(0xac8b64, .9));
                    post.position.set(x, groundY(x, z) + .41, z + side * .49);
                    this.scene.add(post);
                    const bolt = addBall(this.scene, 0xf0d09c, .05, x, groundY(x, z) + .65, z + side * .49, 7);
                    bolt.castShadow = false;
                }
            }
        }
        // Running water as a short curved stream crossing the far edge.
        const path = new THREE.CatmullRomCurve3([
            new THREE.Vector3(-2.9, groundY(-2.9, -5) + .12, -5),
            new THREE.Vector3(-2.3, groundY(-2.3, -3.3) + .12, -3.3),
            new THREE.Vector3(-1.7, groundY(-1.7, -1.8) + .12, -1.8),
            new THREE.Vector3(-1.05, groundY(-1.05, -.3) + .11, -.3),
        ]);
        const stream = mesh(new THREE.TubeGeometry(path, 90, .19, 9, false), new THREE.MeshPhysicalMaterial({
            color: 0x4dccc1, roughness: .18, metalness: .12, transparent: true, opacity: .81, clearcoat: 1, clearcoatRoughness: .08,
        }), false);
        this.scene.add(stream);
        for (let i = 0; i < 18; i++) {
            const t = i / 18;
            const p = path.getPoint(t);
            const sparkling = addBall(this.scene, 0xd8fff4, .035, p.x, p.y + .13, p.z, 7);
            sparkling.material.emissive = new THREE.Color(0x9cfef3);
            sparkling.material.emissiveIntensity = 1.2;
            this.flyingLights.push(sparkling);
            this.flyingLightBaseY.push(sparkling.position.y);
        }
    }
    createResidents() {
        const places = [
            [-1.75, 1.55], [-.62, 1.37], [.12, -.79], [1.45, -.63],
            [2.12, .95], [-.45, 2.5], [3.35, -.2], [4.47, 1.53],
            [-2.8, 2.1], [-2.27, -1.8], [1.22, 2.26], [2.82, -2.4],
        ];
        places.forEach(([x, z], i) => {
            const p = new THREE.Group();
            p.position.set(x, groundY(x, z) + .08, z);
            p.rotation.y = (i * 2.38) % (Math.PI * 2);
            const robe = [0xb39bc8, 0xe7a57e, 0x78a8a4, 0xf5ca77, 0x8db58c][i % 5];
            const body = mesh(new THREE.ConeGeometry(.12, .35, 8), material(robe));
            body.position.y = .22;
            p.add(body);
            addBall(p, 0xffd4aa, .135, 0, .48, 0, 10);
            const hat = new THREE.Group();
            hat.position.y = .6;
            p.add(hat);
            const cap = mesh(new THREE.ConeGeometry(.16, .24, 7), material([0x9a7b8e, 0x627e7b, 0xba8473, 0x9a885c][i % 4]));
            hat.add(cap);
            const arms = [];
            for (const side of [-1, 1]) {
                const arm = new THREE.Group();
                arm.position.set(side * .13, .32, 0);
                const sleeve = mesh(new THREE.CylinderGeometry(.043, .055, .22, 7), material(robe));
                sleeve.position.set(side * .04, -.06, 0);
                sleeve.rotation.z = -side * .55;
                arm.add(sleeve);
                p.add(arm);
                arms.push(arm);
            }
            // A cartoonish slightly overlarge head is essential at miniature scale.
            const nose = addBall(p, 0xc88b71, .04, 0, .48, .126, 7);
            nose.castShadow = false;
            for (const side of [-1, 1]) {
                const eye = addBall(p, 0x473c46, .021, side * .055, .52, .124, 7);
                eye.castShadow = false;
                const foot = mesh(new THREE.SphereGeometry(.065, 8, 6), material(0x6d6060), false);
                foot.scale.set(1, .36, 1.35);
                foot.position.set(side * .071, .045, .036);
                p.add(foot);
            }
            const satchel = addBall(p, 0xd3b48e, .085, .10, .27, -.075, 9);
            satchel.scale.set(.8, .8, .6);
            satchel.castShadow = false;
            this.scene.add(p);
            this.residents.push({ group: p, x, z, phase: i * 1.71, hat, arms });
            this.safeResidents.push({ x, z });
        });
    }
    createRock() {
        const rock = new THREE.Group();
        rock.position.set(POINTS.rockStart.x, groundY(POINTS.rockStart.x, POINTS.rockStart.z) + .75, POINTS.rockStart.z);
        const block = mesh(new THREE.DodecahedronGeometry(.87, 1), material(0x889391, .98));
        block.scale.set(1.05, .9, 1.16);
        block.rotation.set(.16, .5, .09);
        rock.add(block);
        for (let i = 0; i < 6; i++) {
            const tiny = addBall(rock, 0xc2bdaa, .078, (this.rand() - .5) * 1.1, (this.rand() - .5) * .8, (this.rand() - .5) * 1, 8);
            tiny.scale.set(1, .36, .75);
        }
        addBall(rock, 0xffe9ad, .055, .26, .67, .55);
        for (let i = 0; i < 5; i++) {
            const a = i * 2.17;
            const vein = mesh(new THREE.DodecahedronGeometry(.09, 0), material(i % 2 ? 0x6e9685 : 0xb2bca2, .9));
            vein.scale.set(1.4, .29, .7);
            vein.position.set(Math.sin(a) * .54, .52 * Math.cos(a), Math.cos(a) * .56);
            vein.rotation.set(.5, a, .1);
            rock.add(vein);
        }
        this.scene.add(rock);
        return rock;
    }
    createSquare() {
        const circle = mesh(new THREE.CylinderGeometry(1.44, 1.48, .095, 64), material(0xddc3a5), false);
        circle.position.set(POINTS.plaza.x, groundY(POINTS.plaza.x, POINTS.plaza.z) + .055, POINTS.plaza.z);
        circle.castShadow = false;
        this.scene.add(circle);
        const inner = mesh(new THREE.CylinderGeometry(1.23, 1.26, .11, 64), material(0xf4dbbc), false);
        inner.position.copy(circle.position);
        inner.position.y += .042;
        this.scene.add(inner);
        ring(this.scene, POINTS.plaza.x, POINTS.plaza.z, 1.13, 0xffedbd, .56);
        const colors = [0xffbd9d, 0x9ac7e9, 0xf3dc76, 0xc6b0e9, 0xd7eead, 0xfff4cb];
        const paper = new THREE.InstancedMesh(new THREE.BoxGeometry(.073, .013, .105), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .9, side: THREE.DoubleSide }), 108);
        paper.castShadow = false;
        paper.receiveShadow = false;
        paper.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        for (let i = 0; i < 108; i++) {
            const angle = this.rand() * Math.PI * 2;
            const r = .22 + Math.sqrt(this.rand()) * .91;
            const x = POINTS.plaza.x + Math.cos(angle) * r, z = POINTS.plaza.z + Math.sin(angle) * r;
            const y = groundY(POINTS.plaza.x, POINTS.plaza.z) + .14 + this.rand() * .055;
            this.confettiSeeds.push({ x, z, y, angle: angle * 1.3 });
            this.instanceTransform.position.set(x, y, z);
            this.instanceTransform.rotation.set(0, angle * 1.3, 0);
            this.instanceTransform.scale.setScalar(1);
            this.instanceTransform.updateMatrix();
            paper.setMatrixAt(i, this.instanceTransform.matrix);
            paper.setColorAt(i, new THREE.Color(colors[i % colors.length]));
        }
        paper.instanceMatrix.needsUpdate = true;
        this.confettiMesh = paper;
        this.scene.add(paper);
        // Fountain jewel is a public object; it has no hidden task state.
        const orb = addBall(this.scene, 0xb4ede1, .19, POINTS.plaza.x, groundY(POINTS.plaza.x, POINTS.plaza.z) + .52, POINTS.plaza.z);
        orb.material.emissive = new THREE.Color(0x4bc4bc);
        orb.material.emissiveIntensity = .6;
        const column = mesh(new THREE.CylinderGeometry(.095, .14, .4, 10), material(0x9ea99e), false);
        column.position.set(POINTS.plaza.x, groundY(POINTS.plaza.x, POINTS.plaza.z) + .29, POINTS.plaza.z);
        this.scene.add(column);
    }
    createWind() {
        const wind = new THREE.Group();
        wind.position.set(POINTS.windStart.x, groundY(POINTS.windStart.x, POINTS.windStart.z) + .42, POINTS.windStart.z);
        const colors = [0xb8fff1, 0x5ff0d3, 0x8acbd6];
        for (let j = 0; j < 3; j++) {
            const strand = new THREE.Group();
            const helix = [];
            for (let i = 0; i <= 64; i++) {
                const t = i / 64;
                const a = t * 5.2 * Math.PI + j * Math.PI * 2 / 3;
                const rr = (.61 - .34 * t);
                helix.push(new THREE.Vector3(Math.cos(a) * rr, .1 + t * 1.55, Math.sin(a) * rr));
            }
            const spiral = mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(helix), 84, .048, 7, false), new THREE.MeshBasicMaterial({ color: colors[j], transparent: true, opacity: .86, depthWrite: false, blending: THREE.AdditiveBlending }), false);
            strand.add(spiral);
            for (let k = 0; k < 8; k++) {
                const a = k * 2.3 + j * 2, h = .17 + k * .17;
                const b = addBall(strand, colors[j], .048, Math.cos(a) * (.55 - k * .035), h, Math.sin(a) * (.55 - k * .035), 8);
                b.castShadow = false;
            }
            this.windStrands.push(strand);
            wind.add(strand);
        }
        const core = addBall(wind, 0x80ebdc, .16, 0, 1.24, 0);
        core.material.emissive = new THREE.Color(0x59e6c7);
        core.material.emissiveIntensity = 2;
        return wind;
    }
    createSign() {
        const s = new THREE.Group();
        s.position.set(POINTS.sign.x, groundY(POINTS.sign.x, POINTS.sign.z) + .05, POINTS.sign.z);
        const boards = material(0x956d55);
        for (const side of [-1, 1]) {
            const post = mesh(new THREE.CylinderGeometry(.083, .1, 1.75, 9), boards);
            post.position.set(side * .60, .87, 0);
            s.add(post);
            addBall(s, 0xffc67e, .085, side * .60, 1.81, 0);
        }
        addBox(s, 0x725b52, [1.58, .77, .15], 0, 1.28, 0);
        const cv = document.createElement('canvas');
        cv.width = 512;
        cv.height = 256;
        const ctx = cv.getContext('2d');
        ctx.fillStyle = '#f3dfb7';
        ctx.fillRect(0, 0, 512, 256);
        ctx.strokeStyle = '#af8d65';
        ctx.lineWidth = 12;
        ctx.strokeRect(12, 12, 488, 232);
        ctx.fillStyle = '#675c4f';
        ctx.textAlign = 'center';
        ctx.font = 'bold 72px Georgia,serif';
        ctx.fillText('WELCOME', 256, 116);
        ctx.font = 'bold 38px Georgia,serif';
        ctx.fillText('to Little Glories', 256, 182);
        const tx = new THREE.CanvasTexture(cv);
        tx.colorSpace = THREE.SRGBColorSpace;
        const sheet = mesh(new THREE.PlaneGeometry(1.44, .65), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide }), false);
        sheet.position.set(0, 1.28, .086);
        s.add(sheet);
        for (const side of [-1, 1]) {
            const crest = mesh(new THREE.ConeGeometry(.095, .24, 5), material(0xffe6b4, .4, .14));
            crest.position.set(side * .74, 1.67, .09);
            crest.rotation.z = side * .19;
            s.add(crest);
        }
        const gold = addBall(s, 0xffd98b, .16, 0, 1.94, 0);
        gold.scale.set(1, .48, 1);
        s.rotation.z = -.29;
        return s;
    }
    createWardRing() {
        const g = new THREE.Group();
        g.position.set(POINTS.sign.x, groundY(POINTS.sign.x, POINTS.sign.z) + .25, POINTS.sign.z);
        const torus = mesh(new THREE.TorusGeometry(1.42, .084, 10, 88), new THREE.MeshBasicMaterial({
            color: C.violet, transparent: true, opacity: .78, blending: THREE.AdditiveBlending, depthWrite: false,
        }), false);
        torus.rotation.x = Math.PI / 2;
        g.add(torus);
        const arch = mesh(new THREE.TorusGeometry(1.33, .05, 8, 96), new THREE.MeshBasicMaterial({
            color: 0xe7d8ff, transparent: true, opacity: .61, blending: THREE.AdditiveBlending, depthWrite: false,
        }), false);
        arch.position.y = .75;
        arch.rotation.y = .4;
        g.add(arch);
        for (let i = 0; i < 18; i++) {
            const a = i / 18 * Math.PI * 2;
            const star = addBall(g, i % 2 ? 0xffffff : C.violet, .065, Math.cos(a) * 1.4, .18, Math.sin(a) * 1.4, 7);
            star.castShadow = false;
        }
        g.visible = false;
        return g;
    }
    createEffects() {
        const palette = [0xf9de99, 0x9ffff0, 0xe3b9ff, 0xffb9a1, 0xffffff];
        const particleCount = 165;
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        for (let i = 0; i < particleCount; i++) {
            const color = new THREE.Color(palette[i % palette.length]);
            colors.set([color.r, color.g, color.b], i * 3);
            this.effectSeeds.push({ a: this.rand() * Math.PI * 2, speed: .7 + this.rand() * 2.7,
                rad: .5 + this.rand() * 3.5, offset: this.rand() * .9, h: this.rand() * 3.5 });
        }
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        this.effectPoints = new THREE.Points(geometry, new THREE.PointsMaterial({
            color: 0xffffff, size: .15, sizeAttenuation: true, vertexColors: true, transparent: true,
            opacity: .91, depthWrite: false, blending: THREE.AdditiveBlending,
        }));
        this.effectPoints.frustumCulled = false;
        this.effectPoints.visible = false;
        this.scene.add(this.effectPoints);
        for (let i = 0; i < 5; i++) {
            const shock = ring(this.scene, 0, 0, .8, i % 2 ? 0xffe6a5 : C.teal, .85);
            shock.visible = false;
            this.pulse.push(shock);
        }
    }
    createDivineHand() {
        const hand = this.hand;
        const porcelain = material(0xf6d6ad, .34, .06);
        const warmer = material(0xffebc9, .43, .03);
        const gold = material(0xeaba69, .3, .48);
        const wrist = mesh(new THREE.CylinderGeometry(.39, .47, 1.08, 20), porcelain);
        wrist.rotation.x = Math.PI / 2;
        wrist.position.set(0, .17, 1.02);
        wrist.scale.z = .8;
        hand.add(wrist);
        const palm = mesh(new THREE.SphereGeometry(.67, 24, 16), warmer);
        palm.scale.set(.95, .31, 1.04);
        palm.position.set(0, .05, 0);
        hand.add(palm);
        const back = mesh(new THREE.SphereGeometry(.50, 18, 14), porcelain);
        back.scale.set(1, .18, .75);
        back.position.set(0, .18, .06);
        hand.add(back);
        for (let i = 0; i < 4; i++) {
            const group = new THREE.Group();
            const x = (i - 1.5) * .30;
            group.position.set(x, .065, -.46);
            const len = [.63, .78, .75, .57][i];
            const finger = mesh(new THREE.CapsuleGeometry(.125, len - .20, 4, 10), porcelain);
            finger.rotation.x = Math.PI / 2;
            finger.position.z = -len / 2;
            group.add(finger);
            const nail = mesh(new THREE.SphereGeometry(.091, 12, 8), warmer, false);
            nail.scale.set(.83, .25, 1.27);
            nail.position.set(0, .072, -len + .075);
            group.add(nail);
            this.handFingers.push(group);
            hand.add(group);
            const jewel = addBall(hand, i % 2 ? 0xe0b867 : 0xfff0cf, .038, x, .26, -.28, 8);
            jewel.castShadow = false;
        }
        const thumb = new THREE.Group();
        thumb.position.set(-.55, 0, .12);
        thumb.rotation.y = -.77;
        const digit = mesh(new THREE.CapsuleGeometry(.17, .36, 4, 12), porcelain);
        digit.rotation.x = Math.PI / 2;
        digit.position.z = -.22;
        thumb.add(digit);
        hand.add(thumb);
        this.handFingers.push(thumb);
        const cuff = mesh(new THREE.TorusGeometry(.42, .10, 8, 36), gold);
        cuff.rotation.x = Math.PI / 2;
        cuff.position.set(0, .18, 1.27);
        hand.add(cuff);
        const cuff2 = mesh(new THREE.TorusGeometry(.46, .025, 8, 36), warmer);
        cuff2.rotation.x = Math.PI / 2;
        cuff2.position.set(0, .18, 1.39);
        hand.add(cuff2);
        const sigil = mesh(new THREE.TorusGeometry(.19, .025, 6, 32), gold, false);
        sigil.rotation.x = -Math.PI / 2;
        sigil.position.set(0, .32, .06);
        hand.add(sigil);
        const gem = addBall(hand, 0xa8f7ec, .094, 0, .33, .06);
        gem.material.emissive = new THREE.Color(0x36bdab);
        gem.material.emissiveIntensity = .6;
        for (let i = 0; i < 5; i++) {
            const a = i * Math.PI * 2 / 5;
            const crest = mesh(new THREE.IcosahedronGeometry(.085, 0), material(i % 2 ? 0xf5dba4 : 0xb5eadd, .35, .33), false);
            crest.position.set(Math.sin(a) * .35, .19 + Math.cos(a) * .07, 1.35 + Math.cos(a) * .09);
            hand.add(crest);
        }
        for (const side of [-1, 1]) {
            const bracelet = mesh(new THREE.TorusGeometry(.24, .018, 6, 24), material(0xd8b17b, .36, .32), false);
            bracelet.rotation.x = Math.PI / 2;
            bracelet.position.set(side * .38, .16, -.20);
            bracelet.scale.set(.35, 1, .7);
            hand.add(bracelet);
        }
        hand.scale.setScalar(1.18);
    }
    placeHand(position) {
        const norm = Math.hypot(position.x, position.z);
        const x = norm > 7.1 ? position.x * 7.1 / norm : position.x;
        const z = norm > 7.1 ? position.z * 7.1 / norm : position.z;
        this.hand.position.set(x, groundY(x, z) + 2.75, z);
    }
    pick(screenX, screenY, canvas) {
        const rect = canvas.getBoundingClientRect();
        const nx = ((screenX - rect.left) / rect.width) * 2 - 1;
        const ny = -((screenY - rect.top) / rect.height) * 2 + 1;
        this.pointerNdc.set(nx, ny);
        this.raycaster.setFromCamera(this.pointerNdc, this.camera);
        const v = new THREE.Vector3();
        if (this.raycaster.ray.intersectPlane(this.inputPlane, v)) {
            const radius = Math.hypot(v.x, v.z);
            if (radius > 7.1) {
                v.x *= 7.1 / radius;
                v.z *= 7.1 / radius;
            }
            return { x: v.x, z: v.z };
        }
        return { x: 0, z: 0 };
    }
    tintEffects(palette) {
        if (this.effectPalette === palette)
            return;
        this.effectPalette = palette;
        const sets = {
            'rock-moved': [0xffc77b, 0xffeab7, 0xf4a67e],
            'sweep-done': [0xa5ffe5, 0x5fe5d0, 0xe3fff5],
            'sign-warded': [0xd6b5ff, 0xa7a7ec, 0xf5e9ff],
            'victory': [0xf7d18d, 0x9becc8, 0xd2b1f5, 0xffefd5],
        };
        const colors = this.effectPoints.geometry.getAttribute('color');
        for (let i = 0; i < this.effectSeeds.length; i++) {
            const color = new THREE.Color(sets[palette][i % sets[palette].length]);
            colors.setXYZ(i, color.r, color.g, color.b);
        }
        colors.needsUpdate = true;
    }
    trigger(code) {
        if (code === 'reset') {
            this.eventName = '';
            this.eventDuration = 0;
            this.pulseTime = 0;
            this.effectPalette = '';
            this.lastConfettiUpdate = -1;
            return;
        }
        if (code === 'rock-moved' || code === 'sign-warded' || code === 'sweep-done') {
            this.eventName = code;
            this.eventDuration = 2.5;
            this.pulseTime = 0;
            this.tintEffects(code);
        }
    }
    update(dt, time, rules, frame) {
        const s = rules.state;
        const reduced = frame.reducedMotion;
        this.placeHand(frame.hand);
        const hf = this.handFingers;
        const fist = frame.gesture === 'strike' ? .9 : frame.gesture === 'ward' ? -.18 : .1;
        hf.forEach((f, i) => {
            f.rotation.x += (fist - f.rotation.x) * Math.min(1, dt * 11);
            if (i === 4)
                f.rotation.y = -.77 + (reduced ? 0 : Math.sin(time * 1.5) * .04);
        });
        this.hand.rotation.y = reduced ? 0 : Math.sin(time * .6) * .07;
        this.hand.rotation.z = (frame.gesture === 'sweep' ? -.09 : frame.gesture === 'strike' ? .10 : 0) + (reduced ? 0 : Math.sin(time * 1.4) * .025);
        this.hand.position.y += reduced ? 0 : Math.sin(time * 2.2) * .07;
        if (!reduced && this.eventDuration > 2.17) {
            const t = (2.5 - this.eventDuration) / .33;
            if (this.eventName === 'rock-moved')
                this.hand.position.y -= Math.sin(Math.PI * t) * .30;
            if (this.eventName === 'sign-warded')
                this.hand.scale.setScalar(1.18 + Math.sin(Math.PI * t) * .09);
        }
        else
            this.hand.scale.setScalar(1.18);
        this.halo.visible = frame.targetValid;
        const markerMap = { strike: !s.rockDone, sweep: !s.confettiDone && !s.sweepAttached, ward: !s.signDone };
        Object.keys(this.markers).forEach(g => {
            const marker = this.markers[g];
            marker.visible = markerMap[g];
            const mat = marker.material;
            mat.opacity = g === frame.gesture ? .75 + (reduced ? 0 : Math.sin(time * 4) * .12) : .26;
        });
        this.halo.scale.setScalar(.9 + (reduced ? 0 : Math.sin(time * 5) * .06));
        this.halo.material.color.setHex(frame.gesture === 'strike' ? C.gold : frame.gesture === 'sweep' ? C.teal : C.violet);
        const rr = easeInOut(s.rockTime / .95);
        this.rock.position.set(THREE.MathUtils.lerp(POINTS.rockStart.x, POINTS.rockEnd.x, rr), groundY(THREE.MathUtils.lerp(POINTS.rockStart.x, POINTS.rockEnd.x, rr), THREE.MathUtils.lerp(POINTS.rockStart.z, POINTS.rockEnd.z, rr)) + .72 + (s.rockDone && !reduced ? Math.sin(Math.PI * rr) * 1.45 : 0), THREE.MathUtils.lerp(POINTS.rockStart.z, POINTS.rockEnd.z, rr));
        this.rock.rotation.z = s.rockDone ? rr * Math.PI * 1.9 : Math.sin(time * .7) * .02;
        this.rock.rotation.y = s.rockDone ? rr * 3 : 0;
        this.wind.position.set(s.wind.x, groundY(s.wind.x, s.wind.z) + .24, s.wind.z);
        this.windStrands.forEach((g, i) => {
            g.rotation.y = reduced ? 0 : time * (i % 2 ? -1.3 : 1.6);
            g.scale.setScalar(1 + (reduced ? 0 : Math.sin(time * 2 + i) * .04));
        });
        this.wind.visible = !s.confettiDone;
        const confettiTick = Math.floor(time * 18);
        if (this.lastConfettiUpdate !== confettiTick) {
            this.lastConfettiUpdate = confettiTick;
            const sweepActive = s.sweepAttached && Math.hypot(s.wind.x - POINTS.plaza.x, s.wind.z - POINTS.plaza.z) < 1.5;
            this.confettiSeeds.forEach((c, i) => {
                const visible = (i / this.confettiSeeds.length) < 1 - s.sweepProgress;
                const angle = c.angle + (reduced ? 0 : time * (sweepActive ? 2.1 : .31));
                const lift = sweepActive && !reduced ? (.20 + .30 * Math.sin(i * 3.1) ** 2) * Math.min(1, s.sweepProgress * 3) : 0;
                const orbit = sweepActive && !reduced ? .14 * s.sweepProgress : 0;
                this.instanceTransform.position.set(c.x + Math.cos(angle) * orbit, c.y + lift + (sweepActive && !reduced ? .075 * Math.sin(time * 6 + i * 1.8) : 0), c.z + Math.sin(angle) * orbit);
                this.instanceTransform.rotation.set(sweepActive && !reduced ? angle * .6 : 0, angle, 0);
                this.instanceTransform.scale.setScalar(visible ? 1 : 0);
                this.instanceTransform.updateMatrix();
                this.confettiMesh.setMatrixAt(i, this.instanceTransform.matrix);
            });
            this.confettiMesh.instanceMatrix.needsUpdate = true;
        }
        const wardEase = easeInOut(s.wardTime / 1.8);
        const reFall = s.signHasFallenAgain ? (reduced ? 1 : easeInOut((s.victoryTime - 8.4) / 1.2)) : 0;
        this.sign.rotation.z = THREE.MathUtils.lerp(-.29, 0, wardEase) - reFall * 1.25;
        this.wardRing.visible = s.signDone;
        if (s.signDone) {
            this.wardRing.scale.setScalar(.5 + .5 * wardEase);
            this.wardRing.rotation.y = reduced ? 0 : time * .27;
            this.wardRing.children[0].rotation.z = Math.sin(time * 2) * .04;
        }
        const victory = s.victory;
        const camTime = s.victoryTime;
        const reveal = victory ? (reduced ? 1 : easeInOut((camTime - 1.1) / 4.3)) : 0;
        this.camera.position.lerpVectors(this.cameraBase, this.cameraFinal, reveal);
        if (!reduced && this.eventName === 'rock-moved' && this.eventDuration > 1.9) {
            const amplitude = .07 * Math.sin(Math.PI * ((2.5 - this.eventDuration) / .6));
            this.camera.position.x += Math.sin(time * 27) * amplitude;
            this.camera.position.y += Math.cos(time * 29) * amplitude * .40;
        }
        this.cameraTarget.set(reveal * 1.65, reveal * .35, reveal * .68);
        this.camera.lookAt(this.cameraTarget);
        this.camera.zoom = 1 - reveal * .10;
        this.camera.updateProjectionMatrix();
        const eventTarget = this.eventName === 'rock-moved' ? POINTS.strike :
            this.eventName === 'sign-warded' ? POINTS.sign :
                this.eventName === 'sweep-done' ? POINTS.plaza : null;
        this.residents.forEach((r, i) => {
            const bounce = victory ? (Math.abs(Math.sin(time * 5 + r.phase)) * .27) : .035 * Math.sin(time * 2 + r.phase);
            r.group.position.y = groundY(r.x, r.z) + .08 + (reduced ? 0 : bounce);
            const idle = (i * 2.38) % (Math.PI * 2) + Math.sin(time * .7 + i) * .08;
            const attending = eventTarget !== null && this.eventDuration > 0 && !victory;
            const face = attending ? Math.atan2(eventTarget.x - r.x, eventTarget.z - r.z) : idle;
            const targetRotation = victory ? Math.sin(time * 2 + i) * .4 : face;
            const shortest = Math.atan2(Math.sin(targetRotation - r.group.rotation.y), Math.cos(targetRotation - r.group.rotation.y));
            r.group.rotation.y += shortest * Math.min(1, dt * (reduced ? 40 : 4.5));
            r.hat.rotation.z = reduced ? 0 : Math.sin(time * 1.9 + r.phase) * .085;
            r.arms.forEach((arm, j) => {
                arm.rotation.z = victory ? (j ? -.9 : .9) + (reduced ? 0 : Math.sin(time * 7 + i) * .2) :
                    attending ? (j ? -.6 : .6) + (reduced ? 0 : Math.sin(time * 9 + i) * .07) : Math.sin(time * 1.6 + i) * .13;
            });
        });
        this.sparkles.forEach((s, i) => {
            s.position.y = this.sparkleBaseY[i] + (reduced ? 0 : Math.sin(time * .5 + i) * .045);
        });
        this.flyingLights.forEach((m, i) => {
            m.position.y = this.flyingLightBaseY[i] + (reduced ? 0 : Math.sin(time * 3 + i * 1.2) * .035);
        });
        const particleActive = victory || this.eventDuration > 0;
        this.effectPoints.visible = particleActive;
        if (particleActive) {
            if (victory)
                this.tintEffects('victory');
            const a = this.effectPoints.geometry.getAttribute('position');
            const coords = a.array;
            const px = victory ? POINTS.plaza.x : this.eventName === 'rock-moved' ? POINTS.strike.x :
                this.eventName === 'sign-warded' ? POINTS.sign.x : POINTS.plaza.x;
            const pz = victory ? POINTS.plaza.z : this.eventName === 'rock-moved' ? POINTS.strike.z :
                this.eventName === 'sign-warded' ? POINTS.sign.z : POINTS.plaza.z;
            this.effectSeeds.forEach((p, i) => {
                const elapsed = reduced ? .42 : this.pulseTime;
                const angle = p.a + (reduced ? 0 : (this.eventName === 'sweep-done' ? elapsed * 3.3 : time * p.speed * .23));
                let radius = p.rad * .72;
                let rise = elapsed * .9 + p.offset * .4;
                if (victory) {
                    radius = p.rad * 1.35;
                    rise = (time * .43 + p.h) % 6.0;
                }
                else if (this.eventName === 'rock-moved') {
                    radius = .24 + elapsed * (.72 + p.rad * .26);
                    rise = .16 + Math.sin(Math.min(1, elapsed / 2.4) * Math.PI) * (.36 + p.h * .15);
                }
                else if (this.eventName === 'sweep-done') {
                    radius = 1.8 - elapsed * .30 + p.offset * .4;
                    rise = elapsed * 1.15 + p.h * .12;
                }
                else if (this.eventName === 'sign-warded') {
                    radius = .95 + p.offset * .55;
                    rise = .70 + Math.sin(p.a * 2 + elapsed * 2.2) * (.47 + elapsed * .13);
                }
                const offset = i * 3;
                coords[offset] = px + Math.cos(angle) * radius;
                coords[offset + 1] = groundY(px, pz) + .3 + rise;
                coords[offset + 2] = pz + Math.sin(angle) * radius;
            });
            a.needsUpdate = true;
        }
        for (let i = 0; i < 5; i++) {
            const m = this.pulse[i];
            const mm = m.material;
            m.scale.setScalar(1 + (reduced ? 0 : Math.sin(time * .5 + i) * .004));
            mm.opacity = .12 + (reduced ? 0 : Math.sin(time * .8 + i) * .055);
        }
        for (let i = 5; i < this.pulse.length; i++) {
            const m = this.pulse[i];
            const active = this.eventDuration > 0;
            m.visible = active;
            if (active) {
                const p = this.eventName === 'rock-moved' ? POINTS.strike : this.eventName === 'sign-warded' ? POINTS.sign : POINTS.plaza;
                const t = THREE.MathUtils.clamp((this.pulseTime - (i - 5) * .17) / 1.3, 0, 1);
                m.position.set(p.x, groundY(p.x, p.z) + .16, p.z);
                m.scale.setScalar(0.2 + t * 3.2);
                m.material.opacity = .9 * (1 - t);
            }
        }
        if (this.eventDuration > 0) {
            this.eventDuration = Math.max(0, this.eventDuration - dt);
            this.pulseTime += dt;
        }
        this.moon.material.rotation = reduced ? 0 : Math.sin(time * .06) * .04;
        this.ocean.material.opacity = .70 + (reduced ? 0 : Math.sin(time * .75) * .02);
        this.art.update(dt, time, rules, reduced, this.eventName, this.eventDuration);
        this.finishing.update(time, rules, frame.hand, reduced);
    }
    resize(width, height) {
        if (width < 2 || height < 2 || this.disposed)
            return;
        if (width === this.lastWidth && height === this.lastHeight)
            return;
        this.lastWidth = width;
        this.lastHeight = height;
        const aspect = width / height;
        const hh = 17.0;
        this.camera.left = -hh * aspect / 2;
        this.camera.right = hh * aspect / 2;
        this.camera.top = hh / 2;
        this.camera.bottom = -hh / 2;
        if (aspect < .96) {
            this.camera.left = -10.5;
            this.camera.right = 10.5;
            this.camera.top = 10.5 / aspect;
            this.camera.bottom = -10.5 / aspect;
        }
        this.camera.updateProjectionMatrix();
        const mobile = width < 720;
        this.art.setQuality(mobile);
        this.finishing.setQuality(mobile);
        this.effectPoints.geometry.setDrawRange(0, mobile ? 95 : this.effectSeeds.length);
        const shadowSize = mobile ? 1024 : 2048;
        if (this.sun.shadow.mapSize.x !== shadowSize) {
            this.sun.shadow.mapSize.set(shadowSize, shadowSize);
            this.sun.shadow.map?.dispose();
            this.sun.shadow.map = null;
        }
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.35 : 1.65));
        this.renderer.setSize(width, height, false);
    }
    render() { if (!this.disposed)
        this.renderer.render(this.scene, this.camera); }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        const geos = new Set();
        const mats = new Set();
        const textures = new Set();
        this.scene.traverse((obj) => {
            if (obj instanceof THREE.Mesh || obj instanceof THREE.Points || obj instanceof THREE.Line) {
                if (obj.geometry)
                    geos.add(obj.geometry);
                const arr = Array.isArray(obj.material) ? obj.material : [obj.material];
                arr.forEach((m) => mats.add(m));
            }
            if (obj instanceof THREE.Sprite)
                mats.add(obj.material);
        });
        mats.forEach(m => {
            const values = Object.values(m);
            for (const v of values)
                if (v instanceof THREE.Texture)
                    textures.add(v);
            m.dispose();
        });
        geos.forEach(g => g.dispose());
        textures.forEach(t => t.dispose());
        this.scene.clear();
        this.renderer.dispose();
        this.renderer.forceContextLoss();
    }
}
