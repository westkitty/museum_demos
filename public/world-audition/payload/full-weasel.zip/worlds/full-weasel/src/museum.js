/** Mock adapter. Host application may subscribe; no navigation or production writes. */
export function requestMuseumReturn() {
    const detail = { type: 'museum:return-requested', exhibit: 'E27', title: 'The Full Weasel' };
    window.dispatchEvent(new CustomEvent('full-weasel:return', { detail }));
    return detail;
}
