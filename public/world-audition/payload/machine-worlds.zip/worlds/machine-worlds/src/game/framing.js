/** Deterministic orthographic framing math, kept independent of rendering. */
export const MIN_PLAYABLE_HORIZONTAL_SPAN = 16;
export const VISIBLE_PROCESS_SPINE_X = 0;
/** Widen portrait views enough to show the current ledge and the next lateral jump. */
export function responsiveVerticalSpan(nominalSpan, aspect) {
    if (!(nominalSpan > 0) || !Number.isFinite(nominalSpan))
        throw new RangeError('Invalid nominal span');
    if (!(aspect > 0) || !Number.isFinite(aspect))
        throw new RangeError('Invalid camera aspect');
    return Math.max(nominalSpan, MIN_PLAYABLE_HORIZONTAL_SPAN / aspect);
}
export function horizontalLookAhead(x, facing, vx) {
    return x + facing * (1.15 + Math.min(.55, Math.abs(vx) * .1));
}
