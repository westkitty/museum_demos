export class InputRouter {
    canvas;
    controlsRoot;
    held = new Set();
    pressed = new Set();
    touches = new Set();
    activePointer = null;
    previousX = 0;
    previousY = 0;
    onLook = () => { };
    disposers = [];
    constructor(canvas, controlsRoot) {
        this.canvas = canvas;
        this.controlsRoot = controlsRoot;
        const bind = (name, fn) => {
            window.addEventListener(name, fn);
            this.disposers.push(() => window.removeEventListener(name, fn));
        };
        bind('keydown', e => {
            if (e.repeat)
                return;
            const target = e.target;
            if (target instanceof HTMLElement && target.closest('button, select, input, textarea, [contenteditable="true"]'))
                return;
            const k = e.code;
            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(k))
                e.preventDefault();
            if (!this.held.has(k))
                this.pressed.add(k);
            this.held.add(k);
        });
        bind('keyup', e => this.held.delete(e.code));
        bind('blur', () => { this.held.clear(); this.pressed.clear(); this.touches.clear(); });
        const down = (e) => {
            if (e.pointerType === 'mouse' && e.button !== 2)
                return;
            this.activePointer = e.pointerId;
            this.previousX = e.clientX;
            this.previousY = e.clientY;
            this.canvas.setPointerCapture(e.pointerId);
        };
        const move = (e) => {
            if (e.pointerId !== this.activePointer)
                return;
            const dx = e.clientX - this.previousX;
            const dy = e.clientY - this.previousY;
            this.previousX = e.clientX;
            this.previousY = e.clientY;
            this.onLook(dx, dy);
        };
        const stop = (e) => { if (e.pointerId === this.activePointer)
            this.activePointer = null; };
        const context = (e) => e.preventDefault();
        this.canvas.addEventListener('pointerdown', down);
        this.canvas.addEventListener('pointermove', move);
        this.canvas.addEventListener('pointerup', stop);
        this.canvas.addEventListener('pointercancel', stop);
        this.canvas.addEventListener('contextmenu', context);
        this.disposers.push(() => {
            this.canvas.removeEventListener('pointerdown', down);
            this.canvas.removeEventListener('pointermove', move);
            this.canvas.removeEventListener('pointerup', stop);
            this.canvas.removeEventListener('pointercancel', stop);
            this.canvas.removeEventListener('contextmenu', context);
        });
        for (const button of Array.from(controlsRoot.querySelectorAll('[data-action]'))) {
            const action = button.dataset.action;
            const onDown = (e) => {
                e.preventDefault();
                this.touches.add(action);
                if (action === 'jump' || action === 'interact')
                    this.pressed.add('touch:' + action);
                button.setPointerCapture(e.pointerId);
                button.classList.add('held');
            };
            const onUp = (e) => {
                e.preventDefault();
                this.touches.delete(action);
                button.classList.remove('held');
            };
            button.addEventListener('pointerdown', onDown);
            button.addEventListener('pointerup', onUp);
            button.addEventListener('pointercancel', onUp);
            this.disposers.push(() => {
                button.removeEventListener('pointerdown', onDown);
                button.removeEventListener('pointerup', onUp);
                button.removeEventListener('pointercancel', onUp);
            });
        }
    }
    sample() {
        const down = (code, touch) => this.held.has(code) || Boolean(touch && this.touches.has(touch));
        const was = (code, touch) => this.pressed.has(code) || Boolean(touch && this.pressed.has('touch:' + touch));
        const state = {
            x: Number(down('KeyD', 'right') || down('ArrowRight')) - Number(down('KeyA', 'left') || down('ArrowLeft')),
            y: Number(down('KeyW', 'up') || down('ArrowUp')) - Number(down('KeyS', 'down') || down('ArrowDown')),
            jump: was('Space', 'jump'),
            interact: was('KeyE', 'interact') || was('Enter'),
            respawn: was('KeyR'),
            pause: was('Escape')
        };
        this.pressed.clear();
        return state;
    }
    clear() { this.held.clear(); this.pressed.clear(); this.touches.clear(); }
    dispose() { this.clear(); for (const fn of this.disposers)
        fn(); this.disposers.length = 0; }
}
