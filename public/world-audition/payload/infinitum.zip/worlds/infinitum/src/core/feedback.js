import * as THREE from 'three';
/** Fixed-capacity, zero-per-interaction-allocation gameplay feedback pool. */
export class InteractionFeedback {
    scene;
    ringGeometry = new THREE.RingGeometry(.81, 1, 48);
    haloGeometry = new THREE.RingGeometry(.98, 1.02, 48);
    effects = [];
    next = 0;
    constructor(scene, capacity = 12) {
        this.scene = scene;
        for (let i = 0; i < capacity; i++) {
            const ring = new THREE.Mesh(this.ringGeometry, new THREE.MeshBasicMaterial({ color: 0xb2e6db, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
            const halo = new THREE.Mesh(this.haloGeometry, new THREE.MeshBasicMaterial({ color: 0xdcc38d, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
            ring.visible = halo.visible = false;
            ring.renderOrder = 7;
            halo.renderOrder = 7;
            this.scene.add(ring, halo);
            this.effects.push({ ring, halo, time: 0, life: 0, size: 1 });
        }
    }
    pulse(position, color = 0x8bded5, size = 1) {
        const fx = this.effects[this.next];
        this.next = (this.next + 1) % this.effects.length;
        fx.life = 1;
        fx.time = 0;
        fx.size = Math.max(.35, size);
        for (const mesh of [fx.ring, fx.halo]) {
            mesh.visible = true;
            mesh.position.copy(position);
            mesh.scale.setScalar(fx.size);
            mesh.rotation.x = -Math.PI / 2;
            mesh.rotation.y = 0;
        }
        fx.ring.material.color.set(color);
        fx.halo.material.color.set(color);
    }
    update(dt, reducedMotion) {
        for (const fx of this.effects) {
            if (fx.life <= 0)
                continue;
            fx.time += dt;
            const duration = reducedMotion ? .38 : 1.05;
            const t = Math.min(1, fx.time / duration);
            fx.ring.scale.setScalar(fx.size * (1 + t * (reducedMotion ? .32 : 2.1)));
            fx.halo.scale.setScalar(fx.size * (.75 + t * (reducedMotion ? .35 : 2.6)));
            fx.ring.material.opacity = (1 - t) * .6;
            fx.halo.material.opacity = (1 - t) * .24;
            if (t === 1) {
                fx.life = 0;
                fx.ring.visible = false;
                fx.halo.visible = false;
            }
        }
    }
    dispose() {
        for (const fx of this.effects) {
            this.scene.remove(fx.ring, fx.halo);
            fx.ring.material.dispose();
            fx.halo.material.dispose();
        }
        this.ringGeometry.dispose();
        this.haloGeometry.dispose();
        this.effects = [];
    }
}
