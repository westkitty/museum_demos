import * as THREE from 'three';
import { CAN, DEW, STATIONS, SUMMIT, SURFACES } from './course.js';
import { PremiumGardenDetails } from './premium.js';
const C = { ivory: 0xfff3d0, ink: 0x172c30, teal: 0x36c7b7, tealDark: 0x176b69, gold: 0xffbf65, pink: 0xf692b9, rose: 0xf56c81,
    green: 0x5ab961, lime: 0xb7df7a, purple: 0xa989e5, glass: 0xb8f5e7, soil: 0x59432e, sky: 0x80cad8 };
// Reusing a small material palette reduces GPU program churn across the entire level.
const materialCache = new Map();
const mat = (color, roughness = .68, metalness = .0, emissive = 0, emissiveIntensity = 0) => {
    const key = [color, roughness, metalness, emissive, emissiveIntensity].join(':');
    let material = materialCache.get(key);
    if (!material) {
        material = new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive, emissiveIntensity, side: THREE.DoubleSide });
        materialCache.set(key, material);
    }
    return material;
};
const sphereTemplate = new THREE.SphereGeometry(1, 16, 12);
const fogChapters = [0xb9e8d8, 0xcbe6d9, 0xe3ded2, 0xc5dedc].map(c => new THREE.Color(c));
const sunChapters = [0xffd9a4, 0xffdbb9, 0xffcba3, 0xffeac0].map(c => new THREE.Color(c));
const flora = [mat(0x5eae7a), mat(0x6fc991), mat(0x378b66), mat(0x91d99b)];
const wood = mat(0x73553f, .9);
const brass = mat(0xc4a06d, .28, .62);
const darkGold = mat(0xae7847, .4, .28);
const cream = mat(C.ivory, .78);
const glass = new THREE.MeshPhysicalMaterial({ color: C.glass, roughness: .13, metalness: .02, transparent: true, opacity: .17, depthWrite: false, side: THREE.DoubleSide });
const ceramic = mat(0xe08b62, .36, .08);
const skyGlow = mat(C.teal, .32, .08, C.teal, .38);
function mesh(g, m, parent, x = 0, y = 0, z = 0) {
    const obj = new THREE.Mesh(g, m);
    obj.position.set(x, y, z);
    obj.castShadow = true;
    obj.receiveShadow = true;
    parent.add(obj);
    return obj;
}
function ball(parent, r, color, x, y, z, sx = 1, sy = 1, sz = 1) {
    const o = mesh(sphereTemplate, mat(color), parent, x, y, z);
    o.scale.set(r * sx, r * sy, r * sz);
    o.castShadow = r > .69 && r < 13;
    return o;
}
function tube(parent, points, radius, m, segments = 20) {
    return mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), segments, radius, 7, false), m, parent);
}
function rod(parent, start, end, r, m) {
    const delta = new THREE.Vector3().subVectors(end, start), mid = start.clone().add(end).multiplyScalar(.5);
    const o = mesh(new THREE.CylinderGeometry(r, r, delta.length(), 8), m, parent, mid.x, mid.y, mid.z);
    o.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
    return o;
}
function seeded(seed = 1) { let s = seed >>> 0; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; }
function signSprite(text, width = 430, color = '#fff0bd') {
    const cv = document.createElement('canvas');
    cv.width = 1024;
    cv.height = 256;
    const cx = cv.getContext('2d');
    cx.fillStyle = 'rgba(16,47,50,.88)';
    cx.beginPath();
    cx.roundRect(16, 22, 992, 211, 48);
    cx.fill();
    cx.strokeStyle = 'rgba(255,223,161,.85)';
    cx.lineWidth = 6;
    cx.stroke();
    cx.fillStyle = color;
    cx.font = '700 49px Georgia, serif';
    cx.textAlign = 'center';
    cx.textBaseline = 'middle';
    // Fit oversized headlines without clipping.
    const size = Math.min(49, 960 / (cx.measureText(text).width / 49));
    cx.font = `700 ${size}px Georgia, serif`;
    cx.fillText(text, 512, 128);
    const texture = new THREE.CanvasTexture(cv);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 4;
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false }));
    sprite.scale.set(width / 100, width / 400, 1);
    return sprite;
}
export class GardenArt {
    root = new THREE.Group();
    player = new THREE.Group();
    glider = new THREE.Group();
    growth = [new THREE.Group(), new THREE.Group(), new THREE.Group()];
    growthPivot = STATIONS.map(s => new THREE.Vector3(s.x, s.y, s.z));
    clouds = [];
    spareCan;
    spareLabel;
    pollen = null;
    clock = 0;
    animSeed = 0;
    petals = [];
    details;
    clockCloudPositions = [];
    avatarBody;
    avatarHead;
    keyLight;
    scene;
    altars = [];
    ceremonialPulse = 0;
    landingShadow;
    smoothFacing = 0;
    quality;
    constructor(scene, quality = 'rich') {
        this.quality = quality;
        this.scene = scene;
        scene.add(this.root);
        this.buildSky(scene);
        this.buildTerrain();
        this.buildGreenhouse();
        this.buildLandmarks();
        this.buildPollen();
        for (let i = 0; i < 3; i++) {
            this.growth[i].position.copy(this.growthPivot[i]);
            this.root.add(this.growth[i]);
        }
        SURFACES.forEach(s => this.buildSurface(s));
        this.buildSunflowerStalk();
        this.buildStationsAndDew();
        this.buildFinalCan();
        this.spareCan = this.buildCan(this.root, 9, 0, -25, .48, false);
        this.spareCan.visible = false;
        this.spareLabel = signSprite('THE SPARE CAN. IT WAS HERE ALL ALONG.', 900);
        this.spareLabel.position.set(9, 4.6, -25);
        this.spareLabel.scale.set(17, 4, 1);
        this.spareLabel.visible = false;
        this.root.add(this.spareLabel);
        this.buildPlayer();
        this.root.add(this.player);
        this.details = new PremiumGardenDetails(this.root, this.growth, quality);
    }
    buildSky(scene) {
        scene.background = new THREE.Color(0x83d4d5);
        scene.fog = new THREE.FogExp2(0xb9e8d8, .0033);
        const sky = new THREE.Mesh(new THREE.SphereGeometry(420, 36, 20), new THREE.ShaderMaterial({
            side: THREE.BackSide, depthWrite: false, uniforms: {}, vertexShader: `varying vec3 vWorld; void main(){vec4 wp=modelMatrix*vec4(position,1.0);vWorld=wp.xyz;gl_Position=projectionMatrix*viewMatrix*wp;}`,
            fragmentShader: `varying vec3 vWorld; void main(){float h=normalize(vWorld).y;vec3 horizon=vec3(.98,.76,.59);vec3 top=vec3(.24,.54,.65);vec3 below=vec3(.68,.83,.73);vec3 c=mix(horizon,top,smoothstep(.015,.82,h));c=mix(below,c,smoothstep(-.35,.14,h));gl_FragColor=vec4(c,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>}`
        }));
        this.root.add(sky);
        ball(this.root, 19, 0xffe6a4, -120, 136, -135);
        const hemi = new THREE.HemisphereLight(0xffefcf, 0x416a59, 1.7);
        this.root.add(hemi);
        const sun = new THREE.DirectionalLight(0xffd9a4, 2.35);
        this.keyLight = sun;
        sun.position.set(-45, 90, -38);
        sun.castShadow = true;
        sun.shadow.mapSize.set(this.quality === 'lite' ? 768 : 1536, this.quality === 'lite' ? 768 : 1536);
        sun.shadow.camera.left = -85;
        sun.shadow.camera.right = 85;
        sun.shadow.camera.top = 105;
        sun.shadow.camera.bottom = -85;
        sun.shadow.camera.near = .5;
        sun.shadow.camera.far = 230;
        sun.shadow.bias = -.00013;
        sun.shadow.normalBias = .03;
        this.root.add(sun);
        this.root.add(sun.target);
        sun.target.position.set(0, 15, 31);
        const fill = new THREE.DirectionalLight(0x9edacc, .65);
        fill.position.set(50, 55, 90);
        this.root.add(fill);
        // Cloud field: one instanced draw call, with palette variation and coherent drift.
        const rng = seeded(776);
        const cloudGeometry = new THREE.IcosahedronGeometry(1, 1);
        const cloudMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .58, depthWrite: false, fog: true });
        const cloudCount = this.quality === 'lite' ? 74 : 156;
        const cloudMesh = new THREE.InstancedMesh(cloudGeometry, cloudMaterial, cloudCount);
        const cloudColor = new THREE.Color();
        const dummy = new THREE.Object3D();
        let cursor = 0;
        for (let i = 0; i < (this.quality === 'lite' ? 13 : 24); i++) {
            const x = (rng() - .5) * 235, z = (rng() - .5) * 275 + 57;
            const y = 44 + rng() * 70;
            const pieces = 4 + Math.floor(rng() * 5);
            for (let j = 0; j < pieces && cursor < cloudCount; j++) {
                const r = 2.5 + rng() * 3.2;
                dummy.position.set(x + (j - pieces / 2) * 2.6, y + Math.sin(j * 3.9) * 1.1, z + (rng() - .5) * 3);
                dummy.scale.set(r, r * .56, r * .87);
                dummy.rotation.y = rng() * Math.PI;
                dummy.updateMatrix();
                cloudMesh.setMatrixAt(cursor, dummy.matrix);
                cloudColor.setHex(j % 3 === 0 ? 0xdcefe5 : j % 4 === 0 ? 0xfff8e9 : 0xffffff);
                cloudMesh.setColorAt(cursor, cloudColor);
                cursor++;
            }
        }
        cloudMesh.count = cursor;
        cloudMesh.instanceMatrix.needsUpdate = true;
        if (cloudMesh.instanceColor)
            cloudMesh.instanceColor.needsUpdate = true;
        cloudMesh.castShadow = false;
        const cloudDeck = new THREE.Group();
        cloudDeck.add(cloudMesh);
        this.root.add(cloudDeck);
        this.clouds.push(cloudDeck);
        this.clockCloudPositions.push(0);
    }
    buildTerrain() {
        mesh(new THREE.BoxGeometry(88, 2, 123), mat(0x709c70, .95), this.root, 0, -1.1, 25.5);
        mesh(new THREE.BoxGeometry(89, 1.3, 124), mat(0x405b49, .97), this.root, 0, -2.7, 25.5);
        const rng = seeded(42);
        const grassGeom = new THREE.ConeGeometry(.1, .7, 3), grassMat = new THREE.MeshStandardMaterial({ color: 0x9fd49a, roughness: 1 });
        const grass = new THREE.InstancedMesh(grassGeom, grassMat, 2400);
        grass.castShadow = false;
        const tmp = new THREE.Object3D();
        let gi = 0;
        for (let i = 0; i < 2400; i++) {
            const x = (rng() - .5) * 84, z = rng() * 118 - 33;
            if (Math.abs(x) < 4 && z < 6)
                continue;
            tmp.position.set(x, .1, z);
            const size = .38 + rng() * .85;
            tmp.scale.set(size, size, size);
            tmp.rotation.y = rng() * Math.PI;
            tmp.updateMatrix();
            grass.setMatrixAt(gi++, tmp.matrix);
        }
        grass.count = gi;
        grass.instanceMatrix.needsUpdate = true;
        this.root.add(grass);
        for (const data of [[0xf8bf81, 0], [0xf69dba, 1], [0xffedd2, 2], [0x99bbdf, 3]]) {
            const flower = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.22, 0), mat(data[0]), 310);
            let n = 0;
            for (let j = 0; j < 310; j++) {
                const x = (rng() - .5) * 80, z = rng() * 115 - 31;
                if (Math.abs(x) < 5 && z < 5)
                    continue;
                tmp.position.set(x, .43 + rng() * .3, z);
                const s = .7 + rng() * 1.35;
                tmp.scale.set(s, s * .8, s);
                tmp.rotation.y = rng() * 6.28;
                tmp.updateMatrix();
                flower.setMatrixAt(n++, tmp.matrix);
            }
            flower.count = n;
            flower.instanceMatrix.needsUpdate = true;
            this.root.add(flower);
        }
        // The low road is a readable contrasting route toward the first seed station.
        for (let z = -31; z < -1; z += 2.25) {
            const st = mesh(new THREE.CylinderGeometry(1.6, 1.8, .24, 7), mat(z % 4 ? 0xd5c59c : 0xe7d4ae, .95), this.root, Math.sin(z) * .4, .02, z);
            st.rotation.y = z * .1;
        }
        for (let i = 0; i < 12; i++) {
            const x = (i % 2 ? -1 : 1) * (14 + rng() * 23), z = -28 + i * 9.4;
            ball(this.root, 1.4 + rng(), 0x4a8062, x, .25, z, 2.3, .66, 1.2);
            for (let j = 0; j < 5; j++)
                ball(this.root, .35 + rng() * .45, [0xfccf93, 0xef9db9, 0xb4cdae][j % 3], x + (rng() - .5) * 2, 1.1 + rng(), z + (rng() - .5) * 2);
        }
        // Perimeter stakes, deliberately non-colliding decorative geometry.
        for (const x of [-39, 39])
            for (let z = -31; z < 80; z += 11) {
                const pole = mesh(new THREE.CylinderGeometry(.16, .24, 3, 8), wood, this.root, x, 1.4, z);
                ball(this.root, .45, 0xffd991, x, 3, z, .8, 1.4, .8);
                pole.castShadow = false;
            }
        const path = mesh(new THREE.PlaneGeometry(14, 22), new THREE.MeshBasicMaterial({ color: 0x607b64, transparent: true, opacity: .15, depthWrite: false }), this.root, 0, .08, 62);
        path.rotation.x = -Math.PI / 2;
        for (let i = 0; i < 16; i++) {
            const z = 70 + i * .8;
            mesh(new THREE.BoxGeometry(1.6, .25, .45), mat(0xf1dfb4, .85), this.root, Math.sin(i * .9) * 2, .12, z);
        }
    }
    archPoint(t, z) { return new THREE.Vector3(22 * Math.cos(t), 5 + 27 * Math.sin(t), z); }
    buildGreenhouse() {
        for (const z of [-6, 9, 24, 39, 54]) {
            const arr = [];
            for (let i = 0; i <= 24; i++)
                arr.push(this.archPoint(Math.PI * i / 24, z));
            tube(this.root, arr, .43, brass, 80);
            for (const x of [-22, 22]) {
                mesh(new THREE.CylinderGeometry(.35, .42, 5.7, 10), darkGold, this.root, x, 2.8, z);
                ball(this.root, .62, 0xe0c58f, x, 5, z);
            }
            for (const t of [Math.PI * .17, Math.PI * .83]) {
                const pt = this.archPoint(t, z);
                ball(this.root, .27, 0xfde4b1, pt.x, pt.y, pt.z);
            }
        }
        const geometry = new THREE.BufferGeometry();
        const vertices = [];
        for (let z = -6; z < 54; z += 15) {
            for (let i = 0; i < 24; i++) {
                if (i >= 11 && i <= 12 && z === 39)
                    continue; // skylight opening over the upper ascent
                const a = this.archPoint(Math.PI * i / 24, z), b = this.archPoint(Math.PI * (i + 1) / 24, z), c = this.archPoint(Math.PI * i / 24, z + 15), d = this.archPoint(Math.PI * (i + 1) / 24, z + 15);
                vertices.push(...a.toArray(), ...b.toArray(), ...c.toArray(), ...c.toArray(), ...b.toArray(), ...d.toArray());
            }
        }
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geometry.computeVertexNormals();
        const pane = mesh(geometry, glass, this.root);
        pane.castShadow = false;
        pane.receiveShadow = false;
        for (let z = -6; z < 54; z += 15) {
            for (const t of [Math.PI * .1, Math.PI * .33, Math.PI * .66, Math.PI * .9]) {
                rod(this.root, this.archPoint(t, z), this.archPoint(t, z + 15), .12, brass);
            }
        }
        // Hanging lanterns and ornamental railing keep the high path legible.
        for (let z = -2; z <= 44; z += 9) {
            rod(this.root, new THREE.Vector3(0, 30, z), new THREE.Vector3(0, 26, z), .06, brass);
            const lantern = mesh(new THREE.OctahedronGeometry(.67), skyGlow, this.root, 0, 25.7, z);
            lantern.castShadow = false;
            if (this.quality === 'rich' && z % 2 !== 0) {
                const light = new THREE.PointLight(0x81efd5, .8, 10, 2);
                light.position.set(0, 25.3, z);
                this.root.add(light);
            }
        }
        for (const x of [-22.4, 22.4]) {
            for (let z = -5; z < 54; z += 4) {
                mesh(new THREE.BoxGeometry(.7, 1.4, 1.7), wood, this.root, x, .65, z);
            }
        }
        const entrance = signSprite('THE GRAND CONSERVATORY', 760, '#e6f1c5');
        entrance.position.set(0, 11, -7.4);
        entrance.scale.set(16, 4, 1);
        this.root.add(entrance);
    }
    buildLandmarks() {
        // Botanical landmark 1: the moonbell arbor.
        const moonbell = new THREE.Group();
        moonbell.position.set(-17, 0, 11);
        this.root.add(moonbell);
        tube(moonbell, [new THREE.Vector3(0, 0, 0), new THREE.Vector3(1, 7, 0), new THREE.Vector3(-1, 14, 0), new THREE.Vector3(0, 19, 0)], .92, mat(0x437c6e), 30);
        for (let i = 0; i < 6; i++) {
            const a = i * Math.PI / 3;
            const pet = mesh(new THREE.ConeGeometry(2.7, 7, 16, 1, true), mat(i % 2 ? 0x82d2e4 : 0x77acd0, .36, .1), moonbell, Math.cos(a) * 1.5, 17.7, Math.sin(a) * 1.5);
            pet.rotation.z = Math.sin(a) * .23;
            pet.rotation.x = Math.cos(a) * .23;
            pet.castShadow = false;
        }
        ball(moonbell, 2.5, 0xfceeb6, 0, 16, 0, 1, 1.8, 1);
        const moonLabel = signSprite('MOONBELL ARBOR', 560);
        moonLabel.position.set(0, 24, 0);
        moonLabel.scale.set(10, 2.6, 1);
        moonbell.add(moonLabel);
        // Botanical landmark 2: giant prismatic orchid.
        const orchid = new THREE.Group();
        orchid.position.set(17, 0, 38);
        this.root.add(orchid);
        tube(orchid, [new THREE.Vector3(0, 0, 0), new THREE.Vector3(-2, 6, 0), new THREE.Vector3(1, 13, 1), new THREE.Vector3(0, 21, 0)], 1.3, mat(0x397858), 28);
        for (let i = 0; i < 10; i++) {
            const a = i * 2 * Math.PI / 10;
            const pet = ball(orchid, 2.7, i % 2 ? 0xff9cae : 0xb5a1ec, Math.cos(a) * 4.6, 19.5 + Math.sin(i * 7) * 2, Math.sin(a) * 4.6, 1.1, 2.1, .7);
            pet.rotation.y = a;
            pet.rotation.z = Math.sin(a) * .45;
        }
        ball(orchid, 3.6, 0xffe0a6, 0, 20, 0, 1, .75, 1);
        const orchLabel = signSprite('PRISM ORCHID', 500);
        orchLabel.position.set(0, 28, 0);
        orchLabel.scale.set(10, 2.6, 1);
        orchid.add(orchLabel);
        // Botanical landmark 3 is the accessible sunflower itself, built in stages below.
        for (let i = 0; i < 15; i++) {
            const x = 27 * Math.sin(i * 1.67), z = -19 + i * 6;
            if (Math.abs(x) < 7)
                continue;
            tube(this.root, [new THREE.Vector3(x, 0, z), new THREE.Vector3(x + 1, 3, z), new THREE.Vector3(x, 5.6, z)], .22, mat(0x3f9874), 9);
            ball(this.root, 1.2, i % 2 ? 0xf5c2a1 : 0xceaae4, x, 5.7, z, .6, 1.7, .7);
        }
    }
    buildPollen() {
        const rng = seeded(300), positions = new Float32Array(1000 * 3);
        for (let i = 0; i < 1000; i++) {
            positions[i * 3] = (rng() - .5) * 65;
            positions[i * 3 + 1] = rng() * 58 + 1;
            positions[i * 3 + 2] = rng() * 135 - 25;
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        this.pollen = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xffe5aa, size: .19, transparent: true, opacity: .6, depthWrite: false, sizeAttenuation: true }));
        this.root.add(this.pollen);
    }
    surfaceRoot(stage) { return stage === 0 ? this.root : this.growth[stage - 1]; }
    local(stage, x, y, z) {
        if (stage === 0)
            return new THREE.Vector3(x, y, z);
        const p = this.growthPivot[stage - 1];
        return new THREE.Vector3(x - p.x, y - p.y, z - p.z);
    }
    buildSurface(s) {
        const root = this.surfaceRoot(s.stage);
        const p = this.local(s.stage, s.x, s.top, s.z);
        const group = new THREE.Group();
        group.position.copy(p);
        group.name = `surface-${s.id}`;
        root.add(group);
        if (s.look === 'island') {
            mesh(new THREE.CylinderGeometry(s.rx - .8, s.rx + 2, 3.6, 64, 1), mat(0x536c5e), group, 0, -2, 0);
            mesh(new THREE.CylinderGeometry(s.rx - 1, s.rx - .7, .9, 64), mat(0xa4d09a), group, 0, -.46, 0);
            mesh(new THREE.TorusGeometry(s.rx - 1.5, .18, 10, 72), skyGlow, group, 0, -.04, 0).rotation.x = Math.PI / 2;
            const label = signSprite('THE HOLY WATERING CAN', 750);
            label.position.set(0, 12, -1);
            label.scale.set(16, 4, 1);
            group.add(label);
            for (let i = 0; i < 18; i++) {
                const a = i * Math.PI / 9;
                ball(group, .7, i % 2 ? 0xfde0ab : 0xf39ab8, Math.cos(a) * (s.rx - 2), .3, Math.sin(a) * (s.rz - 2), .8, 1.2, 1.2);
            }
            return;
        }
        const isLeaf = s.look === 'leaf';
        const isPetal = s.look === 'petal';
        const isSun = s.look === 'sunflower';
        const palette = isSun ? 0x965e2e : isPetal ? 0xd8a5b7 : isLeaf ? 0x559f6b : 0x86bfa2;
        const under = mesh(new THREE.SphereGeometry(1, 32, 14), mat(isSun ? 0x725027 : 0x376b58), group, 0, -.24, 0);
        under.scale.set(s.rx, .34, s.rz);
        if (isSun) {
            mesh(new THREE.CylinderGeometry(5.8, 5.9, .54, 64), mat(0x95652f, .91), group, 0, -.1, 0);
            // Sunflower's seed tessellation uses two instanced materials instead of 180 meshes.
            const darkSeeds = new THREE.InstancedMesh(sphereTemplate, mat(0x523e2b, .95), 60);
            const goldSeeds = new THREE.InstancedMesh(sphereTemplate, mat(0xe2ad5a, .75), 120);
            const seed = new THREE.Object3D();
            let darkIndex = 0, goldIndex = 0;
            for (let i = 0; i < 180; i++) {
                const r = 5.35 * Math.sqrt((i + .5) / 180), a = i * 2.399963;
                seed.position.set(Math.sin(a) * r, .25, Math.cos(a) * r);
                seed.scale.set(.115 * .8, .115 * .35, .115 * .8);
                seed.rotation.y = a;
                seed.updateMatrix();
                if (i % 3 === 0)
                    darkSeeds.setMatrixAt(darkIndex++, seed.matrix);
                else
                    goldSeeds.setMatrixAt(goldIndex++, seed.matrix);
            }
            darkSeeds.instanceMatrix.needsUpdate = true;
            goldSeeds.instanceMatrix.needsUpdate = true;
            darkSeeds.castShadow = false;
            goldSeeds.castShadow = false;
            group.add(darkSeeds, goldSeeds);
            for (let i = 0; i < 22; i++) {
                const a = i * 2 * Math.PI / 22;
                const pet = ball(group, 2.15, i % 2 ? 0xffd277 : 0xffbc54, Math.cos(a) * 7.7, -.15, Math.sin(a) * 7.7, .67, .17, 1.35);
                pet.rotation.y = -a;
                this.petals.push(pet);
            }
            mesh(new THREE.TorusGeometry(5.9, .3, 8, 64), mat(0xe7ac53), group, 0, .04, 0).rotation.x = Math.PI / 2;
        }
        else {
            const top = mesh(new THREE.SphereGeometry(1, 32, 16), mat(palette, .68), group, 0, -.04, 0);
            top.scale.set(s.rx, .18, s.rz);
            const vein = mat(isLeaf ? 0xb6e28a : isPetal ? 0xffe0ad : 0xcff1bd, .8);
            tube(group, [new THREE.Vector3(0, .14, -s.rz * .76), new THREE.Vector3(0, .2, 0), new THREE.Vector3(0, .14, s.rz * .76)], .12, vein, 22);
            for (const f of [-1, 1])
                for (const n of [-.45, 0, .45]) {
                    tube(group, [new THREE.Vector3(0, .17, n * s.rz), new THREE.Vector3(f * s.rx * .34, .18, n * s.rz + .7), new THREE.Vector3(f * s.rx * .65, .12, n * s.rz + 1.3)], .057, vein, 8);
                }
            if (!isLeaf) {
                for (let i = 0; i < 8; i++) {
                    const a = i * Math.PI / 4;
                    const pet = ball(group, 1.75, isPetal ? (i % 2 ? 0xffdfb0 : 0xf7a2bc) : (i % 2 ? 0xa4e2bb : 0xf2b0cd), Math.cos(a) * s.rx * .83, -.1, Math.sin(a) * s.rz * .83, 1.1, .15, 1.2);
                    pet.rotation.y = a;
                    this.petals.push(pet);
                }
            }
        }
        // Stable structural stems always connect the platform to something recognizable.
        const baseY = s.stage === 1 ? 0 : s.stage === 2 ? 8.8 : 20;
        if (s.top > baseY + 2 && !isSun) {
            const p0 = this.local(s.stage, s.x + (s.z % 3), baseY, s.z - 1.1), p1 = this.local(s.stage, s.x - 1.7, baseY + (s.top - baseY) * .42, s.z - 1.2), p2 = this.local(s.stage, s.x, s.top - .3, s.z);
            tube(root, [p0, p1, p2], isLeaf ? .43 : .37, mat(isLeaf ? 0x4c845b : 0x4d9568), 24);
        }
        const trim = mesh(new THREE.TorusGeometry(Math.min(s.rx, s.rz) * .87, .055, 6, 48), mat(isLeaf ? 0x92d3a7 : 0xffdfa6, .65), group, 0, -.09, 0);
        trim.scale.set(s.rx / s.rz, 1, 1);
        trim.rotation.x = Math.PI / 2;
        trim.castShadow = false;
    }
    buildSunflowerStalk() {
        const x = SUMMIT.x, z = SUMMIT.z;
        tube(this.root, [new THREE.Vector3(x, 0, z), new THREE.Vector3(x - 3, 9, z), new THREE.Vector3(x + 2, 19, z - 1), new THREE.Vector3(x - 1, 30, z), new THREE.Vector3(x, 41, z)], 1.56, mat(0x4b946b, .86), 54);
        for (let i = 0; i < 7; i++) {
            const y = 4 + i * 5.2, a = i * 2.4;
            const leaf = ball(this.root, 2.2, 0x58b66e, x + Math.cos(a) * 3, y, z + Math.sin(a) * 3, 1.9, .2, .8);
            leaf.rotation.y = a;
            tube(this.root, [new THREE.Vector3(x, y - 1, z), new THREE.Vector3(x + Math.cos(a) * 2, y, z + Math.sin(a) * 2), new THREE.Vector3(x + Math.cos(a) * 4, y + .4, z + Math.sin(a) * 4)], .22, flora[1], 12);
        }
        const tip = signSprite('THE SUNFLOWER OF UNREASONABLE IMPORTANCE', 780);
        tip.position.set(x, 50, z);
        tip.scale.set(19, 4.8, 1);
        this.root.add(tip);
        // The dormant bud is readable from the opening until stage three blooms.
        const dormant = ball(this.root, 3.1, 0x477f56, x, 40, z, 1.1, 1.45, 1.1);
        dormant.name = 'dormant-bud';
    }
    buildStationsAndDew() {
        STATIONS.forEach((s, i) => {
            const baseStage = i === 0 ? 0 : i;
            const root = this.surfaceRoot(baseStage);
            const p = this.local(baseStage, s.x, s.y, s.z);
            const g = new THREE.Group();
            g.position.copy(p);
            root.add(g);
            mesh(new THREE.CylinderGeometry(1.65, 1.95, .56, 12), wood, g, 0, .26, 0);
            mesh(new THREE.CylinderGeometry(1.36, 1.44, .28, 12), brass, g, 0, .62, 0);
            for (let j = 0; j < 6; j++) {
                const a = j * Math.PI / 3;
                ball(g, .22, 0xffdb90, Math.sin(a) * 1.2, .9, Math.cos(a) * 1.2);
            }
            const orb = mesh(new THREE.OctahedronGeometry(.77), new THREE.MeshStandardMaterial({ color: 0xffd58d, emissive: 0xf7ba4e, emissiveIntensity: .82, roughness: .2 }), g, 0, 1.55, 0);
            orb.name = 'seed-orb';
            this.altars.push(orb);
            const sign = signSprite(`${i + 1} / 3  ${s.name}`, 740);
            sign.position.set(0, 4.15, 0);
            sign.scale.set(14, 3.6, 1);
            g.add(sign);
            const d = DEW[i], dp = this.local(baseStage, d.x, d.y, d.z);
            const dew = new THREE.Group();
            dew.position.copy(dp);
            root.add(dew);
            mesh(new THREE.CylinderGeometry(1.2, 1.35, .72, 20), brass, dew, 0, .3, 0);
            mesh(new THREE.CylinderGeometry(.98, 1.02, .14, 20), mat(0x4ccfc8, .08, .18, 0x2fa9bb, .6), dew, 0, .73, 0);
            mesh(new THREE.TorusGeometry(1.08, .14, 8, 32), skyGlow, dew, 0, .76, 0).rotation.x = Math.PI / 2;
            const icon = signSprite('RENEWABLE DEW', 370, '#9dfbf1');
            icon.position.set(0, 2.8, 0);
            icon.scale.set(6.8, 1.7, 1);
            dew.add(icon);
            const point = new THREE.PointLight(0x72e8db, 1.8, 8, 2);
            point.position.y = 1.2;
            dew.add(point);
        });
    }
    buildCan(parent, x, y, z, s, hero = true) {
        const g = new THREE.Group();
        g.position.set(x, y, z);
        g.scale.setScalar(s);
        parent.add(g);
        mesh(new THREE.CylinderGeometry(2.25, 2.55, 4.7, 24), mat(hero ? 0x46b8b2 : 0xb1a596, .28, .26), g, 0, 2.4, 0);
        mesh(new THREE.CylinderGeometry(2.35, 2.35, .24, 24), brass, g, 0, 4.85, 0);
        mesh(new THREE.CylinderGeometry(.9, .95, .45, 20), mat(0xf5d39a, .3, .1), g, 0, 5.15, 0);
        const handle = mesh(new THREE.TorusGeometry(2.1, .43, 12, 34, Math.PI * 1.42), mat(0xe1c186, .35, .35), g, 2.4, 2.6, 0);
        handle.rotation.z = Math.PI / 2;
        const spout = mesh(new THREE.CylinderGeometry(.65, .42, 4.5, 14), mat(0x63c4bc, .31, .2), g, -3.95, 3.3, 0);
        spout.rotation.z = -Math.PI * .35;
        const roseSprinkler = mesh(new THREE.CylinderGeometry(1.1, .75, .56, 20), brass, g, -5.6, 4.72, 0);
        roseSprinkler.rotation.z = -Math.PI * .35;
        for (let i = 0; i < 12; i++) {
            const a = i * 2 * Math.PI / 12;
            ball(g, .12, 0x253c3e, -5.61 + Math.cos(a) * .68, 5.06, Math.sin(a) * .68);
        }
        mesh(new THREE.TorusGeometry(2.33, .12, 7, 32), mat(0xffe2ad, .25, .55), g, 0, 2.7, 0).rotation.x = Math.PI / 2;
        if (hero) {
            for (let i = 0; i < 4; i++) {
                const a = i * Math.PI / 2;
                const star = mesh(new THREE.OctahedronGeometry(.62), skyGlow, g, Math.cos(a) * 5.5, 2.5 + Math.sin(a * 2), Math.sin(a) * 5.5);
                star.castShadow = false;
            }
            const light = new THREE.PointLight(0x7ffbe1, 2.5, 24);
            light.position.set(0, 5, 0);
            g.add(light);
        }
        return g;
    }
    buildFinalCan() {
        this.buildCan(this.root, CAN.x, CAN.y, CAN.z, 1.05);
        // Ring of wind currents makes the long glide destination perceptible from afar.
        for (let i = 0; i < 5; i++) {
            const ring = mesh(new THREE.TorusGeometry(11 + i * 2, .13, 7, 64), new THREE.MeshBasicMaterial({ color: 0xc5f8d0, transparent: true, opacity: .25, depthWrite: false }), this.root, CAN.x, 29 + i * 5, CAN.z);
            ring.rotation.x = Math.PI / 2;
        }
        const beacon = mesh(new THREE.CylinderGeometry(.45, .45, 85, 12), new THREE.MeshBasicMaterial({ color: 0xb2ffcf, transparent: true, opacity: .075, depthWrite: false }), this.root, CAN.x, 70, CAN.z);
        beacon.castShadow = false;
    }
    buildPlayer() {
        const root = this.player;
        const body = mesh(new THREE.SphereGeometry(1, 24, 18), ceramic, root, 0, 1.08, 0);
        body.scale.set(.66, .92, .54);
        this.avatarBody = body;
        const head = mesh(new THREE.SphereGeometry(.78, 24, 16), mat(0xf7e4bb, .7), root, 0, 1.76, .15);
        head.scale.set(.85, .73, .76);
        this.avatarHead = head;
        // Anonymous seed-pod adventurer: not humanoid cosplay or any franchise figure.
        ball(root, .11, 0x273b3e, -.22, 1.85, .71, 1, 1, .35);
        ball(root, .11, 0x273b3e, .22, 1.85, .71, 1, 1, .35);
        // A faint grounded contact shadow improves platform contact without faking collision.
        const contactShadow = mesh(new THREE.CircleGeometry(.93, 26), new THREE.MeshBasicMaterial({ color: 0x1a443d, transparent: true, opacity: .23, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 }), root, 0, .02, 0);
        contactShadow.rotation.x = -Math.PI / 2;
        contactShadow.castShadow = false;
        contactShadow.receiveShadow = false;
        this.landingShadow = contactShadow;
        const nose = ball(root, .085, 0xe58b76, 0, 1.65, .75);
        nose.castShadow = false;
        const crest = mesh(new THREE.ConeGeometry(.32, 1.15, 6), mat(0x60a96e), root, -.08, 2.72, 0);
        crest.rotation.z = -.3;
        ball(root, .4, 0x70b982, -.15, 2.8, .18, 1, .3, .6);
        const sash = mesh(new THREE.TorusGeometry(.67, .115, 8, 24), mat(0x57bdb2), root, 0, 1.04, 0);
        sash.rotation.x = Math.PI * .42;
        // Botanical gold leaf emboss, stitched sash, and a ceramic collar; all original identity details.
        const collar = mesh(new THREE.TorusGeometry(.58, .085, 8, 26), mat(0xd7b076, .48, .32), root, 0, 1.51, .05);
        collar.rotation.x = Math.PI / 2;
        for (const side of [-1, 1]) {
            const eyebrow = ball(root, .14, 0x654a42, side * .22, 2.03, .68, 1.32, .3, .25);
            eyebrow.rotation.z = side * .2;
            const satchelStrap = mesh(new THREE.CylinderGeometry(.045, .045, 1.03, 7), mat(0xf4d39a, .85), root, side * .47, 1.08, -.27);
            satchelStrap.rotation.z = side * .3;
        }
        const medallion = mesh(new THREE.TorusGeometry(.24, .042, 8, 24), mat(0xe0b770, .38, .35), root, 0, 1.18, .545);
        const seedMark = mesh(new THREE.OctahedronGeometry(.13, 0), mat(0x70c6a7, .28, .22, 0x319b7c, .27), root, 0, 1.18, .591);
        seedMark.scale.set(.6, 1.2, .5);
        medallion.castShadow = false;
        for (const x of [-.35, .35]) {
            const foot = ball(root, .3, 0x624a39, x, .25, .17, 1, .73, 1.35);
            foot.name = x < 0 ? 'left-foot' : 'right-foot';
        }
        const backpack = mesh(new THREE.BoxGeometry(.92, 1.02, .33), mat(0x9d7254), root, 0, 1.08, -.57);
        backpack.rotation.x = .05;
        const label = mesh(new THREE.BoxGeometry(.62, .58, .02), cream, root, 0, 1.08, -.75);
        label.castShadow = false;
        const leaf = mesh(new THREE.OctahedronGeometry(.28), skyGlow, root, .25, 1.24, -.84);
        leaf.scale.set(.5, 1, .1);
        // Origami seed packet glider: symmetric broad cloth-paper wings, not franchise imagery.
        root.add(this.glider);
        this.glider.position.set(0, 2.72, 0);
        const paper = mat(0xf5e7b9, .65);
        const trim = mat(0x438e7a, .64);
        for (const dir of [-1, 1]) {
            const v = new Float32Array([0, 0, .05, dir * 4, .2, -.35, dir * 2.9, -.14, 2.0, 0, 0, .05, dir * 2.9, -.14, 2.0, dir * 1.9, .18, .8]);
            const geo = new THREE.BufferGeometry();
            geo.setAttribute('position', new THREE.BufferAttribute(v, 3));
            geo.computeVertexNormals();
            mesh(geo, paper, this.glider);
            rod(this.glider, new THREE.Vector3(0, 0, 0), new THREE.Vector3(dir * 4, .2, -.35), .07, trim);
            rod(this.glider, new THREE.Vector3(0, 0, 0), new THREE.Vector3(dir * 2.9, -.14, 2), .06, trim);
            const ink = mat(0xc7a36b, .74);
            for (const ratio of [.3, .58, .84]) {
                rod(this.glider, new THREE.Vector3(dir * ratio * 4, .135, -.12), new THREE.Vector3(dir * ratio * 2.7, -.075, 1.48), .017, ink);
            }
        }
        const packet = mesh(new THREE.BoxGeometry(1.65, .13, 1.55), mat(0xe2c99c), this.glider, 0, .04, .3);
        packet.rotation.y = .03;
        const seedSeal = mesh(new THREE.CircleGeometry(.39, 16), mat(0xb65768), this.glider, 0, .119, .3);
        seedSeal.rotation.x = -Math.PI / 2;
        this.glider.visible = false;
    }
    onEvent(event, state) {
        switch (event.type) {
            case 'grow':
                this.details.onGrowth(event.stage);
                this.ceremonialPulse = 1;
                break;
            case 'dew':
                this.details.onDew(event.index);
                break;
            case 'checkpoint':
            case 'summit':
            case 'respawn':
                this.details.onCheckpoint(state.player.position);
                break;
            case 'victory':
                this.details.onVictory();
                break;
            default: break;
        }
    }
    revealSpare() { this.spareCan.visible = true; this.spareLabel.visible = true; }
    hideSpare() { this.spareCan.visible = false; this.spareLabel.visible = false; }
    update(dt, state, reducedMotion = false) {
        this.clock += dt;
        const t = this.clock;
        const p = state.player.position;
        this.ceremonialPulse = Math.max(0, this.ceremonialPulse - dt * 1.3);
        this.player.position.set(p.x, p.y, p.z);
        if (this.landingShadow)
            this.landingShadow.visible = state.player.grounded && !state.player.gliding;
        const speed = Math.hypot(state.player.velocity.x, state.player.velocity.z);
        const pace = Math.min(1, speed / 8.2);
        const turn = Math.atan2(Math.sin(state.player.facing - this.smoothFacing), Math.cos(state.player.facing - this.smoothFacing));
        this.smoothFacing += turn * (reducedMotion ? 1 : Math.min(1, dt * 14));
        this.player.rotation.y = this.smoothFacing;
        this.player.rotation.z = reducedMotion ? 0 : Math.max(-.085, Math.min(.085, -turn * .065));
        if (this.avatarBody) {
            this.avatarBody.position.y = 1.08 + (reducedMotion ? 0 : Math.abs(Math.sin(t * 15)) * pace * .045);
            this.avatarBody.rotation.x = reducedMotion ? 0 : Math.min(.12, pace * .085);
            this.avatarBody.scale.y = .92 * (1 + (reducedMotion ? 0 : this.ceremonialPulse * .09));
        }
        if (this.avatarHead) {
            this.avatarHead.position.y = 1.76 + (reducedMotion ? 0 : Math.sin(t * 12) * pace * .065);
            this.avatarHead.rotation.z = reducedMotion ? 0 : Math.sin(t * 1.7) * .035;
        }
        const feet = this.player.children.filter((o) => o.name === 'left-foot' || o.name === 'right-foot');
        if (feet.length === 2) {
            const intensity = state.player.grounded ? pace : 0.13;
            feet[0].position.z = .17 + Math.sin(t * 15) * .19 * intensity;
            feet[1].position.z = .17 - Math.sin(t * 15) * .19 * intensity;
            feet[0].position.y = .25 + (reducedMotion ? 0 : Math.max(0, Math.sin(t * 15)) * .1 * intensity);
            feet[1].position.y = .25 + (reducedMotion ? 0 : Math.max(0, -Math.sin(t * 15)) * .1 * intensity);
        }
        this.glider.visible = state.player.gliding;
        if (!reducedMotion) {
            this.glider.rotation.z = state.player.gliding ? Math.sin(t * 3) * .035 : 0;
            this.glider.rotation.x = state.player.gliding ? Math.sin(t * 2) * .023 : 0;
        }
        for (let i = 0; i < 3; i++) {
            const g = this.growth[i], born = state.seedTime[i];
            const visible = i < state.grown;
            g.visible = visible;
            if (visible) {
                const f = reducedMotion ? 1 : Math.min(1, Math.max(0, (state.elapsed - born) / 1.7));
                g.scale.set(1, 1 - Math.pow(1 - f, 3), 1);
            }
        }
        const bud = this.root.getObjectByName('dormant-bud');
        if (bud)
            bud.visible = state.grown < 3;
        // An architectural lighting progression: morning mint, flowering rose, gilded summit, sky-bound finale.
        const chapter = state.summitLaunch ? 3 : Math.min(2, state.grown);
        const l = reducedMotion ? 1 : Math.min(1, dt * .5);
        if (this.scene.fog instanceof THREE.FogExp2)
            this.scene.fog.color.lerp(fogChapters[chapter], l);
        if (this.keyLight)
            this.keyLight.color.lerp(sunChapters[chapter], l);
        this.altars.forEach((orb, i) => {
            const material = orb.material;
            material.emissiveIntensity = i === state.grown ? .85 + (reducedMotion ? 0 : Math.sin(t * 3 + i) * .2) : .18;
            orb.rotation.y = reducedMotion ? 0 : t * .45 + i;
        });
        if (!reducedMotion) {
            this.animSeed += dt;
            this.clouds.forEach((c, i) => { c.position.x = this.clockCloudPositions[i] + Math.sin(this.animSeed * .17 + i) * .56; });
            this.petals.forEach((x, i) => { x.rotation.z = Math.sin(t * .55 + i) * .014; });
            if (this.pollen)
                this.pollen.rotation.y = Math.sin(t * .07) * .003;
        }
        this.details.update(dt, state, reducedMotion);
    }
    dispose() {
        // Shared geometries and palette materials must be disposed once, not once per instance.
        const geometries = new Set();
        const materials = new Set();
        const textures = new Set();
        this.root.traverse((o) => {
            if (o instanceof THREE.Mesh || o instanceof THREE.Points || o instanceof THREE.Sprite || o instanceof THREE.InstancedMesh) {
                if (o.geometry)
                    geometries.add(o.geometry);
                const mats = Array.isArray(o.material) ? o.material : [o.material];
                mats.forEach((m) => {
                    if (m) {
                        materials.add(m);
                        for (const key of ['map', 'alphaMap', 'normalMap', 'roughnessMap', 'metalnessMap', 'emissiveMap']) {
                            const texture = m[key];
                            if (texture instanceof THREE.Texture)
                                textures.add(texture);
                        }
                    }
                });
            }
        });
        textures.forEach(x => x.dispose());
        materials.forEach(x => x.dispose());
        geometries.forEach(x => x.dispose());
        materialCache.clear();
        this.root.parent?.remove(this.root);
    }
}
