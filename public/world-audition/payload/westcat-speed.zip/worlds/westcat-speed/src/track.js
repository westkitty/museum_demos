/** All game-world distances are authored meters. Visuals are original abstractions, not map data. */
/** Elongates the four authored districts without changing their identity or vertical profile. */
export const TRACK_STRETCH = 2.2;
export const COURSE_LENGTH = 2700 * TRACK_STRETCH;
export const PLAYER_RADIUS = 1.45;
const RAW_PROFILE = [
    { x: 0, y: 0 }, { x: 55, y: 0 }, { x: 122, y: 4 }, { x: 175, y: 9 }, { x: 235, y: 4 },
    { x: 310, y: 0 }, { x: 405, y: 0 }, { x: 478, y: 0 }, { x: 535, y: 4 },
    { x: 600, y: 2 }, { x: 685, y: 8 }, { x: 765, y: 16 }, { x: 835, y: 6 }, { x: 918, y: 0 },
    { x: 1010, y: 12 }, { x: 1100, y: 22 }, { x: 1180, y: 9 }, { x: 1245, y: 10 },
    { x: 1330, y: 30 }, { x: 1405, y: 36 }, { x: 1490, y: 27 }, { x: 1572, y: 27 },
    { x: 1665, y: 27 }, { x: 1750, y: 43 }, { x: 1830, y: 29 },
    { x: 1890, y: 29 }, { x: 1990, y: 25 }, { x: 2080, y: 35 }, { x: 2180, y: 35 },
    { x: 2280, y: 17 }, { x: 2350, y: 10 }, { x: 2435, y: 15 },
    { x: 2500, y: 11 }, { x: 2590, y: 15 }, { x: 2650, y: 5 }, { x: 2700, y: 0 }
];
export const PROFILE = RAW_PROFILE.map(p => ({ x: p.x * TRACK_STRETCH, y: p.y }));
// Gaps are deliberately narrower than the long scenic stretches; the spring near each lip guarantees a route.
export const GAPS = [
    { start: 860 * TRACK_STRETCH, end: 860 * TRACK_STRETCH + 39 },
    { start: 1710 * TRACK_STRETCH, end: 1710 * TRACK_STRETCH + 40 },
    { start: 2460 * TRACK_STRETCH, end: 2460 * TRACK_STRETCH + 38 }
];
export const CHECKPOINTS = [
    { x: 600 * TRACK_STRETCH, name: 'Forest Outskirts' },
    { x: 1240 * TRACK_STRETCH, name: 'Cedar Climb' },
    { x: 1870 * TRACK_STRETCH, name: 'The Sentinel' },
    { x: 2360 * TRACK_STRETCH, name: 'Last Broadcast' }
];
export const LOOPS = [
    { x: 442 * TRACK_STRETCH, radius: 22 },
    { x: 1617 * TRACK_STRETCH, radius: 27 }
];
export const RAILS = [
    { start: 1360 * TRACK_STRETCH, end: 1505 * TRACK_STRETCH, lift: 5, exitLift: 8 },
    { start: 2110 * TRACK_STRETCH, end: 2272 * TRACK_STRETCH, lift: 6, exitLift: 9 }
];
export const SPRINGS = [
    { x: GAPS[0].start - 10, impulse: 35 },
    { x: GAPS[1].start - 10, impulse: 36 },
    { x: GAPS[2].start - 10, impulse: 35 }
];
export const BOOST_PADS = [116, 745, 1522, 1980, 2530].map(x => x * TRACK_STRETCH);
export const HURDLES = [245, 686, 1112, 1798, 2302].map(x => x * TRACK_STRETCH);
export function regionFor(x) {
    return x < 580 * TRACK_STRETCH ? 'downtown' : x < 1230 * TRACK_STRETCH ? 'forest' : x < 1850 * TRACK_STRETCH ? 'cedar' : 'sentinel';
}
export function heightAt(x) {
    const clamped = Math.max(0, Math.min(COURSE_LENGTH, x));
    let low = 0, high = PROFILE.length - 1;
    while (low + 1 < high) {
        const m = (low + high) >> 1;
        if (PROFILE[m].x < clamped)
            low = m;
        else
            high = m;
    }
    const a = PROFILE[low], b = PROFILE[high], f = Math.max(0, Math.min(1, (clamped - a.x) / (b.x - a.x)));
    const smooth = f * f * (3 - 2 * f);
    return a.y + (b.y - a.y) * smooth;
}
export function slopeAt(x) { return (heightAt(x + .3) - heightAt(x - .3)) / .6; }
export function isGap(x) { return GAPS.some(g => x > g.start && x < g.end); }
export function railY(index, x) {
    const rail = RAILS[index];
    const t = Math.max(0, Math.min(1, (x - rail.start) / (rail.end - rail.start)));
    return heightAt(rail.start) + rail.lift + (heightAt(rail.end) + rail.exitLift - heightAt(rail.start) - rail.lift) * t;
}
export function zoneProgress(x) { return Math.max(0, Math.min(1, x / COURSE_LENGTH)); }
