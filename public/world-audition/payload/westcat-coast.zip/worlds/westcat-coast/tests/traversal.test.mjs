import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createPlayer,simulate} from '../src/physics.js';
import {CHECKPOINTS,CHAPTERS,FINISH_X,PLATFORMS} from '../src/course.js';
const witness=JSON.parse(readFileSync(new URL('./course-route-witness.json',import.meta.url),'utf8'));

test('one uninterrupted 60Hz input witness crosses all four chapters and six checkpoints, then escapes owl chase',()=>{
  assert.equal(witness.schema,'westcat-route-v1');assert.equal(witness.macroFrames,7);
  const p=createPlayer();let index=0,owlX=92,chase=false,lastJump=false;
  const visitedChapters=new Set([0]);let wallJumps=0,secondJumps=0,chaseFrames=0;
  for(let macro=0;macro<witness.actions.length;macro++){
    const [axis,jump]=witness.actions[macro];
    assert.ok([-1,0,1].includes(axis) && [0,1].includes(jump));
    assert.ok(!(jump&&lastJump),'A new button press must include a released macro between presses');
    lastJump=!!jump;
    for(let j=0;j<witness.macroFrames;j++){
      const events=simulate(p,{axis,jumpPressed:!!jump&&j===0,jumpHeld:!!jump},PLATFORMS,1/60);
      wallJumps+=Number(events.includes('walljump'));secondJumps+=Number(events.includes('doublejump'));
      assert.ok(!events.includes('fall'),`Fell on macro ${macro} near x=${p.x.toFixed(2)}`);
      for(let k=index+1;k<CHECKPOINTS.length;k++){
        const cp=CHECKPOINTS[k];if(p.x<cp.x)break;
        if(p.y>=cp.y-.45 && p.y<=cp.y+3){index=k;}
      }
      if(!chase&&p.x>=103){chase=true;owlX=p.x-15;}
      if(chase){chaseFrames++;owlX+=(5.35+Math.min(.9,(p.x-103)/55))/60;assert.ok(owlX<=p.x-.9,`Owl caught player on macro ${macro}`);}
      for(let c=0;c<CHAPTERS.length;c++)if(p.x>=CHAPTERS[c].from)visitedChapters.add(c);
    }
  }
  assert.deepEqual([...visitedChapters].sort(),[0,1,2,3]);
  assert.equal(index,CHECKPOINTS.length-1,'All checkpoints are collected on a contiguous non-teleported route');
  assert.ok(chaseFrames>0 && chase, 'Pursuit is active during final crossing');
  assert.ok(p.x>=FINISH_X && p.y>10.8,`Finish not reached x=${p.x} y=${p.y}`);
  assert.ok(secondJumps>0, 'Route exercises double jump rather than a no-jump shortcut');
});
