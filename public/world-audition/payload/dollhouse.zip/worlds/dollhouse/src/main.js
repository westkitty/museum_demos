import * as THREE from 'three';
import { act, initialState, pickup } from './rules.js';

const app = document.querySelector('#app');
app.innerHTML = `<canvas id="scene" aria-label="3D toy dollhouse with three helper robots"></canvas><div id="overlay"><div class="top"><div class="panel brand"><div class="eyebrow">MUSEUM OF ME · E18 · INDEPENDENT POCKET WORLD</div><h1>THE DOLLHOUSE<br>HAS NO DOOR</h1><p class="small">A tiny domestic crisis. Three software permissions. An unreasonable amount of paperwork.</p><button id="help">How to play</button> <button id="reset">Restart</button></div><div class="panel side"><div class="eyebrow">HOUSEHOLD INCIDENT REPORT</div><div id="objectives"></div><label for="role" class="small">ASSIGNED MECHANICAL HELPER</label><select id="role"><option value="continuity">Continuity · broad record recovery</option><option value="companion">Companion · append-only provenance</option><option value="moderation">Moderation · read-only inspection</option></select><div id="status" class="small"></div></div></div><div class="bottom"><div class="panel controls"><div class="eyebrow">INTERACTION CONSOLE</div><div id="toast" aria-live="polite"></div><div class="buttons"><button class="primary" id="interact">Interact · E</button><button id="inspect">Inspect · I</button><button id="drop">Pick up door · P</button></div><p class="small">WASD / arrows to move · E interact · 1–3 select helper · I inspect · P pick up · Touch controls below. Approach glowing objects.</p><div id="touch"><div><button data-move="left">◀</button><button data-move="up">▲</button><button data-move="down">▼</button><button data-move="right">▶</button></div><button class="primary" id="touchInteract">USE</button></div></div><div class="panel small">LOCAL SYNTHETIC DATA ONLY<br>No accounts · No external AI · No real memory changes<br><button id="return">Return to E18</button></div></div></div><div id="modal" class="modal"><div class="panel"><div class="eyebrow">E18 · MOCK MUSEUM PORTAL</div><h1>Welcome to the smallest administrative emergency.</h1><p>Find the glowing archive cabinet, recover its missing record with Continuity, pin it with Companion at the memory desk, then carry the toy door to its frame and authorize placement with Continuity.</p><p class="small">Moderation can inspect, but cannot write. Wrong assignments give explicit feedback. Nothing here touches actual companion systems.</p><button class="primary" id="start">Enter Dollhouse</button></div></div><div id="win" class="modal hidden"><div class="panel"><div class="eyebrow">HOUSEHOLD DISASTER AVERTED</div><h1>THE DOOR HAS BEEN AUTHORIZED.</h1><p>Three tasks completed. No unauthorized writes. The door is now the most heavily documented object in the house.</p><button class="primary" id="again">Replay</button> <button id="winReturn">Return to E18</button></div></div>`;
const $ = (id) => document.getElementById(id);
let state = initialState(), started = false, victory = false;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#292640');
scene.fog = new THREE.Fog('#292640', 19, 38);
const camera = new THREE.PerspectiveCamera(46, 1, .1, 100);
camera.position.set(11, 13, 17);
camera.lookAt(0, 1, 0);
const renderer = new THREE.WebGLRenderer({ canvas: $('scene'), antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.4;
scene.add(new THREE.HemisphereLight(0xb9d7ff, 0x76516b, 2.2));
const sun = new THREE.DirectionalLight(0xffdfb4, 3.5);
sun.position.set(-5, 12, 8);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -12;
sun.shadow.camera.right = 12;
sun.shadow.camera.top = 12;
sun.shadow.camera.bottom = -12;
scene.add(sun);
const pink = new THREE.PointLight(0xff6c9e, 45, 16);
pink.position.set(-5, 5, -2);
scene.add(pink);
const cyan = new THREE.PointLight(0x65eaff, 38, 15);
cyan.position.set(5, 4, 1);
scene.add(cyan);
const mat = (c, roughness = .7, metalness = 0) => new THREE.MeshStandardMaterial({ color: c, roughness, metalness });
const cream = mat('#fff0ce'), wood = mat('#b97465'), gold = mat('#f5b968', .28, .48), navy = mat('#303956'), mint = mat('#8ee5c5'), lilac = mat('#b7a5ef'), rose = mat('#ff9ea9');
function cube(w, h, d, m, x, y, z, parent = scene) { const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); o.castShadow = true; o.receiveShadow = true; parent.add(o); return o; }
function ball(r, m, x, y, z, parent = scene) { const o = new THREE.Mesh(new THREE.SphereGeometry(r, 18, 12), m); o.position.set(x, y, z); o.castShadow = true; parent.add(o); return o; }
function cylinder(rt, rb, h, m, x, y, z, parent = scene) { const o = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, 20), m); o.position.set(x, y, z); o.castShadow = true; parent.add(o); return o; }
// Open-front dollhouse: three colorful rooms, one continuous navigable floor.
cube(14, .55, 10, wood, 0, -.35, 0);
cube(14, .12, 10, cream, 0, -.04, 0);
cube(14, 5, .35, lilac, 0, 2.5, -5);
cube(.35, 5, 10, rose, -7, 2.5, 0);
cube(.35, 5, 10, mint, 7, 2.5, 0);
cube(.16, 3.5, 4, cream, -2.2, 1.75, -3);
cube(.16, 3.5, 3, cream, 2.5, 1.75, -3.5);
// Room rugs and decorative furniture.
for (const [x, z, c] of [[-4, 0, '#e6a3b7'], [.2, .4, '#a3cfec'], [4.5, .3, '#e3c187']]) {
    const rug = cube(3, .04, 3, mat(c), x, .035, z);
    rug.receiveShadow = true;
}
// Archive cabinet, drawers, decorative books.
cube(2.1, 2.3, .9, navy, -4.8, 1.15, -3.6);
for (let i = 0; i < 3; i++) {
    cube(1.75, .48, .08, wood, -4.8, .55 + i * .66, -3.1);
    ball(.08, gold, -4.8, .55 + i * .66, -3.02);
}
for (let i = 0; i < 8; i++)
    cube(.12 + (.03 * (i % 3)), .6 + (i % 3) * .13, .45, mat(['#ffd17b', '#a7d9cb', '#b4a3ea', '#e5a0ac'][i % 4]), -6.2 + i * .25, 2.7, -4.1);
// Memory desk and lamp.
cube(2.8, .18, 1.3, wood, .15, 1.05, -2.8);
for (const x of [-1, 1.2])
    for (const z of [-3.25, -2.3])
        cube(.15, 1, .15, gold, x, .55, z);
cylinder(.12, .18, .6, gold, .6, 1.45, -2.9);
const shade = new THREE.Mesh(new THREE.ConeGeometry(.45, .55, 12), rose);
shade.position.set(.6, 1.95, -2.9);
scene.add(shade);
cube(.9, .05, .65, cream, -.4, 1.18, -2.7);
cube(.3, .06, .5, rose, -.4, 1.24, -2.7);
// Sofa, table, plants, wall picture.
cube(2.5, .55, 1.1, mint, 4.6, .42, -3.5);
cube(2.5, .85, .28, mint, 4.6, .92, -4);
for (const x of [3.55, 5.65])
    cube(.3, .6, 1.2, mint, x, .6, -3.5);
cylinder(.8, .8, .13, gold, 4.5, .6, -1.7);
cylinder(.12, .16, .55, wood, 4.5, .29, -1.7);
for (const [x, z] of [[-6, -1], [6, -1], [1.7, -4.1]]) {
    cylinder(.4, .28, .5, rose, x, .25, z);
    for (let j = 0; j < 5; j++) {
        const leaf = ball(.38, mint, x + Math.sin(j * 2.4) * .3, .75 + j * .14, z + Math.cos(j * 2.4) * .3);
        leaf.scale.set(.7, 1.4, .6);
    }
}
cube(1.6, 1.2, .08, gold, 4.4, 3.3, -4.76);
cube(1.35, .95, .09, navy, 4.4, 3.3, -4.7);
ball(.32, rose, 4.4, 3.3, -4.62);
// Frame at east wall, door on floor.
cube(.28, 3.1, .4, gold, 6.72, 1.55, 1.3);
cube(.28, 3.1, .4, gold, 6.72, 1.55, -.7);
cube(.3, .25, 2.4, gold, 6.72, 3.05, .3);
const door = new THREE.Group();
scene.add(door);
cube(.15, 2.65, 1.72, wood, 0, 1.32, 0, door);
cube(.18, 1.85, 1.25, rose, 0, 1.38, 0, door);
ball(.11, gold, .17, 1.2, .55, door);
door.position.set(4.5, -.55, 2.9);
door.rotation.y = .25;
door.rotation.z = Math.PI / 2;
// Mechanical helper robots are clearly tools, not canon embodiments.
const helpers = [];
for (const [role, x, z, color] of [['continuity', -4.8, 1.9, '#7ad5ff'], ['companion', 0, 2.5, '#ffb4cb'], ['moderation', 4.4, 2.5, '#ffe08e']]) {
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    scene.add(g);
    cylinder(.43, .5, .65, mat(color, .28, .35), 0, .55, 0, g);
    ball(.4, cream, 0, 1.1, 0, g);
    cube(.45, .18, .08, navy, 0, 1.12, .36, g);
    for (const dx of [-.12, .12])
        ball(.045, gold, dx, 1.13, .42, g);
    cylinder(.04, .04, .3, gold, 0, 1.58, 0, g);
    ball(.1, mat(color), 0, 1.76, 0, g);
    for (const dx of [-.58, .58])
        ball(.13, gold, dx, .62, 0, g);
    helpers.push({ role, group: g, home: new THREE.Vector3(x, 0, z), color });
}
// Player: generic toy pawn, never a character depiction.
const player = new THREE.Group();
scene.add(player);
cylinder(.27, .4, .8, gold, 0, .5, 0, player);
ball(.36, cream, 0, 1.2, 0, player);
const cap = new THREE.Mesh(new THREE.ConeGeometry(.42, .42, 16), rose);
cap.position.y = 1.57;
player.add(cap);
player.position.set(0, 0, 4);
const targets = [];
for (const [task, x, z, c] of [['record', -4.8, -2.5, '#78d8ff'], ['memory', .15, -1.7, '#ff9fcb'], ['door', 6.1, .3, '#ffe098']]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(.65, .065, 8, 32), new THREE.MeshBasicMaterial({ color: c }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(x, .12, z);
    scene.add(ring);
    targets.push({ task, pos: new THREE.Vector3(x, 0, z), mesh: ring });
}
const keys = new Set();
const moveTouch = new Set();
let last = performance.now(), acc = 0, elapsed = 0;
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
function toast(msg) { $('toast').textContent = msg; updateUI(); }
function updateUI() { const names = [{ task: 'record', name: 'Recover missing record' }, { task: 'memory', name: 'Append provenance pin' }, { task: 'door', name: 'Restore the toy door' }]; $('objectives').innerHTML = names.map((o, i) => `<div class="objective ${state.completed[o.task] ? 'done' : ''}">${state.completed[o.task] ? '✓' : '○'} ${i + 1}. ${o.name}</div>`).join(''); $('status').textContent = `R-018: ${state.entries[0].forgotten ? 'FORGOTTEN (trace retained)' : 'RECOVERED'} · ${state.entries[0].marks.length} pin(s) · Door: ${state.carrying ? 'carried' : state.doorPosition}`; }
function nearest() { let best = null, dist = 1.85; for (const t of targets) {
    const d = player.position.distanceTo(t.pos);
    if (d < dist) {
        dist = d;
        best = t.task;
    }
} return best; }
function interact() { if (!started || victory)
    return; const t = nearest(); if (!t) {
    toast('Approach a glowing task ring first.');
    return;
} if (t === 'door' && !state.carrying && player.position.distanceTo(new THREE.Vector3(4.5, 0, 2.9)) < 2.6) {
    toast(pickup(state));
    return;
} toast(act(state, t)); if (t === 'door' && state.completed.door) {
    door.position.set(6.7, 0, .3);
    door.rotation.set(0, 0, 0);
    victory = true;
    setTimeout(() => { $('win').classList.remove('hidden'); }, reduced ? 0 : 1400);
} }
function inspect() { const t = nearest(); if (!t) {
    toast('No nearby task. Synthetic record R-018 retains its forgotten/recovery state.');
    return;
} const descriptions = { record: 'Archive cabinet: R-018. Continuity may recover; Moderation can inspect only.', memory: 'Memory desk: Companion can append a pin with provenance. No rewriting.', door: 'Door frame: requires a recovered and pinned record, a carried door, and Continuity authorization.' }; toast(descriptions[t] + (state.selected === 'moderation' ? ' Read-only inspection granted.' : '')); }
function pick() { if (player.position.distanceTo(new THREE.Vector3(4.5, 0, 2.9)) > 2.4 && !state.carrying) {
    toast('Move closer to the fallen door.');
    return;
} toast(pickup(state)); }
function restart() { state = initialState(); victory = false; player.position.set(0, 0, 4); door.position.set(4.5, -.55, 2.9); door.rotation.set(0, .25, Math.PI / 2); $('win').classList.add('hidden'); $('role').value = 'continuity'; toast('New synthetic household incident. All tasks reset.'); }
function returnPortal() { $('modal').classList.remove('hidden'); $('modal').querySelector('h1').textContent = 'Return to E18 · mock portal'; $('modal').querySelector('p').textContent = 'This standalone prototype does not navigate or modify the production museum. Choose Enter Dollhouse to resume.'; $('start').textContent = 'Resume Dollhouse'; started = false; }
$('start').onclick = () => { $('modal').classList.add('hidden'); started = true; toast('Find the archive cabinet. Continuity is selected.'); };
$('help').onclick = () => { $('modal').classList.remove('hidden'); started = false; };
$('reset').onclick = restart;
$('again').onclick = () => { restart(); started = true; };
$('return').onclick = returnPortal;
$('winReturn').onclick = () => { $('win').classList.add('hidden'); returnPortal(); };
$('interact').onclick = interact;
$('touchInteract').onclick = interact;
$('inspect').onclick = inspect;
$('drop').onclick = pick;
$('role').onchange = e => { state.selected = e.target.value; toast(`${state.selected.toUpperCase()} helper assigned.`); };
window.addEventListener('keydown', e => { if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key))
    e.preventDefault(); keys.add(e.key.toLowerCase()); if (e.repeat)
    return; if (e.key.toLowerCase() === 'e')
    interact(); if (e.key.toLowerCase() === 'i')
    inspect(); if (e.key.toLowerCase() === 'p')
    pick(); if (['1', '2', '3'].includes(e.key)) {
    state.selected = ['continuity', 'companion', 'moderation'][Number(e.key) - 1];
    $('role').value = state.selected;
    toast(`${state.selected} assigned.`);
} });
window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));
window.addEventListener('blur', () => { keys.clear(); moveTouch.clear(); });
for (const b of document.querySelectorAll('[data-move]')) {
    const dir = b.dataset.move;
    b.addEventListener('pointerdown', e => { e.preventDefault(); b.setPointerCapture(e.pointerId); moveTouch.add(dir); });
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture'])
        b.addEventListener(ev, () => moveTouch.delete(dir));
}
function fixedStep(dt) { if (!started || victory)
    return; let dx = 0, dz = 0; if (keys.has('a') || keys.has('arrowleft') || moveTouch.has('left'))
    dx--; if (keys.has('d') || keys.has('arrowright') || moveTouch.has('right'))
    dx++; if (keys.has('w') || keys.has('arrowup') || moveTouch.has('up'))
    dz--; if (keys.has('s') || keys.has('arrowdown') || moveTouch.has('down'))
    dz++; const len = Math.hypot(dx, dz) || 1; dx /= len; dz /= len; const speed = 3.7; player.position.x = THREE.MathUtils.clamp(player.position.x + dx * speed * dt, -6.35, 6.25); player.position.z = THREE.MathUtils.clamp(player.position.z + dz * speed * dt, -4.3, 4.5); if (dx || dz)
    player.rotation.y = Math.atan2(dx, dz); }
function animate(now) { const dt = Math.min((now - last) / 1000, .08); last = now; acc += dt; while (acc >= 1 / 60) {
    fixedStep(1 / 60);
    acc -= 1 / 60;
} elapsed += dt; if (!reduced) {
    for (let i = 0; i < helpers.length; i++) {
        const h = helpers[i];
        h.group.position.y = Math.sin(elapsed * 2 + i * 2) * .085;
        h.group.rotation.y = Math.sin(elapsed * .7 + i) * .2;
    }
    for (let i = 0; i < targets.length; i++) {
        targets[i].mesh.rotation.z = elapsed * .4;
        targets[i].mesh.position.y = .12 + Math.sin(elapsed * 2 + i) * .045;
    }
} for (const t of targets)
    t.mesh.visible = !state.completed[t.task]; if (state.carrying) {
    door.position.set(player.position.x, 1.2, player.position.z - .6);
    door.rotation.set(0, 0, 0);
    door.scale.set(.7, .7, .7);
}
else
    door.scale.set(1, 1, 1); const width = innerWidth, height = innerHeight; if (renderer.domElement.width !== Math.round(width * renderer.getPixelRatio()) || renderer.domElement.height !== Math.round(height * renderer.getPixelRatio())) {
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
} const desired = new THREE.Vector3(player.position.x * .25 + 10, 12.5, player.position.z * .16 + 15); camera.position.lerp(desired, reduced ? 1 : .025); camera.lookAt(player.position.x * .18, 1, player.position.z * .12); renderer.render(scene, camera); requestAnimationFrame(animate); }
updateUI();
requestAnimationFrame(animate);
window.addEventListener('pagehide', () => { renderer.dispose(); scene.traverse(o => { if (o instanceof THREE.Mesh) {
    o.geometry.dispose();
    const materials = Array.isArray(o.material) ? o.material : [o.material];
    for (const m of materials)
        m.dispose();
} }); });
