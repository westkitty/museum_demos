import { freshState, restoreCheckpoint, step, canActivate, safeRespawn, EXIT } from './logic.js';
import { createWorld } from './world.js';
import { Input } from './input.js';
const $ = (selector) => { const el = document.querySelector(selector); if (!el)
    throw new Error(`Missing interface element: ${selector}`); return el; };
const app = $('#app'), viewport = $('#viewport');
const startOverlay = $('#start-overlay'), pauseOverlay = $('#pause-overlay'), winOverlay = $('#win-overlay'), museumOverlay = $('#museum-overlay');
const transition = $('#transition-card'), statusNote = $('#status-note'), nearPrompt = $('#near-prompt');
const guideKicker = $('#guide-kicker'), guideMain = $('#guide-main');
const STORAGE = 'e14-world-failed-its-own-instructions/save/v1';
const MOTION = 'e14-world-failed-its-own-instructions/motion/v1';
const AUDIO = 'e14-world-failed-its-own-instructions/sound/v1';
const FIXED = 1 / 120;
let game = freshState();
let world = null;
let running = true, elapsed = 0, last = performance.now(), accumulator = 0, lastUi = -1;
let transitionTimer = 0, winDelay = -1;
let previousPause = false;
const input = new Input($('#touch-controls'));
const reduceDefault = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
const getLocal = (k) => { try {
    return localStorage.getItem(k);
}
catch {
    return null;
} };
const setLocal = (k, v) => { try {
    localStorage.setItem(k, v);
}
catch { /** private-mode storage may be unavailable */ } };
const delLocal = (k) => { try {
    localStorage.removeItem(k);
}
catch { /** no persistent storage */ } };
let reduced = getLocal(MOTION) === null ? reduceDefault : getLocal(MOTION) === '1';
let muted = getLocal(AUDIO) === '1';
let sound = null;
const canFocusWorld = () => { viewport.tabIndex = 0; viewport.focus({ preventScroll: true }); };
function sfx(kind) {
    if (muted)
        return;
    try {
        if (!sound)
            sound = new AudioContext();
        if (sound.state === 'suspended')
            void sound.resume();
        const now = sound.currentTime, tones = kind === 'win' ? [330, 440, 554, 660, 880] : kind === 'apply' ? [311, 392, 524] : kind === 'death' ? [330, 220, 165] : kind === 'jump' ? [360, 510] : [200];
        tones.forEach((freq, i) => {
            const osc = sound.createOscillator(), gain = sound.createGain();
            const t = now + i * (kind === 'win' ? .125 : .07);
            osc.type = kind === 'death' ? 'triangle' : kind === 'step' ? 'sine' : 'sine';
            osc.frequency.setValueAtTime(freq, t);
            if (kind === 'jump')
                osc.frequency.exponentialRampToValueAtTime(freq * 1.22, t + .10);
            gain.gain.setValueAtTime(.0001, t);
            gain.gain.exponentialRampToValueAtTime(kind === 'step' ? .016 : .05, t + .018);
            gain.gain.exponentialRampToValueAtTime(.0001, t + .15);
            osc.connect(gain);
            gain.connect(sound.destination);
            osc.start(t);
            osc.stop(t + .17);
        });
    }
    catch { /** audio is optional; visuals/gameplay stay available */ }
}
function persist() { const d = { version: 1, stage: game.stage, deaths: game.deaths }; setLocal(STORAGE, JSON.stringify(d)); }
function loadSave() {
    try {
        const raw = getLocal(STORAGE);
        if (!raw)
            return null;
        const v = JSON.parse(raw);
        if (v?.version !== 1 || !Number.isInteger(v.stage) || v.stage < 1 || v.stage > 3 || !Number.isSafeInteger(v.deaths) || v.deaths < 0)
            return null;
        return { stage: v.stage, deaths: v.deaths };
    }
    catch {
        return null;
    }
}
function syncContinue() { const el = $('#continue-button'); el.hidden = !loadSave(); }
function setInputEnabled() { input.setEnabled(game.started && !game.paused && !game.won && startOverlay.hidden && pauseOverlay.hidden && museumOverlay.hidden && winOverlay.hidden); }
function setModal(element, shown) { element.hidden = !shown; setInputEnabled(); }
function syncSettings() {
    app.classList.toggle('reduced', reduced);
    $('#motion-button').setAttribute('aria-pressed', String(reduced));
    $('#motion-button').setAttribute('aria-label', reduced ? 'Allow full motion' : 'Reduce motion');
    $('#motion-icon').textContent = reduced ? '◼' : '◌';
    $('#sound-button').setAttribute('aria-pressed', String(muted));
    $('#sound-button').setAttribute('aria-label', muted ? 'Enable sound' : 'Mute sound');
    $('#sound-icon').textContent = muted ? '♩' : '♫';
}
function restart(keepIntro = false) {
    game = freshState();
    world?.setStage(0, true);
    accumulator = 0;
    winDelay = -1;
    clearTimeout(transitionTimer);
    transition.hidden = true;
    delLocal(STORAGE);
    setModal(pauseOverlay, false);
    setModal(winOverlay, false);
    setModal(museumOverlay, false);
    game.started = !keepIntro;
    setModal(startOverlay, keepIntro);
    if (keepIntro) {
        syncContinue();
        $('#start-button').focus();
    }
    else {
        canFocusWorld();
        sfx('step');
    }
    setInputEnabled();
    lastUi = -1;
    updateUI();
}
function begin(resume = false) {
    const old = resume ? loadSave() : null;
    game = old ? restoreCheckpoint(old.stage, old.deaths) : freshState();
    game.started = true;
    if (!resume)
        delLocal(STORAGE);
    world?.setStage(game.stage, true);
    setModal(startOverlay, false);
    setModal(pauseOverlay, false);
    setModal(winOverlay, false);
    setModal(museumOverlay, false);
    setInputEnabled();
    canFocusWorld();
    sfx('apply');
    lastUi = -1;
    updateUI();
}
function pause() {
    if (!game.started || game.won || !pauseOverlay.hidden || !museumOverlay.hidden || !startOverlay.hidden)
        return;
    game.paused = true;
    setModal(pauseOverlay, true);
    $('#resume-button').focus();
    setInputEnabled();
}
function unpause() { game.paused = false; setModal(pauseOverlay, false); canFocusWorld(); setInputEnabled(); }
function openMuseum() {
    previousPause = game.paused;
    game.paused = true;
    setModal(pauseOverlay, false);
    setModal(winOverlay, false);
    setModal(museumOverlay, true);
    $('#return-request-button').textContent = 'DISPATCH MOCK RETURN ↗';
    $('#return-request-button').removeAttribute('disabled');
    $('#close-museum-button').focus();
    setInputEnabled();
}
function closeMuseum() {
    setModal(museumOverlay, false);
    game.paused = previousPause;
    if (game.won)
        setModal(winOverlay, true);
    else if (game.started && previousPause)
        setModal(pauseOverlay, true);
    else if (!game.started)
        setModal(startOverlay, true);
    else
        canFocusWorld();
    setInputEnabled();
}
function win() {
    winDelay = -1;
    $('#win-deaths').textContent = String(game.deaths).padStart(2, '0');
    setModal(winOverlay, true);
    $('#play-again-button').focus();
    setInputEnabled();
    delLocal(STORAGE);
}
const stageCopy = [
    { index: '01 / 03', title: 'AT DUSK', caption: 'The architecture has developed an evening habit.' },
    { index: '02 / 03', title: 'WIDE FRAMING', caption: 'A new, solid piece of the world has arrived.' },
    { index: '03 / 03', title: 'NO PEOPLE. NO TEXT.', caption: 'Everything forbidden exits. The clay stays.' }
];
function announceStage(stage) {
    if (stage < 1)
        return;
    const t = stageCopy[stage - 1];
    $('#transition-index').textContent = t.index;
    $('#transition-title').textContent = t.title;
    $('#transition-caption').textContent = t.caption;
    clearTimeout(transitionTimer);
    transition.hidden = true;
    void transition.offsetWidth;
    transition.hidden = false;
    transitionTimer = window.setTimeout(() => { transition.hidden = true; }, reduced ? 1000 : 2670);
    sfx('apply');
    persist();
}
function updateUI() {
    const stage = game.stage;
    app.classList.toggle('dusk', stage >= 1);
    app.classList.toggle('wide', stage >= 2);
    app.classList.toggle('clean', stage >= 3);
    app.classList.toggle('victorious', game.won);
    $('#scene-caption-text').textContent = [
        'I · THE PORCELAIN MORNING',
        'II · WHEN THE SKY REMEMBERS',
        'III · THE HORIZON UNFOLDS',
        'IV · AN IMPOSSIBLE PARADE'
    ][stage];
    for (const [id, on] of [['#rule-dusk', stage >= 1], ['#rule-wide', stage >= 2], ['#rule-people', stage >= 3], ['#rule-text', stage >= 3]]) {
        const el = $(id);
        el.classList.toggle('applied', on);
        el.querySelector('.block-symbol').textContent = on ? '✓' : '○';
    }
    $('#rules-counter').textContent = String(1 + (stage >= 1 ? 1 : 0) + (stage >= 2 ? 1 : 0) + (stage >= 3 ? 2 : 0)).padStart(2, '0');
    $('#checkpoint-tag').textContent = `CHECKPOINT ${String(stage).padStart(2, '0')} · ✧ ${game.deaths}`;
    $('#stage-progress').setAttribute('style', `height:${100 * stage / 3}%`);
    if (game.won) {
        guideKicker.textContent = 'THE FINAL REVISION';
        guideMain.textContent = 'Five rules obeyed. Very little dignity retained.';
    }
    else if (stage === 0) {
        guideKicker.textContent = '01 / FIND THE FIRST SWITCH';
        guideMain.textContent = 'Climb the crooked steps. Rewrite the sky.';
    }
    else if (stage === 1) {
        guideKicker.textContent = '02 / THE LIGHT HAS CHANGED';
        guideMain.textContent = 'Keep climbing. Expand the picture.';
    }
    else if (stage === 2) {
        guideKicker.textContent = '03 / THE WORLD GOT BIGGER';
        guideMain.textContent = 'Cross the bridge and remove the forbidden.';
    }
    else {
        guideKicker.textContent = 'FINALE / THE RULES ARE VALID';
        guideMain.textContent = 'Visit the ridiculous parade and open the exit.';
    }
    const switchNear = canActivate(game);
    const exitNear = stage === 3 && Math.abs(game.player.x - EXIT.x) < 4.25 && Math.abs(game.player.y - EXIT.footY) < 3.4;
    nearPrompt.hidden = !game.started || game.paused || game.won || !startOverlay.hidden || (!switchNear && !exitNear);
    if (!nearPrompt.hidden)
        $('#near-label').textContent = switchNear ? `Apply “${switchNear.label}”` : 'Enter the final arch';
    statusNote.hidden = game.messageTime <= 0 || game.paused || game.won;
    if (!statusNote.hidden)
        statusNote.textContent = game.message;
}
function simulateStep(ctrl) {
    if (!game.started || game.paused || game.won)
        return;
    const before = game.stage, dead = game.deaths, won = game.won;
    const wasGrounded = game.player.grounded;
    step(game, ctrl, FIXED);
    if (before !== game.stage) {
        world?.setStage(game.stage);
        announceStage(game.stage);
        lastUi = -1;
    }
    if (game.deaths !== dead) {
        sfx('death');
        persist();
    }
    if (wasGrounded && !game.player.grounded && game.player.vy > 5)
        sfx('jump');
    if (!won && game.won) {
        sfx('win');
        winDelay = reduced ? .8 : 2.5;
    }
}
function loop(now) {
    if (!running)
        return;
    const raw = Math.min(.065, Math.max(0, (now - last) / 1000));
    last = now;
    const playing = game.started && !game.paused && !game.won;
    if (playing) {
        accumulator += raw;
        const fresh = input.consume();
        let loops = 0;
        while (accumulator >= FIXED && loops < 9) {
            simulateStep(loops === 0 ? fresh : { ...input.snapshot(), jumpPressed: false, activate: false });
            accumulator -= FIXED;
            loops++;
        }
        if (loops === 9)
            accumulator = 0;
    }
    else
        accumulator = 0;
    if (winDelay >= 0) {
        winDelay -= raw;
        if (winDelay < 0)
            win();
    }
    elapsed += raw;
    world?.frame(game, raw, elapsed, reduced);
    if (lastUi < 0 || now - lastUi > 135) {
        lastUi = now;
        updateUI();
    }
    requestAnimationFrame(loop);
}
function showFatal(err) {
    const message = err instanceof Error ? err.message : String(err);
    $('#fatal-message').textContent = `The 3D renderer is unavailable in this browser. ${message}`;
    $('#fatal-overlay').hidden = false;
    console.error('E14 renderer could not start', err);
}
function bind() {
    $('#start-button').addEventListener('click', () => begin(false));
    $('#continue-button').addEventListener('click', () => begin(true));
    $('#pause-button').addEventListener('click', () => { if (!game.started || game.won)
        return; game.paused ? unpause() : pause(); });
    $('#resume-button').addEventListener('click', unpause);
    $('#retry-button').addEventListener('click', () => { safeRespawn(game); persist(); unpause(); });
    $('#restart-button').addEventListener('click', () => restart(false));
    $('#play-again-button').addEventListener('click', () => restart(false));
    $('#museum-button').addEventListener('click', openMuseum);
    $('#win-museum-button').addEventListener('click', openMuseum);
    $('#close-museum-button').addEventListener('click', closeMuseum);
    $('#intro-return-button').addEventListener('click', () => restart(true));
    $('#return-request-button').addEventListener('click', () => {
        const detail = { exhibit: 'E14', intent: 'return-to-museum', source: 'super-prompt-wonder', completed: game.won };
        window.dispatchEvent(new CustomEvent('museum:return', { detail, bubbles: false, cancelable: true }));
        $('#return-request-button').textContent = 'MOCK EVENT DISPATCHED ✓';
        ($('#return-request-button')).disabled = true;
    });
    $('#motion-button').addEventListener('click', () => { reduced = !reduced; setLocal(MOTION, reduced ? '1' : '0'); syncSettings(); });
    $('#sound-button').addEventListener('click', () => { muted = !muted; setLocal(AUDIO, muted ? '1' : '0'); syncSettings(); if (!muted)
        sfx('step'); });
    window.addEventListener('keydown', e => {
        if (e.code === 'Escape') {
            if (!museumOverlay.hidden) {
                closeMuseum();
                e.preventDefault();
                return;
            }
            if (!pauseOverlay.hidden) {
                unpause();
                e.preventDefault();
                return;
            }
            if (game.started && !game.won) {
                pause();
                e.preventDefault();
                return;
            }
        }
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden && game.started && !game.paused && !game.won)
        pause(); });
    window.addEventListener('beforeunload', () => { running = false; input.dispose(); world?.dispose(); if (sound)
        void sound.close(); });
}
try {
    bind();
    world = createWorld(viewport);
    syncSettings();
    syncContinue();
    updateUI();
    window.addEventListener('museum:return', (event) => { if (!(event instanceof CustomEvent))
        return; console.info('Mock museum return event dispatched', event.detail); });
    requestAnimationFrame(loop);
}
catch (error) {
    showFatal(error);
}
/** Read-only debug metadata for test automation; not a free-text prompt interface. */
Object.defineProperty(window, 'E14Test', { value: Object.freeze({
        getState: () => ({ stage: game.stage, x: game.player.x, y: game.player.y, grounded: game.player.grounded, checkpoint: game.checkpoint, deaths: game.deaths, won: game.won, paused: game.paused, started: game.started, reduced }),
        getWorld: () => ({ stage: world?.stage, hasWebGL: !!world, canvasWidth: world?.canvas.width, canvasHeight: world?.canvas.height })
    }), enumerable: false, configurable: false });
