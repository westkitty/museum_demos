import ts from 'typescript';
import { readdirSync, readFileSync } from 'node:fs';
import { join, relative } from 'node:path';
let errors=0;
function inspect(dir){for(const f of readdirSync(dir,{withFileTypes:true})){
  const path=join(dir,f.name);if(f.isDirectory()){inspect(path);continue;}
  if(!f.name.endsWith('.ts'))continue;
  const source=readFileSync(path,'utf8');const output=ts.transpileModule(source,{fileName:path,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}});
  for(const d of output.diagnostics??[]){if(d.category===ts.DiagnosticCategory.Error){errors++;console.error(relative('.',path),ts.flattenDiagnosticMessageText(d.messageText,' '));}}
  if(!output.outputText)throw new Error('No JS output for '+path);
  console.log('Parsed',relative('.',path));
}}
inspect('./src');if(errors)process.exit(1);console.log('TypeScript syntax OK');
