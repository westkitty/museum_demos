import { validExplorer } from './expedition.js';
export function createPortableExpedition(simulation, explorer) {
    if (!validExplorer(explorer))
        throw new Error('Invalid exploration camera');
    return { format: 'INFINITUM_EXPEDITION', version: 2,
        capturedAt: new Date().toISOString(), simulation, explorer };
}
export function inspectPortableExpedition(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const value = raw;
    if (value.schema === 1)
        return { simulation: value, explorer: null };
    if (value.format !== 'INFINITUM_EXPEDITION' || value.version !== 2 ||
        !value.simulation || typeof value.simulation !== 'object' || !validExplorer(value.explorer))
        return null;
    return { simulation: value.simulation, explorer: value.explorer };
}
