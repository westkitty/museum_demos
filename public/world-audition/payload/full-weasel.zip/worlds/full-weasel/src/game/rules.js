export const MECHANISMS = ['crank', 'catch', 'lever'];
export const SAVE_KEY = 'full-weasel-64-save-v1';
export function freshProgress() {
    return {
        version: 1,
        engaged: { crank: false, catch: false, lever: false },
        rewards: { crank: false, catch: false, lever: false },
        won: false
    };
}
export function engaged(progress, mechanism) {
    if (progress.engaged[mechanism])
        return progress;
    return {
        ...progress,
        engaged: { ...progress.engaged, [mechanism]: true }
    };
}
export function collect(progress, mechanism) {
    if (!progress.engaged[mechanism] || progress.rewards[mechanism])
        return progress;
    return {
        ...progress,
        rewards: { ...progress.rewards, [mechanism]: true }
    };
}
export function rewardCount(progress) {
    return MECHANISMS.filter((key) => progress.rewards[key]).length;
}
export function throneUnlocked(progress) {
    return rewardCount(progress) === MECHANISMS.length;
}
export function partyMeter(progress) {
    return progress.won ? 100 : rewardCount(progress) * 25;
}
export function finish(progress) {
    if (!throneUnlocked(progress))
        return progress;
    if (progress.won)
        return progress;
    return { ...progress, won: true };
}
/** Invalid or old saves fail closed; no unearned tokens or win state. */
export function decodeProgress(raw) {
    if (!raw || typeof raw !== 'object')
        return freshProgress();
    const saved = raw;
    if (saved.version !== 1 || !saved.engaged || !saved.rewards)
        return freshProgress();
    const result = freshProgress();
    for (const key of MECHANISMS) {
        result.engaged[key] = saved.engaged[key] === true;
        result.rewards[key] = result.engaged[key] && saved.rewards[key] === true;
    }
    result.won = saved.won === true && throneUnlocked(result);
    return result;
}
export function parseProgress(value) {
    if (!value)
        return freshProgress();
    try {
        return decodeProgress(JSON.parse(value));
    }
    catch {
        return freshProgress();
    }
}
