import * as THREE from 'three';
/** Fixed-capacity, local GPU particle and ripple feedback; never creates per-event meshes. */
export class VisualFX {
    sparks = [];
    ripples = [];
    maxSparks = 104;
    maxRipples = 8;
    geo = new THREE.OctahedronGeometry(.24, 0);
    rippleGeo = new THREE.TorusGeometry(1, .052, 5, 36);
    sparkMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .92, depthWrite: false, toneMapped: false });
    rippleMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .78, depthWrite: false, toneMapped: false });
    sparkMesh = new THREE.InstancedMesh(this.geo, this.sparkMat, this.maxSparks);
    rippleMesh = new THREE.InstancedMesh(this.rippleGeo, this.rippleMat, this.maxRipples);
    dummy = new THREE.Object3D();
    palette = {
        jump: [0xffe3ab, 0xffbb78, 0xffffff], land: [0xffe2af, 0xf7b8d9, 0xffffff],
        spring: [0x7ef3d6, 0xd8ffe9, 0xffc3cf], mechanism: [0xf9d681, 0xffffff, 0x80e6e6],
        reward: [0xffd774, 0xfff6c5, 0xf5b0d7], finale: [0xffd47d, 0xfc8ebf, 0x7ae4d4, 0xffffff],
        respawn: [0x99dbf3, 0xffe0b0, 0xffffff]
    };
    sequence = 1;
    constructor(scene) {
        this.sparkMesh.count = 0;
        this.rippleMesh.count = 0;
        this.sparkMesh.frustumCulled = false;
        this.rippleMesh.frustumCulled = false;
        this.sparkMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.rippleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.sparkMesh.renderOrder = 12;
        this.rippleMesh.renderOrder = 11;
        scene.add(this.sparkMesh, this.rippleMesh);
    }
    burst(at, kind, quality, reducedMotion) {
        const big = kind === 'finale' || kind === 'reward';
        const amount = reducedMotion ? 0 : quality === 'low' ? (big ? 9 : 4) : quality === 'medium' ? (big ? 19 : 8) : (big ? 36 : 13);
        if (kind !== 'jump' && !reducedMotion && this.ripples.length < this.maxRipples) {
            this.ripples.push({ pos: at.clone(), age: 0, life: big ? .9 : .52, size: big ? 1.4 : .8, color: new THREE.Color(this.palette[kind][0]) });
        }
        for (let i = 0; i < amount; i++) {
            if (this.sparks.length >= this.maxSparks)
                this.sparks.shift();
            const angle = i * 2.39996 + this.sequence * .25;
            const spread = big ? 4.4 : kind === 'spring' ? 3.2 : 2.0;
            const energy = .42 + ((i * 37 + this.sequence * 7) % 19) / 21;
            const horizontal = spread * energy;
            this.sparks.push({
                pos: at.clone().add(new THREE.Vector3(Math.sin(angle) * .28, .2, Math.cos(angle) * .28)),
                vel: new THREE.Vector3(Math.sin(angle) * horizontal, (big ? 3.1 : 1.5) + energy * (big ? 3.6 : 2.6), Math.cos(angle) * horizontal),
                age: 0, life: .4 + energy * (big ? .94 : .5), size: (big ? .18 : .11) + energy * .14,
                color: new THREE.Color(this.palette[kind][(i + this.sequence) % this.palette[kind].length])
            });
        }
        this.sequence++;
    }
    update(dt, quality, reducedMotion) {
        if (reducedMotion) {
            this.sparks.length = 0;
            this.ripples.length = 0;
            this.sparkMesh.count = 0;
            this.rippleMesh.count = 0;
            return;
        }
        const activeCap = quality === 'high' ? this.maxSparks : quality === 'medium' ? 56 : 20;
        while (this.sparks.length > activeCap)
            this.sparks.shift();
        let shown = 0;
        for (let i = this.sparks.length - 1; i >= 0; i--) {
            const p = this.sparks[i];
            p.age += dt;
            if (p.age >= p.life) {
                this.sparks.splice(i, 1);
                continue;
            }
            p.vel.y -= 7.6 * dt;
            p.pos.addScaledVector(p.vel, dt);
            const fade = 1 - p.age / p.life;
            this.dummy.position.copy(p.pos);
            this.dummy.rotation.set(p.age * 4.3 + i, p.age * 2.8 + i * .43, p.age * 3.2);
            this.dummy.scale.setScalar(p.size * Math.max(.045, fade));
            this.dummy.updateMatrix();
            this.sparkMesh.setMatrixAt(shown, this.dummy.matrix);
            this.sparkMesh.setColorAt(shown, p.color);
            shown++;
        }
        this.sparkMesh.count = shown;
        if (shown) {
            this.sparkMesh.instanceMatrix.needsUpdate = true;
            if (this.sparkMesh.instanceColor)
                this.sparkMesh.instanceColor.needsUpdate = true;
        }
        let ripples = 0;
        for (let i = this.ripples.length - 1; i >= 0; i--) {
            const p = this.ripples[i];
            p.age += dt;
            if (p.age >= p.life) {
                this.ripples.splice(i, 1);
                continue;
            }
            this.dummy.position.copy(p.pos);
            this.dummy.rotation.set(-Math.PI / 2, 0, 0);
            const radius = p.size * (.55 + 1.35 * (p.age / p.life));
            const fade = 1 - p.age / p.life;
            this.dummy.scale.set(radius * fade, radius * fade, radius * fade);
            this.dummy.updateMatrix();
            this.rippleMesh.setMatrixAt(ripples, this.dummy.matrix);
            this.rippleMesh.setColorAt(ripples, p.color);
            ripples++;
        }
        this.rippleMesh.count = ripples;
        if (ripples) {
            this.rippleMesh.instanceMatrix.needsUpdate = true;
            if (this.rippleMesh.instanceColor)
                this.rippleMesh.instanceColor.needsUpdate = true;
        }
    }
    reset() { this.sparks.length = 0; this.ripples.length = 0; this.sparkMesh.count = 0; this.rippleMesh.count = 0; }
    dispose() {
        this.reset();
        this.sparkMesh.parent?.remove(this.sparkMesh);
        this.rippleMesh.parent?.remove(this.rippleMesh);
        this.sparkMesh.dispose();
        this.rippleMesh.dispose();
        this.geo.dispose();
        this.rippleGeo.dispose();
        this.sparkMat.dispose();
        this.rippleMat.dispose();
    }
}
