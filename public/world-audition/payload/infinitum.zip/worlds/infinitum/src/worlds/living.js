import { VillageLife } from './villagers.js';
import { WatershedVisual } from './hydrology.js';
import { gravityAligned, heartIrrigation, causalStage } from '../core/simulation.js';
import * as THREE from 'three';
import { extraDroplets, isNight, lightAligned, tideAt, TERRAIN_ZONES, treeGrowth, ruinsComplete } from '../core/state.js';
import { TAU, clamp, heightAt, makeTerrain, material, mulberry32, noise2, riverX, smooth, lerp, sphere, cylinder, tube, updateTerrain, disposeScene } from '../core/math.js';
import { EnvironmentRig, labelObject, PortalDrop, waterMaterial, makeDust, addArch } from './shared.js';
import { authoredSurface } from './asset-materials.js';
import { ART, broadleafCrown, coniferCrown, contactShadows, gableRoof, grainTexture, leafBlade, mountainGeometry, reliefTexture, softGlow, stoneSurface } from './art.js';
import { CinematicVistas } from './cinematic-vistas.js';
import { windDriven } from './wind.js';
const TREE_X = 17, TREE_Z = -2;
const RUIN_TARGETS = [[28, 43], [32, 43], [30, 47]];
const LIVING_WIDTH = 240;
const WATER_COLOR = 0x3c8c9d;
function paintTerrain(geometry, state) {
    const p = geometry.attributes.position;
    const n = geometry.attributes.normal;
    let c = geometry.getAttribute('color');
    if (!c) {
        c = new THREE.BufferAttribute(new Float32Array(p.count * 3), 3);
        geometry.setAttribute('color', c);
    }
    const forest = new THREE.Color(0x526854), stone = new THREE.Color(0x717573), sand = new THREE.Color(0xb4a180), snow = new THREE.Color(0xb9d0d1), deep = new THREE.Color(0x324e4e);
    const target = new THREE.Color();
    for (let i = 0; i < p.count; i++) {
        const h = p.getY(i), z = p.getZ(i), steep = 1 - n.getY(i);
        target.copy(forest).lerp(deep, clamp(.5 + noise2(p.getX(i), z) * .4, 0, 1) * .48);
        target.lerp(stone, smooth(.16, .53, steep) * .84);
        target.lerp(snow, smooth(39, 62, h) * .88);
        target.lerp(sand, smooth(42, 72, z) * .92);
        if (h < 0)
            target.lerp(deep, .15);
        c.setXYZ(i, target.r, target.g, target.b);
    }
    c.needsUpdate = true;
    if (state.season === 'Autumn' || state.season === 'Winter' || state.season === 'Spring') {
        const tint = new THREE.Color(state.season === 'Autumn' ? 0x9b724f : state.season === 'Winter' ? 0xb7ccce : 0x7cad79);
        const amount = state.season === 'Winter' ? .4 : state.season === 'Autumn' ? .23 : .13;
        for (let i = 0; i < p.count; i++) {
            target.setRGB(c.getX(i), c.getY(i), c.getZ(i)).lerp(tint, amount);
            c.setXYZ(i, target.r, target.g, target.b);
        }
        c.needsUpdate = true;
    }
}
function ribbon(points, width) {
    const n = points.length;
    const pos = new Float32Array(n * 2 * 3), uv = new Float32Array(n * 2 * 2), indices = [];
    for (let i = 0; i < n; i++) {
        const prev = points[Math.max(0, i - 1)], next = points[Math.min(n - 1, i + 1)];
        const tangent = next.clone().sub(prev).setY(0).normalize();
        const normal = new THREE.Vector3(-tangent.z, 0, tangent.x);
        for (let s = 0; s < 2; s++) {
            const side = s === 0 ? -1 : 1, v = points[i].clone().addScaledVector(normal, width * side * .5);
            pos.set([v.x, v.y, v.z], (i * 2 + s) * 3);
            uv.set([s, i / (n - 1) * 16], (i * 2 + s) * 2);
        }
        if (i < n - 1) {
            const a = i * 2;
            indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
        }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
}
export class LivingWorld {
    id = 1;
    scene = new THREE.Scene();
    spawn = { position: new THREE.Vector3(57, 51, 85), target: new THREE.Vector3(-5, 15, -20) };
    portal = new THREE.Vector3();
    exitPortal = new THREE.Vector3();
    returnIris;
    citizens;
    watershed;
    gravityStones = [];
    gravityLens;
    inspectionObjects = [];
    rig;
    vistas;
    windDrivers = [];
    terrain;
    drop;
    mainTree;
    forest = [];
    waterMats = [];
    riverGroup = new THREE.Group();
    seedGroup = new THREE.Group();
    seedVisuals = new Map();
    markerGroup = new THREE.Group();
    ruinGroup = new THREE.Group();
    ruinParts = [];
    targetRings = [];
    moonObject;
    coastline;
    tideLine;
    fireflies;
    birds = [];
    deer = [];
    prisms = [];
    beams = new THREE.Group();
    beamMaterials = [];
    ruinBeacon;
    extraDrops = [];
    lastExtraDrops = -1;
    snowPatches = null;
    snowAccumulation = 0;
    terrainRings = [];
    beamBaseLengths = [];
    beamPoints = [];
    centralLeaves;
    villageWindows;
    villageLights = [];
    plantAgeLast = -1;
    lastTerrain = [0, 0, 0];
    lastRiverCount = 0;
    lastSeedCount = 0;
    lastMarkers = '';
    lastRuinCount = '';
    dust;
    birdVel = [];
    deerVel = [];
    detailRocks = null;
    waterfallSpray = null;
    cascadeMaterial = null;
    waterfallLight = null;
    storyLanterns = [];
    constructor(s, previewTexture) {
        this.rig = new EnvironmentRig(this.scene, 1, s.quality);
        this.vistas = new CinematicVistas(this.scene, 1, s);
        const earth = grainTexture(418);
        earth.repeat.set(48, 48);
        const earthNormal = s.quality === 'low' ? null : reliefTexture(earth);
        this.terrain = new THREE.Mesh(makeTerrain(s, LIVING_WIDTH, s.quality === 'low' ? 88 : 136), new THREE.MeshStandardMaterial({ vertexColors: true, map: earth, normalMap: earthNormal, normalScale: new THREE.Vector2(.2, .2), metalness: .015, roughness: .94, flatShading: false }));
        paintTerrain(this.terrain.geometry, s);
        this.terrain.receiveShadow = true;
        labelObject(this.terrain, 'The living earth');
        this.scene.add(this.terrain);
        TERRAIN_ZONES.forEach((zone, i) => {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(zone.radius * .72, .12, 7, 68), new THREE.MeshBasicMaterial({ color: i === 1 ? 0x9dcebb : 0xabc3a4, transparent: true, opacity: .46, depthWrite: false }));
            ring.rotation.x = Math.PI / 2;
            ring.position.set(zone.x, heightAt(zone.x, zone.z, s) + .33, zone.z);
            labelObject(ring, `${zone.name} · Sculpting zone`, 'sculpt');
            this.terrainRings.push(ring);
            this.scene.add(ring);
        });
        this.riverGroup.name = 'Waterways';
        this.scene.add(this.riverGroup);
        const riverPoints = [];
        for (let i = 0; i <= 100; i++) {
            const z = -74 + i * 1.7, x = riverX(z);
            riverPoints.push(new THREE.Vector3(x, heightAt(x, z, s) + .18, z));
        }
        const riverMaterial = waterMaterial(WATER_COLOR, .91);
        this.waterMats.push(riverMaterial);
        const mainRiver = new THREE.Mesh(ribbon(riverPoints, 5), riverMaterial);
        mainRiver.name = 'The Silvercourse';
        labelObject(mainRiver, 'THE SILVERCOURSE · Water changes the Heart Tree');
        mainRiver.userData.clueId = 'water-law';
        this.inspectionObjects.push(mainRiver);
        this.riverGroup.add(mainRiver);
        // Waterfall is situated where steep northern terrain descends into the valley.
        const fallX = riverX(-39), topY = heightAt(fallX, -49, s) + 3, bottomY = heightAt(fallX, -26, s) + .1;
        const waterfall = new THREE.Mesh(new THREE.PlaneGeometry(9, Math.abs(topY - bottomY), 26, 40), waterMaterial(0xa5dfe0, .67));
        waterfall.position.set(fallX, (topY + bottomY) / 2, -37);
        waterfall.rotation.y = .16;
        // The cascade uses a separate flowing curtain, with fine vertical highlights and a broken edge.
        const cascade = new THREE.ShaderMaterial({
            uniforms: { uTime: { value: 0 }, uOpacity: { value: .89 } }, transparent: true, depthWrite: false, side: THREE.DoubleSide,
            vertexShader: `varying vec2 vUv;void main(){vUv=uv;vec3 p=position;p.z+=sin(uv.y*34.+uv.x*19.)*.07;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,
            fragmentShader: `uniform float uTime,uOpacity;varying vec2 vUv;
        void main(){float flow=sin(vUv.x*43.+sin(vUv.x*11.)*2.+vUv.y*48.-uTime*5.);
          float thread=pow(.5+.5*sin(vUv.x*81.+sin(vUv.y*8.-uTime)*2.),8.);
          float foam=pow(.5+.5*sin(vUv.y*68.-uTime*8.+vUv.x*11.),5.);
          vec3 color=mix(vec3(.11,.35,.44),vec3(.66,.88,.88),.45+.24*flow+.23*thread+.12*foam);
          float fade=smoothstep(0.,.1,vUv.y)*smoothstep(.0,.18,1.-vUv.y);
          gl_FragColor=vec4(color,uOpacity*(.57+.43*thread)*fade);}`
        });
        waterfall.material.dispose();
        waterfall.material = cascade;
        this.cascadeMaterial = cascade;
        waterfall.renderOrder = 2;
        this.scene.add(waterfall);
        const cascadeGlow = new THREE.PointLight(0x8abdc6, 2.4, 48);
        cascadeGlow.position.set(fallX, bottomY + 9, -34);
        this.scene.add(cascadeGlow);
        const sprayCount = s.quality === 'low' ? 100 : s.quality === 'high' ? 510 : 280;
        const sprayPos = new Float32Array(sprayCount * 3), sprayRng = mulberry32(352);
        for (let i = 0; i < sprayCount; i++) {
            sprayPos[i * 3] = fallX + (sprayRng() - .5) * 13;
            sprayPos[i * 3 + 1] = bottomY + sprayRng() * Math.max(3, topY - bottomY);
            sprayPos[i * 3 + 2] = -37 + (sprayRng() - .5) * 6;
        }
        const sprayGeo = new THREE.BufferGeometry();
        sprayGeo.setAttribute('position', new THREE.BufferAttribute(sprayPos, 3));
        this.waterfallSpray = new THREE.Points(sprayGeo, new THREE.PointsMaterial({ color: 0xcdece6, size: .26, transparent: true, opacity: .52, depthWrite: false, blending: THREE.AdditiveBlending }));
        this.waterfallSpray.frustumCulled = false;
        this.waterfallSpray.userData.fallLow = Math.min(bottomY, topY);
        this.waterfallSpray.userData.fallHigh = Math.max(bottomY + 1, topY);
        this.scene.add(this.waterfallSpray);
        this.waterfallLight = softGlow(0xbce6e1, 18, .25);
        this.waterfallLight.position.set(fallX, bottomY + 2, -33);
        this.scene.add(this.waterfallLight);
        // Ocean surface and exposed shore respond continuously to the moon.
        this.coastline = new THREE.Mesh(new THREE.PlaneGeometry(245, 100, 36, 26), waterMaterial(0x2c6575, .91));
        this.coastline.rotation.x = -Math.PI / 2;
        this.coastline.position.set(0, -1, 94);
        this.waterMats.push(this.coastline.material);
        this.scene.add(this.coastline);
        this.tideLine = new THREE.Mesh(new THREE.PlaneGeometry(245, 4), new THREE.MeshBasicMaterial({ color: 0xc1d8cb, transparent: true, opacity: .23, depthWrite: false }));
        this.tideLine.rotation.x = -Math.PI / 2;
        this.tideLine.position.set(0, -.2, 69);
        this.scene.add(this.tideLine);
        this.createForest(s);
        this.createLandscapeDetails(s);
        this.createSnowPatches(s);
        this.createMountains(s);
        this.createVillage(s);
        this.citizens = new VillageLife(this.scene, s, s.quality, this.inspectionObjects);
        this.watershed = new WatershedVisual(this.scene, s.quality);
        this.createRuins(s);
        this.createPrisms(s);
        this.mainTree = this.createHeartTree(s);
        this.scene.add(this.seedGroup, this.markerGroup);
        this.drop = new PortalDrop(previewTexture, 1.15, 'THE SECOND THRESHOLD · Enter the celestial garden');
        this.portal.set(TREE_X + 8.8, heightAt(TREE_X, TREE_Z, s) + 23, TREE_Z - 3.9);
        this.exitPortal.set(TREE_X - 7, heightAt(TREE_X, TREE_Z, s) + 13, TREE_Z + 9);
        this.drop.group.position.copy(this.portal);
        this.scene.add(this.drop.group);
        // Facing the parent universe: a thin suspended lens near the Heart Tree, not a menu portal.
        this.returnIris = new THREE.Mesh(new THREE.TorusGeometry(2.2, .085, 8, 56), new THREE.MeshStandardMaterial({ color: 0x9dcfc4, emissive: 0x3a8e88, emissiveIntensity: .9, metalness: .8, roughness: .16 }));
        this.returnIris.position.copy(this.exitPortal);
        this.returnIris.rotation.y = Math.PI * .31;
        labelObject(this.returnIris, 'THE RETURN MEMBRANE · The first droplet seen from within', 'portal');
        this.scene.add(this.returnIris);
        this.inspectionObjects.push(this.returnIris);
        this.inspectionObjects.push(this.drop.group, this.drop.glass, this.drop.shell);
        // Supporting leaf and twig make the gateway visibly botanical.
        const twig = tube([new THREE.Vector3(TREE_X + 4, heightAt(TREE_X, TREE_Z, s) + 22, TREE_Z), new THREE.Vector3(TREE_X + 8, heightAt(TREE_X, TREE_Z, s) + 23.6, TREE_Z - 3)], .16, 0x5b6f57, 24);
        this.scene.add(twig);
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(2.9, 14, 8), material(0x5d936f, .7, .08));
        leaf.scale.set(1, .08, .47);
        leaf.rotation.y = .8;
        leaf.position.set(this.portal.x, this.portal.y - 1.3, this.portal.z + .6);
        this.scene.add(leaf);
        this.moonObject = new THREE.Group();
        const moon = sphere(4.1, 0xe6ebeb, 32);
        moon.material = new THREE.MeshStandardMaterial({ color: 0xb3cddd, metalness: .08, roughness: .9, emissive: 0x627b91, emissiveIntensity: .15 });
        this.moonObject.add(moon);
        labelObject(moon, 'THE TIDAL MOON · Drag to change the tide', 'moon');
        this.inspectionObjects.push(moon);
        this.scene.add(this.moonObject);
        this.createWildlife(s);
        const stoneMat = new THREE.MeshStandardMaterial({ color: 0x748985, metalness: .28, roughness: .59, emissive: 0x123f45, emissiveIntensity: .4 });
        for (let i = 0; i < 5; i++) {
            const group = new THREE.Group();
            const stone = new THREE.Mesh(new THREE.BoxGeometry(3.6, .65, 3.4), stoneMat);
            stone.rotation.y = i * .19;
            group.add(stone);
            const glyph = new THREE.Mesh(new THREE.TorusGeometry(.68, .055, 5, 28), new THREE.MeshBasicMaterial({ color: 0xa5e0cf, transparent: true, opacity: .6 }));
            glyph.rotation.x = Math.PI / 2;
            glyph.position.y = .36;
            group.add(glyph);
            group.position.set(5 + i * 3.2, heightAt(12, -17, s) + 9 + i * 3.2, -13 - i * 4.4);
            group.userData.feature = 'gravity-bridge';
            this.scene.add(group);
            this.gravityStones.push(group);
        }
        this.gravityLens = new THREE.Mesh(new THREE.IcosahedronGeometry(1.3, 1), new THREE.MeshStandardMaterial({ color: 0xe9e2c2, emissive: 0x7bb8af, emissiveIntensity: 1.5, metalness: .5, roughness: .22 }));
        this.gravityLens.position.set(20, heightAt(20, -33, s) + 31, -34);
        labelObject(this.gravityLens, 'THE GRAVITY RELIQUARY · The outer world moves these stones');
        this.gravityLens.userData.clueId = 'gravity-reliquary';
        this.scene.add(this.gravityLens);
        this.inspectionObjects.push(this.gravityLens);
        this.createFireflies(s);
        this.dust = makeDust(this.scene, s.quality === 'low' ? 350 : 1100, new THREE.Vector3(200, 100, 190), 987, 0xf2d9ae);
        this.sync(s);
    }
    createForest(s) {
        const rng = mulberry32(4932);
        const firs = [];
        const broad = [];
        for (let i = 0; i < (s.quality === 'low' ? 650 : 1550); i++) {
            const x = (rng() - .5) * 220, z = (rng() - .5) * 160 - 3;
            if (Math.abs(x - riverX(z)) < 7 || Math.hypot(x - TREE_X, z - TREE_Z) < 15 ||
                Math.hypot(x + 29, z - 28) < 16 || Math.hypot(x - 30, z - 44) < 16 || z > 56 || z < -65)
                continue;
            const size = .58 + rng() * 1.12;
            (z < -10 || rng() > .34 ? firs : broad).push({ x, z, size, yaw: rng() * TAU });
        }
        const makeGroup = (seeds, canopy, color) => {
            const trunkGeo = new THREE.CylinderGeometry(.22, .36, 3.6, 5);
            trunkGeo.translate(0, 1.9, 0);
            // Crown geometry is authored at trunk height; it must not be translated again.
            const trunk = new THREE.InstancedMesh(trunkGeo, material(0x544639), seeds.length);
            const crownMat = new THREE.MeshStandardMaterial({ color, vertexColors: canopy.getAttribute('color') !== undefined, roughness: .88, side: THREE.DoubleSide });
            if (s.quality !== 'low')
                this.windDrivers.push(windDriven(crownMat, 12, .48));
            const crowns = new THREE.InstancedMesh(canopy, crownMat, seeds.length);
            const tint = new THREE.Color(), rngTint = mulberry32(seeds.length * 13 + color);
            for (let j = 0; j < seeds.length; j++) {
                tint.setHSL(color === 0x284c44 ? .44 : .26, .12 + .08 * rngTint(), .76 + .19 * rngTint());
                crowns.setColorAt(j, tint);
            }
            if (crowns.instanceColor)
                crowns.instanceColor.needsUpdate = true;
            trunk.castShadow = false;
            crowns.castShadow = false;
            if (s.quality !== 'low')
                crowns.userData.feature = 'wind-canopy';
            const set = { count: seeds.length, seeds, trunks: trunk, crowns };
            this.forest.push(set);
            this.scene.add(trunk, crowns);
        };
        makeGroup(firs, coniferCrown(), 0x507466);
        makeGroup(broad, broadleafCrown(998), 0x73916b);
        this.repositionForest(s);
        const meadowGrass = [];
        for (let j = 0; j < (s.quality === 'low' ? 800 : 2500); j++) {
            const x = (rng() - .5) * 220, z = (rng() - .5) * 150 + 8;
            if (z > 67 || Math.abs(x - riverX(z)) < 4)
                continue;
            meadowGrass.push({ x, y: heightAt(x, z, s) + .2, z, scale: .3 + rng() * .6, ry: rng() * TAU });
        }
        const grassGeo = new THREE.ConeGeometry(.18, 1.9, 3);
        grassGeo.translate(0, .9, 0);
        const grassMat = new THREE.MeshStandardMaterial({ color: 0x6c8962, roughness: 1, side: THREE.DoubleSide });
        if (s.quality !== 'low')
            this.windDrivers.push(windDriven(grassMat, 2.3, .30));
        const grassMesh = new THREE.InstancedMesh(grassGeo, grassMat, meadowGrass.length);
        const obj = new THREE.Object3D();
        meadowGrass.forEach((p, i) => { obj.position.set(p.x, p.y, p.z); obj.scale.setScalar(p.scale); obj.rotation.y = p.ry; obj.updateMatrix(); grassMesh.setMatrixAt(i, obj.matrix); });
        grassMesh.instanceMatrix.needsUpdate = true;
        grassMesh.userData.grassPlaces = meadowGrass;
        if (s.quality !== 'low')
            grassMesh.userData.feature = 'wind-grass';
        this.scene.add(grassMesh);
        // Sparse patches of broad-leaved understory in the glades: cheap real geometry, not sprites.
        const fernGeo = leafBlade();
        fernGeo.scale(.72, .72, .72);
        const fernMat = new THREE.MeshStandardMaterial({ color: 0x709779, roughness: .85, side: THREE.DoubleSide });
        if (s.quality !== 'low')
            this.windDrivers.push(windDriven(fernMat, 1.8, .20));
        const fernPlaces = meadowGrass.filter((_, i) => i % 5 === 0), fern = new THREE.InstancedMesh(fernGeo, fernMat, fernPlaces.length);
        const fernObj = new THREE.Object3D();
        fernPlaces.forEach((p, i) => {
            fernObj.position.set(p.x, p.y, p.z);
            fernObj.scale.setScalar(.64 + p.scale * .9);
            fernObj.rotation.set(-.35, p.ry, .08);
            fernObj.updateMatrix();
            fern.setMatrixAt(i, fernObj.matrix);
        });
        fern.instanceMatrix.needsUpdate = true;
        fern.computeBoundingSphere();
        fern.userData.grassPlaces = fernPlaces;
        fern.userData.decorType = 'fern';
        this.scene.add(fern);
    }
    repositionForest(s) {
        const t = new THREE.Object3D();
        for (const set of this.forest) {
            for (let i = 0; i < set.count; i++) {
                const p = set.seeds[i];
                t.position.set(p.x, heightAt(p.x, p.z, s), p.z);
                t.rotation.y = p.yaw;
                t.scale.setScalar(p.size);
                t.updateMatrix();
                set.trunks.setMatrixAt(i, t.matrix);
                set.crowns.setMatrixAt(i, t.matrix);
            }
            set.trunks.instanceMatrix.needsUpdate = true;
            set.crowns.instanceMatrix.needsUpdate = true;
            set.trunks.computeBoundingSphere();
            set.crowns.computeBoundingSphere();
        }
        this.scene.traverse(o => {
            if (!o.userData.grassPlaces)
                return;
            const mesh = o;
            const places = o.userData.grassPlaces;
            const fern = mesh.userData.decorType === 'fern';
            places.forEach((p, i) => {
                t.position.set(p.x, heightAt(p.x, p.z, s) + .2, p.z);
                t.scale.setScalar(fern ? .64 + p.scale * .9 : p.scale);
                t.rotation.set(fern ? -.35 : 0, p.ry, fern ? .08 : 0);
                t.updateMatrix();
                mesh.setMatrixAt(i, t.matrix);
            });
            mesh.instanceMatrix.needsUpdate = true;
            mesh.computeBoundingSphere();
        });
    }
    createSnowPatches(s) {
        const rng = mulberry32(2741), pts = [];
        for (let j = 0; j < (s.quality === 'low' ? 90 : 280); j++) {
            const x = (rng() - .5) * 225, z = (rng() - .5) * 175;
            if (z > 70 || Math.abs(x - riverX(z)) < 5)
                continue;
            pts.push({ x, z, size: 1.0 + rng() * 2.4, angle: rng() * TAU });
        }
        const g = new THREE.CircleGeometry(1, 9);
        g.rotateX(-Math.PI / 2);
        const mat = new THREE.MeshBasicMaterial({ color: 0xe9f1e8, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide });
        const mesh = new THREE.InstancedMesh(g, mat, pts.length), obj = new THREE.Object3D();
        for (let i = 0; i < pts.length; i++) {
            const p = pts[i];
            obj.position.set(p.x, heightAt(p.x, p.z, s) + .3, p.z);
            obj.rotation.y = p.angle;
            obj.scale.setScalar(p.size);
            obj.updateMatrix();
            mesh.setMatrixAt(i, obj.matrix);
        }
        mesh.instanceMatrix.needsUpdate = true;
        mesh.userData.snowPlaces = pts;
        this.scene.add(mesh);
        this.snowPatches = mesh;
    }
    createLandscapeDetails(s) {
        const rng = mulberry32(8172), stones = [];
        for (let i = 0; i < (s.quality === 'low' ? 180 : 540); i++) {
            const x = (rng() - .5) * 225, z = (rng() - .5) * 185;
            if (Math.hypot(x - TREE_X, z - TREE_Z) < 7 || Math.hypot(x + 29, z - 28) < 12)
                continue;
            stones.push({ x, z, size: .25 + rng() * 2.1, yaw: rng() * TAU });
        }
        const rockGeo = new THREE.DodecahedronGeometry(1, 0), rockMat = stoneSurface(0x7c9290, 214, 2, .93);
        const rocks = new THREE.InstancedMesh(rockGeo, rockMat, stones.length), tmp = new THREE.Object3D();
        const color = new THREE.Color();
        stones.forEach((p, i) => {
            tmp.position.set(p.x, heightAt(p.x, p.z, s) - .14, p.z);
            tmp.rotation.set(.14, p.yaw, .08);
            tmp.scale.set(p.size * 1.2, p.size * .5, p.size * .83);
            tmp.updateMatrix();
            rocks.setMatrixAt(i, tmp.matrix);
            color.setHSL(.49, .07, .58 + rng() * .21);
            rocks.setColorAt(i, color);
        });
        rocks.instanceMatrix.needsUpdate = true;
        rocks.instanceColor.needsUpdate = true;
        rocks.computeBoundingSphere();
        rocks.userData.stonePlaces = stones;
        this.detailRocks = rocks;
        this.scene.add(rocks);
        // Deliberately placed carved standing stones establish a readable forest route.
        const standing = stoneSurface(0x83968d, 349, 2, .83);
        for (let i = 0; i < 7; i++) {
            const x = -68 + i * 16, z = 7 + Math.sin(i * .83) * 12;
            const y = heightAt(x, z, s);
            const obelisk = new THREE.Mesh(new THREE.CylinderGeometry(.38, .9, 4.5 + i % 3 * 1.1, 5), standing);
            obelisk.position.set(x, y + 2.1, z);
            obelisk.rotation.z = Math.sin(i * 2) * .075;
            this.scene.add(obelisk);
            const crest = new THREE.Mesh(new THREE.TorusGeometry(.59, .045, 5, 18), new THREE.MeshBasicMaterial({ color: ART.glacial, transparent: true, opacity: .5 }));
            crest.position.set(x, y + 3.0, z + .64);
            this.scene.add(crest);
        }
        // Shore pebble band visually separates wet sand from the moving waterline.
        const coastMat = new THREE.MeshStandardMaterial({ color: 0xa3afa3, roughness: .96 });
        const pebbleGeo = new THREE.IcosahedronGeometry(.35, 0);
        const pebbleCount = s.quality === 'low' ? 190 : 720, pebbles = new THREE.InstancedMesh(pebbleGeo, coastMat, pebbleCount);
        for (let i = 0; i < pebbleCount; i++) {
            const x = (rng() - .5) * 234, z = 64 + rng() * 9;
            tmp.position.set(x, heightAt(x, z, s) + .08, z);
            tmp.scale.set(.3 + rng() * 1.4, .12 + rng() * .55, .3 + rng() * 1.1);
            tmp.rotation.set(0, rng() * TAU, 0);
            tmp.updateMatrix();
            pebbles.setMatrixAt(i, tmp.matrix);
        }
        pebbles.instanceMatrix.needsUpdate = true;
        pebbles.computeBoundingSphere();
        this.scene.add(pebbles);
    }
    createMountains(s) {
        const rng = mulberry32(340);
        // Three interleaved ridge families, not repeated cone primitives.
        for (let layer = 2; layer >= 0; layer--) {
            const count = s.quality === 'low' ? (layer === 1 ? 9 : 7) : (layer === 1 ? 16 : 13);
            const colorScale = layer === 0 ? 1 : layer === 1 ? .72 : .58;
            for (let i = 0; i < count; i++) {
                const x = -167 + i * (334 / (count - 1)) + Math.sin(i * 2.1 + layer) * 7;
                const z = -106 - layer * 36 - rng() * 17;
                const h = (32 + rng() * 31) * (1 + layer * .22);
                const m = new THREE.Mesh(mountainGeometry(17 + rng() * 14, h, 601 + i + layer * 72), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .95, flatShading: true, side: THREE.DoubleSide }));
                m.position.set(x, 3 - layer * 4, z);
                m.scale.set(colorScale, 1, colorScale);
                m.rotation.y = rng() * TAU;
                this.scene.add(m);
            }
        }
    }
    createVillage(s) {
        const rng = mulberry32(114);
        this.villageWindows = new THREE.MeshBasicMaterial({ color: 0xffd89b, transparent: true, opacity: .2 });
        const roof = authoredSurface('roof', { tint: 0xf0dfdb, repeat: 3, roughness: .9, quality: s.quality }), walls = stoneSurface(0xb1aca0, 271, 2, .9), stones = stoneSurface(0x81928e, 610, 3, .88);
        const houseContacts = [];
        for (let j = 0; j < 14; j++) {
            const angle = j / 14 * TAU * .9, dist = 5 + Math.floor(j / 5) * 5.6;
            const x = -29 + Math.sin(angle + j * .12) * dist, z = 28 + Math.cos(angle + j * .12) * dist;
            const y = heightAt(x, z, s) + .2;
            const house = new THREE.Group();
            house.position.set(x, y, z);
            house.rotation.y = rng() * TAU;
            const h = 4 + rng() * 2, w = 4.3 + rng() * 2.2;
            const block = new THREE.Mesh(new THREE.BoxGeometry(w, h, w * .83), j % 4 === 0 ? stones : walls);
            block.position.y = h / 2;
            block.castShadow = true;
            house.add(block);
            const top = new THREE.Mesh(gableRoof(w, w * .83, 2.7), roof);
            top.position.y = h;
            top.castShadow = true;
            top.material = roof;
            top.userData.feature = 'village-roof-art';
            house.add(top);
            const ridge = new THREE.Mesh(new THREE.BoxGeometry(.24, .23, w * .99), material(0x594b44, .91));
            ridge.position.y = h + 2.72;
            house.add(ridge);
            if (j % 3 === 0) {
                const chimney = new THREE.Mesh(new THREE.BoxGeometry(.75, 2.1, .75), stones);
                chimney.position.set(w * .26, h + 2.0, -w * .1);
                house.add(chimney);
            }
            for (const face of [-1, 1]) {
                const window = new THREE.Mesh(new THREE.PlaneGeometry(.95, 1.0), this.villageWindows);
                window.position.set(face * w * .506, h * .57, 0);
                window.rotation.y = face * Math.PI / 2;
                house.add(window);
            }
            const door = new THREE.Mesh(new THREE.BoxGeometry(.91, 1.8, .13), material(0x463b37));
            door.position.set(0, .9, w * .43);
            house.add(door);
            const lintel = new THREE.Mesh(new THREE.BoxGeometry(1.22, .16, .2), material(0x654d39));
            lintel.position.set(0, 1.92, w * .44);
            house.add(lintel);
            if (j % 2 === 0) {
                const glow = softGlow(0xffc28c, 3.1, .37);
                glow.position.set(0, h * .62, w * .47);
                house.add(glow);
                this.storyLanterns.push(glow);
            }
            labelObject(house, 'A lantern-lit mountain settlement');
            house.userData.clueId = 'village';
            this.inspectionObjects.push(house);
            houseContacts.push({ x, y: y + .06, z, r: w * .78 });
            this.scene.add(house);
            if (j % 4 === 0) {
                const lantern = new THREE.PointLight(0xffba73, 1.2, 14);
                lantern.position.set(x, y + 3.8, z);
                this.scene.add(lantern);
                this.villageLights.push(lantern);
            }
        }
        this.scene.add(contactShadows(houseContacts));
        const pathMat = stoneSurface(0xc0ae92, 338, 5, .95);
        const roadPoints = [[-55, 35], [-45, 27], [-29, 28], [-15, 35], [-7, 52]];
        for (let k = 0; k < roadPoints.length - 1; k++) {
            const a = roadPoints[k], b = roadPoints[k + 1], center = new THREE.Vector3((a[0] + b[0]) / 2, heightAt((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, s) + .25, (a[1] + b[1]) / 2);
            const road = new THREE.Mesh(new THREE.BoxGeometry(2.1, .08, Math.hypot(b[0] - a[0], b[1] - a[1])), pathMat);
            road.position.copy(center);
            road.rotation.y = Math.atan2(b[0] - a[0], b[1] - a[1]);
            this.scene.add(road);
        }
    }
    createRuins(s) {
        const origin = new THREE.Vector3(30, heightAt(30, 44, s), 44);
        this.ruinGroup.position.copy(origin);
        this.scene.add(this.ruinGroup);
        const foundation = new THREE.Mesh(new THREE.CylinderGeometry(10, 11, 1.5, 18), authoredSurface('moss', { tint: 0xe5e5dd, repeat: 3, roughness: .98, quality: s.quality }));
        foundation.position.y = .3;
        this.ruinGroup.add(foundation);
        const dais = new THREE.Mesh(new THREE.CylinderGeometry(6, 7, 1.0, 12), material(0x303d40, .58, .32));
        dais.position.y = 1.3;
        this.ruinGroup.add(dais);
        for (let k = 0; k < 3; k++) {
            const [x, z] = RUIN_TARGETS[k];
            const target = new THREE.Mesh(new THREE.TorusGeometry(1.35, .17, 7, 32), new THREE.MeshBasicMaterial({ color: 0x78dac7, transparent: true, opacity: .75 }));
            target.position.set(x - 30, 1.87, z - 44);
            target.rotation.x = -Math.PI / 2;
            this.ruinGroup.add(target);
            this.targetRings.push(target);
            const group = new THREE.Group();
            const pillar = new THREE.Mesh(new THREE.CylinderGeometry(.86, 1.15, 6.5, 7), material(0x90998e, .87));
            pillar.position.y = 3.25;
            group.add(pillar);
            const carved = new THREE.Mesh(new THREE.TorusGeometry(.92, .10, 6, 20), material(0x83b5b2, .37, .43));
            carved.rotation.x = Math.PI / 2;
            carved.position.y = 5.7;
            group.add(carved);
            labelObject(group, `RUIN FRAGMENT ${k + 1} · Drag toward the cyan socket`, 'ruin');
            group.userData.clueId = 'ruins';
            this.ruinParts.push(group);
            this.scene.add(group);
            this.inspectionObjects.push(group);
        }
        for (let j = 0; j < 5; j++) {
            const a = j / 5 * TAU;
            const broken = new THREE.Mesh(new THREE.CylinderGeometry(.8, 1.2, 2.2 + j % 2 * 1.5, 7), material(0x636d6a));
            broken.position.set(Math.sin(a) * 8, 1.7, Math.cos(a) * 8);
            broken.rotation.z = Math.sin(a) * .25;
            this.ruinGroup.add(broken);
        }
        addArch(this.ruinGroup, new THREE.Vector3(0, 1, 0), 5.7, 8.5, 0x828b81);
        this.ruinBeacon = new THREE.PointLight(0x8bedd8, 0, 52);
        this.ruinBeacon.position.copy(origin).add(new THREE.Vector3(0, 14, 0));
        this.scene.add(this.ruinBeacon);
    }
    createPrisms(s) {
        const gemMaterial = new THREE.MeshPhysicalMaterial({ color: 0x8fe5ec, metalness: .18, roughness: .1, transmission: .28, clearcoat: 1, ior: 1.4 });
        const stone = material(0x727a72, .87), brass = material(0xab9673, .36, .7);
        const origins = [[9, 36], [51, 36]];
        for (let i = 0; i < 2; i++) {
            const [x, z] = origins[i], y = heightAt(x, z, s);
            const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 2.35, 3.8, 10), stone);
            pedestal.position.set(x, y + 1.9, z);
            this.scene.add(pedestal);
            const group = new THREE.Group();
            group.position.set(x, y + 6, z);
            const prism = new THREE.Mesh(new THREE.OctahedronGeometry(2.2, 0), i === 0 ? gemMaterial : brass);
            group.add(prism);
            const ring = new THREE.Mesh(new THREE.TorusGeometry(2.6, .1, 8, 32), brass);
            ring.rotation.x = .6;
            group.add(ring);
            labelObject(group, i === 0 ? 'SOLAR PRISM · Rotate to 41°' : 'LUNAR MIRROR · Rotate to −28°', 'prism');
            this.scene.add(group);
            this.prisms.push(group);
            this.inspectionObjects.push(group);
        }
        this.scene.add(this.beams);
        const source = new THREE.Vector3(9, heightAt(9, 36, s) + 6, 36), relay = new THREE.Vector3(51, heightAt(51, 36, s) + 6, 36), receiver = new THREE.Vector3(30, heightAt(30, 44, s) + 12, 44);
        for (let i = 0; i < 2; i++) {
            const a = i === 0 ? source : relay, b = i === 0 ? relay : receiver;
            const line = new THREE.Vector3().subVectors(b, a);
            const mat = new THREE.MeshBasicMaterial({ color: i === 0 ? 0xf3d7a0 : 0x9aede4, transparent: true, opacity: .16, depthWrite: false, blending: THREE.AdditiveBlending });
            const beam = new THREE.Mesh(new THREE.CylinderGeometry(.09, .09, line.length(), 8), mat);
            beam.position.copy(a).addScaledVector(line, .5);
            beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), line.normalize());
            this.beams.add(beam);
            this.beamMaterials.push(mat);
            this.beamBaseLengths.push(a.distanceTo(b));
            this.beamPoints.push({ start: a.clone(), end: b.clone() });
        }
    }
    createHeartTree(s) {
        const base = heightAt(TREE_X, TREE_Z, s);
        const g = new THREE.Group();
        g.position.set(TREE_X, base, TREE_Z);
        this.scene.add(g);
        const bark = authoredSurface('bark', { tint: 0xe8d4b7, repeat: 2.2, roughness: .95, quality: s.quality, normalStrength: .4 });
        const trunkGeo = new THREE.CylinderGeometry(1.35, 3.5, 24, 18, 16);
        const trunkPos = trunkGeo.getAttribute('position');
        for (let k = 0; k < trunkPos.count; k++) {
            const x = trunkPos.getX(k), y = trunkPos.getY(k), z = trunkPos.getZ(k), a = Math.atan2(z, x);
            const fluting = 1 + .085 * Math.sin(a * 7 + y * .16) + .043 * Math.sin(a * 13 - y * .39);
            trunkPos.setXYZ(k, x * fluting, y, z * fluting);
        }
        trunkGeo.computeVertexNormals();
        const trunk = new THREE.Mesh(trunkGeo, bark);
        trunk.position.y = 12;
        trunk.castShadow = true;
        trunk.userData.feature = 'heart-bark-art';
        g.add(trunk);
        const roots = [];
        for (let j = 0; j < 8; j++) {
            const a = j / 8 * TAU;
            roots.push(new THREE.Vector3(Math.cos(a) * 4, 0, Math.sin(a) * 4));
            g.add(tube([new THREE.Vector3(0, 3, 0), new THREE.Vector3(Math.cos(a) * 2.1, 1.6, Math.sin(a) * 2.1), roots[j]], .43, 0x574d3d, 12));
        }
        for (let j = 0; j < 17; j++) {
            const a = j / 17 * TAU;
            const y = 16 + j % 4 * 2.2;
            const points = [new THREE.Vector3(0, y, 0), new THREE.Vector3(Math.cos(a) * 6, y + 2, Math.sin(a) * 6), new THREE.Vector3(Math.cos(a) * 11, y + 5, Math.sin(a) * 10)];
            g.add(tube(points, .42 - j % 3 * .05, 0x695a49, 22));
        }
        const rng = mulberry32(887);
        const geo = leafBlade();
        const leafMat = new THREE.MeshStandardMaterial({ color: 0x79aa87, roughness: .73, side: THREE.DoubleSide, emissive: 0x0c4239, emissiveIntensity: .15 });
        if (s.quality !== 'low')
            this.windDrivers.push(windDriven(leafMat, 1.6, .12));
        this.centralLeaves = new THREE.InstancedMesh(geo, leafMat, 1020);
        if (s.quality !== 'low')
            this.centralLeaves.userData.feature = 'wind-heart-tree';
        const tmp = new THREE.Object3D(), leafColor = new THREE.Color();
        for (let i = 0; i < 1020; i++) {
            const a = rng() * TAU, b = Math.acos(2 * rng() - 1), r = 7.5 + rng() * 7;
            tmp.position.set(Math.cos(a) * Math.sin(b) * r, 23 + Math.cos(b) * 8, Math.sin(a) * Math.sin(b) * r);
            tmp.scale.set(.55 + rng() * .9, .42 + rng() * .72, .47 + rng() * .8);
            tmp.rotation.set((rng() - .5) * 1.9, rng() * TAU, (rng() - .5) * 1.3);
            tmp.updateMatrix();
            this.centralLeaves.setMatrixAt(i, tmp.matrix);
            leafColor.setHSL(.36 + rng() * .09, .22 + rng() * .18, .63 + rng() * .25);
            this.centralLeaves.setColorAt(i, leafColor);
        }
        this.centralLeaves.instanceMatrix.needsUpdate = true;
        if (this.centralLeaves.instanceColor)
            this.centralLeaves.instanceColor.needsUpdate = true;
        g.add(this.centralLeaves);
        g.add(contactShadows([{ x: 0, y: .03, z: 0, r: 10 }]));
        const inlay = new THREE.Group();
        g.add(inlay);
        for (let i = 0; i < 9; i++) {
            const a = i / 9 * TAU;
            const path = [new THREE.Vector3(Math.cos(a) * 1.15, 5, Math.sin(a) * 1.15),
                new THREE.Vector3(Math.cos(a + .19) * 1.0, 13, Math.sin(a + .19) * 1.0),
                new THREE.Vector3(Math.cos(a + .43) * .73, 20, Math.sin(a + .43) * .73)];
            inlay.add(tube(path, .035, 0x64bda9, 20));
        }
        const lamp = new THREE.PointLight(0x9ddac0, 2.5, 54);
        lamp.position.y = 25;
        g.add(lamp);
        labelObject(g, 'THE HEART TREE · Its growth changes both worlds');
        g.userData.clueId = 'heart-tree';
        this.inspectionObjects.push(g);
        return g;
    }
    createWildlife(s) {
        for (let i = 0; i < 11; i++) {
            const bird = new THREE.Group();
            const body = new THREE.Mesh(new THREE.ConeGeometry(.25, 1.5, 5), material(0x9aaab2));
            body.rotation.x = Math.PI / 2;
            bird.add(body);
            for (let side of [-1, 1]) {
                const wing = new THREE.Mesh(new THREE.ConeGeometry(.19, 2.0, 3), material(i % 3 ? 0x8caba4 : 0xd5c4aa));
                wing.position.x = side * .7;
                wing.rotation.z = side * .97;
                bird.add(wing);
            }
            bird.scale.setScalar(.9 + (i % 3) * .3);
            bird.position.set(-45 + i * 7, 22 + i % 4 * 2, -12 + i * 4);
            this.scene.add(bird);
            this.birds.push(bird);
            this.birdVel.push(new THREE.Vector3(.2, 0, .1));
        }
        for (let i = 0; i < 7; i++) {
            const animal = new THREE.Group();
            const coat = material(0x92735b, .94), horn = material(0xd1baa0);
            const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.7, 2, 3, 7), coat);
            torso.rotation.x = Math.PI / 2;
            torso.position.y = 1.55;
            animal.add(torso);
            const head = sphere(.57, 0x957e67, 10);
            head.position.set(0, 2.2, -1.6);
            animal.add(head);
            const gaitLegs = [];
            for (const dx of [-.55, .55]) {
                for (const dz of [-.85, .83]) {
                    const leg = new THREE.Mesh(new THREE.CylinderGeometry(.13, .16, 1.2, 5), coat);
                    leg.position.set(dx, .65, dz);
                    animal.add(leg);
                    gaitLegs.push(leg);
                }
                const hornMesh = new THREE.Mesh(new THREE.ConeGeometry(.13, .95, 5), horn);
                hornMesh.position.set(dx * .78, 2.95, -1.66);
                hornMesh.rotation.z = dx * .3;
                animal.add(hornMesh);
            }
            animal.userData.gaitLegs = gaitLegs;
            const x = 42 + i * 4, z = 8 + i * 3;
            animal.position.set(x, heightAt(x, z, s), z);
            animal.scale.setScalar(.8 + i % 3 * .1);
            this.scene.add(animal);
            this.deer.push(animal);
            this.deerVel.push(new THREE.Vector3(.05, 0, -.04));
        }
    }
    createFireflies(s) {
        const rng = mulberry32(553), positions = new Float32Array((s.quality === 'low' ? 340 : 1100) * 3);
        for (let i = 0; i < positions.length / 3; i++) {
            const x = (rng() - .5) * 145, z = (rng() - .5) * 110;
            positions[i * 3] = x;
            positions[i * 3 + 1] = heightAt(x, z, s) + .9 + rng() * 9;
            positions[i * 3 + 2] = z;
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        this.fireflies = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xc7f8a7, size: .32, transparent: true, opacity: .25, depthWrite: false, blending: THREE.AdditiveBlending }));
        this.fireflies.frustumCulled = false;
        this.scene.add(this.fireflies);
    }
    rebuildRivers(s) {
        for (const obj of [...this.riverGroup.children])
            if (obj.userData.userRiver) {
                this.riverGroup.remove(obj);
                obj.geometry.dispose();
                obj.material instanceof THREE.Material && obj.material !== this.waterMats[0] && obj.material.dispose();
            }
        for (const coords of s.rivers) {
            const pts = coords.map(([x, z]) => new THREE.Vector3(x, heightAt(x, z, s) + .28, z));
            const mesh = new THREE.Mesh(ribbon(pts, 2.6), this.waterMats[0]);
            mesh.userData.userRiver = true;
            this.riverGroup.add(mesh);
        }
        this.lastRiverCount = s.rivers.length;
    }
    syncSeeds(s) {
        for (const group of this.seedVisuals.values()) {
            this.seedGroup.remove(group);
            group.traverse(o => { const m = o; m.geometry?.dispose(); if (m.material)
                for (const mat of Array.isArray(m.material) ? m.material : [m.material])
                    mat.dispose(); });
        }
        this.seedVisuals.clear();
        for (const seed of s.seeds) {
            const g = new THREE.Group();
            g.position.set(seed.x, heightAt(seed.x, seed.z, s), seed.z);
            const stem = cylinder(.12, .19, 3.6, 0x6e5f42);
            stem.position.y = 1.8;
            g.add(stem);
            const crown = new THREE.Mesh(new THREE.IcosahedronGeometry(1.7, 1), new THREE.MeshStandardMaterial({ color: 0x61a985, emissive: 0x143f33, emissiveIntensity: .28, roughness: .76 }));
            crown.position.y = 4.0;
            g.add(crown);
            const bud = sphere(.3, 0xd9d9a2, 10);
            bud.position.y = 5.2;
            g.add(bud);
            labelObject(g, `LIVING SEED ${seed.id} · Growth ${Math.round(seed.age * 100)}%`, 'seed');
            this.seedVisuals.set(seed.id, g);
            this.seedGroup.add(g);
        }
        this.lastSeedCount = s.seeds.length;
    }
    syncMarkers(s) {
        const previous = [...this.markerGroup.children];
        this.inspectionObjects = this.inspectionObjects.filter(o => !previous.includes(o));
        for (const old of previous) {
            this.markerGroup.remove(old);
            old.traverse(o => { const m = o; m.geometry?.dispose(); if (m.material)
                for (const mat of Array.isArray(m.material) ? m.material : [m.material])
                    mat.dispose(); });
        }
        s.wildlifeMarkers.forEach(([x, z], i) => {
            const g = new THREE.Group();
            g.position.set(x, heightAt(x, z, s) + 1, z);
            const ring = new THREE.Mesh(new THREE.TorusGeometry(1.8, .1, 8, 42), new THREE.MeshBasicMaterial({ color: 0xf3d5a1, transparent: true, opacity: .87 }));
            ring.rotation.x = Math.PI / 2;
            g.add(ring);
            const orb = sphere(.38, 0xe7b880, 12);
            orb.position.y = 1.3;
            g.add(orb);
            labelObject(g, `WILDLIFE LURE ${i + 1} · Click to remove`, 'marker');
            this.inspectionObjects.push(g);
            this.markerGroup.add(g);
        });
        this.lastMarkers = JSON.stringify(s.wildlifeMarkers);
    }
    syncRuins(s) {
        s.ruins.forEach((r, i) => {
            const g = this.ruinParts[i];
            g.position.set(r.x, heightAt(r.x, r.z, s) + .8, r.z);
            g.rotation.y = r.angle;
            const c = g.children[1].material;
            c.emissive = new THREE.Color(r.snapped ? 0x2f8978 : 0x111e20);
            c.emissiveIntensity = r.snapped ? .83 : .1;
            this.targetRings[i].visible = !r.snapped;
        });
        this.lastRuinCount = JSON.stringify(s.ruins);
    }
    syncExtraDrops(s) {
        const number = extraDroplets(s);
        if (number === this.lastExtraDrops)
            return;
        this.extraDrops.forEach(g => { this.mainTree.remove(g); g.traverse(o => { const m = o; m.geometry?.dispose(); if (m.material) {
            for (const mat of Array.isArray(m.material) ? m.material : [m.material])
                mat.dispose();
        } }); });
        this.extraDrops = [];
        this.lastExtraDrops = number;
        for (let i = 0; i < number; i++) {
            const a = i / Math.max(1, number) * TAU + 1.3;
            const drop = new THREE.Group();
            const sphereMesh = new THREE.Mesh(new THREE.SphereGeometry(.55 + i * .04, 12, 9), new THREE.MeshPhysicalMaterial({ color: 0xa8e9e7, transmission: .67, roughness: .08, metalness: .08, transparent: true, opacity: .75, clearcoat: 1 }));
            drop.position.set(Math.cos(a) * 10, 24 + i % 3 * 2.3, Math.sin(a) * 9);
            drop.add(sphereMesh);
            this.mainTree.add(drop);
            this.extraDrops.push(drop);
        }
    }
    lastSeason = 'Summer';
    sync(s) {
        if (this.lastSeason !== s.season) {
            this.lastSeason = s.season;
            paintTerrain(this.terrain.geometry, s);
            const tint = s.season === 'Autumn' ? 0xc48e61 : s.season === 'Winter' ? 0xc2d3cf : s.season === 'Spring' ? 0x9ac389 : 0xffffff;
            this.forest.forEach(f => { f.crowns.material.color.setHex(tint); });
        }
        if (this.lastTerrain.some((h, i) => h !== s.terrain[i])) {
            updateTerrain(this.terrain.geometry, s);
            paintTerrain(this.terrain.geometry, s);
            this.repositionForest(s);
            if (this.detailRocks) {
                const rocks = this.detailRocks, places = rocks.userData.stonePlaces;
                const o = new THREE.Object3D();
                places.forEach((p, i) => {
                    o.position.set(p.x, heightAt(p.x, p.z, s) - .14, p.z);
                    o.rotation.set(.14, p.yaw, .08);
                    o.scale.set(p.size * 1.2, p.size * .5, p.size * .83);
                    o.updateMatrix();
                    rocks.setMatrixAt(i, o.matrix);
                });
                rocks.instanceMatrix.needsUpdate = true;
                rocks.computeBoundingSphere();
            }
            this.mainTree.position.y = heightAt(TREE_X, TREE_Z, s);
            this.citizens.refreshTerrain(s);
            this.gravityLens.position.y = heightAt(20, -33, s) + 31;
            this.ruinGroup.position.y = heightAt(30, 44, s);
            this.terrainRings.forEach((ring, i) => { const z = TERRAIN_ZONES[i]; ring.position.y = heightAt(z.x, z.z, s) + .33; });
            if (this.snowPatches) {
                const pts = this.snowPatches.userData.snowPlaces;
                const obj = new THREE.Object3D();
                pts.forEach((p, i) => { obj.position.set(p.x, heightAt(p.x, p.z, s) + .31, p.z); obj.rotation.y = p.angle; obj.scale.setScalar(p.size); obj.updateMatrix(); this.snowPatches.setMatrixAt(i, obj.matrix); });
                this.snowPatches.instanceMatrix.needsUpdate = true;
                this.snowPatches.computeBoundingSphere();
            }
            this.portal.y = heightAt(TREE_X, TREE_Z, s) + 23;
            this.drop.group.position.y = this.portal.y;
            this.exitPortal.y = heightAt(TREE_X, TREE_Z, s) + 13;
            this.returnIris.position.copy(this.exitPortal);
            this.seedVisuals.forEach((g, id) => { const p = s.seeds.find(seed => seed.id === id); if (p)
                g.position.y = heightAt(p.x, p.z, s); });
            this.lastTerrain = [...s.terrain];
            this.rebuildRivers(s);
            this.syncRuins(s);
        }
        if (this.lastRiverCount !== s.rivers.length)
            this.rebuildRivers(s);
        if (this.lastSeedCount !== s.seeds.length)
            this.syncSeeds(s);
        if (this.lastMarkers !== JSON.stringify(s.wildlifeMarkers))
            this.syncMarkers(s);
        if (this.lastRuinCount !== JSON.stringify(s.ruins))
            this.syncRuins(s);
        this.syncExtraDrops(s);
    }
    getGround(x, z, s) { return heightAt(clamp(x, -119, 119), clamp(z, -119, 119), s); }
    getTerrainPoint(ray) {
        const hits = ray.intersectObject(this.terrain, false);
        return hits.length ? hits[0].point : null;
    }
    getRuinId(object) {
        return this.ruinParts.findIndex(g => { let current = object; while (current) {
            if (current === g)
                return true;
            current = current.parent;
        } return false; });
    }
    update(dt, elapsed, s, camera) {
        this.rig.update(dt, elapsed, s, camera);
        this.drop.update(elapsed, s);
        this.vistas.update(elapsed, s, camera);
        for (const driver of this.windDrivers)
            driver.update(elapsed, s);
        this.citizens.update(dt, elapsed, s);
        this.watershed.update(dt, s);
        const alignedGravity = gravityAligned(s);
        this.gravityStones.forEach((g, i) => {
            const desired = (alignedGravity ? 0 : 6 + Math.sin(i * 2.7) * 3);
            g.position.x += (5 + i * 3.2 + desired - g.position.x) * Math.min(1, dt * 1.6);
            const rotationTarget = alignedGravity ? 0 : .18 * Math.sin(i * 2);
            g.rotation.z += (rotationTarget - g.rotation.z) * Math.min(1, dt * 1.3);
        });
        const lensMat = this.gravityLens.material;
        lensMat.emissiveIntensity = alignedGravity ? 2.7 : .15;
        this.gravityLens.rotation.y += dt * (s.reducedMotion ? .04 : .22);
        this.waterMats.forEach(m => {
            m.uniforms.uTime.value = elapsed;
            m.uniforms.uGravity.value.set(s.gravity[0], s.gravity[1]);
            m.uniforms.uRain.value = s.weather === 'Thunderstorm' ? 1 : s.weather === 'Rain' ? .6 : 0;
            m.uniforms.uDay.value = sunAmountSafe(s.time);
        });
        if (this.cascadeMaterial)
            this.cascadeMaterial.uniforms.uTime.value = elapsed;
        this.snowAccumulation = lerp(this.snowAccumulation, s.weather === 'Snow' ? .55 : s.season === 'Winter' ? .31 : 0, dt * .13);
        if (this.snowPatches)
            this.snowPatches.material.opacity = this.snowAccumulation;
        const wet = s.weather === 'Rain' || s.weather === 'Thunderstorm';
        const earthMat = this.terrain.material;
        earthMat.roughness = lerp(earthMat.roughness, wet ? .69 : .97, dt * .3);
        const tide = tideAt(s.moonAngle);
        this.coastline.position.y = -1 + tide * .43;
        this.coastline.position.z = 94 - tide * 1.7;
        this.tideLine.position.z = 68 - tide * 2;
        this.tideLine.position.y = this.coastline.position.y + .06;
        this.rig.moonMesh.visible = false;
        const mx = Math.cos(s.moonAngle) * 160, my = 55 + Math.sin(s.moonAngle) * 75;
        this.moonObject.position.set(mx, my, -120);
        this.rig.moon.position.copy(this.moonObject.position);
        this.fireflies.material.opacity = clamp((1 - sunAmountSafe(s.time)) * .7 + .05, 0, .84);
        this.fireflies.position.y = Math.sin(elapsed * .8) * .22;
        const night = isNight(s.time);
        this.villageWindows.opacity = night ? .94 : .19;
        this.villageLights.forEach(l => l.intensity = night ? 2.3 : .23);
        const growth = treeGrowth(s);
        this.mainTree.scale.setScalar(1 + growth * .11 + heartIrrigation(s) * .035);
        this.centralLeaves.material.color.setHSL(s.season === 'Autumn' ? .102 : s.season === 'Winter' ? .54 : s.season === 'Spring' ? .32 : .34 + heartIrrigation(s) * .04, s.season === 'Winter' ? .19 : .32, s.season === 'Autumn' ? .42 : .52 + heartIrrigation(s) * .1);
        this.ruinBeacon.color.setHex(causalStage(s) >= 3 ? 0xebc68c : 0x8bedd8);
        this.centralLeaves.material.emissiveIntensity = night ? .64 : .18;
        this.seedVisuals.forEach((g, id) => {
            const seed = s.seeds.find(p => p.id === id);
            if (!seed)
                return;
            const stage = seed.age < .2 ? .12 + seed.age * 1.1 : seed.age < .55 ? .32 + (seed.age - .2) * 1.45 : .83 + (seed.age - .55) * .66;
            g.scale.setScalar(stage);
            g.children[2].visible = seed.age > .54;
        });
        if (this.plantAgeLast < 0 || Math.abs(this.plantAgeLast - s.seeds.reduce((a, b) => a + b.age, 0)) > .08) {
            this.plantAgeLast = s.seeds.reduce((a, b) => a + b.age, 0);
        }
        const factor = s.reducedMotion ? .23 : 1;
        for (let i = 0; i < this.birds.length; i++) {
            const b = this.birds[i], v = this.birdVel[i];
            const marker = s.wildlifeMarkers[i % s.wildlifeMarkers.length];
            const target = marker ? new THREE.Vector3(marker[0], this.getGround(marker[0], marker[1], s) + 13, marker[1]) : new THREE.Vector3(Math.sin(elapsed * .07 + i) * 48, 30 + i % 5 * 3, Math.cos(elapsed * .09 + i) * 39);
            const delta = target.sub(b.position).normalize();
            v.lerp(delta.multiplyScalar(2.8), dt * .7);
            b.position.addScaledVector(v, dt * factor);
            b.rotation.y = Math.atan2(v.x, v.z);
            b.position.y += Math.sin(elapsed * 2.5 + i) * dt * .35 * factor;
            for (let j = 1; j <= 2; j++) {
                const wing = b.children[j];
                wing.rotation.z = (j === 1 ? 1 : -1) * (.9 + Math.sin(elapsed * 5 + i) * .34);
            }
        }
        for (let i = 0; i < this.deer.length; i++) {
            const animal = this.deer[i], v = this.deerVel[i];
            const marker = s.wildlifeMarkers[i % s.wildlifeMarkers.length];
            const target = marker ? new THREE.Vector3(marker[0], 0, marker[1]) : new THREE.Vector3(26 + Math.sin(elapsed * .08 + i * 1.2) * 24, 0, 13 + Math.cos(elapsed * .06 + i) * 23);
            const delta = target.sub(animal.position).setY(0);
            if (delta.length() > 2) {
                v.lerp(delta.normalize().multiplyScalar(marker ? 2.3 : .65), dt * .7);
                animal.position.addScaledVector(v, dt * factor);
            }
            animal.position.y = this.getGround(animal.position.x, animal.position.z, s);
            animal.rotation.y = Math.atan2(-v.x, -v.z);
            const stride = clamp(v.length() * .21, 0, .23) * (s.reducedMotion ? .15 : 1);
            animal.userData.gaitLegs.forEach((leg, j) => {
                leg.rotation.x = Math.sin(elapsed * 2.1 + i * .7 + (j % 3 === 0 ? 0 : Math.PI)) * stride;
            });
        }
        this.prisms[0].rotation.y = s.prismAngle;
        this.prisms[1].rotation.y = s.mirrorAngle;
        for (let j = 0; j < this.beams.children.length; j++) {
            const beam = this.beams.children[j];
            const data = this.beamPoints[j];
            const err = j === 0 ? s.prismAngle - .72 : s.mirrorAngle + .48;
            const end = data.end.clone().add(new THREE.Vector3(Math.sin(err) * 47, Math.sin(err * 1.25) * 13, (1 - Math.cos(err)) * 36));
            const vec = end.sub(data.start);
            const length = vec.length();
            beam.position.copy(data.start).addScaledVector(vec, .5);
            beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), vec.normalize());
            beam.scale.y = length / this.beamBaseLengths[j];
        }
        const aligned = lightAligned(s);
        this.beamMaterials[0].opacity = aligned ? .74 : Math.max(.07, .37 - Math.abs(s.prismAngle - .72) * .25);
        this.beamMaterials[1].opacity = aligned ? .78 : Math.max(.04, .31 - Math.abs(s.mirrorAngle + .48) * .25);
        this.ruinBeacon.intensity = aligned ? 6.8 : ruinsComplete(s) ? 3.5 : 0;
        if (aligned)
            this.ruinGroup.rotation.y = Math.sin(elapsed * .27) * .021;
        for (let j = 0; j < this.targetRings.length; j++) {
            const m = this.targetRings[j].material;
            m.opacity = s.ruins[j].snapped ? 0 : (.49 + Math.sin(elapsed * 2 + j) * .2);
        }
        // Slow globally coherent wind, responding to outer gravity and current storm.
        this.centralLeaves.rotation.y = Math.sin(elapsed * .24) * .008 + s.gravity[0] * .12;
        this.centralLeaves.rotation.z = Math.sin(elapsed * .27) * .012 + s.gravity[0] * .08;
        this.forest.forEach((f, i) => {
            f.crowns.position.x = Math.sin(elapsed * .63 + i) * .11 + s.gravity[0] * .28;
        });
        this.dust.update(elapsed, s.gravity[0]);
        if (this.waterfallSpray) {
            const p = this.waterfallSpray.geometry.getAttribute('position');
            // Bounded CPU particle update, skipped in reduced-motion mode.
            if (!s.reducedMotion) {
                const floor = this.waterfallSpray.userData.fallLow;
                const ceiling = this.waterfallSpray.userData.fallHigh;
                for (let i = 0; i < p.count; i++) {
                    let y = p.getY(i) - dt * (5 + i % 5 * 1.7);
                    if (y < floor)
                        y = ceiling - (floor - y) % (ceiling - floor);
                    p.setY(i, y);
                }
                p.needsUpdate = true;
            }
        }
        if (this.waterfallLight) {
            this.waterfallLight.lookAt(camera.position);
            this.waterfallLight.material.uniforms.uOpacity.value = .22 + Math.sin(elapsed * .55) * .035;
        }
        this.storyLanterns.forEach(glow => {
            const mat = glow.material;
            mat.uniforms.uOpacity.value = night ? .47 : .13;
            glow.lookAt(camera.position);
        });
    }
    dispose() { disposeScene(this.scene); }
}
function sunAmountSafe(time) { return clamp((Math.sin((time - 6) * Math.PI / 12) + .19) * 2.2, 0, 1); }
