import { causalStage, finaleReady } from './simulation.js';
export const OBSERVATIONS = [
    { id: 'outer-drop', world: 0, title: 'A borrowed horizon', text: 'The enclosed landscape does not move as a reflection should. The water seems to contain a distance greater than its diameter.' },
    { id: 'outer-instrument', world: 0, title: 'The measuring machine', text: 'The instrument does not measure a distant sky. Its marks correspond to arrangements appearing within the smaller garden.' },
    { id: 'water-law', world: 1, title: 'A river writes upward', text: 'Water follows the land, but the Heart Tree responds to both. A changed catchment may alter what can be seen from the Observatory.' },
    { id: 'heart-tree', world: 1, title: 'A second threshold', text: 'New growth brings new droplets. The boundaries of this world may be alive rather than fixed.' },
    { id: 'village', world: 1, title: 'People under glass', text: 'The settlement has its own days, storms, paths and shelter. Its life continues whether or not it is being watched.' },
    { id: 'ruins', world: 1, title: 'The forgotten receiver', text: 'The stones were placed to register light, not simply to commemorate it. A reconstruction could change a larger instrument.' },
    { id: 'gravity-reliquary', world: 1, title: 'The reluctant bridge', text: 'These stones move with gravity outside their world. The direction of the outer droplet is a key.' },
    { id: 'garden-orrery', world: 2, title: 'Astronomy that can be walked', text: 'The luminous islands are connected by paths written in stars. Draw the constellations and watch the terrain answer.' },
    { id: 'garden-origin', world: 2, title: 'The same impossible pattern', text: 'The inner machinery and the Observatory are related, but neither is simply a copy of the other.' },
    { id: 'temporal-history', world: 1, title: 'Two landscapes, one place', text: 'The echo preserves a geometry that is no longer present. The world has acquired a visible history.' },
    { id: 'concordance', world: 0, title: 'The concordance', text: 'Water, growth, light and gravity have formed one circuit. The smallest world has answered its origin.' }
];
export const observationById = (id) => OBSERVATIONS.find(o => o.id === id);
export function narrativeStatus(s) {
    const stage = causalStage(s);
    if (finaleReady(s))
        return { stage: 4, title: 'The concordance is possible', hint: 'Return to the Observatory and inspect the first threshold.', ending: s.endingSeen };
    if (stage === 3)
        return { stage, title: 'A pattern without an observer', hint: 'There is something to recognize above the Celestial Garden.', ending: false };
    if (stage === 2)
        return { stage, title: 'The sky remembers', hint: 'Light and stone can be restored; gravity also moves what should be immovable.', ending: false };
    if (stage === 1)
        return { stage, title: 'Water has awakened the tree', hint: 'Beyond its newest droplet, the stars may answer.', ending: false };
    return { stage, title: 'An unexamined impossibility', hint: 'Try the land, water and seeds around the Heart Tree. The world has laws, not instructions.', ending: false };
}
