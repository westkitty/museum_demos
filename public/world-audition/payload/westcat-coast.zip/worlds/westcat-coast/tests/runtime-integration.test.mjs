/** Browser-free integration evidence: real main, input, course, physics modules with a stub renderer.
 * Does NOT establish WebGL/browser visual correctness. Run with --experimental-vm-modules.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const source=name=>readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');

class Target {
  constructor(id,doc){this.id=id;this.doc=doc;this.hidden=false;this.checked=false;this.value='';this.textContent='';this.innerHTML='';this.attrs={};this.style={};this.tagName=id==='quality'?'SELECT':(['reducedMotion','sound'].includes(id)?'INPUT':(/Btn$/.test(id)||['enterBtn','replayBtn'].includes(id)?'BUTTON':'DIV'));this.listeners=new Map();this.dataset={};this.clientWidth=1280;this.clientHeight=720;this.classSet=new Set();this.classList={add:k=>this.classSet.add(k),remove:k=>this.classSet.delete(k),contains:k=>this.classSet.has(k),toggle:(k,force)=>{const yes=force===undefined?!this.classSet.has(k):Boolean(force);if(yes)this.classSet.add(k);else this.classSet.delete(k);return yes;}};}
  addEventListener(k,fn){const arr=this.listeners.get(k)||[];arr.push(fn);this.listeners.set(k,arr);}
  removeEventListener(k,fn){this.listeners.set(k,(this.listeners.get(k)||[]).filter(x=>x!==fn));}
  emit(k, data={}){const e={prevented:false,preventDefault(){this.prevented=true;},target:this,pointerId:1,...data};for(const fn of this.listeners.get(k)||[])fn(e);return e;}
  click(){this.emit('click');}focus(){this.doc.activeElement=this;}setAttribute(k,v){this.attrs[k]=v;}setPointerCapture(){}
}
async function harness(query='?test=1&museum=1'){
 let timeMs=0;const raf=[];const ids=new Map();const doc=new Target('document',null);doc.doc=doc;doc.hidden=false;doc.referrer='';doc.activeElement=null;
 doc.documentElement={dataset:{}};
 doc.getElementById=(id)=>{if(!ids.has(id))ids.set(id,new Target(id,doc));return ids.get(id);};
 doc.querySelector=(q)=>q==='.chapter-title'?doc.getElementById('chapterBox'):null;
 const touches=['left','right','jump'].map(a=>{const o=new Target(`touch-${a}`,doc);o.dataset.action=a;return o;});
 doc.querySelectorAll=q=>q==='[data-action]'?touches:[];
 const win=new Target('window',doc);win.parent=win;win.innerWidth=1280;win.innerHeight=720;win.devicePixelRatio=1;win.AudioContext=null;
 const state={quality:[],frames:[],resetView:0,disposed:0,resize:0};
 const worldStub=()=>({collectibles:[],setQuality:k=>state.quality.push(k),resize:()=>state.resize++,step:(p,owlX,active,dt,reduced,finished)=>state.frames.push({x:p.x,y:p.y,vx:p.vx,vy:p.vy,grounded:p.grounded,wall:p.wall,doubleAvailable:p.doubleAvailable,owlX,active,dt,reduced,finished}),collect:()=>0,dispose:()=>state.disposed++,resetView:()=>state.resetView++});
 const context=vm.createContext({window:win,document:doc,location:{origin:'http://127.0.0.1:8080',search:query},console,URL,URLSearchParams,performance:{now:()=>timeMs},navigator:{deviceMemory:8},matchMedia:()=>({matches:false}),ResizeObserver:class{observe(){}disconnect(){}},requestAnimationFrame:fn=>{raf.push(fn);return raf.length;}});
 const mods={};for(const name of ['course.js','physics.js','input.js','main.js'])mods[name]=new vm.SourceTextModule(source(name),{context,identifier:name});
 mods['world.js']=new vm.SyntheticModule(['createWorld'],function(){this.setExport('createWorld',worldStub);},{context,identifier:'world.js'});
 await mods['main.js'].link(spec=>{const name=spec.slice(2);if(!mods[name])throw new Error(`Unknown import ${spec}`);return mods[name];});
 await mods['main.js'].evaluate();
 const run=(frames=1)=>{for(let i=0;i<frames;i++){timeMs+=1000/60;const fn=raf.shift();if(!fn)throw Error('RAF loop not scheduled');fn(timeMs);}};
 const key=(code,target=doc.activeElement)=>{const e={code,target,prevented:false,preventDefault(){this.prevented=true;}};for(const fn of doc.listeners.get('keydown')||[])fn(e);return e;};
 const up=(code,target=doc.activeElement)=>{const e={code,target};for(const fn of doc.listeners.get('keyup')||[])fn(e);};
 return {doc,win,ids,el:doc.getElementById,run,key,up,touches,state,read:()=>win.__WESTCAT_TEST__.read()};
}

test('mock museum entry, keyboard movement and return preserve position',async()=>{
 const h=await harness();assert.equal(h.read().portal,true);
 h.el('enterBtn').click();h.run(3);assert.equal(h.read().portal,false);
 h.key('ArrowRight');h.run(45);h.up('ArrowRight');let at=h.read().x;assert.ok(at>2.1);
 h.el('museumBtn').click();assert.equal(h.read().portal,true);h.run(80);assert.equal(h.read().x,at);
 h.el('enterBtn').click();h.run(2);assert.equal(h.read().portal,false);assert.ok(h.read().x>=at);
});

test('focused settings or portal controls retain Space/Arrow keyboard semantics',async()=>{
 const h=await harness();h.el('enterBtn').focus();
 const space=h.key('Space',h.el('enterBtn'));
 assert.equal(space.prevented,false,'Space on focused Enter button must not be swallowed');
 h.up('Space');
 h.el('enterBtn').click();h.el('settingsBtn').click();
 h.el('quality').focus();const arrow=h.key('ArrowRight',h.el('quality'));
 assert.equal(arrow.prevented,false,'Arrow keys in focused quality select must be preserved');
});

test('touch right and jump produce input and movement, releasing pointer stops movement',async()=>{
 const h=await harness();h.el('enterBtn').click();const start=h.read().x;
 h.touches[1].emit('pointerdown',{pointerId:12});h.run(35);h.touches[1].emit('pointerup',{pointerId:12});
 assert.ok(h.read().x>start+2);
 const y=h.read().y;h.touches[2].emit('pointerdown',{pointerId:33});h.run(6);h.touches[2].emit('pointerup',{pointerId:33});assert.ok(h.read().y>=y);
});

test('quality and reduced motion are delivered to the renderer and settings are safe during active pursuit',async()=>{
 const h=await harness();h.el('enterBtn').click();h.win.__WESTCAT_TEST__.teleport(110,10.15);h.run(5);
 assert.equal(h.read().chaseActive,true);
 h.el('quality').value='low';h.el('quality').emit('change');assert.equal(h.state.quality.at(-1),'low');
 h.el('reducedMotion').checked=true;h.el('reducedMotion').emit('change');h.run(3);assert.equal(h.state.frames.at(-1).reduced,true);
 assert.equal(h.doc.documentElement.dataset.motion,'reduced','Manual reduced motion should also disable DOM transitions');
 h.el('settingsBtn').click();const snapshot=h.read();h.run(200);
 assert.equal(h.read().deaths,snapshot.deaths,'Settings must not expose a stationary player to pursuit damage');
 assert.equal(h.read().x,snapshot.x,'Settings should freeze player until dismissed');
});

test('finish -> mock museum -> re-enter starts a fresh playable run instead of replaying ending immediately',async()=>{
 const h=await harness();h.el('enterBtn').click();h.win.__WESTCAT_TEST__.teleport(148.7,12.3);h.run(6);
 assert.equal(h.read().finished,true);
 h.el('endMuseumBtn').click();assert.equal(h.read().portal,true);
 h.el('enterBtn').click();h.run(5);
 assert.equal(h.read().finished,false,'Re-entering from museum after finishing must not instantly finish again');
 assert.ok(h.read().x<10,'A completed course should restart when re-entered from mock museum');
});

test('reset returns camera and visual presentation to the initial entry rather than leaving it at the finish',async()=>{
 const h=await harness();h.el('enterBtn').click();h.win.__WESTCAT_TEST__.teleport(148.7,12.3);h.run(5);
 const count=h.state.resetView;h.el('replayBtn').click();
 assert.equal(h.read().finished,false);assert.equal(h.read().checkpoint,'duncan');
 assert.ok(h.state.resetView>count,'Replay must explicitly snap renderer camera to new spawn');
});


test('settings and pause restore playable keyboard focus while respecting an existing pause',async()=>{
 const h=await harness();h.el('enterBtn').click();h.el('settingsBtn').focus();h.el('settingsBtn').click();
 assert.equal(h.read().paused,true);h.el('settingsBtn').click();
 assert.equal(h.read().paused,false);assert.equal(h.doc.activeElement,h.el('game'));
 const x=h.read().x;h.key('ArrowRight');h.run(25);h.up('ArrowRight');assert.ok(h.read().x>x);
 h.el('pauseBtn').focus();h.el('pauseBtn').click();assert.equal(h.read().paused,true);
 h.el('settingsBtn').click();h.el('settingsBtn').click();assert.equal(h.read().paused,true,'Opening settings during a manual pause must not unpause');
 h.el('pauseBtn').click();assert.equal(h.read().paused,false);assert.equal(h.doc.activeElement,h.el('game'));
});

test('keyboard double jump changes vertical velocity in the actual fixed-step main loop',async()=>{
 const h=await harness();h.el('enterBtn').click();h.run(2);
 h.key('Space');h.run(7);h.up('Space');
 assert.ok(h.read().y>1.1);
 h.run(2);h.key('Space');h.run(2);h.up('Space');
 const f=h.state.frames.at(-1);assert.ok(f.vy>8 && !f.doubleAvailable,'Second separate press must provide the air boost');
});

test('keyboard wall jump kicks away from a reachable trunk wall while holding right',async()=>{
 const h=await harness();h.el('enterBtn').click();h.win.__WESTCAT_TEST__.teleport(80.42,8.3);
 h.key('ArrowRight');h.run(14);
 const before=h.state.frames.at(-1);assert.equal(before.wall,1,'Expected contact with authored trunk wall');
 h.key('Space');h.run(2);h.up('Space');h.up('ArrowRight');
 const after=h.state.frames.at(-1);assert.ok(after.vx<0&&after.vy>0,'Wall kick must send player back and upward');
});


test('touch jump can be released and pressed again for a distinct double jump',async()=>{
 const h=await harness();h.el('enterBtn').click();h.run(2);
 const jump=h.touches[2];jump.emit('pointerdown',{pointerId:18});h.run(7);jump.emit('pointerup',{pointerId:18});
 h.run(2);jump.emit('pointerdown',{pointerId:19});h.run(2);jump.emit('pointerup',{pointerId:19});
 const p=h.state.frames.at(-1);assert.equal(p.doubleAvailable,false,'Second touch press must consume second jump');assert.ok(p.vy>8);
});

test('checkpoint acquisition and chase catch restore the last safe platform, with camera snap',async()=>{
 const h=await harness();h.el('enterBtn').click();h.win.__WESTCAT_TEST__.teleport(126.7,11.25);h.run(5);
 assert.equal(h.read().checkpoint,'last-light');assert.equal(h.read().chaseActive,true);
 const snaps=h.state.resetView;h.run(300);
 assert.ok(h.read().deaths>0,'Standing still in the pursuit must trigger a recoverable capture');
 assert.ok(h.read().x>=126.7 && h.read().x<130,'Respawn must use the last checkpoint');
 assert.ok(h.state.resetView>snaps,'Checkpoint respawn must immediately recenter visual camera');
});


test('chapter palette follows actual course state without changing movement or progress',async()=>{
 const h=await harness();
 assert.equal(h.doc.documentElement.dataset.chapter,'duncan');
 h.el('enterBtn').click();
 for(const [x,y,expected] of [[44,2,'outskirts'],[92.9,10.15,'cedar'],[125.6,11.25,'sentinel']]){
   h.win.__WESTCAT_TEST__.teleport(x,y);h.run(4);
   assert.equal(h.doc.documentElement.dataset.chapter,expected);
   assert.equal(h.read().finished,false);
 }
});


test('owl proximity cue reports actual chase state, never obscures regular play or adds gameplay rules',async()=>{
 const h=await harness();h.el('enterBtn').click();
 assert.equal(h.el('chaseCue').hidden,true,'No chase HUD in the peaceful chapters');
 h.win.__WESTCAT_TEST__.teleport(110,10.15);h.run(5);
 assert.equal(h.el('chaseCue').hidden,false,'The chase must expose the observed owl gap');
 assert.ok(Number(h.el('chaseMeter').attrs['aria-valuenow'])>=14);
 h.run(110);
 assert.equal(h.el('chaseCue').classSet.has('urgent'),true,'The closer owl must be communicated without screen flash');
 assert.ok(parseFloat(h.el('chaseFill').style.width)<40);
 h.el('museumBtn').click();const previous=h.read().x;h.run(80);
 assert.equal(h.read().x,previous,'Mock museum opening must continue freezing the chase');
 h.el('enterBtn').click();h.run(2);
 h.win.__WESTCAT_TEST__.teleport(148.7,12.3);h.run(6);
 assert.equal(h.read().finished,true);assert.equal(h.el('chaseCue').hidden,true,'Victory removes the pursuit cue');
 h.el('replayBtn').click();assert.equal(h.el('chaseCue').hidden,true,'Replay leaves the HUD in initial state');
});
