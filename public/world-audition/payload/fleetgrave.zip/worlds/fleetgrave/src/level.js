export const DECKS = [
    { id: 'picket-spine', x: 10, z: 0, length: 65, width: 15, top: 0, kind: 'hull', ship: 'Picket' }, // -22.5...42.5
    { id: 'salvage-alpha', x: 49, z: 0, length: 13, width: 11, top: 0.65, kind: 'salvage', ship: 'Picket' }, // 42.5...55.5
    { id: 'salvage-beta', x: 63, z: 2.0, length: 13, width: 10, top: 1.3, kind: 'salvage', ship: 'Picket' }, // 56.5...69.5
    { id: 'salvage-gamma', x: 78.0, z: 0, length: 12, width: 10, top: 1.9, kind: 'salvage', ship: 'Lance' }, // 72...84
    { id: 'lance-spine', x: 122.0, z: 0, length: 74, width: 16, top: 2.8, kind: 'hull', ship: 'Lance' }, // 85...159
    { id: 'engine-truss', x: 168.5, z: 0, length: 16, width: 12, top: 3.6, kind: 'engine', ship: 'Lance' }, // 160.5..176.5
    { id: 'impulse-pad', x: 185.5, z: 0, length: 15, width: 11, top: 4.0, kind: 'engine', ship: 'Lance' }, // 178..193
    { id: 'throat-bridge', x: 219.5, z: 0, length: 34, width: 9.2, top: 5.35, kind: 'bridge', ship: 'Tender' }, // 202.5..236.5 (gap 9.5)
    { id: 'tender-spine', x: 272, z: 0, length: 70, width: 18, top: 6.2, kind: 'hull', ship: 'Tender' }, // 237..307
    { id: 'observation-gantry', x: 316.5, z: 0, length: 17, width: 13, top: 7.05, kind: 'engine', ship: 'Tender' }, // 308..325
    { id: 'final-overlook', x: 343, z: 0, length: 36, width: 23, top: 8.15, kind: 'overlook', ship: 'Tender' }, // 325..361
];
export const CHECKPOINTS = [
    { x: -12, z: 0, y: 0, deck: 'picket-spine', name: 'Picket / Watchline' },
    { x: 74, z: 0, y: 1.9, deck: 'salvage-gamma', name: 'Salvage / Assembly' },
    { x: 122, z: 0, y: 2.8, deck: 'lance-spine', name: 'Lance / Fireline' },
    { x: 187, z: 0, y: 4.0, deck: 'impulse-pad', name: 'Magnetic impulse' },
    { x: 250, z: 0, y: 6.2, deck: 'tender-spine', name: 'Tender / Haven' },
    { x: 334, z: 0, y: 8.15, deck: 'final-overlook', name: 'The last horizon' },
];
export const FINISH_X = 349;
export const MIN_X = -22.5;
export const MAX_X = 361;
export const PLAYER_RADIUS = 0.66;
export function withinDeck(deck, x, z, margin = 0) {
    return x >= deck.x - deck.length / 2 - margin && x <= deck.x + deck.length / 2 + margin &&
        z >= deck.z - deck.width / 2 - margin && z <= deck.z + deck.width / 2 + margin;
}
export function getSupport(x, z, feet, tolerance = 0.26) {
    let found;
    for (const deck of DECKS) {
        if (Math.abs(feet - deck.top) > tolerance || !withinDeck(deck, x, z, PLAYER_RADIUS * 0.4))
            continue;
        if (!found || deck.top > found.top)
            found = deck;
    }
    return found;
}
export function getLanding(x, z, prevFeet, feet, velocityY) {
    if (velocityY > 0)
        return undefined;
    let highest;
    for (const deck of DECKS) {
        if (!withinDeck(deck, x, z, PLAYER_RADIUS * 0.42))
            continue;
        if (prevFeet >= deck.top - 0.08 && feet <= deck.top + 0.13 && (!highest || deck.top > highest.top))
            highest = deck;
    }
    return highest;
}
export function chapterAt(x) {
    if (x < 68)
        return { id: 'picket', title: 'THE WATCHLINE', description: 'Picket · shielding the approach', ordinal: '01 / 04' };
    if (x < 180)
        return { id: 'lance', title: 'THE FIRELINE', description: 'Lance · a long, broken spear', ordinal: '02 / 04' };
    if (x < 241)
        return { id: 'throat', title: 'BETWEEN TITANS', description: 'Magnetic crossing · the breathing hulls', ordinal: '03 / 04' };
    return { id: 'tender', title: 'THE HAVEN', description: 'Tender · the fleet held together', ordinal: '04 / 04' };
}
/** E28 museum numbers are documentary reference only, NEVER player health or combat stats. */
export const E28_REFERENCE = {
    Picket: { colour: 0x5fb0e8, attack: 2, shield: 4, hull: 10 },
    Lance: { colour: 0xd9543a, attack: 6, shield: 1, hull: 7 },
    Tender: { colour: 0x7fd67f, attack: 0, shield: 3, hull: 12 },
    readouts: ['Power', 'Hull integrity', 'Threat', 'Supply'],
};
