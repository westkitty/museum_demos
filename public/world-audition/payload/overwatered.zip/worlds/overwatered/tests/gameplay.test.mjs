import test from 'node:test';
import assert from 'node:assert/strict';
import { GardenSimulation } from '../src/simulation.ts';
import { CAN, CHECKPOINTS, DEW, STATIONS, SUMMIT, SURFACES, surfaceUnlocked, safeCourseGeometry } from '../src/course.ts';
const DT=1/60;
const run=(g,n,input={})=>{let events=[];for(let i=0;i<n;i++)events.push(...g.step(DT,input));return events;};
const near=(g,pos,grounded=true)=>{g.state.player.position={x:pos.x,y:pos.y,z:pos.z};g.state.player.velocity={x:0,y:0,z:0};g.state.player.grounded=grounded;g.state.player.gliding=false;};
const grow=(g,i)=>{
  const station=STATIONS[i-1];near(g,station);
  // Replenishment is explicitly available next to every growing station.
  if(g.state.water<1||g.state.power<18){near(g,DEW[i-1]);run(g,1);near(g,station);}
  assert.equal(g.water(),true,`stage ${i} must grow`);
  assert.equal(g.state.grown,i);
  g.drainEvents();
};

test('course has three ordered, reachable authored growth segments and a distinct glide island',()=>{
  assert.equal(safeCourseGeometry(),true);
  assert.equal(STATIONS.length,3);
  assert.equal(SURFACES.filter(s=>s.stage===1).length,4);
  assert.equal(SURFACES.filter(s=>s.stage===2).length,5);
  assert.equal(SURFACES.filter(s=>s.stage===3).length,8);
  assert.equal(SURFACES.filter(s=>s.look==='island').length,1);
  assert.ok(CAN.z>SUMMIT.z+70);
  assert.ok(!surfaceUnlocked(SURFACES[0],0));
  assert.ok(surfaceUnlocked(SURFACES[0],1));
});

test('one Water action grows the first stage and protects order and resources',()=>{
  const g=new GardenSimulation();g.start();
  assert.equal(g.water(),false,'Watering from the spawn point is not permitted');
  near(g,STATIONS[1]);assert.equal(g.water(),false,'Station two cannot be used first');
  near(g,STATIONS[0]);assert.equal(g.water(),true);
  assert.equal(g.state.grown,1);assert.equal(g.state.water,1);assert.equal(g.state.power,70);
  assert.equal(g.state.checkpoint,1);
  assert.equal(g.water(),false,'Repeat use at the first station must not spend more water');
});

test('renewable dew prevents all permanent resource softlocks',()=>{
  const g=new GardenSimulation();g.start();
  g.state.water=0;g.state.power=0;
  near(g,STATIONS[0]);assert.equal(g.water(),false);
  near(g,DEW[0]);run(g,1);
  assert.equal(g.state.water,1);assert.equal(g.state.power,24);
  near(g,STATIONS[0]);assert.equal(g.water(),true);
  g.state.water=0;g.state.power=0;
  near(g,DEW[0]);run(g,60);
  assert.equal(g.state.water,0,'condenser has a real short cooldown');
  run(g,600);
  assert.ok(g.state.water>=1,'condenser always regenerates');
});

test('all three stages can be activated in order with checkpoints',()=>{
  const g=new GardenSimulation();g.start();
  for(let i=1;i<=3;i++)grow(g,i);
  assert.equal(g.state.grown,3);assert.equal(g.state.checkpoint,3);
  assert.equal(g.state.seedTime.filter(x=>x>=0).length,3);
  assert.equal(g.water(),false,'no imaginary fourth seed');
});

test('jump arc lands on an actual grown leaf, not an intangible painted prop',()=>{
  const g=new GardenSimulation();g.start();grow(g,1);
  near(g,{x:0,y:0,z:2});
  run(g,1,{jumpPressed:true,jumpHeld:true});
  assert.ok(g.state.player.position.y>0,'jump launched');
  run(g,88);
  assert.ok(Math.abs(g.state.player.position.y-2.1)<.05,`landed on the stage leaf: ${g.state.player.position.y}`);
  assert.equal(g.state.player.grounded,true);
});

test('vines support stamina-free vertical climbing',()=>{
  const g=new GardenSimulation();g.start();grow(g,1);
  near(g,{x:-.3,y:0,z:8});
  run(g,75,{forward:1,cameraYaw:Math.PI/2,jumpHeld:true});
  // The player ascends near the vine even though forward motion alone would not clear a tall stem.
  assert.ok(g.state.player.position.y>4.5,`vertical ascent ${g.state.player.position.y}`);
  assert.equal(g.state.water,1,'climbing consumes no water');
});

test('fall protection returns to latest checkpoint without erasing grown plants',()=>{
  const g=new GardenSimulation();g.start();grow(g,1);grow(g,2);
  near(g,{x:0,y:-19,z:88},false);run(g,1);
  assert.equal(g.state.deaths,1);
  assert.deepEqual(g.state.player.position,CHECKPOINTS[2]);
  assert.equal(g.state.grown,2);
});

test('summit unlocks a controllable long glide and finale must be earned',()=>{
  const g=new GardenSimulation();g.start();grow(g,1);grow(g,2);grow(g,3);
  near(g,SUMMIT);run(g,1);
  assert.equal(g.state.summitVisited,true);
  assert.equal(g.state.checkpoint,4);
  near(g,CAN);run(g,1);
  assert.equal(g.state.won,false,'can cannot be collected by skipping the glide');
  near(g,SUMMIT);
  run(g,1,{jumpPressed:true,jumpHeld:true});
  run(g,1,{glidePressed:true,forward:1});
  assert.equal(g.state.player.gliding,true);
  assert.equal(g.state.summitLaunch,true);
  run(g,290,{forward:1});
  assert.ok(g.state.longGlideDistance>43,`long glide covered ${g.state.longGlideDistance}`);
  assert.ok(g.state.player.position.z>130,'the island is reachable through gliding');
  // Align the final descent above the landing island; actual collision and victory checks still run.
  near(g,{x:CAN.x,y:25,z:CAN.z},false);
  g.state.summitLaunch=true;g.state.longGlideDistance=64;
  run(g,72);
  assert.equal(g.state.player.grounded,true);
  assert.equal(g.state.player.position.y,CAN.y);
  assert.equal(g.state.won,true);
  assert.equal(g.state.phase,'victory');
});

test('restart, save schema, and return session states are deterministic',()=>{
  const g=new GardenSimulation();g.start();grow(g,1);
  const snapshot=g.serialize();
  const second=new GardenSimulation();assert.equal(second.restore(snapshot),true);
  assert.equal(second.state.phase,'title');second.start();
  assert.equal(second.state.grown,1);
  assert.deepEqual(second.state.player.position,CHECKPOINTS[1]);
  assert.equal(second.restore({...snapshot,checkpoint:4}),false,'invalid progress cannot unlock later checkpoints');
  second.restart();assert.equal(second.state.grown,0);assert.equal(second.state.deaths,0);
  second.returnToMuseum();assert.equal(second.state.phase,'returned');
});

test('every consecutive 3D platform is independently jump-reachable',()=>{
  // Each segment gets a fresh deterministic initial state to isolate traversal failure.
  for(let i=0;i<SURFACES.length-2;i++){
    const from=SURFACES[i],to=SURFACES[i+1];
    const g=new GardenSimulation();g.start();g.state.grown=3;g.state.seedTime=[0,0,0];
    near(g,{x:from.x,y:from.top,z:from.z});
    let arrived=false;
    for(let frame=0;frame<130;frame++){
      const p=g.state.player.position;
      const dx=to.x-p.x,dz=to.z-p.z;
      const distance=Math.hypot(dx,dz);
      g.step(DT,{forward:distance>1.3?1:0,cameraYaw:Math.atan2(dx,dz),jumpPressed:frame===0});
      if(Math.abs(p.y-to.top)<.08 && g.state.player.grounded && distance<Math.min(to.rx,to.rz)*.75){arrived=true;break;}
    }
    assert.ok(arrived,`${from.id} -> ${to.id} should be a reachable jump`);
  }
});

test('the finale succeeds with an actual simulated jump, glider, braking, folding, and landing',()=>{
  const g=new GardenSimulation();g.start();grow(g,1);grow(g,2);grow(g,3);
  near(g,SUMMIT);run(g,1);
  let folded=false,won=false;
  for(let frame=0;frame<800;frame++){
    const p=g.state.player.position;
    const controls={forward:0,cameraYaw:Math.atan2(CAN.x-p.x,CAN.z-p.z),jumpPressed:false,glidePressed:false};
    if(frame===0){controls.jumpPressed=true;controls.forward=1;}
    else if(frame===1){controls.glidePressed=true;controls.forward=1;}
    else if(p.z<139){controls.forward=1;}
    else if(p.z<146){controls.forward=0;}
    else if(!folded){controls.glidePressed=true;folded=true;}
    g.step(DT,controls);
    if(g.state.won){won=true;break;}
    assert.equal(g.state.deaths,0,'successful glide should not require a respawn');
  }
  assert.equal(won,true,'glider must deliver the player to the final can');
  assert.ok(g.state.longGlideDistance>70,'finale is a long, user-controllable glide');
  assert.equal(g.state.player.position.y,CAN.y,'can island collision is real');
});
