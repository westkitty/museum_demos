import { mountMuseumE09 } from './game.js';
import { FUTURE_INTEGRATION_DESCRIPTOR } from './adapter.js';
const host = document.getElementById('museum-shell');
if (!host)
    throw new Error('Missing Museum E09 mount root');
const game = mountMuseumE09(host);
// Accessible test instrumentation. Never used for the ordinary visitor journey.
if (new URLSearchParams(window.location.search).get('qa') === '1') {
    Object.assign(window, { __museumQA: {
            snapshot: () => game.snapshot(),
            enter: () => game.enter(),
            teleportTo: (z) => game.debugTeleport(z),
            reset: () => game.reset(),
            dispose: () => game.dispose(),
            contract: FUTURE_INTEGRATION_DESCRIPTOR
        } });
}
window.addEventListener('pagehide', () => game.dispose(), { once: true });
export { mountMuseumE09 } from './game.js';
export { FUTURE_INTEGRATION_DESCRIPTOR } from './adapter.js';
