import * as THREE from 'three';
/** An anonymous guide-sculpture, not any canonical Museum of Me character. */
export class Visitor {
    group = new THREE.Group();
    body = new THREE.Group();
    head = new THREE.Group();
    leftLeg = new THREE.Group();
    rightLeg = new THREE.Group();
    leftArm = new THREE.Group();
    rightArm = new THREE.Group();
    mantleLeft = new THREE.Group();
    mantleRight = new THREE.Group();
    glowMaterials = [];
    ring;
    stride = 0;
    perceivedSpeed = 0;
    airborneBefore = false;
    landing = 0;
    elapsed = 0;
    constructor() {
        this.group.name = 'Anonymous Archive Walker';
        const porcelain = new THREE.MeshStandardMaterial({ color: 0xe5d9c3, roughness: .56, metalness: .16 });
        const mantle = new THREE.MeshStandardMaterial({ color: 0x263948, roughness: .65, metalness: .2 });
        const trim = new THREE.MeshStandardMaterial({ color: 0xb79b6a, roughness: .36, metalness: .72 });
        const boots = new THREE.MeshStandardMaterial({ color: 0x1a2730, roughness: .5, metalness: .34 });
        const luminous = new THREE.MeshStandardMaterial({ color: 0x8ae1de, emissive: 0x32c2da,
            emissiveIntensity: .62, roughness: .22, metalness: .42 });
        this.glowMaterials.push(luminous);
        const mesh = (parent, geo, m, x = 0, y = 0, z = 0) => {
            const object = new THREE.Mesh(geo, m);
            object.position.set(x, y, z);
            object.castShadow = true;
            object.receiveShadow = true;
            parent.add(object);
            return object;
        };
        this.group.add(this.body);
        // Curved ceremonial coat, pleated waist, and one distinctive continuous metallic seam.
        mesh(this.body, new THREE.CylinderGeometry(.3, .50, 1.15, 12), porcelain, 0, 1.3, 0);
        mesh(this.body, new THREE.ConeGeometry(.54, .58, 12, 1, true), mantle, 0, .73, 0).rotation.y = Math.PI / 12;
        mesh(this.body, new THREE.TorusGeometry(.39, .045, 8, 40), trim, 0, 1.65, 0).rotation.x = Math.PI / 2;
        mesh(this.body, new THREE.BoxGeometry(.65, .055, .09), luminous, 0, 1.67, -.37);
        mesh(this.body, new THREE.BoxGeometry(.12, .63, .06), trim, 0, 1.16, -.48);
        for (let i = 0; i < 4; i++)
            mesh(this.body, new THREE.BoxGeometry(.13, .07, .04), i === 3 ? luminous : trim, -.25 + i * .17, 1.43, -.51);
        // Two lightly articulated coat panels follow movement without modifying locomotion.
        for (const [panel, side] of [[this.mantleLeft, -1], [this.mantleRight, 1]]) {
            panel.position.set(side * .24, 1.08, .27);
            const piece = mesh(panel, new THREE.BoxGeometry(.33, .98, .14), mantle, 0, -.42, .06);
            piece.rotation.z = side * .12;
            mesh(panel, new THREE.BoxGeometry(.045, .88, .1), trim, -side * .14, -.38, -.02);
            this.body.add(panel);
        }
        // Face is a clean, unassigned sculpture, not a portrait of a museum subject.
        this.head.position.set(0, 2.02, 0);
        this.body.add(this.head);
        mesh(this.head, new THREE.IcosahedronGeometry(.35, 2), porcelain);
        mesh(this.head, new THREE.BoxGeometry(.38, .06, .06), boots, 0, .045, -.315);
        mesh(this.head, new THREE.TorusGeometry(.32, .035, 8, 32), luminous, 0, .14, 0).rotation.x = Math.PI / 2;
        mesh(this.head, new THREE.CylinderGeometry(.19, .28, .12, 10), trim, 0, .39, 0);
        // Engraved collar and paired shoulder guards produce a readable silhouette at distance.
        for (const side of [-1, 1]) {
            const arm = side < 0 ? this.leftArm : this.rightArm;
            arm.position.set(side * .42, 1.60, 0);
            const sleeve = mesh(arm, new THREE.CylinderGeometry(.13, .10, .70, 10), porcelain, 0, -.35, .02);
            sleeve.rotation.z = side * .07;
            mesh(arm, new THREE.IcosahedronGeometry(.16, 1), trim, 0, -.06, 0);
            mesh(arm, new THREE.BoxGeometry(.18, .16, .29), trim, 0, -.72, -.03);
            mesh(arm, new THREE.IcosahedronGeometry(.095, 1), luminous, 0, -.76, -.10);
            this.body.add(arm);
            const leg = side < 0 ? this.leftLeg : this.rightLeg;
            leg.position.set(side * .20, .87, 0);
            mesh(leg, new THREE.CylinderGeometry(.155, .145, .64, 10), boots, 0, -.34, 0);
            mesh(leg, new THREE.BoxGeometry(.29, .26, .47), boots, 0, -.73, -.10);
            mesh(leg, new THREE.BoxGeometry(.30, .055, .12), trim, 0, -.84, -.26);
            this.body.add(leg);
        }
        this.ring = mesh(this.group, new THREE.TorusGeometry(.64, .025, 5, 60), luminous, 0, .08, 0);
        this.ring.rotation.x = Math.PI / 2;
        this.ring.castShadow = false;
        this.ring.receiveShadow = false;
    }
    animate(dt, speed, airborne, reducedMotion) {
        dt = Math.max(0, Math.min(dt, .05));
        this.elapsed += dt;
        this.perceivedSpeed += (Math.max(0, speed) - this.perceivedSpeed) * (1 - Math.exp(-dt * 12));
        const moving = Math.min(1, this.perceivedSpeed / 5.5);
        if (!airborne && this.airborneBefore)
            this.landing = .23;
        this.airborneBefore = airborne;
        this.landing = Math.max(0, this.landing - dt);
        if (reducedMotion) {
            this.body.position.y = 0;
            this.body.rotation.set(0, 0, 0);
            this.leftLeg.rotation.x = this.rightLeg.rotation.x = 0;
            this.leftArm.rotation.x = this.rightArm.rotation.x = 0;
            this.mantleLeft.rotation.x = this.mantleRight.rotation.x = 0;
            this.head.rotation.set(0, 0, 0);
            this.ring.scale.setScalar(1);
            this.glowMaterials[0].emissiveIntensity = .55;
            return;
        }
        this.stride += dt * this.perceivedSpeed * 2.55;
        const walk = Math.sin(this.stride);
        const gait = airborne ? .20 : Math.min(.60, moving * .52);
        this.leftLeg.rotation.x = walk * gait;
        this.rightLeg.rotation.x = -walk * gait;
        this.leftArm.rotation.x = -walk * gait * .66 - (airborne ? .22 : 0);
        this.rightArm.rotation.x = walk * gait * .66 - (airborne ? .22 : 0);
        const bob = airborne ? -.065 : Math.abs(Math.sin(this.stride)) * .062 * moving;
        const landingSquash = this.landing > 0 ? Math.sin(this.landing / .23 * Math.PI) * .14 : 0;
        this.body.position.y = bob - landingSquash + Math.sin(this.elapsed * 1.7) * .012 * (1 - moving);
        this.body.rotation.x = airborne ? -.11 : -.045 * moving;
        this.body.rotation.z = Math.sin(this.stride * .5) * moving * .023;
        this.head.rotation.y = Math.sin(this.elapsed * .43) * .058 * (1 - moving);
        this.head.rotation.x = -this.body.rotation.x * .65;
        this.mantleLeft.rotation.x = -moving * .22 + Math.sin(this.elapsed * 3 + 1) * .055;
        this.mantleRight.rotation.x = -moving * .22 + Math.sin(this.elapsed * 3 + 2) * .055;
        this.ring.scale.setScalar(1 + Math.sin(this.elapsed * 2) * .022);
        this.glowMaterials[0].emissiveIntensity = .60 + Math.sin(this.elapsed * 1.5) * .12;
    }
    dispose() {
        const geometries = new Set(), materials = new Set();
        this.group.traverse(o => {
            if (o instanceof THREE.Mesh) {
                geometries.add(o.geometry);
                for (const m of Array.isArray(o.material) ? o.material : [o.material])
                    materials.add(m);
            }
        });
        geometries.forEach(g => g.dispose());
        materials.forEach(m => m.dispose());
        this.group.clear();
    }
}
