import * as THREE from 'three';
import { collectWaterCells, HYDROLOGY_GRID_SIZE } from '../core/simulation.js';
import { heightAt } from '../core/math.js';
/** 26x26 bounded moisture field; only saturated cells become visible glistening pools. */
export class WatershedVisual {
    mesh;
    clock = 99;
    cached = '';
    constructor(scene, quality) {
        const count = quality === 'low' ? 13 : HYDROLOGY_GRID_SIZE;
        const poolMat = new THREE.MeshPhysicalMaterial({ color: 0x4a8292, roughness: .12, metalness: .32, clearcoat: .85, transparent: true, opacity: .63, depthWrite: false, side: THREE.DoubleSide });
        const g = new THREE.PlaneGeometry(1, 1);
        g.rotateX(-Math.PI / 2);
        this.mesh = new THREE.InstancedMesh(g, poolMat, count * count);
        this.mesh.userData.feature = 'hydrology-overlay';
        this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.mesh.renderOrder = 1;
        this.mesh.frustumCulled = false;
        scene.add(this.mesh);
        this.count = count;
    }
    count;
    rebuild(s) {
        const cells = collectWaterCells(s), N = this.count, full = HYDROLOGY_GRID_SIZE, dummy = new THREE.Object3D(), tint = new THREE.Color();
        for (let z = 0; z < N; z++)
            for (let x = 0; x < N; x++) {
                const ox = Math.round(x / (N - 1) * (full - 1)), oz = Math.round(z / (N - 1) * (full - 1));
                const water = cells[oz * full + ox], wx = (x / (N - 1) - .5) * 226, wz = (z / (N - 1) - .5) * 226;
                const visible = Math.max(0, (water - .68) / .32);
                dummy.position.set(wx, heightAt(wx, wz, s) + .16, wz);
                dummy.scale.set(visible * .85 * 226 / (N - 1), 1, visible * .85 * 226 / (N - 1));
                dummy.updateMatrix();
                this.mesh.setMatrixAt(z * N + x, dummy.matrix);
                tint.setHSL(.49, .25 + visible * .12, .28 + visible * .24);
                this.mesh.setColorAt(z * N + x, tint);
            }
        this.mesh.instanceMatrix.needsUpdate = true;
        if (this.mesh.instanceColor)
            this.mesh.instanceColor.needsUpdate = true;
    }
    update(dt, s) {
        this.clock += dt;
        if (this.clock < 1.2)
            return;
        this.clock = 0;
        const key = JSON.stringify([s.rivers, s.terrain, Math.round(s.soilWater * 12)]);
        if (this.cached === key)
            return;
        this.cached = key;
        this.rebuild(s);
    }
}
