import * as THREE from '../vendor/build/three.module.js';
import { PLATFORMS, SWITCHES, EXIT, MOVE_SPEED, top } from './logic.js';
const C = {
    outline: 0x21283e, ink: 0x26243c, plum: 0x4c405c, purple: 0x7861a6,
    paper: 0xffedcc, porcelain: 0xf9d5b2, cream: 0xffe9c3, chalk: 0xfff4e1,
    coral: 0xf16c67, peach: 0xfba778, yellow: 0xffc762, lime: 0xc8e08c,
    teal: 0x4da999, aqua: 0x9adad1, blue: 0x6f93b5, lavender: 0xb8acd9,
    night: 0x232541, indigo: 0x3c375d, gold: 0xffdc8f,
    lacquer: 0x322740, berry: 0xc85071, mint: 0xd5f2c8, shell: 0xfff7df, deepTeal: 0x206f77, softBlue: 0x9ebbdc
};
function rng(seed) { let n = seed >>> 0; return () => ((n = (Math.imul(n, 1664525) + 1013904223) >>> 0) / 4294967296); }
function clamp01(x) { return Math.max(0, Math.min(1, x)); }
function ease(x) { const t = clamp01(x); return t * t * (3 - 2 * t); }
function mat(color, extras = {}) { return new THREE.MeshStandardMaterial({ color, roughness: .82, metalness: .04, flatShading: true, ...extras }); }
function basic(color, extras = {}) { return new THREE.MeshBasicMaterial({ color, ...extras }); }
function cylinder(rt, rb, length, color, radial = 12) {
    return new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, length, radial, 1), mat(color));
}
function blob(radius, color, scale = [1, 1, 1]) {
    const m = new THREE.Mesh(new THREE.IcosahedronGeometry(radius, 2), mat(color));
    m.scale.set(...scale);
    return m;
}
function ellipse(radius, color, sx = 1, sy = 1, sz = 1) { const o = new THREE.Mesh(new THREE.SphereGeometry(radius, 16, 10), mat(color)); o.scale.set(sx, sy, sz); return o; }
function prism(w, h, d, r, material) {
    const s = new THREE.Shape(), a = -w / 2, b = -h / 2;
    const q = Math.max(.01, Math.min(r, w / 2 - .015, h / 2 - .015));
    s.moveTo(a + q, b);
    s.lineTo(a + w - q, b);
    s.quadraticCurveTo(a + w, b, a + w, b + q);
    s.lineTo(a + w, b + h - q);
    s.quadraticCurveTo(a + w, b + h, a + w - q, b + h);
    s.lineTo(a + q, b + h);
    s.quadraticCurveTo(a, b + h, a, b + h - q);
    s.lineTo(a, b + q);
    s.quadraticCurveTo(a, b, a + q, b);
    return new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: d, bevelEnabled: true, bevelSegments: 1, steps: 1, bevelSize: .09, bevelThickness: .09, curveSegments: 5 }), material);
}
function ring(radius, tube, color, segments = 40) { return new THREE.Mesh(new THREE.TorusGeometry(radius, tube, 8, segments), mat(color)); }
function beam(x, y, z, w, h, d, color) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(color)); m.position.set(x, y, z); return m; }
function addAt(group, mesh, x, y, z) { mesh.position.set(x, y, z); group.add(mesh); return mesh; }
function curvedStrand(points, color, radius = .11) { const curve = new THREE.CatmullRomCurve3(points); return new THREE.Mesh(new THREE.TubeGeometry(curve, Math.max(12, points.length * 6), radius, 5, false), mat(color)); }
function petal(color, length, width) { const g = blob(1, color, [width / 2, length / 2, .18]); return g; }
function flag(group, x, y, z, color, height = 3) {
    addAt(group, cylinder(.07, .07, height, C.ink, 8), x, y + height / 2, z);
    const f = new THREE.Mesh(new THREE.ConeGeometry(.75, 1.65, 3), mat(color));
    f.rotation.set(0, 0, -Math.PI / 2);
    f.position.set(x + .78, y + height - .6, z);
    group.add(f);
}
function windowGroup(x, y, z, color) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    const frame = prism(2.5, 3.7, .35, 1.03, mat(C.ink));
    group.add(frame);
    const glass = prism(1.85, 2.9, .38, .86, mat(color, { emissive: color, emissiveIntensity: .12 }));
    glass.position.set(0, .03, .28);
    group.add(glass);
    group.add(beam(0, -.08, .78, .16, 2.6, .13, C.ink));
    group.add(beam(0, -1.48, .72, 2.4, .24, .2, C.porcelain));
    return { group, glass };
}
function createTextBillboard(text, w, h, fill = '#fff2d1') {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, 512, 128);
    ctx.strokeStyle = '#352842';
    ctx.lineWidth = 14;
    ctx.strokeRect(10, 10, 492, 108);
    ctx.fillStyle = '#392d4c';
    ctx.font = '900 47px Georgia,serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 256, 65, 464);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    const card = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide }));
    card.userData.ownedTexture = texture;
    return card;
}
function lantern(color) {
    const group = new THREE.Group();
    group.add(cylinder(.16, .2, 2.1, C.ink));
    const bulb = ellipse(.65, color, .76, 1.0, .72);
    bulb.position.y = 1.2;
    group.add(bulb);
    const top = new THREE.Mesh(new THREE.ConeGeometry(.8, .7, 8), mat(C.ink));
    top.position.y = 1.9;
    group.add(top);
    return group;
}
export function createWorld(host) {
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    const deviceMemory = navigator.deviceMemory ?? 8;
    const nativeRatio = Math.min(window.devicePixelRatio || 1, deviceMemory <= 3 ? 1.15 : 1.75);
    let qualityRatio = nativeRatio;
    let overloadedFor = 0;
    renderer.setPixelRatio(qualityRatio);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.10;
    renderer.setClearColor(C.paper);
    renderer.shadowMap.enabled = false;
    const canvas = renderer.domElement;
    canvas.id = 'scene';
    canvas.setAttribute('aria-hidden', 'true');
    host.appendChild(canvas);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xeed8ba);
    // A single painted-sky shader replaces overlapping full-screen haze passes.
    // Its color gradients respond directly to the authored Dusk switch.
    const skyUniforms = { uDusk: { value: 0 }, uTime: { value: 0 } };
    const skyMaterial = new THREE.ShaderMaterial({
        uniforms: skyUniforms, depthWrite: false, depthTest: false, toneMapped: false,
        vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
        fragmentShader: `
      precision mediump float;
      varying vec2 vUv;uniform float uDusk;uniform float uTime;
      float hash(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
      void main(){
        float y=clamp((vUv.y-.13)/.78,0.,1.);
        vec3 day=mix(vec3(1.0,.89,.70),vec3(.48,.72,.76),smoothstep(.04,.96,y));
        day=mix(day,vec3(1.0,.76,.66),.12*exp(-pow((y-.4)*6.,2.)));
        vec3 night=mix(vec3(.87,.40,.47),vec3(.095,.11,.26),smoothstep(.10,.86,y));
        night+=vec3(.22,.075,.095)*exp(-pow((y-.37)*8.,2.));
        vec3 rgb=mix(day,night,smoothstep(0.,1.,uDusk));
        float band=sin(y*34.+sin(vUv.x*16.)*.25)*.009;
        float paper=(hash(floor(vUv*vec2(1300.,760.)))-.5)*.018;
        float glimmer=exp(-pow((vUv.x-.43)*3.7,2.)-pow((y-.48)*8.,2.))*.07;
        rgb+=vec3(band+paper+glimmer*(1.-uDusk),band+paper*.6,band*.58+paper*.5);
        gl_FragColor=vec4(clamp(rgb,0.,1.),1.);
      }`
    });
    const paintedSky = new THREE.Mesh(new THREE.PlaneGeometry(1250, 260), skyMaterial);
    paintedSky.position.set(120, 27, -137);
    paintedSky.frustumCulled = false;
    paintedSky.renderOrder = -10000;
    scene.add(paintedSky);
    const camera = new THREE.OrthographicCamera(-16, 16, 9, -9, .1, 500);
    const hemi = new THREE.HemisphereLight(0xfff7dd, 0x6b789b, 2.4);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffe7bd, 2.9);
    sun.position.set(-45, 72, 60);
    scene.add(sun);
    // Explicitly scoped highlights: low-cost sculpted light without shadow maps.
    const duskLight = new THREE.PointLight(0xffad79, 5, 74, 2);
    duskLight.position.set(117, 27, 12);
    scene.add(duskLight);
    const moonLight = new THREE.DirectionalLight(0x9ab4ff, 0);
    moonLight.position.set(180, 70, 45);
    scene.add(moonLight);
    const fillLight = new THREE.DirectionalLight(0xffe4c5, 1.15);
    fillLight.position.set(65, 17, -22);
    scene.add(fillLight);
    const main = new THREE.Group();
    scene.add(main);
    const back = new THREE.Group();
    scene.add(back);
    const stageGroups = [new THREE.Group(), new THREE.Group(), new THREE.Group(), new THREE.Group()];
    stageGroups.forEach(g => main.add(g));
    const gates = new THREE.Group();
    main.add(gates);
    const figures = new THREE.Group();
    figures.name = 'forbiddenPeople';
    main.add(figures);
    const letters = new THREE.Group();
    letters.name = 'forbiddenWorldText';
    main.add(letters);
    const windows = [];
    const glowMaterials = [];
    const glows = [];
    const glowCanvas = document.createElement('canvas');
    glowCanvas.width = 128;
    glowCanvas.height = 128;
    const glowCtx = glowCanvas.getContext('2d');
    const radial = glowCtx.createRadialGradient(64, 64, 3, 64, 64, 62);
    radial.addColorStop(0, 'rgba(255,246,203,0.91)');
    radial.addColorStop(.16, 'rgba(255,205,145,0.48)');
    radial.addColorStop(.44, 'rgba(242,126,120,0.17)');
    radial.addColorStop(1, 'rgba(255,157,128,0)');
    glowCtx.fillStyle = radial;
    glowCtx.fillRect(0, 0, 128, 128);
    const glowTexture = new THREE.CanvasTexture(glowCanvas);
    glowTexture.colorSpace = THREE.SRGBColorSpace;
    function softGlow(parent, x, y, z, size, power = 1) {
        const material = new THREE.SpriteMaterial({ map: glowTexture, transparent: true, opacity: 0, depthTest: true, depthWrite: false, blending: THREE.AdditiveBlending, color: 0xffdfb1 });
        const sprite = new THREE.Sprite(material);
        sprite.position.set(x, y, z);
        sprite.scale.set(size, size, 1);
        parent.add(sprite);
        glows.push(parent);
        glowMaterials.push(material);
        material.userData.power = power;
        return sprite;
    }
    const accents = [];
    const motifs = [];
    const checkpointBeacons = [];
    const lights = [];
    const balloons = [];
    const platforms = new Map();
    let stage = 0, visualDusk = 0, visualWide = 0, visualConstraints = 0;
    let aspect = 16 / 9, camX = 8, camY = 5, camScale = 1;
    let cameraImpulse = 0;
    let lastGrounded = true, landSquash = 0, jumpStretch = 0;
    let bannerPulse = 0;
    let reduced = false;
    const colorDay = new THREE.Color(0xedd8b8), colorNight = new THREE.Color(0x242c4f);
    const tempColor = new THREE.Color(), target = new THREE.Vector3();
    const duskColor = new THREE.Color(0xbcc8fa), warmColor = new THREE.Color(0xffb586);
    // --------- sky as architectural stage flats, celestial diorama and parallax ----------
    const sunHalo = new THREE.Group();
    back.add(sunHalo);
    sunHalo.position.set(72, 38, -92);
    addAt(sunHalo, new THREE.Mesh(new THREE.CircleGeometry(12, 64), basic(C.yellow)), 0, 0, -.5);
    const sr = ring(14, .38, C.peach, 72);
    sr.material = new THREE.MeshBasicMaterial({ color: C.peach, transparent: true, opacity: .65 });
    sunHalo.add(sr);
    for (let i = 0; i < 18; i++) {
        const theta = i / 18 * Math.PI * 2;
        const bar = beam(Math.sin(theta) * 16, Math.cos(theta) * 16, 0, .32, 2.35, .1, C.chalk);
        bar.rotation.z = -theta;
        sunHalo.add(bar);
    }
    const moon = new THREE.Group();
    moon.position.set(171, 53, -91);
    back.add(moon);
    addAt(moon, new THREE.Mesh(new THREE.CircleGeometry(9, 64), basic(0xf3e3cd)), 0, 0, 0);
    const halo = ring(11.8, .18, C.lavender, 72);
    moon.add(halo);
    for (let i = 0; i < 6; i++) {
        const p = ellipse(.85, C.paper, 1.1, 1.1, .2);
        p.position.set(Math.cos(i * 1.05) * 4, Math.sin(i * 1.05) * 4, .4);
        moon.add(p);
    }
    const starPositions = [];
    const random = rng(1409);
    for (let i = 0; i < 480; i++)
        starPositions.push(-110 + random() * 570, 3 + random() * 100, -85 - random() * 32);
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
    const starMat = new THREE.PointsMaterial({ color: 0xfff4d1, size: 2.5, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false });
    const stars = new THREE.Points(starGeo, starMat);
    back.add(stars);
    const mountainColors = [C.lavender, C.aqua, C.teal];
    for (let layer = 0; layer < 3; layer++) {
        const z = -71 + layer * 13;
        const hillMat = mat(mountainColors[layer], { roughness: 1 });
        for (let i = 0; i < 23; i++) {
            const x = -58 + i * 18 + Math.sin(i * 1.9 + layer) * 4;
            const h = 8 + 6 * Math.abs(Math.sin(i * .83 + layer * 2));
            const m = prism(23, 13 + h, 1.3, 8, hillMat);
            m.position.set(x, -8 + h * .18, z);
            m.scale.y = 1 + Math.sin(i) * .1;
            back.add(m);
            if (layer === 1 && i % 4 === 0) {
                const dome = ellipse(2.8, C.cream, 1.7, .4, .2);
                dome.position.set(x + 3, h - 5, z + 2);
                back.add(dome);
            }
        }
    }
    // Giant railway of surreal office stationery is original decoration, not terrain.
    const cloudGroup = new THREE.Group();
    back.add(cloudGroup);
    for (let i = 0; i < 37; i++) {
        const x = -35 + i * 9.5, y = 22 + Math.sin(i * .73) * 11 + (i % 3) * 8, z = -43 - (i % 3) * 7;
        const g = new THREE.Group();
        g.position.set(x, y, z);
        cloudGroup.add(g);
        const m = mat(i % 4 === 0 ? C.porcelain : C.chalk, { roughness: 1 });
        for (let j = 0; j < 4; j++) {
            const e = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 9), m);
            e.scale.set(1.7 + ((j * 7 + i) % 3) * .6, .8 + ((j * 3 + i) % 4) * .17, .7);
            e.position.set(j * 1.75 - 3, Math.sin(j) * .25, 0);
            g.add(e);
        }
        if (i % 5 === 0) {
            const rr = ring(1.3, .14, C.ink);
            rr.position.set(-.3, -.7, 1);
            g.add(rr);
        }
        motifs.push({ mesh: g, speed: .08 + (i % 4) * .04, phase: i * .7, baseY: y, type: 'bob' });
    }
    // Hanging strings and floating golden cartographic points.
    for (let i = 0; i < 30; i++) {
        const x = -10 + i * 10.1, y = 22 + ((i * 7) % 5) * 4, z = -14 - (i % 3) * 9;
        const d = new THREE.Group();
        d.position.set(x, y, z);
        back.add(d);
        const tiny = ring(.45, .11, i % 2 ? C.coral : C.yellow);
        d.add(tiny);
        const mini = blob(.26, C.ink, [1, 1, .4]);
        d.add(mini);
        motifs.push({ mesh: d, speed: .22, phase: i * 1.8, baseY: y, type: 'bob' });
    }
    // --------- central impossible tower ----------
    const tower = new THREE.Group();
    tower.position.set(128, -.25, -25);
    back.add(tower);
    const towerBack = prism(32, 37, 7, 3, mat(C.ink));
    towerBack.position.set(0, 18, -3);
    tower.add(towerBack);
    const towerShell = prism(30, 36, 5, 2.7, mat(C.porcelain));
    towerShell.position.set(0, 18, .2);
    tower.add(towerShell);
    accents.push(towerShell.material);
    const baseLayer = prism(40, 8, 6, 2.5, mat(C.ink));
    baseLayer.position.set(0, 2, 1.2);
    tower.add(baseLayer);
    const baseFill = prism(38.4, 7.2, 6, 2.2, mat(C.teal));
    baseFill.position.set(0, 2, 1.4);
    tower.add(baseFill);
    accents.push(baseFill.material);
    for (let i = 0; i < 5; i++) {
        const x = -14.6 + i * 7.2;
        const rib = prism(1.1, 37, .8, .45, mat(C.chalk));
        rib.position.set(x, 18, 6);
        tower.add(rib);
        for (let j = 0; j < 2; j++) {
            const w = windowGroup(x + ((j + i) % 2 ? 2.1 : -2.1), 11 + j * 13, 7.12, j === 0 ? C.gold : C.aqua);
            tower.add(w.group);
            windows.push(w.glass);
        }
    }
    const upper = prism(21, 16, 5, 2.3, mat(C.ink));
    upper.position.set(0, 43, 0);
    tower.add(upper);
    const upperInner = prism(19.2, 14.5, 5.2, 2, mat(C.purple));
    upperInner.position.set(0, 43, .4);
    tower.add(upperInner);
    accents.push(upperInner.material);
    for (let i = -1; i <= 1; i++) {
        const w = windowGroup(i * 6.2, 42, 6.25, C.gold);
        w.group.scale.set(1.1, 1.5, 1);
        tower.add(w.group);
        windows.push(w.glass);
    }
    // A lacquered astronomical dial is the central readable silhouette of the tower.
    const dialBack = ring(7.4, .20, C.ink, 64);
    dialBack.position.set(0, 25, 6.95);
    tower.add(dialBack);
    const dialEtch = ring(6.85, .10, C.shell, 64);
    dialEtch.position.set(0, 25, 7.12);
    tower.add(dialEtch);
    for (let i = 0; i < 24; i++) {
        const a = i / 24 * Math.PI * 2;
        const tick = beam(Math.sin(a) * 6.65, 25 + Math.cos(a) * 6.65, 7.3, i % 3 === 0 ? .32 : .12, i % 3 === 0 ? .95 : .46, .13, i % 3 === 0 ? C.gold : C.ink);
        tick.rotation.z = -a;
        tower.add(tick);
    }
    softGlow(tower, 0, 25, 7.9, 16, .62);
    const centerOculus = ring(5.15, 1.05, C.yellow, 32);
    centerOculus.position.set(0, 25, 7.5);
    tower.add(centerOculus);
    const oculusCore = new THREE.Mesh(new THREE.CircleGeometry(3.6, 36), basic(C.ink));
    oculusCore.position.set(0, 25, 7.42);
    tower.add(oculusCore);
    const oculusOrbit = new THREE.Group();
    oculusOrbit.position.set(0, 25, 8);
    tower.add(oculusOrbit);
    for (let i = 0; i < 12; i++) {
        const th = i / 12 * Math.PI * 2;
        const lozenge = blob(.51, i % 3 ? C.aqua : C.coral, [1.45, .48, .4]);
        lozenge.position.set(Math.cos(th) * 4.05, Math.sin(th) * 4.05, 0);
        lozenge.rotation.z = th;
        oculusOrbit.add(lozenge);
    }
    motifs.push({ mesh: oculusOrbit, speed: .16, phase: 0, baseY: 25, type: 'spin' });
    for (let side of [-1, 1]) {
        const shaft = prism(8, 25, 6, 2.1, mat(C.chalk));
        shaft.position.set(side * 19, 23, -1);
        tower.add(shaft);
        const r = ring(4.35, .7, C.coral);
        r.position.set(side * 19, 35, 6);
        tower.add(r);
        const sungear = new THREE.Group();
        sungear.position.set(side * 19, 35, 6.1);
        tower.add(sungear);
        for (let i = 0; i < 8; i++) {
            const tooth = beam(Math.cos(i * Math.PI / 4) * 4, Math.sin(i * Math.PI / 4) * 4, .1, 1.4, 1.2, .5, C.ink);
            tooth.rotation.z = i * Math.PI / 4;
            sungear.add(tooth);
        }
        motifs.push({ mesh: sungear, speed: side * .14, phase: .2, baseY: 35, type: 'spin' });
    }
    // Interlocking roof scales; a silhouette motif distinct from ordinary castle battlements.
    const roofGroup = new THREE.Group();
    roofGroup.position.set(0, 54, 0);
    tower.add(roofGroup);
    const roofLine = new THREE.Mesh(new THREE.ConeGeometry(16, 11, 4), mat(C.coral));
    roofLine.rotation.y = Math.PI / 4;
    roofGroup.add(roofLine);
    for (let i = 0; i < 4; i++) {
        const fin = new THREE.Mesh(new THREE.ConeGeometry(2.7, 9, 7), mat(i % 2 ? C.yellow : C.teal));
        fin.position.set(-12 + i * 8.2, 7 + (i % 2) * 2, 0);
        roofGroup.add(fin);
        addAt(roofGroup, blob(.68, C.yellow), -12 + i * 8.2, 12 + (i % 2) * 2, 0);
    }
    // Ruffled paper valances, gold beaded rivets and a crown of miniature pennants.
    for (let i = 0; i < 11; i++) {
        const px = -16 + i * 3.2;
        const tooth = new THREE.Mesh(new THREE.ConeGeometry(1.9, 3.7, 3), mat(i % 2 ? C.berry : C.gold));
        tooth.rotation.z = Math.PI;
        tooth.position.set(px, 35, 5.9);
        tower.add(tooth);
        addAt(tower, ellipse(.25, C.chalk, .9, 1.2, .55), px, 36.8, 6.4);
    }
    for (let i = 0; i < 9; i++) {
        const height = 3.1 + (i % 3) * 1.3;
        flag(tower, -16.5 + i * 4.1, 57.4, 1.2, i % 2 ? C.teal : C.yellow, height);
    }
    const folding = new THREE.Group();
    tower.add(folding);
    const wingPivotL = new THREE.Group(), wingPivotR = new THREE.Group();
    wingPivotL.position.set(-16, 34, 4);
    wingPivotR.position.set(16, 34, 4);
    folding.add(wingPivotL, wingPivotR);
    for (const [side, pivot] of [[-1, wingPivotL], [1, wingPivotR]]) {
        const panel = prism(7, 17, 1.2, 3, mat(C.yellow));
        panel.position.set(side * 3.4, 0, 0);
        pivot.add(panel);
        for (let j = 0; j < 5; j++) {
            const stripe = beam(side * 3.4, -6 + j * 3, 1, 6, .32, .24, C.ink);
            pivot.add(stripe);
        }
        const loop = ring(3.1, .45, C.teal);
        loop.position.set(side * 5, 8, 2);
        pivot.add(loop);
    }
    for (let i = 0; i < 25; i++) {
        const x = -17 + (i % 7) * 5.4, y = 4 + Math.floor(i / 7) * 10;
        const candy = blob(.35, i % 2 ? C.yellow : C.coral, [1.3, .5, .5]);
        candy.position.set(x, y, 7.6);
        tower.add(candy);
    }
    // Blooming wings are a deliberately staged Dusk architectural reveal.
    for (const side of [-1, 1]) {
        const foldedPetals = new THREE.Group();
        foldedPetals.position.set(side * 16.3, 33.5, 6.2);
        folding.add(foldedPetals);
        for (let i = 0; i < 7; i++) {
            const a = -1.02 + i * .34;
            const piece = ellipse(2.4, i % 2 ? C.peach : C.gold, .36, 1.14, .21);
            piece.position.set(side * (3 + Math.cos(a) * 2.1), Math.sin(a) * 4, 0);
            piece.rotation.z = side * (a + .52);
            foldedPetals.add(piece);
        }
        const jewel = ring(2.1, .25, C.ink);
        jewel.position.set(side * 6, 0, .5);
        foldedPetals.add(jewel);
    }
    // Floating outer towers, reinforcing the single mighty subject.
    for (const [x, y, s] of [[79, 7, .7], [183, 10, .85], [215, 20, .62]]) {
        const g = new THREE.Group();
        g.position.set(x, y, -35);
        back.add(g);
        g.scale.setScalar(s);
        const b = prism(10, 24, 3, 2.3, mat(C.plum));
        g.add(b);
        const f = prism(9, 22, 3.4, 2.3, mat(C.lavender));
        f.position.set(0, 0, .35);
        g.add(f);
        const cap = new THREE.Mesh(new THREE.ConeGeometry(7, 9, 5), mat(C.yellow));
        cap.position.y = 15.7;
        g.add(cap);
        const w = windowGroup(0, 1, 3.7, C.yellow);
        g.add(w.group);
        windows.push(w.glass);
        for (let i = 0; i < 3; i++) {
            const f = ring(2.1, .31, C.ink);
            f.position.set(-3.5 + i * 3.5, -7, 4.2);
            g.add(f);
        }
    }
    // --------- authored collision terrain, with decorative skin shared by stage ----------
    for (const p of PLATFORMS) {
        const group = new THREE.Group();
        group.position.set(p.x, p.y, 0);
        stageGroups[p.stage].add(group);
        platforms.set(p.id, group);
        const shadow = prism(p.w + .55, p.h + .58, 3.3, .42, mat(C.ink));
        shadow.position.set(0, -.17, -1.28);
        group.add(shadow);
        const color = p.stage === 0 ? C.porcelain : p.stage === 1 ? C.purple : p.stage === 2 ? C.aqua : C.yellow;
        const block = prism(p.w, p.h, 3.55, .4, mat(color));
        block.position.set(0, 0, -1.17);
        group.add(block);
        const upper = beam(0, p.h / 2 - .12, .81, p.w - .16, .21, 3.4, p.stage < 2 ? C.chalk : C.cream);
        group.add(upper);
        const rim = beam(0, p.h / 2 - .24, 2.57, p.w - .24, .18, .16, C.ink);
        group.add(rim);
        // Glazed play surfaces have a continuous highlighted lip: unambiguous walkable edge.
        const enamel = beam(0, p.h / 2 + .04, 1.0, p.w - .48, .11, 3.16, p.stage === 0 ? C.mint : p.stage === 1 ? C.gold : p.stage === 2 ? C.shell : C.peach);
        group.add(enamel);
        const inset = beam(0, -.08, 2.47, p.w - .68, .055, .08, p.stage % 2 ? C.gold : C.deepTeal);
        group.add(inset);
        const capL = ellipse(.22, C.ink, .56, .9, .55);
        capL.position.set(-p.w / 2 + .33, p.h / 2, 2.52);
        group.add(capL);
        const capR = capL.clone();
        capR.position.x *= -1;
        group.add(capR);
        // Repeated heraldic reliefs are physically below the ledge, never part of collision.
        const rosetteCount = Math.min(6, Math.floor(p.w / 4.2));
        for (let j = 0; j < rosetteCount; j++) {
            const px = -p.w / 2 + (j + .5) * p.w / rosetteCount;
            const medallion = ring(.28, .055, j % 2 ? C.gold : C.deepTeal, 16);
            medallion.position.set(px, -p.h * .19, 2.71);
            group.add(medallion);
            addAt(group, blob(.095, C.ink, [1, .9, .46]), px, -p.h * .19, 2.82);
        }
        if (p.kind === 'bridge') {
            const brace = curvedStrand([new THREE.Vector3(-p.w / 2 + .4, -p.h * .4, -2.5), new THREE.Vector3(0, -2.45, -3.5), new THREE.Vector3(p.w / 2 - .4, -p.h * .4, -2.5)], C.ink, .22);
            group.add(brace);
            for (let k = 0; k < 3; k++)
                addAt(group, ring(.5, .11, C.coral), -p.w * .3 + k * p.w * .3, -1.6, -2.7);
        }
        const d = p.kind === 'bridge' ? 2.8 : 3.3;
        for (let i = 0; i < Math.max(2, Math.floor(p.w / d)); i++) {
            const x = -p.w / 2 + 2 + i * d;
            const rivet = blob(.18, C.ink, [.9, .9, .35]);
            rivet.position.set(x, -p.h / 2 + .25, 2.6);
            group.add(rivet);
            if (p.stage === 1 || p.stage === 2) {
                const pendant = new THREE.Mesh(new THREE.ConeGeometry(.33, 1.2, 4), mat(p.stage === 1 ? C.yellow : C.coral));
                pendant.position.set(x, -p.h / 2 - .55, 0);
                group.add(pendant);
            }
        }
        // Regular landmarks and short decorative towers on platform edges, never impede collisions.
        if (p.id !== 'prologue' && p.w > 15) {
            const towerlet = new THREE.Group();
            towerlet.position.set(-p.w / 2 + 1.65, p.h / 2 + .9, -2.6);
            group.add(towerlet);
            const stem = prism(1.9, 1.7, .9, .4, mat(C.ink));
            towerlet.add(stem);
            const cap = new THREE.Mesh(new THREE.ConeGeometry(1.45, 1.45, 5), mat(C.coral));
            cap.position.y = 1.35;
            towerlet.add(cap);
        }
    }
    // Stage flats punctuate the chapters without creating misleading collision surfaces.
    const chapterReliefs = [
        { stage: 0, x: 24, y: -1, z: -8, color: C.coral },
        { stage: 1, x: 86, y: 4, z: -9, color: C.gold },
        { stage: 2, x: 147, y: 7, z: -11, color: C.aqua },
        { stage: 3, x: 230, y: 15, z: -8, color: C.berry }
    ];
    for (const spec of chapterReliefs) {
        const g = new THREE.Group();
        g.position.set(spec.x, spec.y, spec.z);
        stageGroups[spec.stage].add(g);
        for (let k = 0; k < 5; k++) {
            const h = 6 + k % 3 * 2.1;
            const column = prism(1.8, h, .95, .85, mat(k % 2 ? C.chalk : spec.color));
            column.position.set(-5.2 + k * 2.6, h * .5, 0);
            g.add(column);
            const crown = ellipse(.72, C.ink, .8, .38, .45);
            crown.position.set(-5.2 + k * 2.6, h + .3, .7);
            g.add(crown);
            const finial = blob(.28, C.gold, [1, 1, .6]);
            finial.position.set(-5.2 + k * 2.6, h + .6, 1.0);
            g.add(finial);
        }
        const ribbon = curvedStrand([new THREE.Vector3(-5, 7.6, 1), new THREE.Vector3(-2.5, 10.2, .6), new THREE.Vector3(1.5, 8.9, .8), new THREE.Vector3(6.0, 10, 1)], spec.color, .18);
        g.add(ribbon);
    }
    // Border ledge with an inviting starting prologue, no opaque overlay on the terrain.
    const entryPlinth = new THREE.Group();
    entryPlinth.position.set(5.5, 0, 0);
    stageGroups[0].add(entryPlinth);
    for (let i = 0; i < 5; i++) {
        const disk = ring(.5 + i * .24, .08, i % 2 ? C.coral : C.yellow);
        disk.position.set(0, .11 + i * .04, 2.5);
        entryPlinth.add(disk);
    }
    // --------- locked gate ribbons visually match hard collision boundaries ----------
    const gateAt = [{ x: 67.6, y: 9.5, unlock: 1 }, { x: 112.3, y: 15.6, unlock: 2 }, { x: 190.55, y: 20.1, unlock: 3 }];
    const gateObjs = [];
    for (const [i, s] of gateAt.entries()) {
        const g = new THREE.Group();
        g.position.set(s.x, s.y, 1.1);
        gates.add(g);
        gateObjs.push(g);
        const pane = new THREE.Mesh(new THREE.BoxGeometry(.5, 10, 2.2), new THREE.MeshStandardMaterial({ color: i === 0 ? C.coral : i === 1 ? C.aqua : C.yellow, transparent: true, opacity: .25, emissive: C.yellow, emissiveIntensity: .25, depthWrite: false }));
        g.add(pane);
        for (let j = 0; j < 5; j++) {
            const r = ring(1.0 + (j % 2) * .35, .12, j % 2 ? C.ink : C.yellow);
            r.position.set(0, -3.65 + j * 1.8, 1.3);
            g.add(r);
        }
        flag(g, 0, 4.7, 0, i % 2 ? C.yellow : C.coral, 2);
    }
    // --------- three author-written instruction switches ----------
    const switchModels = [];
    for (const [i, s] of SWITCHES.entries()) {
        const g = new THREE.Group();
        g.position.set(s.x, s.footY + .9, 1.3);
        main.add(g);
        switchModels.push(g);
        const base = cylinder(1.1, 1.3, .5, C.ink);
        base.position.y = -.65;
        g.add(base);
        const core = blob(.92, [C.coral, C.aqua, C.yellow][i], [1.05, 1.16, .7]);
        g.add(core);
        const escutcheon = ring(.82, .08, C.chalk, 36);
        escutcheon.position.z = .63;
        g.add(escutcheon);
        // Each authorial switch has its own sculpted visual grammar, not just a color.
        if (i === 0) {
            const crescent = new THREE.Mesh(new THREE.TorusGeometry(.45, .105, 8, 28, Math.PI * 1.46), mat(C.gold));
            crescent.position.z = .8;
            g.add(crescent);
        }
        else if (i === 1) {
            for (const side of [-1, 1]) {
                const opener = ring(.44, .10, C.gold, 24);
                opener.position.set(side * .39, 0, .88);
                g.add(opener);
            }
        }
        else {
            for (let k = 0; k < 4; k++) {
                const petal = ellipse(.23, C.lacquer, .7, 1.7, .22);
                petal.position.set(Math.cos(k * Math.PI / 2) * .38, Math.sin(k * Math.PI / 2) * .38, .9);
                petal.rotation.z = k * Math.PI / 2;
                g.add(petal);
            }
        }
        softGlow(g, 0, 0, .55, 5.8, .85);
        const halo = ring(1.42, .16, C.ink);
        halo.position.z = .35;
        g.add(halo);
        const glow = ring(1.75, .12, [C.yellow, C.lavender, C.coral][i]);
        glow.position.z = .2;
        g.add(glow);
        const bolt = blob(.22, C.chalk, [1, 1, .5]);
        bolt.position.z = 1;
        g.add(bolt);
        motifs.push({ mesh: glow, speed: .9, phase: i * .6, baseY: 0, type: 'spin' });
        for (let j = 0; j < 4; j++) {
            const th = j * Math.PI / 2;
            const b = blob(.18, C.ink, [.7, 1, .5]);
            b.position.set(Math.cos(th) * 1.52, Math.sin(th) * 1.52, .5);
            g.add(b);
        }
    }
    // --------- real checkpoints: ceramic flags and soft light beacons ----------
    for (let i = 0; i < 4; i++) {
        const c = [{ x: 5.5, y: 0 }, { x: 59.2, y: 5.4 }, { x: 104.5, y: 10.7 }, { x: 182.5, y: 14.975 }][i];
        const group = new THREE.Group();
        group.position.set(c.x, c.y, -1.6);
        main.add(group);
        checkpointBeacons.push(group);
        const post = cylinder(.10, .14, 2.0, C.ink);
        post.position.y = 1.1;
        group.add(post);
        const point = new THREE.Mesh(new THREE.ConeGeometry(.95, 1.3, 4), mat(i === 0 ? C.teal : C.yellow));
        point.rotation.z = -Math.PI / 2;
        point.position.set(.8, 1.6, 0);
        group.add(point);
        const loop = ring(.36, .13, C.coral);
        loop.position.set(0, .3, 1.7);
        group.add(loop);
        const foot = ellipse(.24, C.gold, 2.0, .25, .8);
        foot.position.set(0, -.03, .6);
        group.add(foot);
        softGlow(group, 0, 1.3, 1, 4.0, .43);
    }
    // --------- forbidden in-world people (cutouts), and forbidden text billboards ----------
    for (let i = 0; i < 12; i++) {
        const x = 19 + i * 14.7, y = i < 4 ? -1.7 : i < 7 ? 5 : 9.2;
        const p = new THREE.Group();
        p.position.set(x, y, -9 - i % 3 * 2);
        figures.add(p);
        const dark = i % 2 ? C.plum : C.ink;
        const head = ellipse(.85, dark, 1, 1, .45);
        head.position.y = 3.25;
        p.add(head);
        const body = prism(1.6, 2.6, .4, .56, mat(dark));
        body.position.y = 1.4;
        p.add(body);
        const legA = beam(-.35, -.5, 0, .4, 1.8, .35, dark), legB = beam(.35, -.5, 0, .4, 1.8, .35, dark);
        p.add(legA, legB);
        const armA = beam(-.95, 1.4, 0, .4, 1.6, .35, dark);
        armA.rotation.z = .31;
        const armB = beam(.95, 1.4, 0, .4, 1.6, .35, dark);
        armB.rotation.z = -.31;
        p.add(armA, armB);
        p.scale.setScalar(.5 + (i % 3) * .14);
    }
    for (const [i, desc] of [{ t: 'INSERT HERO', x: 18, y: 8 }, { t: 'A TOWER', x: 79, y: 16 }, { t: 'DRAFT THE SKY', x: 160, y: 22 }, { t: 'PLEASE ADD TEXT', x: 202, y: 27 }].entries()) {
        const s = createTextBillboard(desc.t, 11.5, 2.85, i % 2 ? '#ffeecc' : '#e8f4df');
        s.position.set(desc.x, desc.y, -11);
        letters.add(s);
        const wire = beam(desc.x, desc.y + 2.5, -11, .13, 2.2, .13, C.ink);
        letters.add(wire);
    }
    // --------- floor-garden, windsocks, paper blossoms, tiny mechanisms ---------
    // Botanical ornament is batched per stage into instanced petals and stems.
    // This replaces hundreds of separate draw calls while preserving the garden.
    const flowers = [];
    for (let i = 0; i < 56; i++) {
        const p = PLATFORMS[i % PLATFORMS.length];
        const x = p.x - p.w / 2 + .9 + (i * 17 % 100) / 100 * Math.max(1, p.w - 1.8);
        flowers.push({ x, y: top(p) + .1, z: -1.75, color: i % 4 ? C.coral : C.yellow, index: i, stage: p.stage });
    }
    const stemGeo = new THREE.BoxGeometry(.10, 1.12, .12);
    const petalGeo = new THREE.IcosahedronGeometry(1, 1);
    const centerGeo = new THREE.IcosahedronGeometry(.18, 1);
    const stamp = new THREE.Object3D();
    function stampInstances(mesh, points) {
        points.forEach((pt, i) => {
            stamp.position.set(pt.x, pt.y, pt.z);
            stamp.scale.set(...pt.scale);
            stamp.rotation.set(0, 0, pt.rz ?? 0);
            stamp.updateMatrix();
            mesh.setMatrixAt(i, stamp.matrix);
        });
        mesh.instanceMatrix.needsUpdate = true;
        mesh.computeBoundingSphere();
    }
    for (let stageId = 0; stageId < 4; stageId++) {
        const f = flowers.filter(p => p.stage === stageId);
        const stems = f.map(p => ({ x: p.x, y: p.y + .52, z: p.z, scale: [1, 1, 1] }));
        const stemsMesh = new THREE.InstancedMesh(stemGeo, mat(C.deepTeal), f.length);
        stampInstances(stemsMesh, stems);
        stageGroups[stageId].add(stemsMesh);
        for (const color of [C.coral, C.yellow]) {
            const pts = [];
            for (const flower of f.filter(p => p.color === color))
                for (let j = 0; j < 5; j++) {
                    const a = j / 5 * Math.PI * 2;
                    pts.push({ x: flower.x + Math.cos(a) * .35, y: flower.y + 1.06 + Math.sin(a) * .35, z: flower.z + .18,
                        scale: [.22, .31, .18], rz: a - Math.PI / 2 });
                }
            if (pts.length) {
                const mesh = new THREE.InstancedMesh(petalGeo, mat(color), pts.length);
                stampInstances(mesh, pts);
                stageGroups[stageId].add(mesh);
            }
        }
        const centers = f.map(p => ({ x: p.x, y: p.y + 1.06, z: p.z + .28, scale: [1, 1, 1] }));
        const seedMesh = new THREE.InstancedMesh(centerGeo, mat(C.ink), f.length);
        stampInstances(seedMesh, centers);
        stageGroups[stageId].add(seedMesh);
    }
    for (let i = 0; i < 18; i++) {
        const p = PLATFORMS[(i * 5) % PLATFORMS.length];
        const lamp = lantern(i % 3 ? C.gold : C.aqua);
        lamp.position.set(p.x + p.w * .35, top(p) + .8, -2.8);
        stageGroups[p.stage].add(lamp);
        lights.push(lamp);
    }
    // --------- constraint-adherent grand finale: absurd towers on little wheels ---------
    const parade = new THREE.Group();
    parade.position.set(224, 19.7, -1.7);
    stageGroups[3].add(parade);
    for (let i = 0; i < 6; i++) {
        const cart = new THREE.Group();
        cart.position.set(i * 4.5, 1.0, -3 - (i % 2) * .9);
        parade.add(cart);
        balloons.push(cart);
        const base = prism(2.8, .48, 1.6, .18, mat(C.ink));
        cart.add(base);
        for (const s of [-1, 1]) {
            const w = ring(.5, .23, i % 2 ? C.coral : C.aqua);
            w.position.set(s * .93, -.42, 1.1);
            cart.add(w);
        }
        const spire = prism(1.6, 2.4 + i % 3, 1, .7, mat([C.porcelain, C.aqua, C.coral, C.yellow][i % 4]));
        spire.position.y = 1.56;
        cart.add(spire);
        const roof = new THREE.Mesh(new THREE.ConeGeometry(1.35, 1.8, 5), mat(C.yellow));
        roof.position.y = 3.6 + i % 3 * .5;
        cart.add(roof);
        const jewel = blob(.26, C.chalk);
        jewel.position.y = 4.65 + i % 3 * .55;
        cart.add(jewel);
        motifs.push({ mesh: cart, speed: .42, phase: i * .6, baseY: 1, type: 'bob' });
    }
    const finalArch = new THREE.Group();
    finalArch.position.set(EXIT.x, EXIT.footY, 0);
    stageGroups[3].add(finalArch);
    for (const side of [-1, 1]) {
        const c = prism(1.5, 8, 2.4, .6, mat(C.ink));
        c.position.set(side * 3.35, 4, 0);
        finalArch.add(c);
        const line = prism(.9, 7.1, 2.48, .38, mat(C.yellow));
        line.position.set(side * 3.35, 4, .25);
        finalArch.add(line);
        const t = ring(1.1, .38, C.teal);
        t.position.set(side * 3.4, 8.3, .4);
        finalArch.add(t);
    }
    const arch = ring(3.5, .85, C.ink, 50);
    arch.position.set(0, 7.4, 0);
    arch.scale.set(1, .7, 1);
    finalArch.add(arch);
    const archInner = ring(3.05, .5, C.yellow, 50);
    archInner.position.set(0, 7.4, .2);
    archInner.scale.set(1, .7, 1);
    finalArch.add(archInner);
    const portal = new THREE.Mesh(new THREE.CircleGeometry(2.5, 56), new THREE.MeshBasicMaterial({ color: C.aqua, transparent: true, opacity: .6, side: THREE.DoubleSide }));
    portal.position.set(0, 3.25, .5);
    portal.scale.set(1, 1.5, 1);
    finalArch.add(portal);
    const portalRing = ring(2.65, .22, C.coral);
    portalRing.position.set(0, 3.2, 1);
    portalRing.scale.set(1, 1.5, 1);
    finalArch.add(portalRing);
    motifs.push({ mesh: portalRing, speed: .18, phase: 1, baseY: 3.2, type: 'bob' });
    // Ceremonial ribbon arch high over the finish.
    const ribbonCurve = [new THREE.Vector3(205, 27, -16), new THREE.Vector3(214, 33, -16), new THREE.Vector3(229, 30, -15), new THREE.Vector3(246, 38, -15), new THREE.Vector3(262, 32, -18)];
    const ribbon = curvedStrand(ribbonCurve, C.coral, .45);
    stageGroups[3].add(ribbon);
    const ribbon2 = curvedStrand(ribbonCurve.map(p => new THREE.Vector3(p.x, p.y - 1.1, p.z)), C.yellow, .22);
    stageGroups[3].add(ribbon2);
    // Piecewise reusable celebration particles. Never add people or 3D text.
    const confetti = new THREE.Group();
    stageGroups[3].add(confetti);
    const flakeCount = deviceMemory <= 3 ? 72 : 132;
    const flakeMesh = new THREE.InstancedMesh(new THREE.TetrahedronGeometry(.28), new THREE.MeshBasicMaterial({ color: C.chalk, transparent: true, opacity: .90, depthWrite: false, side: THREE.DoubleSide }), flakeCount);
    flakeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    for (let i = 0; i < flakeCount; i++)
        flakeMesh.setColorAt(i, new THREE.Color([C.coral, C.teal, C.yellow, C.lavender][i % 4]));
    flakeMesh.instanceColor.needsUpdate = true;
    flakeMesh.frustumCulled = false;
    confetti.add(flakeMesh);
    const flakeStamp = new THREE.Object3D();
    const flakePos = (i, elapsed, still) => {
        const x = 206 + (i * 137 % 57), y = 17 + ((i * 17 % 25) + (still ? 0 : elapsed * (1.3 + i % 4 * .26))) % 25;
        flakeStamp.position.set(x, y, -3 - (i % 9) * 1.4);
        flakeStamp.rotation.set(still ? 0 : elapsed * .6 + i * .3, still ? 0 : elapsed * .8 + i, still ? 0 : i * .31);
        const scale = .55 + (i % 7) * .085;
        flakeStamp.scale.setScalar(scale);
        flakeStamp.updateMatrix();
        flakeMesh.setMatrixAt(i, flakeStamp.matrix);
    };
    for (let i = 0; i < flakeCount; i++)
        flakePos(i, 0, true);
    flakeMesh.instanceMatrix.needsUpdate = true;
    // Instanced activation sparks, allocated exactly once.
    const burstCount = deviceMemory <= 3 ? 22 : 52;
    const burst = new THREE.InstancedMesh(new THREE.OctahedronGeometry(.22, 0), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .94, depthWrite: false }), burstCount);
    burst.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    burst.frustumCulled = false;
    burst.visible = false;
    main.add(burst);
    for (let i = 0; i < burstCount; i++)
        burst.setColorAt(i, new THREE.Color([C.gold, C.coral, C.aqua, C.chalk][i % 4]));
    burst.instanceColor.needsUpdate = true;
    const burstStamp = new THREE.Object3D();
    let burstAge = 999;
    let burstX = 0, burstY = 0;
    // --------- the playable nonhuman clay pebble ----------
    const avatar = new THREE.Group();
    avatar.position.set(5.5, .82, 2.3);
    main.add(avatar);
    const shadowDisk = new THREE.Mesh(new THREE.CircleGeometry(.73, 28), new THREE.MeshBasicMaterial({ color: 0x252742, transparent: true, opacity: .28, depthWrite: false, side: THREE.DoubleSide }));
    shadowDisk.rotation.x = -Math.PI / 2;
    shadowDisk.position.set(0, -.69, -.05);
    avatar.add(shadowDisk);
    const blobRoot = new THREE.Group();
    blobRoot.position.y = .07;
    avatar.add(blobRoot);
    const bodyGeo = new THREE.IcosahedronGeometry(1, 3);
    const pos = bodyGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        const factor = 1 + .035 * Math.sin(8 * x + 5 * z) + .045 * Math.sin(11 * y + 2 * x);
        pos.setXYZ(i, x * factor, y * factor, z * factor);
    }
    bodyGeo.computeVertexNormals();
    const clayCoat = new THREE.MeshBasicMaterial({ color: C.ink, side: THREE.BackSide });
    const silhouette = new THREE.Mesh(bodyGeo, clayCoat);
    silhouette.scale.set(.835, .965, .73);
    blobRoot.add(silhouette);
    const body = new THREE.Mesh(bodyGeo, new THREE.MeshPhysicalMaterial({ color: 0xaed5b0, roughness: .43, metalness: 0, clearcoat: .48, clearcoatRoughness: .34 }));
    body.scale.set(.77, .89, .67);
    blobRoot.add(body);
    const ivorySpot = ellipse(.19, C.mint, .55, 1.18, .15);
    ivorySpot.position.set(.07, .63, .49);
    ivorySpot.rotation.z = -.28;
    blobRoot.add(ivorySpot);
    for (let i = 0; i < 7; i++) {
        const a = .25 + i * .88;
        const freckle = ellipse(.037, i % 2 ? C.teal : C.mint, .8, .75, .46);
        freckle.position.set(Math.cos(a) * .60, Math.sin(a) * .28 - .28, .50);
        blobRoot.add(freckle);
    }
    const footL = ellipse(.27, 0x8bbda3, 1.1, .43, .75), footR = ellipse(.27, 0x8bbda3, 1.1, .43, .75);
    footL.position.set(-.35, -.80, .15);
    footR.position.set(.35, -.80, .15);
    blobRoot.add(footL, footR);
    const armL = ellipse(.20, 0x9cc8a3, 1.1, .62, .72), armR = ellipse(.20, 0x9cc8a3, 1.1, .62, .72);
    armL.position.set(-.77, -.26, .13);
    armR.position.set(.77, -.26, .13);
    blobRoot.add(armL, armR);
    const glint = ellipse(.17, C.mint, .42, 1.7, .20);
    glint.position.set(-.47, .36, .49);
    glint.rotation.z = -.48;
    blobRoot.add(glint);
    const cheekL = ellipse(.18, C.coral, 1.25, .66, .26);
    cheekL.position.set(-.48, -.15, .53);
    blobRoot.add(cheekL);
    const cheekR = ellipse(.18, C.coral, 1.25, .66, .26);
    cheekR.position.set(.48, -.15, .53);
    blobRoot.add(cheekR);
    const eyeMat = mat(C.ink, { roughness: .25 });
    const eyeMeshes = [];
    for (const side of [-1, 1]) {
        const e = ellipse(.115, C.ink, .78, 1.45, .65);
        e.material = eyeMat;
        e.position.set(side * .26, .14, .635);
        blobRoot.add(e);
        eyeMeshes.push(e);
        const shine = ellipse(.028, C.chalk, 1, 1, .6);
        shine.position.set(side * .26 - .025, .2, .715);
        blobRoot.add(shine);
    }
    const mouth = curvedStrand([new THREE.Vector3(-.13, -.26, .673), new THREE.Vector3(0, -.32, .695), new THREE.Vector3(.13, -.26, .673)], C.ink, .028);
    blobRoot.add(mouth);
    const stem = ellipse(.20, C.teal, .43, 1.1, .6);
    stem.rotation.z = .42;
    stem.position.set(-.24, .87, -.06);
    blobRoot.add(stem);
    const leaf = ellipse(.34, C.teal, 1, .4, .36);
    leaf.rotation.z = .35;
    leaf.position.set(.24, .94, -.02);
    blobRoot.add(leaf);
    const leafVein = curvedStrand([new THREE.Vector3(.03, .94, .125), new THREE.Vector3(.23, 1.03, .13), new THREE.Vector3(.46, 1.09, .09)], C.deepTeal, .018);
    blobRoot.add(leafVein);
    // Motion dust: object pool, no dynamic geometry allocation.
    const dust = [];
    for (let i = 0; i < 9; i++) {
        const d = ellipse(.14, i % 2 ? C.yellow : C.chalk, .9, .7, .5);
        d.visible = false;
        d.position.z = 1.9;
        main.add(d);
        dust.push(d);
    }
    let dustTimer = 0;
    // Transformation wave is an independent, non-colliding stage effect.
    const pulse = new THREE.Group();
    main.add(pulse);
    pulse.visible = false;
    const pulseRings = [];
    for (let i = 0; i < 3; i++) {
        const r = ring(1.2, .16, [C.yellow, C.coral, C.aqua][i], 56);
        pulse.add(r);
        pulseRings.push(r);
    }
    // Static enamel and scenery pieces are merged by material inside their own
    // visibility chapter. Animated objects, the avatar, forbidden layers and
    // individually addressed materials are excluded. No collision data changes.
    function batchStillScenery(root, blocked) {
        scene.updateMatrixWorld(true);
        const groups = new Map();
        const accentSet = new Set(accents);
        const windowSet = new Set(windows);
        const isProtected = (node) => {
            let p = node;
            while (p && p !== root) {
                if (blocked.has(p))
                    return true;
                p = p.parent;
            }
            return false;
        };
        root.traverse(o => {
            if (!(o instanceof THREE.Mesh) || o instanceof THREE.InstancedMesh || isProtected(o) || windowSet.has(o))
                return;
            if (Array.isArray(o.material) || !(o.material instanceof THREE.MeshStandardMaterial) || accentSet.has(o.material))
                return;
            const m = o.material;
            if (m.transparent || m.map || m.alphaMap || (m.emissive.getHex() !== 0 && m.emissiveIntensity > 0) || m.opacity !== 1 || m.side !== THREE.FrontSide)
                return;
            const attrs = o.geometry.attributes;
            if (!attrs.position || !attrs.normal || !attrs.uv || attrs.color || o.geometry.morphAttributes.position)
                return;
            const spatialBucket = Math.floor(o.matrixWorld.elements[12] / 32);
            const key = [spatialBucket, m.type, m.color.getHex(), m.roughness, m.metalness, m.flatShading, m.emissive.getHex(), m.side].join('/');
            const current = groups.get(key) ?? [];
            current.push(o);
            groups.set(key, current);
        });
        const fromRoot = root.matrixWorld.clone().invert();
        for (const meshes of groups.values()) {
            if (meshes.length < 4)
                continue;
            // Bound each baked mesh to 80k vertices. This avoids huge GPU uploads on mobile.
            let part = [];
            let count = 0;
            const flush = () => {
                if (part.length < 3) {
                    part = [];
                    count = 0;
                    return;
                }
                const arrays = [];
                let total = 0;
                for (const o of part) {
                    const geometry = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
                    geometry.applyMatrix4(fromRoot.clone().multiply(o.matrixWorld));
                    const ps = geometry.getAttribute('position');
                    const ns = geometry.getAttribute('normal');
                    const us = geometry.getAttribute('uv');
                    if (!ps || !ns || !us) {
                        geometry.dispose();
                        continue;
                    }
                    const pos = new Float32Array(ps.count * 3), norm = new Float32Array(ps.count * 3), uv = new Float32Array(ps.count * 2);
                    for (let v = 0; v < ps.count; v++) {
                        pos[v * 3] = ps.getX(v);
                        pos[v * 3 + 1] = ps.getY(v);
                        pos[v * 3 + 2] = ps.getZ(v);
                        norm[v * 3] = ns.getX(v);
                        norm[v * 3 + 1] = ns.getY(v);
                        norm[v * 3 + 2] = ns.getZ(v);
                        uv[v * 2] = us.getX(v);
                        uv[v * 2 + 1] = us.getY(v);
                    }
                    arrays.push({ pos, norm, uv });
                    total += ps.count;
                    geometry.dispose();
                }
                const positions = new Float32Array(total * 3), normals = new Float32Array(total * 3), uvs = new Float32Array(total * 2);
                let vertex = 0;
                for (const arr of arrays) {
                    positions.set(arr.pos, vertex * 3);
                    normals.set(arr.norm, vertex * 3);
                    uvs.set(arr.uv, vertex * 2);
                    vertex += arr.pos.length / 3;
                }
                const geo = new THREE.BufferGeometry();
                geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
                geo.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
                geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
                geo.computeBoundingSphere();
                const joined = new THREE.Mesh(geo, part[0].material);
                joined.name = 'ceramic-scenery-batch';
                root.add(joined);
                for (const o of part)
                    o.parent?.remove(o);
                part = [];
                count = 0;
            };
            for (const mesh of meshes) {
                const vertices = mesh.geometry.index ? mesh.geometry.index.count : mesh.geometry.getAttribute('position').count;
                if (count + vertices > 80000)
                    flush();
                part.push(mesh);
                count += vertices;
            }
            flush();
        }
    }
    // Never touch dynamic roots, even when they contain static-looking children.
    const movingRoots = new Set([
        ...motifs.map(m => m.mesh), avatar, sunHalo, moon, roofGroup, wingPivotL, wingPivotR,
        ...checkpointBeacons, ...switchModels, ...gateObjs, pulse, burst, parade, finalArch
    ]);
    batchStillScenery(back, movingRoots);
    for (const layer of stageGroups)
        batchStillScenery(layer, movingRoots);
    batchStillScenery(figures, new Set());
    function setStage(next, immediate = false) {
        if (next === stage && !immediate)
            return;
        stage = next;
        for (let i = 0; i < stageGroups.length; i++) {
            stageGroups[i].visible = i <= stage;
        }
        gateObjs.forEach((g, i) => g.visible = stage < i + 1);
        letters.visible = stage < 3;
        figures.visible = stage < 3;
        checkpointBeacons.forEach((g, i) => g.visible = i <= stage);
        switchModels.forEach((g, i) => g.visible = i <= stage);
        if (immediate) {
            visualDusk = stage >= 1 ? 1 : 0;
            visualWide = stage >= 2 ? 1 : 0;
            visualConstraints = stage >= 3 ? 1 : 0;
        }
        else {
            pulse.visible = true;
            bannerPulse = 0;
            burstAge = 0;
            cameraImpulse = .22;
            const anchor = SWITCHES[next - 1];
            if (anchor) {
                pulse.position.set(anchor.x, anchor.footY + .9, 3.4);
                burstX = anchor.x;
                burstY = anchor.footY + 1.3;
            }
        }
    }
    function resize() {
        const width = Math.max(320, host.clientWidth), height = Math.max(260, host.clientHeight);
        aspect = width / height;
        const vertical = aspect < .9 ? 23 : aspect < 1.45 ? 20 : 18.7;
        camera.left = -vertical * aspect / 2;
        camera.right = vertical * aspect / 2;
        camera.top = vertical / 2;
        camera.bottom = -vertical / 2;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height, false);
    }
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(host);
    window.addEventListener('orientationchange', resize);
    setStage(0, true);
    function frame(g, dt, elapsed, reduceMotion) {
        reduced = reduceMotion;
        const targetDusk = stage >= 1 ? 1 : 0, targetWide = stage >= 2 ? 1 : 0, targetConstraints = stage >= 3 ? 1 : 0;
        const animationSpeed = reduced ? 14 : dt * 1.35;
        const a = reduced ? 1 : Math.min(1, animationSpeed);
        visualDusk += (targetDusk - visualDusk) * a;
        visualWide += (targetWide - visualWide) * a;
        visualConstraints += (targetConstraints - visualConstraints) * a;
        const dusk = ease(visualDusk), wide = ease(visualWide);
        skyUniforms.uDusk.value = dusk;
        skyUniforms.uTime.value = reduced ? 0 : elapsed;
        scene.background.copy(colorDay).lerp(colorNight, dusk);
        hemi.color.setHex(C.cream).lerp(new THREE.Color(0xb8c6fa), dusk);
        hemi.intensity = 2.65 - dusk * .8;
        sun.color.setHex(C.cream).lerp(new THREE.Color(0xffa67c), dusk);
        sun.intensity = 2.85 - dusk * 1.6;
        moonLight.intensity = dusk * 1.15;
        duskLight.intensity = .7 + dusk * 4.5;
        fillLight.color.copy(warmColor).lerp(duskColor, dusk * .85);
        fillLight.intensity = 1.05 - dusk * .24;
        renderer.toneMappingExposure = 1.10 - dusk * .09;
        for (const material of glowMaterials) {
            const power = Number(material.userData.power ?? 1);
            material.opacity = (.018 + (dusk * .50)) * power;
        }
        starMat.opacity = dusk * .96;
        sunHalo.scale.setScalar(1 - dusk * .52);
        moon.scale.setScalar(.65 + dusk * .35);
        sunHalo.children[0].visible = dusk < .96;
        for (const m of windows) {
            const mm = m.material;
            mm.emissiveIntensity = .06 + dusk * .86;
        }
        for (const m of accents) {
            const initial = m === towerShell.material ? C.porcelain : m === baseFill.material ? C.teal : C.purple;
            m.color.copy(tempColor.setHex(initial).lerp(new THREE.Color(m === towerShell.material ? C.purple : m === baseFill.material ? C.indigo : C.coral), dusk * .78));
        }
        roofGroup.rotation.y = dusk * .33;
        roofGroup.scale.y = 1 + dusk * .17;
        wingPivotL.rotation.z = -dusk * 1.2;
        wingPivotR.rotation.z = dusk * 1.2;
        // Wide framing physically reveals level geometry above, as the camera opens the shot.
        // Physics and visible platforms agree from the first transformed frame.
        // The camera and decorative reliefs animate, but solid platform skin does not shrink.
        for (const m of motifs) {
            if (m.type === 'spin') {
                m.mesh.rotation.z = (reduced ? 0 : elapsed * m.speed) + m.phase;
            }
            else if (m.type === 'bob') {
                m.mesh.position.y = m.baseY + (reduced ? 0 : Math.sin(elapsed * m.speed + m.phase) * .17);
                m.mesh.rotation.z = reduced ? 0 : Math.sin(elapsed * .5 + m.phase) * .035;
            }
            else if (m.type === 'sway') {
                m.mesh.rotation.z = reduced ? 0 : Math.sin(elapsed * .8 + m.phase) * .12;
            }
        }
        // Parade consists only of abstract wheeled towers, flowers, and falling confetti.
        parade.visible = stage === 3;
        for (let i = 0; i < balloons.length; i++) {
            balloons[i].rotation.z = reduced ? 0 : Math.sin(elapsed * 1.5 + i * .7) * .06;
        }
        if (stage === 3) {
            for (let i = 0; i < flakeCount; i++)
                flakePos(i, elapsed, reduced);
            flakeMesh.instanceMatrix.needsUpdate = true;
            if (g.won && !reduced)
                portal.rotation.z = Math.sin(elapsed * .9) * .045;
        }
        burstAge += dt;
        burst.visible = burstAge < 1.55 && !reduced;
        if (burst.visible) {
            for (let i = 0; i < burstCount; i++) {
                const angle = i * 2.39996322973;
                const speed = 4.0 + (i % 7) * .62;
                const reach = burstAge * speed;
                burstStamp.position.set(burstX + Math.cos(angle) * reach, burstY + Math.sin(angle) * reach + burstAge * burstAge * -.9, 3.45 + (i % 5) * .17);
                burstStamp.rotation.set(burstAge * (i % 3 + 1), burstAge * (i % 5 + 1), angle);
                const size = Math.max(.001, (1 - burstAge / 1.55)) * (.5 + (i % 4) * .19);
                burstStamp.scale.set(size, size * .67, size);
                burstStamp.updateMatrix();
                burst.setMatrixAt(i, burstStamp.matrix);
            }
            burst.instanceMatrix.needsUpdate = true;
        }
        if (pulse.visible) {
            bannerPulse += dt;
            pulse.visible = bannerPulse < 2.3 && !reduced;
            pulseRings.forEach((r, i) => { const prog = bannerPulse / 2.3 + i * .19; r.scale.setScalar(1 + prog * 10); r.material.transparent = true; r.material.opacity = Math.max(0, .58 - prog * .48); });
        }
        const p = g.player;
        if (lastGrounded && !p.grounded)
            jumpStretch = .20;
        if (!lastGrounded && p.grounded) {
            landSquash = Math.min(.28, .13 + Math.abs(p.vy) * .011);
            cameraImpulse = Math.max(cameraImpulse, .045);
            for (let i = 0; i < 5; i++) {
                const d = dust[(i + Math.floor(elapsed * 10)) % dust.length];
                d.visible = true;
                d.position.set(p.x + (i - 2) * .26, p.y + .13, 2.5);
                d.userData.birth = elapsed;
                d.userData.kind = 'landing';
                d.scale.setScalar(.34 + (i % 2) * .14);
            }
        }
        lastGrounded = p.grounded;
        landSquash = Math.max(0, landSquash - dt * 2.4);
        jumpStretch = Math.max(0, jumpStretch - dt * 1.4);
        avatar.position.set(p.x, p.y + .78, 2.1);
        blobRoot.rotation.z = reduced ? 0 : -p.vx * .012;
        const moving = Math.min(1, Math.abs(p.vx) / MOVE_SPEED);
        const bounce = reduced ? 0 : Math.sin(elapsed * 15) * moving * .06;
        const air = !p.grounded ? .085 : 0;
        blobRoot.scale.set(.99 + bounce * .6 + landSquash * .8 - jumpStretch * .45, 1.01 - bounce + air - landSquash * .9 + jumpStretch, .99);
        blobRoot.rotation.y = p.facing < 0 ? -.16 : .16;
        leaf.rotation.z = .35 + (reduced ? 0 : Math.sin(elapsed * 5.7) * .08 + p.vx * .009);
        footL.rotation.z = reduced ? 0 : Math.sin(elapsed * 15) * moving * .29;
        footR.rotation.z = reduced ? 0 : -Math.sin(elapsed * 15) * moving * .29;
        armL.rotation.z = reduced ? 0 : Math.sin(elapsed * 9) * moving * .19;
        armR.rotation.z = reduced ? 0 : -Math.sin(elapsed * 9) * moving * .19;
        const blinking = !reduced && Math.sin(elapsed * 1.67) > 0.992;
        for (const eye of eyeMeshes)
            eye.scale.y = blinking ? .21 : 1.45;
        mouth.scale.y = p.grounded ? 1 : 1.4;
        shadowDisk.visible = p.grounded;
        dustTimer += dt;
        if (!reduced && p.grounded && Math.abs(p.vx) > 3 && dustTimer > .09) {
            const d = dust[Math.floor(elapsed * 18) % dust.length];
            d.visible = true;
            d.position.set(p.x - p.facing * .35, p.y + .15, 2.45);
            d.scale.setScalar(.6);
            d.userData.birth = elapsed;
            d.userData.kind = 'run';
            dustTimer = 0;
        }
        for (const d of dust) {
            if (!d.visible)
                continue;
            const age = elapsed - d.userData.birth;
            if (age > .42) {
                d.visible = false;
                continue;
            }
            const landing = d.userData.kind === 'landing';
            d.position.x += dt * (landing ? (d.position.x >= p.x ? 2 : -2) : -p.facing);
            d.position.y += dt * (landing ? 2.7 : .8);
            d.scale.setScalar((landing ? .38 : .6) + age * (landing ? 1.0 : 1.7));
        }
        // Cinematic, forgiving camera; stage two increases orthographic world coverage.
        const targetScale = 1 + wide * (aspect < .9 ? .15 : .43);
        camScale += (targetScale - camScale) * (reduced ? 1 : Math.min(1, dt * 2.4));
        camera.zoom = 1 / camScale;
        camera.updateProjectionMatrix();
        const lead = aspect < .8 ? 1.2 : aspect < 1.3 ? 2.1 : 4.4 + wide * 1.2;
        const toX = g.started ? p.x + lead : 116;
        const toY = g.started ? p.y + (aspect < 1 ? 4.2 : 5.5) : 18.5;
        camX += (toX - camX) * (g.started ? (reduced ? 1 : Math.min(1, dt * 4.3)) : (reduced ? 1 : Math.min(1, dt * .95)));
        camY += (toY - camY) * (g.started ? (reduced ? 1 : Math.min(1, dt * 3.9)) : (reduced ? 1 : Math.min(1, dt * .95)));
        target.set(camX, camY, 0);
        camera.position.set(camX, camY + 5.2, 55);
        camera.lookAt(target);
        // Staged diorama movement and a restrained, damped transformation impulse.
        if (!reduced) {
            camera.position.x += Math.sin(elapsed * .17) * .065 + Math.sin(elapsed * 39) * cameraImpulse * .24;
            camera.position.y += Math.cos(elapsed * 34) * cameraImpulse * .20;
        }
        cameraImpulse *= Math.exp(-dt * 7);
        renderer.render(scene, camera);
        if (g.started && !g.paused && !g.won) {
            overloadedFor = dt > 1 / 26 ? overloadedFor + Math.min(dt, .065) : Math.max(0, overloadedFor - dt * .65);
            if (overloadedFor > 2.8 && qualityRatio > 1.05) {
                qualityRatio = Math.max(1, qualityRatio - .23);
                renderer.setPixelRatio(qualityRatio);
                resize();
                overloadedFor = 0;
            }
        }
    }
    function dispose() {
        ro.disconnect();
        window.removeEventListener('orientationchange', resize);
        const geometries = new Set();
        const materials = new Set();
        const textures = new Set();
        scene.traverse(o => {
            const mesh = o;
            if (mesh.geometry)
                geometries.add(mesh.geometry);
            const mats = mesh.material ? (Array.isArray(mesh.material) ? mesh.material : [mesh.material]) : [];
            for (const m of mats) {
                materials.add(m);
                const maybe = m;
                if (maybe.map)
                    textures.add(maybe.map);
            }
        });
        for (const geo of geometries)
            geo.dispose();
        for (const material of materials)
            material.dispose();
        for (const texture of textures)
            texture.dispose();
        skyMaterial.dispose();
        renderer.dispose();
        canvas.remove();
    }
    return { canvas, get stage() { return stage; }, setStage, frame, resize, dispose };
}
