const KEYMAP = {
    'a': 'left', 'arrowleft': 'left',
    'd': 'right', 'arrowright': 'right',
    'w': 'jump', 'arrowup': 'jump', ' ': 'jump',
    'e': 'interact', 'enter': 'interact',
    'r': 'respawn',
};
export class InputManager {
    touchRoot;
    pressed = new Set();
    pointerActions = new Map();
    bound = [];
    enabled = false;
    onPause = () => { };
    constructor(touchRoot) {
        this.touchRoot = touchRoot;
        const keydown = (e) => {
            if (e.key === 'Escape') {
                this.onPause();
                return;
            }
            if (!this.enabled || e.ctrlKey || e.metaKey || e.altKey || this.isSemanticTarget(e.target))
                return;
            const action = KEYMAP[e.key.toLowerCase()];
            if (action) {
                e.preventDefault();
                this.pressed.add(action);
            }
        };
        const keyup = (e) => {
            const action = KEYMAP[e.key.toLowerCase()];
            if (action)
                this.pressed.delete(action);
        };
        const blur = () => this.clear();
        const visibility = () => { if (document.hidden)
            this.clear(); };
        window.addEventListener('keydown', keydown);
        window.addEventListener('keyup', keyup);
        window.addEventListener('blur', blur);
        document.addEventListener('visibilitychange', visibility);
        this.bound.push(() => window.removeEventListener('keydown', keydown), () => window.removeEventListener('keyup', keyup), () => window.removeEventListener('blur', blur), () => document.removeEventListener('visibilitychange', visibility));
        const buttons = this.touchRoot.querySelectorAll('[data-action]');
        for (const button of buttons) {
            const action = button.dataset.action;
            const down = (e) => {
                if (!this.enabled)
                    return;
                e.preventDefault();
                this.pointerActions.set(e.pointerId, action);
                button.setPointerCapture(e.pointerId);
                button.classList.add('active');
            };
            const up = (e) => { this.pointerActions.delete(e.pointerId); button.classList.remove('active'); };
            button.addEventListener('pointerdown', down);
            button.addEventListener('pointerup', up);
            button.addEventListener('pointercancel', up);
            button.addEventListener('lostpointercapture', up);
            this.bound.push(() => {
                button.removeEventListener('pointerdown', down);
                button.removeEventListener('pointerup', up);
                button.removeEventListener('pointercancel', up);
                button.removeEventListener('lostpointercapture', up);
            });
        }
    }
    isSemanticTarget(target) {
        if (!(target instanceof HTMLElement))
            return false;
        return Boolean(target.closest('button,input,textarea,select,a,[contenteditable="true"],[role="button"],[role="dialog"]'));
    }
    setEnabled(value) { this.enabled = value; if (!value)
        this.clear(); }
    clear() { this.pressed.clear(); this.pointerActions.clear(); for (const button of this.touchRoot.querySelectorAll('.active'))
        button.classList.remove('active'); }
    sample() {
        const has = (a) => this.enabled && (this.pressed.has(a) || Array.from(this.pointerActions.values()).includes(a));
        return { left: has('left'), right: has('right'), jump: has('jump'), interact: has('interact'), respawn: has('respawn') };
    }
    dispose() { this.clear(); for (const remove of this.bound)
        remove(); this.bound.length = 0; }
}
