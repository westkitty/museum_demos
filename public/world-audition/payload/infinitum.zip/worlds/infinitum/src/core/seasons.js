export const SEASONS = ['Spring', 'Summer', 'Autumn', 'Winter'];
export function seasonalGrowthFactor(s) {
    return s.season === 'Spring' ? 1.28 : s.season === 'Summer' ? 1 : s.season === 'Autumn' ? .72 : .33;
}
export function seasonalLight(s) {
    return s.season === 'Winter' ? { intensity: .73, warmth: 0, snow: .55 } : s.season === 'Autumn' ? { intensity: .88, warmth: .15, snow: 0 } : s.season === 'Spring' ? { intensity: 1.04, warmth: .06, snow: 0 } : { intensity: 1.1, warmth: .10, snow: 0 };
}
