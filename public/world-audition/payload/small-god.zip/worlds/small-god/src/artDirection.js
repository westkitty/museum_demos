import * as THREE from 'three';
import { POINTS, easeInOut } from './rules.js';
const GOLD = 0xf5cc82;
const MINT = 0x77f0db;
const LILAC = 0xd5aeff;
const rng = (initial) => {
    let state = initial >>> 0;
    return () => ((state = (Math.imul(state, 1664525) + 1013904223) >>> 0) / 4294967296);
};
const clamp01 = (v) => Math.min(1, Math.max(0, v));
/** Original procedural set dressing: no remote textures, no external assets, no gameplay authority. */
export class IslandArtDirection {
    scene;
    height;
    rand = rng(731028);
    wave;
    grass = [];
    banners = [];
    glowPoints;
    fireflyBases;
    fireflyPhase;
    wardGlass;
    eventSigils;
    boat;
    birdFlock = [];
    temp = new THREE.Object3D();
    constructor(scene, height) {
        this.scene = scene;
        this.height = height;
        this.createSky();
        this.wave = this.createWaterSurface();
        this.createCliffJewelry();
        this.createFoliage();
        this.createTerracedGardens();
        this.createRiversideLife();
        this.createHarbor();
        this.createLanternPennants();
        const lights = this.createFireflies();
        this.glowPoints = lights.points;
        this.fireflyBases = lights.bases;
        this.fireflyPhase = lights.phases;
        this.wardGlass = this.createWardGlass();
        this.eventSigils = {
            strike: this.createEventSigil(POINTS.strike.x, POINTS.strike.z, GOLD, 5),
            sweep: this.createEventSigil(POINTS.plaza.x, POINTS.plaza.z, MINT, 7),
            ward: this.createEventSigil(POINTS.sign.x, POINTS.sign.z, LILAC, 9),
        };
    }
    createSky() {
        const sphere = new THREE.Mesh(new THREE.SphereGeometry(92, 32, 16), new THREE.ShaderMaterial({
            side: THREE.BackSide, depthWrite: false, fog: false,
            vertexShader: `varying vec3 vDirection;
        void main() {vDirection = normalize(position);gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);}`,
            fragmentShader: `varying vec3 vDirection;
        void main() {
          float h = clamp(vDirection.y * 0.72 + 0.38, 0.0, 1.0);
          vec3 horizon = vec3(0.90, 0.67, 0.56);
          vec3 jade = vec3(0.48, 0.69, 0.70);
          vec3 zenith = vec3(0.19, 0.35, 0.50);
          vec3 col = mix(horizon, jade, smoothstep(0.06, 0.48, h));
          col = mix(col, zenith, smoothstep(0.49, 0.96, h));
          vec3 sunlight = normalize(vec3(-0.54, 0.53, -0.55));
          float glow = pow(max(dot(normalize(vDirection), sunlight), 0.0), 8.0);
          col += vec3(0.32, 0.21, 0.12) * glow;
          gl_FragColor = vec4(col, 1.0);
        }`,
        }));
        sphere.renderOrder = -200;
        sphere.frustumCulled = false;
        this.scene.add(sphere);
    }
    createWaterSurface() {
        const geometry = new THREE.RingGeometry(8.05, 12.02, 144, 7);
        geometry.rotateX(-Math.PI / 2);
        const shader = new THREE.ShaderMaterial({
            transparent: true, depthWrite: false, side: THREE.DoubleSide,
            uniforms: { uTime: { value: 0 }, uStill: { value: 0 } },
            vertexShader: `varying vec3 vPosition;
        void main() {vPosition = position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
            fragmentShader: `uniform float uTime; uniform float uStill; varying vec3 vPosition;
        void main() {
          float r=length(vPosition.xz);
          float a=atan(vPosition.z,vPosition.x);
          float t=mix(uTime,0.0,uStill);
          float bands=sin(r*9.5-t*1.45+sin(a*8.0)*0.55);
          float shiver=sin(r*25.0+t*1.0+a*6.0);
          float foam=smoothstep(0.44,0.98,bands)*0.28+smoothstep(0.8,1.0,shiver)*0.12;
          float inner=1.0-smoothstep(8.15,10.25,r);
          float alpha=(0.045+foam)*(.40+inner*.60);
          vec3 color=mix(vec3(.32,.68,.67),vec3(.91,1.0,.88),clamp(foam*2.0,0.0,1.0));
          gl_FragColor=vec4(color,alpha);
        }`,
        });
        const surface = new THREE.Mesh(geometry, shader);
        surface.position.y = -0.066;
        surface.renderOrder = 1;
        this.scene.add(surface);
        return surface;
    }
    createCliffJewelry() {
        const seamPalette = [0xffe2a0, 0xd6bd86, 0x9eac9a];
        for (let layer = 0; layer < 3; layer++) {
            const curve = [];
            const radius = [7.61, 7.18, 6.09][layer];
            for (let i = 0; i <= 160; i++) {
                const a = i / 160 * Math.PI * 2;
                const r = radius * (1 + .019 * Math.sin(a * 11) + .01 * Math.sin(a * 31 + .8));
                const x = Math.cos(a) * r, z = Math.sin(a) * r;
                const y = layer === 0 ? this.height(x, z) - .11 : [-.61, -1.23][layer - 1];
                curve.push(new THREE.Vector3(x, y, z));
            }
            const torus = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(curve), 184, layer === 0 ? .035 : .017, 5, false), new THREE.MeshStandardMaterial({ color: seamPalette[layer], metalness: .31, roughness: .52, emissive: 0x382d16, emissiveIntensity: .25 }));
            this.scene.add(torus);
        }
        const dripGeo = new THREE.ConeGeometry(.18, .78, 5);
        const drips = new THREE.InstancedMesh(dripGeo, new THREE.MeshStandardMaterial({ color: 0x8ca6a2, roughness: .97, flatShading: true }), 38);
        const o = new THREE.Object3D();
        for (let i = 0; i < 38; i++) {
            const a = i / 38 * Math.PI * 2;
            const r = 5.1 + this.rand() * 1.5;
            o.position.set(Math.cos(a) * r, -1.95 - this.rand() * 1.0, Math.sin(a) * r);
            o.rotation.set(Math.sin(a) * .22, 0, Math.cos(a) * .32);
            o.scale.set(.48 + this.rand() * .7, .6 + this.rand() * 1.65, .48 + this.rand() * .7);
            o.updateMatrix();
            drips.setMatrixAt(i, o.matrix);
        }
        drips.instanceMatrix.needsUpdate = true;
        this.scene.add(drips);
    }
    createFoliage() {
        const blade = new THREE.ConeGeometry(.045, .39, 3);
        blade.translate(0, .195, 0);
        const palettes = [0x4b805d, 0x7ea363, 0xa2b978, 0x9dce91];
        const batches = palettes.map(color => {
            const grass = new THREE.InstancedMesh(blade, new THREE.MeshStandardMaterial({ color, roughness: 1, side: THREE.DoubleSide }), 235);
            grass.castShadow = false;
            grass.receiveShadow = false;
            this.scene.add(grass);
            this.grass.push(grass);
            return grass;
        });
        const houseFootprints = [[-.75, -1.65], [1.65, -2.13], [3.22, -1.24], [4.5, .5], [-.4, 3.04], [1.72, 3.32], [-2.3, 3.08], [-3.4, -2.5]];
        for (let i = 0; i < 940; i++) {
            const a = this.rand() * Math.PI * 2, rad = Math.sqrt(this.rand()) * 7.25;
            const x = Math.cos(a) * rad, z = Math.sin(a) * rad;
            let clear = houseFootprints.every(([hx, hz]) => Math.hypot(x - hx, z - hz) > 1.0);
            clear &&= Math.hypot(x - POINTS.strike.x, z - POINTS.strike.z) > 1.22;
            clear &&= Math.hypot(x - POINTS.rockStart.x, z - POINTS.rockStart.z) > 1.4;
            clear &&= Math.hypot(x - POINTS.rockEnd.x, z - POINTS.rockEnd.z) > 1.35;
            clear &&= Math.hypot(x - POINTS.plaza.x, z - POINTS.plaza.z) > 1.68;
            clear &&= Math.hypot(x - POINTS.sign.x, z - POINTS.sign.z) > 1.48;
            clear &&= Math.hypot(x - POINTS.windStart.x, z - POINTS.windStart.z) > 1.10;
            this.temp.position.set(x, this.height(x, z) + .04, z);
            this.temp.rotation.set((this.rand() - .5) * .12, this.rand() * Math.PI * 2, (this.rand() - .5) * .18);
            this.temp.scale.set(clear ? .58 + this.rand() * .9 : 0, clear ? .40 + this.rand() * 1.25 : 0, clear ? .58 + this.rand() * .8 : 0);
            this.temp.updateMatrix();
            batches[i % 4].setMatrixAt(Math.floor(i / 4), this.temp.matrix);
        }
        batches.forEach(m => m.instanceMatrix.needsUpdate = true);
        // Paired topiary shrubs with contrasting blossom tips.
        const shrubGeo = new THREE.IcosahedronGeometry(.18, 1);
        const shrubMat = new THREE.MeshStandardMaterial({ color: 0x649779, roughness: 1, flatShading: true });
        const shrubs = new THREE.InstancedMesh(shrubGeo, shrubMat, 42);
        for (let i = 0; i < 42; i++) {
            const a = i / 42 * Math.PI * 2 + (this.rand() - .5) * .15;
            const r = 4.3 + this.rand() * 2.25;
            const x = Math.cos(a) * r, z = Math.sin(a) * r;
            this.temp.position.set(x, this.height(x, z) + .20, z);
            this.temp.rotation.set(0, a, 0);
            this.temp.scale.set(.8 + this.rand() * .9, 1.4 + this.rand() * .85, .8 + this.rand() * .7);
            this.temp.updateMatrix();
            shrubs.setMatrixAt(i, this.temp.matrix);
        }
        shrubs.instanceMatrix.needsUpdate = true;
        this.scene.add(shrubs);
    }
    createTerracedGardens() {
        const gardens = [[-4.2, 3.25, .62], [3.95, 3.5, .78], [-3.95, -.85, .58], [5.1, -3.38, .50]];
        const petals = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.11, 0), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .82 }), gardens.length * 12);
        petals.castShadow = false;
        gardens.forEach(([gx, gz, scale], g) => {
            const group = new THREE.Group();
            group.position.set(gx, this.height(gx, gz), gz);
            group.scale.setScalar(scale);
            for (let j = 0; j < 3; j++) {
                const ring = new THREE.Mesh(new THREE.TorusGeometry(.34 + j * .25, .045, 6, 36), new THREE.MeshStandardMaterial({ color: j % 2 ? 0xe2c48e : 0xb8b79b, roughness: 1 }));
                ring.rotation.x = Math.PI / 2;
                ring.position.y = .10 + j * .016;
                group.add(ring);
            }
            this.scene.add(group);
            for (let j = 0; j < 12; j++) {
                const angle = j * 2.4, r = .20 + this.rand() * .55;
                this.temp.position.set(gx + Math.sin(angle) * r * scale, this.height(gx, gz) + (.18 + this.rand() * .2) * scale, gz + Math.cos(angle) * r * scale);
                this.temp.scale.setScalar(scale);
                this.temp.rotation.set(0, angle, 0);
                this.temp.updateMatrix();
                petals.setMatrixAt(g * 12 + j, this.temp.matrix);
                petals.setColorAt(g * 12 + j, new THREE.Color([0xf7c7a1, 0xcdb7ef, 0xf3e4ae, 0xf8b7be][j % 4]));
            }
        });
        petals.instanceMatrix.needsUpdate = true;
        this.scene.add(petals);
        // The village garden is not a playable target; all objects are below hand height.
        const steps = new THREE.Group();
        steps.position.set(5.25, this.height(5.25, 2.45) + .05, 2.45);
        for (let i = 0; i < 6; i++) {
            const slab = new THREE.Mesh(new THREE.BoxGeometry(.57, .10, .30), new THREE.MeshStandardMaterial({ color: i % 2 ? 0xb9c2ac : 0xd8d2ae, roughness: 1 }));
            slab.position.set(i * .10, (i + 1) * .065, -i * .17);
            slab.rotation.y = .17;
            slab.receiveShadow = true;
            steps.add(slab);
        }
        this.scene.add(steps);
    }
    createRiversideLife() {
        const waterPath = [[-2.92, -4.9], [-2.65, -4.1], [-2.35, -3.35], [-2.05, -2.55], [-1.67, -1.65], [-1.15, -.55]];
        const geo = new THREE.SphereGeometry(.12, 8, 6);
        const leaves = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0x73ad7a, roughness: .85, side: THREE.DoubleSide }), 22);
        for (let i = 0; i < 22; i++) {
            const seg = i % (waterPath.length - 1);
            const a = waterPath[seg], b = waterPath[seg + 1];
            const t = this.rand();
            const x = a[0] + (b[0] - a[0]) * t + (i % 2 ? -.22 : .22), z = a[1] + (b[1] - a[1]) * t;
            this.temp.position.set(x, this.height(x, z) + .15, z);
            this.temp.scale.set(.75 + this.rand() * .7, .09, .65 + this.rand() * .45);
            this.temp.rotation.set(0, this.rand() * 6.28, 0);
            this.temp.updateMatrix();
            leaves.setMatrixAt(i, this.temp.matrix);
        }
        leaves.instanceMatrix.needsUpdate = true;
        this.scene.add(leaves);
        const bubbles = new THREE.InstancedMesh(new THREE.SphereGeometry(.045, 6, 6), new THREE.MeshBasicMaterial({ color: 0xc4fff4, transparent: true, opacity: .76, depthWrite: false }), 32);
        for (let i = 0; i < 32; i++) {
            const seg = i % (waterPath.length - 1), a = waterPath[seg], b = waterPath[seg + 1], t = this.rand();
            const x = a[0] + (b[0] - a[0]) * t + (this.rand() - .5) * .24, z = a[1] + (b[1] - a[1]) * t;
            this.temp.position.set(x, this.height(x, z) + .18, z);
            this.temp.scale.setScalar(.65 + this.rand() * .95);
            this.temp.updateMatrix();
            bubbles.setMatrixAt(i, this.temp.matrix);
        }
        bubbles.instanceMatrix.needsUpdate = true;
        this.scene.add(bubbles);
    }
    createHarbor() {
        const boat = this.boat = new THREE.Group();
        boat.position.set(9.12, -.045, 1.9);
        boat.rotation.y = .41;
        const hull = new THREE.Mesh(new THREE.SphereGeometry(.78, 12, 8), new THREE.MeshStandardMaterial({ color: 0x9c5b49, roughness: .56 }));
        hull.scale.set(1, .35, .42);
        hull.position.y = .11;
        hull.castShadow = false;
        boat.add(hull);
        const rim = new THREE.Mesh(new THREE.TorusGeometry(.59, .038, 5, 26), new THREE.MeshStandardMaterial({ color: 0xe1b778, roughness: .48, metalness: .2 }));
        rim.rotation.x = Math.PI / 2;
        rim.scale.set(1, .52, 1);
        rim.position.y = .22;
        boat.add(rim);
        const mast = new THREE.Mesh(new THREE.CylinderGeometry(.025, .032, 1.3, 6), new THREE.MeshStandardMaterial({ color: 0xe1d7ad }));
        mast.position.y = .79;
        boat.add(mast);
        const sailShape = new THREE.Shape();
        sailShape.moveTo(0, 0);
        sailShape.lineTo(.70, .17);
        sailShape.lineTo(.04, 1.08);
        sailShape.closePath();
        const sail = new THREE.Mesh(new THREE.ShapeGeometry(sailShape), new THREE.MeshStandardMaterial({ color: 0xffe4bf, side: THREE.DoubleSide, roughness: 1 }));
        sail.position.set(-.02, .36, 0);
        boat.add(sail);
        const knot = new THREE.Mesh(new THREE.IcosahedronGeometry(.055, 0), new THREE.MeshStandardMaterial({ color: 0xf4c477 }));
        knot.position.set(0, 1.4, 0);
        boat.add(knot);
        this.scene.add(boat);
        // Sculpted gull silhouettes provide far-scale parallax without external models.
        for (let i = 0; i < 7; i++) {
            const bird = new THREE.Group();
            const x = 12 + (i % 3) * 2.5, z = -13 - i * 1.8, y = 7 + (i % 4) * .9;
            bird.position.set(x, y, z);
            const wingMat = new THREE.MeshBasicMaterial({ color: 0xf1f1dd, side: THREE.DoubleSide, transparent: true, opacity: .72, depthWrite: false });
            for (const side of [-1, 1]) {
                const wing = new THREE.Mesh(new THREE.ConeGeometry(.07, .88, 3), wingMat);
                wing.position.x = side * .34;
                wing.rotation.z = side * 1.15;
                bird.add(wing);
            }
            this.birdFlock.push(bird);
            this.scene.add(bird);
        }
    }
    createLanternPennants() {
        const positions = [[-4.4, 1.9, 0], [4.9, 2.38, .75], [-1.42, -5.3, 1.7], [.7, 5.25, 2.3]];
        positions.forEach(([x, z, angle], i) => {
            const g = new THREE.Group();
            g.position.set(x, this.height(x, z), z);
            g.rotation.y = angle;
            const pole = new THREE.Mesh(new THREE.CylinderGeometry(.032, .045, 1.62, 7), new THREE.MeshStandardMaterial({ color: 0xd9c190, roughness: .5, metalness: .2 }));
            pole.position.y = .83;
            g.add(pole);
            const cap = new THREE.Mesh(new THREE.SphereGeometry(.085, 9, 7), new THREE.MeshStandardMaterial({ color: 0xffdf9d, emissive: 0xb58238, emissiveIntensity: .38 }));
            cap.position.y = 1.67;
            g.add(cap);
            const flagShape = new THREE.Shape();
            flagShape.moveTo(0, 0);
            flagShape.lineTo(.72, .08);
            flagShape.lineTo(.60, -.34);
            flagShape.lineTo(.05, -.52);
            flagShape.closePath();
            const flag = new THREE.Mesh(new THREE.ShapeGeometry(flagShape), new THREE.MeshStandardMaterial({ color: [0xeaa58d, 0x88b9a3, 0xa99aca, 0xdbc28b][i], side: THREE.DoubleSide, roughness: 1 }));
            flag.position.y = 1.48;
            g.add(flag);
            this.scene.add(g);
            this.banners.push(g);
        });
        // Celebration bunting appears only on victory; it cannot block the playfield.
        for (let i = 0; i < 3; i++) {
            const g = new THREE.Group();
            g.position.set(-1.8 + i * .8, 3.4 + i * .25, -1.65 + i * 1.25);
            for (let p = 0; p < 13; p++) {
                const s = p / 12, px = (s - .5) * 5.5, py = -.45 * Math.sin(s * Math.PI);
                const body = new THREE.Mesh(new THREE.ConeGeometry(.13, .38, 3), new THREE.MeshStandardMaterial({
                    color: [0xe8b77d, 0xc8a2b0, 0x85bca6, 0xf1d29a][(p + i) % 4], side: THREE.DoubleSide, roughness: 1,
                }));
                body.rotation.z = Math.PI;
                body.position.set(px, py, 0);
                g.add(body);
            }
            this.scene.add(g);
            this.banners.push(g);
            g.scale.setScalar(.001);
        }
    }
    createFireflies() {
        const count = 110, position = new Float32Array(count * 3), base = new Float32Array(count * 3), phases = new Float32Array(count);
        const colors = new Float32Array(count * 3);
        for (let i = 0; i < count; i++) {
            const angle = this.rand() * Math.PI * 2, r = 1.2 + this.rand() * 6.7;
            const x = Math.cos(angle) * r, z = Math.sin(angle) * r;
            const h = this.height(x, z) + .42 + this.rand() * 2.6;
            position.set([x, h, z], i * 3);
            base.set([x, h, z], i * 3);
            phases[i] = this.rand() * Math.PI * 2;
            const c = new THREE.Color([0xffeab7, 0xaaffdd, 0xeac4fc][i % 3]);
            colors.set([c.r, c.g, c.b], i * 3);
        }
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.BufferAttribute(position, 3));
        g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        const tex = document.createElement('canvas');
        tex.width = tex.height = 32;
        const ctx = tex.getContext('2d');
        const grad = ctx.createRadialGradient(16, 16, 1, 16, 16, 16);
        grad.addColorStop(0, '#fff');
        grad.addColorStop(.35, 'rgba(255,255,255,.85)');
        grad.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 32, 32);
        const pointTex = new THREE.CanvasTexture(tex);
        const points = new THREE.Points(g, new THREE.PointsMaterial({ map: pointTex, vertexColors: true, transparent: true, size: .12, sizeAttenuation: true, depthWrite: false, opacity: .75 }));
        points.frustumCulled = false;
        this.scene.add(points);
        return { points, bases: base, phases };
    }
    createWardGlass() {
        const glass = new THREE.Mesh(new THREE.SphereGeometry(1.65, 26, 14), new THREE.MeshPhysicalMaterial({
            color: 0xc7aeff, roughness: .14, metalness: .04, transparent: true, opacity: .115,
            side: THREE.FrontSide, depthWrite: false, clearcoat: 1, clearcoatRoughness: .08,
        }));
        glass.scale.set(1, .73, 1);
        glass.position.set(POINTS.sign.x, this.height(POINTS.sign.x, POINTS.sign.z) + 1.05, POINTS.sign.z);
        glass.visible = false;
        glass.renderOrder = 7;
        this.scene.add(glass);
        return glass;
    }
    createEventSigil(x, z, color, spokes) {
        const g = new THREE.Group();
        g.position.set(x, this.height(x, z) + .16, z);
        g.visible = false;
        const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: .64, depthWrite: false, blending: THREE.AdditiveBlending });
        const halo = new THREE.Mesh(new THREE.TorusGeometry(.72, .025, 5, 64), mat);
        halo.rotation.x = Math.PI / 2;
        g.add(halo);
        for (let i = 0; i < spokes; i++) {
            const a = i / spokes * Math.PI * 2;
            const glyph = new THREE.Mesh(new THREE.TetrahedronGeometry(.12, 0), mat);
            glyph.position.set(Math.cos(a) * .90, .13, Math.sin(a) * .90);
            glyph.rotation.y = a;
            g.add(glyph);
        }
        this.scene.add(g);
        return g;
    }
    setQuality(mobile) {
        this.grass.forEach(g => { g.count = mobile ? 140 : 235; });
        this.glowPoints.geometry.setDrawRange(0, mobile ? 56 : 110);
        this.birdFlock.forEach((bird, i) => { bird.visible = !mobile || i < 3; });
    }
    update(dt, time, rules, reduced, eventName, eventDuration) {
        const shader = this.wave.material;
        shader.uniforms.uTime.value = time;
        shader.uniforms.uStill.value = reduced ? 1 : 0;
        if (!reduced) {
            const a = this.glowPoints.geometry.getAttribute('position');
            const coords = a.array;
            for (let i = 0; i < this.fireflyPhase.length; i++) {
                const idx = i * 3, p = this.fireflyPhase[i];
                coords[idx] = this.fireflyBases[idx] + Math.sin(time * .58 + p) * .15;
                coords[idx + 1] = this.fireflyBases[idx + 1] + Math.sin(time * 1.08 + p) * .13;
                coords[idx + 2] = this.fireflyBases[idx + 2] + Math.cos(time * .48 + p) * .13;
            }
            a.needsUpdate = true;
        }
        this.boat.position.y = -.045 + (reduced ? 0 : Math.sin(time * 1.45) * .07);
        this.boat.rotation.z = reduced ? 0 : Math.sin(time * .75) * .035;
        this.birdFlock.forEach((b, i) => { b.position.x = 12 + (i % 3) * 2.5 + (reduced ? 0 : Math.sin(time * .28 + i) * .4); });
        const celebrating = rules.state.victory;
        this.banners.forEach((b, i) => {
            if (i < 4) {
                b.rotation.z = reduced ? 0 : Math.sin(time * 1.45 + i) * .018;
            }
            else {
                const appear = celebrating ? (reduced ? 1 : easeInOut((rules.state.victoryTime - .9 - (i - 4) * .12) / 1.0)) : 0;
                b.scale.setScalar(Math.max(.001, clamp01(appear)));
            }
        });
        this.wardGlass.visible = rules.state.signDone;
        if (rules.state.signDone) {
            const fraction = easeInOut(rules.state.wardTime / 1.8);
            this.wardGlass.scale.set(1.0, .73 * Math.max(.05, fraction), 1.0);
        }
        const activeGesture = eventName === 'rock-moved' ? 'strike' : eventName === 'sweep-done' ? 'sweep' : eventName === 'sign-warded' ? 'ward' : null;
        Object.keys(this.eventSigils).forEach((gesture) => {
            const group = this.eventSigils[gesture];
            const active = eventDuration > 0 && gesture === activeGesture;
            group.visible = active;
            if (active) {
                const elapsed = 2.5 - eventDuration;
                group.scale.setScalar(.20 + easeInOut(elapsed / 1.35) * 2.45);
                group.rotation.y = reduced ? 0 : elapsed * (gesture === 'sweep' ? 2.8 : .65);
                const opacity = group.children[0].material;
                opacity.opacity = .8 * (1 - clamp01(elapsed / 2.5));
            }
        });
        // Fixed-step and authoritative gameplay state remain in the caller.
        void dt;
    }
}
