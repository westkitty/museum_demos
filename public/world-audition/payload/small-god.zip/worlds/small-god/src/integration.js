/** Optional, opt-in museum bridge. This package never imports or changes the live museum. */
import { mountGodGame } from './game.js';
export const E31_ADAPTER = Object.freeze({
    entry: 'E31',
    wing: 'Story Worlds',
    project: 'Parable',
    experience: 'the-god-of-very-small-problems',
    canonical: false,
    isolated: true,
    needsProductionMuseumChanges: false,
});
export function enterE31(container, hooks = {}) {
    return mountGodGame(container, {
        onReturn: () => hooks.onReturn?.({ exhibit: 'E31', experience: E31_ADAPTER.experience, source: 'mock-portal' }),
        onComplete: event => hooks.onComplete?.(event),
    });
}
