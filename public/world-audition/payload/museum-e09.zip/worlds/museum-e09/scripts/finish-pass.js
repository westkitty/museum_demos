import * as THREE from 'three';
import { PLATFORMS } from './level.js';
/**
 * v0.3: visual-only architectural finish. Platform geometry, player movement and
 * checkpoints remain authoritative in their original modules.
 * The finish is original procedural material/geometry, not historical evidence.
 */
const COLORS = {
    document: { base: 0xe4d2b0, edge: 0x99714b, light: 0xe9c88e },
    rooms: { base: 0x514a73, edge: 0x9e90c8, light: 0xc6aaff },
    monolith: { base: 0x182e3c, edge: 0x7897ad, light: 0x8bdce9 },
    vnext: { base: 0x1b3e42, edge: 0xb89968, light: 0x71dfd8 },
};
const smooth = (v) => { const t = THREE.MathUtils.clamp(v, 0, 1); return t * t * (3 - 2 * t); };
const noise = (n) => { const v = Math.sin(n * 127.1 + 11.2) * 43758.5453; return v - Math.floor(v); };
export class FinishPass {
    group = new THREE.Group();
    highOnly = new THREE.Group();
    textures = [];
    assemblies = [];
    ripple;
    temp = new THREE.Object3D();
    lowEffects = false;
    constructor(parent, collidableVisualRoot) {
        this.group.name = 'E09 premium scene finishes / non-colliding';
        parent.add(this.group);
        this.group.add(this.highOnly);
        this.applyMaterialFinish(collidableVisualRoot);
        this.buildWalkways();
        this.buildPaperScenery();
        this.buildRoomScenery();
        this.buildMonolithScenery();
        this.buildBecomingScenery();
        this.ripple = this.makeWaterRings();
    }
    mesh(geometry, material, parent = this.group) {
        const m = new THREE.Mesh(geometry, material);
        m.castShadow = false;
        m.receiveShadow = false;
        parent.add(m);
        return m;
    }
    material(color, metalness = .14, roughness = .58, emissive = 0) {
        return new THREE.MeshStandardMaterial({ color, metalness, roughness, emissive: color, emissiveIntensity: emissive, side: THREE.DoubleSide });
    }
    batch(boxes, material, parent = this.group) {
        if (!boxes.length)
            return null;
        const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), material, boxes.length);
        boxes.forEach(([x, y, z, w, h, d], i) => {
            this.temp.position.set(x, y, z);
            this.temp.rotation.set(0, 0, 0);
            this.temp.scale.set(w, h, d);
            this.temp.updateMatrix();
            mesh.setMatrixAt(i, this.temp.matrix);
        });
        mesh.instanceMatrix.needsUpdate = true;
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        parent.add(mesh);
        return mesh;
    }
    finishTexture(phase) {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 256;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas 2D is required for authored local floor textures');
        ctx.fillStyle = '#f5f2eb';
        ctx.fillRect(0, 0, 256, 256);
        // Shared material family: archival plate marks, slab seams and fine surface grain.
        const seed = ({ document: 30, rooms: 80, monolith: 130, vnext: 190 })[phase];
        for (let i = 0; i < 940; i++) {
            const x = noise(i + seed) * 256, y = noise(i * 3 + seed + 40) * 256;
            const alpha = phase === 'document' ? .095 : .078;
            ctx.fillStyle = i % 7 === 0 ? `rgba(30,34,46,${alpha})` : `rgba(100,84,65,${alpha * .6})`;
            ctx.fillRect(x, y, .45 + noise(i + 190) * 2, .6 + noise(i + 110) * 2.4);
        }
        ctx.lineWidth = 1;
        if (phase === 'document') {
            ctx.strokeStyle = '#816d58aa';
            for (let y = 22; y < 255; y += 30) {
                ctx.beginPath();
                ctx.moveTo(18, y);
                ctx.lineTo(234, y);
                ctx.stroke();
            }
            ctx.strokeStyle = '#8c684c77';
            ctx.strokeRect(11, 11, 234, 234);
            ctx.beginPath();
            ctx.moveTo(42, 0);
            ctx.lineTo(42, 256);
            ctx.stroke();
        }
        else if (phase === 'rooms') {
            ctx.strokeStyle = '#756c8c74';
            for (let y = 0; y < 256; y += 64) {
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(256, y);
                ctx.stroke();
            }
            for (let x = 0; x < 256; x += 128) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, 256);
                ctx.stroke();
            }
        }
        else if (phase === 'monolith') {
            ctx.strokeStyle = '#42556669';
            for (let x = 6; x < 256; x += 18) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x - 3, 256);
                ctx.stroke();
            }
            ctx.strokeStyle = '#a1b6bd73';
            for (let y = 4; y < 256; y += 85) {
                ctx.fillRect(0, y, 256, 1);
            }
        }
        else {
            ctx.strokeStyle = '#7e877b85';
            for (let y = 0; y < 256; y += 64) {
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(256, y);
                ctx.stroke();
            }
            for (let x = 0; x < 256; x += 64) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, 256);
                ctx.stroke();
            }
            ctx.strokeStyle = '#ad9e7380';
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(256, 256);
            ctx.stroke();
        }
        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(2, 3);
        tex.anisotropy = 4;
        this.textures.push(tex);
        return tex;
    }
    applyMaterialFinish(root) {
        const maps = new Map();
        Object.keys(COLORS).forEach(phase => maps.set(phase, this.finishTexture(phase)));
        const lookup = new Map(PLATFORMS.map(p => [p.id, p]));
        root.traverse(obj => {
            if (!(obj instanceof THREE.Mesh) || typeof obj.userData.platform !== 'string')
                return;
            const platform = lookup.get(obj.userData.platform);
            if (!platform)
                return;
            const material = obj.material;
            if (!(material instanceof THREE.MeshStandardMaterial))
                return;
            material.map = maps.get(platform.phase);
            material.roughness = platform.phase === 'document' ? .83 : .43;
            material.needsUpdate = true;
        });
    }
    buildWalkways() {
        Object.keys(COLORS).forEach(phase => {
            const platforms = PLATFORMS.filter(p => p.phase === phase);
            const struts = [], seams = [], markers = [];
            for (const p of platforms) {
                const x = p.x, z = p.z, half = p.width / 2;
                for (const side of [-1, 1]) {
                    struts.push([x + side * (half - .48), p.top + .083, z, .07, .012, p.length - .48]);
                    for (let k = 0; k < Math.floor(p.length / 2.25); k++) {
                        const zz = z - p.length / 2 + 1.22 + k * 2.25;
                        markers.push([x + side * (half - .62), p.top + .088, zz, .42, .012, .065]);
                    }
                }
                for (let k = 0; k < Math.floor(p.length / 3.45); k++) {
                    const zz = z - p.length / 2 + 1.72 + k * 3.45;
                    seams.push([x, p.top + .083, zz, Math.min(1.32, p.width * .24), .012, .035]);
                }
                if (p.kind === 'view') {
                    // Framing the final lookout without disguising the physical finish plane.
                    markers.push([x, p.top + .09, z - p.length / 2 + 1, p.width - 1.0, .018, .12]);
                }
            }
            const trim = this.material(COLORS[phase].edge, .68, .34, .12);
            const ink = this.material(COLORS[phase].light, .38, .37, .28);
            this.batch(struts, trim);
            this.batch(seams, trim);
            this.batch(markers, ink);
        });
    }
    assembly(group, triggerZ, span, offset) {
        this.highOnly.add(group);
        this.assemblies.push({ group, targetY: group.position.y, triggerZ, span, offset });
    }
    buildPaperScenery() {
        const bronze = this.material(0x93724d, .74, .42);
        const ivory = this.material(0xf1dbb3, .08, .8);
        const frames = [], leaves = [], guides = [];
        for (let i = 0; i < 13; i++) {
            const z = 16 - i * 3.6;
            for (const side of [-1, 1]) {
                const x = side * (10.5 + (i % 4) * .85);
                frames.push([x, 8.7, z, .22, 15.2, .3]);
                frames.push([x, 16.4, z, .92, .18, .9]);
                leaves.push([x + side * 2.4, 9.4, z, .14, 11.8, 3.2]);
                guides.push([x + side * 2.4, 14.9, z, 3.8, .11, .2]);
            }
        }
        this.batch(frames, bronze, this.highOnly);
        this.batch(leaves, ivory, this.highOnly);
        this.batch(guides, bronze, this.highOnly);
        // Oversized paper scrollwork is off the route; never creates collision.
        const torusMat = new THREE.MeshBasicMaterial({ color: 0xc7a473, transparent: true, opacity: .66 });
        for (let i = 0; i < 4; i++) {
            const arch = this.mesh(new THREE.TorusGeometry(5.7, .13, 8, 68, Math.PI), torusMat, this.highOnly);
            arch.position.set(i % 2 ? 12.7 : -12.7, 11.9, 11 - i * 11.5);
            arch.rotation.set(0, .34, 0);
        }
    }
    buildRoomScenery() {
        const stone = this.material(0x5c5675, .55, .57);
        const glass = new THREE.MeshBasicMaterial({ color: 0xbdaeff, transparent: true, opacity: .32, depthWrite: false, side: THREE.DoubleSide });
        for (let i = 0; i < 4; i++) {
            const group = new THREE.Group();
            group.position.set(i % 2 ? 14 : -14, 4, -41 - i * 10);
            const ribs = [], panes = [];
            for (let k = 0; k < 9; k++) {
                const z = (k - 4) * 1.5;
                ribs.push([-4, 2.5, z, .18, 7, .3], [4, 2.5, z, .18, 7, .3]);
                ribs.push([0, 6.1, z, 8.3, .18, .3]);
                if (k < 8)
                    panes.push([0, 2.65, z + .7, 7.7, 5.6, .06]);
            }
            this.batch(ribs, stone, group);
            this.batch(panes, glass, group);
            this.assembly(group, -36 - i * 9, 12, 9);
        }
    }
    buildMonolithScenery() {
        const metal = this.material(0x7a98ab, .83, .25);
        const dark = this.material(0x172334, .57, .45);
        const stamps = [], strata = [];
        for (let i = 0; i < 14; i++) {
            const z = -78 - i * 3.1;
            for (const side of [-1, 1]) {
                const x = side * (13.0 + (i % 3) * .7);
                stamps.push([x, 9.4, z, .26, 16.3, .65]);
                stamps.push([x, 17.5, z, 1.2, .34, .85]);
                for (let row = 0; row < 4; row++)
                    strata.push([x + side * .52, 5 + row * 2.8, z, 1.15, .13, 1.9]);
            }
        }
        this.batch(stamps, metal, this.highOnly);
        this.batch(strata, dark, this.highOnly);
        // A genuinely volumetric broken-file spine with carefully limited silhouette density.
        const group = new THREE.Group();
        group.position.set(-17, 9, -106);
        const layers = [];
        for (let i = 0; i < 26; i++) {
            const zz = (i - 13) * .23;
            layers.push([0, i * .42 - 5.4, zz, 7.7, .15, .17]);
        }
        this.batch(layers, metal, group);
        this.assembly(group, -79, 25, 15);
    }
    buildBecomingScenery() {
        const bronze = this.material(0xbea170, .7, .3);
        const azure = this.material(0x7ee1e0, .27, .44, .28);
        const scaffold = [], joints = [];
        for (let i = 0; i < 12; i++) {
            const z = -130 - i * 4.9;
            for (const side of [-1, 1]) {
                const x = side * (9.6 + (i % 3) * .9);
                scaffold.push([x, 6.8, z, .24, 13.6, .24]);
                joints.push([x, 14.1, z, 1.15, .26, 1.1]);
                joints.push([x, 11.8, z, .55, .14, 2.0]);
            }
        }
        this.batch(scaffold, bronze, this.highOnly);
        this.batch(joints, azure, this.highOnly);
        // A layered, incomplete facade lifts into the future skyline behind the overlook.
        for (let i = 0; i < 3; i++) {
            const group = new THREE.Group();
            group.position.set((i - 1) * 32, 0, -251 - (i === 1 ? 38 : 0));
            const columns = [], beams = [];
            for (let k = 0; k < 7; k++) {
                const x = (k - 3) * 3.4;
                columns.push([x, 9.5, 0, .24, 19, .28]);
                for (let j = 0; j < 4; j++)
                    beams.push([x, 4 + j * 4.5, 0, 3.1, .13, .25]);
            }
            this.batch(columns, bronze, group);
            this.batch(beams, i === 2 ? azure : bronze, group);
            this.assembly(group, -127 - i * 10, 30, 24);
        }
    }
    makeWaterRings() {
        const material = new THREE.MeshBasicMaterial({ color: 0x9dd7d7, transparent: true, opacity: .32, depthWrite: false, side: THREE.DoubleSide });
        const mesh = new THREE.InstancedMesh(new THREE.TorusGeometry(1, .016, 3, 40), material, 22);
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        const matrices = [];
        for (let i = 0; i < 22; i++) {
            const x = (noise(i + 317) - .5) * 170, z = -253 + (noise(i + 621) - .5) * 175;
            this.temp.position.set(x, -10.36, z);
            this.temp.rotation.set(Math.PI / 2, 0, 0);
            this.temp.scale.set(1.5 + noise(i + 11) * 2.5, 1.5 + noise(i + 17) * 2.5, 1);
            this.temp.updateMatrix();
            const matrix = this.temp.matrix.clone();
            matrices.push(matrix);
            mesh.setMatrixAt(i, matrix);
        }
        mesh.instanceMatrix.needsUpdate = true;
        this.highOnly.add(mesh);
        return mesh;
    }
    update(progressZ, elapsed, reducedMotion) {
        for (const a of this.assemblies) {
            const alpha = reducedMotion ? (progressZ <= a.triggerZ ? 1 : 0) : smooth((a.triggerZ - progressZ) / a.span);
            // The building visually assembles but cannot change traversal/collision.
            a.group.position.y = a.targetY - (1 - alpha) * a.offset;
            a.group.visible = alpha > 0.001;
        }
        if (!this.lowEffects && !reducedMotion) {
            // Water shimmer changes intensity only; no texture/reallocation/render target.
            const material = this.ripple.material;
            material.opacity = .24 + Math.sin(elapsed * .35) * .045;
        }
        else
            this.ripple.material.opacity = .25;
    }
    setLowEffects(low) { this.lowEffects = low; this.highOnly.visible = !low; }
    reset() {
        this.assemblies.forEach(a => { a.group.position.y = a.targetY - a.offset; a.group.visible = false; });
        this.ripple.material.opacity = .25;
    }
    dispose() { this.textures.forEach(t => t.dispose()); this.textures.length = 0; }
}
