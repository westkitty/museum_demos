
import { createWorld } from './world.js';
import { createState, step, progress, FIXED_DT, NO_INPUT } from './physics.js';
import { regionFor } from './track.js';
const $ = (id) => {
    const element = document.getElementById(id);
    if (!element)
        throw new Error(`Missing element: ${id}`);
    return element;
};
const elements = {
    canvas: $('gameCanvas'), hud: $('hud'), portal: $('portal'), portalStatus: $('portalStatus'),
    pause: $('pauseOverlay'), victory: $('victoryOverlay'), error: $('errorPanel'),
    errorText: $('errorText'), touch: $('touchControls'), start: $('startButton'),
    introReturn: $('introReturnButton'), pauseButton: $('pauseButton'),
    resume: $('resumeButton'), restartPause: $('restartPauseButton'),
    returnPause: $('returnPauseButton'), replay: $('replayButton'),
    victoryReturn: $('victoryReturnButton'), progressTrack: $('progressTrack'),
    progressFill: $('progressFill'), timer: $('timer'), speed: $('speed'), best: $('best'),
    boostUi: $('boostUi'), boostFill: $('boostFill'), boostValue: $('boostValue'),
    zoneTag: $('zoneTag'), zoneNumber: $('zoneNumber'), zoneName: $('zoneName'), zoneDetail: $('zoneDetail'),
    ticker: $('ticker'), tickerText: $('tickerText'), toast: $('toast'),
    reduced: $('reducedMotion'), lowQuality: $('lowQuality'),
    finishTime: $('finishTime'), finishBest: $('finishBest'), finishFalls: $('finishFalls')
};
const stages = {
    downtown: { number: '01 / 04', name: 'DOWNTOWN DUNCAN', detail: 'Rooftops & broadcast clocks', ticker: 'LIVE: SOMEONE HAS MISPLACED THE START TIME' },
    forest: { number: '02 / 04', name: 'FOREST OUTSKIRTS', detail: 'Giant pines. Questionable ramps.', ticker: 'TIME UNTIL SHOW: NO LONGER A FRIENDLY NUMBER' },
    cedar: { number: '03 / 04', name: 'CEDAR CLIMB', detail: 'Timber trestle & magnetic express', ticker: 'ON LOCATION: THE TRESTLE HAS MADE OTHER PLANS' },
    sentinel: { number: '04 / 04', name: 'OWL SHADOW ESCAPE', detail: 'No battle. Just an urgent departure.', ticker: 'THE GREAT HORNED SENTINEL HAS SEEN THE SCHEDULE' }
};
const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
let reduced = motionQuery.matches;
elements.reduced.checked = reduced;
let qualityLow = false;
let world;
let game = createState();
let active = false, entered = false, destroyed = false, runId = 0;
let currentRegion = 'downtown', toastUntil = 0, wallTime = 0, lastFrame = 0, accumulator = 0, frameCounter = 0, slowDuration = 0;
let bestTime = readBest();
let lastHUD = 0;
const actions = { ...NO_INPUT };
function readBest() {
    try {
        const s = localStorage.getItem('westcat-speed-limit:best:v1');
        if (!s)
            return null;
        const value = Number(s);
        return Number.isFinite(value) && value > 0 ? value : null;
    }
    catch {
        return null;
    }
}
function saveBest(seconds) {
    if (bestTime === null || seconds < bestTime) {
        bestTime = seconds;
        try {
            localStorage.setItem('westcat-speed-limit:best:v1', String(seconds));
        }
        catch { /* storage optional */ }
    }
}
function clock(time) {
    if (!Number.isFinite(time))
        return '00:00.00';
    return `${String(Math.floor(time / 60)).padStart(2, '0')}:${String(Math.floor(time % 60)).padStart(2, '0')}.${String(Math.floor((time % 1) * 100)).padStart(2, '0')}`;
}
function show(element, visible) { element.hidden = !visible; }
function toast(text, duration = 2.5) {
    elements.toast.textContent = text;
    elements.toast.classList.add('visible');
    toastUntil = wallTime + duration;
}
function resetInput() { actions.left = false; actions.right = false; actions.boost = false; actions.jumpPressed = false; }
function transition(region) {
    currentRegion = region;
    const z = stages[region];
    elements.zoneName.textContent = z.name;
    elements.zoneNumber.textContent = z.number;
    elements.zoneDetail.textContent = z.detail;
    elements.tickerText.textContent = z.ticker;
    toast(`${z.number} — ${z.name}`);
}
function dispatchEventToHost(name, data = {}) {
    const detail = { exhibit: 'E26', source: 'westcat-speed-limit', event: name, ...data };
    window.dispatchEvent(new CustomEvent(`westcat:e26:${name}`, { detail }));
    // Optional opt-in, exact-origin iframe bridge. The parent owns navigation and placement.
    const requestedOrigin = new URLSearchParams(window.location.search).get('parentOrigin');
    if (window.parent !== window && requestedOrigin) {
        try {
            const url = new URL(requestedOrigin);
            if (url.origin === requestedOrigin && (url.protocol === 'https:' || url.protocol === 'http:')) {
                window.parent.postMessage({ type: 'westcat:e26', detail }, requestedOrigin);
            }
        }
        catch { /* Ignore malformed or non-origin input */ }
    }
}
function returnToPortal() {
    active = false;
    entered = false;
    game.paused = true;
    resetInput();
    show(elements.portal, true);
    show(elements.pause, false);
    show(elements.victory, false);
    show(elements.hud, false);
    show(elements.progressTrack, false);
    show(elements.zoneTag, false);
    show(elements.ticker, false);
    show(elements.boostUi, false);
    show(elements.touch, false);
    show(elements.portalStatus, true);
    toast('MOCK RETURN REQUESTED — NO LIVE MUSEUM NAVIGATION');
    dispatchEventToHost('return');
    elements.start.focus();
}
function startRun() {
    game = createState();
    game.paused = false;
    active = true;
    entered = true;
    runId++;
    accumulator = 0;
    resetInput();
    transition('downtown');
    show(elements.portal, false);
    show(elements.pause, false);
    show(elements.victory, false);
    show(elements.portalStatus, false);
    for (const e of [elements.hud, elements.progressTrack, elements.zoneTag, elements.ticker, elements.boostUi])
        show(e, true);
    updateTouchVisibility();
    elements.canvas.focus({ preventScroll: true });
    dispatchEventToHost('entry', { run: runId });
}
function togglePause(next) {
    if (!entered || game.finished)
        return;
    const paused = next ?? !game.paused;
    game.paused = paused;
    active = !paused;
    show(elements.pause, paused);
    resetInput();
    if (paused)
        elements.resume.focus();
    else
        elements.canvas.focus({ preventScroll: true });
}
function win() {
    active = false;
    game.paused = true;
    resetInput();
    saveBest(game.elapsed);
    elements.finishTime.textContent = clock(game.elapsed);
    elements.finishBest.textContent = clock(bestTime ?? game.elapsed);
    elements.finishFalls.textContent = String(game.recoveries);
    show(elements.victory, true);
    show(elements.touch, false);
    elements.replay.focus();
    dispatchEventToHost('win', { time: game.elapsed, recoveries: game.recoveries, run: runId });
}
function handleEvent(event) {
    switch (event.type) {
        case 'checkpoint':
            toast(`SIGNAL SAVED / ${event.index + 1} OF 4`);
            break;
        case 'spring':
            toast('SPRING MAIL — PRIORITY DELIVERY', 1.65);
            break;
        case 'loop':
            toast(`COMPLETE THE LOOP / 0${event.index + 1}`, 2.5);
            break;
        case 'rail':
            toast('MAGNETIC EXPRESS — NO TICKET REQUIRED', 2);
            break;
        case 'pad':
            toast('EXTRA POSTAGE / BOOST REFILLED', 1.5);
            break;
        case 'hurdle':
            toast('BRIEF DELAY / NOT AN ACTUAL CRISIS', 1.4);
            break;
        case 'recovery':
            toast('RECOVERED AT CHECKPOINT / +3 SECONDS', 2.8);
            break;
        case 'finish':
            win();
            break;
    }
}
function updateHUD() {
    elements.timer.textContent = clock(game.elapsed);
    elements.speed.textContent = String(Math.round(Math.abs(game.vx))).padStart(3, '0');
    elements.best.textContent = bestTime === null ? '--:--.--' : clock(bestTime);
    const percent = Math.round(progress(game) * 100);
    elements.progressFill.style.width = `${percent}%`;
    elements.progressTrack.setAttribute('aria-valuenow', String(percent));
    elements.boostFill.style.width = `${game.boostEnergy.toFixed(0)}%`;
    elements.boostValue.textContent = `${Math.round(game.boostEnergy)}%`;
    const next = regionFor(game.x);
    if (next !== currentRegion)
        transition(next);
}
const keys = new Map([
    ['ArrowLeft', 'left'], ['KeyA', 'left'], ['ArrowRight', 'right'], ['KeyD', 'right'],
    ['ShiftLeft', 'boost'], ['ShiftRight', 'boost'], ['KeyK', 'boost']
]);
function keyDown(e) {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'Space', 'ShiftLeft', 'ShiftRight', 'KeyA', 'KeyD', 'KeyW', 'KeyK'].includes(e.code) && entered)
        e.preventDefault();
    if (e.code === 'Escape' && entered) {
        e.preventDefault();
        togglePause();
        return;
    }
    if (e.code === 'KeyP' && entered) {
        e.preventDefault();
        togglePause();
        return;
    }
    if (e.code === 'KeyR' && entered) {
        e.preventDefault();
        startRun();
        return;
    }
    if (!active)
        return;
    if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        if (!e.repeat)
            actions.jumpPressed = true;
        return;
    }
    const key = keys.get(e.code);
    if (key) {
        actions[key] = true;
    }
}
function keyUp(e) { const key = keys.get(e.code); if (key)
    actions[key] = false; }
window.addEventListener('keydown', keyDown);
window.addEventListener('keyup', keyUp);
window.addEventListener('blur', () => { resetInput(); if (entered && !game.paused && !game.finished)
    togglePause(true); });
document.querySelectorAll('[data-control]').forEach(button => {
    const action = button.dataset.control;
    const press = (e) => {
        if (!active)
            return;
        e.preventDefault();
        button.setPointerCapture(e.pointerId);
        if (action === 'jump')
            actions.jumpPressed = true;
        else
            actions[action] = true;
        button.classList.add('pressed');
    };
    const release = (e) => {
        if (action !== 'jump')
            actions[action] = false;
        button.classList.remove('pressed');
        if (button.hasPointerCapture(e.pointerId))
            button.releasePointerCapture(e.pointerId);
    };
    button.addEventListener('pointerdown', press);
    button.addEventListener('pointerup', release);
    button.addEventListener('pointercancel', release);
    button.addEventListener('lostpointercapture', () => { if (action !== 'jump')
        actions[action] = false; button.classList.remove('pressed'); });
    button.addEventListener('click', e => {
        if (e.detail === 0 && action === 'jump' && active)
            actions.jumpPressed = true; // keyboard / assistive tech
    });
});
function updateTouchVisibility() { show(elements.touch, active && (window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 760)); }
function frame(time) {
    if (destroyed || !world)
        return;
    const dt = lastFrame ? Math.min(.08, (time - lastFrame) / 1000) : FIXED_DT;
    lastFrame = time;
    wallTime = time / 1000;
    if (active) {
        accumulator = Math.min(.14, accumulator + dt);
        let iterations = 0;
        while (accumulator >= FIXED_DT && iterations < 14) {
            const actionSnapshot = { ...actions };
            actions.jumpPressed = false;
            step(game, actionSnapshot, FIXED_DT, handleEvent);
            accumulator -= FIXED_DT;
            iterations++;
            if (game.finished)
                break;
        }
        if (iterations === 14)
            accumulator = 0;
        frameCounter++;
        slowDuration += (dt > 0.026 ? dt : -slowDuration * .04);
        if (frameCounter > 200 && slowDuration > 3.8 && !qualityLow) {
            qualityLow = true;
            elements.lowQuality.checked = true;
            world.setQuality(true);
            toast('ADAPTIVE QUALITY / PERFORMANCE MODE', 2.2);
            slowDuration = 0;
        }
        if (wallTime - lastHUD > .045) {
            updateHUD();
            lastHUD = wallTime;
        }
    }
    if (elements.toast.classList.contains('visible') && wallTime > toastUntil)
        elements.toast.classList.remove('visible');
    world.update(game, dt, reduced, wallTime);
    world.render();
    window.requestAnimationFrame(frame);
}
function init() {
    try {
        world = createWorld({ canvas: elements.canvas, quality: 'high', reducedMotion: reduced });
    }
    catch (e) {
        const detail = e instanceof Error ? e.message : String(e);
        elements.errorText.textContent = `WebGL could not initialize: ${detail}`;
        show(elements.error, true);
        show(elements.portal, false);
        return;
    }
    window.addEventListener('resize', () => { world?.resize(); updateTouchVisibility(); });
    window.addEventListener('orientationchange', () => { world?.resize(); updateTouchVisibility(); });
    elements.start.addEventListener('click', startRun);
    elements.introReturn.addEventListener('click', returnToPortal);
    elements.pauseButton.addEventListener('click', () => togglePause(true));
    elements.resume.addEventListener('click', () => togglePause(false));
    elements.restartPause.addEventListener('click', startRun);
    elements.returnPause.addEventListener('click', returnToPortal);
    elements.replay.addEventListener('click', startRun);
    elements.victoryReturn.addEventListener('click', returnToPortal);
    elements.reduced.addEventListener('change', () => {
        reduced = elements.reduced.checked;
        document.documentElement.classList.toggle('reduced-motion', reduced);
    });
    elements.lowQuality.addEventListener('change', () => {
        qualityLow = elements.lowQuality.checked;
        world?.setQuality(qualityLow);
    });
    document.documentElement.classList.toggle('reduced-motion', reduced);
    updateHUD();
    window.requestAnimationFrame(frame);
    if (({DEV:false,PROD:true,MODE:"production",BASE_URL:"./"}).PROD && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
        window.addEventListener('load', () => { navigator.serviceWorker.register(`${({DEV:false,PROD:true,MODE:"production",BASE_URL:"./"}).BASE_URL}sw.js`).catch(() => { }); }, { once: true });
    }
}
// Screen closures revoke input & GPU resources rather than leaving ghost loops behind.
window.addEventListener('pagehide', () => {
    destroyed = true;
    resetInput();
    world?.dispose();
    world = undefined;
}, { once: true });
// A back/forward-cache restore cannot reuse GPU resources disposed on pagehide.
window.addEventListener('pageshow', e => { if (e.persisted && destroyed)
    window.location.reload(); });
init();
