const lerp = (a, b, t) => a + (b - a) * t;
export function interpolatePose(previous, current, alpha) {
    const t = Math.max(0, Math.min(1, Number.isFinite(alpha) ? alpha : 1));
    // Never smear a respawn, an out-of-band reset, or a discontinuous fallback.
    const dx = current.x - previous.x, dy = current.y - previous.y, dz = current.z - previous.z;
    if (dx * dx + dy * dy + dz * dz > 16)
        return { ...current };
    return {
        x: lerp(previous.x, current.x, t), y: lerp(previous.y, current.y, t),
        z: lerp(previous.z, current.z, t), vx: lerp(previous.vx, current.vx, t),
        vy: lerp(previous.vy, current.vy, t), vz: lerp(previous.vz, current.vz, t),
        grounded: current.grounded
    };
}
/** Visual-only district selector. The four simulation gates retain their own authority. */
export function districtAtX(x) {
    return Math.max(0, Math.min(3, Math.floor((x - 10) / 40)));
}
