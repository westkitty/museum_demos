import * as THREE from 'three';

import { GESTURES, LevelMachine } from './domain.js';
import { PlayerPhysics } from './physics.js';
import { CityWorld, Avatar } from './scene.js';
import { interpolatePose } from './presentation.js';
const byId = (id) => {
    const node = document.getElementById(id);
    if (!node)
        throw new Error(`Missing document element: ${id}`);
    return node;
};
const html = (value) => value;
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const viewport = byId('viewport');
const overlay = byId('overlay');
const overlayContent = byId('overlay-content');
const gameHud = ['topbar', 'map-rail', 'command-panel', 'chapter-card', 'progress-meter'];
const mobileControls = byId('mobile-controls');
const toastEl = byId('toast');
const errorEl = byId('error');
const cmdList = byId('command-list');
const railItems = byId('rail-items');
const chapterCard = byId('chapter-card');
const initialOverlay = overlayContent.innerHTML;
const level = new LevelMachine();
const physics = new PlayerPhysics();
let previousSim = { ...physics.state };
const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)');
let reduced = prefersReduced.matches;
let phase = 'menu';
let toastExpires = 0;
let previousCheckpoint = 0;
let lastFrame = 0;
let accumulator = 0;
let totalTime = 0;
let stop = false;
let mouseCoarse = window.matchMedia('(pointer: coarse)').matches;
let graphics = mouseCoarse ? 'eco' : 'high';
let graphicsManual = false;
let qualityFrames = 0;
let qualitySlowFrames = 0;
let hasSensor = false;
let sensorBase = null;
let sensorArmed = true;
let sensorEntered = 0;
let sensorLastFire = 0;
let sensorGranted = false;
let activeChapter = -1;
let lastProgress = -1;
const held = new Set();
let queuedJump = false;
let renderer;
let world;
let avatar;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(59, 1, .1, 750);
const lookPoint = new THREE.Vector3(0, 4, 0);
const focus = new THREE.Vector3();
const aimTarget = new THREE.Vector3();
let cameraRoll = 0;
function toast(message, ms = 2300) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    toastExpires = performance.now() + ms;
}
function showGameUI(show) {
    gameHud.forEach(id => byId(id).classList.toggle('hidden', !show));
    mobileControls.classList.toggle('hidden', !show || !mouseCoarse);
}
function makeRows() {
    cmdList.innerHTML = GESTURES.map((g, i) => html(`<div class="command-row" id="command-${i}" style="--phase:${g.hex}"><div class="command-icon" aria-hidden="true">${g.symbol}</div><div><span>${g.gesture.toUpperCase()} · ${i + 1}</span><strong>${g.command.toUpperCase()}</strong></div></div>`)).join('');
    railItems.innerHTML = GESTURES.map((g, i) => html(`<div class="rail-chapter" id="rail-${i}" style="--phase:${g.hex}"><span class="rail-marker"></span><strong>0${i + 1} / ${g.id.toUpperCase()}</strong></div>`)).join('');
}
function refreshUI(force = false) {
    const now = level.activeGate;
    if (force || now !== activeChapter) {
        activeChapter = now;
        GESTURES.forEach((_g, i) => {
            byId(`command-${i}`).classList.toggle('current', i === now);
            byId(`command-${i}`).classList.toggle('done', i < level.unlockedCount);
            byId(`rail-${i}`).classList.toggle('current', i === now);
            byId(`rail-${i}`).classList.toggle('done', i < level.unlockedCount);
        });
        if (now >= 0) {
            const g = GESTURES[now];
            chapterCard.style.setProperty('--phase', g.hex);
            byId('chapter-count').textContent = `GESTURE 0${now + 1} / 04`;
            byId('chapter-title').textContent = g.subtitle;
            byId('chapter-copy').textContent = `Stand on the lit safety circle. ${g.gesture} (${now + 1}) to turn a monumental wall through 90° into a street you can cross.`;
            byId('chapter-hint').innerHTML = `${g.gesture.toUpperCase()} <span>${now + 1}</span> · SOURCE: ${g.command.toUpperCase()}`;
            chapterCard.classList.remove('hidden');
        }
        else {
            byId('chapter-title').textContent = 'ALL FOUR DIRECTIONS';
            byId('chapter-count').textContent = 'FINALE / 04';
            byId('chapter-copy').textContent = 'All four walls have become streets. Follow the luminous lane into the city’s final aperture.';
            byId('chapter-hint').textContent = 'REACH THE TERMINAL ARCH';
            chapterCard.style.setProperty('--phase', '#9fffba');
        }
    }
    byId('rotations').textContent = `${level.unlockedCount} / 4`;
    byId('checkpoint').textContent = String(level.checkpointIndex).padStart(2, '0');
}
function refreshProgress(force = false) {
    const distance = Math.max(0, Math.min(100, Math.round((physics.state.x + 8) / 178 * 100)));
    if (!force && distance === lastProgress)
        return;
    lastProgress = distance;
    byId('route-percent').textContent = `${String(distance).padStart(2, '0')}%`;
    byId('progress-fill').style.width = `${distance}%`;
    byId('progress-meter').setAttribute('aria-valuenow', String(distance));
}
function showOverlay(content) {
    overlayContent.innerHTML = content;
    overlay.classList.remove('hidden');
    showGameUI(false);
}
function startGame() {
    phase = 'playing';
    held.clear();
    queuedJump = false;
    accumulator = 0;
    totalTime = 0;
    camera.position.set(3, 11, 32);
    level.reset();
    physics.reset();
    previousSim = { ...physics.state };
    previousCheckpoint = 0;
    for (let i = 0; i < 4; i++) {
        world.setGateAngle(i, 0);
        world.setGateUnlocked(i, false);
    }
    activeChapter = -1;
    refreshUI(true);
    lastProgress = -1;
    refreshProgress(true);
    world.resetPresentation();
    avatar.resetPresentation();
    cameraRoll = 0;
    lookPoint.set(-2, 4, -10);
    overlay.classList.add('hidden');
    showGameUI(true);
    const active = document.activeElement;
    if (active instanceof HTMLElement)
        active.blur();
    toast('MAKE YOUR WAY TO THE FIRST ILLUMINATED SAFETY PAD.', 3500);
}
function pauseGame() {
    if (phase !== 'playing')
        return;
    phase = 'paused';
    held.clear();
    queuedJump = false;
    showOverlay(html(`<p class="intro-kicker">E19 / DEXTILT</p><h1 style="font-size:clamp(72px,11vw,165px)">PAUSED<span class="stroke">/</span></h1><p class="intro-dek">The streets keep their shape until you return.</p><div class="intro-actions"><button class="primary-btn" id="resume-btn" type="button">RESUME <span>↗</span></button><button class="secondary-btn" id="reset-from-menu" type="button">RESTART ↺</button><button class="secondary-btn" id="return-in-menu" type="button">RETURN TO MUSEUM ↖</button></div>`));
    byId('resume-btn').addEventListener('click', resumeGame);
    byId('reset-from-menu').addEventListener('click', startGame);
    byId('return-in-menu').addEventListener('click', showReturn);
}
function resumeGame() { phase = 'playing'; overlay.classList.add('hidden'); showGameUI(true); accumulator = 0; }
function finishGame() {
    phase = 'complete';
    held.clear();
    world.fx.finish();
    showOverlay(html(`<p class="intro-kicker"><span class="line"></span> FOUR DIRECTIONS / FOUR ILLUSTRATIVE ROTATIONS</p><h1 style="font-size:clamp(80px,13vw,185px)">THE CITY<br>IS <span class="stroke">OPEN.</span></h1><p class="intro-dek">You transformed four walls into streets. The commands you saw were real labels; the city was always imaginary.</p><div class="intro-actions"><button class="primary-btn" id="again-btn" type="button">WALK IT AGAIN ↺</button><button class="secondary-btn" id="complete-return" type="button">RETURN TO MUSEUM ↖</button></div><p class="intro-disclaimer">NO MUSIC-PLAYER, OPERATING-SYSTEM OR REMOTE COMMANDS WERE SENT.</p>`));
    byId('again-btn').addEventListener('click', startGame);
    byId('complete-return').addEventListener('click', showReturn);
}
function showReturn() {
    phase = 'return';
    held.clear();
    // Intentionally mock only. Integration contract lives in integration/README.md.
    showOverlay(html(`<p class="intro-kicker"><span class="line"></span> E19 / MUSEUM PORTAL</p><h1 style="font-size:clamp(75px,12vw,170px)">RETURN<span class="stroke">/</span></h1><p class="intro-dek">Museum portal handoff: <strong>MOCK</strong>.<br>No production museum is connected to this independent exhibit.</p><div class="intro-actions"><button class="primary-btn" id="enter-after-return" type="button">RE-ENTER TILT CITY ↗</button><button class="secondary-btn" id="intro-after-return" type="button">VIEW EXHIBIT TITLE</button></div><p class="intro-disclaimer">FUTURE HOSTS MAY IMPLEMENT THE RETURN CONTRACT. THIS PROTOTYPE NEVER NAVIGATES OR SENDS REAL COMMANDS.</p>`));
    byId('enter-after-return').addEventListener('click', startGame);
    byId('intro-after-return').addEventListener('click', () => { phase = 'menu'; overlayContent.innerHTML = initialOverlay; wireIntro(); });
}
function wireIntro() {
    byId('start-btn').addEventListener('click', startGame);
    byId('return-btn').addEventListener('click', showReturn);
}
function actionRequest(action) {
    if (phase !== 'playing')
        return;
    const s = physics.state;
    const state = level.request(action, s.x, s.grounded);
    switch (state) {
        case 'started': {
            const g = GESTURES[level.movingIndex];
            held.clear();
            queuedJump = false;
            world.fx.gateStart(level.movingIndex);
            toast(`${g.gesture.toUpperCase()} → ${g.command.toUpperCase()} · ILLUSTRATIVE ROTATION`, 2200);
            break;
        }
        case 'wrong-gesture': {
            const g = GESTURES[level.activeGate];
            toast(`THIS GATE REQUIRES: ${g.gesture.toUpperCase()} (${level.activeGate + 1}).`);
            break;
        }
        case 'too-far':
            toast('REACH THE ILLUMINATED SAFETY CIRCLE FIRST.');
            break;
        case 'not-grounded':
            toast('LAND ON THE SAFETY CIRCLE BEFORE TILTING.');
            break;
        case 'in-motion': break;
        case 'already-done':
            toast('ALL FOUR GESTURES COMPLETE. REACH THE FINAL ARCH.');
            break;
        case 'locked-order': break;
    }
}
function onKeyDown(ev) {
    const target = ev.target;
    if (target instanceof HTMLElement && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName))
        return;
    const key = ev.key.toLowerCase();
    if (['arrowleft', 'arrowright', 'arrowup', 'arrowdown', ' '].includes(key))
        ev.preventDefault();
    if (key === 'escape') {
        if (phase === 'playing')
            pauseGame();
        else if (phase === 'paused')
            resumeGame();
        return;
    }
    if (key === 'r') {
        if (phase === 'playing' || phase === 'paused' || phase === 'complete')
            startGame();
        return;
    }
    if (key === 'm') {
        setReduced(!reduced);
        return;
    }
    if (key === 'g') {
        setGraphics(graphics === 'high' ? 'eco' : 'high', true);
        return;
    }
    if (phase !== 'playing')
        return;
    if (key === '1')
        actionRequest('forward');
    else if (key === '2')
        actionRequest('back');
    else if (key === '3')
        actionRequest('right');
    else if (key === '4')
        actionRequest('left');
    else {
        if (key === ' ' && !ev.repeat)
            queuedJump = true;
        held.add(key);
    }
}
function onKeyUp(ev) { held.delete(ev.key.toLowerCase()); }
function axis(positive, negative) {
    const pos = positive.some(k => held.has(k));
    const neg = negative.some(k => held.has(k));
    return Number(pos) - Number(neg);
}
function setReduced(value) {
    reduced = value;
    byId('motion-btn').setAttribute('aria-pressed', String(reduced));
    byId('motion-btn').textContent = reduced ? 'MOTION: REDUCED' : 'REDUCE MOTION';
    if (world)
        world.setReduced(reduced);
}
function setGraphics(value, manual) {
    graphics = value;
    graphicsManual = graphicsManual || manual;
    if (world)
        world.setQuality(value);
    if (renderer)
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, value === 'high' ? 1.65 : 1.04));
    const btn = byId('graphics-btn');
    btn.textContent = value === 'high' ? 'DETAIL: HIGH' : 'DETAIL: ECO';
    btn.setAttribute('aria-pressed', String(value === 'eco'));
    document.documentElement.dataset.graphics = value;
    resize();
}
function onOrientation(ev) {
    if (!hasSensor || phase !== 'playing')
        return;
    if (ev.beta === null || ev.gamma === null)
        return;
    const beta = ev.beta, gamma = ev.gamma;
    if (!sensorBase) {
        sensorBase = { beta, gamma };
        sensorArmed = true;
        toast('SENSOR ZEROED. TILT, THEN RETURN TO NEUTRAL.');
        return;
    }
    const b = clamp(beta - sensorBase.beta, -90, 90);
    const g = clamp(gamma - sensorBase.gamma, -90, 90);
    const nearest = Math.max(Math.abs(b), Math.abs(g));
    const now = performance.now();
    if (nearest < 9) {
        sensorArmed = true;
        sensorEntered = 0;
        return;
    }
    if (nearest < 19 || !sensorArmed || now - sensorLastFire < 1700 || level.movingIndex !== -1) {
        sensorEntered = 0;
        return;
    }
    if (!sensorEntered) {
        sensorEntered = now;
        return;
    }
    if (now - sensorEntered < 130)
        return;
    sensorArmed = false;
    sensorLastFire = now;
    sensorEntered = 0;
    const action = Math.abs(b) >= Math.abs(g) ? (b > 0 ? 'forward' : 'back') : (g > 0 ? 'right' : 'left');
    actionRequest(action);
}
async function toggleSensor() {
    if (hasSensor) {
        window.removeEventListener('deviceorientation', onOrientation);
        hasSensor = false;
        sensorBase = null;
        byId('sensor-btn').textContent = 'SENSOR: OFF';
        byId('sensor-btn').setAttribute('aria-pressed', 'false');
        toast('PHONE SENSOR DISABLED. KEYBOARD AND TOUCH STILL WORK.');
        return;
    }
    if (!('DeviceOrientationEvent' in window)) {
        toast('NO ORIENTATION SENSOR AVAILABLE. USE 1—4 OR TOUCH.');
        return;
    }
    const klass = DeviceOrientationEvent;
    try {
        if (typeof klass.requestPermission === 'function' && !sensorGranted) {
            const result = await klass.requestPermission();
            if (result !== 'granted') {
                toast('SENSOR PERMISSION NOT GRANTED. USE TOUCH OR KEYBOARD.');
                return;
            }
        }
        sensorGranted = true;
        hasSensor = true;
        sensorBase = null;
        sensorArmed = true;
        window.addEventListener('deviceorientation', onOrientation);
        byId('sensor-btn').textContent = 'SENSOR: ON';
        byId('sensor-btn').setAttribute('aria-pressed', 'true');
        toast('SENSOR ENABLED. HOLD PHONE NEUTRAL TO CALIBRATE.');
    }
    catch {
        toast('SENSOR UNAVAILABLE HERE. USE 1—4 OR TOUCH.');
    }
}
function bindTouch() {
    for (const btn of document.querySelectorAll('[data-hold]')) {
        const k = btn.dataset.hold;
        if (!k)
            continue;
        const key = k === 'left' ? 'arrowleft' : k === 'right' ? 'arrowright' : ' ';
        const down = (ev) => {
            ev.preventDefault();
            if (phase !== 'playing')
                return;
            btn.setPointerCapture(ev.pointerId);
            held.add(key);
            btn.classList.add('pressed');
            if (k === 'jump')
                queuedJump = true;
        };
        const up = (ev) => { ev.preventDefault(); held.delete(key); btn.classList.remove('pressed'); };
        btn.addEventListener('pointerdown', down);
        btn.addEventListener('pointerup', up);
        btn.addEventListener('pointercancel', up);
        btn.addEventListener('lostpointercapture', () => { held.delete(key); btn.classList.remove('pressed'); });
    }
    for (const btn of document.querySelectorAll('[data-tilt]')) {
        btn.addEventListener('click', () => actionRequest(btn.dataset.tilt));
    }
}
function frame(now) {
    if (stop)
        return;
    const elapsed = clamp((now - lastFrame) / 1000 || 0, 0, .05);
    lastFrame = now;
    totalTime += elapsed;
    if (phase === 'playing') {
        accumulator = Math.min(accumulator + elapsed, .16);
        let steps = 0;
        while (accumulator >= 1 / 60 && steps < 9) {
            const moving = level.movingIndex;
            if (moving >= 0) {
                const finished = level.tick(reduced ? 2 : 1 / 60);
                GESTURES.forEach((_g, i) => world.setGateAngle(i, level.states[i].angle));
                if (finished !== null) {
                    world.setGateUnlocked(finished, true);
                    world.fx.gateLock(finished);
                    refreshUI(true);
                    toast('90° LOCKED. THE WALL IS NOW A STREET.', 2300);
                }
            }
            else {
                const xAxis = axis(['d', 'arrowright'], ['a', 'arrowleft']);
                const zAxis = axis(['s', 'arrowdown'], ['w', 'arrowup']);
                const groundedBefore = physics.state.grounded;
                const jumpWasQueued = queuedJump;
                previousSim = { ...physics.state };
                physics.step(1 / 60, xAxis, zAxis, queuedJump, level.surfaces());
                if (groundedBefore && jumpWasQueued && !physics.state.grounded)
                    world.fx.jump(physics.state.x, physics.state.z);
                if (!groundedBefore && physics.state.grounded)
                    world.fx.land(physics.state.x, physics.state.z);
                queuedJump = false;
                world.fx.footsteps(physics.state.x, physics.state.z, physics.state.vx, physics.state.grounded, 1 / 60);
                level.approach(physics.state.x);
                if (previousCheckpoint !== level.checkpointIndex) {
                    previousCheckpoint = level.checkpointIndex;
                    refreshUI();
                    world.fx.checkpoint(previousCheckpoint - 1);
                    toast(`CHECKPOINT 0${previousCheckpoint}. STAND HERE AND USE GESTURE ${previousCheckpoint}.`, 2600);
                }
                if (physics.state.y < -18) {
                    const x = level.checkpointX;
                    physics.reset(x);
                    previousSim = { ...physics.state };
                    toast(`RECALIBRATED AT CHECKPOINT 0${level.checkpointIndex}.`);
                }
                if (level.reachFinish(physics.state.x, physics.state.grounded))
                    finishGame();
            }
            accumulator -= 1 / 60;
            steps++;
        }
        refreshProgress();
    }
    else
        accumulator = 0;
    if (now > toastExpires)
        toastEl.classList.remove('show');
    const s = interpolatePose(previousSim, physics.state, phase === 'playing' && !reduced ? accumulator / (1 / 60) : 1);
    avatar.update(s.x, s.y, s.z, phase === 'playing' ? s.vx : 0, s.grounded, totalTime, reduced || phase === 'paused', elapsed);
    world.update(totalTime, elapsed, reduced || phase === 'paused' || phase === 'menu' || phase === 'return', s.x);
    const damp = (lambda) => reduced ? 1 : 1 - Math.exp(-elapsed * lambda);
    if (phase === 'menu' || phase === 'return') {
        const dx = reduced ? 0 : Math.sin(totalTime * .13) * 3.0;
        camera.position.lerp(focus.set(79 + dx, 48, 137), damp(1.12));
        lookPoint.lerp(aimTarget.set(80, 24, -38), damp(2.0));
        cameraRoll = 0;
    }
    else if (phase === 'complete') {
        camera.position.lerp(focus.set(132, 40, 91), damp(1.45));
        lookPoint.lerp(aimTarget.set(152, 18, -40), damp(2.8));
        cameraRoll = 0;
    }
    else {
        const moving = level.movingIndex;
        const reveal = moving >= 0 ? 3.7 : 0;
        const lookAhead = clamp(s.vx * .19, -1.6, 1.6);
        focus.set(s.x + 11.0 + lookAhead, s.y + 8.2 + reveal * .25, s.z + 25.6 + reveal);
        camera.position.lerp(focus, damp(moving >= 0 ? 3.0 : 4.8));
        aimTarget.set(s.x + 7.8 + lookAhead, s.y + 3.55 + reveal * .18, s.z - 14.3);
        lookPoint.lerp(aimTarget, damp(7));
        const targetRoll = (!reduced && moving >= 0) ? Math.sin(Math.abs(level.states[moving].angle) * 1.7) * .061 * Math.sign(level.states[moving].angle) : 0;
        cameraRoll += (targetRoll - cameraRoll) * damp(5.7);
    }
    camera.up.set(Math.sin(cameraRoll), Math.cos(cameraRoll), 0);
    camera.lookAt(lookPoint);
    // One-way automatic fallback: deliberately never oscillate between quality modes.
    if (phase === 'playing' && !graphicsManual && graphics === 'high' && elapsed > 0) {
        qualityFrames++;
        if (elapsed > .029)
            qualitySlowFrames++;
        if (qualityFrames >= 330) {
            if (qualitySlowFrames > 124) {
                setGraphics('eco', false);
                toast('DETAIL REDUCED FOR SMOOTHER PLAY. PRESS G TO CHANGE.');
            }
            qualityFrames = 0;
            qualitySlowFrames = 0;
        }
    }
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
}
function resize() {
    if (!renderer)
        return;
    const w = Math.max(1, viewport.clientWidth), h = Math.max(1, viewport.clientHeight);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.fov = h > w ? 72 : 59;
    camera.updateProjectionMatrix();
}
function init() {
    try {
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.18;
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mouseCoarse ? 1.04 : 1.65));
        viewport.appendChild(renderer.domElement);
        world = new CityWorld(scene);
        avatar = new Avatar(scene);
        setGraphics(graphics, false);
        camera.position.set(80, 48, 140);
        lookPoint.set(80, 24, -38);
        camera.lookAt(lookPoint);
        resize();
        makeRows();
        refreshUI(true);
        wireIntro();
        bindTouch();
        setReduced(reduced);
        byId('reset-btn').addEventListener('click', startGame);
        byId('menu-btn').addEventListener('click', pauseGame);
        byId('motion-btn').addEventListener('click', () => setReduced(!reduced));
        byId('graphics-btn').addEventListener('click', () => setGraphics(graphics === 'high' ? 'eco' : 'high', true));
        byId('sensor-btn').addEventListener('click', () => void toggleSensor());
        window.addEventListener('resize', resize);
        window.addEventListener('keydown', onKeyDown);
        window.addEventListener('keyup', onKeyUp);
        window.addEventListener('blur', () => { held.clear(); queuedJump = false; if (phase === 'playing')
            pauseGame(); });
        document.addEventListener('visibilitychange', () => { if (document.hidden && phase === 'playing')
            pauseGame(); });
        prefersReduced.addEventListener('change', ev => setReduced(ev.matches));
        const coarseQuery = window.matchMedia('(pointer: coarse)');
        coarseQuery.addEventListener('change', ev => { mouseCoarse = ev.matches; mobileControls.classList.toggle('hidden', phase !== 'playing' || !mouseCoarse); });
        requestAnimationFrame(now => { lastFrame = now; frame(now); });
    }
    catch (error) {
        console.error(error);
        errorEl.classList.remove('hidden');
        errorEl.textContent = 'TILT CITY cannot initialize WebGL in this browser. Try an updated browser with hardware acceleration enabled.';
    }
}
init();
// Explicit teardown for embedding hosts. Nothing is exported to globals or performs remote actions.
window.addEventListener('beforeunload', () => {
    stop = true;
    if (hasSensor)
        window.removeEventListener('deviceorientation', onOrientation);
    if (world)
        world.dispose();
    if (renderer) {
        renderer.setAnimationLoop(null);
        renderer.dispose();
        renderer.domElement.remove();
    }
});
