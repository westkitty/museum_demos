export function initialState(chamber = 1) {
    return {
        chamber, linked: chamber === 2, portalTrips: 0,
        traversedWithToken: false, carrying: false, inserted: false, rotorIndex: 0,
        validated: false, verified: false, proofClaimed: false,
        forbiddenAttempts: 0, won: false
    };
}
export const forbiddenResponses = [
    'PUBLICATION REQUEST DENIED. The confetti has also been denied.',
    'A README is not a permission slip. Nice try, architecture.',
    'This door has an enormous ego and absolutely no authority.',
    'REQUEST REJECTED. Zero repositories were harmed.',
    'Spectacular lighting does not constitute informed consent.'
];
export function transition(previous, action) {
    const s = { ...previous };
    const result = (accepted, message, event = 'none') => ({ state: accepted ? s : previous, accepted, message, event });
    if (action === 'RESET')
        return { state: initialState(previous.chamber), accepted: true, message: 'Checkpoint restored. No authority was carried forward.', event: 'reset' };
    // Forbidden is a deliberately safe local joke. It cannot alter any other flag.
    if (action === 'PUBLISH') {
        s.forbiddenAttempts += 1;
        return result(true, forbiddenResponses[(s.forbiddenAttempts - 1) % forbiddenResponses.length], 'denied');
    }
    if (s.won)
        return result(false, 'Proof is already on the record. Fictionally.');
    if (s.chamber === 1) {
        if (action === 'LINK') {
            s.linked = true;
            return result(true, 'Candidate accepted. Reversible portal pair linked.', 'link');
        }
        if (action === 'TRAVERSE' && s.linked) {
            s.portalTrips += 1;
            return result(true, 'A reversible connection. Imagine that: boundaries.', 'teleport');
        }
        if (action === 'EXIT' && s.portalTrips > 0) {
            return { state: initialState(2), accepted: true, message: 'Chamber 01 complete. Welcome to the rotating docket.', event: 'advance' };
        }
        return result(false, action === 'EXIT' ? 'Cross a linked door first. The exit expects evidence.' : 'First, authorize the paired connection.');
    }
    if (s.chamber === 2) {
        if (action === 'PICK_TOKEN' && !s.carrying && !s.inserted) {
            s.carrying = true;
            return result(true, 'Synthetic capability token acquired. Heavy responsibility; light prop.', 'token');
        }
        if (action === 'DROP_TOKEN' && s.carrying) {
            s.carrying = false;
            return result(true, 'Token placed locally. Nothing has been granted.', 'token');
        }
        if (action === 'TRAVERSE' && s.linked) {
            s.portalTrips += 1;
            if (s.carrying)
                s.traversedWithToken = true;
            return result(true, s.carrying ? 'Token crossed the link. Chain of custody maintained.' : 'You arrived. Your token did not.', 'teleport');
        }
        if (action === 'ROTATE' && s.traversedWithToken && !s.inserted) {
            s.rotorIndex = (s.rotorIndex + 1) % 4;
            return result(true, `Docket indexed to ${s.rotorIndex * 90} degrees. Align to 180.`, 'rotor');
        }
        if (action === 'INSERT' && s.traversedWithToken && s.carrying && s.rotorIndex === 2) {
            s.carrying = false;
            s.inserted = true;
            return result(true, 'Scope verified. Token sealed in the 180-degree receiver.', 'seal');
        }
        if (action === 'EXIT' && s.inserted) {
            return { state: initialState(3), accepted: true, message: 'Chamber 02 complete. The publishing apparatus is getting ideas.', event: 'advance' };
        }
        if (action === 'ROTATE')
            return result(false, 'The rotor requires a token to have crossed the linked doors.');
        if (action === 'INSERT')
            return result(false, 'Receiver needs a carried token and an exact 180-degree alignment.');
        if (action === 'EXIT')
            return result(false, 'No exit until the scoped token is sealed.');
        return result(false, 'Pick up the synthetic token using Interact.');
    }
    if (action === 'VALIDATE') {
        s.validated = true;
        s.linked = true;
        return result(true, 'BOUNDARY APPROVED: read-only, bounded validation. Portals linked.', 'link');
    }
    if (action === 'TRAVERSE' && s.validated && s.linked) {
        s.portalTrips += 1;
        return result(true, 'Approved route taken. Zero side effects.', 'teleport');
    }
    if (action === 'VERIFY' && s.validated && s.portalTrips > 0) {
        s.verified = true;
        return result(true, 'Evidence reconciled. Proof available. This building will now overreact.', 'proof');
    }
    if (action === 'CLAIM_PROOF' && s.verified) {
        s.proofClaimed = true;
        s.won = true;
        return result(true, 'VALIDATION PASSED. Nobody deployed anything.', 'victory');
    }
    if (action === 'VERIFY')
        return result(false, 'Verification requires the authorized link to have been traversed.');
    if (action === 'CLAIM_PROOF')
        return result(false, 'The proof lamp stays dark until verification succeeds.');
    return result(false, 'Authority before invocation. Choose the smaller door.');
}
export function phaseLabels(s) {
    if (s.chamber === 1)
        return [
            { label: 'SCAN', done: true }, { label: 'CANDIDATE', done: s.linked },
            { label: 'AUTHORITY', done: s.linked }, { label: 'INVOKE', done: s.portalTrips > 0 },
            { label: 'VERIFY', done: false }, { label: 'PROOF', done: false }
        ];
    if (s.chamber === 2)
        return [
            { label: 'SCAN', done: true }, { label: 'CANDIDATE', done: true },
            { label: 'AUTHORITY', done: s.traversedWithToken }, { label: 'INVOKE', done: s.portalTrips > 0 },
            { label: 'VERIFY', done: s.inserted }, { label: 'PROOF', done: false }
        ];
    return [
        { label: 'SCAN', done: true }, { label: 'CANDIDATE', done: true },
        { label: 'AUTHORITY', done: s.validated }, { label: 'INVOKE', done: s.portalTrips > 0 },
        { label: 'VERIFY', done: s.verified }, { label: 'PROOF', done: s.proofClaimed }
    ];
}
export function objective(s) {
    switch (s.chamber) {
        case 1:
            return !s.linked ? 'Find the LINK console and authorize one reversible pair.'
                : s.portalTrips === 0 ? 'Walk into the cyan portal. Its partner leads across the wall.'
                    : 'Reach the far-side archive gate and interact to continue.';
        case 2:
            return !s.carrying && !s.traversedWithToken ? 'Pick up the synthetic capability token.'
                : !s.traversedWithToken ? 'Carry the token through the linked portal.'
                    : s.rotorIndex !== 2 && !s.inserted ? 'Index the golden rotor to 180 degrees at its pedestal.'
                        : !s.inserted ? 'Carry the token to the aligned receiver and insert it.'
                            : 'Reach the far-side gate to enter the final chamber.';
        case 3:
            return !s.validated ? 'Choose bounded validation, not the unauthorized publish portal.'
                : s.portalTrips === 0 ? 'Use the teal validation link. The red portal remains forbidden.'
                    : !s.verified ? 'Interact with the far-side verification plinth.'
                        : !s.proofClaimed ? 'Find the tiny VALIDATION PASSED lamp in the unfolding hall.'
                            : 'Validation passed. Restart or return to the mock museum.';
    }
}
export function isPortalActive(s) {
    return s.linked;
}
