/** Render-resolution adaptation only; never changes the user's authored world or chosen quality tier. */
export class AdaptiveResolution {
    scale = 1;
    enabled = true;
    samples = [];
    goodWindows = 0;
    badWindows = 0;
    get percent() { return Math.round(this.scale * 100); }
    reset() { this.scale = 1; this.samples = []; this.goodWindows = 0; this.badWindows = 0; }
    sample(frameMs) {
        if (!this.enabled || !Number.isFinite(frameMs) || frameMs <= 0 || frameMs > 180)
            return false;
        this.samples.push(frameMs);
        if (this.samples.length < 90)
            return false;
        const samples = this.samples.sort((a, b) => a - b);
        const p90 = samples[Math.floor((samples.length - 1) * .9)];
        this.samples = [];
        if (p90 > 28) {
            this.badWindows++;
            this.goodWindows = 0;
        }
        else if (p90 < 16) {
            this.goodWindows++;
            this.badWindows = 0;
        }
        else {
            this.goodWindows = 0;
            this.badWindows = 0;
        }
        if (this.badWindows >= 2 && this.scale > .7) {
            this.badWindows = 0;
            this.scale = Math.max(.7, +(this.scale - .15).toFixed(2));
            return true;
        }
        if (this.goodWindows >= 4 && this.scale < 1) {
            this.goodWindows = 0;
            this.scale = Math.min(1, +(this.scale + .1).toFixed(2));
            return true;
        }
        return false;
    }
}
