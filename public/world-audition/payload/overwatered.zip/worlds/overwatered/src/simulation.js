import { CAN, CHECKPOINTS, DEW, groundExists, sqDistXZ, STATIONS, SUMMIT, SURFACES, surfaceUnlocked, VINES } from './course.js';
const PLAYER_RADIUS = 0.46;
const GRAVITY = 20;
const JUMP = 11.4;
const WALK = 8.2;
const GLIDE_SPEED = 15.5;
const GLIDE_SINK = 2.55;
const WATER_CAP = 3;
const POWER_CAP = 100;
const TOTAL_STAGES = 3;
const PLAYER_HEIGHT = 1.5;
const DEFAULT_CONTROLS = { forward: 0, right: 0, cameraYaw: 0, jumpHeld: false, jumpPressed: false, glidePressed: false, waterPressed: false };
function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }
function approach(v, goal, speed) { return v < goal ? Math.min(goal, v + speed) : Math.max(goal, v - speed); }
function dist3XZ(a, b) { return Math.sqrt(sqDistXZ(a.x, a.z, b.x, b.z)); }
function copyPos(p) { return { x: p.x, y: p.y, z: p.z }; }
export class GardenSimulation {
    state;
    events = [];
    constructor() { this.state = this.newState(); }
    newState() {
        return {
            phase: 'title', player: { position: copyPos(CHECKPOINTS[0]), velocity: { x: 0, y: 0, z: 0 }, grounded: true, climbing: false, gliding: false, facing: 0 },
            grown: 0, water: 2, power: 88, checkpoint: 0, dewCooldown: [0, 0, 0], summitVisited: false, summitLaunch: false, longGlideDistance: 0,
            elapsed: 0, won: false, deaths: 0, seedTime: [-1, -1, -1]
        };
    }
    start() { if (this.state.phase === 'title' || this.state.phase === 'returned')
        this.state.phase = 'playing'; }
    pause() { if (this.state.phase === 'playing')
        this.state.phase = 'paused'; }
    resume() { if (this.state.phase === 'paused')
        this.state.phase = 'playing'; }
    returnToMuseum() { this.state.phase = 'returned'; }
    restart() { this.state = this.newState(); this.state.phase = 'playing'; this.events = []; }
    drainEvents() { const r = this.events; this.events = []; return r; }
    serialize() {
        const s = this.state;
        return { version: 1, grown: s.grown, water: s.water, power: s.power, checkpoint: s.checkpoint, elapsed: s.elapsed, won: s.won, summitVisited: s.summitVisited };
    }
    restore(value) {
        if (!value || typeof value !== 'object')
            return false;
        const v = value;
        if (v.version !== 1 || !Number.isInteger(v.grown) || !Number.isInteger(v.checkpoint) || !Number.isFinite(v.water) || !Number.isFinite(v.power) || !Number.isFinite(v.elapsed))
            return false;
        const grown = v.grown, cp = v.checkpoint;
        if (grown < 0 || grown > TOTAL_STAGES || cp < 0 || cp > 4 || cp > grown + 1)
            return false;
        const s = this.newState();
        s.grown = grown;
        s.checkpoint = cp;
        s.water = clamp(v.water, 0, WATER_CAP);
        s.power = clamp(v.power, 0, POWER_CAP);
        s.elapsed = clamp(v.elapsed, 0, 36000);
        s.summitVisited = Boolean(v.summitVisited) && grown === 3;
        s.won = Boolean(v.won) && s.summitVisited;
        s.seedTime = [0, 1, 2].map(i => i < grown ? 0 : -1);
        s.player.position = copyPos(CHECKPOINTS[cp]);
        s.phase = 'title';
        this.state = s;
        return true;
    }
    emit(e) { this.events.push(e); }
    setCheckpoint(i) {
        if (i <= this.state.checkpoint)
            return;
        this.state.checkpoint = i;
        this.emit({ type: 'checkpoint', index: i });
    }
    collectDew(dt) {
        const s = this.state, p = s.player.position;
        for (let i = 0; i < DEW.length; i++) {
            s.dewCooldown[i] = Math.max(0, s.dewCooldown[i] - dt);
            const d = DEW[i];
            if (s.dewCooldown[i] > 0 || Math.abs(p.y - d.y) > 2.1 || sqDistXZ(p.x, p.z, d.x, d.z) > 2.8 ** 2)
                continue;
            if (s.water >= WATER_CAP && s.power >= POWER_CAP - 14)
                continue;
            s.water = clamp(s.water + 1, 0, WATER_CAP);
            s.power = clamp(s.power + 24, 0, POWER_CAP);
            s.dewCooldown[i] = 10;
            this.emit({ type: 'dew', index: i });
            this.emit({ type: 'toast', message: 'Condensed morning dew: +1 water, +24 power. Bureaucracy defeated.' });
        }
    }
    water() {
        const s = this.state, p = s.player.position;
        if (s.phase !== 'playing')
            return false;
        if (s.grown >= TOTAL_STAGES) {
            this.emit({ type: 'toast', message: 'All three plants are already gloriously overwatered.' });
            return false;
        }
        const station = STATIONS[s.grown];
        const near = sqDistXZ(p.x, p.z, station.x, station.z) < 3.9 ** 2 && Math.abs(p.y - station.y) < 2.5;
        if (!near) {
            this.emit({ type: 'toast', message: 'Approach the glowing seed pedestal before watering.' });
            return false;
        }
        if (s.water < station.costWater || s.power < station.costPower) {
            this.emit({ type: 'toast', message: 'Insufficient resources. Stand beside the blue dew collector for renewable supplies.' });
            return false;
        }
        s.water -= station.costWater;
        s.power -= station.costPower;
        s.grown = station.id;
        s.seedTime[s.grown - 1] = s.elapsed;
        this.setCheckpoint(s.grown === 1 ? 1 : s.grown === 2 ? 2 : 3);
        this.emit({ type: 'grow', stage: s.grown });
        this.emit({ type: 'toast', message: station.quip });
        return true;
    }
    respawn() {
        const s = this.state, p = s.player;
        p.position = copyPos(CHECKPOINTS[s.checkpoint]);
        p.velocity = { x: 0, y: 0, z: 0 };
        p.grounded = true;
        p.gliding = false;
        p.climbing = false;
        s.summitLaunch = false;
        s.longGlideDistance = 0;
        s.deaths++;
        this.emit({ type: 'respawn' });
        this.emit({ type: 'toast', message: 'Botanical insurance claim approved. Checkpoint restored.' });
    }
    /** Deterministic, fixed-step update; no DOM, rendering, or external state. */
    step(dt, input = {}) {
        if (this.state.phase !== 'playing')
            return this.drainEvents();
        if (!(dt > 0 && dt <= 1 / 20))
            throw new Error('Simulation expects bounded fixed-step dt <= 50ms');
        const c = { ...DEFAULT_CONTROLS, ...input }, s = this.state, p = s.player;
        const old = copyPos(p.position);
        s.elapsed += dt;
        this.collectDew(dt);
        if (c.waterPressed)
            this.water();
        // The only vertical climb mechanism is a nearby authored vine, never a stamina tax.
        const vine = VINES.find(v => v.stage <= s.grown &&
            sqDistXZ(p.position.x, p.position.z, v.x, v.z) < (v.radius + 0.5) ** 2 &&
            p.position.y >= v.base - 1 && p.position.y <= v.top + 0.3);
        const climbRequested = c.forward > 0.25 && c.jumpHeld && !!vine && !p.gliding && p.position.y < (vine?.top ?? 0) - 0.2;
        p.climbing = climbRequested;
        if (climbRequested && vine) {
            p.velocity.y = 5.9;
            p.position.x += (vine.x - p.position.x) * Math.min(1, dt * 1.2);
            p.position.z += (vine.z - p.position.z) * Math.min(1, dt * 1.2);
            p.grounded = false;
        }
        if (c.jumpPressed && p.grounded) {
            p.velocity.y = JUMP;
            p.grounded = false;
            p.gliding = false;
        }
        else if (c.jumpPressed && !p.grounded && !p.climbing) {
            p.gliding = !p.gliding;
        }
        if (c.glidePressed && !p.grounded && !p.climbing) {
            p.gliding = !p.gliding;
        }
        if (p.grounded)
            p.gliding = false;
        if (p.gliding) {
            p.climbing = false;
            // Preserve natural upward jump momentum; once the apex passes, glide only descends.
            if (p.velocity.y > 0)
                p.velocity.y = Math.max(0, p.velocity.y - GRAVITY * dt);
            else
                p.velocity.y = -GLIDE_SINK;
            if (s.summitVisited && !s.summitLaunch && p.position.y > 33 && p.position.z > 63) {
                s.summitLaunch = true;
                s.longGlideDistance = 0;
                this.emit({ type: 'toast', message: 'THE FINAL GLIDE: aim for the floating watering can. Try not to become compost.' });
            }
        }
        else if (!p.climbing) {
            p.velocity.y -= GRAVITY * dt;
        }
        let forward = clamp(c.forward, -1, 1), right = clamp(c.right, -1, 1);
        const mag = Math.hypot(forward, right);
        if (mag > 1) {
            forward /= mag;
            right /= mag;
        }
        const sin = Math.sin(c.cameraYaw), cos = Math.cos(c.cameraYaw);
        const mx = sin * forward + cos * right;
        const mz = cos * forward - sin * right;
        const currentSpeed = p.gliding ? GLIDE_SPEED : WALK;
        const wantedX = mx * currentSpeed, wantedZ = mz * currentSpeed;
        const accel = p.gliding ? 14 : p.grounded ? 35 : 23;
        if (p.climbing) {
            // Assisted vine latch prevents directional input from ejecting the climber.
            p.velocity.x = 0;
            p.velocity.z = 0;
        }
        else if (p.gliding && mag < 0.1) {
            // Forward momentum persists on deployment, even if movement keys are released.
            const fx = Math.sin(p.facing), fz = Math.cos(p.facing);
            p.velocity.x = approach(p.velocity.x, fx * 4.5, accel * dt);
            p.velocity.z = approach(p.velocity.z, fz * 4.5, accel * dt);
        }
        else {
            p.velocity.x = approach(p.velocity.x, wantedX, accel * dt);
            p.velocity.z = approach(p.velocity.z, wantedZ, accel * dt);
        }
        if (mag > 0.18)
            p.facing = Math.atan2(mx, mz);
        p.position.x += p.velocity.x * dt;
        p.position.z += p.velocity.z * dt;
        p.position.y += p.velocity.y * dt;
        // Restrained architectural collision, separate from authoritative walkable surfaces.
        for (const z of [-4, 10, 24, 38, 52]) {
            for (const x of [-21, 21]) {
                const dx = p.position.x - x, dz = p.position.z - z, dis = Math.hypot(dx, dz), r = 1.4 + PLAYER_RADIUS;
                if (dis < r && p.position.y < 31) {
                    const angle = dis > .0001 ? Math.atan2(dz, dx) : 0;
                    p.position.x = x + Math.cos(angle) * r;
                    p.position.z = z + Math.sin(angle) * r;
                }
            }
        }
        if (p.position.x < -47 || p.position.x > 47 || p.position.z < -40 || p.position.z > 168) {
            this.respawn();
            return this.drainEvents();
        }
        // Falling feet hit only the top face of authored ledges and the bounded ground deck.
        let bestY = -Infinity;
        if (groundExists(p.position.x, p.position.z))
            bestY = 0;
        for (const surf of SURFACES) {
            if (!surfaceUnlocked(surf, s.grown))
                continue;
            const nx = (p.position.x - surf.x) / (surf.rx + PLAYER_RADIUS * .4);
            const nz = (p.position.z - surf.z) / (surf.rz + PLAYER_RADIUS * .4);
            if (nx * nx + nz * nz > 1)
                continue;
            if (old.y >= surf.top - 0.14 && p.position.y <= surf.top + 0.04 && p.velocity.y <= 0)
                bestY = Math.max(bestY, surf.top);
        }
        // Climbing allows passing through intermediate petals from underneath.
        if (p.position.y <= bestY && p.velocity.y <= 0) {
            p.position.y = bestY;
            p.velocity.y = 0;
            p.grounded = true;
            p.climbing = false;
            p.gliding = false;
        }
        else if (p.position.y > bestY + 0.03) {
            p.grounded = false;
        }
        if (s.summitVisited && s.summitLaunch && p.gliding) {
            s.longGlideDistance += dist3XZ(old, p.position);
        }
        if (s.grown === 3 && !s.summitVisited && p.position.y >= SUMMIT.y - .1 &&
            sqDistXZ(p.position.x, p.position.z, SUMMIT.x, SUMMIT.z) < 7 ** 2) {
            s.summitVisited = true;
            this.setCheckpoint(4);
            this.emit({ type: 'summit' });
            this.emit({ type: 'toast', message: 'SUMMIT ACHIEVED. You are the hero this watering can probably deserves.' });
        }
        if (s.grown === 3 && s.summitVisited && s.longGlideDistance >= 43 &&
            p.grounded && Math.abs(p.position.y - CAN.y) < 0.45 &&
            sqDistXZ(p.position.x, p.position.z, CAN.x, CAN.z) < 4.8 ** 2) {
            s.won = true;
            s.phase = 'victory';
            this.emit({ type: 'victory' });
        }
        if (p.position.y < -18) {
            this.respawn();
        }
        return this.drainEvents();
    }
    static PLAYER_HEIGHT = PLAYER_HEIGHT;
}
