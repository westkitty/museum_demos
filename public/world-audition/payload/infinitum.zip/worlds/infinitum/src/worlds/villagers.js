import * as THREE from 'three';
import { heightAt, clamp } from '../core/math.js';
import { soilMoisture } from '../core/simulation.js';
import { labelObject } from './shared.js';
/** Tiny deterministic settlement population. No collision engine or autonomous timers. */
export class VillageLife {
    residents = [];
    vegetablePlots = [];
    constructor(scene, s, quality, inspection) {
        const cloth = [0x647a76, 0xb18a6c, 0x647b91, 0x986e77, 0x8a7962];
        const stone = new THREE.MeshStandardMaterial({ color: 0x6a6255, roughness: .93 });
        const complexion = [0xc9a78b, 0xad846e, 0xd4baa0, 0x926e5a].map(color => new THREE.MeshStandardMaterial({ color, roughness: .91 }));
        const bronze = new THREE.MeshStandardMaterial({ color: 0xb99d76, metalness: .62, roughness: .42 });
        const count = quality === 'low' ? 7 : 13;
        for (let i = 0; i < count; i++) {
            const group = new THREE.Group();
            const costume = new THREE.MeshStandardMaterial({ color: cloth[i % cloth.length], roughness: .89 });
            const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.35, .83, 3, 7), costume);
            torso.position.y = 1.28;
            group.add(torso);
            const head = new THREE.Mesh(new THREE.SphereGeometry(.3, 10, 8), complexion[i % complexion.length]);
            head.position.y = 2.35;
            group.add(head);
            // A deliberate family of recognisable workwear silhouettes, not identical cone people.
            if (i % 3 === 0) {
                const brim = new THREE.Mesh(new THREE.CylinderGeometry(.52, .52, .065, 11), stone);
                brim.position.y = 2.65;
                brim.userData.feature = 'resident-headwear-art';
                group.add(brim);
                const crown = new THREE.Mesh(new THREE.CylinderGeometry(.31, .36, .29, 9), costume);
                crown.position.y = 2.83;
                group.add(crown);
            }
            else if (i % 3 === 1) {
                const hood = new THREE.Mesh(new THREE.SphereGeometry(.37, 10, 6, 0, Math.PI * 2, 0, Math.PI * .57), costume);
                hood.position.y = 2.46;
                hood.userData.feature = 'resident-headwear-art';
                group.add(hood);
            }
            else {
                const cap = new THREE.Mesh(new THREE.CylinderGeometry(.41, .33, .17, 9), stone);
                cap.position.y = 2.70;
                cap.rotation.z = .1;
                cap.userData.feature = 'resident-headwear-art';
                group.add(cap);
                const pin = new THREE.Mesh(new THREE.SphereGeometry(.08, 6, 5), bronze);
                pin.position.set(.28, 2.76, .19);
                group.add(pin);
            }
            const arms = [new THREE.Group(), new THREE.Group()];
            for (let a = 0; a < 2; a++) {
                arms[a].position.set(a === 0 ? -.48 : .48, 1.9, 0);
                const arm = new THREE.Mesh(new THREE.CapsuleGeometry(.13, .56, 3, 5), costume);
                arm.position.y = -.37;
                arms[a].add(arm);
                group.add(arms[a]);
            }
            // Legs rotate from the hips, not their centres, for grounded gait/contact.
            const legs = [new THREE.Group(), new THREE.Group()];
            legs.forEach((leg, j) => {
                leg.position.set(j === 0 ? -.18 : .18, .84, 0);
                const boot = new THREE.Mesh(new THREE.CylinderGeometry(.14, .18, .82, 6), stone);
                boot.position.y = -.41;
                leg.add(boot);
                group.add(leg);
            });
            // Tools are carried on the animated arm, so secondary motion stays coupled.
            let lantern;
            if (i % 4 === 0) {
                const frame = new THREE.Mesh(new THREE.CylinderGeometry(.17, .13, .39, 7), bronze);
                frame.position.set(0, -.55, .26);
                arms[1].add(frame);
                lantern = new THREE.Mesh(new THREE.SphereGeometry(.12, 8, 6), new THREE.MeshStandardMaterial({ color: 0xffc594, emissive: 0xffb772, emissiveIntensity: .2, roughness: .48 }));
                lantern.position.copy(frame.position);
                arms[1].add(lantern);
            }
            else if (i % 4 === 1) {
                const satchel = new THREE.Mesh(new THREE.BoxGeometry(.39, .46, .19), stone);
                satchel.position.set(.36, 1.07, -.30);
                group.add(satchel);
                const clasp = new THREE.Mesh(new THREE.SphereGeometry(.055, 5, 4), bronze);
                clasp.position.set(.36, 1.08, -.408);
                group.add(clasp);
            }
            else if (i % 4 === 2) {
                const shoulder = new THREE.Mesh(new THREE.ConeGeometry(.42, .96, 7), costume);
                shoulder.rotation.z = Math.PI;
                shoulder.position.y = 1.14;
                group.add(shoulder);
            }
            else {
                const instrument = new THREE.Mesh(new THREE.TorusGeometry(.22, .055, 5, 12), bronze);
                instrument.position.set(0, -.63, .27);
                instrument.rotation.x = .48;
                arms[0].add(instrument);
            }
            const angle = i / count * Math.PI * 2;
            const home = [-29 + Math.sin(angle) * (7 + i % 4 * 2), 28 + Math.cos(angle) * (8 + i % 3 * 3)];
            const x = home[0], z = home[1];
            group.position.set(x, heightAt(x, z, s), z);
            group.scale.setScalar(.8 + i % 3 * .06);
            labelObject(group, `RESIDENT ${i + 1} · a life beneath the raindrop`, 'resident');
            group.userData.clueId = 'village';
            group.userData.feature = 'resident';
            inspection.push(group);
            scene.add(group);
            this.residents.push({ group, torso, head, leftArm: arms[0], rightArm: arms[1], leftLeg: legs[0], rightLeg: legs[1], lantern, x, z, home, phase: i * .73, speed: .6 + i % 4 * .14 });
        }
        const fieldMat = new THREE.MeshStandardMaterial({ color: 0x426b4d, roughness: .96 });
        for (let i = 0; i < 6; i++) {
            const mesh = new THREE.Mesh(new THREE.BoxGeometry(2.4, .15, 5.6), fieldMat.clone());
            const x = -44 + i * 3.4, z = 44 + (i % 2) * 2;
            mesh.position.set(x, heightAt(x, z, s) + .1, z);
            scene.add(mesh);
            this.vegetablePlots.push(mesh);
        }
    }
    update(dt, elapsed, s) {
        const night = s.time < 5 || s.time > 21;
        const storm = s.weather === 'Rain' || s.weather === 'Thunderstorm' || s.weather === 'Snow';
        const celebration = s.ruins.every(r => r.snapped);
        for (let i = 0; i < this.residents.length; i++) {
            const r = this.residents[i];
            const angle = (s.time / 24) * Math.PI * 2 + i * 1.24;
            const market = soilMoisture(s, -43, 44) > .63 && i % 4 === 1;
            const targetX = storm || night ? r.home[0] : celebration && i % 4 === 0 ? 30 + Math.sin(angle) * 4 : market ? -43 + Math.sin(angle) * 2 : -30 + Math.sin(angle) * (12 + i % 3 * 3);
            const targetZ = storm || night ? r.home[1] : celebration && i % 4 === 0 ? 44 + Math.cos(angle) * 3 : market ? 44 + Math.cos(angle) * 2 : 31 + Math.cos(angle * 1.13) * (11 + i % 3 * 3);
            const dx = targetX - r.x, dz = targetZ - r.z;
            const length = Math.hypot(dx, dz);
            const move = Math.min(length, Math.min(dt, .05) * r.speed * (storm ? .72 : 1));
            if (length > .06) {
                r.x += dx / length * move;
                r.z += dz / length * move;
                r.group.rotation.y = Math.atan2(-dx, -dz);
            }
            r.group.position.set(r.x, heightAt(r.x, r.z, s), r.z);
            const gait = length > .1 ? Math.sin(elapsed * 4.8 + i * 2) * .31 * (s.reducedMotion ? .15 : 1) : 0;
            r.leftArm.rotation.x = gait;
            r.rightArm.rotation.x = -gait;
            r.leftLeg.rotation.x = -gait * .72;
            r.rightLeg.rotation.x = gait * .72;
            r.torso.rotation.z = Math.sin(elapsed * .63 + i) * .012;
            r.torso.scale.y = 1 + Math.sin(elapsed * .9 + r.phase) * .013 * (s.reducedMotion ? .2 : 1);
            r.head.rotation.y = Math.sin(elapsed * .39 + r.phase) * .18 * (s.reducedMotion ? .12 : 1);
            if (r.lantern)
                r.lantern.material.emissiveIntensity = night ? 1.2 : storm ? .7 : .12;
            // Residents enter their buildings during weather; don't spawn them out of view.
            r.group.visible = !(night && i % 3 !== 0) && !(storm && i % 4 === 0);
        }
        for (let i = 0; i < this.vegetablePlots.length; i++) {
            const p = this.vegetablePlots[i];
            const wet = soilMoisture(s, p.position.x, p.position.z);
            const material = p.material;
            material.color.setHSL(.30, .18 + wet * .25, .2 + wet * .09);
            p.scale.y = 1 + clamp(wet * .2, 0, .2);
        }
    }
    refreshTerrain(s) {
        this.vegetablePlots.forEach(p => { p.position.y = heightAt(p.position.x, p.position.z, s) + .1; });
    }
}
