import * as THREE from 'three';
import { landmarksIn } from '../core/expedition.js';
/** Deliberately small, low-draw-call landmark affordance: no text texture or external asset. */
export class ExpeditionBeacons {
    group = new THREE.Group();
    crowns = [];
    constructor(scene, world) {
        const ringGeometry = new THREE.TorusGeometry(.72, .035, 5, 28);
        const meshGeometry = new THREE.OctahedronGeometry(.34, 0);
        for (const mark of landmarksIn(world)) {
            const marker = new THREE.Group();
            marker.position.set(...mark.position);
            const ring = new THREE.Mesh(ringGeometry.clone(), new THREE.MeshBasicMaterial({ color: 0xc4d8b7, transparent: true, opacity: .38, depthWrite: false }));
            ring.rotation.x = Math.PI * .5;
            ring.position.y = -1.15;
            const crown = new THREE.Mesh(meshGeometry.clone(), new THREE.MeshBasicMaterial({ color: world === 2 ? 0xaac9f4 : 0xd8d1ad, transparent: true, opacity: .46, depthWrite: false }));
            crown.position.y = 1.9;
            marker.add(ring, crown);
            marker.userData.landmarkId = mark.id;
            this.crowns.push(crown);
            this.group.add(marker);
        }
        scene.add(this.group);
    }
    update(elapsed, s) {
        // Reduced motion suppresses animation, not navigation landmarks.
        this.group.visible = true;
        for (let i = 0; i < this.crowns.length; i++) {
            const m = this.crowns[i];
            m.rotation.y = s.reducedMotion ? i : elapsed * .22 + i;
            m.material.opacity = s.reducedMotion ? .4 : .3 + .14 * Math.sin(elapsed * .45 + i);
        }
    }
    dispose() {
        this.group.parent?.remove(this.group);
        this.group.traverse(o => {
            const m = o;
            if (m.geometry)
                m.geometry.dispose();
            if (m.material)
                for (const mat of Array.isArray(m.material) ? m.material : [m.material])
                    mat.dispose();
        });
    }
}
