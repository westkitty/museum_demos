export const POINTS = Object.freeze({
    strike: { x: -4.06, z: 0.76 },
    rockStart: { x: -3.32, z: 0.48 },
    rockEnd: { x: -5.16, z: -1.18 },
    windStart: { x: -1.05, z: -3.34 },
    plaza: { x: 0.75, z: 0.30 },
    sign: { x: 3.43, z: 2.48 },
});
const distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const clamp = (v, low, high) => Math.min(high, Math.max(low, v));
const within = (a, b, r) => distance(a, b) <= r;
export class GodGameRules {
    state;
    constructor() { this.state = this.initial(); }
    initial() {
        return {
            gesture: 'strike', rockDone: false, confettiDone: false, signDone: false,
            sweepAttached: false, sweepProgress: 0, wind: { ...POINTS.windStart },
            victory: false, victoryTime: 0, rockTime: 0, wardTime: 0,
            signHasFallenAgain: false, seconds: 0,
        };
    }
    restart() { this.state = this.initial(); }
    select(gesture) {
        if (this.state.sweepAttached)
            this.state.sweepAttached = false;
        this.state.gesture = gesture;
    }
    completed() {
        return Number(this.state.rockDone) + Number(this.state.confettiDone) + Number(this.state.signDone);
    }
    checkTarget(position, residents = []) {
        const s = this.state;
        if (s.victory)
            return { ok: false, code: 'victory', message: 'The village has already filed its miracle.' };
        switch (s.gesture) {
            case 'strike':
                if (s.rockDone)
                    return { ok: false, code: 'done', message: 'That rock has accepted its reassignment.' };
                if (!within(position, POINTS.strike, 0.92))
                    return { ok: false, code: 'off-target', message: 'Aim for the amber seal on empty ground beside the rock.' };
                if (residents.some(p => within(p, position, 1.0) || within(p, POINTS.rockEnd, 0.9))) {
                    return { ok: false, code: 'occupied', message: 'Ground occupied. Divine paperwork strictly forbids collateral shenanigans.' };
                }
                return { ok: true, code: 'strike-ready', message: 'STRIKE READY: unoccupied ground. Move the ridiculous rock.' };
            case 'sweep':
                if (s.confettiDone)
                    return { ok: false, code: 'done', message: 'Not a scrap of confetti remains.' };
                if (s.sweepAttached)
                    return { ok: true, code: 'sweep-attached', message: 'Guide the captured spiral across the turquoise village square.' };
                if (!within(position, s.wind, 1.1))
                    return { ok: false, code: 'off-target', message: 'Catch the teal wind spiral, then carry it to the square.' };
                return { ok: true, code: 'sweep-ready', message: 'SWEEP READY: catch the spiral.' };
            case 'ward':
                if (s.signDone)
                    return { ok: false, code: 'done', message: 'The sign has received divine structural support.' };
                if (!within(position, POINTS.sign, 1.13))
                    return { ok: false, code: 'off-target', message: 'Center the violet ward on the leaning welcome sign.' };
                return { ok: true, code: 'ward-ready', message: 'WARD READY: protect the sign before straightening it.' };
        }
    }
    act(position, residents = []) {
        const target = this.checkTarget(position, residents);
        if (!target.ok)
            return target;
        const s = this.state;
        if (s.gesture === 'strike') {
            s.rockDone = true;
            s.rockTime = 0;
            this.maybeWin();
            return { ok: true, code: 'rock-moved', message: 'BOULDER REASSIGNED. The road has been promoted to road.' };
        }
        if (s.gesture === 'ward') {
            s.signDone = true;
            s.wardTime = 0;
            this.maybeWin();
            return { ok: true, code: 'sign-warded', message: 'WELCOME SIGN STABILIZED. The masonry is deeply impressed.' };
        }
        if (s.sweepAttached) {
            s.sweepAttached = false;
            return { ok: true, code: 'sweep-released', message: 'Spiral released. Catch it again if confetti remains.' };
        }
        s.sweepAttached = true;
        return { ok: true, code: 'sweep-caught', message: 'SPIRAL CAPTURED. Guide it over the square to clear the confetti.' };
    }
    moveWind(position, dt) {
        const s = this.state;
        if (!s.sweepAttached || s.confettiDone || s.victory)
            return false;
        const mag = Math.hypot(position.x, position.z);
        const b = mag > 7.2 ? { x: position.x * 7.2 / mag, z: position.z * 7.2 / mag } : position;
        s.wind = { x: b.x, z: b.z };
        const radius = distance(b, POINTS.plaza);
        if (radius < 1.55) {
            const power = clamp((1.55 - radius) / 0.8, 0.18, 1);
            s.sweepProgress = clamp(s.sweepProgress + dt * 0.48 * power, 0, 1);
            if (s.sweepProgress >= 1) {
                s.confettiDone = true;
                s.sweepAttached = false;
                this.maybeWin();
                return true;
            }
        }
        return false;
    }
    tick(dt) {
        const s = this.state;
        dt = clamp(dt, 0, 0.05);
        s.seconds += dt;
        if (s.rockDone)
            s.rockTime = clamp(s.rockTime + dt, 0, 4);
        if (s.signDone)
            s.wardTime = clamp(s.wardTime + dt, 0, 4);
        if (s.victory) {
            s.victoryTime += dt;
            if (s.victoryTime > 8.4)
                s.signHasFallenAgain = true;
        }
    }
    maybeWin() {
        if (this.completed() === 3 && !this.state.victory) {
            this.state.victory = true;
            this.state.victoryTime = 0;
            this.state.sweepAttached = false;
        }
    }
}
export function easeInOut(t) {
    t = clamp(t, 0, 1);
    return t * t * (3 - 2 * t);
}
