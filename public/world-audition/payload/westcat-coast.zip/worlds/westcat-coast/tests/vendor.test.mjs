import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const official={
 'three.core.min.js':'fcf90d35125fb8032944f3211a57fb5f29433bae',
 'three.module.min.js':'5ae623ca0c049185052dafc5ef764d236ec93bfe'
};
const blobHash=bytes=>createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
test('vendored local Three.js files exactly match official r185 Git blob hashes',()=>{
 for(const [name,sha] of Object.entries(official))assert.equal(blobHash(readFileSync(resolve(root,'vendor',name))),sha,name);
});
test('local Three.js runtime exports the expected upstream revision',async()=>{
 const T=await import('../vendor/three.module.min.js');assert.equal(T.REVISION,'185');
});
test('runtime boot imports only local modules and no external asset URLs',()=>{
 for(const file of ['index.html','src/main.js','src/world.js','src/course.js','src/physics.js','src/input.js']){
  const s=readFileSync(resolve(root,file),'utf8');
  assert.doesNotMatch(s,/https?:\/\//,`remote URL in ${file}`);
 }
});
