import * as THREE from 'three';
import { COURSE_FLOORS, GATE_CENTERS, GESTURES } from './domain.js';
import { ArtDirectedSkyline } from './art-direction.js';
import { CityEffects } from './effects.js';
import { StreetFinishes } from './street-finishes.js';
import { districtAtX } from './presentation.js';
const TAU = Math.PI * 2;
const navy = 0x050b1a;
const sharedBox = new THREE.BoxGeometry(1, 1, 1);
const sharedBall = new THREE.SphereGeometry(1, 14, 10);
function prng(seed = 0x71ac1e) {
    let s = seed >>> 0;
    return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return (s >>> 0) / 4294967296; };
}
function mat(color, emissive = 0x000000, intensity = 0) {
    return new THREE.MeshStandardMaterial({ color, metalness: 0.58, roughness: 0.24, emissive, emissiveIntensity: intensity });
}
function glass(color, opacity = 0.9) {
    return new THREE.MeshPhysicalMaterial({ color, transparent: opacity < 1, opacity, metalness: 0.55, roughness: 0.17, clearcoat: 0.98, clearcoatRoughness: 0.08, depthWrite: opacity >= 1 });
}
function glow(color) {
    return new THREE.MeshBasicMaterial({ color, toneMapped: false });
}
function makeBox(parent, w, h, d, material, x = 0, y = 0, z = 0) {
    const mesh = new THREE.Mesh(sharedBox, material);
    mesh.position.set(x, y, z);
    mesh.scale.set(w, h, d);
    parent.add(mesh);
    return mesh;
}
function makeBall(parent, r, material, x, y, z) {
    const mesh = new THREE.Mesh(sharedBall, material);
    mesh.position.set(x, y, z);
    mesh.scale.setScalar(r);
    parent.add(mesh);
    return mesh;
}
function makeRing(parent, r, tube, color, x, y, z) {
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 8, 96), glow(color));
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
}
function makeInstancedSurface(parent, material, instances) {
    if (!instances.length)
        return;
    const mesh = new THREE.InstancedMesh(sharedBox, material, instances.length);
    const object = new THREE.Object3D();
    instances.forEach((v, i) => {
        object.position.set(v.x, v.y, v.z);
        object.scale.set(v.w, v.h, v.d);
        object.updateMatrix();
        mesh.setMatrixAt(i, object.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.frustumCulled = false;
    parent.add(mesh);
}
function createSign(parent, top, bottom, color) {
    const canvas = document.createElement('canvas');
    canvas.width = 768;
    canvas.height = 256;
    const c = canvas.getContext('2d');
    if (!c)
        throw new Error('Canvas unavailable');
    c.clearRect(0, 0, 768, 256);
    c.fillStyle = 'rgba(4,13,28,.89)';
    c.fillRect(0, 0, 768, 256);
    c.strokeStyle = color;
    c.lineWidth = 6;
    c.strokeRect(8, 8, 752, 240);
    c.fillStyle = '#a7becf';
    c.font = '600 27px monospace';
    c.fillText('SOURCE GESTURE', 36, 62);
    c.fillStyle = '#ffffff';
    c.font = 'bold 54px sans-serif';
    c.fillText(top.toUpperCase(), 34, 132);
    c.fillStyle = color;
    c.font = 'bold 33px monospace';
    c.fillText('→ ' + bottom.toUpperCase(), 35, 200);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(9.8, 3.26), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.DoubleSide }));
    parent.add(sign);
    return sign;
}
export class CityWorld {
    scene;
    gates = [];
    rings = [];
    floorLights = [];
    trains = [];
    kinetics = [];
    cues = [];
    ringColors = GESTURES.map(g => new THREE.Color(g.color));
    fx;
    skyline;
    street;
    padRings = [];
    skyTexture = null;
    moodFog = [0x09172a, 0x171329, 0x201727, 0x0a2226].map(c => new THREE.Color(c));
    moodSky = [0x050b1a, 0x090b23, 0x15101b, 0x061721].map(c => new THREE.Color(c));
    detail = 'high';
    constructor(scene) {
        this.scene = scene;
        this.scene.background = new THREE.Color(navy);
        this.scene.fog = new THREE.FogExp2(navy, 0.0066);
        this.createLights();
        this.createPhone();
        this.createBackdrop();
        this.skyline = new ArtDirectedSkyline(this.scene);
        this.createCourse();
        this.street = new StreetFinishes(this.scene);
        this.createGates();
        this.createFinish();
        this.createTransit();
        this.fx = new CityEffects(this.scene);
    }
    createLights() {
        this.scene.add(new THREE.HemisphereLight(0x9dd4ef, 0x170f28, 1.82));
        const sun = new THREE.DirectionalLight(0xf8dfca, 2.72);
        sun.position.set(-38, 92, 44);
        this.scene.add(sun);
        const fill = new THREE.DirectionalLight(0x63dfff, 1.28);
        fill.position.set(160, 55, -70);
        this.scene.add(fill);
        const colorLights = [0x4ddad6, 0xca72fa, 0xf0ae6b, 0x7feead];
        for (let i = 0; i < 4; i++) {
            const light = new THREE.PointLight(colorLights[i], 23, 38, 2);
            light.position.set(GATE_CENTERS[i], 8, 8);
            this.scene.add(light);
            this.floorLights.push(light);
        }
    }
    createPhone() {
        const frame = new THREE.Group();
        frame.position.set(80, 25, -80);
        this.scene.add(frame);
        const dark = glass(0x101926);
        const shadow = mat(0x080d18);
        const brushed = mat(0x647c93);
        const w = 262, h = 158, d = 19;
        makeBox(frame, w, 5, d, shadow, 0, h / 2, 0);
        makeBox(frame, w, 5, d, shadow, 0, -h / 2, 0);
        makeBox(frame, 5, h, d, shadow, -w / 2, 0, 0);
        makeBox(frame, 5, h, d, shadow, w / 2, 0, 0);
        makeBox(frame, w - 5, 0.4, d, brushed, 0, h / 2 - 3.2, 0);
        makeBox(frame, w - 5, 0.4, d, brushed, 0, -h / 2 + 3.2, 0);
        makeBox(frame, .4, h - 5, d, brushed, -w / 2 + 3.2, 0, 0);
        makeBox(frame, .4, h - 5, d, brushed, w / 2 - 3.2, 0, 0);
        makeBox(frame, w - 12, .32, .35, glow(0x263c57), 0, -h / 2 + 5.2, 9.9);
        const screen = makeBox(frame, w - 12, h - 12, .35, dark, 0, 0, -8.5);
        screen.material = new THREE.MeshBasicMaterial({ color: 0x020812 });
        makeBox(frame, 14, .6, .35, glow(0xb9d5dc), 0, h / 2 - 2.6, 10.1);
        makeBall(frame, 0.55, glow(0x6bf3e7), 17, h / 2 - 2.6, 10.1);
        makeBox(frame, 13, 1.8, 2, brushed, w / 2 + 1, 18, 0);
        makeBox(frame, 8, 1.4, 2, brushed, w / 2 + 1, 8, 0);
        for (let k = 0; k < 3; k++) {
            const lens = makeRing(frame, 3.1 + k * .2, .18, 0x6c93c6, -w / 2 + 10 + k * 9, h / 2 - 10, -10);
            lens.rotation.y = Math.PI / 8;
        }
        makeBox(frame, 28, 2, 1.2, glow(0x90b4cb), 0, -h / 2 + 9, 11.2);
    }
    createBackdrop() {
        const canvas = document.createElement('canvas');
        canvas.width = 1024;
        canvas.height = 512;
        const c = canvas.getContext('2d');
        if (!c)
            return;
        const g = c.createLinearGradient(0, 0, 0, 512);
        g.addColorStop(0, '#080e2d');
        g.addColorStop(.35, '#102653');
        g.addColorStop(.68, '#14132f');
        g.addColorStop(1, '#060f21');
        c.fillStyle = g;
        c.fillRect(0, 0, 1024, 512);
        const rand = prng(0x13579);
        for (let i = 0; i < 850; i++) {
            const x = rand() * 1024, y = rand() * 512;
            c.globalAlpha = .1 + rand() * .7;
            c.fillStyle = rand() > .92 ? '#ffdeba' : '#d9f1ff';
            c.beginPath();
            c.arc(x, y, .35 + rand() * 1.8, 0, TAU);
            c.fill();
        }
        c.globalAlpha = 1;
        const radial = c.createRadialGradient(720, 310, 2, 720, 310, 300);
        radial.addColorStop(0, 'rgba(201,91,247,.2)');
        radial.addColorStop(1, 'rgba(201,91,247,0)');
        c.fillStyle = radial;
        c.fillRect(0, 0, 1024, 512);
        this.skyTexture = new THREE.CanvasTexture(canvas);
        this.skyTexture.colorSpace = THREE.SRGBColorSpace;
        const pane = new THREE.Mesh(new THREE.PlaneGeometry(254, 146), new THREE.MeshBasicMaterial({ map: this.skyTexture, depthWrite: false }));
        pane.position.set(80, 25, -88);
        this.scene.add(pane);
        const points = [];
        for (let i = 0; i < 650; i++) {
            points.push(-25 + rand() * 217, 5 + rand() * 95, -54 - rand() * 16);
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(points, 3));
        const stars = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xa6cfff, size: .24, sizeAttenuation: true, transparent: true, opacity: .7 }));
        this.scene.add(stars);
    }
    createCourse() {
        const black = mat(0x101d2c);
        const rail = glass(0x31475e, .84);
        const pearl = glow(0xe0eefd);
        const rand = prng(0x911ad);
        const dashes = [];
        const ribs = [];
        for (let i = 0; i < COURSE_FLOORS.length; i++) {
            const [lo, hi] = COURSE_FLOORS[i];
            const center = (lo + hi) / 2, len = hi - lo;
            const color = GESTURES[Math.min(3, Math.floor(Math.max(0, center - 10) / 40))].color;
            makeBox(this.scene, len, 1.0, 8.5, black, center, -.5, 0);
            makeBox(this.scene, len, .08, 7.95, glass(0x263b50), center, -.025, 0);
            // Two unbroken signal conduits make the safe traversal line readable at speed.
            const conduit = glow(color);
            for (const z of [-3.56, 3.56]) {
                makeBox(this.scene, len, .045, .07, conduit, center, .08, z);
                makeBox(this.scene, len, .22, .08, mat(0x0d2337), center, -.34, z);
            }
            // Abstract directional road glyphs: never collision geometry.
            for (let x = lo + 4.8; x < hi - 3; x += 8.5) {
                const a = makeBox(this.scene, 1.35, .028, .095, conduit, x, .115, -.48);
                a.rotation.y = -.48;
                const b = makeBox(this.scene, 1.35, .028, .095, conduit, x, .115, .48);
                b.rotation.y = .48;
            }
            for (const z of [-4.33, 4.33]) {
                makeBox(this.scene, len, .15, .15, glow(color), center, .14, z);
                makeBox(this.scene, len, .34, .24, rail, center, -.1, z);
            }
            for (let x = lo + 1; x < hi; x += 2.1) {
                dashes.push({ x, y: .12, z: 0, w: 1, h: .025, d: .06 });
                ribs.push({ x, y: -1.22, z: 0, w: .11, h: 1.1, d: 2.9 });
                if (rand() > .73) {
                    const foot = makeBox(this.scene, 1.1, .2, 1.7, glow(color), x, -1.02, -3.9);
                    foot.material.transparent = true;
                    foot.material.opacity = .65;
                }
            }
            const under = makeBox(this.scene, len, .5, 5.5, glass(0x1b3350, .55), center, -1.45, 0);
            under.rotation.z = (i % 2 ? 1 : -1) * .002;
            for (let x = lo + 3; x < hi - 2; x += 9) {
                makeBox(this.scene, .42, 6, .42, glass(color, .42), x, -4.7, -2.5);
                makeBall(this.scene, .4, glow(color), x, -7.2, -2.5);
            }
        }
        makeInstancedSurface(this.scene, pearl, dashes);
        makeInstancedSurface(this.scene, mat(0x1f3f56), ribs);
        // The four safety pads have persistent ground and signal exactly where a 90 degree action can occur.
        for (let i = 0; i < 4; i++) {
            const cx = GATE_CENTERS[i] - 10, color = GESTURES[i].color;
            const pad = new THREE.Mesh(new THREE.CylinderGeometry(2.65, 2.65, .12, 48), new THREE.MeshStandardMaterial({ color: 0x162c3c, metalness: .83, roughness: .19, emissive: color, emissiveIntensity: .37 }));
            pad.position.set(cx, .1, 0);
            this.scene.add(pad);
            const ring = makeRing(this.scene, 2.5, .055, color, cx, .17, 0);
            ring.rotation.x = Math.PI / 2;
            ring.material.transparent = true;
            ring.material.opacity = .96;
            this.rings.push(ring);
            this.padRings.push(ring);
            for (let k = 0; k < 4; k++) {
                const a = k * Math.PI / 2;
                makeBall(this.scene, .16, glow(color), cx + Math.cos(a) * 2.85, .23, Math.sin(a) * 2.85);
            }
        }
        for (let x = -9; x < 175; x += 12) {
            if (GATE_CENTERS.some(c => Math.abs(c - x) < 8))
                continue;
            makeBox(this.scene, .26, 7, .26, mat(0x384a6e), x, -3, -5.2);
            makeBall(this.scene, .4, glow(0x79e2f0), x, .55, -5.2);
        }
        for (let i = 0; i < 8; i++) {
            const x = 11 + i * 22;
            const mesh = new THREE.Mesh(new THREE.TorusKnotGeometry(1.8, .25, 48, 8, 2, 5), glass(GESTURES[i % 4].color, .6));
            mesh.position.set(x, 6, -12);
            this.scene.add(mesh);
            this.kinetics.push({ mesh, speed: (i % 2 ? -.17 : .11) });
        }
    }
    createGates() {
        for (let i = 0; i < 4; i++) {
            const g = GESTURES[i], center = GATE_CENTERS[i], color = g.color;
            const arm = new THREE.Group();
            arm.position.set(center, -.45, 0);
            this.scene.add(arm);
            this.gates.push(arm);
            const slab = makeBox(arm, .92, 12.12, 8.2, glass(0x213d55, .96));
            const core = makeBox(arm, .38, 12, 7.9, mat(0x213947, color, .36), 0, 0, 0);
            core.material.side = THREE.DoubleSide;
            for (let t = -5.45; t <= 5.45; t += .72) {
                makeBox(arm, .99, .055, 8.28, glow(color), 0, t, 0);
                makeBox(arm, 1.15, .24, .12, glow(0xe2f7ff), 0, t, 4.11);
            }
            for (const z of [-4.19, 4.19]) {
                makeBox(arm, 1.16, 12, .12, glow(color), 0, 0, z);
                for (let a = -5; a <= 5; a += 1.25)
                    makeBall(arm, .12, glow(0xffffff), 0, a, z);
            }
            // Independent sculptural pivot rings never become collision geometry.
            const ring = makeRing(this.scene, 6.75, .22, color, center, 1.25, -6.6);
            ring.material.transparent = true;
            ring.material.opacity = .44;
            this.rings.push(ring);
            const ring2 = makeRing(this.scene, 8.3, .055, 0xb5d1ff, center, 1.25, -8.2);
            ring2.material.transparent = true;
            ring2.material.opacity = .33;
            for (let j = 0; j < 4; j++) {
                const a = j * Math.PI / 2;
                const pillar = makeBox(this.scene, 1.3, 8.5, 1.3, glass(color, .68), center + Math.cos(a) * 8.4, 2.1, -8.5 + Math.sin(a) * .7);
                pillar.rotation.z = (j % 2 ? .2 : -.2);
            }
            const sign = createSign(this.scene, g.gesture, g.command, g.hex);
            sign.position.set(center, 16.4, -15.5);
            const cue = new THREE.Group();
            cue.position.set(center - 10, 3.9, -3.4);
            this.scene.add(cue);
            this.cues.push(cue);
            const badge = makeRing(cue, 1.1, .095, color, 0, 0, 0);
            badge.material.transparent = true;
            badge.material.opacity = .9;
            const compass = new THREE.Mesh(new THREE.ConeGeometry(.35, 1.2, 3), glow(color));
            compass.position.y = 1.8;
            cue.add(compass);
            makeBox(cue, .13, 2.0, .12, glow(color), 0, -1.95, 0);
            for (let j = 0; j < 5; j++)
                makeBall(cue, .13, glow(color), Math.cos(j * TAU / 5) * 1.55, Math.sin(j * TAU / 5) * 1.55, .05);
            const flare = new THREE.PointLight(color, 10, 19, 2);
            flare.position.set(center, 2, -3);
            this.scene.add(flare);
            // Gold-toned safety rails and inset signals are visual only: they rotate with the real wall.
            for (let y = -4.8; y <= 4.8; y += 2.4) {
                const signal = makeBox(arm, .12, .52, 1.2, glow(color), -.51, y, -2.75);
                signal.rotation.x = .08;
            }
            for (const z of [-3.5, 3.5])
                makeBox(arm, .18, 11.5, .15, glow(0xe6f1fa), -.61, 0, z);
            // Bridge geometry is visible as an upright wall. Its separate CPU collider only activates after the exact quarter-turn.
            slab.userData.kind = 'illustrative-bridge';
        }
    }
    createFinish() {
        const root = new THREE.Group();
        root.position.set(170, 0, -2);
        this.scene.add(root);
        for (let k = 0; k < 4; k++) {
            const ring = makeRing(root, 4 + k * 1.2, .2, 0xa9ffdc, 0, 5, -k * 1.2);
            ring.material.transparent = true;
            ring.material.opacity = 1 - k * .18;
        }
        for (let k = -1; k <= 1; k++) {
            makeBox(root, .72, 17, .72, glass(0x3ae7c9, .65), k * 5, 8, -7);
            makeBall(root, .8, glow(0xe7fff3), k * 5, 17, -7);
        }
        makeBox(root, 12, .28, 2, glow(0x63ffe5), 0, .03, -2);
        makeBox(root, 16, .55, 2, glass(0x326d73), 0, 16, -8);
        const finish = createSign(root, 'THE CITY TURNS', 'FOUR / FOUR', '#9fffba');
        finish.position.set(0, 20, -9);
        const sun = new THREE.Mesh(new THREE.SphereGeometry(14, 40, 24), new THREE.MeshBasicMaterial({ color: 0xffd7b4, transparent: true, opacity: .3, depthWrite: false }));
        sun.position.set(184, 48, -70);
        this.scene.add(sun);
        for (let j = 0; j < 4; j++) {
            const halo = makeRing(this.scene, 16 + j * 4, .14, j % 2 ? 0xb87aff : 0xffd9b8, 184, 48, -70 - j * .4);
            halo.material.transparent = true;
            halo.material.opacity = .3 - j * .06;
        }
    }
    createTransit() {
        const routes = [
            { points: [[-15, 25, -34], [20, 35, -27], [52, 31, -38], [84, 48, -42], [118, 40, -35], [150, 53, -39], [190, 49, -45]], color: 0x54e8de },
            { points: [[-20, 17, -54], [12, 22, -56], [38, 28, -64], [80, 27, -59], [122, 36, -61], [158, 32, -55], [194, 45, -62]], color: 0xa57bff },
            { points: [[-20, 57, -66], [20, 63, -60], [60, 54, -70], [112, 66, -58], [164, 61, -67], [194, 57, -63]], color: 0xffba6c }
        ];
        for (let k = 0; k < routes.length; k++) {
            const route = routes[k];
            const pts = route.points.map(p => new THREE.Vector3(p[0], p[1], p[2]));
            const curve = new THREE.CatmullRomCurve3(pts, false, 'centripetal');
            const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 180, .065, 5, false), new THREE.MeshBasicMaterial({ color: route.color, transparent: true, opacity: .65, depthWrite: false }));
            this.scene.add(tube);
            for (let s = 0; s < 3; s++) {
                const train = new THREE.Mesh(new THREE.OctahedronGeometry(.38, 0), glow(route.color));
                this.scene.add(train);
                this.trains.push({ mesh: train, curve, phase: s / 3, speed: .014 + .004 * k });
            }
        }
    }
    setGateAngle(i, angle) { this.gates[i].rotation.z = angle; this.street.setGateAngle(i, angle); }
    setGateUnlocked(i, unlocked) {
        this.cues[i].visible = !unlocked;
        this.gates[i].userData.unlocked = unlocked;
        this.padRings[i].material.opacity = unlocked ? .24 : .96;
    }
    resetPresentation() {
        this.skyline.reset();
        this.street.reset();
        this.fx.clear();
        this.kinetics.forEach(k => { k.mesh.rotation.y = 0; });
        this.padRings.forEach(r => { r.scale.setScalar(1); r.material.opacity = .96; });
        this.cues.forEach(c => { c.position.y = 3.9; });
    }
    setQuality(mode) {
        this.detail = mode;
        this.skyline.setQuality(mode);
        this.street.setQuality(mode);
        this.fx.setQuality(mode);
        this.floorLights.forEach(light => { light.intensity = mode === 'eco' ? 12 : 23; });
    }
    setReduced(reduced) { this.fx.setComfort(reduced); }
    update(seconds, dt, reduced, focusX) {
        const chapter = districtAtX(focusX);
        // Expensive environment lights are local to one district in economy mode.
        this.floorLights.forEach((lamp, i) => { lamp.visible = this.detail === 'high' || i === chapter; });
        const blend = reduced ? 1 : 1 - Math.exp(-Math.max(0, Math.min(.05, dt)) * 1.7);
        if (this.scene.fog)
            this.scene.fog.color.lerp(this.moodFog[chapter], blend);
        if (this.scene.background instanceof THREE.Color)
            this.scene.background.lerp(this.moodSky[chapter], blend);
        this.fx.update(dt, reduced);
        this.skyline.update(seconds, dt, reduced);
        this.street.update(seconds, reduced);
        if (reduced)
            return;
        for (let i = 0; i < this.padRings.length; i++) {
            const r = this.padRings[i];
            r.scale.setScalar(1 + Math.sin(seconds * 2.5 + i) * .026);
        }
        for (const kin of this.kinetics)
            kin.mesh.rotation.y += kin.speed * dt;
        for (const train of this.trains) {
            train.mesh.position.copy(train.curve.getPointAt((train.phase + seconds * train.speed) % 1));
            train.mesh.rotation.y += dt * .8;
        }
        for (let i = 0; i < 4; i++) {
            if (this.cues[i].visible)
                this.cues[i].position.y = 3.9 + Math.sin(seconds * 1.9 + i) * .25;
        }
    }
    dispose() {
        this.fx.dispose();
        const geos = new Set();
        const mats = new Set();
        this.scene.traverse((obj) => {
            if (obj instanceof THREE.Mesh || obj instanceof THREE.LineSegments || obj instanceof THREE.Points) {
                geos.add(obj.geometry);
                const m = obj.material;
                if (Array.isArray(m))
                    m.forEach(v => mats.add(v));
                else
                    mats.add(m);
            }
        });
        geos.forEach(g => g.dispose());
        mats.forEach(m => {
            const withMap = m;
            withMap.map?.dispose();
            m.dispose();
        });
        this.skyTexture?.dispose();
        this.scene.clear();
    }
}
export class Avatar {
    root = new THREE.Group();
    leftLeg = new THREE.Group();
    rightLeg = new THREE.Group();
    leftArm = new THREE.Group();
    rightArm = new THREE.Group();
    shadow;
    scarf;
    helmet;
    scarfLinks = [];
    jumpJets = [];
    stride = 0;
    heading = Math.PI / 5;
    landedEase = 0;
    lastGrounded = true;
    constructor(scene) {
        const suit = glass(0x89b7d4);
        const dark = mat(0x17253d);
        const cyan = glow(0x5cf6ea);
        const whites = glow(0xf7ffff);
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(.42, .65, 6, 12), suit);
        body.position.y = 1.26;
        this.root.add(body);
        const chest = makeBox(this.root, .6, .18, .14, cyan, 0, 1.44, .42);
        chest.rotation.z = .04;
        this.helmet = new THREE.Mesh(new THREE.SphereGeometry(.52, 26, 18), glass(0xe6e9ff));
        this.helmet.position.y = 2.22;
        this.root.add(this.helmet);
        const visor = new THREE.Mesh(new THREE.SphereGeometry(.41, 20, 12, 0, Math.PI), dark);
        visor.rotation.y = Math.PI / 2;
        visor.position.set(0, 2.24, .24);
        this.root.add(visor);
        makeBox(this.root, .7, .12, .07, cyan, 0, 2.26, .59);
        makeBall(this.root, .09, whites, -.3, 2.27, .62);
        makeBall(this.root, .09, whites, .3, 2.27, .62);
        // Identification silhouette: luminous breathing core, split shoulder yoke,
        // suit underframe and a compact jump-pack, all local primitive geometry.
        const frame = mat(0x263d56);
        const pearl = mat(0xc5e9ed, 0x356d7d, .22);
        makeBox(this.root, .74, .22, .4, frame, 0, .97, 0);
        makeBox(this.root, .66, .065, .5, cyan, 0, .90, .02);
        makeBox(this.root, .88, .11, .16, pearl, 0, 1.68, .18);
        makeBox(this.root, .28, .36, .09, cyan, 0, 1.31, .49);
        makeBall(this.root, .12, whites, 0, 1.40, .57);
        for (const side of [-1, 1]) {
            const shoulder = makeBall(this.root, .25, pearl, side * .51, 1.69, .03);
            shoulder.scale.set(.26, .17, .3);
            makeBox(this.root, .15, .43, .15, cyan, side * .46, 1.30, .12);
            makeBox(this.root, .28, .22, .16, frame, side * .31, .72, .23);
            makeBox(this.root, .22, .13, .2, cyan, side * .24, .55, .19);
        }
        makeBox(this.root, .73, .78, .29, frame, 0, 1.33, -.49);
        for (const side of [-1, 1]) {
            makeBox(this.root, .2, .62, .11, cyan, side * .28, 1.33, -.70);
            makeBall(this.root, .13, whites, side * .27, 1.01, -.62);
        }
        const neck = new THREE.Mesh(new THREE.TorusGeometry(.38, .065, 7, 32), glow(0x6efcf4));
        neck.position.set(0, 1.94, 0);
        neck.rotation.x = Math.PI / 2;
        this.root.add(neck);
        const earLeft = makeBox(this.root, .15, .36, .23, pearl, -.51, 2.27, 0);
        const earRight = makeBox(this.root, .15, .36, .23, pearl, .51, 2.27, 0);
        earLeft.rotation.z = -.15;
        earRight.rotation.z = .15;
        this.leftLeg.position.set(-.23, .85, 0);
        this.root.add(this.leftLeg);
        this.rightLeg.position.set(.23, .85, 0);
        this.root.add(this.rightLeg);
        for (const leg of [this.leftLeg, this.rightLeg]) {
            makeBox(leg, .24, .68, .31, suit, 0, -.35, 0);
            makeBox(leg, .32, .17, .55, dark, 0, -.72, .1);
            makeBox(leg, .31, .06, .6, cyan, 0, -.78, .12);
            makeBox(leg, .29, .28, .1, pearl, 0, -.38, .17);
            makeBox(leg, .13, .17, .62, cyan, 0, -.74, .1);
        }
        this.leftArm.position.set(-.52, 1.66, 0);
        this.root.add(this.leftArm);
        this.rightArm.position.set(.52, 1.66, 0);
        this.root.add(this.rightArm);
        for (const arm of [this.leftArm, this.rightArm]) {
            makeBox(arm, .23, .7, .25, dark, 0, -.35, 0);
            makeBall(arm, .14, cyan, 0, -.73, 0);
            makeBox(arm, .31, .17, .3, pearl, 0, -.69, .06);
        }
        this.scarf = new THREE.Group();
        this.scarf.position.set(0, 1.83, -.35);
        this.root.add(this.scarf);
        for (let j = 0; j < 5; j++) {
            const link = makeBox(this.scarf, .33, .2, .8 - j * .1, glow(j % 2 ? 0xffb577 : 0xffd6c4), 0, j * .05, -.65 - j * .62);
            link.rotation.x = -.06 * j;
            this.scarfLinks.push(link);
        }
        // Two small jet wisps are cosmetic jump-state signals, not propulsion.
        for (const side of [-1, 1]) {
            const plumeMat = new THREE.MeshBasicMaterial({ color: 0x86fff0, transparent: true, opacity: .6, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
            const plume = new THREE.Mesh(new THREE.ConeGeometry(.15, .73, 9), plumeMat);
            plume.rotation.z = Math.PI;
            plume.position.set(side * .26, .64, -.76);
            plume.visible = false;
            this.root.add(plume);
            this.jumpJets.push(plume);
        }
        const shadowCanvas = document.createElement('canvas');
        shadowCanvas.width = 128;
        shadowCanvas.height = 128;
        const brush = shadowCanvas.getContext('2d');
        if (brush) {
            const g = brush.createRadialGradient(64, 64, 5, 64, 64, 63);
            g.addColorStop(0, 'rgba(1,10,22,.76)');
            g.addColorStop(.45, 'rgba(1,10,22,.35)');
            g.addColorStop(1, 'rgba(1,10,22,0)');
            brush.fillStyle = g;
            brush.fillRect(0, 0, 128, 128);
        }
        const shadowTex = new THREE.CanvasTexture(shadowCanvas);
        shadowTex.colorSpace = THREE.SRGBColorSpace;
        this.shadow = new THREE.Mesh(new THREE.PlaneGeometry(2.7, 2.1), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false, opacity: .79 }));
        this.shadow.rotation.x = -Math.PI / 2;
        this.shadow.position.y = .095;
        scene.add(this.shadow);
        scene.add(this.root);
    }
    resetPresentation() {
        this.stride = 0;
        this.heading = Math.PI / 5;
        this.landedEase = 0;
        this.lastGrounded = true;
        this.root.scale.setScalar(1);
        this.root.rotation.set(0, 0, 0);
        this.helmet.rotation.set(0, 0, 0);
        this.scarf.rotation.set(0, 0, 0);
        this.leftLeg.rotation.set(0, 0, 0);
        this.rightLeg.rotation.set(0, 0, 0);
        this.leftArm.rotation.set(0, 0, 0);
        this.rightArm.rotation.set(0, 0, 0);
        this.jumpJets.forEach(jet => { jet.visible = false; jet.scale.setScalar(1); });
        this.scarfLinks.forEach((link, i) => { link.rotation.set(-.06 * i, 0, 0); });
    }
    update(x, y, z, vx, grounded, time, reduced, dt) {
        const step = Math.max(0, Math.min(.05, dt));
        if (grounded && !this.lastGrounded)
            this.landedEase = .23;
        this.lastGrounded = grounded;
        this.landedEase = Math.max(0, this.landedEase - step);
        const speed = Math.min(1, Math.abs(vx) / 8.9);
        if (grounded && speed > .025)
            this.stride += step * (4.5 + 8 * speed);
        const targetHeading = vx < -.2 ? -Math.PI / 5 : vx > .2 ? Math.PI / 5 : this.heading;
        this.heading += (targetHeading - this.heading) * (reduced ? 1 : 1 - Math.exp(-step * 11));
        const idleFloat = grounded && !reduced ? Math.sin(time * 2.2) * .018 : 0;
        this.root.position.set(x, y + idleFloat, z);
        this.root.rotation.y = this.heading;
        const cycle = this.stride;
        const swing = reduced ? 0 : Math.sin(cycle) * .49 * speed;
        const recovery = grounded ? 1 : .38;
        this.leftLeg.rotation.z = swing * recovery;
        this.rightLeg.rotation.z = -swing * recovery;
        this.leftArm.rotation.z = -swing * .85 * recovery;
        this.rightArm.rotation.z = swing * .85 * recovery;
        this.leftArm.rotation.x = grounded ? 0 : -.32;
        this.rightArm.rotation.x = grounded ? 0 : -.32;
        this.root.rotation.z = reduced ? 0 : (grounded ? -Math.sign(vx) * .034 * speed : -.09);
        this.helmet.rotation.z = reduced ? 0 : Math.sin(time * 1.65) * .018;
        this.scarf.rotation.y = reduced ? 0 : Math.sin(time * 3.4) * .07;
        for (let i = 0; i < this.scarfLinks.length; i++) {
            const item = this.scarfLinks[i];
            item.rotation.x = -.045 * i + (reduced ? 0 : Math.sin(time * 5.0 - i * .58) * (.018 + i * .01));
            item.rotation.y = reduced ? 0 : Math.sin(time * 4.8 - i * .47) * (.025 + i * .015);
        }
        const landing = reduced ? 0 : Math.sin(Math.PI * (this.landedEase / .23)) * .22;
        this.root.scale.set(1 + landing * .17, 1 - landing * .33, 1 + landing * .1);
        this.jumpJets.forEach((jet, i) => {
            jet.visible = !grounded && !reduced;
            jet.scale.y = .68 + Math.sin(time * 16 + i) * .21;
        });
        this.shadow.visible = y >= -.02 && y < 5;
        this.shadow.position.set(x, .09, z);
        this.shadow.scale.setScalar(Math.max(.52, 1 - y * .09));
        const material = this.shadow.material;
        material.opacity = Math.max(.18, .79 - y * .12);
    }
}
