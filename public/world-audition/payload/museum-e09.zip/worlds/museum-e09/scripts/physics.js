import { RECOVERY_Y, floorBelow } from './level.js';
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function damp(current, target, lambda, dt) { return target + (current - target) * Math.exp(-lambda * dt); }
/**
 * Deterministic fixed-step kinematic traversal against a data-only platform
 * layout. The visuals never own collision, timing or checkpoint decisions.
 */
export function advancePlayer(previous, input, dt) {
    if (!Number.isFinite(dt) || dt <= 0 || dt > 0.05)
        throw new Error('Fixed step must be between 0 and 0.05s');
    const p = { ...previous };
    const speed = input.run ? 7.1 : 5.0;
    const magnitude = Math.hypot(input.x, input.z);
    const nx = magnitude > 1 ? input.x / magnitude : input.x;
    const nz = magnitude > 1 ? input.z / magnitude : input.z;
    p.vx = damp(p.vx, nx * speed, 10, dt);
    p.vz = damp(p.vz, nz * speed, 10, dt);
    const jumped = !!(p.grounded && input.jump);
    if (jumped) {
        p.vy = 8.3;
        p.grounded = false;
    }
    let nextX = p.x + p.vx * dt, nextZ = p.z + p.vz * dt;
    const ahead = floorBelow(nextX, nextZ, p.y, 0.5);
    if (ahead && ahead.top > p.y + 0.5) {
        nextX = p.x;
        nextZ = p.z;
    }
    p.x = clamp(nextX, -30, 30);
    p.z = clamp(nextZ, -196, 19);
    const ground = floorBelow(p.x, p.z, p.y, 0.5);
    let landed = false;
    if (p.grounded && ground && ground.top >= p.y - 0.45 && ground.top <= p.y + 0.5) {
        p.y = ground.top;
        p.vy = 0;
    }
    else {
        const oldY = p.y;
        p.vy = Math.max(-24, p.vy - 18.4 * dt);
        p.y += p.vy * dt;
        p.grounded = false;
        if (ground && p.vy <= 0 && oldY >= ground.top - 0.08 && p.y <= ground.top) {
            p.y = ground.top;
            p.vy = 0;
            p.grounded = true;
            landed = true;
        }
    }
    return { state: p, fell: p.y <= RECOVERY_Y, jumped, landed };
}
