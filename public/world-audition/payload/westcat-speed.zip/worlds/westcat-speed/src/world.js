import * as THREE from 'three';
import { COURSE_LENGTH, TRACK_STRETCH, CHECKPOINTS, LOOPS, RAILS, SPRINGS, BOOST_PADS, HURDLES, GAPS, heightAt as groundForSim, isGap as isGapSim, railY, regionFor } from './track.js';
import { BOOST_TOP_SPEED } from './physics.js';
const C = {
    cream: 0xfff2cf, navy: 0x112b49, gold: 0xffcf62, coral: 0xff795c,
    teal: 0x39e8cc, turquoise: 0x78fff0, pink: 0xff83c3,
    green: 0x1f8769, ocean: 0x168b8a, purple: 0x5f5a9e
};
const ZONES = [
    { skyTop: 0x206293, skyBottom: 0xffd0a7, ground: 0x715077, side: 0x302943, edge: 0xffd182, light: 0xffe1af },
    { skyTop: 0x206f8c, skyBottom: 0x91e8b2, ground: 0x3c876b, side: 0x193d4f, edge: 0x9effc2, light: 0xb6ffdc },
    { skyTop: 0x424b89, skyBottom: 0xb3f0e0, ground: 0x536fa1, side: 0x282e5b, edge: 0xfacb84, light: 0xbeeefc },
    { skyTop: 0x4f3478, skyBottom: 0xff9b81, ground: 0x69518c, side: 0x2b2f61, edge: 0xffcc8f, light: 0xffbdab }
];
function randomFactory(seed) { let t = seed >>> 0; return () => { t += 0x6D2B79F5; let x = t; x = Math.imul(x ^ (x >>> 15), x | 1); x ^= x + Math.imul(x ^ (x >>> 7), x | 61); return ((x ^ (x >>> 14)) >>> 0) / 4294967296; }; }
const rnd = randomFactory(26306);
function mat(color, roughness = .72, metalness = .04) {
    return new THREE.MeshStandardMaterial({ color, roughness, metalness, flatShading: true });
}
function basic(color, opacity = 1) {
    return new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity, depthWrite: opacity === 1, side: THREE.DoubleSide });
}
export function createWorld(opts) {
    const { canvas } = opts;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: opts.quality === 'high', alpha: false, powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.5;
    renderer.setClearColor(0x183c62, 1);
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x78a6b6, .004);
    const camera = new THREE.PerspectiveCamera(46, 1, .1, 1200);
    const sun = new THREE.DirectionalLight(0xffe9bb, 2.1);
    sun.position.set(-15, 62, 62);
    scene.add(sun);
    const fill = new THREE.HemisphereLight(0xc5efff, 0x2e5271, 2.05);
    scene.add(fill);
    const ambient = new THREE.AmbientLight(0xffffff, .35);
    scene.add(ambient);
    const root = new THREE.Group();
    scene.add(root);
    // Everything in root is authored in chapter coordinates, then placed at stretched X.
    const heightAt = (rawX) => groundForSim(rawX * TRACK_STRETCH);
    const isGap = (rawX) => isGapSim(rawX * TRACK_STRETCH);
    const toRaw = (physicsX) => physicsX / TRACK_STRETCH;
    const moving = new THREE.Group();
    scene.add(moving);
    const palettes = ZONES.map(z => ({ ground: mat(z.ground), side: mat(z.side), edge: mat(z.edge, .34, .17) }));
    const shared = {
        white: mat(C.cream), gold: mat(C.gold, .45, .24), teal: mat(C.teal, .35, .17),
        coral: mat(C.coral), dark: mat(C.navy), mint: mat(0x9af7cd),
        bark: mat(0x826050), barkDark: mat(0x374753), leaf: mat(0x258d70),
        leaf2: mat(0x3ebc86), leaf3: mat(0x66e3ae), concrete: mat(0xb0aeb7),
        lamp: new THREE.MeshBasicMaterial({ color: C.gold })
    };
    function add(geo, material, x, y, z, parent = root) {
        const object = new THREE.Mesh(geo, material);
        object.position.set(parent === root ? x * TRACK_STRETCH : x, y, z);
        parent.add(object);
        return object;
    }
    function cube(x, y, z, w, h, d, material, parent) {
        return add(new THREE.BoxGeometry(w, h, d), material, x, y, z, parent);
    }
    function sphere(x, y, z, r, material, parent, detail = 1) {
        return add(new THREE.IcosahedronGeometry(r, detail), material, x, y, z, parent);
    }
    function cylinder(x, y, z, top, bottom, height, material, parent, segments = 8) {
        return add(new THREE.CylinderGeometry(top, bottom, height, segments), material, x, y, z, parent);
    }
    function line(points, radius, material, parent = root) {
        const adjusted = parent === root ? points.map(p => new THREE.Vector3(p.x * TRACK_STRETCH, p.y, p.z)) : points;
        const curve = new THREE.CatmullRomCurve3(adjusted);
        return add(new THREE.TubeGeometry(curve, Math.max(12, points.length * 5), radius, 6, false), material, 0, 0, 0, parent);
    }
    function ring(x, y, z, r, material, thick = .25, parent = root) {
        return add(new THREE.TorusGeometry(r, thick, 8, 48), material, x, y, z, parent);
    }
    function caption(text, fg = '#fdf1d2', bg = 'rgba(11,29,50,.92)', w = 768, h = 192) {
        const cn = document.createElement('canvas');
        cn.width = w;
        cn.height = h;
        const ctx = cn.getContext('2d');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = 'rgba(255,206,118,.8)';
        ctx.lineWidth = 8;
        ctx.strokeRect(12, 12, w - 24, h - 24);
        ctx.fillStyle = fg;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const size = text.length > 22 ? 48 : text.length > 14 ? 61 : 76;
        ctx.font = `900 ${size}px system-ui, sans-serif`;
        ctx.fillText(text, w / 2, h / 2, w - 52);
        const texture = new THREE.CanvasTexture(cn);
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.anisotropy = 2;
        return texture;
    }
    function sign(text, x, y, z, w, theme = 'dark') {
        const texture = caption(text, theme === 'light' ? '#17354f' : '#ffebc9', theme === 'light' ? 'rgba(238,243,204,.96)' : 'rgba(18,41,68,.92)');
        const m = new THREE.MeshBasicMaterial({ map: texture, transparent: true, side: THREE.DoubleSide, depthWrite: false });
        const sheet = add(new THREE.PlaneGeometry(w, w * .25), m, x, y, z);
        return sheet;
    }
    function land(start, end, idx) {
        const step = 2.5, top = [], sides = [], bevel = [];
        for (let x = start; x < end;) {
            if (isGap(x + .25)) {
                x += step;
                continue;
            }
            let nx = Math.min(x + step, end);
            for (const gap of GAPS) {
                const a = toRaw(gap.start), b = toRaw(gap.end);
                if (x < a && nx > a)
                    nx = a;
                if (x >= a && x < b) {
                    x = b;
                    nx = x;
                    break;
                }
            }
            if (nx <= x + .0001) {
                x = Math.max(x + step, nx);
                continue;
            }
            const y = heightAt(x), y2 = heightAt(nx);
            // Color-capped road deck and an uninterrupted deep cliff side.
            top.push(x, y, -8.1, x, y, 8.1, nx, y2, -8.1, nx, y2, -8.1, x, y, 8.1, nx, y2, 8.1);
            sides.push(x, y, 8.1, x, y - 22, 8.1, nx, y2, 8.1, nx, y2, 8.1, x, y - 22, 8.1, nx, y2 - 22, 8.1);
            sides.push(x, y, -8.1, x, y - 22, -8.1, nx, y2, -8.1, nx, y2, -8.1, x, y - 22, -8.1, nx, y2 - 22, -8.1);
            bevel.push(x, y + .18, 8.2, x, y - .38, 8.2, nx, y2 + .18, 8.2, nx, y2 + .18, 8.2, x, y - .38, 8.2, nx, y2 - .38, 8.2);
            x = nx;
        }
        function surface(verts, material) {
            const g = new THREE.BufferGeometry();
            const scaled = verts.slice();
            for (let k = 0; k < scaled.length; k += 3)
                scaled[k] *= TRACK_STRETCH;
            g.setAttribute('position', new THREE.Float32BufferAttribute(scaled, 3));
            g.computeVertexNormals();
            const mm = new THREE.Mesh(g, material);
            root.add(mm);
        }
        surface(top, palettes[idx].ground);
        surface(sides, palettes[idx].side);
        surface(bevel, palettes[idx].edge);
        // Marked running stripes and small high-visibility delineators.
        const laneMaterial = basic(idx === 1 ? 0xb2ffb5 : 0xffe5ae, .68);
        for (let x = start + 14; x < end; x += 28) {
            if (isGap(x))
                continue;
            const m = cube(x, heightAt(x) + .12, 8.25, 12, .12, .1, laneMaterial);
            m.rotation.z = Math.atan2(heightAt(x + 2) - heightAt(x - 2), 4);
        }
    }
    land(0, 580, 0);
    land(580, 1230, 1);
    land(1230, 1850, 2);
    land(1850, COURSE_LENGTH / TRACK_STRETCH, 3);
    // Distant layered mountain silhouettes with no fetched location artwork.
    const mountains = [
        { z: -95, base: -35, color: 0x386787, height: 30, step: 37, seed: 12 },
        { z: -140, base: -17, color: 0x65829c, height: 48, step: 47, seed: 3 },
        { z: -190, base: -3, color: 0x719fb0, height: 65, step: 60, seed: 31 }
    ];
    for (const layer of mountains) {
        const vals = [];
        for (let x = -350; x < COURSE_LENGTH / TRACK_STRETCH + 400; x += layer.step) {
            const a = layer.base + layer.height * (.5 + .5 * Math.sin(x * .011 + layer.seed)) + .22 * layer.height * Math.sin(x * .027);
            const b = layer.base + layer.height * (.5 + .5 * Math.sin((x + layer.step) * .011 + layer.seed)) + .22 * layer.height * Math.sin((x + layer.step) * .027);
            vals.push(x, -90, layer.z, x + layer.step, -90, layer.z, x, a, layer.z, x + layer.step, -90, layer.z, x + layer.step, b, layer.z, x, a, layer.z);
        }
        const g = new THREE.BufferGeometry();
        for (let k = 0; k < vals.length; k += 3)
            vals[k] *= TRACK_STRETCH;
        g.setAttribute('position', new THREE.Float32BufferAttribute(vals, 3));
        root.add(new THREE.Mesh(g, basic(layer.color, .58)));
    }
    // Big stylized distant clouds & sunset color orbs. No copyrighted sprites or textures.
    const cloudMat = basic(0xf4f8ee, .37), cloudMat2 = basic(0xf6cdd1, .23);
    for (let i = 0; i < 65; i++) {
        const x = rnd() * (COURSE_LENGTH / TRACK_STRETCH), y = 80 + rnd() * 86, z = -100 - rnd() * 75;
        const cloud = sphere(x, y, z, 8 + rnd() * 14, i % 3 ? cloudMat : cloudMat2);
        cloud.scale.set(2.5 + rnd() * 2, .48, .3);
    }
    const sunDisk = add(new THREE.CircleGeometry(90, 64), basic(0xffd9a7, .25), 2465, 115, -165);
    sunDisk.scale.set(1.15, 1, 1);
    ring(2465, 115, -164, 82, basic(0xffdea3, .25), 1.8);
    // Architected Duncan rooftops: generic facades, no copied storefront names.
    const paint = [mat(0xefad89), mat(0xd88679), mat(0x96c7c5), mat(0xf9d4a4), mat(0xada3c4), mat(0x77aebc)];
    const windows = basic(0xffecc6, .8), windowShade = basic(0x3b6084, .9);
    for (let i = 0; i < 26; i++) {
        const x = 18 + i * 22 + (rnd() - .5) * 3, w = 27 + rnd() * 9, h = 26 + rnd() * 23;
        const y = heightAt(x) - 3 + h / 2, z = -25 - (i % 3) * 11;
        cube(x, y, z, w, h, 11, paint[i % paint.length]);
        cube(x, y + h / 2 + 2, z, w + 2, 3, 13, shared.dark);
        cube(x, y - h / 2 + 4, z + 6, w - 1, 6, 1, mat(0x314968));
        for (let row = 0; row < 3; row++)
            for (let col = 0; col < 3; col++) {
                const wx = x + (col - 1) * (w * .14), wy = y - h * .28 + row * h * .26;
                cube(wx, wy, z + 5.7, w * .18, h * .13, .14, (row + col + i) % 4 === 0 ? windows : windowShade);
            }
        if (i % 4 === 0) {
            ring(x, y + h * .23, z + 6, 3.2, shared.gold, .45);
            cube(x, y + h * .23, z + 6, 3, .45, .8, shared.dark);
        }
    }
    // Broadcast clock tower and editorial overhead pennants.
    cylinder(78, 36, -14, 9, 10, 68, mat(0x6479a2), undefined, 12);
    ring(78, 64, -7, 7, shared.gold, 1.2);
    sphere(78, 64, -7, 5.5, shared.white, undefined, 2);
    cube(78, 65, -.5, 1, 5, .25, shared.dark);
    cube(80, 63.5, -.4, 4, .8, .25, shared.dark);
    sign('DUNCAN / LIVE', 160, 55, -8, 29);
    sign('BROADCAST IN 04:30', 505, 48, -17, 36);
    for (let x = 35; x < 580; x += 37) {
        const wireY = 65 + (x % 74 ? 2 : 0);
        line([new THREE.Vector3(x - 17, wireY, -7), new THREE.Vector3(x, wireY - 2, -7), new THREE.Vector3(x + 17, wireY, -7)], .08, shared.white);
        const flag = add(new THREE.ConeGeometry(1.9, 4.7, 3), paint[Math.floor(x / 37) % paint.length], x, wireY - 4, -7);
        flag.rotation.x = Math.PI / 2;
        flag.rotation.z = Math.PI;
    }
    // Chunked, instanced forests; silhouette quality without hundreds of draw calls.
    function plantForest(start, end, amount, tint, depth) {
        const trunkMaterial = mat(depth < -32 ? 0x506c6a : 0x6a5c61), foliage = mat(tint);
        const trunkGeometry = new THREE.CylinderGeometry(.55, .95, 1, 7);
        const crownGeometry = new THREE.ConeGeometry(1, 1, 7);
        const trunks = new THREE.InstancedMesh(trunkGeometry, trunkMaterial, amount);
        const crowns = new THREE.InstancedMesh(crownGeometry, foliage, amount * 3);
        const object = new THREE.Object3D();
        for (let i = 0; i < amount; i++) {
            const x = start + rnd() * (end - start), scale = 9 + rnd() * 21;
            const ground = heightAt(x) - 3, z = depth + (rnd() - .5) * 12;
            object.position.set(x * TRACK_STRETCH, ground + scale * .5, z);
            object.scale.set(1, scale, 1);
            object.rotation.set(0, 0, 0);
            object.updateMatrix();
            trunks.setMatrixAt(i, object.matrix);
            for (let j = 0; j < 3; j++) {
                object.position.set(x * TRACK_STRETCH, ground + scale * (.55 + .19 * j), z);
                object.scale.set(scale * (.24 - j * .025), scale * (.56 - j * .1), scale * (.24 - j * .025));
                object.updateMatrix();
                crowns.setMatrixAt(i * 3 + j, object.matrix);
            }
        }
        trunks.instanceMatrix.needsUpdate = true;
        crowns.instanceMatrix.needsUpdate = true;
        root.add(trunks, crowns);
    }
    plantForest(530, 1280, 90, 0x1c675d, -65);
    plantForest(540, 1310, 115, 0x2f9b75, -29);
    plantForest(1190, 1860, 80, 0x244f69, -60);
    plantForest(1180, 1860, 92, 0x398d82, -24);
    plantForest(1840, 2690, 72, 0x4b577b, -72);
    plantForest(1840, 2690, 75, 0x73577b, -32);
    for (let i = 0; i < 180; i++) {
        const x = 580 + rnd() * 1200;
        if (isGap(x))
            continue;
        const z = -12 + rnd() * 25, y = heightAt(x) + .3;
        const leaf = sphere(x, y, z, .4 + rnd() * .55, i % 2 ? shared.leaf2 : shared.leaf3);
        leaf.scale.set(.42, 1.8, .3);
        leaf.rotation.z = rnd() * Math.PI;
    }
    sign('FOREST OUTSKIRTS', 623, 43, -13, 34);
    sign('CEDAR CLIMB', 1278, 64, -12, 35);
    // Layered timber trestle: generic X-braced engineering, NOT ceremonial art.
    for (let x = 1290; x < 1790; x += 33) {
        const y = heightAt(x) - 1;
        cube(x, y - 20, -19, 3, 40, 3, shared.bark);
        cube(x, y - 20, -11, 3, 40, 3, shared.barkDark);
        cube(x, y - 3, -15, 31, 2.5, 3, shared.bark);
        const diagonal = cube(x, y - 20, -17, 2, 43, 2, shared.bark);
        diagonal.rotation.z = .62;
        const reverse = cube(x, y - 20, -18, 2, 43, 2, shared.bark);
        reverse.rotation.z = -.62;
        sphere(x, y + 3, -12, 1.5, shared.lamp);
    }
    // Monumental cedar-column silhouettes; repeated bands imply construction, not local cultural carving.
    for (let x = 1300; x < 1850; x += 108) {
        const y = heightAt(x), h = 67 + rnd() * 45;
        cylinder(x, y + h / 2 - 10, -54, 4, 7, h, shared.bark);
        for (let j = 0; j < 5; j++)
            ring(x, y + j * 13 + 7, -47, 4.7, basic(0x98d9c0, .4), .45);
        sphere(x, y + h - 10, -54, 20, shared.leaf, undefined, 0).scale.set(1.3, 1.55, 1.2);
    }
    // Two physical circular loops. Path geometry is the exact analytic path used by physics.ts.
    for (let i = 0; i < LOOPS.length; i++) {
        const loop = LOOPS[i], radius = loop.radius, cx = toRaw(loop.x), base = heightAt(cx);
        const palette = i === 0 ? shared.coral : shared.teal;
        const points = [];
        for (let j = 0; j <= 128; j++) {
            const a = -Math.PI / 2 + j / 128 * Math.PI * 2;
            points.push(new THREE.Vector3(cx + (radius / TRACK_STRETCH) * Math.cos(a), base + radius + radius * Math.sin(a), -.1));
        }
        line(points, 1.2, palette);
        const glow = basic(i === 0 ? 0xfff1a8 : 0xb6fff0, .75);
        line(points.map(p => p.clone().add(new THREE.Vector3(0, 0, 1.05))), .23, glow);
        for (let j = 0; j < 20; j++) {
            const a = -Math.PI / 2 + j / 20 * Math.PI * 2;
            const px = cx + ((radius + 2.3) / TRACK_STRETCH) * Math.cos(a), py = base + radius + (radius + 2.3) * Math.sin(a);
            sphere(px, py, 1, 1.0, j % 2 ? shared.gold : shared.white);
        }
        sign(i === 0 ? 'CLOCK LOOP I' : 'CLOCK LOOP II', cx + 8, base + radius * 2 + 15, -17, 36);
    }
    // Functional magnetic rails: start and finish heights match the physics railY function.
    for (let i = 0; i < RAILS.length; i++) {
        const rail = RAILS[i], pts = [];
        for (let j = 0; j <= 30; j++) {
            const x = toRaw(rail.start + (rail.end - rail.start) * j / 30);
            pts.push(new THREE.Vector3(x, railY(i, x * TRACK_STRETCH), 2.5));
        }
        line(pts, .85, i === 0 ? shared.gold : shared.teal);
        line(pts.map(p => p.clone().add(new THREE.Vector3(0, 0, -1.7))), .23, shared.dark);
        for (let x = toRaw(rail.start); x <= toRaw(rail.end); x += 9) {
            const ry = railY(i, x * TRACK_STRETCH);
            sphere(x, ry + .7, 3.4, .65, i === 0 ? shared.gold : shared.mint);
            cube(x, (ry + heightAt(x)) / 2, -3, 1, Math.max(1, ry - heightAt(x)), 1.5, shared.barkDark);
        }
        sign('MAGNETIC EXPRESS', toRaw(rail.start) + 63, railY(i, rail.start) + 19, -16, 39);
    }
    // Embedded spring plates, boosts, clearance hoops, and visible gap warnings.
    for (const spring of SPRINGS) {
        const x = toRaw(spring.x), y = heightAt(x);
        cube(x, y + .55, 4, 4.5, 1.1, 8, shared.coral);
        cube(x, y + 1.4, 4, 3.5, .6, 8, shared.gold);
        for (let j = 0; j < 3; j++) {
            const coil = ring(x, y + 2.5 + j * .66, 4, 1.3, shared.gold, .32);
            coil.rotation.x = Math.PI / 2;
        }
        sphere(x, y + 3.9, 4, 1.1, shared.mint);
    }
    for (const padX of BOOST_PADS) {
        const x = toRaw(padX), y = heightAt(x);
        cube(x, y + .3, 5, 7, .65, 6, shared.teal);
        for (let j = -1; j <= 1; j++) {
            const tri = add(new THREE.ConeGeometry(1.5, 2.9, 3), shared.white, x + j * 2, y + 1.1, 8.3);
            tri.rotation.z = -Math.PI / 2;
        }
    }
    for (const hurdleX of HURDLES) {
        const x = toRaw(hurdleX), y = heightAt(x);
        cube(x, y + 2.1, 5, 2.8, 4, 3, shared.dark);
        ring(x, y + 4.5, 7.4, 1.5, shared.gold, .45);
        sphere(x, y + 4.5, 8.5, .55, shared.coral);
    }
    for (const gap of GAPS) {
        for (const edge of [toRaw(gap.start), toRaw(gap.end)]) {
            const y = heightAt(edge);
            cube(edge, y + .4, 7.7, 3, .7, 2, shared.gold);
            for (let j = 0; j < 3; j++) {
                const bar = cube(edge, y - 4 - j * 2.1, 8.1, 1.7, 1.05, 1, shared.coral);
                bar.rotation.z = .1;
            }
        }
    }
    // Lit checkpoints, grounded on accessible surface (not placed in gaps).
    for (let i = 0; i < CHECKPOINTS.length; i++) {
        const cp = CHECKPOINTS[i], x = toRaw(cp.x), y = heightAt(x);
        ring(x, y + 10, 0, 7.5, i % 2 ? shared.gold : shared.teal, .66);
        cube(x - 7, y + 5, -1, 1.1, 10, 1.1, shared.dark);
        cube(x + 7, y + 5, -1, 1.1, 10, 1.1, shared.dark);
        sphere(x, y + 18, -1, 2.2, shared.gold);
        sign('CHECKPOINT ' + String(i + 1).padStart(2, '0'), x, y + 29, -14, 39);
    }
    sign('THE GREAT HORNED SENTINEL', 1910, 88, -24, 59);
    sign('LIVE NOW / ALMOST', 2360, 70, -16, 42);
    // A symbolic owl-shaped *shadow*, not a copied boss model or combat target.
    const owl = new THREE.Group();
    moving.add(owl);
    const shadow = basic(0x201a48, .7);
    function wing(reverse) {
        const shape = new THREE.Shape();
        const signDir = reverse ? -1 : 1;
        shape.moveTo(0, 0);
        shape.lineTo(signDir * 13, 9);
        shape.lineTo(signDir * 37, 11);
        shape.lineTo(signDir * 33, 1);
        shape.lineTo(signDir * 47, -7);
        shape.lineTo(signDir * 28, -7);
        shape.lineTo(signDir * 21, -16);
        shape.lineTo(signDir * 13, -8);
        shape.closePath();
        add(new THREE.ShapeGeometry(shape), shadow, 0, 0, 0, owl);
    }
    wing(false);
    wing(true);
    sphere(0, -1, 1, 12, shadow, owl, 1).scale.set(1.1, .78, .15);
    const hornA = add(new THREE.ConeGeometry(5, 15, 3), shadow, -8, 9, 0, owl);
    hornA.rotation.z = .25;
    const hornB = add(new THREE.ConeGeometry(5, 15, 3), shadow, 8, 9, 0, owl);
    hornB.rotation.z = -.25;
    for (const side of [-1, 1]) {
        sphere(side * 5.3, 1, 2, 2.5, shared.gold, owl);
        sphere(side * 5.3, 1, 2.8, 1.2, shared.dark, owl);
    }
    owl.scale.set(.85, .85, .85);
    // Ending arch and two appointment clocks for the joke payoff.
    const endX = COURSE_LENGTH / TRACK_STRETCH - 8, endY = heightAt(endX);
    ring(endX, endY + 17, 0, 13, shared.gold, 1.6);
    for (const side of [-1, 1]) {
        cylinder(endX + side * 13, endY + 8, -1, 1.5, 2.4, 16, shared.teal);
    }
    sign('ON AIR', endX, endY + 37, -6, 40, 'light');
    for (const [i, words] of ['LATE FOR THIS SHOW', 'EARLY FOR NEXT SHOW'].entries()) {
        const x = COURSE_LENGTH / TRACK_STRETCH - 78 + i * 46;
        ring(x, heightAt(x) + 37, -18, 8, shared.gold, 1.3);
        sphere(x, heightAt(x) + 37, -17, 6, shared.white, undefined, 2);
        cube(x, heightAt(x) + 39, -11, 1, 5, .5, shared.dark);
        const hand = cube(x + 1.8, heightAt(x) + 36, -11, 3.5, .8, .5, shared.coral);
        hand.rotation.z = i === 0 ? -.35 : .45;
        sign(words, x, heightAt(x) + 54, -15, 37);
    }
    // An original courier marker, purposefully noncanonical and unlike any WestCat or Sonic design.
    const player = new THREE.Group();
    moving.add(player);
    const body = new THREE.Group();
    player.add(body);
    const bodyMain = sphere(0, 0, 0, 1.65, shared.coral, body, 1);
    bodyMain.scale.set(1, .96, .86);
    // Cream faceplate, postage stamp geometry, mint accents and hinged bronze feet.
    cube(0, .1, 1.22, 2.3, 1.58, .37, shared.white, body);
    cube(0, .3, 1.45, 1.37, .33, .12, shared.dark, body);
    for (const side of [-1, 1]) {
        sphere(side * .48, .32, 1.55, .13, shared.teal, body);
        const foot = cube(side * .8, -1.34, .6, .9, .4, .65, shared.gold, body);
        foot.rotation.z = side * .1;
        const pin = sphere(side * 1.55, .12, .25, .35, shared.teal, body);
        pin.scale.set(.65, 1.15, .7);
    }
    cube(0, -.45, 1.48, .88, .12, .11, shared.coral, body);
    const topper = sphere(0, 1.64, 0, .52, shared.teal, body);
    topper.scale.set(1.5, .35, .8);
    const groundShadow = add(new THREE.CircleGeometry(2.4, 32), basic(0x1b2849, .24), 0, 0, 0, moving);
    groundShadow.rotation.x = -Math.PI / 2;
    const trails = [];
    for (let i = 0; i < 19; i++) {
        const m = sphere(0, 0, 0, 1.2, new THREE.MeshBasicMaterial({ color: i % 3 ? C.gold : C.teal, transparent: true, opacity: 0, depthWrite: false }), moving);
        trails.push(m);
    }
    const airDust = [];
    for (let i = 0; i < 22; i++) {
        const m = sphere(0, 0, 0, .45, new THREE.MeshBasicMaterial({ color: i % 2 ? 0xffdf91 : 0xc1fff1, transparent: true, opacity: .35, depthWrite: false }), moving);
        airDust.push(m);
    }
    const colorSky = new THREE.Color(0x7ac2e0);
    let cameraInit = false, currentRegion = 0, visualTime = 0, destroyed = false;
    function setQuality(low) {
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, low ? 1 : 1.65));
        renderer.setSize(canvas.clientWidth || window.innerWidth, canvas.clientHeight || window.innerHeight, false);
        airDust.forEach((o, i) => { o.visible = !low || i < 9; });
    }
    function resize() {
        if (destroyed)
            return;
        const w = Math.max(1, canvas.clientWidth), h = Math.max(1, canvas.clientHeight);
        camera.aspect = w / h;
        camera.fov = w < 580 ? 53 : 46;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h, false);
    }
    setQuality(opts.quality === 'low');
    resize();
    function update(s, dt, reduced, seconds) {
        if (destroyed)
            return;
        visualTime += dt;
        // Position follows *sim state* only. Loop orientation follows actual analytic tangent.
        player.position.set(s.x, s.y, 5);
        const orientation = s.mode === 'loop' ? s.loopAngle + Math.PI / 2 : s.mode === 'rail' ? .08 : Math.atan((groundForSim(s.x + .5) - groundForSim(s.x - .5))) * .65;
        player.rotation.z = orientation;
        body.scale.set(1 + Math.min(.18, Math.abs(s.vx) * .006), 1 - Math.min(.18, Math.abs(s.vx) * .004), 1);
        const bounce = reduced ? 0 : Math.sin(seconds * 11 + Math.abs(s.vx) * .05) * .15 * Math.min(1, Math.abs(s.vx) / 8);
        body.position.y = bounce;
        topper.rotation.y = reduced ? 0 : visualTime * 1.8;
        groundShadow.position.set(s.x, groundForSim(s.x) + .14, 5);
        const shadowDistance = Math.max(.5, s.y - groundForSim(s.x));
        groundShadow.scale.setScalar(Math.max(.5, 1 - shadowDistance * .025));
        groundShadow.material.opacity = .21 * Math.max(.25, 1 - shadowDistance * .02);
        trails.forEach((m, i) => {
            const speed = Math.abs(s.vx), active = !reduced && speed > 7;
            const age = i / trails.length;
            const angle = i * .58 + visualTime * 1.3;
            m.position.set(s.x - Math.max(0, s.vx) * (i + 1) * .035, s.y + Math.sin(angle) * .45, 4.3 - i * .028);
            const scale = (.2 + age * .7) * (speed / BOOST_TOP_SPEED);
            m.scale.setScalar(Math.max(.05, scale));
            m.material.opacity = active ? (1 - age) * .47 : 0;
        });
        airDust.forEach((m, i) => {
            const a = i * 2.399 + visualTime * (reduced ? .1 : .3), r = 5 + i % 7 * 1.4;
            m.position.set(s.x + (i - 11) * 3 + r * Math.sin(a) * .5, s.y + 8 + (i % 8) * 2 + r * Math.cos(a) * .5, -8 - (i % 5) * 2);
            m.material.opacity = reduced ? .12 : .20 + .2 * Math.sin(a) * Math.sin(a);
        });
        const showOwl = s.x >= 1820 * TRACK_STRETCH;
        owl.visible = showOwl;
        if (showOwl) {
            const proximity = (s.x - 1820 * TRACK_STRETCH) / (COURSE_LENGTH - 1820 * TRACK_STRETCH);
            owl.position.set(s.x - 48 + Math.sin(seconds * .4) * 5, s.y + 44 + Math.sin(seconds * .65) * 6, -15);
            const scale = 1.05 + Math.sin(seconds * .3) * .035 + proximity * .14;
            owl.scale.setScalar(scale);
            owl.rotation.y = reduced ? 0 : Math.sin(seconds * .9) * .07;
        }
        const zoneTarget = regionFor(s.x) === 'downtown' ? 0 : regionFor(s.x) === 'forest' ? 1 : regionFor(s.x) === 'cedar' ? 2 : 3;
        currentRegion += (zoneTarget - currentRegion) * Math.min(1, dt * 1.35);
        const index = Math.floor(currentRegion), next = Math.min(3, index + 1), mix = currentRegion - index;
        const skyA = new THREE.Color(ZONES[index].skyTop), skyB = new THREE.Color(ZONES[next].skyTop);
        colorSky.copy(skyA).lerp(skyB, mix);
        scene.background = colorSky;
        scene.fog.color.copy(colorSky).lerp(new THREE.Color(0x9cded6), .2);
        const litA = new THREE.Color(ZONES[index].light), litB = new THREE.Color(ZONES[next].light);
        sun.color.copy(litA.lerp(litB, mix));
        const speed = Math.abs(s.vx);
        const lookahead = reduced ? 10 : Math.max(10, Math.min(27, s.vx * 1.05));
        const loopExtra = s.mode === 'loop' ? 22 : 0;
        const zoom = reduced ? 0 : Math.min(18, speed * .55) + loopExtra;
        const desiredX = s.x + lookahead, desiredY = s.y + 8 + (s.mode === 'loop' ? 10 : 0);
        const desiredZ = 82 + zoom;
        const follow = 1 - Math.exp(-dt * (reduced ? 7 : 4.2));
        if (!cameraInit) {
            camera.position.set(desiredX + 12, desiredY + 10, desiredZ);
            cameraInit = true;
        }
        camera.position.lerp(new THREE.Vector3(desiredX + 12, desiredY + 10, desiredZ), follow);
        camera.lookAt(camera.position.x - 12, camera.position.y - 10, 0);
        // A slight authored camera pitch conveys speed while keeping controls side-on.
        if (!reduced)
            camera.rotation.z += Math.max(-.015, Math.min(.015, (s.vx / BOOST_TOP_SPEED) * -.008));
    }
    function render() { if (!destroyed)
        renderer.render(scene, camera); }
    function dispose() {
        if (destroyed)
            return;
        destroyed = true;
        const geometries = new Set(), materials = new Set(), textures = new Set();
        scene.traverse((o) => {
            const m = o;
            if (m.geometry)
                geometries.add(m.geometry);
            if (m.material) {
                for (const mat of Array.isArray(m.material) ? m.material : [m.material]) {
                    materials.add(mat);
                    const map = mat.map;
                    if (map)
                        textures.add(map);
                }
            }
        });
        for (const g of geometries)
            g.dispose();
        for (const t of textures)
            t.dispose();
        for (const m of materials)
            m.dispose();
        renderer.dispose();
        scene.clear();
        root.clear();
        moving.clear();
    }
    return { scene, camera, renderer, player, update, render, resize, setQuality, dispose };
}
