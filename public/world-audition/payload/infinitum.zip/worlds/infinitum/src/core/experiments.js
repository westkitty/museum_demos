import { lightAligned, ruinsComplete, tideAt } from './state.js';
import { causalStage, gravityAligned, heartIrrigation, gardenAccess, soilMoisture } from './simulation.js';
/** Optional, non-linear discovery experiments: every result derives from world state. */
export const EXPERIMENTS = [
    { id: 'water', title: 'Follow a drop of rain', question: 'Can you change the Heart Tree by changing water?', hint: 'Draw a river toward the Heart Tree and look for its irrigation response.', test: s => s.rivers.length > 0 && heartIrrigation(s) > .48 },
    { id: 'life', title: 'A second beginning', question: 'Can a planted seed mature beneath a new sky?', hint: 'Plant beside the Heart Tree and advance the shared clock.', test: s => s.seeds.some(p => Math.hypot(p.x - 17, p.z + 2) < 27 && p.age > .4) },
    { id: 'tide', title: 'The lunar shoreline', question: 'Does moving the moon change the land you can walk?', hint: 'Drag the moon to shift the tidal line visibly.', test: s => Math.abs(tideAt(s.moonAngle)) > 1.5 },
    { id: 'light', title: 'The ancient receiver', question: 'Can stone focus two beams into one?', hint: 'Align both prism and mirror with their ruined receivers.', test: lightAligned },
    { id: 'ruins', title: 'Reconstruct a memory', question: 'What happens when the three ruins remember their places?', hint: 'Return each fragment to its luminous socket.', test: ruinsComplete },
    { id: 'habitat', title: 'The weather writes on the earth', question: 'Can a storm reach the village soil?', hint: 'Bring rain, then accelerate the clock until moisture travels inland.', test: s => soilMoisture(s, -43, 44) > .35 && s.soilWater > .38 },
    { id: 'stars', title: 'Walk the constellation', question: 'Can a drawing become a bridge?', hint: 'Finish the Crown constellation in the inner garden.', test: s => gardenAccess(s, 0) },
    { id: 'gravity', title: 'As above, so below', question: 'Can an outer tilt move inner stone?', hint: 'Tilt the first raindrop east and back until the suspended pathway aligns.', test: gravityAligned },
    { id: 'circuit', title: 'The concordance', question: 'Can water, stars and gravity form one circuit?', hint: 'Follow the previous discoveries, then return to the Observatory.', test: s => causalStage(s) === 3 && s.endingSeen }
];
export function experimentById(id) { return EXPERIMENTS.find(e => e.id === id); }
export function completedExperiments(s) { return EXPERIMENTS.filter(e => e.test(s)); }
