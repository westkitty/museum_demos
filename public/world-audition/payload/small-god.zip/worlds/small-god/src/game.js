import { GodGameRules, POINTS } from './rules.js';
import { IslandWorld } from './world.js';
import { victoryStage } from './presentation.js';

const getSnapshot = (rules) => ({ ...rules.state, wind: { ...rules.state.wind } });
const gestureNames = ['strike', 'sweep', 'ward'];
const clamp = (n, a, b) => Math.min(Math.max(n, a), b);
export function mountGodGame(root, options = {}) {
    if (root.dataset.mounted === 'true')
        throw new Error('E31 game is already mounted in this root');
    root.dataset.mounted = 'true';
    root.innerHTML = `
  <div class="exhibit-shell">
    <canvas id="island-canvas" aria-label="Three-dimensional fantasy island, controlled with the gesture buttons and mouse, touch, or keyboard" tabindex="0"></canvas>
    <div class="atmosphere-overlay" aria-hidden="true"></div>
    <header class="masthead">
      <div class="brand-lockup"><div class="brand-emblem" aria-hidden="true">✧</div><div>
        <span class="eyebrow">MUSEUM OF ME &nbsp; / &nbsp; E31</span>
        <div class="brand-name">STORY WORLDS <span class="slash">/</span> PARABLE</div>
      </div></div>
      <div class="masthead-actions"><span class="noncanon">FICTIONAL SIDE EXPERIENCE</span>
        <button type="button" id="return-button" class="nav-return">↗ &nbsp; Return to Museum</button>
      </div>
    </header>
    <main class="game-hud" id="game-hud">
      <section class="title-cluster" aria-label="Chapter title"><div class="roman">I. THE PETITION OF THE VILLAGE</div>
        <h1>THE GOD OF<br><em>VERY SMALL</em><br>PROBLEMS</h1>
        <p class="title-deck">All-powerful. Wildly overqualified.<br>Entrusted with three rather modest inconveniences.</p>
      </section>
      <div class="task-panel" aria-label="Divine gestures">
        <div class="panel-heading"><span>DIVINE INSTRUMENTS</span><span id="count">0 / 3 MIRACLES</span></div>
        <div class="gesture-stack" role="group" aria-label="Choose a gesture">
          <button type="button" class="gesture selected" data-gesture="strike" aria-pressed="true">
            <span class="gesture-key">01</span><span class="gesture-icon strike-icon" aria-hidden="true">✦</span>
            <span class="gesture-copy"><strong>STRIKE</strong><small>Reassign one problematic rock</small></span><span class="task-check" aria-hidden="true">✓</span>
          </button>
          <button type="button" class="gesture" data-gesture="sweep" aria-pressed="false">
            <span class="gesture-key">02</span><span class="gesture-icon sweep-icon" aria-hidden="true">≋</span>
            <span class="gesture-copy"><strong>SWEEP</strong><small>Escort the breeze into the square</small></span><span class="task-check" aria-hidden="true">✓</span>
          </button>
          <button type="button" class="gesture" data-gesture="ward" aria-pressed="false">
            <span class="gesture-key">03</span><span class="gesture-icon ward-icon" aria-hidden="true">◎</span>
            <span class="gesture-copy"><strong>WARD</strong><small>Protect our emotionally fragile sign</small></span><span class="task-check" aria-hidden="true">✓</span>
          </button>
        </div>
        <div class="sweep-meter" id="sweep-meter" hidden><div class="sweep-label"><span>CONFETTI RELOCATION</span><span id="sweep-value">0%</span></div><div class="meter-track"><div id="meter-fill"></div></div></div>
        <div class="mission-line"><span class="mission-indicator" aria-hidden="true"></span><span id="target-readout">Point at the amber seal beside the rock.</span></div>
      </div>
      <div class="bottom-rail">
        <div class="control-legend"><span class="legend-head">COMMAND YOUR DIVINITY</span>
          <span><kbd>MOVE</kbd> pointer / touch / W A S D</span><span><kbd>ACT</kbd> click / Enter / Space</span>
          <span><kbd>SWITCH</kbd> 1 / 2 / 3</span></div>
        <div class="bottom-actions"><button id="motion-toggle" type="button" aria-pressed="false" class="text-button">◌ &nbsp; Reduced motion: Off</button>
          <button id="restart-button" type="button" class="text-button">↺ &nbsp; Restart island</button></div>
      </div>
      <div class="touch-pad" aria-label="Touch and switch-control movement">
        <button type="button" data-move="up" aria-label="Move hand north">↑</button>
        <div class="touch-row"><button type="button" data-move="left" aria-label="Move hand west">←</button>
        <button type="button" id="action-button" class="touch-act">ACT</button>
        <button type="button" data-move="right" aria-label="Move hand east">→</button></div>
        <button type="button" data-move="down" aria-label="Move hand south">↓</button>
      </div>
    </main>
    <div class="bottom-toast" id="toast" role="status" aria-live="polite">The island is accepting petitions.</div>
    <section class="portal-overlay" id="portal-overlay" aria-labelledby="portal-title">
      <div class="portal-border"></div><div class="portal-content">
        <div class="portal-topline">STORY WORLDS &nbsp; • &nbsp; EXHIBIT E31 &nbsp; • &nbsp; A DIVINE MISUNDERSTANDING</div>
        <div class="portal-drawing" aria-hidden="true"><span class="portal-sun">✳</span><span class="portal-hand">☟</span></div>
        <div class="portal-kicker">AN EXTREMELY IMPORTANT ENGAGEMENT</div>
        <h2 id="portal-title">THE GOD OF<br><i>VERY SMALL</i><br>PROBLEMS</h2>
        <p>You have been given limitless power and three complaints from a village roughly the size of a biscuit.</p>
        <button type="button" id="enter-button" class="enter-portal">ENTER E31 &nbsp; <span aria-hidden="true">↗</span></button>
        <div class="portal-fineprint">AN ORIGINAL, NONCANONICAL PARABLE MINIATURE &nbsp; / &nbsp; NO REAL-WORLD AUTHORITY CONFERRED</div>
      </div>
    </section>
    <div class="victory-banner" id="victory-banner" hidden aria-live="polite" role="region" aria-label="Village celebration">
      <div class="victory-spark" aria-hidden="true">✺</div>
      <span class="victory-overline">A DECREE FROM THE HIGH MOUNTAIN</span>
      <strong>THE VILLAGE IS SAVED!</strong>
      <p>Its three emergencies have been addressed.<br>Of these, one was a slightly crooked sign.</p>
      <div class="victory-buttons"><button type="button" id="replay-button">↺ &nbsp; PLAY AGAIN</button><button type="button" id="victory-return">↗ &nbsp; RETURN TO MUSEUM</button></div>
    </div>
    <div class="letterbox top" aria-hidden="true"></div><div class="letterbox bottom" aria-hidden="true"></div>
  </div>`;
    const $ = (selector) => {
        const el = root.querySelector(selector);
        if (!el)
            throw new Error(`Missing game element ${selector}`);
        return el;
    };
    const canvas = $('#island-canvas');
    const rules = new GodGameRules();
    let world;
    try {
        world = new IslandWorld(canvas);
    }
    catch (error) {
        root.innerHTML = '<div class="fatal"><h1>Island renderer unavailable</h1><p>Your browser needs working WebGL 2 to enter this exhibit. Use an updated browser with graphics enabled.</p></div>';
        root.dataset.mounted = 'false';
        throw error;
    }
    const overlay = $('#portal-overlay');
    const victory = $('#victory-banner');
    const hint = $('#target-readout');
    const toast = $('#toast');
    const count = $('#count');
    const meter = $('#sweep-meter');
    const meterFill = $('#meter-fill');
    const meterValue = $('#sweep-value');
    const motionButton = $('#motion-toggle');
    const gestureButtons = Array.from(root.querySelectorAll('[data-gesture]'));
    const abort = new AbortController();
    const listeners = { signal: abort.signal };
    let started = false, disposed = false, won = false;
    let displayStage = 'hidden';
    let reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let hand = { x: POINTS.strike.x, z: POINTS.strike.z };
    let time = 0, previous = 0, accumulator = 0, hintTick = 0, statusUntil = 0;
    const keys = new Set();
    const touchKeys = new Set();
    let lastStatus = 'The island is accepting petitions.';
    function announce(text, seconds = 4) {
        if (lastStatus !== text) {
            toast.textContent = text;
            lastStatus = text;
        }
        statusUntil = time + seconds;
    }
    function updateHUD() {
        count.textContent = `${rules.completed()} / 3 MIRACLES`;
        gestureButtons.forEach(button => {
            const gesture = button.dataset.gesture;
            const selected = rules.state.gesture === gesture;
            const done = gesture === 'strike' ? rules.state.rockDone : gesture === 'sweep' ? rules.state.confettiDone : rules.state.signDone;
            button.classList.toggle('selected', selected);
            button.classList.toggle('completed', done);
            button.setAttribute('aria-pressed', String(selected));
            button.setAttribute('aria-label', `${gesture.toUpperCase()}${done ? ' - completed' : ''}`);
        });
        meter.hidden = rules.state.gesture !== 'sweep' || rules.state.confettiDone;
        const percent = Math.round(rules.state.sweepProgress * 100);
        meterFill.style.width = `${percent}%`;
        meterValue.textContent = `${percent}%`;
    }
    function setGesture(g) {
        if (disposed || !started)
            return;
        rules.select(g);
        updateHUD();
        const label = g === 'strike' ? 'Amber seal on empty ground.' : g === 'sweep' ? 'Catch the wind; take it to the square.' : 'Violet circle around the sign.';
        announce(`${g.toUpperCase()} SELECTED. ${label}`, 2.7);
    }
    function act() {
        if (!started || disposed)
            return;
        const outcome = rules.act(hand, world.safeResidents);
        announce(outcome.message, outcome.ok ? 4.6 : 3);
        if (outcome.ok) {
            world.trigger(outcome.code);
            updateHUD();
            verifyVictory();
        }
    }
    function verifyVictory() {
        if (rules.state.victory && !won) {
            won = true;
            announce('THE VILLAGE IS SAVED. The administrative standard of excellence has been met.', 7);
            victory.hidden = false;
            root.querySelector('.exhibit-shell')?.classList.add('is-victorious');
            options.onComplete?.({ entry: 'E31', tasks: 3, canonical: false, durationSeconds: Math.round(rules.state.seconds) });
        }
    }
    function moveHand(dx, dz) {
        const x = hand.x + dx, z = hand.z + dz, r = Math.hypot(x, z);
        hand = r > 7.05 ? { x: x / r * 7.05, z: z / r * 7.05 } : { x, z };
    }
    function reset() {
        rules.restart();
        won = false;
        victory.hidden = true;
        displayStage = 'hidden';
        victory.classList.remove('epilogue', 'postscript');
        root.querySelector('.exhibit-shell')?.classList.remove('is-victorious');
        hand = { x: POINTS.strike.x, z: POINTS.strike.z };
        time = 0;
        accumulator = 0;
        hintTick = 0;
        statusUntil = 0;
        keys.clear();
        touchKeys.clear();
        world.trigger('reset');
        updateHUD();
        announce('Island restored. The village has found three new catastrophes.', 3.5);
        canvas.focus({ preventScroll: true });
    }
    function begin() {
        if (disposed)
            return;
        reset();
        overlay.hidden = true;
        started = true;
        canvas.focus({ preventScroll: true });
        announce('Move your hand to a glowing seal. The villagers have unreasonable confidence in you.', 6);
    }
    function back() {
        if (disposed)
            return;
        started = false;
        overlay.hidden = false;
        keys.clear();
        touchKeys.clear();
        $('#enter-button').focus();
        options.onReturn?.();
    }
    function setReduced(value) {
        reduced = value;
        motionButton.setAttribute('aria-pressed', String(value));
        motionButton.textContent = `◌  Reduced motion: ${value ? 'On' : 'Off'}`;
        root.querySelector('.exhibit-shell')?.classList.toggle('reduced', value);
    }
    setReduced(reduced);
    $('#enter-button').addEventListener('click', begin, listeners);
    $('#return-button').addEventListener('click', back, listeners);
    $('#victory-return').addEventListener('click', back, listeners);
    $('#restart-button').addEventListener('click', reset, listeners);
    $('#replay-button').addEventListener('click', reset, listeners);
    motionButton.addEventListener('click', () => setReduced(!reduced), listeners);
    gestureButtons.forEach((button) => button.addEventListener('click', () => setGesture(button.dataset.gesture), listeners));
    $('#action-button').addEventListener('click', act, listeners);
    const movementButtons = Array.from(root.querySelectorAll('[data-move]'));
    movementButtons.forEach(button => {
        const v = button.dataset.move;
        button.addEventListener('pointerdown', e => { e.preventDefault(); touchKeys.add(v); button.setPointerCapture(e.pointerId); }, listeners);
        const release = () => touchKeys.delete(v);
        button.addEventListener('pointerup', release, listeners);
        button.addEventListener('pointercancel', release, listeners);
        button.addEventListener('lostpointercapture', release, listeners);
    });
    const hasFocusInButton = (target) => {
        const el = target;
        return el?.tagName === 'BUTTON' || el?.tagName === 'INPUT';
    };
    window.addEventListener('keydown', e => {
        if (!started || disposed || e.altKey || e.ctrlKey || e.metaKey)
            return;
        const k = e.key.toLowerCase();
        if (['1', '2', '3'].includes(k)) {
            setGesture(gestureNames[Number(k) - 1]);
            e.preventDefault();
            return;
        }
        if ([' ', 'enter'].includes(k) && !hasFocusInButton(e.target)) {
            act();
            e.preventDefault();
            return;
        }
        if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'w', 'a', 's', 'd'].includes(k)) {
            keys.add(k);
            e.preventDefault();
        }
    }, listeners);
    window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()), listeners);
    window.addEventListener('blur', () => { keys.clear(); touchKeys.clear(); }, listeners);
    canvas.addEventListener('pointermove', e => {
        if (!started || disposed)
            return;
        hand = world.pick(e.clientX, e.clientY, canvas);
    }, listeners);
    canvas.addEventListener('pointerdown', e => {
        if (!started || disposed || e.button !== 0)
            return;
        e.preventDefault();
        hand = world.pick(e.clientX, e.clientY, canvas);
        act();
        canvas.focus({ preventScroll: true });
    }, listeners);
    canvas.addEventListener('contextmenu', e => e.preventDefault(), listeners);
    const resize = new ResizeObserver(() => {
        const rect = canvas.getBoundingClientRect();
        world.resize(rect.width, rect.height);
    });
    resize.observe(canvas);
    const initialRect = canvas.getBoundingClientRect();
    world.resize(initialRect.width, initialRect.height);
    document.addEventListener('visibilitychange', () => { previous = 0; accumulator = 0; keys.clear(); }, listeners);
    function step(dt) {
        time += dt;
        if (started) {
            const speed = 4.6 * dt;
            const go = (...v) => v.some(k => keys.has(k) || touchKeys.has(k));
            let dx = 0, dz = 0;
            if (go('a', 'arrowleft', 'left'))
                dx -= 1;
            if (go('d', 'arrowright', 'right'))
                dx += 1;
            if (go('w', 'arrowup', 'up'))
                dz -= 1;
            if (go('s', 'arrowdown', 'down'))
                dz += 1;
            const m = Math.hypot(dx, dz) || 1;
            if (dx || dz)
                moveHand(dx / m * speed, dz / m * speed);
            if (rules.state.sweepAttached && rules.moveWind(hand, dt)) {
                world.trigger('sweep-done');
                announce('SQUARE PURIFIED. Confetti has been relocated to the upper atmosphere.', 5);
                updateHUD();
                verifyVictory();
            }
            rules.tick(dt);
            const nextStage = victoryStage(rules.state);
            if (nextStage !== displayStage) {
                displayStage = nextStage;
                victory.classList.toggle('epilogue', nextStage === 'epilogue' || nextStage === 'postscript');
                victory.classList.toggle('postscript', nextStage === 'postscript');
                if (nextStage === 'postscript')
                    announce('The welcome sign has fallen over again. Victory remains legally binding.', 8);
            }
            hintTick += dt;
            if (hintTick > .11) {
                hintTick = 0;
                const feedback = rules.checkTarget(hand, world.safeResidents);
                hint.textContent = feedback.message;
                hint.parentElement?.classList.toggle('ready', feedback.ok);
                const color = feedback.ok ? 'var(--mint)' : 'var(--sand)';
                hint.style.color = color;
                if (time > statusUntil && lastStatus !== feedback.message) {
                    lastStatus = feedback.message;
                    toast.textContent = feedback.message;
                }
            }
        }
        const target = rules.checkTarget(hand, world.safeResidents).ok;
        world.update(dt, time, rules, { gesture: rules.state.gesture, hand, targetValid: target, reducedMotion: reduced });
    }
    world.renderer.setAnimationLoop((t) => {
        if (disposed)
            return;
        const secs = t / 1000;
        if (!previous)
            previous = secs;
        const delta = clamp(secs - previous, 0, .10);
        previous = secs;
        if (!document.hidden) {
            accumulator += delta;
            let steps = 0;
            while (accumulator >= 1 / 60 && steps < 5) {
                step(1 / 60);
                accumulator -= 1 / 60;
                steps++;
            }
            if (steps === 5)
                accumulator = 0;
            world.render();
        }
    });
    updateHUD();
    return {
        dispose() {
            if (disposed)
                return;
            disposed = true;
            abort.abort();
            resize.disconnect();
            world.renderer.setAnimationLoop(null);
            world.dispose();
            root.replaceChildren();
            delete root.dataset.mounted;
        },
        restart: reset,
        begin,
        snapshot: () => getSnapshot(rules),
    };
}
