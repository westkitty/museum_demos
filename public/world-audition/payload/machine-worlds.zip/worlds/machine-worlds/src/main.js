import * as THREE from 'three';

import { ACTS, END, PLATFORMS } from './game/route.js';
import { GameSimulation, FIXED_STEP } from './game/physics.js';
import { InputManager } from './game/input.js';
import { ProcessWorld } from './game/world.js';
import { responsiveVerticalSpan, horizontalLookAhead } from './game/framing.js';
import { requestMuseumReturn } from './game/bridge.js';
function el(id) {
    const node = document.getElementById(id);
    if (!node)
        throw new Error(`Missing required UI element: ${id}`);
    return node;
}
function hide(id, value) { el(id).hidden = value; }
function fmt(n) { const minutes = Math.floor(n / 60); return `${minutes}:${String(Math.floor(n % 60)).padStart(2, '0')}`; }
let disposed = false;
let paused = false;
let entered = false;
let showingOverview = false;
let elapsed = 0;
let highest = 0;
let lastAct = -1;
let accumulator = 0;
let lastFrame = 0;
let hardSnap = false;
let raf = 0;
let viewportWidth = 0;
let viewportHeight = 0;
let lastCheckpointCount = -1;
let lastRouteTarget = -1;
let diagnostics = null;
let diagnosticsClock = 0;
let diagnosticsFrames = 0;
let reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let reducedExplicit = false;
let highContrast = false;
let eco = false;
let isExiting = false;
const media = window.matchMedia('(prefers-reduced-motion: reduce)');
const simulation = new GameSimulation(event => onGameEvent(event));
let previousPlayerX = simulation.player.x;
let previousPlayerY = simulation.player.y;
const input = new InputManager(el('touch-controls'));
let world;
let renderer;
let camera;
const tmpTarget = new THREE.Vector3();
const camState = { x: -12, y: 9, span: 22 };
function setGuidance(message, announce = false) {
    el('guidance-text').textContent = message;
    if (announce)
        el('announce').textContent = message;
}
function setAct(act, force = false) {
    if (act === lastAct && !force)
        return;
    lastAct = act;
    const info = ACTS[act];
    el('act-number').textContent = info.number;
    el('act-name').textContent = info.name;
    el('act-description').textContent = info.function;
    const accent = `#${info.color.toString(16).padStart(6, '0')}`;
    el('act-name').style.setProperty('--act-color', accent);
    document.documentElement.style.setProperty('--stage-accent', accent);
    el('chapter-title').textContent = info.name;
    for (const item of document.querySelectorAll('#stage-index span'))
        item.classList.toggle('index-active', Number(item.dataset.stage) === act);
    setGuidance(info.narration, true);
}
function onGameEvent(event) {
    if (event.type === 'checkpoint') {
        setGuidance(`Checkpoint secured. ${ACTS[event.act].name} — fall recovery available.`, true);
        if (world && !reducedMotion)
            world.pulseAt(simulation.player.x, simulation.player.y, event.act, 20);
    }
    else if (event.type === 'act')
        setAct(event.act);
    else if (event.type === 'lift-start') {
        setGuidance(`Structural lift engaged. Rising toward ${ACTS[event.act + 1].name}.`, true);
        if (world && !reducedMotion)
            world.pulseAt(simulation.player.x, simulation.player.y, event.act, 28);
    }
    else if (event.type === 'lift-end')
        setGuidance('Lift reached its upper station. Jump onto the next illuminated platform.', true);
    else if (event.type === 'respawn') {
        hardSnap = true;
        setAct(event.act, true);
        setGuidance('Returned safely to the latest checkpoint.', true);
    }
    else if (event.type === 'complete') {
        if (world && !reducedMotion)
            world.pulseAt(simulation.player.x, simulation.player.y, 3, 32);
        finish();
    }
}
function updateHud() {
    const p = simulation.player;
    const percent = Math.max(0, Math.min(100, Math.round(p.y / END.y * 100)));
    el('progress-fill').style.width = `${percent}%`;
    el('elevation-readout').textContent = `${percent}% ASCENT`;
    el('journey-progress').setAttribute('aria-valuenow', String(percent));
    highest = Math.max(highest, p.y);
    const count = simulation.checkpoints.length;
    if (count !== lastCheckpointCount) {
        lastCheckpointCount = count;
        el('checkpoint-label').textContent = `SAFE RETURN  /  ${String(count).padStart(2, '0')} OF 16`;
    }
    const spec = PLATFORMS.find(x => x.id === p.groundedId);
    if (spec) {
        const index = PLATFORMS.indexOf(spec);
        if (index !== lastRouteTarget) {
            lastRouteTarget = index;
            const next = PLATFORMS[index + 1];
            el('landing-label').textContent = next ? `NEXT LANDING / ${String(next.index + 1).padStart(2, '0')} OF 40` : 'FINAL OVERLOOK';
        }
    }
    hide('lift-hint', !(entered && !paused && spec?.kind === 'lift' && simulation.lifts[spec.act] < 1));
}
function setMotion(value, manual = true) {
    reducedMotion = value;
    if (manual)
        reducedExplicit = true;
    simulation.reducedMotion = value;
    document.documentElement.classList.toggle('reduced-motion', value);
    el('introMotion').textContent = `REDUCE MOTION: ${value ? 'ON' : 'OFF'}`;
    el('introMotion').setAttribute('aria-pressed', String(value));
    const button = el('motionToggle');
    button.setAttribute('aria-pressed', String(value));
    button.querySelector('span').textContent = value ? 'ON' : 'OFF';
}
function toggleContrast() {
    highContrast = !highContrast;
    document.documentElement.classList.toggle('high-contrast', highContrast);
    if (world)
        world.setContrast(highContrast);
    const button = el('contrastToggle');
    button.setAttribute('aria-pressed', String(highContrast));
    button.querySelector('span').textContent = highContrast ? 'ON' : 'OFF';
}
function toggleEco() {
    eco = !eco;
    el('qualityToggle').setAttribute('aria-pressed', String(eco));
    el('qualityToggle').querySelector('span').textContent = eco ? 'ON' : 'OFF';
    if (renderer) {
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, eco ? 1 : window.matchMedia('(max-width: 640px)').matches ? 1.2 : 1.6));
        resize();
    }
    if (world)
        world.setQuality(eco);
}
function begin() {
    if (disposed)
        return;
    hide('intro', true);
    hide('pause', true);
    hide('complete', true);
    hide('overview-label', true);
    simulation.resetFull();
    elapsed = 0;
    highest = 0;
    entered = true;
    paused = false;
    showingOverview = false;
    previousPlayerX = simulation.player.x;
    previousPlayerY = simulation.player.y;
    hardSnap = true;
    setAct(0, true);
    updateHud();
    input.setEnabled(true);
    document.activeElement?.blur();
}
function setPaused(value) {
    if (!entered || simulation.player.finished || showingOverview || disposed)
        return;
    paused = value;
    hide('pause', !paused);
    input.setEnabled(!paused);
    if (paused) {
        el('resume').focus();
        el('announce').textContent = 'Journey paused.';
    }
    else {
        el('pauseHud').blur();
        el('announce').textContent = 'Ascent resumed.';
    }
}
function finish() {
    input.setEnabled(false);
    hide('lift-hint', true);
    hide('complete', false);
    el('final-time').textContent = `Journey time ${fmt(elapsed)}. This is a process illustration, not a canonical historical event.`;
    setGuidance('Overlook reached. Four functions are now visible within one model.', true);
    el('overview').focus();
}
function toggleOverview(value) {
    showingOverview = value;
    hide('complete', value);
    hide('overview-label', !value);
    if (value)
        el('closeOverview').focus();
    else
        el('overview').focus();
}
function returnToPortal() {
    showingOverview = false;
    entered = false;
    paused = false;
    simulation.resetFull();
    input.setEnabled(false);
    previousPlayerX = simulation.player.x;
    previousPlayerY = simulation.player.y;
    hardSnap = true;
    hide('pause', true);
    hide('complete', true);
    hide('overview-label', true);
    hide('intro', false);
    camState.x = -12;
    camState.y = 9;
    camState.span = 22;
    setAct(0, true);
    updateHud();
    el('begin').focus();
    setGuidance('Return complete: local museum portal mock is ready.', true);
}
async function returnToMuseum() {
    if (isExiting || disposed)
        return;
    isExiting = true;
    setGuidance('Requesting museum return…', true);
    try {
        const mode = await requestMuseumReturn(() => dispose());
        if (mode === 'mock')
            returnToPortal();
    }
    catch (e) {
        setGuidance(`Museum bridge unavailable: ${e instanceof Error ? e.message : String(e)}`, true);
        returnToPortal();
    }
    finally {
        isExiting = false;
    }
}
function installUI() {
    el('begin').addEventListener('click', begin);
    el('pauseHud').addEventListener('click', () => setPaused(!paused));
    el('resume').addEventListener('click', () => setPaused(false));
    el('respawn').addEventListener('click', () => { simulation.resetToCheckpoint(); updateHud(); setPaused(false); });
    el('motionToggle').addEventListener('click', () => setMotion(!reducedMotion));
    el('introMotion').addEventListener('click', () => setMotion(!reducedMotion));
    el('contrastToggle').addEventListener('click', toggleContrast);
    el('qualityToggle').addEventListener('click', toggleEco);
    el('returnPause').addEventListener('click', () => void returnToMuseum());
    el('returnComplete').addEventListener('click', () => void returnToMuseum());
    el('replay').addEventListener('click', begin);
    el('overview').addEventListener('click', () => toggleOverview(true));
    el('closeOverview').addEventListener('click', () => toggleOverview(false));
    input.onPause = () => {
        if (!entered)
            return;
        if (showingOverview) {
            toggleOverview(false);
            return;
        }
        if (simulation.player.finished)
            return;
        setPaused(!paused);
    };
    media.addEventListener('change', onMediaMotion);
    const enterHandler = (event) => {
        if (event.key === 'Tab') {
            const panel = !el('pause').hidden ? el('pause') : !el('complete').hidden ? el('complete') : !el('intro').hidden ? el('intro') : null;
            if (!panel)
                return;
            const controls = Array.from(panel.querySelectorAll('button:not([disabled])'));
            if (!controls.length)
                return;
            const first = controls[0], last = controls.at(-1);
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            }
            else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        }
    };
    window.addEventListener('keydown', enterHandler);
    teardown.push(() => window.removeEventListener('keydown', enterHandler), () => media.removeEventListener('change', onMediaMotion));
}
function onMediaMotion() { if (!reducedExplicit)
    setMotion(media.matches, false); }
const teardown = [];
function resize() {
    if (!renderer)
        return;
    const parent = el('viewport');
    const w = Math.max(1, parent.clientWidth), h = Math.max(1, parent.clientHeight);
    if (w !== viewportWidth || h !== viewportHeight) {
        viewportWidth = w;
        viewportHeight = h;
        renderer.setSize(w, h, false);
    }
    const aspect = w / h;
    const visibleSpan = responsiveVerticalSpan(camState.span, aspect);
    const left = -visibleSpan * aspect * .5;
    const right = visibleSpan * aspect * .5;
    const top = visibleSpan * .5;
    const bottom = -visibleSpan * .5;
    // A projection rebuild is necessary only when size or framing actually changes.
    if (Math.abs(camera.left - left) > 1e-5 || Math.abs(camera.top - top) > 1e-5 ||
        Math.abs(camera.right - right) > 1e-5 || Math.abs(camera.bottom - bottom) > 1e-5) {
        camera.left = left;
        camera.right = right;
        camera.top = top;
        camera.bottom = bottom;
        camera.updateProjectionMatrix();
    }
}
function updateCamera(dt, visualX = simulation.player.x, visualY = simulation.player.y, snapCamera = false) {
    const overview = (simulation.player.finished && showingOverview);
    const desired = {
        x: overview ? -3 : horizontalLookAhead(visualX, simulation.player.facing, simulation.player.vx),
        y: overview ? (END.y / 2 + 4) : visualY + 6.4 + Math.max(0, simulation.player.vy) * .09,
        span: overview ? (END.y + 49) : simulation.liftActive.some(Boolean) ? 25 : 22,
    };
    // Recovery and new runs recenter immediately; decorative easing cannot hide a respawn.
    const factor = (snapCamera || reducedMotion) ? 1 : 1 - Math.exp(-dt * (overview ? 1.15 : 4.8));
    camState.x += (desired.x - camState.x) * factor;
    camState.y += (desired.y - camState.y) * factor;
    camState.span += (desired.span - camState.span) * factor;
    camera.position.set(camState.x + (overview ? 10 : 4.6), camState.y + (overview ? 6 : 2.8), overview ? 142 : 51);
    tmpTarget.set(camState.x, camState.y, 0);
    camera.lookAt(tmpTarget);
    world.setOverview(overview);
    resize();
}
function frame(now) {
    if (disposed)
        return;
    if (!lastFrame)
        lastFrame = now;
    const dt = Math.min(.075, Math.max(0, (now - lastFrame) / 1000));
    lastFrame = now;
    if (entered && !paused && !simulation.player.finished) {
        accumulator = Math.min(.15, accumulator + dt);
        let steps = 0;
        while (accumulator >= FIXED_STEP && steps < 6) {
            previousPlayerX = simulation.player.x;
            previousPlayerY = simulation.player.y;
            simulation.step(FIXED_STEP, input.sample());
            accumulator -= FIXED_STEP;
            steps++;
        }
        if (steps === 6)
            accumulator = 0;
        elapsed += dt;
    }
    const alpha = Math.max(0, Math.min(1, accumulator / FIXED_STEP));
    const cameraSnap = hardSnap;
    const snap = hardSnap || simulation.player.finished || paused || reducedMotion;
    const visualX = snap ? simulation.player.x : previousPlayerX + (simulation.player.x - previousPlayerX) * alpha;
    const visualY = snap ? simulation.player.y : previousPlayerY + (simulation.player.y - previousPlayerY) * alpha;
    const renderTime = snap ? simulation.time : Math.max(0, simulation.time - FIXED_STEP + accumulator);
    hardSnap = false;
    world.update(simulation, entered && !paused ? dt : 0, visualX, visualY, renderTime);
    updateCamera(dt, visualX, visualY, cameraSnap);
    updateHud();
    renderer.render(world.scene, camera);
    if (diagnostics) {
        diagnosticsFrames++;
        diagnosticsClock += dt;
        if (diagnosticsClock >= 1) {
            const fps = Math.round(diagnosticsFrames / diagnosticsClock);
            const savings = world.getRenderSavings();
            diagnostics.textContent = `E02 QA  |  ${fps} FPS  |  ${renderer.info.render.calls} DRAWS  |  ` +
                `${renderer.info.memory.geometries} GEOMETRIES  |  ${renderer.info.memory.textures} TEXTURES  |  ${savings.estimatedSaved} STATIC DRAWS CONSOLIDATED (EST.)  |  ACT ${simulation.player.act + 1}`;
            diagnosticsFrames = 0;
            diagnosticsClock = 0;
        }
    }
    raf = requestAnimationFrame(frame);
}
function dispose() {
    if (disposed)
        return;
    disposed = true;
    cancelAnimationFrame(raf);
    input.dispose();
    for (const fn of teardown)
        fn();
    if (world)
        world.dispose();
    if (renderer) {
        renderer.dispose();
        renderer.forceContextLoss();
        renderer.domElement.remove();
    }
    diagnostics?.remove();
    diagnostics = null;
}
function init() {
    try {
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, window.matchMedia('(max-width: 640px)').matches ? 1.2 : 1.6));
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.18;
        renderer.domElement.setAttribute('aria-hidden', 'true');
        renderer.domElement.setAttribute('tabindex', '-1');
        el('viewport').appendChild(renderer.domElement);
        camera = new THREE.OrthographicCamera(-16, 16, 11, -11, 0.1, 650);
        world = new ProcessWorld();
        world.setQuality(eco);
        if (new URLSearchParams(location.search).get('diagnostics') === '1') {
            diagnostics = document.createElement('output');
            diagnostics.className = 'qa-diagnostics';
            diagnostics.setAttribute('aria-label', 'Optional live rendering diagnostics');
            diagnostics.textContent = 'E02 QA / Initializing renderer counters';
            el('app').appendChild(diagnostics);
        }
        setMotion(reducedMotion, false);
        setAct(0, true);
        input.setEnabled(false);
        installUI();
        window.addEventListener('resize', resize);
        window.addEventListener('pagehide', dispose, { once: true });
        teardown.push(() => window.removeEventListener('resize', resize), () => window.removeEventListener('pagehide', dispose));
        resize();
        raf = requestAnimationFrame(frame);
        el('begin').focus();
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        el('error-detail').textContent = message;
        hide('error', false);
        console.error('E02 pocket-world bootstrap failed', error);
    }
}
init();
