import * as THREE from 'three';
import { CHECKPOINTS, DECKS, E28_REFERENCE } from './level.js';
const C = {
    void: 0x030a16,
    hull: 0x182738,
    hullBright: 0x28445a,
    dark: 0x0b1728,
    white: 0xe6f5ff,
    cyan: E28_REFERENCE.Picket.colour,
    scarlet: E28_REFERENCE.Lance.colour,
    verdant: E28_REFERENCE.Tender.colour,
    gold: 0xffc77e,
    energy: 0x7de9f0,
};
const COLORS = { Picket: C.cyan, Lance: C.scarlet, Tender: C.verdant };
function randomFactory(seed) {
    let state = seed >>> 0;
    return () => { state = (1664525 * state + 1013904223) >>> 0; return state / 4294967296; };
}
function material(color, metalness = 0.7, roughness = 0.33, emissive = 0, glow = 0) {
    return new THREE.MeshStandardMaterial({ color, metalness, roughness, emissive, emissiveIntensity: glow, flatShading: false });
}
function lightMat(hex, intensity = 1.8) {
    return new THREE.MeshStandardMaterial({ color: hex, roughness: 0.35, metalness: 0.24, emissive: hex, emissiveIntensity: intensity });
}
class FleetWorld {
    detail;
    scene = new THREE.Scene();
    playerAnchor = new THREE.Group();
    moveCameraTarget = new THREE.Vector3();
    root = new THREE.Group();
    /** One deterministic random stream per world, independent of prior constructions. */
    rng = randomFactory(28028);
    rand(lo, hi) { return lo + (hi - lo) * this.rng(); }
    boxGeometries = new Map();
    motion = [];
    checkpoints = [];
    energy = [];
    engineLights = [];
    engineFlames = [];
    impactPool = [];
    boostFX = new THREE.Group();
    particles = [];
    stars;
    planet;
    planetClouds;
    glowTexture;
    surfaceTexture;
    hullWearTexture;
    environmentTexture;
    temp = new THREE.Vector3();
    currentCheckpoint = -1;
    boostStart = -100;
    clock = 0;
    constructor(detail = 'full') {
        this.detail = detail;
        this.scene.background = new THREE.Color(C.void);
        this.scene.fog = new THREE.FogExp2(C.void, 0.00031);
        this.scene.add(this.root);
        this.root.add(this.playerAnchor);
        this.glowTexture = this.createGlowTexture();
        this.surfaceTexture = this.createDeckTexture();
        this.hullWearTexture = this.createHullWearTexture();
        this.environmentTexture = this.createReflectionEnvironment();
        this.scene.environment = this.environmentTexture;
        this.scene.environmentIntensity = .78;
        this.scene.add(new THREE.HemisphereLight(0x9fceff, 0x101824, 2.05));
        const sun = new THREE.DirectionalLight(0xffdbba, 3.0);
        sun.position.set(-100, 195, 70);
        this.scene.add(sun);
        const rim = new THREE.DirectionalLight(0x63bdfa, 2.5);
        rim.position.set(280, 75, -180);
        this.scene.add(rim);
        const red = new THREE.DirectionalLight(0xd9543a, 0.75);
        red.position.set(150, 10, 150);
        this.scene.add(red);
        // The colored key pools are deliberately limited and do not cast shadowmaps.
        for (const [x, y, z, hue] of [[28, 16, -13, C.cyan], [163, 16, -13, C.scarlet], [300, 18, -16, C.verdant]]) {
            const pool = new THREE.PointLight(hue, 480, 76, 2);
            pool.position.set(x, y, z);
            this.scene.add(pool);
        }
        this.stars = this.makeStars();
        this.root.add(this.stars);
        this.addNebulae();
        const { planet, clouds } = this.makePlanet();
        this.planet = planet;
        this.planetClouds = clouds;
        this.root.add(planet, clouds);
        this.buildShips();
        this.buildDecks();
        this.buildCausewayThroat();
        this.buildDebris();
        this.buildCheckpointBeacons();
        this.buildFinish();
        this.buildSignatureStructures();
        this.buildRunwayGuides();
        this.buildDistantGraveyard();
        this.buildImpactPool();
        this.root.add(this.boostFX);
        this.buildBoostFX();
    }
    box(parent, w, h, d, m, x = 0, y = 0, z = 0) {
        const key = `${w.toFixed(3)}/${h.toFixed(3)}/${d.toFixed(3)}`;
        let geo = this.boxGeometries.get(key);
        if (!geo) {
            geo = new THREE.BoxGeometry(w, h, d);
            this.boxGeometries.set(key, geo);
        }
        const mesh = new THREE.Mesh(geo, m);
        mesh.position.set(x, y, z);
        parent.add(mesh);
        return mesh;
    }
    /** One draw call for repeated static plates rather than one mesh per marking. */
    boxBatch(parent, w, h, d, mat, locations) {
        if (!locations.length)
            return;
        const key = `${w.toFixed(3)}/${h.toFixed(3)}/${d.toFixed(3)}`;
        let geo = this.boxGeometries.get(key);
        if (!geo) {
            geo = new THREE.BoxGeometry(w, h, d);
            this.boxGeometries.set(key, geo);
        }
        const inst = new THREE.InstancedMesh(geo, mat, locations.length);
        const dummy = new THREE.Object3D();
        locations.forEach(([x, y, z], i) => { dummy.position.set(x, y, z); dummy.updateMatrix(); inst.setMatrixAt(i, dummy.matrix); });
        inst.instanceMatrix.needsUpdate = true;
        inst.computeBoundingSphere();
        parent.add(inst);
    }
    boxBatchRotated(parent, w, h, d, mat, locations) {
        if (!locations.length)
            return;
        const key = `${w.toFixed(3)}/${h.toFixed(3)}/${d.toFixed(3)}`;
        let geo = this.boxGeometries.get(key);
        if (!geo) {
            geo = new THREE.BoxGeometry(w, h, d);
            this.boxGeometries.set(key, geo);
        }
        const inst = new THREE.InstancedMesh(geo, mat, locations.length);
        const dummy = new THREE.Object3D();
        locations.forEach(([x, y, z, angle], i) => {
            dummy.position.set(x, y, z);
            dummy.rotation.y = angle;
            dummy.updateMatrix();
            inst.setMatrixAt(i, dummy.matrix);
        });
        inst.instanceMatrix.needsUpdate = true;
        inst.computeBoundingSphere();
        parent.add(inst);
    }
    createDeckTexture() {
        // Reusable deterministic etched metal; no image download or runtime dependency.
        const c = document.createElement('canvas');
        c.width = c.height = 512;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#b0bdc5';
        ctx.fillRect(0, 0, 512, 512);
        for (let x = 0; x < 512; x += 64) {
            for (let y = 0; y < 512; y += 64) {
                const alt = (x / 64 + y / 64) % 3;
                ctx.fillStyle = alt ? 'rgba(10,28,44,.105)' : 'rgba(226,245,250,.09)';
                ctx.fillRect(x + 2, y + 2, 60, 60);
                ctx.strokeStyle = 'rgba(8,25,40,.38)';
                ctx.lineWidth = 2;
                ctx.strokeRect(x + .5, y + .5, 63, 63);
                ctx.fillStyle = 'rgba(10,28,41,.55)';
                for (const a of [8, 55])
                    for (const b of [8, 55]) {
                        ctx.beginPath();
                        ctx.arc(x + a, y + b, 2.2, 0, Math.PI * 2);
                        ctx.fill();
                    }
            }
        }
        const rand = randomFactory(7792);
        for (let i = 0; i < 1500; i++) {
            const x = rand() * 512, y = rand() * 512;
            ctx.strokeStyle = rand() > .5 ? 'rgba(11,34,54,.09)' : 'rgba(240,252,255,.10)';
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + 2 + rand() * 25, y + rand() * 1.2);
            ctx.stroke();
        }
        const texture = new THREE.CanvasTexture(c);
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
        texture.repeat.set(3.3, 1.6);
        texture.anisotropy = 4;
        return texture;
    }
    /** One shared procedural micro-relief map for hull plating. No image loading or unique per-mesh textures. */
    createHullWearTexture() {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 512;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#909090';
        ctx.fillRect(0, 0, 512, 512);
        const rand = randomFactory(19128);
        for (let row = 0; row < 8; row++)
            for (let col = 0; col < 8; col++) {
                const x = col * 64, y = row * 64;
                ctx.fillStyle = (row + col) % 3 === 0 ? '#999999' : '#888888';
                ctx.fillRect(x + 2, y + 2, 60, 60);
                ctx.strokeStyle = '#555555';
                ctx.lineWidth = 2;
                ctx.strokeRect(x + .5, y + .5, 63, 63);
                ctx.strokeStyle = '#b7b7b7';
                ctx.lineWidth = 1;
                ctx.strokeRect(x + 3, y + 3, 57, 57);
                for (const dotX of [8, 56])
                    for (const dotY of [8, 56]) {
                        ctx.fillStyle = '#464646';
                        ctx.beginPath();
                        ctx.arc(x + dotX, y + dotY, 2.2, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.fillStyle = '#b8b8b8';
                        ctx.fillRect(x + dotX - 1, y + dotY - 1, 1, 1);
                    }
            }
        for (let i = 0; i < 3600; i++) {
            const x = rand() * 512, y = rand() * 512;
            ctx.strokeStyle = rand() > .5 ? 'rgba(242,242,242,.24)' : 'rgba(33,33,33,.25)';
            ctx.lineWidth = .5 + rand();
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + 2 + rand() * 19, y + rand() * 1.6 - .8);
            ctx.stroke();
        }
        const texture = new THREE.CanvasTexture(canvas);
        texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
        texture.repeat.set(3, 2);
        texture.anisotropy = 4;
        return texture;
    }
    createReflectionEnvironment() {
        // Reflection-only studio sky: long luminous panels in a dark orbital environment.
        // This is cheaper than realtime reflection capture and gives metallic hulls form.
        const c = document.createElement('canvas');
        c.width = 1024;
        c.height = 512;
        const ctx = c.getContext('2d');
        const bg = ctx.createLinearGradient(0, 0, 0, 512);
        bg.addColorStop(0, '#15243a');
        bg.addColorStop(.45, '#31455c');
        bg.addColorStop(.55, '#1b283e');
        bg.addColorStop(1, '#080f1d');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, 1024, 512);
        for (const [x, y, w, h, color] of [
            [125, 110, 84, 90, 'rgba(176,231,255,.86)'],
            [370, 140, 230, 24, 'rgba(243,198,148,.75)'],
            [710, 98, 56, 145, 'rgba(95,204,230,.65)'],
            [870, 188, 104, 26, 'rgba(252,228,196,.72)'],
        ]) {
            const halo = ctx.createRadialGradient(x + w / 2, y + h / 2, 1, x + w / 2, y + h / 2, Math.max(w, h) * 1.9);
            halo.addColorStop(0, color);
            halo.addColorStop(1, 'rgba(11,21,44,0)');
            ctx.fillStyle = halo;
            ctx.fillRect(x - 210, y - 210, w + 420, h + 420);
            ctx.fillStyle = color;
            ctx.fillRect(x, y, w, h);
        }
        const tex = new THREE.CanvasTexture(c);
        tex.mapping = THREE.EquirectangularReflectionMapping;
        tex.colorSpace = THREE.SRGBColorSpace;
        return tex;
    }
    cylinder(parent, r0, r1, length, m, x, y, z, rotateZ = Math.PI / 2) {
        const mesh = new THREE.Mesh(new THREE.CylinderGeometry(r0, r1, length, 18, 1), m);
        mesh.rotation.z = rotateZ;
        mesh.position.set(x, y, z);
        parent.add(mesh);
        return mesh;
    }
    line(parent, pts, color, opacity = 0.8) {
        const geo = new THREE.BufferGeometry().setFromPoints(pts);
        const mat = new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthWrite: false, blending: THREE.AdditiveBlending });
        parent.add(new THREE.Line(geo, mat));
    }
    createGlowTexture() {
        const c = document.createElement('canvas');
        c.width = c.height = 128;
        const ctx = c.getContext('2d');
        const grad = ctx.createRadialGradient(64, 64, 2, 64, 64, 62);
        grad.addColorStop(0, 'rgba(255,255,255,1)');
        grad.addColorStop(0.12, 'rgba(220,250,255,.88)');
        grad.addColorStop(0.4, 'rgba(112,205,255,.24)');
        grad.addColorStop(1, 'rgba(10,30,90,0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 128, 128);
        const tex = new THREE.CanvasTexture(c);
        tex.colorSpace = THREE.SRGBColorSpace;
        return tex;
    }
    sprite(parent, x, y, z, s, color, opacity = 0.8) {
        const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glowTexture, color, blending: THREE.AdditiveBlending, transparent: true, opacity, depthWrite: false }));
        spr.position.set(x, y, z);
        spr.scale.set(s, s, 1);
        parent.add(spr);
        return spr;
    }
    makeStars() {
        const count = this.detail === 'full' ? 7000 : 2900;
        const positions = new Float32Array(count * 3);
        const colors = new Float32Array(count * 3);
        for (let i = 0; i < count; i++) {
            const j = i * 3;
            positions[j] = this.rand(-1750, 1750);
            positions[j + 1] = this.rand(-850, 1000);
            positions[j + 2] = this.rand(-1800, -150);
            const t = this.rng();
            colors[j] = t > .83 ? .98 : t > .4 ? .48 : .3;
            colors[j + 1] = t > .83 ? .76 : .74;
            colors[j + 2] = t > .83 ? .57 : .99;
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        return new THREE.Points(geo, new THREE.PointsMaterial({ size: 2.4, transparent: true, opacity: .72, vertexColors: true, sizeAttenuation: true, depthWrite: false }));
    }
    addNebulae() {
        const nebula = [
            [-650, 150, -1200, 720, 0x1b5c83, .22],
            [800, 250, -1400, 970, 0x604390, .16],
            [-300, -300, -1100, 620, 0x254a9c, .2],
            [900, -100, -1200, 750, 0x8b384d, .11],
        ];
        for (const [x, y, z, s, color, opacity] of nebula)
            this.sprite(this.root, x, y, z, s, color, opacity);
        for (let i = 0; i < (this.detail === 'full' ? 46 : 16); i++) {
            const x = this.rand(-650, 850), y = this.rand(-270, 380), z = this.rand(-800, -300);
            this.sprite(this.root, x, y, z, this.rand(8, 28), this.rng() > .55 ? 0xb6dbff : 0xd8b6a0, this.rand(.1, .35));
        }
    }
    planetTexture() {
        const w = 1024, h = 512;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        const img = ctx.createImageData(w, h);
        for (let j = 0; j < h; j++) {
            const lat = j / h;
            for (let i = 0; i < w; i++) {
                const u = i / w;
                const warped = lat * 26 + .45 * Math.sin(u * 16 + lat * 18) + .23 * Math.sin(u * 61 - lat * 53);
                const band = Math.sin(warped * 2.25) * .46 + Math.sin(warped * 4.0) * .13 + Math.sin(warped * .61) * .22;
                const storm = Math.sin(u * 43 + Math.sin(lat * 27) * 3) * Math.cos(lat * 40 - u * 9) * .10;
                const swirl = Math.sin(2 * Math.PI * (u * 3 + lat * 8) + Math.sin(u * 30) * .3) * .07;
                // A single storm eye near the southern atmosphere interrupts the bands.
                // It reads as planetary scale rather than extra noise.
                const eyeX = (u - .68) / .075, eyeY = (lat - .53) / .095;
                const stormRadius = Math.sqrt(eyeX * eyeX + eyeY * eyeY);
                const cyclone = Math.exp(-Math.pow((stormRadius - .82) * 2.9, 2));
                const pupil = Math.exp(-stormRadius * stormRadius * 12);
                const t = Math.max(0, Math.min(1, .55 + band + storm + swirl + cyclone * .14 - pupil * .26));
                const deep = [23, 58, 93], bright = [216, 190, 158], ink = [78, 127, 150];
                const w2 = Math.max(0, Math.min(1, Math.sin(t * Math.PI) * .48));
                const r = deep[0] + (bright[0] - deep[0]) * t;
                const g = deep[1] + (bright[1] - deep[1]) * t;
                const b = deep[2] + (bright[2] - deep[2]) * t;
                const idx = (j * w + i) * 4;
                img.data[idx] = r * (1 - w2) + ink[0] * w2 + cyclone * 22;
                img.data[idx + 1] = g * (1 - w2) + ink[1] * w2 + cyclone * 9;
                img.data[idx + 2] = b * (1 - w2) + ink[2] * w2 - cyclone * 16;
                img.data[idx + 3] = 255;
            }
        }
        ctx.putImageData(img, 0, 0);
        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = THREE.RepeatWrapping;
        tex.anisotropy = 4;
        return tex;
    }
    makePlanet() {
        const center = new THREE.Vector3(225, -212, -690);
        const radius = 260;
        const sphere = new THREE.SphereGeometry(radius, 96, 64);
        const tex = this.planetTexture();
        const mat = new THREE.MeshStandardMaterial({ map: tex, metalness: 0.04, roughness: 0.96, emissive: 0x214063, emissiveIntensity: 0.12 });
        const planet = new THREE.Mesh(sphere, mat);
        planet.position.copy(center);
        planet.rotation.z = .12;
        // A faint second atmospheric sphere shows atmospheric limb while preserving a clean silhouette.
        const clouds = new THREE.Mesh(new THREE.SphereGeometry(radius + 6, 64, 48), new THREE.ShaderMaterial({
            uniforms: { color: { value: new THREE.Color(0x66d9ff) } },
            vertexShader: `varying vec3 vNormal; varying vec3 vEye; void main(){vec4 mv=modelViewMatrix*vec4(position,1.);vNormal=normalize(normalMatrix*normal);vEye=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}`,
            fragmentShader: `uniform vec3 color; varying vec3 vNormal; varying vec3 vEye; void main(){float edge=pow(1.-abs(dot(normalize(vNormal),normalize(vEye))),3.);gl_FragColor=vec4(color,edge*.56);}`,
            transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        }));
        clouds.position.copy(center);
        // Wide backlit corona, deliberately not a weather effect.
        this.sprite(this.root, center.x, center.y, center.z - 10, radius * 2.9, 0x4f8fb8, .30);
        this.sprite(this.root, center.x - 180, center.y + 155, center.z - 70, radius * 1.8, 0xe4ac73, .14);
        // Backlit dust ring: a single quiet disc, not weather and not postprocessing.
        const ring = new THREE.Mesh(new THREE.RingGeometry(radius * 1.27, radius * 1.68, 160, 1), new THREE.MeshBasicMaterial({ color: 0x7fb0c6, transparent: true, opacity: .13, side: THREE.DoubleSide, depthWrite: false }));
        ring.position.copy(center);
        ring.rotation.set(-.34, -.12, .18);
        this.root.add(ring);
        const ringHighlight = new THREE.Mesh(new THREE.RingGeometry(radius * 1.44, radius * 1.455, 160, 1), new THREE.MeshBasicMaterial({ color: 0xeec7a3, transparent: true, opacity: .24, side: THREE.DoubleSide, depthWrite: false }));
        ringHighlight.position.copy(center);
        ringHighlight.rotation.copy(ring.rotation);
        this.root.add(ringHighlight);
        // Thin orbital drafting arcs at vastly different depths.
        const arcPts = [];
        for (let i = 0; i <= 180; i++) {
            const a = -Math.PI * .32 + i / 180 * Math.PI * 1.22;
            arcPts.push(new THREE.Vector3(center.x + Math.cos(a) * (radius + 58), center.y + Math.sin(a) * (radius * .48), center.z - 110));
        }
        this.line(this.root, arcPts, 0x8cb8d3, .16);
        return { planet, clouds };
    }
    hullShape(length, width, role) {
        const l = length / 2, w = width / 2;
        const s = new THREE.Shape();
        if (role === 'Picket') {
            s.moveTo(-l, -w * .26);
            s.lineTo(-l * .80, -w * .62);
            s.lineTo(-l * .28, -w);
            s.lineTo(l * .65, -w * .77);
            s.lineTo(l, 0);
            s.lineTo(l * .65, w * .77);
            s.lineTo(-l * .28, w);
            s.lineTo(-l * .80, w * .62);
            s.lineTo(-l, w * .26);
        }
        else if (role === 'Lance') {
            s.moveTo(-l, -w * .34);
            s.lineTo(-l * .72, -w * .88);
            s.lineTo(l * .18, -w * .67);
            s.lineTo(l * .63, -w * .37);
            s.lineTo(l, 0);
            s.lineTo(l * .63, w * .37);
            s.lineTo(l * .18, w * .67);
            s.lineTo(-l * .72, w * .88);
            s.lineTo(-l, w * .34);
        }
        else {
            s.moveTo(-l, -w * .56);
            s.lineTo(-l * .67, -w);
            s.lineTo(l * .35, -w);
            s.lineTo(l * .82, -w * .73);
            s.lineTo(l, -w * .38);
            s.lineTo(l * .8, 0);
            s.lineTo(l, w * .38);
            s.lineTo(l * .82, w * .73);
            s.lineTo(l * .35, w);
            s.lineTo(-l * .67, w);
            s.lineTo(-l, w * .56);
        }
        s.closePath();
        return s;
    }
    buildShips() {
        this.buildShip('Picket', 5, 121, 35, -1.2, 0);
        this.buildShip('Lance', 140, 149, 46, 1.45, 1);
        this.buildShip('Tender', 283, 163, 54, 4.75, 2);
    }
    buildShip(role, x, length, width, deckTop, index) {
        const group = new THREE.Group();
        group.position.set(x, 0, 0);
        this.root.add(group);
        const tint = COLORS[role];
        const hull = material(role === 'Picket' ? 0x18334c : role === 'Lance' ? 0x3a2b33 : 0x243b3b, .80, .30);
        const steel = material(C.hull, .86, .28);
        const dark = material(0x0b1524, .76, .42);
        const bright = material(0x3c556a, .81, .35);
        // Bump only: tint is controlled by art direction and remains legible under dim light.
        hull.bumpMap = this.hullWearTexture;
        hull.bumpScale = .085;
        steel.bumpMap = this.hullWearTexture;
        steel.bumpScale = .045;
        bright.bumpMap = this.hullWearTexture;
        bright.bumpScale = .035;
        const neon = lightMat(tint, 2.3);
        const dimNeon = lightMat(tint, .65);
        const shaped = new THREE.Mesh(new THREE.ExtrudeGeometry(this.hullShape(length, width, role), {
            depth: 14 + index * 3, steps: 1, bevelEnabled: true, bevelThickness: .82, bevelSize: .64, bevelSegments: 2, curveSegments: 4,
        }), [hull, steel]);
        shaped.rotation.x = Math.PI / 2;
        shaped.position.y = deckTop - 1.35;
        shaped.material = hull;
        group.add(shaped);
        this.box(group, length * .70, 1.4, width * .58, bright, -length * .06, deckTop - 1.05, 0);
        this.box(group, length * .48, .28, width * .3, dark, length * .05, deckTop - .22, 0);
        this.box(group, length * .64, 2.1, width * .27, dark, -length * .04, deckTop - 14 - index * 1.5, 0);
        // Massive gunwale veins, layered keels, construction plates. Repeated plates are instanced.
        const armorRibs = Array.from({ length: 3 }, () => []);
        const accentRibs = Array.from({ length: 3 }, () => []);
        const signalDots = [];
        for (const side of [-1, 1]) {
            this.box(group, length * .7, 1.6, 1.7, steel, -length * .04, deckTop - 2.1, side * width * .4);
            this.box(group, length * .70, .14, .18, neon, -length * .04, deckTop - .92, side * width * .38);
            this.box(group, length * .56, .11, .11, dimNeon, -length * .12, deckTop - 5.5, side * width * .43);
            for (let i = 0; i < 12; i++) {
                const px = -length * .34 + i * length * .056;
                (i % 4 === 0 ? accentRibs : armorRibs)[i % 3].push([px, deckTop - .82, side * width * .29]);
                signalDots.push([px, deckTop + .05, side * width * .28]);
            }
        }
        for (let h = 0; h < 3; h++) {
            this.boxBatch(group, .42, 1.4 + h, width * .18, steel, armorRibs[h]);
            this.boxBatch(group, .42, 1.4 + h, width * .18, bright, accentRibs[h]);
        }
        this.boxBatch(group, .25, .12, width * .12, dimNeon, signalDots);
        // Silhouette: graduated staggered weapons, exposed bridge and spine.
        for (let i = 0; i < 5; i++) {
            const px = -length * .23 + i * length * .117;
            const height = 3.3 + (i % 2) * 2.3;
            this.box(group, 5.3, height, 5 + (i % 2) * 2, dark, px, deckTop - .9 + height * .5, width * .33);
            this.box(group, 4.2, .22, 4.6, dimNeon, px, deckTop + height - .6, width * .33);
            this.box(group, 5.3, height * .72, 4.1, dark, px, deckTop - .9 + height * .38, -width * .35);
            const turret = this.cylinder(group, .65, 1.05, 6.3, dark, px + 2.5, deckTop + height * .8, width * .32, Math.PI / 2);
            turret.rotation.z = Math.PI / 2;
        }
        this.box(group, length * .36, .26, width * .06, neon, length * .04, deckTop - .05, 0);
        // Forward command spire: tall but kept off navigable corridor.
        this.box(group, 9, 8 + index * 3, 5, steel, length * .18, deckTop + 2.0, -width * .39);
        this.box(group, 12, 1.1, 7, bright, length * .18, deckTop + 6.5 + index * 3, -width * .39);
        const fin = this.cylinder(group, .55, 1.15, 10 + index * 4, steel, length * .18, deckTop + 12 + index * 3, -width * .39, 0);
        fin.rotation.z = 0;
        this.sprite(group, length * .18, deckTop + 18 + index * 5, -width * .39, 12, tint, .75);
        // Engine assembly: layered luminous plasma throats animate gently with their sprites.
        const engineCount = role === 'Tender' ? 4 : role === 'Lance' ? 3 : 2;
        const plasma = new THREE.MeshBasicMaterial({
            color: role === 'Lance' ? 0xffab75 : tint,
            transparent: true, opacity: .24, depthWrite: false, side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
        });
        const flameGeometry = new THREE.CylinderGeometry(.16, 2.8, 18, 12, 1, true);
        for (let i = 0; i < engineCount; i++) {
            const z = (i - (engineCount - 1) / 2) * Math.min(width * .28, 12);
            const rear = -length * .45;
            this.cylinder(group, 5.1, 6.0, 11, steel, rear, deckTop - 8.5, z);
            const glow = new THREE.Mesh(new THREE.TorusGeometry(4.3, .65, 10, 44), neon);
            glow.rotation.y = Math.PI / 2;
            glow.position.set(rear - 6.0, deckTop - 8.5, z);
            group.add(glow);
            const iris = new THREE.Mesh(new THREE.CircleGeometry(3.5, 44), lightMat(role === 'Lance' ? 0xffb36f : tint, 3.1));
            iris.rotation.y = -Math.PI / 2;
            iris.position.set(rear - 6.35, deckTop - 8.5, z);
            group.add(iris);
            this.sprite(group, rear - 7.8, deckTop - 8.5, z, 21, tint, .95);
            const jet = this.sprite(group, rear - 18, deckTop - 8.5, z, 30, role === 'Lance' ? 0xff8c5e : tint, .28);
            jet.scale.set(40, 17, 1);
            this.engineLights.push(jet);
            const flame = new THREE.Mesh(flameGeometry, plasma);
            flame.rotation.z = Math.PI / 2;
            flame.position.set(rear - 15.1, deckTop - 8.5, z);
            group.add(flame);
            this.engineFlames.push(flame);
        }
        // Small identity plaques, readable from camera approach.
        this.addWorldLabel(group, `${String(index + 1).padStart(2, '0')}  /  ${role.toUpperCase()}`, -length * .1, deckTop + 8.2, role === 'Picket' ? -width * .68 : width * .65, tint, 12.4);
    }
    addWorldLabel(parent, label, x, y, z, color, width) {
        const canvas = document.createElement('canvas');
        canvas.width = 1024;
        canvas.height = 166;
        const c = canvas.getContext('2d');
        c.clearRect(0, 0, canvas.width, canvas.height);
        c.fillStyle = 'rgba(4,16,32,.72)';
        c.fillRect(7, 7, 1010, 152);
        c.strokeStyle = '#' + new THREE.Color(color).getHexString();
        c.lineWidth = 8;
        c.strokeRect(7, 7, 1010, 152);
        c.font = '700 73px monospace';
        c.fillStyle = '#e5f7ff';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText(label, 512, 83);
        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: .88 }));
        spr.position.set(x, y, z);
        spr.scale.set(width, width * .163, 1);
        parent.add(spr);
    }
    buildDecks() {
        const base = material(0x304354, .82, .39);
        const detail = material(0xb4d3df, .79, .42);
        detail.map = this.surfaceTexture;
        const steel = material(0x101c2b, .8, .32);
        const caution = lightMat(0xffbd73, 1.12);
        const seam = material(0x142c3d, .7, .41);
        for (const deck of DECKS) {
            const g = new THREE.Group();
            g.position.set(deck.x, 0, deck.z);
            this.root.add(g);
            const neon = lightMat(COLORS[deck.ship], deck.kind === 'bridge' ? 1.65 : 1.18);
            const main = deck.kind === 'bridge' ? material(0x2c4e5e, .66, .35) : base;
            this.box(g, deck.length, .56, deck.width, main, 0, deck.top - .28, 0);
            this.box(g, deck.length * .96, .84, deck.width * .83, steel, 0, deck.top - .9, 0);
            this.box(g, deck.length * .98, .12, deck.width * .64, detail, 0, deck.top + .09, 0);
            for (const side of [-1, 1]) {
                this.box(g, deck.length, .16, .18, neon, 0, deck.top + .08, side * (deck.width / 2 - .12));
                this.box(g, deck.length, .12, .36, steel, 0, deck.top - .55, side * deck.width / 2);
            }
            const seams = [];
            const amberPips = [];
            const luminousPips = [];
            const rivets = [];
            for (let xi = -deck.length / 2 + 1.5; xi <= deck.length / 2 - 1; xi += 3.0) {
                seams.push([xi, deck.top + .169, 0]);
                for (const side of [-1, 1]) {
                    (Math.round(xi) % 4 === 0 ? amberPips : luminousPips).push([xi, deck.top + .198, side * (deck.width * .35)]);
                    rivets.push([xi, deck.top + .19, side * (deck.width * .26)]);
                }
            }
            this.boxBatch(g, .06, .021, deck.width * .80, seam, seams);
            this.boxBatch(g, .7, .025, .09, caution, amberPips);
            this.boxBatch(g, .7, .025, .09, neon, luminousPips);
            this.boxBatch(g, .085, .025, .085, steel, rivets);
            // Repeated chevrons are one instanced draw call per deck, not individual meshes.
            const chevrons = [];
            for (let px = -deck.length / 2 + 5; px < deck.length / 2 - 2; px += 9) {
                for (const side of [-1, 1])
                    chevrons.push([px + .2, deck.top + .17, side * .70, side * .57]);
            }
            this.boxBatchRotated(g, 1.15, .025, .14, neon, chevrons);
            if (deck.kind === 'salvage' || deck.kind === 'engine') {
                // Suspension members produce readable structure when viewed from below.
                for (const side of [-1, 1]) {
                    this.box(g, deck.length * .88, .28, .42, steel, 0, deck.top - 2.0, side * (deck.width * .35));
                    for (let i = 0; i < 4; i++) {
                        const p = -deck.length * .36 + i * deck.length * .24;
                        const strut = this.box(g, .25, 1.8, .33, detail, p, deck.top - 1.15, side * deck.width * .34);
                        strut.rotation.z = i % 2 ? -.32 : .32;
                    }
                }
            }
            if (deck.kind === 'bridge')
                this.buildBridgeRailings(g, deck, neon, steel);
            if (deck.kind === 'overlook') {
                for (const side of [-1, 1]) {
                    const railZ = side * deck.width / 2;
                    this.box(g, deck.length * .8, .14, .2, neon, -2, deck.top + 1.15, railZ);
                    const railingPosts = [];
                    for (let i = 0; i < 9; i++)
                        railingPosts.push([-deck.length * .35 + i * 3.3, deck.top + .55, railZ]);
                    this.boxBatch(g, .16, 1.13, .16, steel, railingPosts);
                }
            }
        }
    }
    buildBridgeRailings(g, deck, neon, metal) {
        for (const side of [-1, 1]) {
            const z = side * (deck.width / 2 - .17);
            this.box(g, deck.length, .14, .14, neon, 0, deck.top + 1.18, z);
            this.box(g, deck.length, .10, .12, neon, 0, deck.top + .53, z);
            const posts = [];
            for (let i = 0; i <= 11; i++)
                posts.push([-deck.length / 2 + i * deck.length / 11, deck.top + .56, z]);
            this.boxBatch(g, .21, 1.16, .23, metal, posts);
        }
    }
    buildCausewayThroat() {
        const hullRed = material(0x49303e, .9, .24);
        const hullGreen = material(0x2c4847, .91, .27);
        const dark = material(0x121f2e, .79, .36);
        const cross = material(0x647b8d, .65, .48);
        const configs = [
            { z: -21.5, side: -1, color: C.scarlet, shell: hullRed },
            { z: 21.5, side: 1, color: C.verdant, shell: hullGreen },
        ];
        for (const conf of configs) {
            const g = new THREE.Group();
            g.position.set(218, 0, conf.z);
            this.root.add(g);
            this.motion.push(g);
            // The two animated walls are parts of Lance and Tender; not extra craft.
            this.box(g, 72, 30, 17, conf.shell, 0, -1.0, 0);
            this.box(g, 78, 5.2, 20, dark, 0, 13.2, 0);
            this.box(g, 70, 5.8, 21, dark, 0, -18.8, 0);
            this.box(g, 79, .20, .35, lightMat(conf.color, 3.0), 0, 15.9, -conf.side * 8.4);
            this.box(g, 78, .22, .31, lightMat(conf.color, 1.8), 0, -14.3, -conf.side * 8.4);
            // The wall segments move as one hull; internal repeaters remain instanced in local space.
            const railsBright = [];
            const railsDim = [];
            const ribs = [];
            const brightRibs = [];
            for (let i = 0; i < 14; i++) {
                const x = -32 + i * 5;
                (i % 3 === 0 ? brightRibs : ribs).push([x, -1, -conf.side * 7.8]);
                (i % 4 === 0 ? railsBright : railsDim).push([x, 0, -conf.side * 9.1]);
            }
            this.boxBatch(g, 1.2, 28, 2.5, dark, ribs);
            this.boxBatch(g, 1.2, 28, 2.5, cross, brightRibs);
            this.boxBatch(g, .32, 21, .25, lightMat(conf.color, 2.2), railsBright);
            this.boxBatch(g, .32, 21, .25, lightMat(conf.color, .65), railsDim);
            for (let i = 0; i < 4; i++) {
                this.cylinder(g, 1.4, 1.4, 28, dark, -28 + i * 19, 5 + i % 2 * 4, conf.side * 6, 0);
                this.sprite(g, -28 + i * 19, 13 + i % 2 * 4, -conf.side * 8, 8, conf.color, .6);
            }
            this.addWorldLabel(g, conf.side < 0 ? 'LANCE // HULL SHIFT' : 'TENDER // HULL SHIFT', 4, 19, -conf.side * 8, conf.color, 14);
        }
        // Suspended links, negative-space trestle, and an optical targeting frame.
        for (let i = 0; i < 6; i++) {
            const x = 206 + i * 5.4;
            const t = new THREE.Group();
            t.position.set(x, 5.2, 0);
            this.root.add(t);
            for (const side of [-1, 1]) {
                const post = this.box(t, .42, 9.5, .44, dark, 0, 5, side * 4.9);
                post.rotation.z = side * .15;
                const brace = this.box(t, .27, 13.0, .32, material(0x65869b, .55, .44), .2, 7.5, side * 2.8);
                brace.rotation.x = side * .22;
            }
            this.box(t, .54, .22, 10.8, lightMat(i === 2 ? C.gold : C.energy, 1.3), 0, 10.6, 0);
        }
        // The boost is legible before the gap.
        const gate = new THREE.Group();
        gate.position.set(191, 7.7, 0);
        this.root.add(gate);
        const a = new THREE.Mesh(new THREE.TorusGeometry(5.8, .22, 10, 64, Math.PI), lightMat(C.energy, 2.5));
        a.rotation.y = Math.PI / 2;
        a.rotation.z = Math.PI / 2;
        gate.add(a);
        this.sprite(gate, -2, -1.8, 0, 18, C.energy, .27);
        this.addWorldLabel(gate, 'E  /  MAGNETIC IMPULSE', -1.2, 3.3, 0, C.energy, 15);
    }
    buildDebris() {
        const count = 190;
        const geo = new THREE.TetrahedronGeometry(1, 0);
        const mat = material(0x667989, .76, .44);
        const inst = new THREE.InstancedMesh(geo, mat, count);
        const dummy = new THREE.Object3D();
        for (let i = 0; i < count; i++) {
            const x = this.rand(-58, 375);
            const z = (this.rng() > .5 ? 1 : -1) * this.rand(23, 170);
            const y = this.rand(-50, 72);
            dummy.position.set(x, y, z);
            dummy.rotation.set(this.rand(0, 6), this.rand(0, 6), this.rand(0, 6));
            dummy.scale.set(this.rand(.42, 3.4), this.rand(.4, 2.2), this.rand(.5, 2.5));
            dummy.updateMatrix();
            inst.setMatrixAt(i, dummy.matrix);
        }
        inst.instanceMatrix.needsUpdate = true;
        this.root.add(inst);
        // Larger broken panels cast recognizable parallax silhouettes.
        for (let i = 0; i < 26; i++) {
            const g = new THREE.Group();
            g.position.set(this.rand(-50, 380), this.rand(-36, 24), (this.rng() > .5 ? 1 : -1) * this.rand(28, 112));
            g.rotation.set(this.rand(-.7, .7), this.rand(-.5, .5), this.rand(-.7, .7));
            const w = this.rand(3, 10), d = this.rand(1.3, 4);
            this.box(g, w, .55, d, i % 2 ? mat : material(0x405e6c, .7, .38));
            this.box(g, w * .6, .08, .12, lightMat(i % 2 ? C.cyan : C.gold, .52), 0, .32, d * .22);
            this.root.add(g);
            if (i < 12)
                this.particles.push({ mesh: g, phase: this.rng() * 6.3, rate: this.rand(.2, .6), baseY: g.position.y });
        }
        // Broken navigation bands trace distant intended paths but do not pretend to be collision.
        for (let i = 0; i < 8; i++) {
            const x = this.rand(-30, 360), z = (this.rng() > .5 ? 1 : -1) * this.rand(50, 135);
            const points = [];
            for (let j = 0; j < 10; j++)
                points.push(new THREE.Vector3(x + j * 2.8, -8 + Math.sin(j * .55 + i) * 2.4, z + j * .6));
            this.line(this.root, points, i % 2 ? C.cyan : C.gold, .19);
        }
    }
    buildCheckpointBeacons() {
        CHECKPOINTS.forEach((cp, i) => {
            const g = new THREE.Group();
            g.position.set(cp.x, cp.y, cp.z - (i === 3 ? 4.2 : 4.9));
            this.root.add(g);
            const core = new THREE.Mesh(new THREE.IcosahedronGeometry(.37, 1), lightMat(i === 3 ? C.gold : C.cyan, 1.6));
            core.position.y = 1.45;
            g.add(core);
            const ring = new THREE.Mesh(new THREE.TorusGeometry(.83, .06, 6, 36), lightMat(C.cyan, 1.3));
            ring.position.y = 1.45;
            ring.rotation.y = Math.PI / 2;
            g.add(ring);
            this.cylinder(g, .65, .72, 1.35, material(0x243443, .78, .36), 0, .55, 0, 0);
            this.box(g, 1.35, .12, 1.25, lightMat(i === 3 ? C.gold : C.cyan, .7), 0, .92, 0);
            this.sprite(g, 0, 1.45, 0, 6, i === 3 ? C.gold : C.cyan, .36);
            this.checkpoints.push({ ring, core });
        });
    }
    buildFinish() {
        const g = new THREE.Group();
        g.position.set(352, 8.2, 0);
        this.root.add(g);
        const metal = material(0x62788c, .7, .32);
        const cyan = lightMat(0xc5f6ff, 2.1);
        const verdant = lightMat(C.verdant, 2.1);
        for (const side of [-1, 1]) {
            const z = side * 7.6;
            this.box(g, .7, 6.7, .9, metal, 0, 3.2, z);
            this.box(g, 3.5, .20, 3.0, verdant, 0, 6.5, z);
        }
        const ring = new THREE.Mesh(new THREE.TorusGeometry(6.7, .32, 12, 80, Math.PI), cyan);
        ring.rotation.z = Math.PI / 2;
        ring.position.set(0, 7.4, 0);
        g.add(ring);
        this.sprite(g, 0, 6.5, 0, 30, C.energy, .28);
        this.addWorldLabel(g, 'THE FLEET IS STILL HERE', -1.9, 10.1, 0, C.verdant, 21);
        // Final terrace and foreground horizon rails.
        for (let i = 0; i < 5; i++) {
            const z = (i - 2) * 4;
            this.box(g, 1.8, 1.2, 1.8, metal, 7.5, .65, z);
            this.box(g, 2.1, .22, 2.1, cyan, 7.5, 1.3, z);
        }
    }
    /** Large-scale art direction: a fortress, a spear and a repair ark. All off the playable deck. */
    buildSignatureStructures() {
        const ships = [
            { role: 'Picket', x: 5, length: 121, width: 35, top: -1.2 },
            { role: 'Lance', x: 140, length: 149, width: 46, top: 1.45 },
            { role: 'Tender', x: 283, length: 163, width: 54, top: 4.75 },
        ];
        const armor = material(0x152333, .72, .52);
        const chamfer = material(0x60798b, .76, .37);
        armor.bumpMap = this.hullWearTexture;
        armor.bumpScale = .055;
        chamfer.bumpMap = this.hullWearTexture;
        chamfer.bumpScale = .036;
        const voidMetal = material(0x07121e, .87, .3);
        for (const ship of ships) {
            const g = new THREE.Group();
            g.position.x = ship.x;
            this.root.add(g);
            const accent = COLORS[ship.role];
            const light = lightMat(accent, 2.3);
            const dim = lightMat(accent, .62);
            const windows = [];
            const lowerWindows = [];
            for (const side of [-1, 1]) {
                // The broad distant silhouette reads as manufactured, not as a single extruded toy.
                for (let i = 0; i < 9; i++) {
                    const x = -ship.length * .39 + i * ship.length * .093;
                    this.box(g, ship.length * .055, 2.5 + (i % 3) * 1.1, 3.4, i % 4 === 0 ? chamfer : armor, x, ship.top - 4.6 - (i % 3), side * ship.width * .48);
                    if (i % 2 === 0)
                        this.box(g, ship.length * .048, .18, 3.55, dim, x, ship.top - 2.8, side * ship.width * .48);
                }
                for (let i = 0; i < (this.detail === 'full' ? 36 : 19); i++) {
                    const x = -ship.length * .39 + i * ship.length * (this.detail === 'full' ? .022 : .043);
                    windows.push([x, ship.top - 7.1, side * ship.width * .513]);
                    if (i % 3 === 0)
                        lowerWindows.push([x, ship.top - 10.2, side * ship.width * .515]);
                }
                // Long protected keel strakes make the silhouettes credible at orbital scale.
                this.box(g, ship.length * .81, .45, .6, voidMetal, -ship.length * .03, ship.top - 12.6, side * ship.width * .39);
                this.box(g, ship.length * .67, .15, .24, dim, -ship.length * .09, ship.top - 11.1, side * ship.width * .43);
            }
            this.boxBatch(g, .93, .15, .26, light, windows);
            this.boxBatch(g, .45, .12, .20, dim, lowerWindows);
            if (ship.role === 'Picket') {
                // Shield-petals: layered floating bulwarks that frame the safe, narrow spine.
                for (const side of [-1, 1]) {
                    for (let i = 0; i < (this.detail === 'full' ? 5 : 3); i++) {
                        const x = -ship.length * .34 + i * ship.length * .17;
                        const shield = new THREE.Shape();
                        shield.moveTo(-6, -8);
                        shield.lineTo(6.5, -8);
                        shield.lineTo(8.5, 1.1);
                        shield.lineTo(2, 7.7);
                        shield.lineTo(-6.5, 3.3);
                        shield.closePath();
                        const mesh = new THREE.Mesh(new THREE.ExtrudeGeometry(shield, {
                            depth: 1.5, bevelEnabled: true, bevelThickness: .3, bevelSize: .24, bevelSegments: 1,
                        }), i % 2 ? chamfer : armor);
                        mesh.position.set(x, ship.top - 7, side * (ship.width * .58));
                        mesh.rotation.y = side * .16;
                        g.add(mesh);
                        this.box(g, 10.8, .21, .24, light, x + 1, ship.top + 2.0, side * (ship.width * .59));
                    }
                    const arc = new THREE.Mesh(new THREE.TorusGeometry(18, .36, 8, 68, Math.PI * 1.1), dim);
                    arc.rotation.set(0, side * .16, -.18);
                    arc.position.set(-ship.length * .23, ship.top - 7.8, side * ship.width * .66);
                    g.add(arc);
                }
            }
            else if (ship.role === 'Lance') {
                // Charged launch coils and paired long spear-fins, aggressively horizontal.
                const hot = lightMat(0xffbc82, 2.5);
                for (const side of [-1, 1]) {
                    for (let i = 0; i < (this.detail === 'full' ? 5 : 3); i++) {
                        const x = -ship.length * .29 + i * ship.length * .145;
                        const coil = new THREE.Mesh(new THREE.TorusGeometry(5.5, .47, 8, 48), i % 2 ? light : hot);
                        coil.position.set(x, ship.top - 6.2, side * ship.width * .62);
                        coil.rotation.y = side * .16;
                        g.add(coil);
                        const recess = new THREE.Mesh(new THREE.CircleGeometry(3.6, 32), voidMetal);
                        recess.position.set(x, ship.top - 6.2, side * ship.width * .618);
                        g.add(recess);
                    }
                    for (let i = 0; i < 3; i++) {
                        const spear = new THREE.Mesh(new THREE.ConeGeometry(2.4 - i * .4, 27 - i * 4, 5), chamfer);
                        spear.rotation.z = -Math.PI / 2;
                        spear.position.set(ship.length * (.24 - i * .12), ship.top - 2.5, side * (ship.width * (.62 + i * .06)));
                        g.add(spear);
                    }
                }
            }
            else {
                // The Tender is an immense service cathedral: overhead drydock arches and rescue pods.
                for (let i = 0; i < (this.detail === 'full' ? 5 : 3); i++) {
                    const x = -ship.length * .33 + i * ship.length * .165;
                    for (const side of [-1, 1]) {
                        this.box(g, 2.1, 23, 2.3, chamfer, x, ship.top + 5, side * ship.width * .48);
                        this.box(g, .42, 19, .45, dim, x, ship.top + 6.5, side * ship.width * .47);
                        const pod = new THREE.Mesh(new THREE.IcosahedronGeometry(3.4, 1), i % 2 ? armor : chamfer);
                        pod.position.set(x, ship.top - 2.5, side * ship.width * .68);
                        g.add(pod);
                        const halo = new THREE.Mesh(new THREE.TorusGeometry(3.9, .21, 6, 36), light);
                        halo.rotation.x = .2;
                        halo.position.copy(pod.position);
                        g.add(halo);
                    }
                    this.box(g, 2.1, 1.15, ship.width * .94, armor, x, ship.top + 17, 0);
                    this.box(g, .48, .3, ship.width * .83, light, x, ship.top + 17.75, 0);
                }
            }
        }
    }
    /** Landing surfaces stay unmistakable: markers sit *on* collidable decks, never across a void. */
    buildRunwayGuides() {
        const amber = lightMat(0xf3b674, 1.55);
        const dark = material(0x0d1d2d, .62, .50);
        const ghost = material(0x8396a0, .66, .37);
        const guideShape = new THREE.ConeGeometry(.46, 1.65, 4);
        DECKS.forEach((deck, index) => {
            const accent = lightMat(COLORS[deck.ship], 1.5);
            const g = new THREE.Group();
            g.position.set(deck.x, 0, deck.z);
            this.root.add(g);
            const atStart = -deck.length / 2 + 1.40;
            const atEnd = deck.length / 2 - 1.40;
            const startMarkers = [];
            const warningMarkers = [];
            for (const side of [-1, 1]) {
                const z = side * (deck.width * .34);
                for (let strip = 0; strip < 3; strip++) {
                    const offset = strip * .48;
                    if (index > 0)
                        startMarkers.push([atStart + offset, deck.top + .195, z]);
                    if (index < DECKS.length - 1)
                        warningMarkers.push([atEnd - offset, deck.top + .195, z]);
                }
                // Low inset pilot lamps are at the edge only, clear of the center traversal lane.
                if (index > 0) {
                    const tower = new THREE.Mesh(guideShape, ghost);
                    tower.position.set(atStart, deck.top + .85, side * (deck.width / 2 - .65));
                    tower.rotation.y = Math.PI / 4;
                    g.add(tower);
                    this.box(g, .4, .12, .4, accent, atStart, deck.top + 1.73, side * (deck.width / 2 - .65));
                }
            }
            this.boxBatch(g, .18, .028, 1.34, accent, startMarkers);
            this.boxBatch(g, .18, .028, 1.34, amber, warningMarkers);
            // Strongly outlined warning stripes, never a false bridge over a non-solid gap.
            if (index < DECKS.length - 1)
                this.box(g, .15, .028, deck.width * .68, dark, atEnd - 2.04, deck.top + .196, 0);
        });
    }
    /** Capital-scale remains in the parallax planes; fragments are art, not collision or obstacles. */
    buildDistantGraveyard() {
        const n = this.detail === 'full' ? 44 : 18;
        const geo = new THREE.BoxGeometry(1, 1, 1);
        const steel = material(0x294456, .71, .38);
        steel.bumpMap = this.hullWearTexture;
        steel.bumpScale = .035;
        const shards = new THREE.InstancedMesh(geo, steel, n);
        const dummy = new THREE.Object3D();
        for (let i = 0; i < n; i++) {
            const x = this.rand(-250, 560);
            const side = this.rng() > .5 ? 1 : -1;
            dummy.position.set(x, this.rand(-80, 130), side * this.rand(130, 400));
            dummy.rotation.set(this.rand(-1.4, 1.4), this.rand(-1.4, 1.4), this.rand(-1.4, 1.4));
            dummy.scale.set(this.rand(13, 49), this.rand(.48, 3.7), this.rand(1.5, 9));
            dummy.updateMatrix();
            shards.setMatrixAt(i, dummy.matrix);
        }
        shards.instanceMatrix.needsUpdate = true;
        shards.computeBoundingSphere();
        this.root.add(shards);
        // A trio of quiet distant navigation lenses rewards the eventual panoramic reveal.
        const lensGeo = new THREE.TorusGeometry(10, .21, 5, 64);
        const lensMat = new THREE.MeshBasicMaterial({ color: C.energy, transparent: true, opacity: .14, depthWrite: false });
        for (let i = 0; i < 3; i++) {
            const lens = new THREE.Mesh(lensGeo, lensMat);
            lens.position.set(90 + i * 116, 45 + i * 22, -180 - i * 43);
            lens.rotation.set(.14, .25 + .07 * i, -.18);
            this.root.add(lens);
        }
    }
    /** Preallocated and bounded contact effects. Never spawns persistent per-event objects. */
    buildImpactPool() {
        const poolSize = this.detail === 'full' ? 3 : 2;
        const sparkCount = this.detail === 'full' ? 26 : 12;
        for (let i = 0; i < poolSize; i++) {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(.9, .045, 5, 40), new THREE.MeshBasicMaterial({
                color: C.energy, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending,
            }));
            ring.rotation.x = Math.PI / 2;
            ring.visible = false;
            const positions = new Float32Array(sparkCount * 3);
            const geo = new THREE.BufferGeometry();
            geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            const sparks = new THREE.Points(geo, new THREE.PointsMaterial({
                color: C.gold, size: .19, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending,
            }));
            sparks.frustumCulled = false; // Their pooled positions move after the original bounds are created.
            sparks.visible = false;
            this.root.add(ring, sparks);
            this.impactPool.push({ ring, sparks, positions, born: -100, x: 0, y: 0, z: 0, strength: 0 });
        }
    }
    triggerImpact(kind, x, y, z) {
        // Reuse the oldest pool entry; frequent landings cannot inflate the scene graph.
        const fx = this.impactPool.reduce((oldest, candidate) => candidate.born < oldest.born ? candidate : oldest);
        fx.born = this.clock;
        fx.x = x;
        fx.y = y;
        fx.z = z;
        fx.strength = kind === 'recovery' ? 1.5 : kind === 'checkpoint' ? 1.35 : kind === 'land' ? 1 : .55;
        const color = kind === 'checkpoint' ? C.verdant : kind === 'recovery' ? C.gold : C.energy;
        fx.ring.material.color.setHex(color);
        fx.sparks.material.color.setHex(color);
    }
    activateCheckpoint(index) {
        this.currentCheckpoint = index;
        this.checkpoints.forEach(({ ring, core }, i) => {
            const active = i <= index;
            ring.material.emissiveIntensity = active ? 3.2 : 1.15;
            core.scale.setScalar(active ? 1.18 : .82);
        });
    }
    buildBoostFX() {
        for (let i = 0; i < 5; i++) {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(1.2 + i * .47, .065, 5, 28), new THREE.MeshBasicMaterial({ color: i % 2 ? C.energy : C.gold, transparent: true, opacity: .6 - i * .08, blending: THREE.AdditiveBlending, depthWrite: false }));
            ring.rotation.y = Math.PI / 2;
            ring.position.x = -i * 1.3;
            this.boostFX.add(ring);
            this.energy.push(ring);
        }
        this.boostFX.visible = false;
    }
    triggerBoost(x, y, z) {
        this.clearBoostFX();
        this.boostStart = -1; // set relative to next deterministic update time
        this.boostFX.position.set(x, y + 1.2, z);
        this.boostFX.visible = true;
    }
    /** Fully reset ephemeral visuals as well as deterministic animation phases. */
    reset() {
        this.clearBoostFX();
        this.boostStart = -100;
        this.clock = 0;
        this.boostFX.position.set(0, 0, 0);
        this.boostFX.scale.set(1, 1, 1);
        this.impactPool.forEach(fx => {
            fx.born = -100;
            fx.ring.visible = false;
            fx.sparks.visible = false;
            fx.ring.material.opacity = 0;
            fx.sparks.material.opacity = 0;
        });
        this.activateCheckpoint(0);
        this.update(0, false, 0);
    }
    clearBoostFX() {
        this.boostFX.visible = false;
        this.boostFX.scale.set(1, 1, 1);
    }
    update(time, reducedMotion, playerX) {
        this.clock = time;
        const t = reducedMotion ? 0 : time;
        // The opposed structures open and close slowly around a permanently safe bridge.
        this.motion.forEach((g, i) => {
            const side = i === 0 ? -1 : 1;
            g.position.z = side * (21.5 + 2.5 * Math.sin(t * .57 + .8 + i * .31));
            g.position.y = reducedMotion ? 0 : Math.sin(t * .41 + i * 1.7) * .55;
            g.rotation.x = reducedMotion ? 0 : side * .009 * Math.sin(t * .32);
        });
        this.planet.rotation.y = reducedMotion ? 0 : t * .0038;
        this.planetClouds.rotation.y = this.planet.rotation.y;
        this.checkpoints.forEach(({ core, ring }, i) => {
            core.rotation.y = t * .85 + i;
            ring.rotation.z = reducedMotion ? 0 : Math.sin(t * 1.1 + i) * .09;
        });
        this.particles.forEach(p => { p.mesh.position.y = p.baseY + (reducedMotion ? 0 : Math.sin(t * p.rate + p.phase) * .88); });
        this.engineLights.forEach((jet, i) => {
            const pulse = reducedMotion ? 1 : 1 + Math.sin(t * 2.1 + i * .81) * .09;
            jet.scale.set(40 * pulse, 17 * pulse, 1);
            jet.material.opacity = reducedMotion ? .25 : .27 + Math.sin(t * 1.7 + i) * .035;
            const flame = this.engineFlames[i];
            if (flame)
                flame.scale.y = reducedMotion ? 1 : .93 + Math.sin(t * 1.8 + i * .67) * .12;
        });
        for (const fx of this.impactPool) {
            const age = time - fx.born;
            const active = !reducedMotion && age >= 0 && age <= .62;
            fx.ring.visible = fx.sparks.visible = active;
            if (!active)
                continue;
            const fade = Math.pow(1 - age / .62, 1.65);
            const spread = 1 + age * 5.2 * fx.strength;
            fx.ring.position.set(fx.x, fx.y + .10, fx.z);
            fx.ring.scale.setScalar(spread);
            fx.ring.material.opacity = fade * .56;
            fx.sparks.material.opacity = fade * .8;
            const pos = fx.positions;
            for (let i = 0; i < pos.length / 3; i++) {
                const angle = i * 2.399963 + fx.born * .37;
                const radial = (i % 7 + 1) / 8 * spread * .78;
                pos[3 * i] = fx.x + Math.cos(angle) * radial;
                pos[3 * i + 1] = fx.y + .1 + Math.sin(i * 4.3) * age * 2.2;
                pos[3 * i + 2] = fx.z + Math.sin(angle) * radial;
            }
            fx.sparks.geometry.getAttribute('position').needsUpdate = true;
        }
        if (this.boostStart === -1)
            this.boostStart = t;
        const age = t - this.boostStart;
        const visible = !reducedMotion && age < .75;
        const wasVisible = this.boostFX.visible;
        this.boostFX.visible = visible;
        if (visible) {
            const f = 1 + age * 6;
            this.boostFX.scale.set(f, f, f);
            this.boostFX.position.x = playerX - age * 5;
        }
        else if (wasVisible) {
            this.clearBoostFX();
        }
    }
    dispose() {
        this.clearBoostFX();
        const geometries = new Set();
        const materials = new Set();
        const textures = new Set();
        this.scene.traverse(obj => {
            const o = obj;
            if (o.geometry)
                geometries.add(o.geometry);
            if (o.material) {
                const arr = Array.isArray(o.material) ? o.material : [o.material];
                for (const mat of arr) {
                    materials.add(mat);
                    for (const val of Object.values(mat))
                        if (val instanceof THREE.Texture)
                            textures.add(val);
                }
            }
        });
        for (const g of geometries)
            g.dispose();
        for (const m of materials)
            m.dispose();
        for (const t of textures)
            t.dispose();
        this.boxGeometries.clear();
        this.glowTexture.dispose();
        this.surfaceTexture.dispose();
        this.hullWearTexture.dispose();
        this.environmentTexture.dispose();
        this.root.clear();
        this.scene.clear();
    }
}
export function buildFleetWorld(detail = 'full') { return new FleetWorld(detail); }
