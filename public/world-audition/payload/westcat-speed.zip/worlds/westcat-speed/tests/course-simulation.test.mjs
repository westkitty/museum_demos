import test from 'node:test';
import assert from 'node:assert/strict';
import {createState,step,FIXED_DT} from '../.test-build/physics.js';
import {GAPS,CHECKPOINTS,COURSE_LENGTH} from '../.test-build/track.js';
// A deterministic assist pilot verifies that there is a possible full start-to-finish route.
test('start-to-finish run is reachable with jump + boost and four grounded checkpoints',()=>{
 const s=createState(),ev=[];let steps=0;
 while(!s.finished&&steps<Math.round(600/FIXED_DT)){
   const nearbyGap=GAPS.some(g=>s.x>g.start-54&&s.x<g.end);
   const jump=nearbyGap && s.mode==='ground' && GAPS.some(g=>s.x>g.start-54&&s.x<g.start-43);
   // Boost intentionally rationed: 4 seconds on, 10 seconds off.
   const boost=(steps*FIXED_DT)%14<4;
   step(s,{right:true,left:false,jumpPressed:jump,boost},FIXED_DT,e=>ev.push(e));
   steps++;
 }
 assert.ok(s.finished,`route not finished: ${JSON.stringify({x:s.x,y:s.y,mode:s.mode,recoveries:s.recoveries,elapsed:s.elapsed})}`);
 assert.ok(s.elapsed>=240 && s.elapsed<=300,`route pace outside 4–5 minute target: ${s.elapsed}`);
 assert.ok(s.distance>=COURSE_LENGTH-4);
 assert.equal(s.checkpointIndex,CHECKPOINTS.length-1);
 assert.ok(ev.filter(e=>e.type==='loop').length>=2);
 assert.ok(ev.filter(e=>e.type==='rail').length>=2);
 assert.ok(ev.some(e=>e.type==='finish'));
 console.log('Full route:', {simulatedSeconds:(steps*FIXED_DT).toFixed(1),timerSeconds:s.elapsed.toFixed(1),recoveries:s.recoveries});
});
