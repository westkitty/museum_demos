import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const text=(path)=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');

test('shipped runtime source contains no network-dependent asset URLs or fetch calls',()=>{
  const entries=['index.html','src/main.ts','src/art.ts','src/premium.ts','src/style.css','src/input.ts','src/course.ts','src/simulation.ts'];
  for(const path of entries){
    const value=text(path);
    assert.doesNotMatch(value,/https?:\/\/|\bfetch\s*\(|@import\s+url|<img\s|<audio\s|<video\s/i,`${path} should not fetch runtime assets`);
  }
  assert.match(text('package.json'),/"three"\s*:\s*"0\.185\.1"/);
});

test('DOM element IDs required by the game controller all exist in the HTML',()=>{
  const ids=new Set([...text('index.html').matchAll(/\bid="([a-z0-9-]+)"/g)].map(m=>m[1]));
  const required=[...text('src/main.ts').matchAll(/\$\s*(?:<[^>]*>)?\s*\(\s*'([a-z0-9-]+)'\s*\)/g)].map(m=>m[1]);
  assert.ok(required.length>20,`expected substantial UI wiring, found ${required.length} ids`);
  for(const id of required)assert.ok(ids.has(id),`missing DOM element #${id}`);
  const touch=text('index.html');
  for(const value of ['forward','back','left','right','jump'])assert.match(touch,new RegExp(`data-hold="${value}"`));
  for(const value of ['water','glide'])assert.match(touch,new RegExp(`data-action="${value}"`));
});
