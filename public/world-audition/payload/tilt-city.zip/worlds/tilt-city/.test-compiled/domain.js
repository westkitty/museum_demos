export const GESTURES = [
    { id: 'forward', gesture: 'Tip forward', command: 'Next track', color: 0x55f0e8, hex: '#55f0e8', subtitle: 'THE NEXT LINE', rotationSign: 1, symbol: '↟' },
    { id: 'back', gesture: 'Tip back', command: 'Previous track', color: 0xce93ff, hex: '#ce93ff', subtitle: 'AFTERIMAGE DISTRICT', rotationSign: -1, symbol: '↡' },
    { id: 'right', gesture: 'Roll right', command: 'Volume up', color: 0xffc56d, hex: '#ffc56d', subtitle: 'THE GAIN ENGINE', rotationSign: 1, symbol: '↻' },
    { id: 'left', gesture: 'Roll left', command: 'Volume down', color: 0x9fffba, hex: '#9fffba', subtitle: 'QUIET HORIZON', rotationSign: -1, symbol: '↺' }
];
export const GATE_CENTERS = [30, 70, 110, 150];
export const CHECKPOINT_X = [20, 60, 100, 140];
export const FINISH_X = 170;
export const LANE_HALF_WIDTH = 4.1;
export const ROTATION_DURATION = 1.35;
export const MAX_SIM_DT = 1 / 60;
export const COURSE_FLOORS = [
    [-15, 24.05], [35.95, 49.0], [52.0, 64.05], [75.95, 89.0],
    [92.0, 104.05], [115.95, 129.0], [132.0, 144.05], [155.95, 179.5]
];
const floor = (minX, maxX, id) => ({ minX, maxX, minZ: -LANE_HALF_WIDTH, maxZ: LANE_HALF_WIDTH, top: 0, id });
export const STATIC_SURFACES = COURSE_FLOORS.map(([lo, hi], i) => floor(lo, hi, `island-${i}`));
export class LevelMachine {
    unlocked = [false, false, false, false];
    angles = [0, 0, 0, 0];
    moving = -1;
    elapsed = 0;
    checkpoint = 0;
    completed = false;
    revisions = 0;
    get activeGate() { return this.unlocked.findIndex(v => !v); }
    get complete() { return this.completed; }
    get checkpointIndex() { return this.checkpoint; }
    get checkpointX() { return this.checkpoint === 0 ? -8 : CHECKPOINT_X[this.checkpoint - 1]; }
    get unlockedCount() { return this.unlocked.filter(Boolean).length; }
    get movingIndex() { return this.moving; }
    get revision() { return this.revisions; }
    get states() {
        return GESTURES.map((g, i) => ({ index: i, action: g.id, angle: this.angles[i], unlocked: this.unlocked[i], rotating: this.moving === i }));
    }
    surfaces() {
        const all = [...STATIC_SURFACES];
        for (let i = 0; i < 4; i++)
            if (this.unlocked[i])
                all.push(floor(GATE_CENTERS[i] - 6.02, GATE_CENTERS[i] + 6.02, `bridge-${i}`));
        return all;
    }
    approach(x) {
        const n = this.activeGate;
        if (n >= 0 && Math.abs(x - CHECKPOINT_X[n]) <= 3.7) {
            if (this.checkpoint < n + 1)
                this.checkpoint = n + 1;
            return n;
        }
        return null;
    }
    request(action, x, grounded) {
        if (this.moving !== -1)
            return 'in-motion';
        const n = this.activeGate;
        if (n === -1)
            return 'already-done';
        if (!grounded)
            return 'not-grounded';
        if (Math.abs(x - CHECKPOINT_X[n]) > 3.7)
            return 'too-far';
        if (GESTURES[n].id !== action)
            return 'wrong-gesture';
        this.moving = n;
        this.elapsed = 0;
        this.revisions++;
        return 'started';
    }
    /** Fixed-step deterministic interpolation. Returns gate index when it becomes solid. */
    tick(dt) {
        if (this.moving < 0)
            return null;
        const i = this.moving;
        this.elapsed = Math.min(ROTATION_DURATION, this.elapsed + Math.max(0, dt));
        const t = this.elapsed / ROTATION_DURATION;
        const eased = t * t * (3 - 2 * t);
        this.angles[i] = GESTURES[i].rotationSign * eased * (Math.PI / 2);
        if (t < 1)
            return null;
        this.angles[i] = GESTURES[i].rotationSign * (Math.PI / 2);
        this.unlocked[i] = true;
        this.moving = -1;
        this.revisions++;
        return i;
    }
    reachFinish(x, grounded) {
        if (!this.complete && this.unlocked.every(Boolean) && x >= FINISH_X && grounded) {
            this.completed = true;
            this.revisions++;
            return true;
        }
        return false;
    }
    reset() {
        this.unlocked = [false, false, false, false];
        this.angles = [0, 0, 0, 0];
        this.moving = -1;
        this.elapsed = 0;
        this.checkpoint = 0;
        this.completed = false;
        this.revisions++;
    }
}
