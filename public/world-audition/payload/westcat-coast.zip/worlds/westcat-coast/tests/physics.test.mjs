import test from 'node:test';
import assert from 'node:assert/strict';
import {createPlayer,simulate,resetPlayer,RULES} from '../src/physics.js';
const floor=[{x:0,w:12,top:1,thickness:2}];
const go=(p,frames,input,world=floor)=>{let ev=[];for(let i=0;i<frames;i++)ev.push(...simulate(p,typeof input==='function'?input(i):input,world,1/60));return ev;};
test('player rests on a solid surface without falling through at fixed 60 Hz',()=>{
 const p=createPlayer(2,1);go(p,180,{axis:0,jumpPressed:false,jumpHeld:false});
 assert.ok(p.grounded);assert.ok(Math.abs(p.y-1)<1e-6);
});
test('player accelerates and is capped, decelerating on release',()=>{
 const p=createPlayer(2,1);go(p,25,{axis:1});assert.ok(p.vx>3);assert.ok(p.vx<=RULES.speed);
 const v=p.vx;go(p,10,{axis:0});assert.ok(p.vx<v);
});
test('jump and double-jump consume exactly two air boosts',()=>{
 const p=createPlayer(2,1);assert.ok(go(p,1,{axis:0,jumpPressed:true,jumpHeld:true}).includes('jump'));
 go(p,11,{axis:0,jumpHeld:true});
 assert.ok(go(p,1,{axis:0,jumpPressed:true,jumpHeld:true}).includes('doublejump'));
 assert.ok(!p.doubleAvailable);
 assert.ok(!go(p,1,{axis:0,jumpPressed:true,jumpHeld:true}).includes('doublejump'));
});
test('grounded collision restores double jump',()=>{
 const p=createPlayer(2,1);go(p,1,{axis:0,jumpPressed:true,jumpHeld:false});go(p,15,{axis:0,jumpHeld:false});
 go(p,1,{axis:0,jumpPressed:true,jumpHeld:false});go(p,160,{axis:0,jumpHeld:false});
 assert.equal(p.grounded,true);assert.equal(p.doubleAvailable,true);
});
test('coyote jump succeeds just after leaving a ledge',()=>{
 const p=createPlayer(3,1);const tiny=[{x:0,w:3.2,top:1,thickness:1.0}];
 go(p,13,{axis:1},tiny);assert.equal(p.grounded,false);
 const ev=go(p,1,{axis:1,jumpPressed:true,jumpHeld:true},tiny);
 assert.ok(ev.includes('jump'),`expected coyote jump, got ${ev}`);
});
test('wall contact blocks horizontal penetration and allows kick-off',()=>{
 const solids=[{x:0,w:12,top:1,thickness:1},{x:4,w:1,top:6,thickness:4.5}];
 const p=createPlayer(2,1);go(p,1,{axis:0,jumpPressed:true,jumpHeld:true},solids);
 go(p,12,{axis:1,jumpHeld:true},solids);
 assert.ok(p.x+RULES.playerWidth/2<=4.0001,`wall penetration at x=${p.x}`);
 // Explicit wall-contact state sets a physically valid collision pose.
 resetPlayer(p,4-RULES.playerWidth/2,3.5);p.grounded=false;p.wall=1;p.coyote=0;
 const e=go(p,1,{axis:1,jumpPressed:true,jumpHeld:true},solids);
 assert.ok(e.includes('walljump'));assert.ok(p.vx<0);
});
test('head-on roof collision stops upward motion rather than phasing through',()=>{
 const solids=[...floor,{x:1,w:3,top:4,thickness:.4}];const p=createPlayer(2,1);
 go(p,1,{axis:0,jumpPressed:true,jumpHeld:true},solids);
 go(p,25,{axis:0,jumpHeld:true},solids);
 assert.ok(p.y+RULES.playerHeight<=3.61 || p.y>=4,`intersects solid underside at ${p.y}`);
});
test('reset restores an unambiguous checkpoint state',()=>{
 const p=createPlayer(2,1);p.vx=20;p.vy=-18;p.doubleAvailable=false;p.wall=1;
 resetPlayer(p,42,3);assert.equal(p.x,42);assert.equal(p.y,3);assert.equal(p.vx,0);assert.equal(p.vy,0);assert.equal(p.doubleAvailable,true);
});
test('oversize timestep is rejected instead of tunneling into geometry',()=>{
 assert.throws(()=>simulate(createPlayer(),{axis:1},floor,.6),/bounded/);
});
