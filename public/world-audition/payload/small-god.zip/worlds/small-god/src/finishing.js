import * as THREE from 'three';
import { POINTS } from './rules.js';
const TAU = Math.PI * 2;
const INK = 0x345561;
const LIGHT = 0xffe5b9;
const PALETTE = { strike: 0xffcd78, sweep: 0x89ffe1, ward: 0xd3aaff };
const seed = (initial) => {
    let state = initial >>> 0;
    return () => ((state = Math.imul(state, 1664525) + 1013904223 >>> 0) / 4294967296);
};
/** Carefully placed, gameplay-inert finishing details. All resources are owned by the scene. */
export class LittleGloriesFinishing {
    scene;
    height;
    random = seed(70941);
    temp = new THREE.Object3D();
    activeLight;
    targetGuides;
    fountain;
    fountainArray;
    fountainCount = 30;
    hourHand;
    minuteHand;
    brassBell;
    horizon;
    festival;
    signAftershock;
    hoveringShadow;
    isMobile = false;
    constructor(scene, height) {
        this.scene = scene;
        this.height = height;
        this.horizon = this.createDistantIslets();
        ({ hour: this.hourHand, minute: this.minuteHand, bell: this.brassBell } = this.createBellTower());
        this.createMarketPavilion();
        this.createPlazaMosaic();
        this.createCobbledShoreline();
        this.targetGuides = {
            strike: this.createGuide('strike', POINTS.strike.x, POINTS.strike.z),
            sweep: this.createGuide('sweep', POINTS.windStart.x, POINTS.windStart.z),
            ward: this.createGuide('ward', POINTS.sign.x, POINTS.sign.z),
        };
        this.activeLight = new THREE.PointLight(PALETTE.strike, 1.4, 4.1, 2);
        this.activeLight.castShadow = false;
        this.scene.add(this.activeLight);
        ({ points: this.fountain, positions: this.fountainArray } = this.createFountain());
        this.festival = this.createFestival();
        this.signAftershock = this.createSignAftershock();
        this.hoveringShadow = this.createHandShadow();
    }
    standard(color, roughness = 0.84, metalness = 0) {
        return new THREE.MeshStandardMaterial({ color, roughness, metalness, flatShading: true });
    }
    box(parent, w, h, d, x, y, z, color, castShadow = false) {
        const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), this.standard(color));
        m.position.set(x, y, z);
        m.castShadow = castShadow;
        m.receiveShadow = true;
        parent.add(m);
        return m;
    }
    createDistantIslets() {
        const group = new THREE.Group();
        const total = 12;
        const lower = new THREE.InstancedMesh(new THREE.ConeGeometry(1, 1.6, 7), this.standard(0x547a7b), total);
        const crowns = new THREE.InstancedMesh(new THREE.CylinderGeometry(.83, .98, .18, 7), this.standard(0x91ad91), total);
        lower.castShadow = false;
        crowns.castShadow = false;
        for (let i = 0; i < total; i++) {
            // A deliberate crescent of distant silhouettes, never presented as new playable islands.
            const angle = -2.4 + (i / (total - 1)) * 3.35;
            const radius = 22.5 + (i % 4) * 2.0;
            const x = Math.cos(angle) * radius - 1.5;
            const z = Math.sin(angle) * radius - 10;
            const y = -3.8 + Math.sin(i * 2.2) * 1.9;
            const size = 1.1 + (i % 4) * .33;
            this.temp.rotation.set(0, angle, 0);
            this.temp.position.set(x, y - .90 * size, z);
            this.temp.scale.set(size, size * 1.8, size);
            this.temp.updateMatrix();
            lower.setMatrixAt(i, this.temp.matrix);
            this.temp.position.set(x, y + .11 * size, z);
            this.temp.scale.set(size, size * .75, size);
            this.temp.updateMatrix();
            crowns.setMatrixAt(i, this.temp.matrix);
            const variance = new THREE.Color(i % 3 === 0 ? 0x6e8a85 : 0x557875);
            lower.setColorAt(i, variance);
            crowns.setColorAt(i, new THREE.Color(i % 3 === 0 ? 0xa7b9a0 : 0x8fb09c));
        }
        lower.instanceMatrix.needsUpdate = crowns.instanceMatrix.needsUpdate = true;
        group.add(lower, crowns);
        this.scene.add(group);
        return group;
    }
    createBellTower() {
        const x = 5.75, z = -1.32;
        const tower = new THREE.Group();
        tower.position.set(x, this.height(x, z) + .07, z);
        tower.rotation.y = .18;
        const plinth = new THREE.Mesh(new THREE.CylinderGeometry(.67, .74, .26, 8), this.standard(0x9f9b87));
        plinth.position.y = .13;
        plinth.receiveShadow = true;
        tower.add(plinth);
        const body = new THREE.Mesh(new THREE.CylinderGeometry(.41, .56, 2.06, 8), this.standard(0xf3dfc1));
        body.position.y = 1.22;
        body.castShadow = true;
        body.receiveShadow = true;
        tower.add(body);
        for (const y of [.37, 1.17, 2.1]) {
            const band = new THREE.Mesh(new THREE.CylinderGeometry(.52 + (y < 1 ? .08 : 0), .52, .095, 8), this.standard(0xc8a985));
            band.position.y = y;
            tower.add(band);
        }
        const canopy = new THREE.Mesh(new THREE.CylinderGeometry(.70, .54, .22, 8), this.standard(0x7aa6a0));
        canopy.position.y = 2.37;
        canopy.castShadow = true;
        tower.add(canopy);
        const roof = new THREE.Mesh(new THREE.ConeGeometry(.72, .78, 8), this.standard(0x6b8b8c));
        roof.position.y = 2.88;
        roof.castShadow = true;
        tower.add(roof);
        const roofTrim = new THREE.Mesh(new THREE.TorusGeometry(.55, .034, 6, 40), this.standard(0xeac78c, .35, .23));
        roofTrim.rotation.x = Math.PI / 2;
        roofTrim.position.y = 2.44;
        tower.add(roofTrim);
        const finial = new THREE.Mesh(new THREE.IcosahedronGeometry(.12, 0), this.standard(0xf6d890, .3, .28));
        finial.position.y = 3.29;
        tower.add(finial);
        // Faceted enamel clock, readable from the game's fixed diorama camera.
        const dial = new THREE.Group();
        dial.position.set(0, 1.83, .52);
        dial.rotation.y = .12;
        const clockFace = new THREE.Mesh(new THREE.CircleGeometry(.30, 32), new THREE.MeshBasicMaterial({ color: 0xfff3d6, side: THREE.DoubleSide }));
        clockFace.position.z = .027;
        dial.add(clockFace);
        const bezel = new THREE.Mesh(new THREE.TorusGeometry(.31, .036, 8, 40), this.standard(0xd5a86a, .34, .4));
        bezel.position.z = .045;
        dial.add(bezel);
        const ticks = new THREE.InstancedMesh(new THREE.BoxGeometry(.025, .068, .011), new THREE.MeshBasicMaterial({ color: INK }), 12);
        for (let i = 0; i < 12; i++) {
            const angle = i / 12 * TAU;
            this.temp.position.set(Math.sin(angle) * .243, Math.cos(angle) * .243, .059);
            this.temp.rotation.set(0, 0, -angle);
            this.temp.scale.setScalar(1);
            this.temp.updateMatrix();
            ticks.setMatrixAt(i, this.temp.matrix);
        }
        ticks.instanceMatrix.needsUpdate = true;
        dial.add(ticks);
        const hour = new THREE.Group(), minute = new THREE.Group();
        this.box(hour, .026, .16, .018, 0, .07, .066, 0x44565b);
        this.box(minute, .018, .23, .015, 0, .105, .075, 0xc38956);
        dial.add(hour, minute);
        tower.add(dial);
        for (const side of [-1, 1]) {
            const window = new THREE.Mesh(new THREE.BoxGeometry(.19, .38, .055), new THREE.MeshStandardMaterial({ color: 0xffdca5, emissive: 0xe6a756, emissiveIntensity: .54 }));
            window.position.set(side * .31, 1.01, .35);
            tower.add(window);
        }
        const bell = new THREE.Mesh(new THREE.SphereGeometry(.16, 12, 10), this.standard(0xeec48a, .32, .33));
        bell.position.set(0, 2.42, 0);
        bell.scale.set(1.0, 1.32, .76);
        tower.add(bell);
        // No dynamic lights per window: emissive paint provides the warmth without GPU cost.
        tower.scale.setScalar(.94);
        this.scene.add(tower);
        return { hour, minute, bell };
    }
    createMarketPavilion() {
        const x = -4.45, z = 4.42;
        const group = new THREE.Group();
        group.position.set(x, this.height(x, z), z);
        group.rotation.y = -.4;
        const floor = this.box(group, 1.42, .11, 1.04, 0, .08, 0, 0xa99a79);
        floor.receiveShadow = true;
        for (const dx of [-.57, .57])
            for (const dz of [-.38, .38]) {
                this.box(group, .085, 1.10, .085, dx, .62, dz, 0xdbcbac);
            }
        const awning = new THREE.Mesh(new THREE.ConeGeometry(1.04, .50, 4), this.standard(0xb9a6c1));
        awning.rotation.y = Math.PI / 4;
        awning.scale.set(1, .7, .82);
        awning.position.y = 1.31;
        group.add(awning);
        const counter = this.box(group, 1.14, .12, .42, 0, .55, .08, 0xeccca2);
        counter.castShadow = false;
        const fruits = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.085, 0), this.standard(0xffffff), 16);
        for (let i = 0; i < 16; i++) {
            this.temp.position.set(-.44 + i % 8 * .125, .67 + Math.floor(i / 8) * .12, -.02);
            this.temp.rotation.set(0, i * .4, 0);
            this.temp.scale.setScalar(1);
            this.temp.updateMatrix();
            fruits.setMatrixAt(i, this.temp.matrix);
            fruits.setColorAt(i, new THREE.Color([0xd88373, 0xf0bb75, 0x9cc17c, 0xa9a3d3][i % 4]));
        }
        fruits.instanceMatrix.needsUpdate = true;
        group.add(fruits);
        this.scene.add(group);
    }
    createPlazaMosaic() {
        const x = POINTS.plaza.x, z = POINTS.plaza.z;
        const tiles = new THREE.InstancedMesh(new THREE.BoxGeometry(.095, .02, .24), this.standard(0xffffff), 48);
        tiles.castShadow = false;
        tiles.receiveShadow = true;
        for (let i = 0; i < 48; i++) {
            const a = i * TAU / 48;
            this.temp.position.set(x + Math.cos(a) * 1.31, this.height(x, z) + .188, z + Math.sin(a) * 1.31);
            this.temp.rotation.set(0, -a, 0);
            this.temp.scale.setScalar(1);
            this.temp.updateMatrix();
            tiles.setMatrixAt(i, this.temp.matrix);
            tiles.setColorAt(i, new THREE.Color(i % 4 === 0 ? 0xb6a2a4 : i % 2 === 0 ? 0xc59e7c : 0xf8e0b8));
        }
        tiles.instanceMatrix.needsUpdate = true;
        this.scene.add(tiles);
        // Four subtle cross-quadrant markers emphasize the square's true sweep target.
        const compass = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.09, 0), this.standard(0xe8be87, .43, .14), 4);
        for (let i = 0; i < 4; i++) {
            const a = i * TAU / 4;
            this.temp.position.set(x + Math.cos(a) * 1.02, this.height(x, z) + .197, z + Math.sin(a) * 1.02);
            this.temp.rotation.set(0, a, 0);
            this.temp.scale.set(.52, .16, 1.2);
            this.temp.updateMatrix();
            compass.setMatrixAt(i, this.temp.matrix);
        }
        compass.instanceMatrix.needsUpdate = true;
        this.scene.add(compass);
    }
    createCobbledShoreline() {
        // A single draw call per material makes a raised embroidered shoreline.
        const stones = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(.11, 0), this.standard(0xd7c3aa, .96), 144);
        stones.castShadow = false;
        stones.receiveShadow = true;
        for (let i = 0; i < 144; i++) {
            const angle = i / 144 * TAU;
            const radius = 7.25 + Math.sin(angle * 11) * .1 + this.random() * .18;
            const x = Math.cos(angle) * radius, z = Math.sin(angle) * radius;
            this.temp.position.set(x, this.height(x, z) + .025, z);
            this.temp.rotation.set(0, angle, .20);
            this.temp.scale.set(.7 + this.random() * .5, .18 + this.random() * .32, .58 + this.random() * .6);
            this.temp.updateMatrix();
            stones.setMatrixAt(i, this.temp.matrix);
            stones.setColorAt(i, new THREE.Color(i % 5 === 0 ? 0xa8b9a4 : i % 3 === 0 ? 0xe6d6b8 : 0xc4ae93));
        }
        stones.instanceMatrix.needsUpdate = true;
        this.scene.add(stones);
    }
    createGuide(gesture, x, z) {
        const group = new THREE.Group();
        group.position.set(x, this.height(x, z) + .13, z);
        const color = PALETTE[gesture];
        const radius = gesture === 'ward' ? 1.18 : .79;
        const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: .72,
            depthWrite: false, blending: THREE.AdditiveBlending });
        const outer = new THREE.Mesh(new THREE.TorusGeometry(radius, .022, 5, 80), material);
        outer.rotation.x = Math.PI / 2;
        outer.position.y = .07;
        group.add(outer);
        const glyphCount = gesture === 'strike' ? 8 : gesture === 'sweep' ? 12 : 9;
        const glyphs = new THREE.InstancedMesh(gesture === 'ward' ? new THREE.IcosahedronGeometry(.08, 0) : new THREE.BoxGeometry(.055, .027, .19), material, glyphCount);
        glyphs.frustumCulled = false;
        for (let i = 0; i < glyphCount; i++) {
            const a = i / glyphCount * TAU;
            const r = radius + .15;
            this.temp.position.set(Math.cos(a) * r, .12, Math.sin(a) * r);
            this.temp.rotation.set(0, -a, 0);
            this.temp.scale.set(1, 1, 1);
            this.temp.updateMatrix();
            glyphs.setMatrixAt(i, this.temp.matrix);
        }
        glyphs.instanceMatrix.needsUpdate = true;
        group.add(glyphs);
        this.scene.add(group);
        if (gesture === 'sweep')
            this.createSweepRoute();
        return group;
    }
    createSweepRoute() {
        const dots = new THREE.InstancedMesh(new THREE.SphereGeometry(.045, 7, 6), new THREE.MeshBasicMaterial({ color: 0x77eacb, transparent: true, opacity: .4, depthWrite: false }), 23);
        for (let i = 0; i < 23; i++) {
            const t = (i + .8) / 24;
            const x = THREE.MathUtils.lerp(POINTS.windStart.x, POINTS.plaza.x, t);
            const z = THREE.MathUtils.lerp(POINTS.windStart.z, POINTS.plaza.z, t) - Math.sin(t * Math.PI) * .25;
            this.temp.position.set(x, this.height(x, z) + .14, z);
            this.temp.rotation.set(0, 0, 0);
            this.temp.scale.setScalar(.8 + Math.sin(t * Math.PI) * .55);
            this.temp.updateMatrix();
            dots.setMatrixAt(i, this.temp.matrix);
        }
        dots.instanceMatrix.needsUpdate = true;
        this.targetGuidedRoute = dots;
        this.scene.add(dots);
    }
    targetGuidedRoute;
    createFountain() {
        const position = new Float32Array(this.fountainCount * 3);
        const colors = new Float32Array(this.fountainCount * 3);
        for (let i = 0; i < this.fountainCount; i++) {
            const c = new THREE.Color(i % 3 === 0 ? 0xf9f2c9 : 0x9deee1);
            colors.set([c.r, c.g, c.b], i * 3);
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(position, 3));
        geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        const points = new THREE.Points(geo, new THREE.PointsMaterial({
            size: .095, sizeAttenuation: true, vertexColors: true, transparent: true, opacity: .75,
            depthWrite: false, blending: THREE.AdditiveBlending,
        }));
        points.frustumCulled = false;
        this.scene.add(points);
        return { points, positions: position };
    }
    createFestival() {
        const festival = new THREE.Group();
        const count = 16;
        const lanterns = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.12, 0), new THREE.MeshStandardMaterial({ color: 0xffefc9, emissive: 0xffc574,
            emissiveIntensity: .6, roughness: .7 }), count);
        for (let i = 0; i < count; i++) {
            const a = i / count * TAU;
            const r = i % 2 ? 5.7 : 4.1;
            const x = Math.cos(a) * r, z = Math.sin(a) * r;
            this.temp.position.set(x, this.height(x, z) + 2.45, z);
            this.temp.scale.set(1.0, 1.5, 1.0);
            this.temp.rotation.set(0, a, 0);
            this.temp.updateMatrix();
            lanterns.setMatrixAt(i, this.temp.matrix);
            lanterns.setColorAt(i, new THREE.Color(i % 3 === 0 ? 0xc5f5d6 : i % 3 === 1 ? 0xf9dd9b : 0xdac3fb));
        }
        lanterns.instanceMatrix.needsUpdate = true;
        lanterns.castShadow = false;
        festival.add(lanterns);
        this.scene.add(festival);
        festival.visible = false;
        return festival;
    }
    createSignAftershock() {
        const group = new THREE.Group();
        group.position.set(POINTS.sign.x, this.height(POINTS.sign.x, POINTS.sign.z) + 1.3, POINTS.sign.z);
        const pieces = new THREE.InstancedMesh(new THREE.TetrahedronGeometry(.16, 0), new THREE.MeshBasicMaterial({ color: LIGHT, transparent: true, opacity: .78, depthWrite: false }), 5);
        for (let i = 0; i < 5; i++) {
            const a = -Math.PI * .3 + i * .35;
            this.temp.position.set(Math.cos(a) * .76, Math.sin(a) * .67, .19);
            this.temp.rotation.set(0, a, .2);
            this.temp.scale.set(.30, 1.3, .28);
            this.temp.updateMatrix();
            pieces.setMatrixAt(i, this.temp.matrix);
        }
        pieces.instanceMatrix.needsUpdate = true;
        group.add(pieces);
        group.visible = false;
        this.scene.add(group);
        return group;
    }
    createHandShadow() {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 64;
        const ctx = canvas.getContext('2d');
        const gradient = ctx.createRadialGradient(32, 32, 2, 32, 32, 31);
        gradient.addColorStop(0, 'rgba(20,45,40,.60)');
        gradient.addColorStop(.48, 'rgba(20,45,40,.17)');
        gradient.addColorStop(1, 'rgba(20,45,40,0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 64, 64);
        const texture = new THREE.CanvasTexture(canvas);
        const shadow = new THREE.Mesh(new THREE.PlaneGeometry(2.9, 2.9), new THREE.MeshBasicMaterial({ map: texture, transparent: true, opacity: .45,
            depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 }));
        shadow.rotation.x = -Math.PI / 2;
        shadow.renderOrder = 2;
        shadow.visible = true;
        this.scene.add(shadow);
        return shadow;
    }
    setQuality(mobile) {
        this.isMobile = mobile;
        this.fountain.geometry.setDrawRange(0, mobile ? 16 : this.fountainCount);
        this.horizon.visible = !mobile;
    }
    update(time, rules, hand, reduced) {
        const s = rules.state;
        const active = s.gesture;
        this.targetGuides.strike.visible = !s.rockDone;
        this.targetGuides.sweep.visible = !s.confettiDone && !s.sweepAttached;
        this.targetGuides.ward.visible = !s.signDone;
        for (const g of ['strike', 'sweep', 'ward']) {
            const target = this.targetGuides[g];
            const selected = active === g;
            target.scale.setScalar(selected ? 1.0 + (reduced ? 0 : .035 * Math.sin(time * 2.0)) : .94);
            const m = target.children[0].material;
            m.opacity = selected ? .80 : .22;
        }
        this.targetGuidedRoute.visible = active === 'sweep' && !s.confettiDone;
        const targetPoint = active === 'strike' ? POINTS.strike : active === 'sweep' ? s.wind : POINTS.sign;
        this.activeLight.color.setHex(PALETTE[active]);
        this.activeLight.position.set(targetPoint.x, this.height(targetPoint.x, targetPoint.z) + .85, targetPoint.z);
        const done = active === 'strike' ? s.rockDone : active === 'sweep' ? s.confettiDone : s.signDone;
        this.activeLight.intensity = done ? .25 : this.isMobile ? .60 : 1.1;
        const angle = reduced ? 0 : time;
        this.hourHand.rotation.z = -.62 - angle * .007;
        this.minuteHand.rotation.z = .44 - angle * .033;
        this.brassBell.rotation.z = s.victory && !reduced ? Math.sin(time * 7.0) * .18 : 0;
        this.festival.visible = s.victory;
        this.signAftershock.visible = s.signHasFallenAgain;
        if (this.signAftershock.visible) {
            this.signAftershock.scale.setScalar(reduced ? 1.0 : .82 + .12 * Math.sin(time * 2.3));
        }
        this.hoveringShadow.position.set(hand.x, this.height(hand.x, hand.z) + .11, hand.z);
        this.hoveringShadow.scale.setScalar(reduced ? 1 : 1 + Math.sin(time * 1.7) * .035);
        // One fixed-size particle buffer; no newly allocated object per frame.
        for (let i = 0; i < this.fountainCount; i++) {
            const phase = reduced ? .35 : (time * .42 + i / this.fountainCount) % 1;
            const a = i * 2.39996;
            const distance = .08 + phase * .30;
            const x = POINTS.plaza.x + Math.cos(a) * distance;
            const z = POINTS.plaza.z + Math.sin(a) * distance;
            const rise = phase * (1 - phase) * 1.3;
            const offset = i * 3;
            this.fountainArray[offset] = x;
            this.fountainArray[offset + 1] = this.height(POINTS.plaza.x, POINTS.plaza.z) + .58 + rise;
            this.fountainArray[offset + 2] = z;
        }
        this.fountain.geometry.getAttribute('position').needsUpdate = true;
    }
}
