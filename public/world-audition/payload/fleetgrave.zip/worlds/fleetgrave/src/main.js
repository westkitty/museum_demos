import * as THREE from 'three';
import { CHECKPOINTS, FINISH_X, MIN_X, chapterAt } from './level.js';
import { FIXED_DT, MAX_SIM_STEPS, newGame, stepGame } from './physics.js';
import { buildFleetWorld } from './world.js';
import { makeMuseumReturnRequest, publishMuseumReturn } from './integration.js';

const dom = (id) => {
    const elem = document.getElementById(id);
    if (!elem)
        throw new Error(`Missing app element #${id}`);
    return elem;
};
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const timeString = (sec) => `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
const coarse = window.matchMedia('(pointer: coarse)');
function markup() {
    return `
    <main class="shell" id="shell">
      <canvas id="scene" aria-label="Third-person 3D platformer aboard Picket, Lance and Tender ship hulls, with a giant planet behind the fleet" tabindex="0"></canvas>
      <div class="cinema-grain" aria-hidden="true"></div>
      <div class="vignette" aria-hidden="true"></div>
      <div class="impulse-veil" id="impulseVeil" aria-hidden="true"></div>
      <div class="hud" id="hud" hidden>
        <header class="hud-top">
          <div class="hud-id"><span class="cross" aria-hidden="true">✦</span><span class="hud-id-small">MUSEUM OF ME <b>/</b> E28</span><strong>FLEETGRAVE</strong></div>
          <div class="hud-top-meta"><span class="signal"><i></i> LOCAL SYSTEMS ONLINE</span><span id="clock">00:00</span></div>
        </header>
        <div class="fleet-route" aria-hidden="true"><span id="routePicket" class="active"><i></i>PICKET</span><b></b><span id="routeLance"><i></i>LANCE</span><b></b><span id="routeThroat"><i></i>PASSAGE</span><b></b><span id="routeTender"><i></i>TENDER</span></div>
        <aside class="telemetry" aria-label="Illustrative E28 tactical readouts, not gameplay health or resources">
          <span class="telemetry-heading">TACTICAL RELICS <small>DISPLAY ONLY</small></span>
          <div class="telemetry-row"><span>POWER</span><em id="powerText">NOMINAL</em><div class="meter"><span id="powerBar" style="width:74%"></span></div></div>
          <div class="telemetry-row"><span>HULL INTEGRITY</span><em id="hullText">SEALED</em><div class="meter"><span id="hullBar" style="width:88%"></span></div></div>
          <div class="telemetry-row"><span>THREAT</span><em id="threatText">DISTANT</em><div class="meter hot"><span id="threatBar" style="width:21%"></span></div></div>
          <div class="telemetry-row"><span>SUPPLY</span><em id="supplyText">ROUTED</em><div class="meter green"><span id="supplyBar" style="width:63%"></span></div></div>
        </aside>
        <div class="phase-card" id="phaseCard"><span id="phaseNum">01 / 04</span><h2 id="phaseName">THE WATCHLINE</h2><p id="phaseDescription">Picket · shielding the approach</p></div>
        <div class="right-hud"><div class="progress-label">TRAVERSAL <span id="progressText">00%</span></div><div class="progress-track"><span id="progressFill"></span></div><div class="checkpoint-label"><span class="pip"></span><span id="checkpointText">PICKET / WATCHLINE</span></div><div class="waypoint"><span class="waypoint-kicker">NEXT TRANSFER <b id="nextRange">086 M</b></span><strong id="nextObjective">SALVAGE / ASSEMBLY</strong></div></div>
        <div class="bottom-left"><span class="control-line">WASD / ARROWS <em>MOVE</em> &nbsp; SPACE <em>JUMP</em> &nbsp; SHIFT <em>RUN</em> &nbsp; E <em>BOOST</em></span><span class="minor">R RESET &nbsp;·&nbsp; ESC PAUSE &nbsp;·&nbsp; no combat / no survival stats</span></div>
        <div id="boostStatus" class="boost-status ready"><span class="boost-emblem">◎</span><div><b>MAGNETIC IMPULSE</b><span id="boostText">READY · PRESS E</span></div><span id="boostCharge" class="charge"></span></div>
        <div id="toast" class="toast" role="status" aria-live="polite" aria-atomic="true"></div>
        <div class="top-actions"><button id="motionBtn" class="utility" type="button" aria-pressed="false">REDUCE MOTION: OFF</button><button id="audioBtn" class="utility" type="button" aria-pressed="false">SOUND: OFF</button><button id="pauseBtn" class="utility" type="button">PAUSE <span>Ⅱ</span></button></div>
      </div>
      <div id="touchControls" class="touch-controls" aria-label="Touch movement and actions" hidden>
        <div class="touch-pad"><button type="button" data-action="forward" aria-label="Move forward">▲</button><div><button type="button" data-action="left" aria-label="Move left">◀</button><button type="button" data-action="back" aria-label="Move backward">▼</button><button type="button" data-action="right" aria-label="Move right">▶</button></div></div>
        <div class="touch-actions"><button type="button" data-action="sprint" aria-label="Run faster">RUN</button><button type="button" data-action="boost" aria-label="Magnetic boost">BOOST</button><button type="button" data-action="jump" aria-label="Jump">JUMP</button></div>
      </div>
      <div id="titleScreen" class="screen title-screen" role="dialog" aria-modal="true" aria-labelledby="mainTitle">
        <div class="title-top"><span class="mini-symbol">✦</span> <span>EXHIBIT E28 / AGAINST THE VOID</span><span class="title-top-right">INDEPENDENT POCKET WORLD <span>•</span> 01</span></div>
        <div class="title-main">
          <div class="overline"><span class="line"></span> A JOURNEY ACROSS A DEAD FLEET</div>
          <h1 id="mainTitle"><span>THE</span> <strong>FLEETGRAVE</strong><span>CAUSEWAY</span></h1>
          <p class="title-intro">Three ships. One fragile path between their bones.<br>At the edge of a beautiful, indifferent world.</p>
          <div class="title-divider"></div>
          <p class="title-context">An original traversal interpretation of E28's <em>Picket</em>, <em>Lance</em> and <em>Tender</em> tactical pieces. No fleet combat. Just the distance between them.</p>
          <div class="vessel-legend" aria-label="Course vessels"><span class="picket">01 <b>PICKET</b><small>THE SHIELD</small></span><span class="lance">02 <b>LANCE</b><small>THE SPEAR</small></span><span class="tender">03 <b>TENDER</b><small>THE HAVEN</small></span></div>
          <div class="title-buttons"><button id="startBtn" class="primary" type="button"><span>ENTER THE CAUSEWAY</span><b>↗</b></button><button id="titleReturnBtn" class="secondary" type="button">RETURN TO MUSEUM <span>↗</span></button></div>
        </div>
        <div class="title-foot"><span>WASD / ARROWS MOVE <b>•</b> SPACE JUMP <b>•</b> E MAGNETIC BOOST</span><span>STANDALONE PROTOTYPE <b>—</b> NOT THE LIVE EXHIBIT</span></div>
      </div>
      <div id="pauseScreen" class="screen pause-screen" role="dialog" aria-modal="true" aria-labelledby="pauseTitle" hidden>
        <div class="dialog-panel"><div class="overline">FLIGHT PATH HELD</div><h2 id="pauseTitle">PAUSED <span>// E28</span></h2><p>The void is in no particular hurry.</p><button id="resumeBtn" class="primary" type="button">RESUME TRAVERSAL <b>↗</b></button><button id="resetBtn" class="secondary" type="button">RESTART FROM PICKET</button><button id="pauseReturnBtn" class="secondary" type="button">RETURN TO MUSEUM</button><p class="pause-hint">ESC TO RESUME • R TO RESTART</p></div>
      </div>
      <div id="finishScreen" class="screen finish-screen" role="dialog" aria-modal="true" aria-labelledby="finishTitle" hidden>
        <div class="finish-panel"><span class="overline">E28 / THE LAST HORIZON</span><h2 id="finishTitle">THE FLEET<br><em>STILL HOLDS.</em></h2><p>Three different hulls. One causeway between them. Beyond the wreckage, the planet continues.</p><div class="finish-stats"><div><small>TRAVERSAL</small><strong id="finalTime">00:00</strong></div><div><small>RECOVERIES</small><strong id="finalRespawns">0</strong></div><div><small>DESIGNATION</small><strong>E28</strong></div></div><button id="finishRestartBtn" class="primary" type="button">WALK THE CAUSEWAY AGAIN <b>↗</b></button><button id="finishReturnBtn" class="secondary" type="button">RETURN TO MUSEUM</button></div>
      </div>
      <div id="returnScreen" class="return-screen" role="dialog" aria-modal="true" aria-labelledby="returnTitle" hidden>
        <div class="dialog-panel"><span class="overline">INTEGRATION PREVIEW</span><h2 id="returnTitle">RETURN REQUESTED</h2><p id="returnMessage">A typed museum return event has been emitted. This independent prototype does not navigate or modify E28.</p><button id="returnDismissBtn" class="primary" type="button">STAY IN PROTOTYPE</button></div>
      </div>
      <div id="errorScreen" class="error-screen" role="alert" hidden><h2>WEBGL COULD NOT START</h2><p id="errorMessage"></p><p>Use an up-to-date browser with hardware-accelerated WebGL enabled.</p></div>
      <div class="sr-only" id="announcements" role="status" aria-live="polite"></div>
    </main>`;
}
function buildCharacter() {
    const root = new THREE.Group();
    const body = new THREE.Group();
    root.add(body);
    const white = new THREE.MeshStandardMaterial({ color: 0xd1e1e7, metalness: .58, roughness: .34 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x1a3042, metalness: .78, roughness: .3 });
    const ink = new THREE.MeshStandardMaterial({ color: 0x050f21, metalness: .8, roughness: .19 });
    const lit = new THREE.MeshStandardMaterial({ color: 0x9cecff, emissive: 0x4bdcf6, emissiveIntensity: 2, metalness: .1, roughness: .2 });
    const orange = new THREE.MeshStandardMaterial({ color: 0xe7a76e, emissive: 0xb95f3b, emissiveIntensity: .45, metalness: .6 });
    const cobalt = new THREE.MeshStandardMaterial({ color: 0x466d82, metalness: .74, roughness: .33 });
    const glass = new THREE.MeshStandardMaterial({ color: 0x4ca7be, emissive: 0x0c5d89, emissiveIntensity: .58, metalness: .43, roughness: .13 });
    const sphere = (p, r, x, y, z, mat, scale) => {
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, 20, 14), mat);
        mesh.position.set(x, y, z);
        if (scale)
            mesh.scale.set(...scale);
        p.add(mesh);
        return mesh;
    };
    const box = (p, x, y, z, w, h, d, mat) => {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
        mesh.position.set(x, y, z);
        p.add(mesh);
        return mesh;
    };
    sphere(body, .54, 0, 1.44, 0, white, [.88, 1.15, .91]);
    box(body, -.49, 1.45, 0, .29, .79, .71, dark); // thruster pack
    box(body, -.69, 1.48, 0, .12, .43, .46, lit);
    // Articulated plated EVA suit, with a stronger silhouette from the follow camera.
    box(body, .39, 1.48, 0, .14, .51, .62, cobalt);
    box(body, .48, 1.5, 0, .075, .09, .5, lit);
    for (const side of [-1, 1]) {
        box(body, .30, 1.08, side * .31, .32, .17, .24, white);
        box(body, -.57, 1.48, side * .39, .46, .6, .22, cobalt);
        box(body, -.84, 1.36, side * .33, .08, .22, .16, orange);
    }
    const thrusterLamp = sphere(body, .24, -.92, 1.48, 0, lit, [.55, 1, 1]);
    thrusterLamp.visible = false;
    sphere(body, .41, 0, .92, 0, dark, [1, .53, 1.2]);
    const head = new THREE.Group();
    head.position.y = 2.04;
    body.add(head);
    sphere(head, .57, 0, .1, 0, white);
    sphere(head, .46, .35, .1, 0, ink, [.40, .81, 1.0]);
    sphere(head, .4, .53, .1, 0, glass, [.10, .37, .85]);
    box(head, .57, .20, 0, .075, .055, .54, lit);
    sphere(head, .50, 0, -.23, 0, dark, [1.05, .21, 1.07]);
    box(head, -.35, .59, 0, .33, .1, .15, cobalt);
    for (const side of [-1, 1]) {
        sphere(head, .20, -.09, .10, side * .55, dark, [1, 1.2, .67]);
        box(head, -.04, .1, side * .59, .18, .08, .09, orange);
    }
    const leftArm = new THREE.Group(), rightArm = new THREE.Group();
    const leftLeg = new THREE.Group(), rightLeg = new THREE.Group();
    for (const [sign, arm, leg] of [[-1, leftArm, leftLeg], [1, rightArm, rightLeg]]) {
        arm.position.set(.02, 1.75, sign * .6);
        body.add(arm);
        sphere(arm, .26, 0, -.08, 0, dark, [1, 1.1, 1.1]);
        const forearm = new THREE.Mesh(new THREE.CylinderGeometry(.16, .21, .72, 10), white);
        forearm.position.y = -.47;
        forearm.rotation.z = sign * .04;
        arm.add(forearm);
        sphere(arm, .19, .06, -.82, 0, dark);
        box(arm, .15, -.47, 0, .10, .34, .18, cobalt);
        box(arm, .24, -.78, 0, .08, .08, .22, orange);
        leg.position.set(0, .86, sign * .26);
        body.add(leg);
        const shin = new THREE.Mesh(new THREE.CylinderGeometry(.23, .17, .68, 12), white);
        shin.position.y = -.36;
        leg.add(shin);
        box(leg, .14, -.72, 0, .47, .27, .41, dark);
        box(leg, .32, -.78, 0, .21, .08, .43, lit);
        box(leg, .18, -.31, 0, .12, .14, .32, cobalt);
    }
    box(body, .43, 1.29, -.27, .11, .12, .23, lit);
    box(body, .43, 1.29, .27, .11, .12, .23, lit);
    const glow = sphere(body, .18, -.8, 1.44, 0, lit);
    glow.visible = false;
    // Fresnel-like accent glints are fixed suit geometry, not flashing postprocessing.
    box(head, .52, .43, -.21, .035, .10, .29, orange);
    for (const side of [-1, 1]) {
        box(body, .43, 1.05, side * .44, .065, .31, .17, orange);
        sphere(body, .16, .05, .45, side * .45, ink);
        box(body, -.93, 1.58, side * .33, .20, .09, .14, lit);
    }
    // Prebuilt impulse jets and dynamic line segment exhaust. No allocations in the tick path.
    const boostJets = new THREE.Group();
    body.add(boostJets);
    const ion = new THREE.MeshBasicMaterial({ color: 0x86eaff, transparent: true, opacity: .68,
        depthWrite: false, blending: THREE.AdditiveBlending });
    const jetGeo = new THREE.ConeGeometry(.19, 1.25, 8);
    for (const sign of [-1, 1]) {
        const jet = new THREE.Mesh(jetGeo, ion);
        jet.rotation.z = Math.PI / 2;
        jet.position.set(-1.39, 1.45, sign * .33);
        boostJets.add(jet);
    }
    boostJets.visible = false;
    const trailPositions = new Float32Array(7 * 6);
    const trailGeo = new THREE.BufferGeometry();
    trailGeo.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3).setUsage(THREE.DynamicDrawUsage));
    const boostTrail = new THREE.LineSegments(trailGeo, new THREE.LineBasicMaterial({ color: 0x7adcf4, transparent: true, opacity: .62,
        depthWrite: false, blending: THREE.AdditiveBlending }));
    root.add(boostTrail);
    boostTrail.frustumCulled = false;
    boostTrail.visible = false;
    // Soft elliptical contact shadow gives readable grounding without expensive shadowmaps.
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = shadowCanvas.height = 128;
    const shadowCtx = shadowCanvas.getContext('2d');
    const gradient = shadowCtx.createRadialGradient(64, 64, 4, 64, 64, 62);
    gradient.addColorStop(0, 'rgba(0,0,0,.88)');
    gradient.addColorStop(.48, 'rgba(0,0,0,.51)');
    gradient.addColorStop(1, 'rgba(0,0,0,0)');
    shadowCtx.fillStyle = gradient;
    shadowCtx.fillRect(0, 0, 128, 128);
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const shadow = new THREE.Mesh(new THREE.CircleGeometry(1.15, 48), new THREE.MeshBasicMaterial({
        map: shadowTexture, color: 0x061523, opacity: .7, transparent: true, depthWrite: false,
    }));
    shadow.rotation.x = -Math.PI / 2;
    shadow.scale.set(1.45, .95, 1);
    root.add(shadow);
    return {
        root, body, head, leftLeg, rightLeg, leftArm, rightArm, glow, thrusterLamp, shadow,
        boostJets, boostTrail, trailPositions,
        dispose() {
            const geo = new Set();
            const mats = new Set();
            const textures = new Set();
            root.traverse(obj => {
                const m = obj;
                if (m.geometry)
                    geo.add(m.geometry);
                if (m.material)
                    (Array.isArray(m.material) ? m.material : [m.material]).forEach(mat => mats.add(mat));
            });
            for (const mat of mats)
                for (const value of Object.values(mat)) {
                    if (value instanceof THREE.Texture)
                        textures.add(value);
                }
            geo.forEach(g => g.dispose());
            mats.forEach(m => m.dispose());
            textures.forEach(t => t.dispose());
            root.clear();
        }
    };
}
class TinySound {
    context;
    oscillator;
    sub;
    gain;
    enabled = false;
    set(on) {
        this.enabled = on;
        if (!on) {
            if (this.gain && this.context)
                this.gain.gain.setTargetAtTime(0, this.context.currentTime, .2);
            return false;
        }
        try {
            if (!this.context) {
                this.context = new AudioContext();
                this.oscillator = this.context.createOscillator();
                this.sub = this.context.createOscillator();
                this.gain = this.context.createGain();
                const lower = this.context.createGain();
                lower.gain.value = .22;
                this.oscillator.type = 'sine';
                this.oscillator.frequency.value = 54;
                this.sub.type = 'triangle';
                this.sub.frequency.value = 81;
                this.oscillator.connect(this.gain);
                this.sub.connect(lower);
                lower.connect(this.gain);
                this.gain.connect(this.context.destination);
                this.gain.gain.value = 0;
                this.oscillator.start();
                this.sub.start();
            }
            void this.context.resume();
            this.gain.gain.setTargetAtTime(.025, this.context.currentTime, .35);
        }
        catch {
            this.enabled = false;
        }
        return this.enabled;
    }
    pulse(pitch = 210) {
        if (!this.enabled || !this.context || !this.gain)
            return;
        const osc = this.context.createOscillator(), vol = this.context.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(pitch, this.context.currentTime);
        osc.frequency.exponentialRampToValueAtTime(Math.max(75, pitch / 2), this.context.currentTime + .3);
        vol.gain.setValueAtTime(.045, this.context.currentTime);
        vol.gain.exponentialRampToValueAtTime(.001, this.context.currentTime + .31);
        osc.connect(vol);
        vol.connect(this.context.destination);
        osc.start();
        osc.stop(this.context.currentTime + .32);
        osc.addEventListener('ended', () => { osc.disconnect(); vol.disconnect(); }, { once: true });
    }
    stop() {
        this.enabled = false;
        try {
            this.oscillator?.stop();
            this.sub?.stop();
            void this.context?.close();
        }
        catch { /* best-effort cleanup */ }
        this.context = undefined;
    }
}
class FleetgraveGame {
    renderer;
    world;
    detail;
    camera = new THREE.PerspectiveCamera(58, 1, .1, 2500);
    /** Presentation interpolation, deliberately not part of 60 Hz collision authority. */
    previousPose = new THREE.Vector3();
    renderPose = new THREE.Vector3();
    simulatedPose = new THREE.Vector3();
    cameraDestination = new THREE.Vector3();
    cameraLook = new THREE.Vector3();
    cameraDesiredLook = new THREE.Vector3();
    cameraChase = new THREE.Vector3();
    cameraFocus = new THREE.Vector3();
    cameraPass = new THREE.Vector3();
    cameraPassFocus = new THREE.Vector3();
    cameraReveal = new THREE.Vector3();
    cameraRevealFocus = new THREE.Vector3();
    character;
    sound = new TinySound();
    controller = new AbortController();
    keys = new Set();
    touch = new Set();
    state = newGame();
    mode = 'title';
    reducedMotion;
    soundEnabled = false;
    lastTime = 0;
    accumulated = 0;
    raf = 0;
    width = 1;
    height = 1;
    lastChapter = '';
    lastCheckpoint = -1;
    toastExpires = 0;
    finishCardAt = 0;
    jumpQueued = false;
    boostQueued = false;
    lastMovement = 0;
    landingKick = 0;
    qualityWindowFrames = 0;
    qualitySlowFrames = 0;
    qualityDropped = false;
    wasReturningFrom = 'title';
    disposed = false;
    constructor() {
        dom('app').innerHTML = markup();
        this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const cores = navigator.hardwareConcurrency || 6;
        this.detail = coarse.matches && (cores <= 6 || (window.devicePixelRatio || 1) >= 2) ? 'economy' : 'full';
        this.renderer = new THREE.WebGLRenderer({ canvas: dom('scene'), antialias: true, alpha: false, powerPreference: 'high-performance' });
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.detail === 'economy' ? 1.15 : 1.65));
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.31;
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.renderer.setClearColor(0x030a16, 1);
        this.world = buildFleetWorld(this.detail);
        this.character = buildCharacter();
        this.world.playerAnchor.add(this.character.root);
        this.world.reset();
        this.previousPose.set(this.state.x, this.state.y, this.state.z);
        this.renderPose.copy(this.previousPose);
        this.camera.position.set(-29, 21, 40);
        this.cameraLook.set(25, 4, 0);
        this.bindEvents();
        this.updateMotionButton();
        this.syncModalInert();
        this.resize();
        this.renderHUD(true);
        this.raf = requestAnimationFrame(this.tick);
        if (new URLSearchParams(location.search).has('autostart'))
            this.start();
        if (({DEV:false,PROD:true,MODE:"production",BASE_URL:"./"}).DEV && new URLSearchParams(location.search).has('debug')) {
            window.__fleetgraveDebug = {
                state: () => ({ ...this.state, mode: this.mode, camera: this.camera.position.toArray(), reducedMotion: this.reducedMotion, detail: this.detail }),
                renderStats: () => ({ calls: this.renderer.info.render.calls, triangles: this.renderer.info.render.triangles, textures: this.renderer.info.memory.textures, geometries: this.renderer.info.memory.geometries }),
                reset: () => this.reset(),
                setPlayer: (x, z = 0, y) => { this.state.x = x; this.state.z = z; if (y !== undefined)
                    this.state.y = y; this.state.vx = 0; this.state.vz = 0; this.previousPose.set(this.state.x, this.state.y, this.state.z); this.renderPose.copy(this.previousPose); },
                setMode: (mode) => { this.mode = mode; },
            };
        }
    }
    addClick(id, fn) { dom(id).addEventListener('click', fn, { signal: this.controller.signal }); }
    bindEvents() {
        this.addClick('startBtn', () => this.start());
        this.addClick('resumeBtn', () => this.resume());
        this.addClick('pauseBtn', () => this.pause());
        this.addClick('resetBtn', () => this.reset());
        this.addClick('finishRestartBtn', () => this.reset());
        this.addClick('titleReturnBtn', () => this.requestMuseumReturn());
        this.addClick('pauseReturnBtn', () => this.requestMuseumReturn());
        this.addClick('finishReturnBtn', () => this.requestMuseumReturn());
        this.addClick('returnDismissBtn', () => this.dismissReturn());
        this.addClick('motionBtn', () => { this.reducedMotion = !this.reducedMotion; this.updateMotionButton(); this.announce(this.reducedMotion ? 'Reduced motion enabled.' : 'Full motion enabled.'); });
        this.addClick('audioBtn', () => { this.soundEnabled = this.sound.set(!this.soundEnabled); dom('audioBtn').textContent = `SOUND: ${this.soundEnabled ? 'ON' : 'OFF'}`; dom('audioBtn').setAttribute('aria-pressed', String(this.soundEnabled)); });
        window.addEventListener('keydown', e => {
            if (this.disposed || e.repeat && ['Space', 'KeyR', 'Escape', 'KeyE'].includes(e.code))
                return;
            const recognized = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyE', 'KeyR', 'ShiftLeft', 'ShiftRight', 'Escape'];
            if (!recognized.includes(e.code))
                return;
            const focused = document.activeElement;
            // Do not hijack a keyboard press intended to activate a menu button.
            if (focused instanceof HTMLButtonElement && (e.code === 'Space' || e.code === 'Enter'))
                return;
            if (this.mode === 'playing')
                e.preventDefault();
            if (e.code === 'Escape') {
                if (this.mode === 'playing')
                    this.pause();
                else if (this.mode === 'paused')
                    this.resume();
                return;
            }
            if (e.code === 'KeyR' && (this.mode === 'playing' || this.mode === 'paused' || this.mode === 'finished')) {
                this.reset();
                return;
            }
            this.keys.add(e.code);
            if (e.code === 'Space' && this.mode === 'playing')
                this.jumpQueued = true;
            if (e.code === 'KeyE' && this.mode === 'playing')
                this.boostQueued = true;
        }, { signal: this.controller.signal });
        window.addEventListener('keyup', e => { this.keys.delete(e.code); }, { signal: this.controller.signal });
        window.addEventListener('blur', () => { this.keys.clear(); this.touch.clear(); if (this.mode === 'playing')
            this.pause(); }, { signal: this.controller.signal });
        document.addEventListener('visibilitychange', () => { if (document.hidden && this.mode === 'playing')
            this.pause(); }, { signal: this.controller.signal });
        window.addEventListener('resize', () => this.resize(), { signal: this.controller.signal });
        coarse.addEventListener('change', () => this.updateTouch(), { signal: this.controller.signal });
        dom('touchControls').querySelectorAll('[data-action]').forEach(btn => {
            const action = btn.dataset.action;
            btn.addEventListener('pointerdown', e => {
                if (this.mode !== 'playing')
                    return;
                e.preventDefault();
                btn.setPointerCapture(e.pointerId);
                this.touch.add(action);
                btn.classList.add('pressed');
                if (action === 'jump')
                    this.jumpQueued = true;
                if (action === 'boost')
                    this.boostQueued = true;
            }, { signal: this.controller.signal });
            const up = () => { this.touch.delete(action); btn.classList.remove('pressed'); };
            btn.addEventListener('pointerup', up, { signal: this.controller.signal });
            btn.addEventListener('pointercancel', up, { signal: this.controller.signal });
            btn.addEventListener('lostpointercapture', up, { signal: this.controller.signal });
            btn.addEventListener('click', e => { if (this.mode !== 'playing')
                return; e.preventDefault(); if (e.detail !== 0)
                return; /* keyboard/screen-reader activation; pointerdown already queued */ /* keyboard/screen-reader activation; pointerdown already queued */ if (action === 'jump')
                this.jumpQueued = true; if (action === 'boost')
                this.boostQueued = true; }, { signal: this.controller.signal });
        });
        window.addEventListener('pagehide', () => this.dispose(), { once: true, signal: this.controller.signal });
    }
    /** Keep hidden/covered surfaces out of keyboard focus while a dialog owns interaction. */
    syncModalInert() {
        const returning = !dom('returnScreen').hidden;
        const blockWorld = this.mode !== 'playing' || returning;
        dom('scene').inert = blockWorld;
        dom('hud').inert = blockWorld;
        dom('touchControls').inert = blockWorld;
        for (const id of ['titleScreen', 'pauseScreen', 'finishScreen'])
            dom(id).inert = returning;
    }
    updateMotionButton() {
        dom('motionBtn').textContent = `REDUCE MOTION: ${this.reducedMotion ? 'ON' : 'OFF'}`;
        dom('motionBtn').setAttribute('aria-pressed', String(this.reducedMotion));
        document.documentElement.classList.toggle('reduced-motion', this.reducedMotion);
    }
    updateTouch() {
        dom('touchControls').hidden = !(this.mode === 'playing' && coarse.matches);
        document.documentElement.classList.toggle('touch-active', this.mode === 'playing' && coarse.matches);
    }
    start() {
        this.state = newGame();
        this.mode = 'playing';
        this.lastChapter = '';
        this.lastCheckpoint = -1;
        this.lastMovement = 0;
        this.landingKick = 0;
        this.world.reset();
        this.previousPose.set(this.state.x, this.state.y, this.state.z);
        this.renderPose.copy(this.previousPose);
        dom('titleScreen').hidden = true;
        dom('pauseScreen').hidden = true;
        dom('finishScreen').hidden = true;
        dom('hud').hidden = false;
        this.updateTouch();
        this.syncModalInert();
        this.announce('Causeway entered. Walk the Picket dorsal spine.');
        this.toast('01  /  THE WATCHLINE', 3.0);
        dom('scene').focus({ preventScroll: true });
        this.renderHUD(true);
    }
    pause() {
        if (this.mode !== 'playing')
            return;
        this.mode = 'paused';
        this.keys.clear();
        this.touch.clear();
        dom('pauseScreen').hidden = false;
        this.updateTouch();
        this.syncModalInert();
        dom('resumeBtn').focus();
    }
    resume() {
        if (this.mode !== 'paused')
            return;
        this.mode = 'playing';
        dom('pauseScreen').hidden = true;
        this.lastTime = performance.now();
        this.updateTouch();
        this.syncModalInert();
        dom('scene').focus({ preventScroll: true });
    }
    reset() {
        this.state = newGame();
        this.mode = 'playing';
        this.lastTime = performance.now();
        this.accumulated = 0;
        this.jumpQueued = false;
        this.boostQueued = false;
        this.keys.clear();
        this.touch.clear();
        this.lastChapter = '';
        this.lastCheckpoint = -1;
        this.finishCardAt = 0;
        this.lastMovement = 0;
        this.landingKick = 0;
        this.world.reset();
        this.previousPose.set(this.state.x, this.state.y, this.state.z);
        this.renderPose.copy(this.previousPose);
        this.camera.position.set(-29, 21, 40);
        this.cameraLook.set(25, 4, 0);
        this.character.body.rotation.set(0, 0, 0);
        this.character.body.scale.set(1, 1, 1);
        this.character.root.rotation.set(0, 0, 0);
        this.character.boostJets.visible = false;
        this.character.boostTrail.visible = false;
        dom('impulseVeil').classList.remove('active');
        dom('titleScreen').hidden = true;
        dom('pauseScreen').hidden = true;
        dom('finishScreen').hidden = true;
        dom('returnScreen').hidden = true;
        dom('hud').hidden = false;
        this.updateTouch();
        this.syncModalInert();
        this.toast('COURSE RESET  /  PICKET', 2.6);
        this.announce('Run reset. All checkpoints, boost and timing restored.');
        dom('scene').focus({ preventScroll: true });
        this.renderHUD(true);
    }
    requestMuseumReturn() {
        this.wasReturningFrom = this.mode;
        const request = makeMuseumReturnRequest(this.state);
        publishMuseumReturn(request);
        dom('returnScreen').hidden = false;
        this.keys.clear();
        this.touch.clear();
        this.updateTouch();
        this.syncModalInert();
        dom('returnDismissBtn').focus();
    }
    dismissReturn() {
        dom('returnScreen').hidden = true;
        this.syncModalInert();
        if (this.wasReturningFrom === 'paused')
            dom('resumeBtn').focus();
        else if (this.wasReturningFrom === 'finished')
            dom('finishRestartBtn').focus();
        else if (this.wasReturningFrom === 'title')
            dom('startBtn').focus();
        else
            dom('scene').focus({ preventScroll: true });
    }
    announce(msg) { dom('announcements').textContent = msg; }
    toast(message, seconds = 2.3) {
        dom('toast').textContent = message;
        dom('toast').classList.add('visible');
        this.toastExpires = this.state.elapsed + seconds;
    }
    sampleInput() {
        const down = (action, ...codes) => this.touch.has(action) || codes.some(k => this.keys.has(k));
        return {
            forward: Number(down('forward', 'KeyW', 'ArrowUp')) - Number(down('back', 'KeyS', 'ArrowDown')),
            lateral: Number(down('right', 'KeyD', 'ArrowRight')) - Number(down('left', 'KeyA', 'ArrowLeft')),
            sprint: down('sprint', 'ShiftLeft', 'ShiftRight'),
            jump: this.jumpQueued,
            boost: this.boostQueued,
        };
    }
    tick = (timestamp) => {
        if (this.disposed)
            return;
        this.raf = requestAnimationFrame(this.tick);
        const dt = this.lastTime ? Math.min((timestamp - this.lastTime) / 1000, .07) : 0;
        this.lastTime = timestamp;
        // Conservative one-way resolution governor, sampled after sustained slow frames.
        if (this.mode === 'playing' && !this.qualityDropped && dt > 0) {
            this.qualityWindowFrames++;
            if (dt > .040)
                this.qualitySlowFrames++;
            if (this.qualityWindowFrames >= 240) {
                if (this.qualitySlowFrames >= 130) {
                    this.qualityDropped = true;
                    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.0));
                    this.resize();
                    this.announce('Rendering resolution adjusted to keep traversal responsive.');
                }
                this.qualityWindowFrames = 0;
                this.qualitySlowFrames = 0;
            }
        }
        if (this.mode === 'playing' && dom('returnScreen').hidden) {
            this.accumulated = Math.min(.09, this.accumulated + dt);
            let steps = 0;
            while (this.accumulated >= FIXED_DT && steps < MAX_SIM_STEPS) {
                const input = this.sampleInput();
                this.previousPose.set(this.state.x, this.state.y, this.state.z);
                stepGame(this.state, input, FIXED_DT);
                // Never interpolate across an instant checkpoint recovery or teleport.
                if (this.state.lastEvent === 'respawn')
                    this.previousPose.set(this.state.x, this.state.y, this.state.z);
                this.jumpQueued = false;
                this.boostQueued = false;
                this.accumulated -= FIXED_DT;
                steps++;
                this.reactToEvent();
                if (this.state.completed)
                    break;
            }
            this.renderHUD(false);
            if (this.toastExpires <= this.state.elapsed)
                dom('toast').classList.remove('visible');
        }
        else {
            this.accumulated = 0;
        }
        if (this.mode === 'playing' && dom('returnScreen').hidden) {
            this.renderPose.lerpVectors(this.previousPose, this.simulatedPose.set(this.state.x, this.state.y, this.state.z), clamp(this.accumulated / FIXED_DT, 0, 1));
        }
        else
            this.renderPose.set(this.state.x, this.state.y, this.state.z);
        this.world.update(this.state.elapsed, this.reducedMotion, this.renderPose.x);
        dom('impulseVeil').classList.toggle('active', this.mode === 'playing' && !this.reducedMotion && this.state.boostTime > 0);
        this.animateCharacter(dt);
        this.updateCamera(dt);
        this.renderer.render(this.world.scene, this.camera);
        if (this.mode === 'finished' && this.finishCardAt > 0 && timestamp >= this.finishCardAt) {
            dom('finishScreen').hidden = false;
            this.finishCardAt = 0;
            this.syncModalInert();
            dom('finishRestartBtn').focus();
        }
    };
    reactToEvent() {
        const event = this.state.lastEvent;
        if (event === 'boost') {
            this.world.triggerBoost(this.state.x, this.state.y, this.state.z);
            this.sound.pulse(330);
            this.toast('MAGNETIC IMPULSE  /  ENGAGED', 2.0);
            this.announce('Magnetic boost engaged.');
        }
        else if (event === 'respawn') {
            this.world.triggerImpact('recovery', this.state.x, this.state.y, this.state.z);
            this.sound.pulse(120);
            this.toast(`RECOVERED  /  ${CHECKPOINTS[this.state.checkpoint].name.toUpperCase()}`);
            this.announce(`Recovered at checkpoint ${CHECKPOINTS[this.state.checkpoint].name}. Magnetic impulse recharged.`);
        }
        else if (event === 'checkpoint') {
            this.world.activateCheckpoint(this.state.checkpoint);
            this.world.triggerImpact('checkpoint', this.state.x, this.state.y, this.state.z);
            this.sound.pulse(260);
            this.toast(`CHECKPOINT  /  ${CHECKPOINTS[this.state.checkpoint].name.toUpperCase()}`);
            this.announce(`Checkpoint saved: ${CHECKPOINTS[this.state.checkpoint].name}.`);
        }
        else if (event === 'jump') {
            this.world.triggerImpact('jump', this.state.x, this.state.y, this.state.z);
            this.sound.pulse(175);
        }
        else if (event === 'land') {
            this.world.triggerImpact('land', this.state.x, this.state.y, this.state.z);
            this.landingKick = Math.min(.22, .09 + Math.abs(this.state.vx) * .003);
        }
        else if (event === 'finished')
            this.finish();
    }
    finish() {
        this.mode = 'finished';
        this.keys.clear();
        this.touch.clear();
        this.updateTouch();
        this.syncModalInert();
        this.sound.pulse(540);
        dom('finalTime').textContent = timeString(this.state.elapsed);
        dom('finalRespawns').textContent = String(this.state.respawns);
        this.toast('THE FLEET STILL HOLDS  /  CAUSEWAY COMPLETE', 3.5);
        // Reduced motion removes authored camera travel and finish-card delay.
        this.finishCardAt = performance.now() + (this.reducedMotion ? 0 : 2800);
        if (this.reducedMotion) {
            dom('finishScreen').hidden = false;
            this.syncModalInert();
            this.finishCardAt = 0;
            dom('finishRestartBtn').focus();
        }
        this.announce('Course complete. Three ships against the planet. You may restart or request a museum return.');
    }
    animateCharacter(dt) {
        const s = this.state;
        this.world.playerAnchor.position.copy(this.renderPose);
        const c = this.character;
        const moving = this.mode === 'playing' && s.grounded && Math.abs(s.vx) + Math.abs(s.vz) > 1;
        this.lastMovement = moving ? this.lastMovement + dt * (s.vx > 14 ? 13 : 9) : this.lastMovement * .92;
        const amp = moving && !this.reducedMotion ? Math.min(.62, Math.hypot(s.vx, s.vz) / 28) : 0;
        const swing = Math.sin(this.lastMovement) * amp;
        c.leftLeg.rotation.z = swing;
        c.rightLeg.rotation.z = -swing;
        c.leftArm.rotation.z = -swing * .74;
        c.rightArm.rotation.z = swing * .74;
        const easing = Math.min(1, dt * 10);
        c.head.rotation.z = this.reducedMotion ? 0 : Math.sin(s.elapsed * 1.8) * .025;
        c.head.rotation.y = this.reducedMotion ? 0 : Math.sin(s.elapsed * .91) * .045;
        const lean = this.reducedMotion ? 0 : s.boostTime > 0 ? -.25 : moving ? -.09 - Math.min(.12, Math.abs(s.vx) * .004) : 0;
        c.body.rotation.z += (lean - c.body.rotation.z) * easing;
        this.landingKick *= Math.exp(-dt * 13);
        c.body.scale.y = this.reducedMotion ? 1 : 1 - this.landingKick;
        c.root.position.y = moving && !this.reducedMotion ? Math.abs(Math.sin(this.lastMovement)) * .048 : 0;
        const yaw = Math.atan2(s.vz, Math.max(.1, s.vx)) * -.68;
        c.root.rotation.y += (yaw - c.root.rotation.y) * easing;
        if (!s.grounded) {
            c.leftLeg.rotation.z = .22;
            c.rightLeg.rotation.z = -.15;
            c.leftArm.rotation.z = -.35;
            c.rightArm.rotation.z = .35;
        }
        c.glow.visible = s.boostTime > 0;
        c.glow.scale.setScalar(s.boostTime > 0 ? 1.5 : 1);
        c.thrusterLamp.visible = s.boostTime > 0;
        c.thrusterLamp.scale.setScalar(s.boostTime > 0 ? 1.65 : 1);
        const impulse = s.boostTime > 0 && !this.reducedMotion;
        c.boostJets.visible = impulse;
        c.boostTrail.visible = impulse;
        if (impulse) {
            const pos = c.trailPositions;
            for (let i = 0; i < pos.length / 6; i++) {
                const j = i * 6;
                const phase = s.elapsed * 13 + i * 1.7;
                const z = (i % 2 ? -1 : 1) * (.18 + i * .06);
                pos[j] = -.99 - i * .19;
                pos[j + 1] = 1.15 + Math.sin(phase) * .10;
                pos[j + 2] = z;
                pos[j + 3] = -2.2 - i * .38;
                pos[j + 4] = 1.18 + Math.sin(phase + .8) * .18;
                pos[j + 5] = z * 1.45;
            }
            c.boostTrail.geometry.getAttribute('position').needsUpdate = true;
        }
        c.shadow.visible = s.grounded;
        c.shadow.position.y = -.04;
    }
    updateCamera(dt) {
        const s = this.state;
        if (this.mode === 'title') {
            this.cameraDestination.set(-36, 24, 41);
            this.cameraDesiredLook.set(26, 2, -14);
        }
        else if (this.mode === 'finished' || s.x > 344) {
            // The authored end shot frames all three ships and the planet, without forcing camera input.
            this.cameraDestination.set(404, 108, 240);
            this.cameraDesiredLook.set(160, -16, -86);
        }
        else {
            const x = this.renderPose.x, y = this.renderPose.y;
            const inPassage = smooth(180, 207, x) * (1 - smooth(244, 265, x));
            const reveal = smooth(242, 258, x) * (1 - smooth(287, 319, x));
            const chase = this.cameraChase.set(x - 17.5, y + 11.7, this.renderPose.z + 19.1);
            const look = this.cameraFocus.set(x + 9.5, y + 2.3, this.renderPose.z);
            // Stay *between* the moving walls: the previous exterior viewpoint entered the right hull.
            const throat = this.cameraPass.set(x - 12.5, y + 13.5, this.renderPose.z + 8);
            const throatLook = this.cameraPassFocus.set(x + 13, y + 4.1, 0);
            chase.lerp(throat, inPassage);
            look.lerp(throatLook, inPassage);
            // Short lateral orbit reveals vessel silhouettes immediately after the moving passage.
            const orbit = this.cameraReveal.set(x + 21, y + 27, 71);
            const orbitLook = this.cameraRevealFocus.set(x - 60, y - 4.5, -5);
            chase.lerp(orbit, reveal * .84);
            look.lerp(orbitLook, reveal * .79);
            this.cameraDestination.copy(chase);
            this.cameraDesiredLook.copy(look);
        }
        const a = this.reducedMotion ? 1 : 1 - Math.exp(-dt * (this.mode === 'finished' ? 1.1 : 3.5));
        this.camera.position.lerp(this.cameraDestination, a);
        this.cameraLook.lerp(this.cameraDesiredLook, this.reducedMotion ? 1 : a * .83);
        this.camera.lookAt(this.cameraLook);
        this.camera.fov = this.mode === 'finished' ? 58 : 59;
        this.camera.updateProjectionMatrix();
    }
    renderHUD(force) {
        if (this.mode === 'title')
            return;
        const s = this.state, chapter = chapterAt(s.x);
        if (this.lastChapter !== chapter.id || force) {
            this.lastChapter = chapter.id;
            dom('phaseNum').textContent = chapter.ordinal;
            dom('phaseName').textContent = chapter.title;
            dom('phaseDescription').textContent = chapter.description;
            const route = ['picket', 'lance', 'throat', 'tender'];
            const stage = route.indexOf(chapter.id);
            ['routePicket', 'routeLance', 'routeThroat', 'routeTender'].forEach((id, i) => {
                dom(id).classList.toggle('active', i === stage);
                dom(id).classList.toggle('passed', i < stage);
            });
            if (!force && s.x > 8)
                this.announce(`${chapter.ordinal}: ${chapter.title}. ${chapter.description}.`);
        }
        if (this.lastCheckpoint !== s.checkpoint || force) {
            this.lastCheckpoint = s.checkpoint;
            dom('checkpointText').textContent = CHECKPOINTS[s.checkpoint].name.toUpperCase();
        }
        const target = CHECKPOINTS[s.checkpoint + 1];
        dom('nextObjective').textContent = target ? target.name.toUpperCase() : 'THE FINAL OVERLOOK';
        dom('nextRange').textContent = `${String(Math.max(0, Math.ceil((target?.x ?? FINISH_X) - s.x))).padStart(3, '0')} M`;
        const progress = clamp((s.x - MIN_X) / (FINISH_X - MIN_X), 0, 1);
        dom('progressText').textContent = `${Math.round(progress * 100).toString().padStart(2, '0')}%`;
        dom('progressFill').style.width = `${progress * 100}%`;
        dom('clock').textContent = timeString(s.elapsed);
        const boost = dom('boostStatus');
        boost.classList.toggle('ready', s.boostReady);
        boost.classList.toggle('spent', !s.boostReady);
        dom('boostText').textContent = s.boostReady ? 'READY · PRESS E' : s.boostTime > 0 ? 'ENGAGED' : 'SPENT · RECHARGES ON RECOVERY';
        const zone = s.x < 68 ? 0 : s.x < 180 ? 1 : s.x < 241 ? 2 : 3;
        const display = [
            { power: ['NOMINAL', 72], hull: ['SEALED', 86], threat: ['DISTANT', 21], supply: ['ROUTED', 61] },
            { power: ['CHARGED', 93], hull: ['SCARRED', 65], threat: ['SIGNAL', 43], supply: ['THIN', 41] },
            { power: ['IMPULSE', 100], hull: ['SHIFTING', 49], threat: ['CLOSE', 77], supply: ['BRIDGED', 57] },
            { power: ['STABLE', 81], hull: ['HELD', 71], threat: ['CLEAR', 14], supply: ['RESTORED', 94] },
        ][zone];
        for (const key of ['power', 'hull', 'threat', 'supply']) {
            const pair = display[key];
            dom(`${key}Text`).textContent = pair[0];
            dom(`${key}Bar`).style.width = `${pair[1]}%`;
        }
    }
    resize() {
        const canvas = dom('scene');
        this.width = Math.max(1, canvas.clientWidth);
        this.height = Math.max(1, canvas.clientHeight);
        this.camera.aspect = this.width / this.height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(this.width, this.height, false);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        cancelAnimationFrame(this.raf);
        this.controller.abort();
        this.keys.clear();
        this.touch.clear();
        this.character.dispose();
        this.world.dispose();
        this.sound.stop();
        this.renderer.renderLists.dispose();
        this.renderer.dispose();
    }
}
try {
    new FleetgraveGame();
}
catch (error) {
    // A structured failure, not a blank canvas or false 'loading' promise.
    console.error('Fleetgrave initialization failed', error);
    const el = document.getElementById('errorScreen');
    if (el) {
        el.hidden = false;
        document.getElementById('errorMessage').textContent = error instanceof Error ? error.message : String(error);
    }
    else
        document.getElementById('app').textContent = `Fleetgrave could not start: ${String(error)}`;
}
