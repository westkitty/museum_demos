const keyMap = {
    ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
    Space: 'jump', ArrowUp: 'jump', KeyW: 'jump', KeyE: 'activate', Enter: 'activate'
};
/** Unified edge-triggered input with pointer ownership and explicit disposal. */
export class Input {
    held = new Set();
    pressed = new Set();
    pointers = new Map();
    buttons = [];
    enabled = false;
    constructor(touchHost) {
        window.addEventListener('keydown', this.keydown, { passive: false });
        window.addEventListener('keyup', this.keyup, { passive: false });
        window.addEventListener('blur', this.blur);
        for (const el of touchHost.querySelectorAll('[data-control]')) {
            const key = el.dataset.control;
            if (!['left', 'right', 'jump', 'activate'].includes(key))
                continue;
            el.addEventListener('pointerdown', this.pointerDown);
            el.addEventListener('pointerup', this.pointerUp);
            el.addEventListener('pointercancel', this.pointerUp);
            el.addEventListener('lostpointercapture', this.pointerUp);
            el.addEventListener('contextmenu', this.preventContext);
            this.buttons.push(el);
        }
    }
    setEnabled(value) { this.enabled = value; if (!value)
        this.blur(); }
    preventContext = (e) => e.preventDefault();
    keydown = (e) => {
        const el = e.target;
        if (el.closest('button,input,select,textarea,[role="dialog"]'))
            return;
        const key = keyMap[e.code];
        if (!key || !this.enabled)
            return;
        e.preventDefault();
        if (!e.repeat && !this.held.has(key))
            this.pressed.add(key);
        this.held.add(key);
    };
    keyup = (e) => { const key = keyMap[e.code]; if (!key)
        return; if (this.enabled)
        e.preventDefault(); this.held.delete(key); };
    pointerDown = (e) => {
        if (!this.enabled)
            return;
        e.preventDefault();
        const el = e.currentTarget, key = el.dataset.control;
        this.pointers.set(e.pointerId, key);
        this.held.add(key);
        this.pressed.add(key);
        el.classList.add('held');
        el.setPointerCapture?.(e.pointerId);
    };
    pointerUp = (e) => {
        const key = this.pointers.get(e.pointerId);
        if (!key)
            return;
        this.pointers.delete(e.pointerId);
        if (![...this.pointers.values()].includes(key))
            this.held.delete(key);
        e.currentTarget.classList.remove('held');
    };
    blur = () => { this.held.clear(); this.pressed.clear(); this.pointers.clear(); for (const b of this.buttons)
        b.classList.remove('held'); };
    consume() {
        const controls = { axis: this.held.has('left') && !this.held.has('right') ? -1 : this.held.has('right') && !this.held.has('left') ? 1 : 0,
            jump: this.held.has('jump'), jumpPressed: this.pressed.has('jump'), activate: this.pressed.has('activate') };
        this.pressed.clear();
        return controls;
    }
    snapshot() { return { axis: this.held.has('left') && !this.held.has('right') ? -1 : this.held.has('right') && !this.held.has('left') ? 1 : 0, jump: this.held.has('jump'), jumpPressed: false, activate: false }; }
    dispose() {
        window.removeEventListener('keydown', this.keydown);
        window.removeEventListener('keyup', this.keyup);
        window.removeEventListener('blur', this.blur);
        for (const el of this.buttons) {
            el.removeEventListener('pointerdown', this.pointerDown);
            el.removeEventListener('pointerup', this.pointerUp);
            el.removeEventListener('pointercancel', this.pointerUp);
            el.removeEventListener('lostpointercapture', this.pointerUp);
            el.removeEventListener('contextmenu', this.preventContext);
        }
        this.blur();
    }
}
