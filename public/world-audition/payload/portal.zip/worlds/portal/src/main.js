import { Game } from './game.js';
const query = (selector) => {
    const el = document.querySelector(selector);
    if (!el)
        throw new Error(`Missing UI element: ${selector}`);
    return el;
};
const screens = {
    entry: query('#entry-screen'), pause: query('#pause-screen'),
    win: query('#win-screen'), museum: query('#museum-screen'), error: query('#error-screen')
};
let visibleScreen = 'entry';
let game = null;
let noticeTimer = null;
let pointerDrag = null;
let lastPointer = { x: 0, y: 0 };
const stageNames = ['', 'CONNECTION', 'CAPABILITY', 'AUTHORITY'];
const galleryNames = ['', 'THE REVERSIBLE ATRIUM', 'THE ORRERY OF CUSTODY', 'THE UNGRANTED CATHEDRAL'];
const announce = query('#notice');
const screenControls = query('#play-ui');
function showScreen(next) {
    visibleScreen = next;
    for (const [id, element] of Object.entries(screens)) {
        element.hidden = id !== next;
    }
    if (next === 'game')
        screenControls.removeAttribute('inert');
    else
        screenControls.setAttribute('inert', '');
    if (next !== 'game') {
        if (document.pointerLockElement)
            document.exitPointerLock();
        game?.pause();
    }
    const first = next === 'pause' ? '#resume-button' : next === 'win' ? '#restart-button' : next === 'museum' ? '#reenter-button' : '#begin-button';
    if (next !== 'game')
        window.setTimeout(() => query(first).focus(), 0);
}
function hint(message) {
    announce.textContent = message;
    announce.hidden = false;
    announce.classList.remove('notice-in');
    void announce.offsetWidth;
    announce.classList.add('notice-in');
    if (noticeTimer !== null)
        window.clearTimeout(noticeTimer);
    noticeTimer = window.setTimeout(() => { announce.hidden = true; }, 4800);
}
function updateState(state, goal, phases) {
    document.body.dataset.chamber = String(state.chamber);
    query('#chamber-count').textContent = `0${state.chamber}`;
    query('#spine-count').textContent = `0${state.chamber}`;
    query('#hud-division').textContent = galleryNames[state.chamber];
    query('#stage-name').textContent = stageNames[state.chamber];
    query('#mission-title').textContent = state.chamber === 1 ? 'ONE LINK. TWO SIDES.' : state.chamber === 2 ? 'AUTHORITY IN TRANSIT.' : 'GRANDEUR IS NOT PERMISSION.';
    query('#mission-desc').textContent = goal;
    const linked = state.linked;
    query('#authority-text').textContent = state.chamber === 3
        ? state.verified ? 'EVIDENCE VERIFIED / PROOF PENDING' : state.validated ? 'BOUNDED VALIDATION / APPROVED' : 'PUBLICATION / NOT AUTHORIZED'
        : state.chamber === 2 ? state.inserted ? 'CAPABILITY SEALED / VERIFIED' : 'SYNTHETIC CAPABILITY / LOCAL'
            : linked ? 'PAIRED DOORS / AUTHORIZED' : 'PAIRED DOORS / PENDING';
    query('#authority-state').classList.toggle('is-authorized', linked || state.verified);
    const strip = query('#phase-strip');
    strip.replaceChildren(...phases.map((phase, index) => {
        const el = document.createElement('li');
        el.className = phase.done ? 'is-done' : index === phases.findIndex(p => !p.done) ? 'is-current' : '';
        const number = document.createElement('span');
        number.textContent = String(index + 1).padStart(2, '0');
        const label = document.createElement('b');
        label.textContent = phase.label;
        el.append(number, label);
        return el;
    }));
}
function updateContext(title) {
    const prompt = query('#context-prompt');
    prompt.hidden = !title;
    query('#context-copy').textContent = title ?? '';
}
let visualCueTimer = null;
function showVisualCue(event) {
    const layer = query('#interaction-flash');
    layer.classList.remove('cue-teleport', 'cue-denied', 'cue-authority');
    if (visualCueTimer !== null) {
        window.clearTimeout(visualCueTimer);
        visualCueTimer = null;
    }
    if (document.body.classList.contains('low-motion') || !['teleport', 'denied', 'link', 'seal', 'proof'].includes(event))
        return;
    void layer.offsetWidth;
    layer.classList.add(event === 'teleport' ? 'cue-teleport' : event === 'denied' ? 'cue-denied' : 'cue-authority');
    visualCueTimer = window.setTimeout(() => { layer.classList.remove('cue-teleport', 'cue-denied', 'cue-authority'); visualCueTimer = null; }, 600);
}
function reportError(message) {
    query('#error-detail').textContent = message;
    showScreen('error');
}
try {
    game = new Game(query('#world-host'), {
        onState: updateState, onHint: hint, onContext: updateContext,
        onStage: (stage) => hint(`CHAMBER 0${stage} / ${stageNames[stage]}. Checkpoint established.`),
        onVictory: () => showScreen('win'), onError: reportError, onVisualCue: showVisualCue
    });
}
catch (error) {
    reportError(String(error));
}
function begin(reset) {
    if (!game)
        return;
    if (reset)
        game.restart();
    showScreen('game');
    game.start();
    if (window.matchMedia('(pointer:fine)').matches) {
        void Promise.resolve(game.canvas.requestPointerLock?.()).catch(() => { hint('Pointer lock declined. Drag the scene or use arrow keys to look.'); });
    }
}
query('#begin-button').addEventListener('click', () => begin(true));
query('#resume-button').addEventListener('click', () => begin(false));
query('#checkpoint-button').addEventListener('click', () => { game?.restoreCheckpoint(); begin(false); });
query('#restart-button').addEventListener('click', () => begin(true));
query('#reenter-button').addEventListener('click', () => begin(true));
query('#pause-button').addEventListener('click', () => showScreen('pause'));
query('#return-button').addEventListener('click', () => showScreen('museum'));
query('#win-return-button').addEventListener('click', () => showScreen('museum'));
const media = window.matchMedia('(prefers-reduced-motion: reduce)');
const motionToggle = query('#reduced-motion-toggle');
let stored = null;
try {
    stored = window.localStorage.getItem('e15-reduced-motion');
}
catch { /* optional */ }
motionToggle.checked = stored === null ? media.matches : stored === 'true';
game?.setReducedMotion(motionToggle.checked);
document.body.classList.toggle('low-motion', motionToggle.checked);
motionToggle.addEventListener('change', () => {
    game?.setReducedMotion(motionToggle.checked);
    document.body.classList.toggle('low-motion', motionToggle.checked);
    try {
        window.localStorage.setItem('e15-reduced-motion', String(motionToggle.checked));
    }
    catch { /* optional */ }
});
const moveMap = {
    KeyW: 'forward', ArrowUp: 'forward', KeyS: 'back', ArrowDown: 'back', KeyA: 'left', KeyD: 'right'
};
window.addEventListener('keydown', event => {
    if (event.code === 'Escape' && visibleScreen === 'game') {
        event.preventDefault();
        showScreen('pause');
        return;
    }
    if (visibleScreen !== 'game' || !game)
        return;
    if (event.code in moveMap) {
        event.preventDefault();
        game.setMove(moveMap[event.code], true);
    }
    else if (event.code === 'Space') {
        event.preventDefault();
        game.jump();
    }
    else if (event.code === 'KeyE' || event.code === 'Enter' && event.target === document.body) {
        event.preventDefault();
        if (!event.repeat)
            game.interact();
    }
    else if (event.code === 'KeyR') {
        event.preventDefault();
        if (!event.repeat)
            game.restoreCheckpoint();
    }
    else if (event.code === 'ArrowLeft') {
        event.preventDefault();
        game.keyboardTurn(0.12, 0);
    }
    else if (event.code === 'ArrowRight') {
        event.preventDefault();
        game.keyboardTurn(-0.12, 0);
    }
    else if (event.code === 'PageUp') {
        event.preventDefault();
        game.keyboardTurn(0, 0.08);
    }
    else if (event.code === 'PageDown') {
        event.preventDefault();
        game.keyboardTurn(0, -0.08);
    }
});
window.addEventListener('keyup', event => {
    if (event.code in moveMap)
        game?.setMove(moveMap[event.code], false);
});
window.addEventListener('blur', () => {
    for (const dir of Object.values(moveMap))
        game?.setMove(dir, false);
});
document.addEventListener('mousemove', event => {
    if (visibleScreen !== 'game' || !game)
        return;
    if (document.pointerLockElement === game.canvas)
        game.turn(event.movementX, event.movementY);
    else if (pointerDrag !== null && event.buttons === 1) {
        game.turn(event.clientX - lastPointer.x, event.clientY - lastPointer.y);
        lastPointer = { x: event.clientX, y: event.clientY };
    }
});
game?.canvas.addEventListener('pointerdown', event => {
    if (visibleScreen !== 'game' || !game)
        return;
    if (event.pointerType === 'touch') {
        pointerDrag = event.pointerId;
        lastPointer = { x: event.clientX, y: event.clientY };
        game.canvas.setPointerCapture(event.pointerId);
    }
    else if (document.pointerLockElement !== game.canvas) {
        pointerDrag = event.pointerId;
        lastPointer = { x: event.clientX, y: event.clientY };
        void Promise.resolve(game.canvas.requestPointerLock?.()).catch(() => { });
    }
});
game?.canvas.addEventListener('pointermove', event => {
    if (visibleScreen !== 'game' || !game || pointerDrag !== event.pointerId)
        return;
    if (event.pointerType === 'touch') {
        game.turn(event.clientX - lastPointer.x, event.clientY - lastPointer.y);
        lastPointer = { x: event.clientX, y: event.clientY };
    }
});
const stopDrag = (event) => { if (pointerDrag === event.pointerId)
    pointerDrag = null; };
game?.canvas.addEventListener('pointerup', stopDrag);
game?.canvas.addEventListener('pointercancel', stopDrag);
for (const btn of document.querySelectorAll('[data-hold]')) {
    const direction = btn.dataset.hold;
    const down = (event) => {
        event.preventDefault();
        if (visibleScreen !== 'game')
            return;
        btn.setPointerCapture(event.pointerId);
        game?.setMove(direction, true);
        btn.classList.add('pressed');
    };
    const up = (event) => {
        event.preventDefault();
        game?.setMove(direction, false);
        btn.classList.remove('pressed');
    };
    btn.addEventListener('pointerdown', down);
    btn.addEventListener('pointerup', up);
    btn.addEventListener('pointercancel', up);
    btn.addEventListener('lostpointercapture', () => { game?.setMove(direction, false); btn.classList.remove('pressed'); });
}
query('#touch-jump').addEventListener('pointerdown', (event) => { event.preventDefault(); game?.jump(); });
query('#touch-interact').addEventListener('pointerdown', (event) => { event.preventDefault(); game?.interact(); });
window.addEventListener('beforeunload', () => { game?.destroy(); });
showScreen('entry');
