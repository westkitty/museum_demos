export function selectVisualBudget(width, height, dpr, coarsePointer) {
    const validWidth = Number.isFinite(width) ? Math.max(320, width) : 320;
    const validHeight = Number.isFinite(height) ? Math.max(320, height) : 320;
    const compact = coarsePointer || validWidth * validHeight > 2600000 || validWidth < 750;
    // Keep output pixels bounded on very large displays; sub-1 DPR is a valid fallback.
    const pixelCap = Math.sqrt((compact ? 2200000 : 3500000) / (validWidth * validHeight));
    const pixelRatio = Math.max(0.65, Math.min(Number.isFinite(dpr) ? Math.max(0.65, dpr) : 1, compact ? 1.3 : 1.6, pixelCap));
    return Object.freeze({
        tier: compact ? 'compact' : 'full',
        pixelRatio,
        shadowSize: compact ? 1024 : 1536,
        previewWidth: compact ? 256 : 384,
        previewHeight: compact ? 352 : 512,
        previewStride: compact ? 5 : 3,
        dustCount: compact ? 64 : 115,
        burstCount: compact ? 24 : 44
    });
}
export const VISUAL_CHAPTERS = Object.freeze({
    1: Object.freeze({ name: 'THE REVERSIBLE ATRIUM', accent: 0x42e3d6, atmospheric: 0x274853, backplate: 0x16313d, warm: 0xffd59d, crown: 0x62e6eb }),
    2: Object.freeze({ name: 'THE ORRERY OF CUSTODY', accent: 0xffd68d, atmospheric: 0x464248, backplate: 0x1d2e3c, warm: 0xffca79, crown: 0xffd18b }),
    3: Object.freeze({ name: 'THE UNGRANTED CATHEDRAL', accent: 0x56eedb, atmospheric: 0x343341, backplate: 0x171e34, warm: 0xffd99e, crown: 0xff93a6 })
});
