const p = (id, x, z, top, sx, sz, kind, extra = {}) => ({ id, x, z, top, sx, sz, kind, ...extra });
/** All world space is continuous. Rooms connect to the hub through collision-open arches. */
export const PLATFORMS = [
    p('hub', 0, 0, 0, 29, 27, 'hub'),
    p('north-hall', 0, -22, 0, 10, 20, 'hall'),
    p('east-hall', 23, 0, 0, 20, 10, 'hall'),
    p('west-hall', -23, 0, 0, 20, 10, 'hall'),
    p('south-hall', 0, 23, 0, 10, 20, 'hall'),
    p('throne', 0, 45, 0, 31, 34, 'throne'),
    p('crank-0', 0, -34, 0, 10, 9, 'tile'),
    p('crank-1', -6, -39, 0.9, 5.7, 5.7, 'tile'),
    p('crank-2', -10, -45, 1.8, 5.7, 5.7, 'tile'),
    p('crank-3', -4, -51, 2.7, 5.7, 5.7, 'tile'),
    p('crank-4', 3, -53, 3.6, 5.7, 5.7, 'tile'),
    p('crank-5', 9, -49, 4.5, 7.4, 7.4, 'tile'),
    p('crank-bridge-a', 6, -56, 4.5, 5.8, 5.8, 'bridge', { required: 'crank' }),
    p('crank-bridge-b', 0, -61, 4.5, 7.5, 7.0, 'bridge', { required: 'crank' }),
    p('catch-0', 35, 0, 0, 10, 12, 'tile'),
    p('catch-1', 42, -5, 0.9, 6.8, 6.8, 'spring'),
    p('catch-2', 49, 3, 1.8, 6.8, 6.8, 'spring'),
    p('catch-3', 55, -4, 2.7, 6.8, 6.8, 'spring'),
    p('catch-4', 63, 0, 3.6, 11, 13, 'tile'),
    p('lever-0', -35, 0, 0, 10, 12, 'tile'),
    p('lever-1', -42, -4, 0.8, 6.8, 7.2, 'conveyor', { beltX: -1.4 }),
    p('lever-2', -49, -4, 1.6, 6.8, 7.2, 'conveyor', { beltZ: 1.2 }),
    p('lever-3', -55, 2, 2.4, 7.2, 7.2, 'conveyor', { beltX: 1.1 }),
    p('lever-4', -63, 0, 3.2, 11.5, 10.5, 'tile'),
    p('lever-bridge', -63, 7.5, 3.2, 8.5, 6.8, 'bridge', { required: 'lever' })
];
export const DEVICES = {
    crank: { x: 9, y: 4.5, z: -49, label: 'THE WIND-UP CRANK', verb: 'Wind the crank' },
    catch: { x: 63, y: 3.6, z: -3.5, label: 'THE GOLDEN CATCH', verb: 'Release the catch' },
    lever: { x: -63, y: 3.2, z: -2.5, label: 'THE IMPROBABLE LEVER', verb: 'Pull the lever' }
};
export const REWARDS = {
    crank: { x: 0, y: 5.65, z: -61, label: 'Crank Star' },
    catch: { x: 65.2, y: 4.8, z: 4.2, label: 'Catch Star' },
    lever: { x: -63, y: 4.35, z: 8.2, label: 'Lever Star' }
};
export const THRONE_BUTTON = { x: 0, y: 0, z: 46.8 };
export const GATE_Z = 28.0;
/** A conservative rectangular-platform jump graph, used for deterministic layout regression tests. */
export function reachable(from, to, maxGap = 5.7, maxRise = 2.2) {
    const dx = Math.max(0, Math.abs(from.x - to.x) - (from.sx + to.sx) / 2);
    const dz = Math.max(0, Math.abs(from.z - to.z) - (from.sz + to.sz) / 2);
    const gap = Math.hypot(dx, dz);
    return gap <= maxGap && to.top - from.top <= maxRise && from.top - to.top <= 7;
}
export function pathExists(fromId, toId, unlocked = []) {
    const eligible = PLATFORMS.filter(v => !v.required || unlocked.includes(v.required));
    const source = eligible.find(v => v.id === fromId);
    if (!source)
        return false;
    const seen = new Set([source.id]);
    const queue = [source];
    while (queue.length) {
        const next = queue.shift();
        if (next.id === toId)
            return true;
        for (const target of eligible) {
            if (!seen.has(target.id) && reachable(next, target)) {
                seen.add(target.id);
                queue.push(target);
            }
        }
    }
    return false;
}
